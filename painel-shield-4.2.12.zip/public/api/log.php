<?php
/**
 * Recebe o log que o ERP mandou - 25/08/2026.
 *
 *   POST /api/log.php?cnpj=...&terminal=...&de=...&ate=...
 *   corpo = o zip, cru
 *
 * Publica pelo mesmo motivo do endpoint de licenca: quem chama e o ERP na loja
 * do cliente, que nao tem sessao do painel.
 *
 * ELE SO ACEITA O QUE FOI PEDIDO. O terminal precisa existir, pertencer ao CNPJ
 * informado e ter recebido pedido nas ultimas horas. Sem isso, o endereco vira
 * um lugar aberto para qualquer um despejar arquivo no disco do membro.
 *
 * TETO DE TAMANHO, sempre. Hospedagem compartilhada tem cota, e log de uma
 * semana com o sistema conversando muito passa de dezenas de megabytes.
 */

declare(strict_types=1);

ob_start();

require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/notificacao/comando_erp.php';

// 25 MB. Log da pasta de um dia fica em centenas de KB; uma semana inteira de
// um terminal movimentado nao passa disto compactado.
const SHIELD_LOG_TETO = 26214400;
// Quantos dias o zip fica no disco do membro. Log de suporte serve por
// semanas, nao por anos.
const SHIELD_LOG_DIAS = 30;
// Janela em que a entrega ainda e aceita depois do pedido. O ERP so ve o
// pedido na proxima batida, que pode levar 18 horas; tres dias cobrem
// terminal desligado no fim de semana.
const SHIELD_LOG_JANELA_DIAS = 3;

function responder_log(int $http, string $texto): void
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        http_response_code($http);
    }

    echo json_encode(array('ok' => $http < 400, 'resultado' => $texto));
    exit;
}

if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? '')) !== 'POST') {
    responder_log(405, 'metodo');
}

$cnpj = preg_replace('/[^0-9]/', '', (string) ($_GET['cnpj'] ?? ''));
$terminal = (int) ($_GET['terminal'] ?? 0);

if ($cnpj === '' || $terminal <= 0) {
    responder_log(400, 'pedido');
}

try {
    $stmt = $pdo->prepare(
        'SELECT t.CODIGO, t.FK_EMPRESA, t.VERSAO_EXE, t.log_pedido_em, e.cnpj
           FROM terminais t
           JOIN empresa e ON e.codigo = t.FK_EMPRESA
          WHERE t.CODIGO = :ter LIMIT 1'
    );
    $stmt->execute(array(':ter' => $terminal));
    $linha = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!is_array($linha)) {
        responder_log(404, 'terminal');
    }

    // O CNPJ tem de bater com o do terminal: sem isso, saber um numero de
    // terminal bastaria para despejar arquivo em nome de qualquer cliente.
    $doTerminal = preg_replace('/[^0-9]/', '', (string) $linha['cnpj']);
    if ($doTerminal !== $cnpj) {
        responder_log(403, 'terminal');
    }

    // E tem de ter havido pedido, ha pouco. Endereco que aceita envio sem
    // pedido e disco do membro aberto para quem descobrir a URL.
    $pedidoEm = trim((string) ($linha['log_pedido_em'] ?? ''));
    if ($pedidoEm === ''
        || strtotime($pedidoEm) < strtotime('-' . SHIELD_LOG_JANELA_DIAS . ' days')) {
        responder_log(409, 'sem pedido');
    }

    $corpo = (string) file_get_contents('php://input');
    $tamanho = strlen($corpo);

    if ($tamanho === 0) {
        responder_log(400, 'vazio');
    }
    if ($tamanho > SHIELD_LOG_TETO) {
        responder_log(413, 'grande demais');
    }
    // "PK" e a assinatura do zip. Sem conferir, qualquer coisa entra -- e o que
    // o membro vai abrir depois nao e o que ele espera.
    if (substr($corpo, 0, 2) !== 'PK') {
        responder_log(415, 'nao e zip');
    }

    $nome = sprintf('log_%d_%s_%s.zip', $terminal, $cnpj, date('Ymd_His'));
    $caminho = shield_comando_pasta_logs() . '/' . $nome;

    if (@file_put_contents($caminho, $corpo) === false) {
        responder_log(500, 'nao consegui gravar');
    }

    $stmt = $pdo->prepare(
        'INSERT INTO log_capturado
            (fk_empresa, fk_terminal, de, ate, arquivo, tamanho, versao_exe, expurgo_em)
         VALUES (:emp, :ter, :de, :ate, :arq, :tam, :ver,
                 DATE_ADD(CURDATE(), INTERVAL :dias DAY))'
    );
    $stmt->execute(array(
        ':emp' => (int) $linha['FK_EMPRESA'],
        ':ter' => $terminal,
        ':de' => substr((string) ($_GET['de'] ?? ''), 0, 10) ?: null,
        ':ate' => substr((string) ($_GET['ate'] ?? ''), 0, 10) ?: null,
        ':arq' => $nome,
        ':tam' => $tamanho,
        ':ver' => substr((string) ($linha['VERSAO_EXE'] ?? ''), 0, 20) ?: null,
        ':dias' => SHIELD_LOG_DIAS,
    ));

    // O pedido esta cumprido. Nao limpar aqui faria o mesmo terminal reenviar
    // a cada batida ate a janela expirar.
    $stmt = $pdo->prepare('UPDATE terminais SET log_pedido_em = NULL WHERE CODIGO = :id');
    $stmt->execute(array(':id' => $terminal));

    responder_log(200, 'recebido');
} catch (Throwable $e) {
    error_log('[log] ' . $e->getMessage());
    responder_log(500, 'interno');
}
