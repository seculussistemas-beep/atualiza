<?php

/**
 * Servico de licenca do ERP — 23/08/2026.
 *
 *   POST /api/licenca.php     Content-Type: application/json
 *   {"acao":"validar","cnpj":"...","fingerprint":"M:..;B:..;D:..",
 *    "mac":"00-11-...","nome":"CAIXA1","versao":"7.4.7"}
 *
 * Devolve {"ok":true,"licenca":"<token assinado>","status":"ativa","motivo":"..."}
 *
 * E, havendo mensalidade em aberto, o bloco "cobranca" (04/09/2026):
 *   {"id":77,"descricao":"Mensalidade 09/2026","valor":14900,"vencimento":"2026-09-10",
 *    "situacao":"aberta","provedor":"pix_estatico","apelido":"PIX da loja","metodo":"pix",
 *    "manual":true,"link":"","copia_e_cola":"000201...","informado_em":"","informado_forma":"",
 *    "linha_digitavel":""}
 * -- e o cliente paga pela aba Mensalidade da Licenca do Sistema. O bloco vai
 * tambem no 409 de quem ainda nao tem validade: e a fila de venda pagando a
 * primeira. ERP antigo ignora o bloco, como ignora todo campo que nao conhece.
 *
 * Duas acoes a mais no mesmo pedido, ambas com "cobranca":<id> e a "licenca"
 * guardada como identidade (ou um terminal que este painel ja conhecia pela
 * impressao de hardware):
 *   "acao":"conferir_pagamento"  pergunta ao provedor; se pagou, a validade anda
 *   "acao":"informar_pagamento"  marca a cobranca ("forma", "obs"); e aviso, nao prova
 * A resposta traz "acao_resultado" dizendo o que aconteceu -- no 200 e, desde
 * 14/09/2026, tambem no 409 sem_validade, porque a acao roda (e o informar
 * grava) ANTES de se decidir a validade. Sem identidade: 403.
 *
 * Entrada PUBLICA de proposito: quem chama e o ERP na loja do cliente, que nao
 * tem sessao do painel. Segue o mesmo desenho dos webhooks/ — arquivo solto,
 * require do banco.php, sem passar pelo router.
 *
 * NAO exigir sessao aqui, e NAO devolver nada alem do token: a resposta e lida
 * por programa, e mensagem de erro detalhada em endpoint aberto vira mapa da
 * base para quem estiver sondando.
 *
 * O token e assinado; quem o recebe nao consegue altera-lo. Por isso a
 * resposta pode ser lida por qualquer um sem risco: ela so vale na maquina
 * cuja impressao de hardware esta dentro dela.
 */

declare(strict_types=1);

// Buffer ligado ANTES de qualquer include. Arquivo com BOM antes do <?php --
// havia onze deles no painel em 23/08/2026 -- cospe bytes no corpo da resposta
// e derruba os header() daqui; o ERP receberia BOM onde espera JSON. Com o
// buffer, nada do que os includes emitirem chega ao cliente.
ob_start();

require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/licenca_assinada.php';
require_once __DIR__ . '/../../funcoes/licenca/parque.php';
require_once __DIR__ . '/../../funcoes/licenca/teto_api.php';
require_once __DIR__ . '/../../funcoes/notificacao/comando_erp.php';
require_once __DIR__ . '/../../funcoes/cobranca/relogio.php';
// O contrato novo com o ERP -- 10/09/2026: modulos no token,
// certificado no pedido, todas as cobrancas e a liberacao em confianca.
require_once __DIR__ . '/../../funcoes/licenca/modulos_licenca.php';
require_once __DIR__ . '/../../funcoes/licenca/certificado.php';
require_once __DIR__ . '/../../funcoes/licenca/confianca.php';
require_once __DIR__ . '/../../funcoes/licenca/teste.php';      // os sete dias de avaliacao (fatia 6)

/**
 * Grava a batida e responde -- toda saida deste arquivo passa por aqui.
 *
 * A telemetria vem ANTES do responder() porque o responder() encerra o
 * processo; e vem dentro dele, e nao espalhada pelos pontos de saida, porque
 * ponto de saida que a gente esquece e exatamente o caso raro que interessa
 * medir. shield_parque_registrar NAO levanta: licenca nao para por causa de
 * telemetria.
 */
function responder_e_registrar(PDO $pdo, int $http, array $corpo, array $batida): void
{
    shield_parque_registrar($pdo, $batida);
    responder($http, $corpo);
}

/**
 * Resposta curta. O detalhe vai para o log do servidor, nao para a rede.
 */
function responder(int $http, array $corpo): void
{
    // Joga fora o que os includes tenham emitido e responde so o JSON.
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        http_response_code($http);
    }

    echo json_encode($corpo, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * A empresa de novo, pelo codigo. Existe porque a validade pode andar DENTRO
 * do pedido -- pelo conferir pagamento ou pelo relogio -- e a licenca assinada
 * tem de sair com o valor de agora, nao com o lido no comeco.
 */
/**
 * A copia em memoria da empresa com o teste emprestado (fatia 6): validade =
 * fim do teste, cota = tres caixas. So quando ha teste vigente; fora dele a
 * linha volta como esta no banco. Marca '_teste' para a resposta dizer.
 */
function emprestar_teste(array $empresa): array
{
    global $pdo;
    $cfg = shield_teste_config($pdo);
    if (!shield_teste_vigente($empresa, $cfg)) {
        return $empresa;
    }
    $empresa['validade_licenca'] = shield_teste_fim($empresa, $cfg);
    // A cota do teste e por loja quando o membro a definiu (teste_terminais).
    $empresa['nterminais'] = shield_teste_terminais_de($empresa, $cfg);
    $empresa['_teste'] = true;

    return $empresa;
}

/** ['area_cliente' => ['url' => ...]] ou [] -- nunca pode impedir a licenca de sair. */
function area_cliente_bloco(int $codigo): array
{
    try {
        require_once __DIR__ . '/../../funcoes/licenca/area_cliente.php';
        $url = shield_area_url($codigo);

        return $url !== '' ? ['area_cliente' => ['url' => $url]] : [];
    } catch (Throwable $ignorado) {
        return [];
    }
}

function reler_empresa(PDO $pdo, int $codigo): ?array
{
    $stmt = $pdo->prepare(
        'SELECT * FROM empresa WHERE codigo = :c LIMIT 1'
    );
    $stmt->execute([':c' => $codigo]);
    $linha = $stmt->fetch(PDO::FETCH_ASSOC);

    return is_array($linha) ? $linha : null;
}

if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? '')) !== 'POST') {
    responder(405, ['ok' => false, 'erro' => 'metodo']);
}

$bruto = (string) file_get_contents('php://input');
$pedido = json_decode($bruto, true);
if (!is_array($pedido)) {
    responder(400, ['ok' => false, 'erro' => 'pedido']);
}

$cnpj = preg_replace('/\D+/', '', (string) ($pedido['cnpj'] ?? ''));
$impressao = trim((string) ($pedido['fingerprint'] ?? ''));
$mac = trim((string) ($pedido['mac'] ?? ''));
$nome = trim((string) ($pedido['nome'] ?? ''));
$versao = substr(trim((string) ($pedido['versao'] ?? '')), 0, 20);

// O que o cliente pode pedir alem da licenca - 04/09/2026.
$acao = preg_replace('/[^a-z_]/', '', strtolower((string) ($pedido['acao'] ?? 'validar'))) ?: 'validar';
$cobrancaPedida = (int) ($pedido['cobranca'] ?? 0);
$formaPedida = substr(trim((string) ($pedido['forma'] ?? '')), 0, 20);
$obsPedida = substr(trim((string) ($pedido['obs'] ?? '')), 0, 150);
$tokenDoErp = trim((string) ($pedido['licenca'] ?? ''));

if ($cnpj === '') {
    responder(400, ['ok' => false, 'erro' => 'cnpj']);
}

// O TETO -- 09/09/2026. Ver BAIXO-3 em docs/auditoria-seguranca.md e o
// cabecalho de funcoes/licenca/teto_api.php, onde os numeros sao justificados.
//
// AQUI, e nao antes: so agora existe CNPJ para contar. E antes do emissor,
// porque assinar e a parte cara do pedido e e justamente ela que o martelo
// quer gastar.
//
// A recusa NAO passa por responder_e_registrar. Gravar a batida de quem esta
// sendo barrado alimentaria a propria contagem que o barrou -- o teto se
// reforcaria sozinho e a janela nunca esvaziaria.
$teto = shield_teto_api_excedido($pdo, $cnpj, shield_teto_api_ip());
if ($teto !== null) {
    // 429 e nao 403: o ERP trata resposta diferente de 200 como rede fora e
    // segue com o token que ja tem. Para a loja isto e uma revalidacao adiada,
    // nao um caixa parado.
    responder(429, ['ok' => false, 'erro' => 'teto', 'motivo' => $teto]);
}

try {
    $emissor = shield_licenca_emissor_ativo($pdo);
    if ($emissor === null) {
        // Painel ainda sem par de chaves. O ERP trata isto como "a via
        // assinada nao respondeu" e segue pela via de sempre.
        error_log('[licenca] pedido de ' . $cnpj . ' sem emissor configurado');
        responder_e_registrar($pdo, 503, ['ok' => false, 'erro' => 'emissor'], [
            'cnpj' => $cnpj, 'fingerprint' => $impressao, 'nome' => $nome,
            'versao' => $versao, 'resultado' => 'sem_emissor',
            'motivo' => 'o painel ainda nao tem par de chaves',
        ]);
    }

    $stmt = $pdo->prepare(
        'SELECT *
           FROM empresa WHERE REPLACE(REPLACE(REPLACE(cnpj, ".", ""), "/", ""), "-", "") = :cnpj
          ORDER BY codigo LIMIT 1'
    );
    $stmt->execute([':cnpj' => $cnpj]);
    $empresa = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!is_array($empresa)) {
        // AUTO-CADASTRO. E o canal de venda: o membro manda o instalador, o
        // cliente testa, a empresa aparece aqui e, fechando negocio, basta
        // inserir a validade. Ela nasce INERTE -- sem validade nao ha licenca
        // --, entao copia que ninguem vendeu entra na lista e fica parada.
        $empresa = shield_licenca_criar_empresa($pdo, $cnpj, $pedido);

        if (!is_array($empresa)) {
            // So documento valido cria empresa. Sem isto um CNPJ digitado
            // errado viraria lixo parecido com cliente de verdade.
            error_log('[licenca] documento invalido, nao cadastrado: ' . $cnpj);
            responder_e_registrar($pdo, 400, ['ok' => false, 'erro' => 'documento'], [
                'cnpj' => $cnpj, 'fingerprint' => $impressao, 'nome' => $nome,
                'versao' => $versao, 'resultado' => 'documento_invalido',
                'motivo' => 'CNPJ nao passou na conferencia, empresa nao criada',
            ]);
        }

        error_log('[licenca] empresa cadastrada automaticamente: ' . $cnpj);
    } else {
        // A LOJA JA EXISTIA. Pode ter vindo do auto-cadastro de ontem ou da tela
        // de cadastrar cliente, digitada a mao com CNPJ e nome e mais nada: o
        // ERP completa o que ficou em branco, e nunca encosta no que o membro
        // escreveu (shield_licenca_completar_cadastro). Sem campo vazio nao ha
        // comando nenhum, e este e o caminho mais quente do painel.
        $empresa = shield_licenca_completar_cadastro($pdo, $empresa, $pedido);
    }

    // O TESTE COMECA AQUI PARA QUEM FOI CADASTRADO A MAO -- 16/09/2026, e ANTES
    // de emprestar_teste(): o relogio contava do nascimento do cadastro, entao
    // a loja cadastrada ha tres semanas chegaria com o teste vencido no dia em
    // que instalou. Para quem chega pelo auto-cadastro nada muda, porque ali a
    // primeira chamada e o proprio nascimento.
    $empresa = shield_licenca_iniciar_teste_na_primeira_maquina($pdo, $empresa, shield_teste_config($pdo));

    // OS SETE DIAS DE AVALIACAO -- 10/09/2026, fatia 6. Lead (sem validade,
    // nao encerrado) dentro do teste trabalha como se tivesse validade ate o
    // fim do teste e tres caixas contratados. NADA E GRAVADO: a conta e feita
    // na hora sobre a data em que a empresa nasceu (ou teste_ate), e so nesta
    // copia em memoria -- treze pontos do painel deduzem "lead" por validade
    // nula, e gravar aqui os enganaria todos. Ver funcoes/licenca/teste.php.
    $empresa = emprestar_teste($empresa);

    // Uma transacao para o casamento do terminal: dois caixas abrindo ao mesmo
    // tempo poderiam contar a mesma vaga como livre e estourar a cota.
    $pdo->beginTransaction();
    try {
        $terminal = shield_licenca_reconciliar_terminal(
            $pdo,
            (int) $empresa['codigo'],
            (int) ($empresa['nterminais'] ?? 0),
            $impressao,
            $mac,
            $nome,
            $versao
        );
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }

    // ---------------------------------------------------------------------
    // O cliente paga pelo ERP - 04/09/2026.
    //
    // As duas acoes exigem IDENTIDADE: a licenca assinada que o ERP guarda
    // (prova que foi este painel que a emitiu, para este CNPJ) ou, para a
    // instalacao que ainda nao tem licenca nenhuma -- o cliente da fila de
    // venda pagando a primeira --, um terminal que este painel JA conhecia
    // PELA IMPRESSAO DE HARDWARE. Casar pelo MAC nao vale como identidade:
    // e a rede de seguranca das linhas antigas, e MAC se repete e se digita.
    // Sem uma das duas, quem soubesse um CNPJ encheria a lista do membro de
    // "cliente avisou que pagou".
    //
    // NENHUMA DAS DUAS ESTENDE VALIDADE POR PALAVRA DO CLIENTE: conferir
    // pergunta ao provedor, informar so marca a cobranca.
    // ---------------------------------------------------------------------
    // O CERTIFICADO DIGITAL DA LOJA, quando o ERP o informa -- 10/09/2026.
    // Informacao de gestao, nunca condicao de licenca; por isso fora de
    // qualquer decisao e engolindo a propria falha.
    if (isset($pedido['certificado_vence'])) {
        // A data que o painel ja tinha vai junto: e com ela que a renovacao entra no livro.
        shield_certificado_gravar($pdo, (int) $empresa['codigo'], (string) $pedido['certificado_vence'], $empresa['certificado_vence'] ?? null);
    }

    $acaoResultado = '';
    if ($acao === 'conferir_pagamento' || $acao === 'informar_pagamento' || $acao === 'liberar_confianca' || $acao === 'pedir_prazo') {
        $identidade = ($tokenDoErp !== '' && shield_licenca_token_confere($pdo, $tokenDoErp, $cnpj) !== null)
            || ((int) $terminal['terminal'] > 0
                && (string) $terminal['motivo'] === 'casou pela impressao de hardware');
        if (!$identidade) {
            error_log('[licenca] ' . $cnpj . ' pediu ' . $acao . ' sem identidade');
            responder_e_registrar($pdo, 403, ['ok' => false, 'erro' => 'identidade'], [
                'empresa' => (int) $empresa['codigo'],
                'terminal' => (int) $terminal['terminal'],
                'cnpj' => $cnpj, 'fingerprint' => $impressao, 'nome' => $nome,
                'versao' => $versao, 'resultado' => 'identidade',
                'motivo' => $acao . ' sem licenca assinada nem terminal conhecido',
            ]);
        }

        if ($acao === 'informar_pagamento') {
            $motivo = shield_comando_informar_pagamento(
                $pdo, $empresa, $cobrancaPedida, $formaPedida, $obsPedida
            );
            $acaoResultado = $motivo === '' ? 'informado' : 'nao_informado: ' . $motivo;
        } elseif ($acao === 'pedir_prazo') {
            // "Vou pagar dia 22", pedido de dentro do ERP (doc, secao 1). Nasce
            // pendente: alguem no painel aceita ou recusa, e so aceito o token
            // da batida seguinte anda. Os textos sao os que o doc promete.
            $acaoResultado = shield_promessa_pedir(
                $pdo, $empresa, $cobrancaPedida, (string) ($pedido['ate'] ?? ''), (string) ($pedido['obs'] ?? ''),
                $nome !== '' ? $nome : ('terminal ' . (int) $terminal['terminal'])
            );
        } elseif ($acao === 'liberar_confianca') {
            // "Mais uns dias" pedido pela tela do ERP. O acao_resultado e em
            // PORTUGUES porque o ERP o mostra ao cliente como veio. Concedendo,
            // a licenca assinada abaixo ja sai com o valido_ate novo -- e e o
            // unico efeito: validade, bloqueio e cobranca ficam como estao.
            $r = shield_confianca_conceder($pdo, $empresa, $nome !== '' ? $nome : ('terminal ' . (int) $terminal['terminal']));
            $acaoResultado = (string) $r['motivo'];
        } else {
            $situacao = shield_comando_conferir_pagamento($pdo, $empresa, $cobrancaPedida);
            $acaoResultado = 'conferido: ' . ($situacao !== '' ? $situacao : 'sem_provedor');
        }
    }

    // O RELOGIO DO PAINEL BATE COM O PARQUE. Webhook so era processado quando
    // alguem abria o painel ou o cron rodava; membro sem cron via o cliente
    // pagar e a cobranca ficar aberta. Cada batida do ERP passa a ser um tique
    // (no maximo um a cada cinco minutos -- a trava e do proprio relogio), e o
    // "paguei e nao liberou" deixa de depender de alguem abrir uma tela.
    // NAO levanta e nao suspende ninguem: e o mesmo limite do cron.
    try {
        shield_relogio_oportunista($pdo);
    } catch (Throwable $ignorado) {
    }

    // A validade pode ter andado agora mesmo -- pelo conferir, pelo relogio --
    // e a licenca assinada abaixo tem de sair com ela.
    $relida = reler_empresa($pdo, (int) $empresa['codigo']);
    if ($relida !== null) {
        $empresa = emprestar_teste($relida);
    }

    // A mensalidade em aberto, se houver. Vai nas DUAS respostas -- na
    // assinada e no 409 de quem ainda nao tem validade --, porque o cliente
    // da fila de venda e justamente quem precisa pagar para ganhar a primeira.
    // TODAS as abertas, e a mais urgente e a primeira -- o contrato com o ERP
    // exige que `cobranca` e `cobrancas[0]` sejam a mesma. Uma consulta so.
    // COM AS PAGAS DOS ULTIMOS SETE DIAS (11/09/2026): sem elas o ERP nunca
    // chegava a dizer "paga -- obrigado" -- no instante em que o pagamento
    // entrava a fatura sumia da lista, e a tela ficava muda. Elas vem por
    // ULTIMO: a primeira da lista continua sendo a mais urgente a pagar.
    $cobrancas = shield_comando_cobrancas($pdo, $empresa, 20, true);
    $cobranca = $cobrancas ? $cobrancas[0] : null;

    // Sem validade nao se assina nada. Antes o calculo do prazo caia em
    // "hoje + carencia" quando nao havia validade, e isso e licenca renovavel
    // para sempre -- de graca, para quem quer que rodasse o executavel.
    //
    // O terminal JA foi registrado acima, de proposito: e assim que a maquina
    // aparece na lista com a impressao de hardware, e e por esse numero que o
    // membro precifica antes de vender.
    // ENCERRADO RECEBE LICENCA BLOQUEADA -- 11/09/2026 (era 409 sem licenca,
    // fatia 5). O 409 e o que o ERP conhece como "o painel nao respondeu":
    // ele segura a licenca guardada por ate sete dias, e a loja que o membro
    // acabou de encerrar continuava trabalhando a semana inteira -- visto no
    // painel de testes, no primeiro encerramento de verdade. Encerrar e uma
    // decisao, e decisao viaja ASSINADA: a licenca sai como bloqueada (o ERP
    // so obedece ao que esta assinado) e a loja para no proximo contato. A
    // marca continua sendo so uma marca: reabrir e um clique na ficha e a
    // batida seguinte devolve a licenca de sempre. Sem validade tambem se
    // assina aqui: bloqueada nao e licenca de graca para ninguem.
    $encerrado = trim((string) ($empresa['encerrado_em'] ?? '')) !== '';

    // O TIPO DO BLOQUEIO -- 14/09/2026. O token reduz encerramento, bloqueio
    // manual e suspensao por divida a mesma palavra, 'bloqueada', e o ERP
    // manda os tres falarem com o suporte -- inclusive quem so precisa pagar.
    // O tipo vai FORA do token ($extras['bloqueio'], mais abaixo): palavra nova
    // dentro do status assinado seria desconhecida para o ERP em campo, e o
    // conteudo assinado nao muda por causa de um texto de tela.
    //
    // CALCULADO AQUI, antes do bloco do encerrado: ele apaga o suspenso_em da
    // copia em memoria. A regra de suspensao e a MESMA de
    // shield_licenca_montar_conteudo (bloqueado 'S' com suspenso_em preenchido),
    // senao a resposta diria um tipo e o token decidiria por outro.
    $bloqueioTipo = '';
    $bloqueioDesde = '';
    if ($encerrado) {
        $bloqueioTipo = 'encerrado';
        $bloqueioDesde = substr(trim((string) $empresa['encerrado_em']), 0, 10);
    } elseif (strtoupper(trim((string) ($empresa['bloqueado'] ?? ''))) === 'S') {
        $suspensoEm = trim((string) ($empresa['suspenso_em'] ?? ''));
        $bloqueioTipo = $suspensoEm !== '' ? 'suspensao' : 'manual';
        // Bloqueio manual nao guarda data: vai vazio, nunca uma data inventada.
        $bloqueioDesde = substr($suspensoEm, 0, 10);
    }
    // Data zerada ('0000-00-00 00:00:00', de base antiga) nao e data: vai vazia
    // como a do manual. O TIPO fica, porque o token decide pela mesma coluna
    // preenchida.
    if (strncmp($bloqueioDesde, '0000', 4) === 0) {
        $bloqueioDesde = '';
    }

    if ($encerrado) {
        error_log('[licenca] ' . $cnpj . ' encerrado: licenca assinada como bloqueada');
        $empresa['bloqueado'] = 'S';
        // Bloqueio de decisao, nao suspensao por divida: promessa e confianca
        // nao o mascaram (ver shield_licenca_montar_conteudo).
        $empresa['suspenso_em'] = '';
    }

    if (!$encerrado && trim((string) ($empresa['validade_licenca'] ?? '')) === '') {
        error_log('[licenca] ' . $cnpj . ' sem validade: nada assinado'
            . ($acaoResultado !== '' ? ' ' . $acao . ' -> ' . $acaoResultado : ''));
        // O teste que venceu vai dito: o ERP (build futuro) pode mostrar
        // "sua avaliacao terminou em DD/MM" em vez de "sem licenca".
        $testeFim = shield_teste_fim($empresa, shield_teste_config($pdo));
        responder_e_registrar($pdo, 409, array_merge([
            'ok'   => false,
            'erro' => 'sem_validade',
        ], $cobranca !== null ? ['cobranca' => $cobranca, 'cobrancas' => $cobrancas] : [],
           area_cliente_bloco((int) $empresa['codigo']),
           $testeFim !== null ? ['teste' => ['fim' => $testeFim, 'vencido' => true]] : [],
           // O RESULTADO DA ACAO TAMBEM NA RECUSA -- 14/09/2026. A acao ja rodou
           // la em cima, antes de se decidir a validade, e o informar_pagamento
           // GRAVOU (marcou a fatura): sem o campo o ERP nao tinha como dizer ao
           // cliente o que aconteceu com o clique. NUNCA 'motivo' aqui: o
           // LerResposta do ERP le 'motivo' no lugar de 'erro', e o sem_validade
           // sumiria.
           $acaoResultado !== '' ? ['acao_resultado' => $acaoResultado] : []), [
            'empresa' => (int) $empresa['codigo'],
            'terminal' => (int) $terminal['terminal'],
            'cnpj' => $cnpj, 'fingerprint' => $impressao, 'nome' => $nome,
            'versao' => $versao, 'resultado' => 'sem_validade',
            'motivo' => 'cliente cadastrado e sem validade -- e fila de venda'
                . ($acaoResultado !== '' ? '; ' . $acao . ' -> ' . $acaoResultado : ''),
        ]);
    }

    // O QUE VAI DENTRO DO TOKEN ALEM DAS NOVE CHAVES -- 10/09/2026. Modulos
    // contratados (o ERP so obedece ao que esta assinado) e a promessa /
    // liberacao em confianca aberta, que levanta o valido_ate ate a data
    // prometida. As duas leituras engolem a propria falha: base intermediaria
    // emite a licenca de sempre.
    $promessa = shield_promessa_aberta($pdo, (int) $empresa['codigo']);
    $conteudo = shield_licenca_montar_conteudo(
        $empresa,
        $terminal,
        $impressao,
        (string) ($empresa['razao'] ?? ''),
        [
            'modulos' => shield_licenca_modulos_para_token($pdo, (int) $empresa['codigo']),
            'promessa_ate' => $promessa !== null ? (string) $promessa['ate'] : '',
            // O fim do contrato para a tela do ERP -- 11/09/2026 (ver o
            // cabecalho do montar_conteudo).
            'contrato_ate' => true,
        ]
    );

    $token = shield_licenca_assinar($emissor, $conteudo);

    error_log(sprintf(
        '[licenca] %s terminal=%d status=%s (%s)%s',
        $cnpj,
        (int) $terminal['terminal'],
        (string) $conteudo['status'],
        (string) $terminal['motivo'],
        $acaoResultado !== '' ? ' ' . $acao . ' -> ' . $acaoResultado : ''
    ));

    // O canal de comando. Os dois campos so aparecem quando ha o que dizer, e
    // ERP que nao os conhece os ignora -- como sempre fez. NENHUM deles pode
    // impedir a licenca de sair: por isso ambos vem de funcao que engole a
    // propria falha e devolve nulo.
    $extras = [];

    if ($cobranca !== null) {
        $extras['cobranca'] = $cobranca;
        $extras['cobrancas'] = $cobrancas;
    }
    if ($acaoResultado !== '') {
        $extras['acao_resultado'] = $acaoResultado;
    }

    // O tipo do bloqueio, calculado antes do bloco do encerrado. SO quando o
    // token saiu bloqueado: a suspensao mascarada por promessa sai 'ativa' e
    // nao tem bloqueio a explicar. ERP que nao conhece o campo o ignora.
    if ((string) $conteudo['status'] === 'bloqueada' && $bloqueioTipo !== '') {
        $extras['bloqueio'] = ['tipo' => $bloqueioTipo, 'desde' => $bloqueioDesde];
    }

    // O botao "liberar em confianca" so aparece na tela do cliente quando
    // este bloco vem; sem ele, nada muda para ninguem. Nulo quando o membro
    // nao ligou o recurso.
    // Em avaliacao: o cliente em teste nao pede prazo em confianca (pede
    // fechamento), entao o bloco confianca nao vai; vai o bloco teste.
    if (!empty($empresa['_teste'])) {
        $extras['teste'] = [
            'fim' => (string) $empresa['validade_licenca'],
            'dias' => (int) shield_teste_dias_restantes(['validade_licenca' => null, 'teste_ate' => $empresa['validade_licenca']]),
            'terminais' => (int) $empresa['nterminais'],
        ];
    } else {
        $confianca = shield_confianca_oferta($pdo, $empresa);
        if ($confianca !== null) {
            $extras['confianca'] = $confianca;
        }
    }

    $pedidoLog = shield_comando_pedido_de_log($pdo, (int) $terminal['terminal']);
    if ($pedidoLog !== null) {
        $extras['pedir_log'] = $pedidoLog;
    }

    $aviso = shield_comando_aviso($pdo, $empresa);
    if ($aviso !== null) {
        $extras['aviso'] = $aviso;
    }

    // A AREA DO CLIENTE (10/09/2026, tarde): o link assinado que o ERP abre no
    // navegador. Some da resposta quando a instalacao nao tem chave.
    $extras = array_merge($extras, area_cliente_bloco((int) $empresa['codigo']));

    // O PEDIDO DE PRAZO em que pe esta (pendente, aceita, recusada ha pouco):
    // vai em TODA batida, para a Central do ERP mostrar. Ausente = nada.
    $blocoPromessa = shield_promessa_bloco($pdo, (int) $empresa['codigo']);
    if ($blocoPromessa !== null) {
        $extras['promessa'] = $blocoPromessa;
    }

    responder_e_registrar($pdo, 200, array_merge([
        'ok'      => true,
        'licenca' => $token,
        'status'  => (string) $conteudo['status'],
        'motivo'  => (string) $terminal['motivo'],
    ], $extras), [
        'empresa' => (int) $empresa['codigo'],
        'terminal' => (int) $terminal['terminal'],
        'cnpj' => $cnpj, 'fingerprint' => $impressao, 'nome' => $nome,
        'versao' => $versao,
        // 'ativa' vira 'assinada' porque a linha registra o que ACONTECEU, nao
        // o estado do cliente: excedente e bloqueada tambem saem assinadas, e o
        // que as separa e este campo.
        'resultado' => (string) $conteudo['status'] === 'ativa'
            ? 'assinada' : (string) $conteudo['status'],
        'motivo' => (string) $terminal['motivo'],
    ]);
} catch (Throwable $e) {
    error_log('[licenca] falha: ' . $e->getMessage());
    // A mensagem da excecao vai para a linha, e nao para a rede: e ela que
    // responde "por que aquele cliente nao consegue licenca desde terca".
    // A acao pode ter gravado antes da falha. `?? ''` porque a excecao pode vir
    // antes de $acaoResultado existir (emissor, empresa, terminal).
    $acaoResultado = $acaoResultado ?? '';
    responder_e_registrar($pdo, 500, array_merge(
        ['ok' => false, 'erro' => 'interno'],
        $acaoResultado !== '' ? ['acao_resultado' => $acaoResultado] : []
    ), [
        'cnpj' => $cnpj, 'fingerprint' => $impressao, 'nome' => $nome,
        'versao' => $versao, 'resultado' => 'erro',
        'motivo' => $e->getMessage(),
    ]);
}
