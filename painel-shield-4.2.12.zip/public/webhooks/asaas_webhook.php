<?php
/**
 * Webhook do Asaas -- reescrito em 10/09/2026, tarde.
 *
 * ESTA URL FICA porque esta cadastrada la no provedor; o que mudou e quem a
 * atende. Ate hoje ela passava pela "ponte": o motor novo olhava primeiro e,
 * se nao reconhecesse o aviso como seu, o motor antigo (tabela `pedido`)
 * tentava dar baixa. O motor antigo saiu do projeto, e com ele a ponte.
 *
 * O que sobra e o caminho de sempre do motor novo: o aviso e GUARDADO, a
 * assinatura conferida pelo adaptador, e o que se enfileira e "va perguntar
 * ao provedor" -- nada aqui paga cobranca nenhuma pelo corpo do aviso. Ver
 * shield_webhook_receber em funcoes/cobranca/cobranca_fila.php.
 */

// Qualquer byte antes do JSON corrompe a resposta para o provedor. Mesmo
// cuidado do api/licenca.php. NAO enfileire header() antes desta linha.
ob_start();

require_once __DIR__ . '/../../funcoes/nucleo/webhook_resposta.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca_motor.php';

$corpo = (string) file_get_contents('php://input');

try {
    $r = shield_webhook_receber($pdo, 'asaas', $corpo, shield_webhook_cabecalhos($_SERVER));
    shield_webhook_responder((int) $r['http'], array(
        'ok' => (int) $r['http'] < 400,
        'resultado' => (string) $r['texto'],
        'cobranca' => isset($r['cobranca']) ? $r['cobranca'] : null,
    ));
} catch (Throwable $e) {
    // O detalhe vai para o log do servidor, nao para a rede: endpoint aberto
    // nao descreve a base para quem estiver sondando.
    error_log('[webhook asaas] ' . $e->getMessage());
    shield_webhook_responder(500, array('ok' => false, 'resultado' => 'interno'));
}
