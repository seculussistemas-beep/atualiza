<?php
/**
 * Entrada de webhook dos provedores de cobranca - 25/08/2026.
 *
 *   POST /webhooks/cobranca.php?p=asaas
 *
 * Publica de proposito: quem chama e o gateway, que nao tem sessao. Segue o
 * mesmo desenho do endpoint de licenca -- arquivo solto, require do banco.php,
 * sem passar pelo roteador.
 *
 * ELA NAO MOVE NADA. Confere a assinatura, guarda o evento cru e enfileira uma
 * VERIFICACAO. Quem diz se houve pagamento e a consulta ao provedor, depois. O
 * maximo que um POST forjado consegue e fazer o painel perguntar ao gateway.
 *
 * RESPONDE RAPIDO. O provedor precisa do 200 imediato: quem nao recebe 200
 * reenvia, e reenvia fora de ordem. O trabalho de verdade fica na fila.
 */

declare(strict_types=1);

// Buffer antes de qualquer include: arquivo com BOM cospe bytes no corpo e
// derruba os header() daqui. Mesmo cuidado do api/licenca.php.
ob_start();

require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca_motor.php';

function responder_webhook(int $http, string $texto): void
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        http_response_code($http);
    }

    echo json_encode(array('ok' => $http < 400, 'resultado' => $texto));
    exit;
}

if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? '')) !== 'POST') {
    responder_webhook(405, 'metodo');
}

$provedor = preg_replace('/[^a-z_]/', '', strtolower((string) ($_GET['p'] ?? '')));
if ($provedor === '') {
    responder_webhook(400, 'provedor');
}

$corpo = (string) file_get_contents('php://input');

// Cabecalho em minusculas, sem o prefixo HTTP_: e assim que o adaptador os
// procura, e assim ele nao precisa saber como o servidor os entrega.
$cabecalhos = shield_webhook_cabecalhos($_SERVER);

try {
    $r = shield_webhook_receber($pdo, $provedor, $corpo, $cabecalhos);
    responder_webhook((int) $r['http'], (string) $r['texto']);
} catch (Throwable $e) {
    // O detalhe vai para o log do servidor, nao para a rede: mensagem
    // detalhada em endpoint aberto vira mapa da base para quem estiver sondando.
    error_log('[webhook cobranca] ' . $e->getMessage());
    responder_webhook(500, 'interno');
}
