<?php

require_once __DIR__ . '/../../funcoes/nucleo/system_bootstrap.php';

// Esta tela NAO passa pelo router -- install/ e pasta servida direto pelo
// .htaccess --, entao a protecao anti-CSRF precisa ser ligada aqui. Ver
// ALTO-3 em docs/auditoria-seguranca.md.
require_once __DIR__ . '/../../funcoes/nucleo/csrf.php';
shield_csrf_proteger();

function shield_h($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$appConfig = shield_load_app_config();
$isInstalled = !empty($appConfig['installed']);

$formConfig = shield_load_database_config();
$messages = [];
$errors = [];
$logs = [];
$pdo = null;
// Banco de outra instalacao sem a crypto_key: o formulario abre o bloco que pede a antiga.
$pedirCofre = false;

if ($isInstalled) {
    $messages[] = 'Sistema ja instalado. Redirecionando para /update...';
    header('Refresh: 3; url=/update/');
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string) ($_POST['action'] ?? 'install');
    if ($action !== 'test_connection') {
        $action = 'install';
    }

    $formConfig = [
        'configured' => true,
        'host' => trim((string) ($_POST['host'] ?? 'localhost')),
        'port' => (int) ($_POST['port'] ?? 3306),
        'database' => trim((string) ($_POST['database'] ?? '')),
        'username' => trim((string) ($_POST['username'] ?? '')),
        'password' => (string) ($_POST['password'] ?? ''),
        'charset' => trim((string) ($_POST['charset'] ?? 'utf8')),
        'ssl' => !empty($_POST['ssl']),
        'ssl_ca' => trim((string) ($_POST['ssl_ca'] ?? '')),
    ];

    if ($formConfig['port'] <= 0) {
        $formConfig['port'] = 3306;
    }
    if ($formConfig['charset'] === '') {
        $formConfig['charset'] = 'utf8';
    }
    // CONFERIR O CERTIFICADO SO E GRAVADO COM CA (15/09/2026): sem CA a conexao
    // TLS nao confere, e um ssl_verify gravado ali mandaria o autoassinado da
    // hospedagem para o pacote do sistema, que o recusa.
    if ($formConfig['ssl_ca'] !== '') {
        $formConfig['ssl'] = true;
        $formConfig['ssl_verify'] = !empty($_POST['ssl_verify']);
    }

    try {
        $pdo = shield_create_pdo_connection($formConfig);
    } catch (Throwable $exception) {
        $errors[] = 'Falha ao conectar no banco: ' . $exception->getMessage();
        $dicaConexao = shield_banco_dica_conexao($exception, $formConfig);
        if ($dicaConexao !== '') {
            $errors[] = $dicaConexao;
        }
    }

    $diagnostics = shield_collect_environment_diagnostics($formConfig, $pdo);
    if ($action === 'test_connection') {
        if (empty($errors) && $pdo !== null) {
            $messages[] = 'Conexao com banco de dados realizada com sucesso.';
        }
    } else {
        if ($diagnostics['has_critical_failures']) {
            $errors[] = 'Foram detectados erros criticos no ambiente. Corrija antes de instalar.';
        }

        if (empty($errors) && $pdo !== null) {
            try {
                if (!shield_write_database_config($formConfig)) {
                    throw new RuntimeException('Nao foi possivel salvar config/database.php.');
                }

                // A TABELA DE MIGRACOES VEM ANTES DA SINCRONIZACAO -- 24/09/2026.
                // Quem decide se uma tabela do baseline ja foi derrubada por
                // migracao e shield_baseline_tabelas_derrubadas, lendo
                // shield_migrations; com a ordem invertida, a instalacao que
                // ainda nao tem essa tabela responde "nada foi derrubado" e o
                // baseline recria o que a V4_2_9 tirou (a `etiquetas`). O
                // /update ja fazia nesta ordem; aqui estava ao contrario.
                shield_ensure_version_tables($pdo);
                $baselineResult = shield_sync_missing_baseline_tables($pdo, shield_baseline_sql_path(), $logs);

                // O COFRE (15/09/2026): banco que ja tem segredo cifrado nao ganha
                // crypto_key nova calado. Instalar do zero sobre o banco antigo
                // deixava a chave da licenca ilegivel, e nenhum bloqueio chegava
                // mais as lojas. Ver funcoes/nucleo/cofre.php.
                require_once __DIR__ . '/../../funcoes/nucleo/cofre.php';
                $cofre = shield_cofre_decidir_instalacao($pdo, $appConfig, $_POST);
                if ($cofre['erro'] !== null) {
                    $pedirCofre = true;
                    throw new RuntimeException($cofre['erro']);
                }
                if ($cofre['recomecar']) {
                    $desligados = shield_cofre_recomecar($pdo);
                    $logs[] = ['level' => 'warning', 'message' => 'Chaves comecadas do zero: ' . $desligados['emissores']
                        . ' chave(s) de licenca desligada(s) e ' . $desligados['contas'] . ' credencial(is) de gateway apagada(s).'];
                }
                if ($cofre['crypto_key'] !== null) {
                    $appConfig['crypto_key'] = $cofre['crypto_key'];
                }

                $currentVersion = shield_get_system_meta($pdo, 'db_version', '0.0.0');
                shield_set_system_meta($pdo, 'db_version', $currentVersion === '' ? '0.0.0' : $currentVersion);
                shield_set_system_meta($pdo, 'app_version', (string) ($appConfig['app_version'] ?? '2.0.0'));
                shield_set_system_meta($pdo, 'installed_at', date('c'));

                $appConfig['installed'] = true;
                $appConfig['installed_at'] = date('c');
                if (!shield_write_app_config($appConfig)) {
                    throw new RuntimeException('Nao foi possivel salvar config/app.php.');
                }

                $messages[] = 'Instalacao concluida. Tabelas criadas no baseline: ' . (int) $baselineResult['created_count'];

                // O /update/ passou a exigir administrador logado (08/09/2026),
                // e aqui ainda nao houve login -- nem sempre nem ha admin. Num
                // banco REAPROVEITADO ja existe administrador de antes, e sem
                // esta marca a instalacao pararia no ultimo passo, diante de um
                // 403. A liberacao vale so para esta sessao, e este trecho e
                // inalcancavel depois de instalado ($isInstalled, linha 25).
                if (session_status() !== PHP_SESSION_ACTIVE) {
                    require_once __DIR__ . '/../../funcoes/nucleo/sessao.php'; shield_sessao_abrir();
                }
                $_SESSION['shield_update_liberado'] = true;

                shield_redirect('/update/?installed=1');
            } catch (Throwable $exception) {
                $errors[] = 'Falha durante a instalacao: ' . $exception->getMessage();
            }
        }
    }
} else {
    if (shield_is_database_configured($formConfig)) {
        try {
            $pdo = shield_create_pdo_connection($formConfig);
        } catch (Throwable $ignored) {
            $pdo = null;
        }
    }
}

if (!isset($diagnostics)) {
    $diagnostics = shield_collect_environment_diagnostics($formConfig, $pdo);
}

function shield_status_class($status)
{
    switch ($status) {
        case 'PASS':
            return 'status-pass';
        case 'WARN':
            return 'status-warn';
        default:
            return 'status-fail';
    }
}
?>
<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Painel Shield - Instalacao</title>
    <link rel="stylesheet" href="/css/instalacao.css?v=<?= (int) @filemtime(__DIR__ . '/../css/instalacao.css'); ?>">
</head>
<body>
    <div class="container">
        <div class="topo">
            <img src="/img/escudo-256.png?v=<?= (int) @filemtime(__DIR__ . '/../img/escudo-256.png'); ?>" alt="" aria-hidden="true">
            <div class="dizer">
                <h1>Instalar o Painel Shield</h1>
                <p>Aponte o banco, confira o ambiente e o painel se monta sozinho: as tabelas, as migracoes e os arquivos de configuracao.</p>
            </div>
            <span class="etapa">Passo 1 de 2</span>
        </div>

        <?php foreach ($messages as $message): ?>
            <div class="msg msg-ok"><?= shield_h($message); ?></div>
        <?php endforeach; ?>

        <?php foreach ($errors as $error): ?>
            <div class="msg msg-err"><?= shield_h($error); ?></div>
        <?php endforeach; ?>

        <?php if ($isInstalled): ?>
            <div class="msg msg-info">Redirecionamento automatico para <code>/update</code> em 3 segundos.</div>
        <?php else: ?>
            <h2>Configuracao do Banco</h2>
            <form method="post" action="/install/">
                <div class="grid">
                    <div>
                        <label for="host">Host</label>
                        <input id="host" name="host" required value="<?= shield_h($formConfig['host'] ?? 'localhost'); ?>">
                    </div>
                    <div>
                        <label for="port">Porta</label>
                        <input id="port" name="port" type="number" required value="<?= shield_h($formConfig['port'] ?? 3306); ?>">
                    </div>
                    <div>
                        <label for="database">Banco</label>
                        <input id="database" name="database" required value="<?= shield_h($formConfig['database'] ?? ''); ?>">
                    </div>
                    <div>
                        <label for="charset">Charset</label>
                        <input id="charset" name="charset" required value="<?= shield_h($formConfig['charset'] ?? 'utf8'); ?>">
                        <small class="hint">Recomendado: utf8</small>
                    </div>
                    <div>
                        <label for="username">Usuario</label>
                        <input id="username" name="username" required value="<?= shield_h($formConfig['username'] ?? ''); ?>">
                    </div>
                    <div>
                        <label for="password">Senha</label>
                        <input id="password" name="password" type="password" value="<?= shield_h($formConfig['password'] ?? ''); ?>">
                    </div>
                </div>
                <?php /* O BANCO QUE EXIGE TLS (15/09/2026). Fechado por padrao, como o
                         cofre: a hospedagem comum nao pede, e o instalador explica o 3159
                         quando o servidor recusa a conexao sem criptografia. */ ?>
                <details class="cofre"<?= !empty($formConfig['ssl']) ? ' open' : ''; ?>>
                    <summary>O servidor do banco exige conex&atilde;o criptografada (TLS)?</summary>
                    <p class="hint">
                        S&oacute; marque se a hospedagem pedir, ou se o teste de conex&atilde;o disser que o servidor s&oacute;
                        aceita conex&atilde;o criptografada. Com o certificado (CA) da hospedagem o painel confere o servidor;
                        sem ele, a conex&atilde;o &eacute; criptografada mas o certificado n&atilde;o &eacute; conferido.
                    </p>
                    <label class="marcar"><input type="checkbox" name="ssl" value="1"<?= !empty($formConfig['ssl']) ? ' checked' : ''; ?>> Conex&atilde;o criptografada (TLS)</label>
                    <label for="ssl_ca">Caminho do certificado CA no servidor (opcional)</label>
                    <input id="ssl_ca" name="ssl_ca" autocomplete="off" spellcheck="false" placeholder="/etc/ssl/certs/ca-banco.pem" value="<?= shield_h($formConfig['ssl_ca'] ?? ''); ?>">
                    <label class="marcar"><input type="checkbox" name="ssl_verify" value="1"<?= (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' ? !empty($_POST['ssl_verify']) : (!array_key_exists('ssl_verify', $formConfig) || !empty($formConfig['ssl_verify']))) ? ' checked' : ''; ?>> Conferir o certificado (desmarque se o certificado for autoassinado)</label>
                </details>
                <?php /* O COFRE (15/09/2026). Fechado por padrao: so quem reaproveita o
                         banco de outra instalacao precisa, e o instalador o abre sozinho
                         quando percebe. A chave colada nunca volta preenchida na tela. */ ?>
                <details class="cofre"<?= $pedirCofre ? ' open' : ''; ?>>
                    <summary>Este banco j&aacute; era usado por outra instala&ccedil;&atilde;o do painel?</summary>
                    <p class="hint">
                        A chave da licen&ccedil;a e as credenciais dos gateways ficam cifradas com a <code>crypto_key</code>
                        do <code>config/app.php</code> da instala&ccedil;&atilde;o antiga. Cole essa linha aqui para continuar usando tudo.
                        Sem ela, marque come&ccedil;ar do zero: ser&aacute; preciso gerar outro par em Chaves, recompilar o ERP e
                        cadastrar de novo as credenciais em Formas de recebimento.
                    </p>
                    <label for="crypto_key_antiga">crypto_key do config/app.php antigo</label>
                    <input id="crypto_key_antiga" name="crypto_key_antiga" autocomplete="off" spellcheck="false" placeholder="44 caracteres, terminando em =">
                    <label class="marcar"><input type="checkbox" name="recomecar_chaves" value="1"> N&atilde;o tenho a chave antiga: come&ccedil;ar as chaves do zero</label>
                </details>
                <div class="actions">
                    <button type="submit" name="action" value="test_connection" class="btn-secondary">Conectar ao banco de dados</button>
                    <button type="submit" name="action" value="install" class="btn-primary">Instalar e Configurar</button>
                </div>
            </form>
        <?php endif; ?>

        <h2>Diagnostico de Hospedagem</h2>
        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Atual</th>
                    <th>Necessario/Recomendado</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($diagnostics['items'] as $item): ?>
                    <tr>
                        <td><?= shield_h($item['label']); ?></td>
                        <td><?= shield_h($item['current']); ?></td>
                        <td><?= shield_h($item['required']); ?></td>
                        <td><span class="<?= shield_h(shield_status_class($item['status'])); ?>"><?= shield_h($item['status']); ?></span></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <?php if (!empty($logs)): ?>
            <h2>Log da Instalacao</h2>
            <ul>
                <?php foreach ($logs as $entry): ?>
                    <li>[<?= shield_h(strtoupper((string) $entry['level'])); ?>] <?= shield_h($entry['message']); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</body>
</html>
