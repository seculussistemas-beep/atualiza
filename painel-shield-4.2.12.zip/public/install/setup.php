<?php

require_once __DIR__ . '/../../funcoes/nucleo/system_bootstrap.php';
require_once __DIR__ . '/../../funcoes/acesso/primeiro_admin.php';

// Esta tela NAO passa pelo router -- install/ e pasta servida direto pelo
// .htaccess --, entao a protecao anti-CSRF precisa ser ligada aqui. Ver
// ALTO-3 em docs/auditoria-seguranca.md.
require_once __DIR__ . '/../../funcoes/nucleo/csrf.php';
shield_csrf_proteger();

function shield_h($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function shield_setup_sanitize_digits($value)
{
    return preg_replace('/\D+/', '', (string) $value);
}

function shield_setup_format_cnpj($cnpj)
{
    $cnpj = shield_setup_sanitize_digits($cnpj);
    if (strlen($cnpj) !== 14) {
        return $cnpj;
    }

    return preg_replace('/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/', '$1.$2.$3/$4-$5', $cnpj);
}

function shield_setup_format_cep($cep)
{
    $cep = shield_setup_sanitize_digits($cep);
    if (strlen($cep) !== 8) {
        return $cep;
    }

    return preg_replace('/^(\d{5})(\d{3})$/', '$1-$2', $cep);
}

function shield_setup_default_admin_form()
{
    return [
        'email' => '',
    ];
}

function shield_setup_default_softhouse_form()
{
    return [
        'razao' => '',
        'fantasia' => '',
        'cnpj' => '',
        'ie' => '',
        'telefone' => '',
        'cep' => '',
        'endereco' => '',
        'numero' => '',
        'cidade' => '',
        'estado' => '',
    ];
}

function shield_admin_name_from_email($email)
{
    $localPart = trim((string) strstr((string) $email, '@', true));
    if ($localPart === '') {
        return 'administrador';
    }

    $normalized = preg_replace('/[^a-zA-Z0-9._-]+/', '', $localPart);
    if ($normalized === '') {
        return 'administrador';
    }

    return $normalized;
}

$appConfig = shield_load_app_config();
if (empty($appConfig['installed'])) {
    shield_redirect('/install/');
}

$dbConfig = shield_load_database_config();
if (!shield_is_database_configured($dbConfig)) {
    shield_redirect('/install/?error=db_config');
}

try {
    $pdo = shield_create_pdo_connection($dbConfig);
} catch (Throwable $exception) {
    shield_redirect('/install/?error=db_connection');
}

try {
    $pending = shield_detect_pending_updates($pdo, shield_baseline_sql_path(), shield_migrations_dir());
    if (!empty($pending['needs_update'])) {
        shield_redirect('/update/');
    }
} catch (Throwable $exception) {
    shield_redirect('/update/?error=pending_check');
}

if (!shield_table_exists($pdo, 'usuario') || !shield_table_exists($pdo, 'softhouse')) {
    shield_redirect('/update/');
}

$errors = [];
$messages = [];
$adminForm = shield_setup_default_admin_form();
$softhouseForm = shield_setup_default_softhouse_form();

$hasAdmin = shield_has_admin_user($pdo);
$hasSofthouse = shield_has_softhouse($pdo);
$adminCompleted = shield_is_first_access_admin_completed($pdo);
$firstCompleted = shield_is_first_access_completed($pdo);

if ($firstCompleted) {
    shield_redirect('/login.php?setup=done');
}

if ($hasSofthouse) {
    $softhouseRow = $pdo->query('SELECT * FROM softhouse ORDER BY id ASC LIMIT 1')->fetch(PDO::FETCH_ASSOC);
    if (is_array($softhouseRow)) {
        $softhouseForm['razao'] = (string) ($softhouseRow['razao'] ?? '');
        $softhouseForm['fantasia'] = (string) ($softhouseRow['fantasia'] ?? '');
        $softhouseForm['cnpj'] = shield_setup_sanitize_digits($softhouseRow['cnpj'] ?? '');
        $softhouseForm['ie'] = (string) ($softhouseRow['ie'] ?? '');
        $softhouseForm['telefone'] = (string) ($softhouseRow['telefone'] ?? '');
        $softhouseForm['cep'] = shield_setup_sanitize_digits($softhouseRow['cep'] ?? '');
        $softhouseForm['endereco'] = (string) ($softhouseRow['endereco'] ?? '');
        $softhouseForm['numero'] = (string) ($softhouseRow['numero'] ?? '');
        $softhouseForm['cidade'] = (string) ($softhouseRow['cidade'] ?? '');
        $softhouseForm['estado'] = strtoupper((string) ($softhouseRow['estado'] ?? ''));
    }
}

$stage = ($adminCompleted && $hasAdmin) ? 'choice' : 'admin';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string) ($_POST['action'] ?? '');

    try {
        $pending = shield_detect_pending_updates($pdo, shield_baseline_sql_path(), shield_migrations_dir());
        if (!empty($pending['needs_update'])) {
            shield_redirect('/update/');
        }
    } catch (Throwable $exception) {
        shield_redirect('/update/?error=pending_check');
    }

    if ($action === 'save_admin') {
        $adminForm['email'] = trim((string) ($_POST['email'] ?? ''));
        $senha = (string) ($_POST['senha'] ?? '');
        $senhaConfirmacao = (string) ($_POST['senha_confirmacao'] ?? '');

        if ($adminForm['email'] === '') {
            $errors[] = 'Informe o e-mail do administrador.';
        } elseif (!filter_var($adminForm['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Informe um e-mail valido para o administrador.';
        }

        if ($senha === '' || $senhaConfirmacao === '') {
            $errors[] = 'Informe senha e confirmacao de senha.';
        } elseif (!hash_equals($senha, $senhaConfirmacao)) {
            $errors[] = 'Senha e confirmacao nao conferem.';
        }

        if (empty($errors)) {
            try {
                shield_ensure_version_tables($pdo);
                $nomeAdmin = shield_admin_name_from_email($adminForm['email']);
                $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

                $pdo->beginTransaction();

                // A gravacao mora em funcoes/acesso/primeiro_admin.php desde
                // 17/09/2026, onde o teste alcanca: e o unico lugar do painel que
                // cria usuario.
                shield_primeiro_admin_gravar($pdo, $nomeAdmin, $adminForm['email'], $senhaHash);

                shield_set_system_meta($pdo, 'first_access_completed', '0');
                shield_set_system_meta($pdo, 'first_access_admin_completed', '1');
                shield_set_system_meta($pdo, 'first_access_admin_completed_at', date('c'));
                shield_set_system_meta($pdo, 'first_access_softhouse_skipped', '0');
                $pdo->commit();

                $hasAdmin = true;
                $adminCompleted = true;
                $stage = 'choice';
                $messages[] = 'Administrador inicial salvo com sucesso. Escolha como deseja concluir o onboarding.';
            } catch (Throwable $exception) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $errors[] = 'Falha ao salvar administrador inicial: ' . $exception->getMessage();
                $stage = 'admin';
            }
        } else {
            $stage = 'admin';
        }
    } elseif ($action === 'open_softhouse') {
        if (!$adminCompleted || !$hasAdmin) {
            $errors[] = 'Cadastre e salve e-mail/senha do administrador antes de continuar.';
            $stage = 'admin';
        } else {
            $stage = 'softhouse';
        }
    } elseif ($action === 'save_softhouse') {
        if (!$adminCompleted || !$hasAdmin) {
            $errors[] = 'Cadastre e salve e-mail/senha do administrador antes de continuar.';
            $stage = 'admin';
        } else {
            $stage = 'softhouse';

            $softhouseForm['razao'] = trim((string) ($_POST['razao'] ?? ''));
            $softhouseForm['fantasia'] = trim((string) ($_POST['fantasia'] ?? ''));
            $softhouseForm['cnpj'] = shield_setup_sanitize_digits($_POST['cnpj'] ?? '');
            $softhouseForm['ie'] = trim((string) ($_POST['ie'] ?? ''));
            $softhouseForm['telefone'] = trim((string) ($_POST['telefone'] ?? ''));
            $softhouseForm['cep'] = shield_setup_sanitize_digits($_POST['cep'] ?? '');
            $softhouseForm['endereco'] = trim((string) ($_POST['endereco'] ?? ''));
            $softhouseForm['numero'] = trim((string) ($_POST['numero'] ?? ''));
            $softhouseForm['cidade'] = trim((string) ($_POST['cidade'] ?? ''));
            $softhouseForm['estado'] = strtoupper(trim((string) ($_POST['estado'] ?? '')));

            if ($softhouseForm['razao'] === '') {
                $errors[] = 'Informe a razao social da softhouse.';
            }
            if ($softhouseForm['cnpj'] === '') {
                $errors[] = 'Informe o CNPJ da softhouse.';
            } elseif (strlen($softhouseForm['cnpj']) !== 14) {
                $errors[] = 'CNPJ invalido. Informe 14 digitos.';
            }
            if ($softhouseForm['cep'] === '') {
                $errors[] = 'Informe o CEP da softhouse.';
            } elseif (strlen($softhouseForm['cep']) !== 8) {
                $errors[] = 'CEP invalido. Informe 8 digitos.';
            }
            if ($softhouseForm['endereco'] === '') {
                $errors[] = 'Informe o endereco da softhouse.';
            }
            if ($softhouseForm['numero'] === '') {
                $errors[] = 'Informe o numero do endereco.';
            }
            if ($softhouseForm['cidade'] === '') {
                $errors[] = 'Informe a cidade da softhouse.';
            }
            if (!preg_match('/^[A-Z]{2}$/', $softhouseForm['estado'])) {
                $errors[] = 'Informe um estado (UF) valido com 2 letras.';
            }

            if (empty($errors)) {
                try {
                    shield_ensure_version_tables($pdo);
                    $pdo->beginTransaction();

                    $softhouseId = $pdo->query('SELECT id FROM softhouse ORDER BY id ASC LIMIT 1')->fetchColumn();
                    if ($softhouseId !== false) {
                        $stmt = $pdo->prepare(
                            'UPDATE softhouse
                             SET cnpj = :cnpj,
                                 razao = :razao,
                                 fantasia = :fantasia,
                                 ie = :ie,
                                 estado = :estado,
                                 cidade = :cidade,
                                 endereco = :endereco,
                                 numero = :numero,
                                 cep = :cep,
                                 telefone = :telefone
                             WHERE id = :id'
                        );
                        $stmt->execute([
                            'cnpj' => $softhouseForm['cnpj'],
                            'razao' => $softhouseForm['razao'],
                            'fantasia' => $softhouseForm['fantasia'] !== '' ? $softhouseForm['fantasia'] : null,
                            'ie' => $softhouseForm['ie'] !== '' ? $softhouseForm['ie'] : null,
                            'estado' => $softhouseForm['estado'],
                            'cidade' => $softhouseForm['cidade'],
                            'endereco' => $softhouseForm['endereco'],
                            'numero' => $softhouseForm['numero'],
                            'cep' => $softhouseForm['cep'],
                            'telefone' => $softhouseForm['telefone'] !== '' ? $softhouseForm['telefone'] : null,
                            'id' => (int) $softhouseId,
                        ]);
                    } else {
                        $stmt = $pdo->prepare(
                            'INSERT INTO softhouse (cnpj, razao, fantasia, ie, estado, cidade, endereco, numero, cep, telefone)
                             VALUES (:cnpj, :razao, :fantasia, :ie, :estado, :cidade, :endereco, :numero, :cep, :telefone)'
                        );
                        $stmt->execute([
                            'cnpj' => $softhouseForm['cnpj'],
                            'razao' => $softhouseForm['razao'],
                            'fantasia' => $softhouseForm['fantasia'] !== '' ? $softhouseForm['fantasia'] : null,
                            'ie' => $softhouseForm['ie'] !== '' ? $softhouseForm['ie'] : null,
                            'estado' => $softhouseForm['estado'],
                            'cidade' => $softhouseForm['cidade'],
                            'endereco' => $softhouseForm['endereco'],
                            'numero' => $softhouseForm['numero'],
                            'cep' => $softhouseForm['cep'],
                            'telefone' => $softhouseForm['telefone'] !== '' ? $softhouseForm['telefone'] : null,
                        ]);
                    }

                    shield_mark_first_access_completed($pdo);
                    shield_set_system_meta($pdo, 'first_access_softhouse_skipped', '0');
                    shield_set_system_meta($pdo, 'first_access_softhouse_skipped_at', '');
                    $pdo->commit();

                    shield_redirect('/login.php?setup=done');
                } catch (Throwable $exception) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    $errors[] = 'Falha ao salvar softhouse: ' . $exception->getMessage();
                }
            }
        }
    } elseif ($action === 'skip_softhouse') {
        if (!$adminCompleted || !$hasAdmin) {
            $errors[] = 'Cadastre e salve e-mail/senha do administrador antes de continuar.';
            $stage = 'admin';
        } else {
            try {
                shield_ensure_version_tables($pdo);
                shield_mark_first_access_completed($pdo);
                shield_set_system_meta($pdo, 'first_access_softhouse_skipped', '1');
                shield_set_system_meta($pdo, 'first_access_softhouse_skipped_at', date('c'));

                shield_redirect('/login.php?setup=done&softhouse=pending');
            } catch (Throwable $exception) {
                $errors[] = 'Falha ao concluir onboarding sem softhouse: ' . $exception->getMessage();
                $stage = 'choice';
            }
        }
    }
}

$diagnostics = shield_collect_environment_diagnostics($dbConfig, $pdo);
if ($diagnostics['has_critical_failures']) {
    $messages[] = 'Existem alertas criticos no ambiente. Corrija para evitar falhas no uso do sistema.';
}
?>
<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Painel Shield - Cadastro Inicial</title>
    <link rel="stylesheet" href="/css/instalacao.css?v=<?= (int) @filemtime(__DIR__ . '/../css/instalacao.css'); ?>">
</head>
<body>
    <div class="container">
        <div class="topo">
            <img src="/img/escudo-256.png?v=<?= (int) @filemtime(__DIR__ . '/../img/escudo-256.png'); ?>" alt="" aria-hidden="true">
            <div class="dizer">
                <h1>Primeiro acesso</h1>
                <p>Crie o administrador que vai entrar no painel. Os dados da softhouse podem ficar para depois, em Minha empresa.</p>
            </div>
            <span class="etapa">Passo 2 de 2</span>
        </div>

        <?php foreach ($messages as $message): ?>
            <div class="msg msg-info"><?= shield_h($message); ?></div>
        <?php endforeach; ?>

        <?php foreach ($errors as $error): ?>
            <div class="msg msg-err"><?= shield_h($error); ?></div>
        <?php endforeach; ?>

        <?php if ($stage === 'admin'): ?>
            <div class="section">
                <h2>1. Administrador inicial</h2>
                <form method="post" action="/install/setup.php" autocomplete="off">
                    <input type="hidden" name="action" value="save_admin">
                    <div class="grid">
                        <div>
                            <label for="email">E-mail do administrador *</label>
                            <input id="email" name="email" type="email" required value="<?= shield_h($adminForm['email']); ?>">
                        </div>
                        <div>
                            <label for="senha">Senha *</label>
                            <input id="senha" name="senha" type="password" required>
                        </div>
                        <div>
                            <label for="senha_confirmacao">Confirmacao da senha *</label>
                            <input id="senha_confirmacao" name="senha_confirmacao" type="password" required>
                        </div>
                    </div>
                    <small class="hint">O e-mail sera usado como login e a senha sera salva com hash seguro.</small>
                    <div class="actions">
                        <button type="submit" class="btn-primary">Salvar Administrador</button>
                    </div>
                </form>
            </div>
        <?php elseif ($stage === 'choice'): ?>
            <div class="section">
                <h2>2. Concluir onboarding</h2>
                <p>Administrador salvo. Escolha se deseja cadastrar a softhouse agora.</p>
                <div class="actions">
                    <form method="post" action="/install/setup.php">
                        <input type="hidden" name="action" value="open_softhouse">
                        <button type="submit" class="btn-primary">Cadastrar Softhouse</button>
                    </form>
                    <form method="post" action="/install/setup.php">
                        <input type="hidden" name="action" value="skip_softhouse">
                        <button type="submit" class="btn-warning">Cadastrar depois</button>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <div class="section">
                <h2>Cadastro da Softhouse</h2>
                <form method="post" action="/install/setup.php" autocomplete="off">
                    <input type="hidden" name="action" value="save_softhouse">
                    <div class="grid">
                        <div>
                            <label for="razao">Razao Social *</label>
                            <input id="razao" name="razao" required value="<?= shield_h($softhouseForm['razao']); ?>">
                        </div>
                        <div>
                            <label for="fantasia">Nome Fantasia</label>
                            <input id="fantasia" name="fantasia" value="<?= shield_h($softhouseForm['fantasia']); ?>">
                        </div>
                        <div>
                            <label for="cnpj">CNPJ *</label>
                            <input id="cnpj" name="cnpj" required value="<?= shield_h(shield_setup_format_cnpj($softhouseForm['cnpj'])); ?>">
                        </div>
                        <div>
                            <label for="ie">Inscricao Estadual</label>
                            <input id="ie" name="ie" value="<?= shield_h($softhouseForm['ie']); ?>">
                        </div>
                        <div>
                            <label for="telefone">Telefone</label>
                            <input id="telefone" name="telefone" value="<?= shield_h($softhouseForm['telefone']); ?>">
                        </div>
                        <div>
                            <label for="cep">CEP *</label>
                            <input id="cep" name="cep" required value="<?= shield_h(shield_setup_format_cep($softhouseForm['cep'])); ?>">
                        </div>
                        <div>
                            <label for="endereco">Endereco *</label>
                            <input id="endereco" name="endereco" required value="<?= shield_h($softhouseForm['endereco']); ?>">
                        </div>
                        <div>
                            <label for="numero">Numero *</label>
                            <input id="numero" name="numero" required value="<?= shield_h($softhouseForm['numero']); ?>">
                        </div>
                        <div>
                            <label for="cidade">Cidade *</label>
                            <input id="cidade" name="cidade" required value="<?= shield_h($softhouseForm['cidade']); ?>">
                        </div>
                        <div>
                            <label for="estado">Estado (UF) *</label>
                            <input id="estado" name="estado" maxlength="2" required value="<?= shield_h($softhouseForm['estado']); ?>">
                        </div>
                    </div>
                    <div class="actions">
                        <button type="submit" class="btn-primary">Salvar Softhouse e Concluir</button>
                    </div>
                </form>

                <div class="actions">
                    <form method="post" action="/install/setup.php">
                        <input type="hidden" name="action" value="skip_softhouse">
                        <button type="submit" class="btn-warning">Cadastrar depois</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        <h2>Diagnostico de Hospedagem</h2>
        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Atual</th>
                    <th>Necessario/Recomendado</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($diagnostics['items'] as $item): ?>
                    <?php
                    $statusClass = 'status-fail';
                    if ($item['status'] === 'PASS') {
                        $statusClass = 'status-pass';
                    } elseif ($item['status'] === 'WARN') {
                        $statusClass = 'status-warn';
                    }
                    ?>
                    <tr>
                        <td><?= shield_h($item['label']); ?></td>
                        <td><?= shield_h($item['current']); ?></td>
                        <td><?= shield_h($item['required']); ?></td>
                        <td><span class="<?= shield_h($statusClass); ?>"><?= shield_h($item['status']); ?></span></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script>
        document.addEventListener('input', function (event) {
            if (event.target.id === 'cnpj') {
                let value = event.target.value.replace(/\D/g, '');
                value = value.replace(/^(\d{2})(\d)/, '$1.$2');
                value = value.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3');
                value = value.replace(/\.(\d{3})(\d)/, '.$1/$2');
                value = value.replace(/(\d{4})(\d)/, '$1-$2');
                event.target.value = value.slice(0, 18);
            }

            if (event.target.id === 'cep') {
                let value = event.target.value.replace(/\D/g, '');
                value = value.replace(/^(\d{5})(\d)/, '$1-$2');
                event.target.value = value.slice(0, 9);
            }

            if (event.target.id === 'telefone') {
                let value = event.target.value.replace(/\D/g, '');
                value = value.replace(/^(\d{2})(\d)/g, '($1) $2');
                value = value.replace(/(\d)(\d{4})$/, '$1-$2');
                event.target.value = value.slice(0, 15);
            }

            if (event.target.id === 'estado') {
                event.target.value = event.target.value.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 2);
            }
        });
    </script>
</body>
</html>
