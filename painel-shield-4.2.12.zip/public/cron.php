<?php
/**
 * O relogio do painel - 25/08/2026.
 *
 *   GET /cron.php?chave=<a chave configurada>
 *
 * Na hospedagem do membro nao ha shell nem processo residente: o que existe e
 * o agendador do painel de controle chamando uma URL. E isto.
 *
 * ELE E OPORTUNISTA, NAO OBRIGATORIO. Tudo o que ele faz tambem acontece
 * quando alguem abre o painel -- mais devagar, em lotes menores. Membro que
 * nunca configurar o agendador continua funcionando; ele so descobre pagamento
 * quando entrar na tela.
 *
 * O QUE ELE NAO FAZ: suspender ninguem. Silencio do gateway, erro de
 * integracao ou cron que parou NAO podem desligar o caixa de uma loja. A regua
 * e a suspensao sao da fase seguinte, e mesmo la a decisao nao sai daqui.
 *
 * A CHAVE nao e senha de usuario, mas tambem nao e enfeite: quem a tem dispara
 * a regua, e a regua e a unica coisa daqui que PARA a loja de um cliente. Por
 * isso ela nao se entrega a quem chega (ver shield_cron_chave_entregar, e o
 * tanto que ela custou em 16/09/2026). Fora a regua, nada aqui move dinheiro
 * por conta propria.
 */

declare(strict_types=1);

require_once __DIR__ . '/../banco.php';
require_once __DIR__ . '/../funcoes/cobranca/cobranca_motor.php';
require_once __DIR__ . '/../funcoes/licenca/parque.php';
require_once __DIR__ . '/../funcoes/cobranca/assinatura.php';
require_once __DIR__ . '/../funcoes/cobranca/regua.php';
require_once __DIR__ . '/../funcoes/notificacao/email.php';
require_once __DIR__ . '/../funcoes/cobranca/relogio.php';
require_once __DIR__ . '/../funcoes/licenca/certificado_aviso.php';

header('Content-Type: text/plain; charset=utf-8');

$chaveConfigurada = trim((string) shield_get_system_meta($pdo, 'cron_chave', ''));

if ($chaveConfigurada === '' || !hash_equals($chaveConfigurada, (string) ($_GET['chave'] ?? ''))) {
    /* Aqui chega o agendador mal configurado E a pessoa que abriu o endereco no
       navegador para descobrir a chave. Esta e a tela dela: o painel nao tem
       outra que mostre a chave do relogio.

       A SESSAO SO ABRE QUANDO O NAVEGADOR TROUXE UM COOKIE. O agendador que
       acerta a chave nem entra neste bloco, e o robo que chuta sem cookie nao
       faz o PHP criar um arquivo de sessao por tentativa. */
    $ehAdmin = false;
    if (isset($_COOKIE[session_name()])) {
        require_once __DIR__ . '/../funcoes/nucleo/sessao.php';
        shield_sessao_abrir();
        $ehAdmin = trim((string) ($_SESSION['usuario']['acesso'] ?? '')) === '1';
    }

    $entrega = shield_cron_chave_entregar($pdo, $ehAdmin);

    if ($entrega['chave'] === '') {
        http_response_code(403);
        echo $entrega['recusa'], "\n";
        exit;
    }

    echo $entrega['criada']
        ? "Chave criada agora. Configure o agendador da sua hospedagem para chamar:\n"
        : "A chave do relogio deste painel. Configure o agendador para chamar:\n";
    echo "  cron.php?chave=" . $entrega['chave'] . "\n";
    exit;
}

$inicio = microtime(true);
$linhas = array();

try {
    $n = shield_cobranca_marcar_vencidas($pdo);
    $linhas[] = sprintf('vencidas marcadas: %d', $n);
} catch (Throwable $e) {
    $linhas[] = 'vencidas: ' . $e->getMessage();
}

try {
    // As cobrancas do ciclo das assinaturas MANUAIS. Nas nativas quem cobra e o
    // provedor, e gerar aqui faria o cliente receber duas.
    $r = shield_assinatura_gerar_ciclo($pdo);
    $linhas[] = sprintf('ciclo: %d cobranca(s) criada(s), %d ja existia(m)',
                        $r['criadas'], $r['puladas']);
} catch (Throwable $e) {
    $linhas[] = 'ciclo: ' . $e->getMessage();
}

try {
    $n = shield_trabalho_processar($pdo, 25);
    $linhas[] = sprintf('trabalhos da fila: %d', $n);
} catch (Throwable $e) {
    $linhas[] = 'fila: ' . $e->getMessage();
}

try {
    // A peca principal, e nao a rede de seguranca: webhook se perde, e sem
    // alguem indo perguntar o pagamento nunca aparece.
    $r = shield_cobranca_conciliar($pdo);
    $linhas[] = sprintf('conciliacao: %d olhada(s), %d mudou(aram)', $r['olhadas'], $r['mudaram']);
} catch (Throwable $e) {
    $linhas[] = 'conciliacao: ' . $e->getMessage();
}

/* A ORDEM IMPORTA, e ela e esta: descobrir o dinheiro ANTES de suspender
   (11/09/2026). Ate aqui a regua passava primeiro, e quem pagou com o webhook
   perdido era suspenso na linha de cima e so depois o painel via o pagamento --
   que nao desfaz suspensao. Conciliar e barato e nunca desliga ninguem; a
   regua e a unica coisa aqui que para a loja de alguem. */
try {
    $r = shield_regua_passar($pdo);

    $enfileirados = 0;
    foreach ($r['avisos'] as $aviso) {
        $email = trim((string) ($aviso['cobranca']['email'] ?? ''));
        // UM AVISO POR COBRANCA E POR PASSO (08/10/2026): sem a marca, cada
        // passada do dia mandava o mesmo e-mail de novo. Ver regua.php.
        if ($email === '' || shield_regua_aviso_ja_enviado($pdo, $aviso)) {
            continue;
        }
        $m = shield_email_da_regua($pdo, $aviso);
        if (shield_email_enfileirar($pdo, $email, $m['assunto'], $m['html'])) {
            shield_regua_aviso_marcar($pdo, $aviso, $email);
            $enfileirados++;
        }
    }

    $linhas[] = sprintf('regua: %d aviso(s) na fila, %d suspensao(oes), %d proposta(s)',
                        $enfileirados, count($r['suspensoes']), count($r['propostas']));
} catch (Throwable $e) {
    // A regua falhando NAO suspende ninguem -- ela so deixa de avisar. E o
    // lado certo de errar: ausencia nao desliga caixa de loja.
    $linhas[] = 'regua: ' . $e->getMessage();
}

try {
    // O certificado digital vencendo (08/10/2026): um resumo por dia ao membro,
    // so com SMTP. Depois da regua porque nao decide nada -- e so aviso.
    $linhas[] = 'certificados: ' . shield_certificado_aviso_passar($pdo);
} catch (Throwable $e) {
    $linhas[] = 'certificados: ' . $e->getMessage();
}

try {
    $n = shield_parque_compactar($pdo);
    $linhas[] = sprintf('batidas compactadas: %d', $n);
} catch (Throwable $e) {
    $linhas[] = 'parque: ' . $e->getMessage();
}

shield_set_system_meta($pdo, 'cron_ultima_em', date('Y-m-d H:i:s'));

echo implode("\n", $linhas), "\n";
printf("%.2fs\n", microtime(true) - $inicio);
