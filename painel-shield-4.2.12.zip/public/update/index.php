<?php

require_once __DIR__ . '/../../funcoes/nucleo/system_bootstrap.php';
require_once __DIR__ . '/../../funcoes/nucleo/csrf.php';
require_once __DIR__ . '/../../funcoes/nucleo/update_guarda.php';
require_once __DIR__ . '/../../funcoes/nucleo/tranca_pastas.php';

// Como em install/index.php: estas telas NAO passam pelo router, entao o
// gancho de CSRF nao chega nelas sozinho. Isto tambem abre o filtro de saida
// que injeta o campo _csrf no formulario de aplicar.
shield_csrf_proteger();

if (session_status() !== PHP_SESSION_ACTIVE) {
    require_once __DIR__ . '/../../funcoes/nucleo/sessao.php'; shield_sessao_abrir();
}

function shield_h($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function shield_status_class($status)
{
    switch ($status) {
        case 'PASS':
            return 'status-pass';
        case 'WARN':
            return 'status-warn';
        default:
            return 'status-fail';
    }
}

$appConfig = shield_load_app_config();
if (empty($appConfig['installed'])) {
    shield_redirect('/install/');
}

$messages = [];
$warnings = [];
$errors = [];
$logs = [];
$summary = [
    'created_tables' => 0,
    'applied_migrations' => 0,
    'skipped_migrations' => 0,
    'db_version' => '0.0.0',
];

$dbConfig = shield_load_database_config();
$pdo = null;

try {
    $pdo = shield_create_pdo_connection($dbConfig);
} catch (Throwable $exception) {
    $errors[] = 'Falha de conexao com o banco: ' . $exception->getMessage();
}

$diagnostics = shield_collect_environment_diagnostics($dbConfig, $pdo);
if ($diagnostics['has_critical_failures']) {
    $errors[] = 'Existe ao menos um erro critico no ambiente. Atualizacao bloqueada ate a correcao.';
}

// O DocumentRoot entra na lista AQUI, e nao dentro de
// shield_collect_environment_diagnostics(): aquele arquivo e o tronco que
// todas as sessoes disputam, e este item nao precisa morar la. Ele avisa e
// nao trava -- ver o porque em shield_docroot_item().
$itemDocroot = shield_docroot_item(
    (string) ($_SERVER['DOCUMENT_ROOT'] ?? ''),
    shield_root_path() . DIRECTORY_SEPARATOR . 'public'
);
$diagnostics['items'][] = $itemDocroot;
if ($itemDocroot['aviso'] !== '') {
    $warnings[] = $itemDocroot['aviso'];
}

// QUEM PODE APLICAR. Ate 08/09/2026 a resposta era "qualquer um": esta tela
// aplicava migracao, criava tabela, convertia conta de recebimento e
// reescrevia o config/app.php num GET anonimo.
//
// A janela da instalacao continua abrindo no GET, de proposito: enquanto nao
// ha administrador nao ha a quem pedir sessao, e e para ca que o instalador
// manda o navegador. Painel ja instalado exige administrador logado e POST.
$temAdmin = $pdo !== null && shield_has_admin_user($pdo);
$portao = shield_update_pode_aplicar($temAdmin, isset($_SESSION) ? $_SESSION : array());
$aplicar = shield_update_deve_aplicar(
    $portao,
    (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'),
    (string) ($_POST['acao'] ?? '')
);

if (!$portao['pode']) {
    // 403 de verdade, e nao so um texto na tela: quem le esta rota por
    // programa (monitor, varredura, o proprio membro com curl) precisa ver a
    // recusa no status, nao ter de interpretar HTML.
    http_response_code(403);
    $errors[] = $portao['motivo'] === 'sem_permissao'
        ? 'Sua conta nao tem permissao para aplicar atualizacao. Peca a um administrador do painel.'
        : 'Esta tela aplica migracoes no banco e reescreve a configuracao do painel. '
            . 'Entre como administrador para continuar.';
}

if ($aplicar && $pdo !== null && empty($errors)) {
    try {
        shield_ensure_version_tables($pdo);

        $baselineResult = shield_sync_missing_baseline_tables($pdo, shield_baseline_sql_path(), $logs);
        $summary['created_tables'] = (int) $baselineResult['created_count'];

        $migrationResult = shield_run_migrations($pdo, shield_migrations_dir(), $logs);
        $summary['applied_migrations'] = (int) $migrationResult['applied_count'];
        $summary['skipped_migrations'] = (int) $migrationResult['skipped_count'];

        // Migracao ja aplicada cujo arquivo mudou depois. Nao trava mais nada,
        // mas o membro precisa ver -- correcao de migracao antiga se faz com
        // migracao NOVA, nunca editando a que ja rodou.
        foreach ((array) ($migrationResult['checksum_warnings'] ?? []) as $arquivo) {
            $warnings[] = 'A migracao ' . $arquivo . ' ja foi aplicada e o arquivo atual esta '
                . 'diferente do que rodou. Ela nao roda de novo; se algo precisa mudar no banco, '
                . 'escreva uma migracao nova.';
        }
        $summary['db_version'] = (string) $migrationResult['latest_version'];

        if (!$migrationResult['success']) {
            $errors[] = (string) $migrationResult['error'];
        } else {
            $messages[] = 'Atualizacao executada com sucesso.';

            // A conversao do que ja estava configurado em `gateways` para
            // conta_recebimento roda AQUI, e nao dentro da migracao, porque as
            // credenciais entram cifradas pelo cofre do painel -- e cofre e
            // PHP, nao SQL. E idempotente: so cria o que falta.
            //
            // O ponto e o membro nao refazer nada. Ele ja tem conta de gateway
            // ligada; a reforma nao pode custar a ele uma tarde reconfigurando
            // credencial que ele nem lembra onde guardou.
            try {
                require_once __DIR__ . '/../../funcoes/cobranca/cobranca.php';
                $conversao = shield_cobranca_converter_contas($pdo);
                if ((int) $conversao['criadas'] > 0) {
                    $messages[] = sprintf(
                        '%d conta(s) de recebimento trazidas da configuracao anterior.',
                        (int) $conversao['criadas']
                    );
                }
            } catch (Throwable $conversaoFalhou) {
                // Conversao e conveniencia; migracao e obrigacao. Falhar aqui
                // nao pode derrubar a atualizacao inteira -- o membro
                // reconfigura a conta na tela e segue.
                $warnings[] = 'Nao consegui converter as contas de recebimento: '
                    . $conversaoFalhou->getMessage();
            }

            // O piso de PHP novo so alcanca quem ja instalou por aqui: o
            // config/app.php e escrito uma vez e vence o padrao do codigo.
            // Ver shield_reconcile_version_floors().
            try {
                $pisos = shield_reconcile_version_floors();
                if ($pisos !== []) {
                    $messages[] = 'Requisitos de ambiente atualizados (' . implode('; ', $pisos) . ').';

                    // AVISO ANTES DO BLOQUEIO. O diagnostico marca PHP abaixo
                    // do minimo como falha critica, e falha critica trava a
                    // proxima atualizacao. Quem esta em PHP velho precisa ler
                    // isto AGORA, com a atualizacao desta rodada ja concluida,
                    // e nao descobrir na proxima vez diante de uma tela
                    // travada que nao explica o que mudou.
                    $novoMinimo = (string) (shield_load_app_config()['php_min_version'] ?? '');
                    if ($novoMinimo !== '' && version_compare(PHP_VERSION, $novoMinimo, '<')) {
                        $warnings[] = sprintf(
                            'ATENCAO: este servidor roda PHP %s e o painel passou a exigir %s ou superior. '
                            . 'Esta atualizacao foi concluida, mas a PROXIMA ficara bloqueada ate o PHP subir. '
                            . 'Troque a versao do PHP no painel da hospedagem (procure por "Selecionar versao do PHP" '
                            . 'ou "PHP Selector"). O PHP %s nao recebe mais correcao de seguranca.',
                            PHP_VERSION,
                            $novoMinimo,
                            PHP_VERSION
                        );
                    }
                }
            } catch (Throwable $pisoFalhou) {
                // Nao derruba a atualizacao: as migracoes ja rodaram e o banco
                // ja esta na versao nova. Piso desatualizado e chato, banco
                // pela metade e desastre.
                $warnings[] = 'Nao consegui atualizar os requisitos de ambiente em config/app.php: '
                    . $pisoFalhou->getMessage();
            }

            // Mesma historia do piso, com a cor: o padrao da marca esta no
            // codigo, mas quem vence e o que esta gravado em marca_cor. Sem
            // isto, o painel recolorido continua azul em toda instalacao que
            // ja rodou -- e o membro nao teria o que fazer alem de abrir a tela
            // de softhouse e adivinhar o hex novo.
            // Ver shield_reconcile_marca_padrao(): so troca o que ainda e de
            // fabrica; cor escolhida pelo membro fica.
            try {
                $marcaTrocada = shield_reconcile_marca_padrao($pdo);
                if ($marcaTrocada !== []) {
                    $messages[] = 'Cor da marca atualizada para o padrao novo ('
                        . implode('; ', $marcaTrocada) . ').';
                }
            } catch (Throwable $marcaFalhou) {
                // Cor errada e chato; atualizacao pela metade e desastre.
                $warnings[] = 'Nao consegui atualizar a cor padrao da marca: '
                    . $marcaFalhou->getMessage();
            }

            // A SEGUNDA TRANCA das pastas que o pacote nao alcanca. O
            // atualizador preserva config/ inteira (shield_atu_preservados), e
            // com razao -- e onde mora a instalacao do membro. O efeito
            // colateral e que nada que venha no pacote e escrito la, nem o
            // .htaccess que nega tudo. Quem ja instalou so recebe a tranca por
            // aqui. Ver funcoes/nucleo/tranca_pastas.php.
            try {
                $trancadas = shield_tranca_pastas_do_painel();
                if ($trancadas !== []) {
                    $messages[] = 'Protecao de pasta criada em: ' . implode('; ', $trancadas) . '.';
                }
            } catch (Throwable $trancaFalhou) {
                // Mesma regra das anteriores: nao derruba a atualizacao.
                $warnings[] = 'Nao consegui criar a protecao de pasta: ' . $trancaFalhou->getMessage();
            }
        }

        shield_set_system_meta($pdo, 'app_version', (string) ($appConfig['app_version'] ?? '2.0.0'));
        if (empty($appConfig['installed_at'])) {
            shield_set_system_meta($pdo, 'installed_at', date('c'));
        }

        $pending = shield_detect_pending_updates($pdo, shield_baseline_sql_path(), shield_migrations_dir());
        if (!empty($pending['needs_update'])) {
            if (!empty($pending['missing_tables'])) {
                $warnings[] = 'Ainda existem tabelas ausentes: ' . implode(', ', $pending['missing_tables']);
            }
            if (!empty($pending['pending_migrations'])) {
                $warnings[] = 'Ainda existem migracoes pendentes: ' . implode(', ', $pending['pending_migrations']);
            }
            if (!empty($pending['checksum_errors'])) {
                $warnings[] = 'Conflito de checksum: ' . implode(', ', $pending['checksum_errors']);
            }
        } elseif (shield_requires_first_access_setup($pdo)) {
            shield_redirect('/install/setup.php');
        } else {
            // Banco em dia e primeiro acesso ja feito: esta tela era um beco
            // sem saida -- quem instalou num banco reaproveitado (o setup ja
            // tinha sido concluido nele) ficava aqui sem link nenhum.
            $proximo = '/login.php';
        }
    } catch (Throwable $exception) {
        $errors[] = 'Falha no processo de update: ' . $exception->getMessage();
    }
}

$pendencias = null;
if (!$aplicar && $pdo !== null && empty($errors)) {
    try {
        $pendencias = shield_detect_pending_updates($pdo, shield_baseline_sql_path(), shield_migrations_dir());
    } catch (Throwable $pendenciaFalhou) {
        $warnings[] = 'Nao consegui conferir o que esta pendente: ' . $pendenciaFalhou->getMessage();
    }
}

if (isset($_GET['installed']) && $_GET['installed'] === '1') {
    $messages[] = 'Instalacao inicial concluida. Verificacao de update finalizada.';
}
?>
<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Painel Shield - Update</title>
    <link rel="stylesheet" href="/css/instalacao.css?v=<?= (int) @filemtime(__DIR__ . '/../css/instalacao.css'); ?>">
</head>
<body>
    <div class="container">
        <div class="topo">
            <img src="/img/escudo-256.png?v=<?= (int) @filemtime(__DIR__ . '/../img/escudo-256.png'); ?>" alt="" aria-hidden="true">
            <div class="dizer">
                <h1>Atualizacao do banco</h1>
                <p>Confere o ambiente e poe o banco na versao deste codigo: as tabelas que faltam e as migracoes que ainda nao rodaram.</p>
            </div>
            <span class="etapa">Manutencao</span>
        </div>

        <?php if (!empty($proximo)): ?>
            <p><a class="entrar" href="<?= shield_h($proximo); ?>">Entrar no painel &rarr;</a></p>
        <?php endif; ?>
        <?php foreach ($messages as $message): ?>
            <div class="msg msg-ok"><?= shield_h($message); ?></div>
        <?php endforeach; ?>

        <?php foreach ($warnings as $warning): ?>
            <div class="msg msg-warn"><?= shield_h($warning); ?></div>
        <?php endforeach; ?>

        <?php foreach ($errors as $error): ?>
            <div class="msg msg-err"><?= shield_h($error); ?></div>
        <?php endforeach; ?>

        <?php if (!$aplicar && $portao['pode'] && empty($errors)): ?>
            <?php if ($pendencias !== null && empty($pendencias['needs_update'])): ?>
                <div class="msg msg-ok">Nada pendente: o banco ja esta na versao deste codigo.</div>
            <?php elseif ($pendencias !== null): ?>
                <div class="msg msg-warn">
                    Ha atualizacao pendente.
                    <?php if (!empty($pendencias['missing_tables'])): ?>
                        Tabelas ausentes: <?= shield_h(implode(', ', $pendencias['missing_tables'])); ?>.
                    <?php endif; ?>
                    <?php if (!empty($pendencias['pending_migrations'])): ?>
                        Migracoes: <?= shield_h(implode(', ', $pendencias['pending_migrations'])); ?>.
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <form method="post" action="">
                <input type="hidden" name="acao" value="aplicar">
                <button class="entrar" type="submit" style="border:0;cursor:pointer">Aplicar agora</button>
            </form>
        <?php endif; ?>

        <div class="summary">
            <div class="card">
                <small>Tabelas criadas</small>
                <strong><?= shield_h($summary['created_tables']); ?></strong>
            </div>
            <div class="card">
                <small>Migracoes aplicadas</small>
                <strong><?= shield_h($summary['applied_migrations']); ?></strong>
            </div>
            <div class="card">
                <small>Migracoes ignoradas</small>
                <strong><?= shield_h($summary['skipped_migrations']); ?></strong>
            </div>
            <div class="card">
                <small>Versao DB</small>
                <strong><?= shield_h($summary['db_version']); ?></strong>
            </div>
        </div>

        <h2>Diagnostico de Hospedagem</h2>
        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Atual</th>
                    <th>Necessario/Recomendado</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($diagnostics['items'] as $item): ?>
                    <tr>
                        <td><?= shield_h($item['label']); ?></td>
                        <td><?= shield_h($item['current']); ?></td>
                        <td><?= shield_h($item['required']); ?></td>
                        <td><span class="<?= shield_h(shield_status_class($item['status'])); ?>"><?= shield_h($item['status']); ?></span></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h2>Log da Atualizacao</h2>
        <?php if (empty($logs)): ?>
            <p>Nenhuma operacao foi executada.</p>
        <?php else: ?>
            <ul>
                <?php foreach ($logs as $entry): ?>
                    <li>[<?= shield_h(strtoupper((string) $entry['level'])); ?>] <?= shield_h($entry['message']); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</body>
</html>
