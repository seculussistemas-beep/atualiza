/* Senha: olho de mostrar/ocultar, medidor de forca e conferencia da repeticao.
 * 03/09/2026. Usado nas telas de entrada (login, cadastro, redefinir) e no
 * painel (editar perfil). Um lugar so, para a escala nao divergir.
 *
 * A ESCALA E A MESMA de funcoes/acesso/senha_forca.php: tamanho e variedade
 * (minuscula, maiuscula, numero, simbolo), com o tamanho compensando a
 * variedade. Se mudar la, mude aqui. 0 vazia, 1 fraca, 2 razoavel, 3 boa,
 * 4 forte; o painel exige 3.
 *
 * Marcacao esperada:
 *   <div class="senha-caixa"><input ...><button class="olho">...</button></div>
 *   <input data-forca="idDoMedidor">   <div class="forca" id="idDoMedidor">...</div>
 *   <input data-confere="idDoOriginal">  e um .confere no mesmo .campo
 */
(function () {
  function forca(s) {
    if (!s.length) return 0;
    var c = 0;
    if (/[a-z]/.test(s)) c++;
    if (/[A-Z]/.test(s)) c++;
    if (/[0-9]/.test(s)) c++;
    if (/[^a-zA-Z0-9]/.test(s)) c++;
    var n = s.length;
    if (n < 8) return 1;
    if ((n >= 12 && c >= 3) || (n >= 16 && c >= 2)) return 4;
    if (c >= 3 || (n >= 12 && c >= 2)) return 3;
    if (c >= 2) return 2;
    return 1;
  }

  var rotulos = ['', 'Fraca', 'Razoável', 'Boa', 'Forte'];
  var dicas = ['', 'Use 8 ou mais caracteres.', 'Misture letras, números e símbolos.', 'Serve. Mais longa fica melhor.', 'Ótima.'];

  function ligar(raiz) {
    raiz = raiz || document;

    raiz.querySelectorAll('.olho').forEach(function (olho) {
      if (olho.dataset.ligado) return;
      olho.dataset.ligado = '1';
      var campo = olho.parentNode.querySelector('input');
      if (!campo) return;
      olho.addEventListener('click', function () {
        var mostrando = campo.type === 'text';
        campo.type = mostrando ? 'password' : 'text';
        olho.setAttribute('aria-pressed', mostrando ? 'false' : 'true');
        olho.setAttribute('aria-label', mostrando ? 'Mostrar senha' : 'Ocultar senha');
        campo.focus();
      });
    });

    raiz.querySelectorAll('input[data-forca]').forEach(function (campo) {
      if (campo.dataset.ligado) return;
      campo.dataset.ligado = '1';
      var medidor = document.getElementById(campo.getAttribute('data-forca'));
      if (!medidor) return;
      var nivelEl = medidor.querySelector('b');
      var dicaEl = medidor.querySelector('span');
      // A dica que veio no HTML fica enquanto o campo esta vazio.
      var dicaInicial = dicaEl ? dicaEl.textContent : '';
      function atualiza() {
        var n = forca(campo.value);
        medidor.setAttribute('data-nivel', n);
        if (nivelEl) nivelEl.textContent = rotulos[n];
        if (dicaEl) dicaEl.textContent = n === 0 ? dicaInicial : dicas[n];
        // O navegador so deixa enviar a partir de "boa"; o servidor confere de novo.
        campo.setCustomValidity(campo.value && n < 3 ? 'A senha precisa ser pelo menos boa.' : '');
      }
      campo.addEventListener('input', atualiza);
      atualiza();
    });

    raiz.querySelectorAll('input[data-confere]').forEach(function (campo) {
      if (campo.dataset.ligado) return;
      campo.dataset.ligado = '1';
      var original = document.getElementById(campo.getAttribute('data-confere'));
      var caixa = campo.closest('.campo') || campo.parentNode.parentNode;
      var aviso = caixa ? caixa.querySelector('.confere') : null;
      if (!original) return;
      function confere() {
        var igual = campo.value !== '' && campo.value === original.value;
        campo.setCustomValidity(campo.value && !igual ? 'As duas senhas não são iguais.' : '');
        if (!aviso) return;
        aviso.className = 'confere' + (campo.value === '' ? '' : (igual ? ' igual' : ' diferente'));
        aviso.textContent = campo.value === '' ? '' : (igual ? 'As senhas batem.' : 'Ainda não é a mesma senha.');
      }
      campo.addEventListener('input', confere);
      original.addEventListener('input', confere);
    });
  }

  window.shieldSenhaForca = forca;
  window.shieldLigarSenha = ligar;
})();
