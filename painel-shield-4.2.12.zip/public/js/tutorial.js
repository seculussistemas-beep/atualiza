/* O tutorial das telas -- 08/09/2026; refeito em 10/09/2026 (tarde).
 *
 * Um passeio guiado que comeca na SUA CONTA (a bolinha no canto direito), passa
 * pela BARRA LATERAL item por item e depois entra em CADA TELA do painel,
 * campo por campo, na ordem em que o dia acontece: quem ainda nao e cliente,
 * o inicio do contrato, a lista de clientes, a ficha de um deles, o contrato,
 * a mudanca no meio do contrato, maquinas, monitoramento, logs, dinheiro e,
 * por fim, as configuracoes. Voltar / Proximo / Pular, e o "?" do rodape da
 * lateral traz de volta.
 *
 * COMO ATRAVESSA PAGINAS: o passeio troca de tela a cada bloco, entao nenhum
 * script sobrevive de um passo ao outro. O estado (ativo, passo, rumo e os
 * enderecos ja visitados) mora no localStorage; a pagina que abre le o
 * estado e, se for a tela do passo, desenha o destaque -- se nao for (a pessoa
 * clicou em outro lugar no meio), o passeio para de se intrometer e espera o
 * "?" de novo.
 *
 * ALGUMAS TELAS SO EXISTEM PARA UM CLIENTE (a ficha, o contrato, a mudanca, o
 * inicio do contrato): nao ha URL fixa para elas. O passo traz `via`, o
 * seletor do link que leva ate la a partir da tela anterior; o passeio segue
 * o primeiro link que achar e guarda o endereco para o Voltar. Instalacao sem
 * cliente nenhum pula essas telas inteiras, sem sumir em silencio.
 *
 * O ALVO MUDA A CADA PASSO, e e isso que faz o passeio parecer andar. Onde a
 * tela tem um seletor unico ele e usado como esta; onde nao tinha, a tela
 * ganhou um `data-tour`, que e endereco explicito e nao se perde no proximo
 * ajuste de layout -- foi por seletor adivinhado que o passeio ja sumiu em
 * Cobrancas uma vez.
 *
 * E O RESTO DA TELA APAGA. O recorte e uma sombra de 9999px em volta do alvo
 * -- o negativo do destaque, sem precisar de quatro divs tapando os lados.
 *
 * NUNCA SOME EM SILENCIO. Se o seletor do passo nao achar nada, cai para o
 * cabecalho, e depois para o corpo da pagina.
 */
(function () {
  'use strict';

  var CHAVE = 'painel_tutorial';

  /* Os prazos citados nos textos vem do PHP (templates/fecha.php), das mesmas
     constantes que a rotina usa: escrito a mao aqui, o texto ficou para tras
     quando o prazo mudou. */
  var DADOS = window.shieldTutorialDados || {};

  /* Os passos. `tela` amarra os passos consecutivos de uma mesma tela e e de
     onde saem as duas contas do balao. `url` e o caminho da tela; `via` e o
     link que leva ate ela quando o caminho depende de um cliente. `abrir`
     abre algo antes de medir (um menu, um bloco fechado). `preparar: 'menu'`
     garante a lateral aberta e todos os grupos expandidos. `quantos` une os
     irmaos do mesmo seletor num recorte so. */
  var PASSOS = [
    /* ---------- a sua conta ---------- */
    { url: '/index.php', tela: 'Sua conta', alvo: '.conta-topo',
      titulo: 'Este é você',
      texto: 'A bolinha com as suas iniciais, no canto direito de toda tela, é a sua conta. Clicar nela abre o menu com o seu perfil, a sua empresa e a saída do painel. Vamos abrir.' },
    { url: '/index.php', tela: 'Sua conta', alvo: '.menu-conta', abrir: '.conta-topo',
      titulo: 'O menu da conta',
      texto: 'Em cima, o seu nome e o e-mail com que você entra. "Meu perfil" troca nome e senha e mostra a sua atividade recente. "Minha empresa" é o cadastro da sua softhouse: é o nome que sai no PIX e nos avisos ao cliente. "Sair" encerra a sessão neste navegador.' },

    /* ---------- a barra lateral ---------- */
    { url: '/index.php', tela: 'Menu', alvo: '#lateral', preparar: 'menu',
      titulo: 'A barra lateral',
      texto: 'Tudo o que o painel faz está aqui, em três grupos: quem ainda não é cliente, os clientes e as configurações. Cada grupo abre e fecha no título, e o painel lembra como você deixou. Vamos passar item por item.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral .marca-painel', preparar: 'menu',
      titulo: 'O nome do painel',
      texto: 'O escudo e o nome da sua empresa. Clicar aqui volta para o Dashboard de qualquer tela.' },
    { url: '/index.php', tela: 'Menu', alvo: '#btBusca',
      titulo: 'Buscar cliente ou terminal',
      texto: 'Ctrl+K de qualquer lugar. Digite parte do nome, do CNPJ ou do nome da máquina e a lista aparece enquanto você escreve; setas e Enter abrem o resultado.' },
    { url: '/index.php', tela: 'Menu', alvo: '.parque-chip:not(.sandbox-chip)',
      titulo: 'Caixas no ar',
      texto: 'Quantas máquinas abriram o sistema nos últimos dias, de quantas existem. Vermelho é zero caixa dando sinal. Clicar leva ao Monitoramento.' },
    { url: '/index.php', tela: 'Menu', alvo: '.sandbox-chip',
      titulo: 'Contas em homologação',
      texto: 'Aparece só quando alguma forma de recebimento está em teste (sandbox). É o lembrete de que o PIX gerado por ela não vale dinheiro de verdade. Some quando você passa a conta para produção.' },
    { url: '/index.php', tela: 'Menu', alvo: '#btTema',
      titulo: 'Claro ou escuro',
      texto: 'Troca o tema do painel. Fica guardado neste navegador.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral .grupo-acc[data-grupo="avaliacao"]', preparar: 'menu',
      titulo: 'Grupo: Ainda não é cliente',
      texto: 'Quem apareceu no painel mas ainda não fechou contrato. Toda loja que instala o ERP se cadastra aqui sozinha, no primeiro contato do sistema com o painel.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/avaliacao.php"]', preparar: 'menu',
      titulo: 'Em avaliação',
      texto: 'A fila de quem está no período de teste. O número no badge é quantas lojas estão testando agora. É por aqui que se dá início ao contrato.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral .grupo-acc[data-grupo="clientes"]', preparar: 'menu',
      titulo: 'Grupo: Clientes',
      texto: 'O dia a dia de quem já paga: a lista, as máquinas, quem está no ar, os logs e o dinheiro. A ordem é a ordem do dia de quem opera.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/clientes.php"]', preparar: 'menu',
      titulo: 'Clientes',
      texto: 'Todo mundo que roda o seu sistema, com a situação da licença em cada linha. O badge conta as licenças vencidas.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/terminais.php"]', preparar: 'menu',
      titulo: 'Terminais',
      texto: 'As máquinas cadastradas, agrupadas por cliente. Aqui se apaga máquina que não existe mais e se vê quem está ocupando vaga.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/parque.php"]', preparar: 'menu',
      titulo: 'Monitoramento',
      texto: 'Quem está no ar, quem parou e que versão do ERP cada máquina roda. Terminal parado é loja parada, e você fica sabendo antes do telefone tocar.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/logs_cliente.php"]', preparar: 'menu',
      titulo: 'Logs do cliente',
      texto: 'Pede o arquivo de log de uma máquina e ele chega sozinho, sem o cliente zipar pasta nenhuma.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href^="/cobrancas.php"]', preparar: 'menu',
      titulo: 'Cobranças',
      texto: 'Cada fatura, por quem foi emitida e em que pé está. O badge conta o que está em aberto, e fica âmbar quando um cliente pede prazo. Assinaturas e pré-pagos se veem lá dentro.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/relatorio_financeiro.php"]', preparar: 'menu',
      titulo: 'Relatório do período',
      texto: 'O que entrou e o que está para entrar entre duas datas: recebido pela data do pagamento, a receber pela do vencimento.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/contas_receber.php"]', preparar: 'menu',
      titulo: 'Contas a receber',
      texto: 'Quem está devendo, um cliente por linha: quanto ao todo, quanto já venceu, a fatura mais atrasada e o próximo vencimento.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral .grupo-acc[data-grupo="config"]', preparar: 'menu',
      titulo: 'Grupo: Configurações',
      texto: 'O que se ajusta uma vez e fica. Dois blocos: o que fala com o ERP e o que fala com o dinheiro.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/licenca_arquivo.php"]', preparar: 'menu',
      titulo: 'Licença em arquivo',
      texto: 'Para o cliente sem internet: a licença vai num arquivo, por WhatsApp, e-mail ou pen drive.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/emissor_licenca.php"]', preparar: 'menu',
      titulo: 'Chaves',
      texto: 'O par de chaves que assina toda licença. A pública vai dentro do ERP; a privada nunca sai daqui.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/atualizacao.php"]', preparar: 'menu',
      titulo: 'Atualização',
      texto: 'Traz a versão nova deste painel sem FTP. Não mexe no ERP do cliente.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/limpeza_cadastros.php"]', preparar: 'menu',
      titulo: 'Limpeza de cadastros',
      texto: 'Empresa que se cadastrou sozinha e nunca deu sinal, e cliente encerrado. Aqui se apaga de verdade, com você marcando linha por linha.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/modulos.php"]', preparar: 'menu',
      titulo: 'Módulos',
      texto: 'O catálogo do que o cliente contrata além do básico, com o preço de tabela e o que cada módulo liga no ERP.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/listar_planos.php"]', preparar: 'menu',
      titulo: 'Planos',
      texto: 'A tabela do pré-pago: quantos meses e por quanto. É ela que aparece em "Cobrar por", na Nova cobrança.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/formas_recebimento.php"]', preparar: 'menu',
      titulo: 'Formas de recebimento',
      texto: 'Por onde o dinheiro chega: provedor com credencial, PIX na sua chave ou dinheiro em espécie.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/regua.php"]', preparar: 'menu',
      titulo: 'Régua de cobrança',
      texto: 'Quantos dias antes e depois do vencimento o cliente é avisado, o que acontece quando atrasa e a liberação em confiança.' },
    { url: '/index.php', tela: 'Menu', alvo: '#lateral a.menu-item[href="/contrato_modelo.php"]', preparar: 'menu',
      titulo: 'Modelo de contrato',
      texto: 'O contrato que o cliente lê e aceita na área do cliente. Você escreve uma vez; o painel preenche os dados de cada um e guarda o aceite em PDF.' },
    { url: '/index.php', tela: 'Menu', alvo: '#btRecolher', preparar: 'menu',
      titulo: 'Recolher o menu',
      texto: 'Deixa só os ícones e dá mais tela para as listas. Passar o mouse mostra o nome; o "?" ao lado é este tutorial.' },

    /* ---------- Dashboard ---------- */
    { url: '/index.php', tela: 'Dashboard', alvo: '.topo-tela',
      titulo: 'Onde você começa o dia',
      texto: 'A Central de operação é a tela de todo dia. O relógio à direita anda sozinho: é o sinal de que o painel está vivo e falando com o banco agora.' },
    { url: '/index.php', tela: 'Dashboard', alvo: '[data-tour="inicio-numeros"]',
      titulo: 'Os quatro números',
      texto: 'Licenças válidas, caixas dando sinal, o que entrou no mês e o que há para receber. Cada um é um link: clicar leva para a lista já filtrada por aquilo.' },
    { url: '/index.php', tela: 'Dashboard', alvo: '[data-tour="inicio-carteira"]',
      titulo: 'Carteira de licenças',
      texto: 'A barra divide a sua carteira em quatro estados: válida, vencendo, vencida e bloqueada. Cada faixa abre a lista de clientes já filtrada por ela, e a legenda diz quantos são.' },
    { url: '/index.php', tela: 'Dashboard', alvo: '.regua',
      titulo: 'Vencimentos deste mês',
      texto: 'Cada risco é um dia do mês e a altura diz quantos clientes renovam nele. Serve para ver os picos antes de eles virarem telefone tocando.' },
    { url: '/index.php', tela: 'Dashboard', alvo: '[data-tour="inicio-versoes"]',
      titulo: 'Versões rodando',
      texto: 'Que versão do ERP cada caixa roda, da mais nova para a mais velha. Quem ficou para trás só recebe a correção no próximo update.' },
    { url: '/index.php', tela: 'Dashboard', alvo: '[data-tour="inicio-renovacoes"]',
      titulo: 'Renovações e recebimento',
      texto: 'Doze meses de histórico: quanto foi renovado e quanto entrou. Preenche sozinho conforme a validade anda e as faturas são pagas.' },
    { url: '/index.php', tela: 'Dashboard', alvo: '[data-tour="inicio-consultas"]',
      titulo: 'Consultas de licença',
      texto: 'Toda vez que um caixa abre, ele pergunta ao painel se pode operar. Recusada é caixa que perguntou e levou não: loja parada até alguém resolver.' },
    { url: '/index.php', tela: 'Dashboard', alvo: '.listas-decisao',
      titulo: 'As próximas decisões',
      texto: 'O que venceu, quem chegou sem licença, o que vence em breve e o que há para receber. Bloco vazio é boa notícia: nada esperando por você.' },

    /* ---------- Em avaliação ---------- */
    { url: '/avaliacao.php', tela: 'Em avaliação', alvo: '.topo-tela',
      titulo: 'Quem ainda não é cliente',
      texto: 'Estas lojas vêm do ERP: na primeira vez que o sistema fala com o painel, a empresa se cadastra sozinha com o CNPJ e a razão social que estão na instalação. Ela ganha um período de teste e entra nesta fila até alguém dar início ao contrato ou o teste vencer.' },
    { url: '/avaliacao.php', tela: 'Em avaliação', alvo: '#regra_dias',
      titulo: 'Dias de teste',
      texto: 'Quantos dias uma loja nova pode usar o sistema antes de virar cliente. Vale para todo mundo que entra na fila; para uma loja só, mova a data direto na linha dela.' },
    { url: '/avaliacao.php', tela: 'Em avaliação', alvo: '#regra_terminais',
      titulo: 'Caixas no teste',
      texto: 'Quantas máquinas o teste libera. Cada loja pode ter um número próprio, ajustado pelo ícone de máquinas na linha.' },
    { url: '/avaliacao.php', tela: 'Em avaliação', alvo: '#buscaFila',
      titulo: 'Procurar na fila',
      texto: 'Nome ou CNPJ. A lista filtra enquanto você digita.' },
    { url: '/avaliacao.php', tela: 'Em avaliação', alvo: '[data-tour="aval-fila"]',
      titulo: 'A fila',
      texto: 'Uma linha por loja: quando apareceu, até quando vai o teste, quantas máquinas já deram sinal e o último contato. Teste vencido há mais de ' + DADOS.encerramentoDias + ' dias é encerrado sozinho pelo painel; com rascunho do contrato salvo, o prazo sobe para ' + DADOS.encerramentoDiasRascunho + ' dias.' },
    { url: '/avaliacao.php', tela: 'Em avaliação', alvo: '[data-tour="aval-fila"] .acoes',
      titulo: 'O que se faz com cada uma',
      texto: 'Prorrogar o teste, mudar quantos caixas ela libera, encerrar quem desistiu e, o principal, o ícone de contrato: dar início ao contrato (ou concluir, quando já há rascunho salvo). É ele que transforma a loja em cliente. Vamos entrar.' },

    /* ---------- Dar início ao contrato ---------- */
    { url: '/fechamento.php', tela: 'Início do contrato', via: 'a[href^="/fechamento.php?id="]', alvo: '.topo-tela',
      titulo: 'Tudo numa tela só',
      texto: 'Aqui a loja vira cliente. Seis blocos, de cima para baixo: o cadastro, os responsáveis, o que ela contrata, como paga, por onde o dinheiro entra e a primeira cobrança. Nada é gravado até você clicar em "Dar início ao contrato", e um F5 não duplica nada.' },
    { url: '/fechamento.php', tela: 'Início do contrato', alvo: '[data-tour="fech-1"]',
      titulo: '1. Cadastro',
      texto: 'Razão social e CNPJ vieram do ERP e ficam travados. O resto você completa: endereço, CEP (que preenche bairro, cidade e UF sozinho), telefone e e-mail da loja. Boleto exige o CEP; PIX não.' },
    { url: '/fechamento.php', tela: 'Início do contrato', alvo: '#area_senha',
      titulo: 'Senha da área do cliente',
      texto: 'O cliente tem uma página só dele, onde vê a licença, as máquinas e as faturas com o PIX. Ele entra com o e-mail da loja e esta senha. Vazia, nenhuma senha é definida; dá para resetar depois na ficha.' },
    { url: '/fechamento.php', tela: 'Início do contrato', alvo: '[data-tour="fech-2"]',
      titulo: '2. Responsáveis',
      texto: 'Quem assina o contrato e quem paga a fatura, cada um com nome, telefone e e-mail. Quase sempre são pessoas diferentes: quem atende o telefone da cobrança raramente é o dono. O botão copia um para o outro quando são a mesma pessoa.' },
    { url: '/fechamento.php', tela: 'Início do contrato', alvo: '[data-tour="fech-3"]',
      titulo: '3. O que ele vai contratar',
      texto: 'Inclusos no plano é o que a mensalidade já cobre. Terminais adicionais são os que o cliente quer além disso, e cada um custa o valor do campo ao lado, por mês; a licença libera a soma dos dois. Embaixo, os módulos: o preço de tabela é copiado para o cliente na hora de marcar.' },
    { url: '/fechamento.php', tela: 'Início do contrato', alvo: '[data-tour="fech-4"]',
      titulo: '4. Como ele paga',
      texto: 'Assinatura é a mensalidade que nasce sozinha todo ciclo (mensal, trimestral, anual). Pré-pago é uma fatura só, pelos meses escolhidos, e a licença vale a partir do pagamento. O valor é digitado aqui; a prévia embaixo soma módulos e caixas fora do plano.' },
    { url: '/fechamento.php', tela: 'Início do contrato', alvo: '#vencimento',
      titulo: 'O vencimento',
      texto: 'Na assinatura, o primeiro vencimento define o dia do mês de todas as próximas. No pré-pago, é a data de pagamento: até quando a fatura única pode ser paga.' },
    { url: '/fechamento.php', tela: 'Início do contrato', alvo: '[data-tour="fech-5"]',
      titulo: '5. Por onde o dinheiro entra',
      texto: 'A conta de recebimento que vai gerar o PIX, o boleto ou o link de cartão, entre as que estão ligadas em Formas de recebimento. Na assinatura ela fica fixa: todo ciclo emite nela. Só aparece a forma que a conta escolhida sabe fazer.' },
    { url: '/fechamento.php', tela: 'Início do contrato', alvo: '[data-tour="fech-6"]',
      titulo: '6. Primeira cobrança',
      texto: 'O contrato só começa gerando a primeira fatura, pela conta escolhida: no gateway sai o código para o cliente pagar, no PIX na sua chave sai o copia e cola, no dinheiro a fatura fica aberta a receber no balcão. A caixa que sobra é a de liberar o sistema antes do primeiro pagamento. "Gravar rascunho" guarda tudo sem virar cliente e sem emitir nada; "Dar início ao contrato" gera a fatura e faz a loja sair da fila e aparecer em Clientes.' },

    /* ---------- Clientes ---------- */
    { url: '/clientes.php', tela: 'Clientes', alvo: '.faixa-topo',
      titulo: 'Todo mundo que roda o seu sistema',
      texto: 'Depois do início do contrato a loja aparece aqui. A faixa diz quantos clientes o recorte atual tem; ela muda junto com o filtro, então é sempre a contagem do que está na tela.' },
    { url: '/clientes.php', tela: 'Clientes', alvo: '.faixa-numeros',
      titulo: 'Estes números são filtros',
      texto: 'Válidas, vencendo, vencidas, bloqueadas. Clique em "vencidas" e a lista abaixo vira só as vencidas; clique de novo para voltar a todas. Encerrados não entram em "todas": eles moram na Limpeza de cadastros.' },
    { url: '/clientes.php', tela: 'Clientes', alvo: '[data-tour="clientes-filtro"]',
      titulo: 'Buscar e recortar',
      texto: 'Nome, CNPJ e situação da licença. O que você escolhe fica guardado: o "Voltar" de qualquer tela do cliente traz a lista com a mesma busca.' },
    { url: '/clientes.php', tela: 'Clientes', alvo: 'table.lista',
      titulo: 'A lista',
      texto: 'Cada linha traz a situação, a validade, quantos caixas contratou e quantos estão dando sinal, e quanto há em aberto. A bolinha da esquerda é a cor da situação: verde válida, amarela vencendo ou bloqueada, vermelha vencida.' },
    { url: '/clientes.php', tela: 'Clientes', alvo: 'table.lista .acoes',
      titulo: 'O que se faz em cada linha',
      texto: 'Abrir a ficha, o contrato, as máquinas, as cobranças e os logs daquele cliente. Vamos abrir a ficha do primeiro.' },

    /* ---------- Visão do cliente ---------- */
    { url: '/ver_empresa.php', tela: 'Ficha do cliente', via: 'table.lista a[href*="ver_empresa.php"]', alvo: '.topo-tela',
      titulo: 'Tudo de um cliente num lugar só',
      texto: 'Razão social, CNPJ e cidade em cima. O "Voltar" leva à lista de clientes com a busca que estava lá.' },
    { url: '/ver_empresa.php', tela: 'Ficha do cliente', alvo: '[data-tour="ficha-numeros"]',
      titulo: 'Os quatro números dele',
      texto: 'A licença (até quando vale e o dia em que renova), quantos caixas estão dando sinal de quantos contratou, quanto ele deve e a situação. "Encerrar" marca o cliente como encerrado sem apagar nada: ele some das listas e o ERP recebe "encerrado".' },
    { url: '/ver_empresa.php', tela: 'Ficha do cliente', alvo: '[data-tour="ficha-area"]',
      titulo: 'A área do cliente',
      texto: 'O link fixo da página dele, para copiar ou mandar no WhatsApp. Ele entra com o e-mail da loja e a senha; "Resetar senha" sorteia uma temporária, válida ' + DADOS.senhaTemporariaDias + ' dias, que ele troca no primeiro acesso.' },
    { url: '/ver_empresa.php', tela: 'Ficha do cliente', alvo: '.ficha-quatro > div:nth-child(1) .card',
      titulo: 'Terminais',
      texto: 'As máquinas dele, com a versão, o último sinal e o botão de pedir o log de cada uma. Até quatro linhas e o quadro rola por dentro; "gerenciar" abre a lista completa.' },
    { url: '/ver_empresa.php', tela: 'Ficha do cliente', alvo: '.ficha-quatro > div:nth-child(2) .card',
      titulo: 'Monitoramento',
      texto: 'Quantas trabalhando e quantas sem sinal, o último contato da loja e as versões do ERP nas máquinas dela, com a mais nova marcada.' },
    { url: '/ver_empresa.php', tela: 'Ficha do cliente', alvo: '.ficha-quatro > div:nth-child(3) .card',
      titulo: 'Cobranças',
      texto: 'A assinatura na primeira linha (valor, dia e quem gera o PIX) e as últimas faturas com a situação de cada uma. Quando o cliente avisa pela área dele que pagou, aparece aqui.' },
    { url: '/ver_empresa.php', tela: 'Ficha do cliente', alvo: '.ficha-quatro > div:nth-child(4) .card',
      titulo: 'Logs que ele mandou',
      texto: 'Os arquivos de log que já chegaram desta loja. Vazio diz "nenhum log recebido": o pedido se faz na tela de Logs do cliente. Agora o contrato dele.' },

    /* ---------- Contrato do cliente ---------- */
    { url: '/editar_empresa.php', tela: 'Contrato do cliente', via: 'a[href*="editar_empresa.php"]', derivar: 'Ficha do cliente', alvo: '[data-tour="contrato-maquinas"]',
      titulo: 'Máquinas e módulos',
      texto: 'Quantos caixas ele contratou, quantos o plano inclui e quanto custa cada um a mais, com o que está dando sinal agora. Isto é só leitura: mexer em caixa e módulo é em "Mudar o contrato", que mostra o antes e o depois e cobra o mês corrente.' },
    { url: '/editar_empresa.php', tela: 'Contrato do cliente', alvo: '[data-tour="contrato-cadastro"]',
      titulo: 'Cadastro',
      texto: 'Os mesmos campos do início do contrato, para corrigir depois: endereço, CEP, telefone e e-mail da loja, a senha da área do cliente e os dois responsáveis. Razão social e CNPJ continuam travados: vieram do ERP.' },
    { url: '/editar_empresa.php', tela: 'Contrato do cliente', alvo: '[data-tour="contrato-licenca"]',
      titulo: 'Licença e acesso',
      texto: 'A validade anda sozinha quando o cliente paga; por isso o campo vem travado e só abre marcando "Ajustar à mão". Bloqueado é para fraude, troca de CNPJ ou litígio, nunca para atraso: atraso quem trata é a régua.' },
    { url: '/editar_empresa.php', tela: 'Contrato do cliente', alvo: 'button[type="submit"].btn-primary',
      titulo: 'Salvar',
      texto: 'Grava o cadastro, a licença e o acesso. Toda mudança fica no livro de auditoria com o antes e o depois. Agora a tela onde o contrato muda de verdade.' },

    /* ---------- Mudar o contrato ---------- */
    { url: '/mudanca_contrato.php', tela: 'Mudar o contrato', via: 'a[href*="mudanca_contrato.php"]', alvo: '#formMudanca .card',
      titulo: 'Como fica',
      texto: 'Digite o número final de caixas, os inclusos no plano, o extra por caixa e marque ou desmarque módulos. Embaixo de cada campo está o "hoje", para comparar.' },
    { url: '/mudanca_contrato.php', tela: 'Mudar o contrato', alvo: '#previaMudanca',
      titulo: 'Antes de confirmar',
      texto: 'A conta aparece aqui na hora: o que muda na mensalidade a partir da próxima fatura, e a pergunta sobre cobrar o mês corrente, proporcional, numa fatura avulsa. Reduzir caixas avisa quantas máquinas vão parar.' },
    { url: '/mudanca_contrato.php', tela: 'Mudar o contrato', alvo: '[data-tour="mud-modo"]',
      titulo: 'Como paga',
      texto: 'Trocar assinatura por pré-pago ou o contrário, mudar valor, ciclo, dia do vencimento, conta e forma. O que você gravar começa quando o período já pago terminar: ninguém paga duas vezes o mesmo mês. O histórico das trocas fica ao lado.' },
    { url: '/mudanca_contrato.php', tela: 'Mudar o contrato', alvo: '[data-tour="mud-conta"]',
      titulo: 'Por onde o dinheiro entra',
      texto: 'Troca a conta que gera o PIX da assinatura. As faturas em aberto vão junto: o código antigo é cancelado no provedor de antes e um novo é emitido no de agora, mesmo valor e vencimento. Entrando ou saindo do dinheiro em espécie, a forma vai junto. Nos outros casos, se a conta nova não faz a forma de alguma fatura na rua, a troca é recusada antes de mexer: use Como paga, que muda conta e forma juntas.' },

    /* ---------- Terminais ---------- */
    { url: '/terminais.php', tela: 'Terminais', alvo: '.topo-tela',
      titulo: 'As máquinas cadastradas',
      texto: 'Terminal é a máquina, e não o nome dela. Formatada, ela continua sendo a mesma: o painel reconhece pela impressão do equipamento (placa, disco e MAC, dois de três bastam).' },
    { url: '/terminais.php', tela: 'Terminais', alvo: '[data-tour="terminais-numeros"]',
      titulo: 'Quatro estados',
      texto: 'Trabalhando (deu sinal nos últimos 3 dias), sem sinal (calada até 30 dias, e ainda ocupa a vaga), vaga livre (30 dias ou mais, ou nunca abriu) e desativada. Clicar em cada número recorta a lista.' },
    { url: '/terminais.php', tela: 'Terminais', alvo: '[data-tour="terminais-filtro"]',
      titulo: 'Achar uma máquina',
      texto: 'Por cliente, por MAC ou nome do computador e por estado. "Limpar" tira a busca mas mantém o cliente escolhido.' },
    { url: '/terminais.php', tela: 'Terminais', alvo: '.grupo-terminais', quantos: 2,
      titulo: 'Agrupadas por cliente',
      texto: 'Cada bloco é um cliente, fechado por padrão; abrir mostra as máquinas dele com MAC, versão e último sinal. A coluna de ações só aparece no bloco em que alguma máquina tem o que fazer: liberar a vaga da calada, trocar de computador (a máquina trabalhando cede a vaga quando outra do mesmo cliente foi recusada por cota cheia, confirmando pelo nome do computador), reativar a desativada e apagar a vaga livre ou a desativada, com a confirmação dizendo de quem é a máquina antes de sumir.' },

    /* ---------- Monitoramento ---------- */
    { url: '/parque.php', tela: 'Monitoramento', alvo: '.topo-tela',
      titulo: 'O parque visto de cima',
      texto: 'Quem está no ar, quem parou e que versão cada um roda. É a tela de olhar de manhã: terminal parado é loja parada.' },
    { url: '/parque.php', tela: 'Monitoramento', alvo: '[data-tour="parque-numeros"]',
      titulo: 'O resumo do parque',
      texto: 'Vivos, sem sinal, quantas versões diferentes rodam e quantas caixas passam do contratado. A última é venda esperando ser feita: a loja está usando mais do que paga.' },
    { url: '/parque.php', tela: 'Monitoramento', alvo: '[data-tour="parque-lista"]',
      titulo: 'Máquinas por cliente',
      texto: 'Os mesmos blocos por cliente da tela de Terminais, com o último sinal de cada máquina. Os botões em cima recortam por situação sem sair da tela.' },
    { url: '/parque.php', tela: 'Monitoramento', alvo: '[data-tour="parque-versoes"]',
      titulo: 'Versões do ERP',
      texto: 'Quantas máquinas rodam cada versão, da mais nova para a mais velha. Quem ficou para trás só recebe a correção no próximo update.' },
    { url: '/parque.php', tela: 'Monitoramento', alvo: '[data-tour="parque-recusados"]',
      titulo: 'Pedidos recusados',
      texto: 'Cada vez que um caixa perguntou e levou não nos últimos 7 dias, com o motivo: licença vencida, acima do contratado, bloqueado. É a lista de quem está parado agora.' },

    /* ---------- Logs do cliente ---------- */
    { url: '/logs_cliente.php', tela: 'Logs do cliente', alvo: '.topo-tela',
      titulo: 'O log sem pedir favor ao cliente',
      texto: 'Você pede o arquivo daqui e o ERP entrega no próximo contato dele com o painel. O cliente não precisa achar pasta nenhuma.' },
    { url: '/logs_cliente.php', tela: 'Logs do cliente', alvo: '[data-tour="logs-pedir"]',
      titulo: 'Pedir o log',
      texto: 'Escolha a máquina (o defeito acontece num caixa, e é o log dele que interessa), o período e, se quiser, a pasta inteira. O pedido fica na fila até a máquina responder.' },
    { url: '/logs_cliente.php', tela: 'Logs do cliente', alvo: '[data-tour="logs-fila"]',
      titulo: 'Aguardando',
      texto: 'O que já foi pedido e ainda não chegou. Pode levar alguns minutos: depende de a máquina abrir o sistema.' },
    { url: '/logs_cliente.php', tela: 'Logs do cliente', alvo: '[data-tour="logs-chegou"]',
      titulo: 'O que já chegou',
      texto: 'Os arquivos recebidos, agrupados por cliente. "Ler" abre o log numa janela, com a lista de arquivos daquele pedido e o fim primeiro: o último passo do arquivo é onde o sistema parou.' },

    /* ---------- Cobranças ---------- */
    { url: '/cobrancas.php', tela: 'Cobranças', alvo: '.topo-tela',
      titulo: 'Onde o dinheiro é pedido',
      texto: 'Cada fatura, por quem foi emitida e em que pé está. A cor da pílula é a do provedor: é assim que você sabe em qual extrato procurar.' },
    { url: '/cobrancas.php', tela: 'Cobranças', alvo: '[data-tour="cob-filtro"]',
      titulo: 'Todas, em aberto, pagas',
      texto: 'O recorte da lista. Ao lado, a busca por cliente, descrição ou CNPJ, com ou sem pontos e barra. No canto de cima, "Assinaturas e pré-pagos" é só para olhar: quem paga como, quanto entra por mês e quanto já entrou.' },
    { url: '/cobrancas.php', tela: 'Cobranças', alvo: '[data-tour="cob-faixa"]',
      titulo: 'O contrato deste cliente',
      texto: 'Quando um cliente está escolhido, esta faixa diz como ele paga: assinatura ativa, aguardando o primeiro pagamento ou com mensalidade vencida, o valor e o dia, e quem gera o PIX. No pré-pago, até quando o sistema está liberado.' },
    { url: '/cobrancas.php', tela: 'Cobranças', alvo: '[data-tour="cob-nova"]', abrir: '[data-tour="cob-nova"]',
      titulo: 'Nova cobrança',
      texto: 'A cobrança do mês nasce sozinha pela assinatura; abra isto para algo fora dela: instalação, treinamento, backup. A cobrança avulsa não move a validade; um plano escolhido em "Cobrar por" vale os meses dele. Cliente, o que está sendo cobrado, valor, vencimento, quem gera o código (o dinheiro em espécie também: a cobrança fica a receber, sem código) e, ao lado, só as formas que essa conta cobra (o "Cobra por" de Formas de recebimento).' },
    { url: '/cobrancas.php', tela: 'Cobranças', alvo: '[data-tour="cob-lista"]',
      titulo: 'A lista',
      texto: 'Um bloco por cliente, fechado por padrão. O cabeçalho sempre diz como o cliente está: quantas faturas venceram e quanto, quantas estão a vencer e quanto, ou "em dia"; e se há fatura a emitir, se o cliente pediu prazo ou avisou que pagou. Aberto, cada fatura: por quem foi emitida, valor, vencimento e a situação. Pagou a mais, a diferença vira crédito na próxima.' },
    { url: '/cobrancas.php', tela: 'Cobranças', alvo: '[data-tour="cob-lista"] .acoes', abrir: '[data-tour="cob-lista"] details',
      titulo: 'O que se faz com cada fatura',
      texto: 'Sempre na mesma ordem: copiar o código para mandar ao cliente, abrir a cobrança no provedor, editar como o cliente paga, ir para a ficha do cliente e, por último, confirmar o pagamento à mão ou lançar o estorno. Conforme a situação aparecem antes do último: emitir o rascunho, reemitir com multa e juros, conferir no provedor. Reemitir cancela o código antigo no provedor antes de emitir o novo: o cliente nunca fica com dois PIX na mão.' },

    /* ---------- Assinaturas e pré-pagos ---------- */
    { url: '/assinaturas.php', tela: 'Assinaturas e pré-pagos', alvo: '.topo-tela',
      titulo: 'Só para olhar',
      texto: 'Quem paga todo ciclo, quem paga de uma vez, quanto entra por mês e quanto já entrou. Nada se muda aqui: mudar como um cliente paga é em "Mudar o contrato", na ficha dele.' },
    { url: '/assinaturas.php', tela: 'Assinaturas e pré-pagos', alvo: '[data-tour="assinaturas-numeros"]',
      titulo: 'A conta do recorrente',
      texto: 'Quanto entra por mês, quantas assinaturas estão ativas, quantas vencem na semana e a média por cliente. Ciclo longo entra dividido pelos meses.' },
    { url: '/assinaturas.php', tela: 'Assinaturas e pré-pagos', alvo: '[data-tour="assinaturas-dinheiro"]',
      titulo: 'O que entrou e o que está na rua',
      texto: 'Recebido nos últimos 12 meses (assinaturas e pré-pagos, pelo que foi pago), o que está em aberto e o que já passou da data.' },
    { url: '/assinaturas.php', tela: 'Assinaturas e pré-pagos', alvo: '[data-tour="assinaturas-lista"]',
      titulo: 'Quem é recorrente',
      texto: 'Cada assinatura com o valor por mês, o próximo vencimento e a conta que gera o PIX. Os ícones levam às cobranças do cliente e a "Mudar o contrato".' },
    { url: '/assinaturas.php', tela: 'Assinaturas e pré-pagos', alvo: '[data-tour="assinaturas-prepagos"]',
      titulo: 'Quem paga de uma vez',
      texto: 'Os pré-pagos: até quando o sistema está liberado, o último pagamento e quanto entrou de cada um em 12 meses.' },

    /* ---------- Licença em arquivo ---------- */
    { url: '/licenca_arquivo.php', tela: 'Licença em arquivo', alvo: '[data-tour="lic-cliente"]',
      titulo: 'Para o cliente sem internet',
      texto: 'Quando o caixa não alcança o painel, a licença vai em arquivo: WhatsApp, e-mail ou pen drive. Comece escolhendo de quem é, na lista ou pela busca.' },
    { url: '/licenca_arquivo.php', tela: 'Licença em arquivo', alvo: '[data-tour="lic-maquina"]',
      titulo: 'Qual máquina',
      texto: 'O arquivo é assinado para uma máquina só. É o mesmo par de chaves da licença pela internet, então o ERP valida do mesmo jeito.' },
    { url: '/licenca_arquivo.php', tela: 'Licença em arquivo', alvo: '[data-tour="lic-prazo"]',
      titulo: 'Prazo e arquivo',
      texto: 'O prazo nunca passa da validade da licença do cliente. Gerado, o arquivo baixa na hora.' },

    /* ---------- Chaves ---------- */
    { url: '/emissor_licenca.php', tela: 'Chaves', alvo: '[data-tour="chaves-estado"]',
      titulo: 'O par que assina tudo',
      texto: 'Toda licença sai assinada por este par. O número da chave vai dentro do ERP, e ele confere antes de aceitar. A auto-conferência assina uma amostra para provar que o caminho inteiro funciona.' },
    { url: '/emissor_licenca.php', tela: 'Chaves', alvo: '[data-tour="chaves-erp"]',
      titulo: 'O que colar no ERP',
      texto: 'A chave pública em Pascal, pronta para copiar. Depois de colar, recompile: sem ela dentro do executável o ERP não reconhece licença nenhuma.' },
    { url: '/emissor_licenca.php', tela: 'Chaves', alvo: '[data-tour="chaves-pem"]',
      titulo: 'A mesma chave em PEM',
      texto: 'O mesmo conteúdo no formato que qualquer ferramenta OpenSSL lê. Serve para conferir por fora. A privada fica cifrada aqui e não aparece em lugar nenhum.' },
    { url: '/emissor_licenca.php', tela: 'Chaves', alvo: '[data-tour="chaves-cota"]',
      titulo: 'Como funciona a cota',
      texto: 'As regras que o painel aplica sozinho: o que conta como máquina, quando uma vaga é devolvida (30 dias sem sinal) e por quanto tempo a licença vale offline.' },

    /* ---------- Atualização ---------- */
    { url: '/atualizacao.php', tela: 'Atualização', alvo: '.topo-tela',
      titulo: 'Onde o painel se atualiza',
      texto: 'Traz a versão nova deste painel sem FTP. Não mexe no ERP: ele tem o atualizador dele.' },
    { url: '/atualizacao.php', tela: 'Atualização', alvo: '[data-tour="atu-como"]',
      titulo: 'Como funciona',
      texto: 'Procurar, baixar e conferir não mudam nada. Só o botão de instalar mexe em arquivo, e cada arquivo trocado vira backup antes, fora da pasta publicada.' },
    { url: '/atualizacao.php', tela: 'Atualização', alvo: '[data-tour="atu-origem"]',
      titulo: 'De onde vem',
      texto: 'O endereço do manifesto: você publica o pacote num endereço seu e cola o link aqui. O painel só olha para lá.' },

    /* ---------- Limpeza de cadastros ---------- */
    { url: '/limpeza_cadastros.php', tela: 'Limpeza de cadastros', alvo: '.topo-tela',
      titulo: 'Cadastro que nunca deu sinal',
      texto: 'Empresa que se cadastrou sozinha e nunca abriu o ERP, e cliente que você encerrou. É lixo de teste na frente do que importa.' },
    { url: '/limpeza_cadastros.php', tela: 'Limpeza de cadastros', alvo: '#formLimpeza',
      titulo: 'Nada sai sem você marcar',
      texto: 'Você escolhe linha por linha e confirma na janela, que diz quantas empresas e quantos terminais vão junto. Não existe apagar tudo, e o que foi apagado fica no livro de auditoria.' },

    /* ---------- Módulos ---------- */
    { url: '/modulos.php', tela: 'Módulos', alvo: '.topo-tela',
      titulo: 'O que o cliente contrata além do básico',
      texto: 'Módulo é o extra que vai somado ao plano na mensalidade do cliente, e o que ele liga no ERP: cada módulo tem uma chave, e a licença leva a lista das chaves contratadas.' },
    { url: '/modulos.php', tela: 'Módulos', alvo: '[data-tour="mod-regra"]',
      titulo: 'Quem não tem módulo recebe',
      texto: '"Tudo" libera o ERP inteiro para quem não contratou módulo nenhum; "Só o básico" trava o que tem chave até contratar. É a regra da casa: quem vende por módulo quer a segunda.' },
    { url: '/modulos.php', tela: 'Módulos', alvo: '[data-tour="mod-catalogo"]',
      titulo: 'O catálogo',
      texto: 'Nome, chave, valor de tabela e quantos clientes têm. Mexer no preço aqui reajusta quem já tem, a partir da próxima fatura. "Novo módulo" abre a janela de cadastro.' },

    /* ---------- Planos ---------- */
    { url: '/listar_planos.php', tela: 'Planos', alvo: '.topo-tela',
      titulo: 'A tabela do pré-pago',
      texto: 'Cada plano é um período com preço: o cliente paga uma vez e a licença anda aqueles meses. Mudar o valor vale para as próximas cobranças; a que já saiu fica com o preço dela. Negócio fora da tabela vai pelo período personalizado, na Nova cobrança.' },

    /* ---------- Formas de recebimento ---------- */
    { url: '/formas_recebimento.php', tela: 'Formas de recebimento', alvo: '.topo-tela',
      titulo: 'Por onde o dinheiro chega',
      texto: 'Provedor com credencial (Asaas, Cora, Mercado Pago, PagBank, Pagar.me, Efí), PIX na sua chave ou dinheiro em espécie. Conta em homologação aparece num chip lá em cima, em toda tela.' },
    { url: '/formas_recebimento.php', tela: 'Formas de recebimento', alvo: '[data-tour="formas-prontas"]',
      titulo: 'Prontas para usar',
      texto: 'As formas ligadas, com o que cada uma sabe cobrar: PIX, boleto, cartão. Só o que está aqui aparece na hora de abrir uma cobrança. "Testar" emite um PIX de um real para provar a credencial.' },
    { url: '/formas_recebimento.php', tela: 'Formas de recebimento', alvo: '.grupo-formas', quantos: 3,
      titulo: 'Os três jeitos de receber',
      texto: 'Pelo provedor, que avisa o painel sozinho quando o dinheiro cai (webhook). No PIX da sua chave, que você confere no extrato e confirma à mão. E em espécie, que é só marcar como paga.' },

    /* ---------- Régua de cobrança ---------- */
    { url: '/regua.php', tela: 'Régua de cobrança', alvo: '[data-tour="regua-passos"]',
      titulo: 'Os passos',
      texto: 'Quantos dias antes e depois do vencimento o cliente é avisado, e com que texto. Cada passo liga e desliga. É o que insiste sozinho para você não precisar lembrar.' },
    { url: '/regua.php', tela: 'Régua de cobrança', alvo: '[data-tour="regua-fim"]',
      titulo: 'Ao chegar no último passo',
      texto: '"Só propor" deixa a suspensão na sua mão: aparece na lista de propostas. "Suspender sozinha" para a loja quando o último passo passa. Suspender é a última carta.' },
    { url: '/regua.php', tela: 'Régua de cobrança', alvo: '[data-tour="regua-atraso"]',
      titulo: 'Quando atrasa',
      texto: 'Multa e juros ao dia, em porcentagem. Eles entram na fatura numa reemissão (o código antigo é cancelado antes): no clique, ou todo dia sozinha, se você ligar.' },
    { url: '/regua.php', tela: 'Régua de cobrança', alvo: '[data-tour="regua-confianca"]',
      titulo: 'Liberação em confiança',
      texto: 'Quantos dias o cliente pode se liberar sozinho pelo ERP quando a licença venceu, e quantas vezes por ano. Só o token anda; a dívida e a fatura ficam onde estão. Zero desliga.' },
    { url: '/regua.php', tela: 'Régua de cobrança', alvo: '[data-tour="regua-propostas"]',
      titulo: 'Propostas',
      texto: 'Quem a régua sugere suspender. Você aceita ou não, um por um.' },
    { url: '/regua.php', tela: 'Régua de cobrança', alvo: '[data-tour="regua-suspensos"]',
      titulo: 'Suspensos',
      texto: 'Quem está suspenso por dívida agora. Pagou, volta sozinho pela ponte de pagamento.' },

    /* ---------- Meu perfil ---------- */
    { url: '/perfil.php', tela: 'Meu perfil', alvo: '.topo-tela',
      titulo: 'A sua conta',
      texto: 'O que o painel sabe sobre você. Daqui saem o nome que assina as ações no painel e o e-mail com que você entra.' },
    { url: '/perfil.php', tela: 'Meu perfil', alvo: '.perfil-identidade',
      titulo: 'Quem você é aqui',
      texto: 'Nome, papel e desde quando a conta existe. Administrador vê o painel inteiro; os outros papéis veem menos.' },
    { url: '/perfil.php', tela: 'Meu perfil', alvo: '.perfil-coluna section.card:nth-of-type(2)',
      titulo: 'Segurança',
      texto: 'Trocar a senha e derrubar os navegadores lembrados. Derrubar faz todos, inclusive este, pedirem a senha de novo.' },
    { url: '/perfil.php', tela: 'Meu perfil', alvo: '.perfil-atividade',
      titulo: 'Atividade recente',
      texto: 'As últimas ações feitas com esta conta. É por aqui que você percebe entrada que não foi sua.' },

    /* ---------- Minha empresa ---------- */
    { url: '/softhouse.php', tela: 'Minha empresa', alvo: '.topo-tela',
      titulo: 'A sua softhouse',
      texto: 'É deste cadastro que sai o seu nome na cobrança e no e-mail que chega ao cliente. Sem ele, o cliente recebe um PIX sem dono.' },
    { url: '/softhouse.php', tela: 'Minha empresa', alvo: '[data-tour="empresa-dados"]',
      titulo: 'O que o cliente vê',
      texto: 'Razão social, CNPJ, contato e endereço. É o que aparece no boleto, no PIX e no rodapé dos avisos da régua.' },
    { url: '/softhouse.php', tela: 'Minha empresa', alvo: '[data-tour="empresa-certificado"]',
      titulo: 'Certificado A1',
      texto: 'O certificado da sua empresa, guardado fora da pasta que o navegador alcança. Ele não viaja em atualização nenhuma. Fim do passeio: o "?" no rodapé da lateral traz você de volta a qualquer passo.' }
  ];

  /* Duas contas, as duas tiradas do proprio PASSOS para que acrescentar um
     passo nao exija mexer em mais nada: em que TELA o passeio esta (o trilho)
     e em que passo DAQUELA tela (a linha de cima do balao). */
  var TELAS = [], TELA_DO_PASSO = [], NA_TELA = [];
  (function () {
    var atual = null, inicio = 0, i;
    for (i = 0; i < PASSOS.length; i++) {
      if (PASSOS[i].tela !== atual) { atual = PASSOS[i].tela; TELAS.push(atual); inicio = i; }
      TELA_DO_PASSO.push(TELAS.length - 1);
      NA_TELA.push(i - inicio + 1);
    }
  })();

  var SEM_MOVIMENTO = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function ler() {
    try { return JSON.parse(localStorage.getItem(CHAVE) || 'null'); } catch (e) { return null; }
  }
  function gravar(estado) {
    try {
      if (estado) { localStorage.setItem(CHAVE, JSON.stringify(estado)); }
      else { localStorage.removeItem(CHAVE); }
    } catch (e) {}
  }
  function caminhoAtual() {
    var c = location.pathname;
    return (c === '/' || c === '') ? '/index.php' : c;
  }

  /* Os enderecos das telas que dependem de um cliente, guardados quando o
     passeio passa por elas: e o que faz o Voltar funcionar. */
  var estado = ler() || {};
  var hrefs = (estado && estado.hrefs) || {};

  function limpar() {
    ['tutorialBalao', 'tutorialRecorte'].forEach(function (id) {
      var e = document.getElementById(id);
      if (e) { e.remove(); }
    });
  }

  function navegar(destino) {
    if (SEM_MOVIMENTO) { location.href = destino; return; }
    document.documentElement.classList.add('tutorial-saindo');
    setTimeout(function () { location.href = destino; }, 160);
  }

  /* Primeiro passo da tela seguinte (rumo 1) ou ultimo da anterior (rumo -1). */
  function foraDaTela(passo, rumo) {
    var i = passo, t = PASSOS[passo].tela;
    while (i >= 0 && i < PASSOS.length && PASSOS[i].tela === t) { i += rumo; }
    return i;
  }

  function ir(passo, rumo) {
    rumo = rumo || 1;
    if (passo < 0 || passo >= PASSOS.length) { encerrar(); return; }
    var p = PASSOS[passo];
    // O RUMO VIAJA JUNTO: quem chega numa tela precisa saber para que lado
    // continuar pulando os passos que ali nao tem alvo.
    /* MESMA TELA, SEM RECARREGAR. Com varios passos por tela, navegar a cada
       clique fazia a pagina inteira piscar so para mover o destaque de um
       bloco para o de baixo. Recarrega so quando a tela muda de verdade. */
    if (p.url === caminhoAtual()) {
      gravar({ ativo: true, passo: passo, rumo: rumo, hrefs: hrefs });
      limpar();
      desenhar(passo, rumo);
      return;
    }
    var destino = p.url;
    // `via` e `derivar` moram no PRIMEIRO passo da tela; o Voltar chega pelo
    // ultimo, e tem de achar o mesmo endereco.
    var cabeca = PASSOS[foraDaTela(passo, -1) + 1];
    if (cabeca.via || cabeca.derivar) {
      /* TELA DE UM CLIENTE: o link esta na tela anterior (indo) ou no que foi
         guardado (voltando). Sem os dois, a tela inteira e pulada. */
      var link = cabeca.via ? document.querySelector(cabeca.via) : null;
      if (link && link.href) { destino = link.href; }
      else if (hrefs[p.tela]) { destino = hrefs[p.tela]; }
      else if (cabeca.derivar && hrefs[cabeca.derivar]) {
        // A ficha nao tem link para o contrato (ele mora na lista): o
        // endereco sai do da ficha, trocando so o nome da tela.
        var deUrl = null;
        for (var k = 0; k < PASSOS.length; k++) { if (PASSOS[k].tela === cabeca.derivar) { deUrl = PASSOS[k].url; break; } }
        destino = deUrl ? hrefs[cabeca.derivar].replace(deUrl, p.url) : hrefs[cabeca.derivar];
      }
      else { ir(foraDaTela(passo, rumo), rumo); return; }
      hrefs[p.tela] = destino;
    }
    gravar({ ativo: true, passo: passo, rumo: rumo, hrefs: hrefs });
    navegar(destino);
  }

  function encerrar() {
    gravar(null);
    hrefs = {};
    fecharAberto();
    limpar();
  }

  /* PASSO SEM ALVO NESTA INSTALACAO E PULADO. Metade dos passos aponta para
     bloco que so existe quando ha dado. A abertura de cada tela nunca e
     pulada: e ela que garante que a tela aparece no passeio mesmo vazia. */
  function existe(i) {
    if (NA_TELA[i] === 1) { return true; }
    var e = document.querySelector(PASSOS[i].alvo);
    // O que o passo ABRE ainda esta fechado na hora de julgar (o menu da
    // conta tem altura zero ate abrir): basta existir.
    if (PASSOS[i].abrir) { return !!e; }
    return !!(e && e.getBoundingClientRect().height > 0);
  }

  /* O proximo passo que da para desenhar, andando no rumo da viagem. So se
     pode julgar os passos DESTA tela -- os da proxima so se conhecem quando
     ela abrir, e por isso um passo de outra url sempre serve. */
  function proximoUtil(i, rumo) {
    while (i >= 0 && i < PASSOS.length) {
      if (PASSOS[i].url !== caminhoAtual() || existe(i)) { return i; }
      i += rumo;
    }
    return -1;
  }

  function contaNaTela(passo) {
    var t = TELA_DO_PASSO[passo], vistos = 0, meu = 0;
    for (var i = 0; i < PASSOS.length; i++) {
      if (TELA_DO_PASSO[i] !== t || !existe(i)) { continue; }
      vistos++;
      if (i === passo) { meu = vistos; }
    }
    return { meu: meu || 1, total: vistos || 1 };
  }

  /* O alvo do passo, com queda: o seletor proprio, depois o cabecalho da tela,
     depois o corpo. NUNCA devolve nada. */
  function acharAlvo(p) {
    var tentativas = [p.alvo, '.faixa-recorte', '.topo-tela', '.corpo > :first-child', '.corpo'];
    for (var i = 0; i < tentativas.length; i++) {
      if (!tentativas[i]) { continue; }
      var e = document.querySelector(tentativas[i]);
      if (e && e.getBoundingClientRect().height > 0) { return e; }
    }
    return document.body;
  }

  /* A LATERAL PRONTA PARA SER APRESENTADA: expandida (nao so icones), aberta
     no celular e com todos os grupos abertos. O que a pessoa tinha fica
     lembrado do mesmo jeito que a lateral lembra: nas mesmas chaves. */
  function prepararMenu() {
    if (document.documentElement.getAttribute('data-sidebar') === 'compacta') {
      document.documentElement.removeAttribute('data-sidebar');
      var bt = document.getElementById('btRecolher');
      if (bt) { bt.setAttribute('aria-pressed', 'false'); }
      try { localStorage.setItem('painel_sidebar_compacta', '0'); } catch (e) {}
    }
    var lateral = document.getElementById('lateral');
    if (lateral && window.innerWidth <= 992) {
      lateral.classList.add('aberta');
      document.body.classList.add('menu-aberto');
    }
    var lembrados = {};
    try { lembrados = JSON.parse(localStorage.getItem('painel_grupos') || '{}') || {}; } catch (e) {}
    document.querySelectorAll('.grupo-acc').forEach(function (g) {
      g.classList.add('aberto');
      var t = g.querySelector('.grupo-trigger');
      if (t) { t.setAttribute('aria-expanded', 'true'); }
      lembrados[g.getAttribute('data-grupo')] = true;
    });
    try { localStorage.setItem('painel_grupos', JSON.stringify(lembrados)); } catch (e) {}
  }

  /* O QUE UM PASSO ABRE, o seguinte fecha -- senao o menu da conta ficaria
     pendurado sobre a barra lateral no passo seguinte. */
  var abertoAgora = null;
  function fecharAberto() {
    if (!abertoAgora) { return; }
    var e = document.querySelector(abertoAgora);
    abertoAgora = null;
    if (!e) { return; }
    if (e.tagName === 'DETAILS') { e.open = false; return; }
    if (e.getAttribute('data-bs-toggle') === 'dropdown' && window.bootstrap && bootstrap.Dropdown) {
      bootstrap.Dropdown.getOrCreateInstance(e).hide();
    }
  }
  function abrir(sel) {
    if (abertoAgora === sel) { return; }
    fecharAberto();
    var e = document.querySelector(sel);
    if (!e) { return; }
    abertoAgora = sel;
    if (e.tagName === 'DETAILS') { e.open = true; return; }
    if (e.getAttribute('data-bs-toggle') === 'dropdown' && window.bootstrap && bootstrap.Dropdown) {
      // DEPOIS do clique que nos trouxe aqui: o Bootstrap fecha todo menu
      // aberto ao ver um clique fora dele, e o clique em "Proximo" e um.
      // Abrir no mesmo evento era abrir e fechar na mesma hora.
      setTimeout(function () { bootstrap.Dropdown.getOrCreateInstance(e).show(); }, 0);
    }
  }

  /* O RECORTE PODE ABRACAR MAIS DE UM BLOCO. `quantos` diz quantos irmaos do
     mesmo seletor entram, e o retangulo e a uniao deles. */
  function medir(p, alvo) {
    var r = alvo.getBoundingClientRect();
    var n = p.quantos || 1;
    if (n < 2 || document.querySelector(p.alvo) !== alvo) { return r; }
    var todos = document.querySelectorAll(p.alvo);
    var topo = r.top, base = r.bottom, esq = r.left, dir = r.right;
    for (var i = 0; i < todos.length && i < n; i++) {
      var q = todos[i].getBoundingClientRect();
      if (q.height <= 0) { continue; }
      topo = Math.min(topo, q.top);
      base = Math.max(base, q.bottom);
      esq = Math.min(esq, q.left);
      dir = Math.max(dir, q.right);
    }
    return { top: topo, bottom: base, left: esq, right: dir, width: dir - esq, height: base - topo };
  }

  function h(t) {
    return String(t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* MEDIR SO DEPOIS QUE A ROLAGEM PARA: duas leituras iguais de scrollY. */
  function assentar(cb) {
    if (SEM_MOVIMENTO) { setTimeout(cb, 0); return; }
    var anterior = null, voltas = 0;
    (function olha() {
      var agora = window.scrollY;
      if (agora === anterior || voltas > 40) { cb(); return; }
      anterior = agora;
      voltas++;
      setTimeout(olha, 60);
    })();
  }

  var desenhoAtual = 0;

  function desenhar(passo, rumo) {
    rumo = rumo || 1;
    var util = proximoUtil(passo, rumo);
    if (util === -1) { encerrar(); return; }
    if (util !== passo) { ir(util, rumo); return; }

    var meu = ++desenhoAtual;
    var p = PASSOS[passo];
    if (p.preparar === 'menu') { prepararMenu(); }
    if (p.abrir) { abrir(p.abrir); } else { fecharAberto(); }
    // O que acabou de abrir ainda esta se posicionando (o menu da conta e
    // colocado pelo Popper no quadro seguinte): mede so depois.
    setTimeout(function () {
    if (meu !== desenhoAtual) { return; }
    var alvo = acharAlvo(p);

    alvo.scrollIntoView({ block: 'center', behavior: SEM_MOVIMENTO ? 'auto' : 'smooth' });

    assentar(function () {
      if (meu !== desenhoAtual) { return; }
      var r = medir(p, alvo);
      var folga = 8;
      var topo = window.scrollY + r.top - folga;
      var esq = window.scrollX + r.left - folga;
      var larg = r.width + folga * 2;
      var alt = r.height + folga * 2;

      var recorte = document.createElement('div');
      recorte.className = 'tutorial-recorte';
      recorte.id = 'tutorialRecorte';
      if (!SEM_MOVIMENTO) {
        recorte.style.cssText = 'top:' + (topo - 14) + 'px;left:' + (esq - 14) + 'px;width:' + (larg + 28) + 'px;height:' + (alt + 28) + 'px';
      } else {
        recorte.style.cssText = 'top:' + topo + 'px;left:' + esq + 'px;width:' + larg + 'px;height:' + alt + 'px';
      }
      document.body.appendChild(recorte);
      if (!SEM_MOVIMENTO) {
        requestAnimationFrame(function () {
          recorte.style.top = topo + 'px'; recorte.style.left = esq + 'px';
          recorte.style.width = larg + 'px'; recorte.style.height = alt + 'px';
        });
      }

      var balao = document.createElement('div');
      balao.className = 'tutorial-balao';
      balao.id = 'tutorialBalao';
      balao.setAttribute('role', 'dialog');
      balao.setAttribute('aria-label', 'Tutorial: ' + p.titulo);

      var conta = contaNaTela(passo);
      var trilho = '';
      for (var i = 0; i < TELAS.length; i++) {
        var onde = i < TELA_DO_PASSO[passo] ? 'feito' : (i === TELA_DO_PASSO[passo] ? 'agora' : '');
        trilho += '<i class="' + onde + '" title="' + h(TELAS[i]) + '"></i>';
      }
      balao.innerHTML =
        '<div class="trilho-passos" aria-hidden="true">' + trilho + '</div>' +
        '<div class="passo">' + h(p.tela) + ' &middot; ' + conta.meu + ' de ' + conta.total +
          ' <span class="passo-tela">tela ' + (TELA_DO_PASSO[passo] + 1) + ' de ' + TELAS.length + '</span></div>' +
        '<h3>' + h(p.titulo) + '</h3>' +
        '<p>' + h(p.texto) + '</p>' +
        '<div class="acoes">' +
          '<button type="button" class="pular" data-acao="pular">Pular tutorial</button>' +
          (passo > 0 ? '<button type="button" class="btn btn-outline-secondary btn-sm" data-acao="voltar">Voltar</button>' : '') +
          '<button type="button" class="btn btn-primary btn-sm" data-acao="proximo">' +
            (passo === PASSOS.length - 1 ? 'Concluir' : 'Próximo') + '</button>' +
        '</div>';
      document.body.appendChild(balao);

      /* EMBAIXO DO ALVO SEMPRE QUE DER, E NUNCA FORA DA JANELA. Mede a parte
         VISIVEL do alvo; quando nem embaixo nem acima cabe, o balao encosta
         no rodape da janela. Posiciona mais de uma vez porque a largura final
         do balao (e portanto a altura) so assenta no quadro seguinte. */
      function posicionar() {
        if (meu !== desenhoAtual || !balao.isConnected) { return; }
        var r = medir(p, alvo);
        var b = balao.getBoundingClientRect();
        var vh = window.innerHeight;
        var visTopo = Math.min(Math.max(r.top, 12), vh - 12);
        var visBase = Math.max(Math.min(r.bottom, vh - 12), 12);
        var cabeAbaixo = visBase + 14 + b.height <= vh - 12;
        var cabeAcima = visTopo - 14 - b.height >= 12;
        var naJanela;
        if (cabeAbaixo) { naJanela = visBase + 14; }
        else if (cabeAcima) { naJanela = visTopo - b.height - 14; }
        else { naJanela = vh - b.height - 12; }

        var esqBalao = window.scrollX + r.left;
        var limite = window.scrollX + document.documentElement.clientWidth - b.width - 12;
        if (esqBalao > limite) { esqBalao = limite; }
        if (esqBalao < window.scrollX + 12) { esqBalao = window.scrollX + 12; }
        balao.style.top = (window.scrollY + naJanela) + 'px';
        balao.style.left = esqBalao + 'px';
        balao.classList.toggle('acima', !cabeAbaixo && cabeAcima);
      }
      posicionar();
      requestAnimationFrame(posicionar);
      setTimeout(posicionar, 400);

      balao.addEventListener('click', function (ev) {
        var bt = ev.target.closest('[data-acao]');
        if (!bt) { return; }
        var acao = bt.getAttribute('data-acao');
        if (acao === 'pular') { encerrar(); }
        else if (acao === 'voltar') { ir(passo - 1, -1); }
        else if (acao === 'proximo') {
          if (passo === PASSOS.length - 1) { encerrar(); } else { ir(passo + 1, 1); }
        }
      });

      var pr = balao.querySelector('[data-acao="proximo"]');
      if (pr) { pr.focus({ preventScroll: true }); }
    });
    }, p.abrir ? 320 : 0);
  }

  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape' && document.getElementById('tutorialBalao')) { encerrar(); }
  });

  var bt = document.getElementById('btTutorial');
  if (bt) { bt.addEventListener('click', function () { hrefs = {}; ir(0, 1); }); }

  if (estado && estado.ativo && PASSOS[estado.passo]) {
    if (PASSOS[estado.passo].url === caminhoAtual()) {
      desenhar(estado.passo, estado.rumo === -1 ? -1 : 1);
    } else {
      // Foi para outro lugar no meio do passeio: nao insiste. O "?" retoma.
      gravar(null);
    }
  }
})();
