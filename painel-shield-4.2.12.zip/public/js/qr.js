/**
 * Gerador de QR Code - 04/09/2026.
 *
 * Existe porque o PIX estatico e o unico provedor em que NAO HA NINGUEM do
 * outro lado para devolver a imagem: o painel monta o copia-e-cola sozinho
 * (Brcode.php) e precisa desenhar o QR sozinho tambem. Os gateways mandam a
 * imagem pronta e nao passam por aqui.
 *
 * Modo byte, correcao M, versoes 1 a 40, mascara escolhida por penalidade --
 * o basico da ISO 18004, sem kanji nem modo numerico, que o PIX nao usa.
 *
 * Uso: shieldQr.desenhar(canvas, 'texto', tamanhoEmPixels)
 */
(function (global) {
  'use strict';

  // ------------------------------------------------------------ GF(256) --
  var EXP = new Array(512), LOG = new Array(256);
  (function () {
    var x = 1;
    for (var i = 0; i < 255; i++) {
      EXP[i] = x; LOG[x] = i;
      x <<= 1;
      if (x & 0x100) { x ^= 0x11d; }
    }
    for (var j = 255; j < 512; j++) { EXP[j] = EXP[j - 255]; }
  }());
  function mul(a, b) { return (a === 0 || b === 0) ? 0 : EXP[LOG[a] + LOG[b]]; }

  function geradorRs(grau) {
    var g = [1];
    for (var i = 0; i < grau; i++) {
      var novo = new Array(g.length + 1).fill(0);
      for (var j = 0; j < g.length; j++) {
        novo[j] ^= g[j];
        novo[j + 1] ^= mul(g[j], EXP[i]);
      }
      g = novo;
    }
    return g;
  }

  function restoRs(dados, grau) {
    var g = geradorRs(grau);
    var resto = new Array(grau).fill(0);
    for (var i = 0; i < dados.length; i++) {
      var fator = dados[i] ^ resto.shift();
      resto.push(0);
      if (fator === 0) { continue; }
      for (var j = 0; j < grau; j++) {
        resto[j] ^= mul(g[j + 1], fator);
      }
    }
    return resto;
  }

  // -------------------------------------------------- tabelas (nivel M) --
  // [blocos de EC por versao] e [codewords de EC por bloco], versoes 1..40
  var EC_BLOCOS = [1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49];
  var EC_POR_BLOCO = [10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28];

  var ALINHAMENTO = [[], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50],
    [6, 30, 54], [6, 32, 58], [6, 34, 62], [6, 26, 46, 66], [6, 26, 48, 70], [6, 26, 50, 74], [6, 30, 54, 78], [6, 30, 56, 82], [6, 30, 58, 86], [6, 34, 62, 90],
    [6, 28, 50, 72, 94], [6, 26, 50, 74, 98], [6, 30, 54, 78, 102], [6, 28, 54, 80, 106], [6, 32, 58, 84, 110], [6, 30, 58, 86, 114], [6, 34, 62, 90, 118], [6, 26, 50, 74, 98, 122], [6, 30, 54, 78, 102, 126], [6, 26, 52, 78, 104, 130],
    [6, 30, 56, 82, 108, 134], [6, 34, 60, 86, 112, 138], [6, 30, 58, 86, 114, 142], [6, 34, 62, 90, 118, 146], [6, 30, 54, 78, 102, 126, 150], [6, 24, 50, 76, 102, 128, 154], [6, 28, 54, 80, 106, 132, 158], [6, 32, 58, 84, 110, 136, 162], [6, 26, 54, 82, 110, 138, 166], [6, 30, 58, 86, 114, 142, 170]];

  function totalCodewords(v) {
    // A conta fechada da ISO 18004 (mesma do qrcodegen): localizadores,
    // temporizacao, formato, versao e alinhamento -- descontando os padroes
    // de alinhamento que caem EM CIMA da temporizacao, que ja foi descontada.
    var total = (16 * v + 128) * v + 64;
    if (v >= 2) {
      var k = Math.floor(v / 7) + 2;
      total -= (25 * k - 10) * k - 55;
      if (v >= 7) { total -= 36; }
    }
    return Math.floor(total / 8);
  }

  // ----------------------------------------------------------- bits ----
  function Bits() { this.b = []; }
  Bits.prototype.poe = function (valor, n) {
    for (var i = n - 1; i >= 0; i--) { this.b.push((valor >>> i) & 1); }
  };

  function utf8(texto) {
    var s = unescape(encodeURIComponent(texto)), out = [];
    for (var i = 0; i < s.length; i++) { out.push(s.charCodeAt(i)); }
    return out;
  }

  function codificar(texto) {
    var bytes = utf8(texto);
    var versao = 0;
    for (var v = 1; v <= 40; v++) {
      var cap = totalCodewords(v) - EC_BLOCOS[v - 1] * EC_POR_BLOCO[v - 1];
      var cabecalho = 4 + (v < 10 ? 8 : 16);
      if (bytes.length * 8 + cabecalho <= cap * 8) { versao = v; break; }
    }
    if (!versao) { throw new Error('texto grande demais para um QR'); }

    var bits = new Bits();
    bits.poe(4, 4);
    bits.poe(bytes.length, versao < 10 ? 8 : 16);
    bytes.forEach(function (b) { bits.poe(b, 8); });

    var total = totalCodewords(versao);
    var blocos = EC_BLOCOS[versao - 1], ecPorBloco = EC_POR_BLOCO[versao - 1];
    var dadosCw = total - blocos * ecPorBloco;

    bits.poe(0, Math.min(4, dadosCw * 8 - bits.b.length));
    while (bits.b.length % 8) { bits.b.push(0); }
    var dados = [];
    for (var i = 0; i < bits.b.length; i += 8) {
      var c = 0;
      for (var j = 0; j < 8; j++) { c = (c << 1) | bits.b[i + j]; }
      dados.push(c);
    }
    for (var k = 0; dados.length < dadosCw; k++) { dados.push(k % 2 ? 0x11 : 0xec); }

    // Blocos: os primeiros (blocos - resto) sao curtos, o resto tem 1 a mais.
    var curtos = blocos - (dadosCw % blocos);
    var tamCurto = Math.floor(dadosCw / blocos);
    var partes = [], ecs = [], pos = 0;
    for (var b2 = 0; b2 < blocos; b2++) {
      var tam = tamCurto + (b2 < curtos ? 0 : 1);
      var pedaco = dados.slice(pos, pos + tam); pos += tam;
      partes.push(pedaco);
      ecs.push(restoRs(pedaco, ecPorBloco));
    }

    var saida = [];
    var maior = tamCurto + 1;
    for (var col = 0; col < maior; col++) {
      for (var bl = 0; bl < blocos; bl++) {
        if (col < partes[bl].length) { saida.push(partes[bl][col]); }
      }
    }
    for (var col2 = 0; col2 < ecPorBloco; col2++) {
      for (var bl2 = 0; bl2 < blocos; bl2++) { saida.push(ecs[bl2][col2]); }
    }
    return { versao: versao, codewords: saida };
  }

  // ----------------------------------------------------------- matriz --
  function Matriz(n) {
    this.n = n;
    this.m = []; this.fixo = [];
    for (var i = 0; i < n; i++) {
      this.m.push(new Array(n).fill(0));
      this.fixo.push(new Array(n).fill(false));
    }
  }
  Matriz.prototype.set = function (x, y, v) { this.m[y][x] = v ? 1 : 0; this.fixo[y][x] = true; };

  function localizador(mt, x0, y0) {
    for (var dy = -1; dy <= 7; dy++) {
      for (var dx = -1; dx <= 7; dx++) {
        var x = x0 + dx, y = y0 + dy;
        if (x < 0 || y < 0 || x >= mt.n || y >= mt.n) { continue; }
        var d = Math.max(Math.abs(dx - 3), Math.abs(dy - 3));
        mt.set(x, y, d !== 2 && d !== 4);
      }
    }
  }

  function alinhamento(mt, cx, cy) {
    for (var dy = -2; dy <= 2; dy++) {
      for (var dx = -2; dx <= 2; dx++) {
        mt.set(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
      }
    }
  }

  function bch(valor, poli, bitsPoli, deslocamento) {
    var r = valor << deslocamento;
    for (var i = bitsPoli + deslocamento - 1; i >= deslocamento; i--) {
      if ((r >>> i) & 1) { r ^= poli << (i - deslocamento); }
    }
    return (valor << deslocamento) | r;
  }

  function formato(mt, mascara) {
    // nivel M = 00, seguido da mascara; BCH(15,5) e xor 0x5412.
    var info = bch((0 << 3) | mascara, 0x537, 11, 10) ^ 0x5412;
    var n = mt.n;
    for (var i = 0; i < 15; i++) {
      var bit = (info >>> i) & 1;
      // ao redor do localizador de cima-esquerda
      if (i < 6) { mt.set(8, i, bit); }
      else if (i < 8) { mt.set(8, i + 1, bit); }
      else { mt.set(i === 8 ? 7 : 14 - i, 8, bit); }
      // os outros dois
      if (i < 8) { mt.set(n - 1 - i, 8, bit); }
      else { mt.set(8, n - 15 + i, bit); }
    }
    mt.set(8, n - 8, 1); // modulo escuro
  }

  function versaoInfo(mt, v) {
    if (v < 7) { return; }
    var info = bch(v, 0x1f25, 13, 12);
    var n = mt.n;
    for (var i = 0; i < 18; i++) {
      var bit = (info >>> i) & 1;
      var a = Math.floor(i / 3), b = n - 11 + (i % 3);
      mt.set(a, b, bit); mt.set(b, a, bit);
    }
  }

  function mascarar(mascara, x, y) {
    switch (mascara) {
      case 0: return (x + y) % 2 === 0;
      case 1: return y % 2 === 0;
      case 2: return x % 3 === 0;
      case 3: return (x + y) % 3 === 0;
      case 4: return (Math.floor(y / 2) + Math.floor(x / 3)) % 2 === 0;
      case 5: return (x * y) % 2 + (x * y) % 3 === 0;
      case 6: return ((x * y) % 2 + (x * y) % 3) % 2 === 0;
      default: return ((x + y) % 2 + (x * y) % 3) % 2 === 0;
    }
  }

  function penalidade(mt) {
    var n = mt.n, m = mt.m, p = 0, x, y, k, cor;
    for (y = 0; y < n; y++) {
      for (x = 0, k = 0, cor = -1; x < n; x++) {
        if (m[y][x] === cor) { k++; if (k === 5) { p += 3; } else if (k > 5) { p++; } }
        else { cor = m[y][x]; k = 1; }
      }
    }
    for (x = 0; x < n; x++) {
      for (y = 0, k = 0, cor = -1; y < n; y++) {
        if (m[y][x] === cor) { k++; if (k === 5) { p += 3; } else if (k > 5) { p++; } }
        else { cor = m[y][x]; k = 1; }
      }
    }
    for (y = 0; y < n - 1; y++) {
      for (x = 0; x < n - 1; x++) {
        var s = m[y][x] + m[y][x + 1] + m[y + 1][x] + m[y + 1][x + 1];
        if (s === 0 || s === 4) { p += 3; }
      }
    }
    var padrao1 = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0], padrao2 = [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1];
    function bate(linha, i, pat) {
      for (var t = 0; t < 11; t++) { if (linha[i + t] !== pat[t]) { return false; } }
      return true;
    }
    for (y = 0; y < n; y++) {
      var coluna = [];
      for (x = 0; x < n; x++) { coluna.push(m[x][y]); }
      for (x = 0; x <= n - 11; x++) {
        if (bate(m[y], x, padrao1) || bate(m[y], x, padrao2)) { p += 40; }
        if (bate(coluna, x, padrao1) || bate(coluna, x, padrao2)) { p += 40; }
      }
    }
    var escuros = 0;
    for (y = 0; y < n; y++) { for (x = 0; x < n; x++) { escuros += m[y][x]; } }
    var pct = escuros * 100 / (n * n);
    p += Math.floor(Math.abs(pct - 50) / 5) * 10;
    return p;
  }

  function montar(texto) {
    var cod = codificar(texto);
    var n = cod.versao * 4 + 17;
    var mt = new Matriz(n);

    localizador(mt, 0, 0); localizador(mt, n - 7, 0); localizador(mt, 0, n - 7);
    var al = ALINHAMENTO[cod.versao - 1];
    for (var i = 0; i < al.length; i++) {
      for (var j = 0; j < al.length; j++) {
        var cx = al[i], cy = al[j];
        var emLocalizador = (cx <= 8 && cy <= 8) || (cx >= n - 9 && cy <= 8) || (cx <= 8 && cy >= n - 9);
        if (!emLocalizador) { alinhamento(mt, cx, cy); }
      }
    }
    for (var t = 8; t < n - 8; t++) { mt.set(t, 6, t % 2 === 0); mt.set(6, t, t % 2 === 0); }
    formato(mt, 0);
    versaoInfo(mt, cod.versao);

    // Os bits de dado entram em zigue-zague, de baixo para cima, duas colunas
    // por vez, pulando a coluna 6 da temporizacao.
    var bits = [];
    cod.codewords.forEach(function (c) { for (var b = 7; b >= 0; b--) { bits.push((c >>> b) & 1); } });
    var idx = 0, subindo = true;
    var caminho = [];
    for (var x = n - 1; x > 0; x -= 2) {
      if (x === 6) { x--; }
      for (var passo = 0; passo < n; passo++) {
        var y = subindo ? n - 1 - passo : passo;
        for (var dx = 0; dx < 2; dx++) {
          var xx = x - dx;
          if (!mt.fixo[y][xx]) {
            mt.m[y][xx] = idx < bits.length ? bits[idx] : 0;
            caminho.push([xx, y]);
            idx++;
          }
        }
      }
      subindo = !subindo;
    }

    var melhor = null, melhorPen = Infinity, base = mt.m.map(function (l) { return l.slice(); });
    for (var mk = 0; mk < 8; mk++) {
      mt.m = base.map(function (l) { return l.slice(); });
      for (var c2 = 0; c2 < caminho.length; c2++) {
        var px = caminho[c2][0], py = caminho[c2][1];
        if (mascarar(mk, px, py)) { mt.m[py][px] ^= 1; }
      }
      formato(mt, mk);
      var pen = penalidade(mt);
      if (pen < melhorPen) { melhorPen = pen; melhor = mt.m.map(function (l) { return l.slice(); }); }
    }
    return { n: n, m: melhor };
  }

  function desenhar(canvas, texto, tamanho) {
    var q = montar(texto);
    var margem = 4, celulas = q.n + margem * 2;
    var px = Math.max(1, Math.floor((tamanho || 256) / celulas));
    canvas.width = canvas.height = px * celulas;
    var g = canvas.getContext('2d');
    g.fillStyle = '#fff';
    g.fillRect(0, 0, canvas.width, canvas.height);
    g.fillStyle = '#000';
    for (var y = 0; y < q.n; y++) {
      for (var x = 0; x < q.n; x++) {
        if (q.m[y][x]) { g.fillRect((x + margem) * px, (y + margem) * px, px, px); }
      }
    }
    return q;
  }

  global.shieldQr = { montar: montar, desenhar: desenhar };
}(window));
