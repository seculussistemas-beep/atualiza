/* A constelacao do fundo das telas de entrada -- 08/09/2026.
 *
 * Uma grade de pontos presa por molas: o cursor afasta os pontos por onde
 * passa e eles voltam sozinhos. Perto do cursor os pontos ganham a cor da
 * marca; longe dele, ficam quietos e apagados. E o unico movimento da tela.
 *
 * SIMPLES DE PROPOSITO. A referencia trazia coordenadas em hexadecimal, aneis
 * de radar e titulo em mix-blend: bonito numa demo, grotesco numa tela em que a
 * pessoa quer digitar a senha. Aqui ficaram so a grade, a mola e a cor.
 *
 * Em canvas puro, sem React: o painel e PHP e nao tem build de front. A cor
 * vem de --marca-clara, que o casco ja escreve a partir do cadastro do membro
 * -- quem escolheu vermelho tem constelacao vermelha.
 *
 * Quem pediu menos movimento no sistema ve um quadro parado: a grade e
 * desenhada uma vez e o cursor nao a mexe.
 */
(function () {
  'use strict';

  var canvas = document.querySelector('canvas.constelacao');
  if (!canvas) { return; }
  var ctx = canvas.getContext('2d');
  if (!ctx) { return; }

  var reduzido = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function corMarca() {
    var v = getComputedStyle(document.documentElement).getPropertyValue('--marca-clara').trim();
    var m = /^#([0-9a-f]{6})$/i.exec(v);
    if (!m) { return '2, 200, 240'; }
    var n = parseInt(m[1], 16);
    return ((n >> 16) & 255) + ', ' + ((n >> 8) & 255) + ', ' + (n & 255);
  }

  var largura = 0, altura = 0, pontos = [], acento = corMarca();

  /* DOIS FOCOS, e nao um.
   *
   * `mouse` e o cursor. `passeio` e um foco que atravessa o fundo sozinho, de
   * um lado para o outro, com exatamente o mesmo efeito -- porque a tela nao
   * pode depender de alguem passar o mouse para ficar viva, e a maioria de
   * quem abre o login nao passa: cai no campo de e-mail e digita.
   *
   * O passeio e mais fraco de proposito (`forca` e `brilho` menores): quando a
   * pessoa move o cursor, quem tem de chamar a atencao e ela, e nao o fundo.
   */
  var mouse = { x: -9999, y: -9999, raio: 170, forca: 900, brilho: 0.9 };
  var passeio = { x: -9999, y: -9999, raio: 200, forca: 700, brilho: 0.78 };
  var FOCOS = [mouse, passeio];

  var ESPACO = 52, MOLA = 16, ATRITO = 0.84, LIGA = 66, LIGA2 = LIGA * LIGA;

  /* O caminho do passeio: vai e volta na horizontal e sobe e desce na
     vertical, em periodos que nao sao multiplos um do outro (19s e 31s). Se
     fossem, o caminho fecharia e a mesma volta se repetiria a olho nu. Fica
     dentro das bordas para o halo nao morrer metade fora da tela. */
  var relogio = 0;
  function andarPasseio(dt) {
    relogio += dt;
    var fx = (Math.sin(relogio * (6.2832 / 19)) + 1) / 2;
    var fy = (Math.sin(relogio * (6.2832 / 31)) + 1) / 2;
    passeio.x = largura * (0.08 + fx * 0.84);
    passeio.y = altura * (0.18 + fy * 0.62);
  }

  function montar() {
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    largura = window.innerWidth; altura = window.innerHeight;
    canvas.width = largura * dpr; canvas.height = altura * dpr;
    canvas.style.width = largura + 'px'; canvas.style.height = altura + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    pontos = [];
    formado = false;
    var cols = Math.ceil(largura / ESPACO) + 1, lins = Math.ceil(altura / ESPACO) + 1;
    for (var i = 0; i < cols; i++) {
      for (var j = 0; j < lins; j++) {
        var x = i * ESPACO, y = j * ESPACO;
        // `gx/gy` e a CASA do ponto na grade; `bx/by` e para onde a mola
        // puxa agora. Nos dois sao iguais -- so o easter egg os separa.
        pontos.push({ x: x, y: y, bx: x, by: y, gx: x, gy: y, marcado: false,
                      vx: 0, vy: 0, r: 1.1 + Math.random() * 0.9, f: Math.random() * 6.28 });
      }
    }
  }

  /* O EASTER EGG -- 09/09/2026.
   *
   * Teclar a palavra na tela de entrada e os pontos da constelacao saem da
   * grade e se juntam para escrever a marca. Nada de camada nova: o desenho e
   * feito com os MESMOS pontos, mudando so para onde a mola de cada um puxa
   * (`bx/by`). Por isso o cursor continua empurrando as letras enquanto elas
   * estao ali -- que e a graca da coisa.
   *
   * A palavra nao aparece sozinha para ninguem, e isso e de proposito: quem
   * abre esta tela pode ser o lojista do cliente do membro, e a marca que ele
   * tem de ver e a de quem lhe vendeu o sistema (ver o cabecalho de
   * css/entrada.css). Assinatura escondida, e nao letreiro.
   */
  var LEMA = 'lojadev';
  var digitado = '';
  var formado = false, soltarEm = 0;

  /* Onde os pontos precisam ficar para a palavra aparecer: a palavra e
     desenhada num canvas de lado e depois lida de volta como uma grade de
     pixels acesos. Sai um texto do tamanho da tela sem ninguem medir letra
     nenhuma na mao. */
  /* ONDE A PALAVRA CABE. O cartao do formulario e opaco e a constelacao mora
     atras dele: palavra desenhada ali simplesmente nao aparece, e foi o que
     aconteceu na primeira tentativa -- metade de "LOJADEV" ficava escondida.
     Sobra a faixa a esquerda do cartao. Ela e mais estreita, e isso melhora o
     desenho: o mesmo numero de pontos numa palavra menor da uma letra bem mais
     cheia. Sem cartao (ou com ele ocupando quase tudo), vale a tela inteira. */
  function areaLivre() {
    var toda = { x0: 0, x1: largura, y0: 0, y1: altura };
    var pecas = [];
    ['.folha .marca', '.folha .form'].forEach(function (sel) {
      var e = document.querySelector(sel);
      if (!e) { return; }
      var r = e.getBoundingClientRect();
      if (r.height > 0) { pecas.push(r); }
    });
    if (!pecas.length) { return toda; }

    var topo = Infinity, base = -Infinity;
    for (var i = 0; i < pecas.length; i++) {
      topo = Math.min(topo, pecas[i].top);
      base = Math.max(base, pecas[i].bottom);
    }
    var acima = topo, abaixo = altura - base;

    // A faixa vazia mais alta, desde que caiba a palavra com folga. Ali ela sai
    // grande e limpa, atravessando a tela inteira.
    if (acima >= 120 && acima >= abaixo) { return { x0: 0, x1: largura, y0: 0, y1: topo }; }
    if (abaixo >= 120) { return { x0: 0, x1: largura, y0: base, y1: altura }; }

    // Tela apertada, sem faixa: sobra o lado do cartao, que e onde ainda se ve
    // o fundo. Atras do cartao nao adianta desenhar -- ele e opaco.
    var cartao = document.querySelector('.folha .form');
    if (cartao) {
      var rc = cartao.getBoundingClientRect();
      if (rc.width > 0 && rc.left > largura * 0.45) { return { x0: 0, x1: rc.left, y0: 0, y1: altura }; }
    }
    return toda;
  }

  function alvosDoTexto(texto) {
    var caixa = areaLivre();
    var cabe = (caixa.x1 - caixa.x0) * 0.84;
    var alto = (caixa.y1 - caixa.y0) * 0.6;
    var fora = document.createElement('canvas');
    fora.width = Math.max(1, Math.round(largura));
    fora.height = Math.max(1, Math.round(altura));
    var fx = fora.getContext('2d');
    if (!fx) { return []; }
    var corpo = Math.min(cabe * 0.25, alto);
    for (var tenta = 0; tenta < 24; tenta++) {
      fx.font = '800 ' + Math.round(corpo) + 'px Inter, system-ui, sans-serif';
      if (fx.measureText(texto).width <= cabe) { break; }
      corpo *= 0.92;
    }
    fx.fillStyle = '#fff';
    fx.textAlign = 'center';
    fx.textBaseline = 'middle';
    fx.fillText(texto, (caixa.x0 + caixa.x1) / 2, (caixa.y0 + caixa.y1) / 2);

    var dados = fx.getImageData(0, 0, fora.width, fora.height).data;
    var passo = 7, achados = [];
    for (var y = 0; y < fora.height; y += passo) {
      for (var x = 0; x < fora.width; x += passo) {
        if (dados[(y * fora.width + x) * 4 + 3] > 128) { achados.push({ x: x, y: y }); }
      }
    }
    return achados;
  }

  function porLugar(a, b) { return (a.x - b.x) || (a.y - b.y); }

  function formar() {
    /* A grade pode ter sido montada com OUTRO tamanho de janela -- o navegador
       manda `resize` ate com a aba escondida, e ai `largura`/`altura` ficam de
       um tamanho e a tela de outro. Como a area livre e a palavra sao medidas
       nesses dois valores, a palavra saia fora do canvas e os pontos iam todos
       para uma tira na borda. Remontar antes deixa grade, canvas e conta
       falando do mesmo tamanho. */
    if (largura !== window.innerWidth || altura !== window.innerHeight) { montar(); }
    if (pontos.length < 4 || largura < 200 || altura < 200) { return; }
    var alvos = alvosDoTexto(LEMA.toUpperCase());
    if (!alvos.length) { return; }

    // Mais lugares do que pontos: pega espalhado, e nao os primeiros -- senao
    // so a metade de cima da palavra ganharia ponto.
    if (alvos.length > pontos.length) {
      var salto = alvos.length / pontos.length, escolhidos = [];
      for (var k = 0; k < pontos.length; k++) { escolhidos.push(alvos[Math.floor(k * salto)]); }
      alvos = escolhidos;
    }

    // Emparelhado por posicao: assim o ponto vai para o lugar mais proximo do
    // que ja ocupa, e a nuvem se fecha sem os caminhos se cruzarem.
    var ordem = pontos.slice().sort(porLugar);
    alvos.sort(porLugar);
    for (var i = 0; i < ordem.length; i++) {
      var q = ordem[i];
      q.marcado = i < alvos.length;
      q.bx = q.marcado ? alvos[i].x : q.gx;
      q.by = q.marcado ? alvos[i].y : q.gy;
      if (reduzido) { q.x = q.bx; q.y = q.by; }
    }
    formado = true;
    soltarEm = (window.performance ? performance.now() : Date.now()) + 6500;
  }

  function soltar() {
    for (var i = 0; i < pontos.length; i++) {
      var q = pontos[i];
      q.bx = q.gx;
      q.by = q.gy;
      q.marcado = false;
      if (reduzido) { q.x = q.gx; q.y = q.gy; }
    }
    formado = false;
  }

  /* O gatilho e o teclado, e ele NAO ENCOSTA NO CAMPO DE SENHA. Guardar tecla
     digitada em campo de senha, nem para brincadeira: o buffer zera assim que
     o foco esta nele. O que fica na memoria sao as ultimas sete letras, e nada
     sai daqui. */
  window.addEventListener('keydown', function (e) {
    var alvo = e.target;
    if (alvo && alvo.tagName === 'INPUT' && alvo.type === 'password') { digitado = ''; return; }
    if (e.ctrlKey || e.metaKey || e.altKey || e.key.length !== 1) { return; }
    digitado = (digitado + e.key.toLowerCase()).slice(-LEMA.length);
    if (digitado !== LEMA) { return; }
    digitado = '';
    formar();
    if (reduzido) {
      quadro(0);
      setTimeout(function () { soltar(); quadro(0); }, 6500);
    }
  });

  function quadro(dt) {
    ctx.clearRect(0, 0, largura, altura);
    var i, j, p, q;
    andarPasseio(dt);
    if (formado && (window.performance ? performance.now() : Date.now()) > soltarEm) { soltar(); }

    for (i = 0; i < pontos.length; i++) {
      p = pontos[i];
      p.f += dt * 2;
      for (j = 0; j < FOCOS.length; j++) {
        var f = FOCOS[j];
        var dx = f.x - p.x, dy = f.y - p.y, d = Math.sqrt(dx * dx + dy * dy);
        if (d < f.raio && d > 0) {
          var forca = (1 - d / f.raio) * f.forca;
          p.vx -= (dx / d) * forca * dt;
          p.vy -= (dy / d) * forca * dt;
        }
      }
      p.vx += (p.bx - p.x) * MOLA * dt;
      p.vy += (p.by - p.y) * MOLA * dt;
      p.vx *= ATRITO; p.vy *= ATRITO;
      p.x += p.vx * dt * 60; p.y += p.vy * dt * 60;
    }

    ctx.lineWidth = 0.7;
    for (i = 0; i < pontos.length; i++) {
      p = pontos[i];
      for (j = i + 1; j < pontos.length; j++) {
        q = pontos[j];
        var ex = p.x - q.x, ey = p.y - q.y, d2 = ex * ex + ey * ey;
        if (d2 < LIGA2) {
          ctx.strokeStyle = 'rgba(255, 255, 255, ' + ((1 - Math.sqrt(d2) / LIGA) * 0.10).toFixed(3) + ')';
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke();
        }
      }
    }

    for (i = 0; i < pontos.length; i++) {
      p = pontos[i];
      // Vale o foco MAIS PERTO, medido em fracao do raio dele: assim o
      // cursor, que tem raio menor, ainda ganha do passeio quando os dois
      // alcancam o mesmo ponto.
      var perto = false, brilho = 0;
      for (j = 0; j < FOCOS.length; j++) {
        var fc = FOCOS[j];
        var ax = fc.x - p.x, ay = fc.y - p.y;
        var frac = Math.sqrt(ax * ax + ay * ay) / fc.raio;
        if (frac < 1 && (!perto || fc.brilho > brilho)) { perto = true; brilho = fc.brilho; }
      }
      /* Com a palavra formada, ela acende na cor da marca e o resto da grade
         apaga -- sem isso o desenho se perde no meio dos outros pontos. */
      if (formado) {
        perto = p.marcado;
        brilho = 0.95;
      }
      var alfa = perto ? brilho : (0.22 + Math.sin(p.f) * 0.08) * (formado ? 0.28 : 1);
      ctx.fillStyle = perto ? 'rgba(' + acento + ', ' + alfa.toFixed(3) + ')' : 'rgba(255, 255, 255, ' + alfa.toFixed(3) + ')';
      ctx.beginPath();
      ctx.arc(p.x, p.y, perto ? p.r * 2 : p.r, 0, 6.2832);
      ctx.fill();
    }
  }

  montar();
  window.addEventListener('resize', montar);

  if (reduzido) {
    // Quem pediu menos movimento ve um quadro parado -- e o passeio, que e
    // movimento pelo movimento, nem comeca. O halo dele fica no lugar em que
    // o caminho comeca, que e o canto de cima a esquerda.
    andarPasseio(0);
    quadro(0);
    return;
  }

  window.addEventListener('mousemove', function (e) { mouse.x = e.clientX; mouse.y = e.clientY; });
  window.addEventListener('mouseleave', function () { mouse.x = -9999; mouse.y = -9999; });

  var ultimo = performance.now(), rodando = true;
  document.addEventListener('visibilitychange', function () {
    rodando = !document.hidden;
    if (rodando) { ultimo = performance.now(); requestAnimationFrame(laco); }
  });
  function laco(agora) {
    if (!rodando) { return; }
    var dt = Math.min((agora - ultimo) / 1000, 0.05);
    ultimo = agora;
    quadro(dt);
    requestAnimationFrame(laco);
  }
  requestAnimationFrame(laco);
})();
