<?php

declare(strict_types=1);

require_once __DIR__ . '/../router/dispatch.php';
shield_dispatch_request();
