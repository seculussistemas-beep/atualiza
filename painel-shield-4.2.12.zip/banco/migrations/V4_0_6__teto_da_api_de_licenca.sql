-- Migracao para a versao 4.0.6: o teto da API de licenca
-- Data: 09/09/2026
-- Autor: lojadev
--
-- BAIXO-3 da auditoria. `public/api/licenca.php` e publico, se identifica so
-- pelo CNPJ e AUTO-CADASTRA quem nao conhece: varrer CNPJs validos enche a base
-- de empresas fantasma e revela, pela resposta, quais deles sao clientes.
--
-- NAO HA TABELA NOVA, e isso e o ponto. `terminal_batida` ja grava uma linha
-- por chamada -- e o caminho que o ERP percorre a cada abertura de caixa, em
-- toda loja. Contar de uma tabela propria dobraria a escrita justamente ali.
-- O que falta e so o IP e por onde procurar.
--
-- O IP ACEITA NULO porque a coluna nasce depois das linhas. Batida antiga nao
-- tem IP e nao vai ter; a contagem por IP simplesmente nao a enxerga, o que e o
-- lado certo de errar.
--
-- 45 CARACTERES: e o tamanho de um IPv6 com zona ("fe80::1%eth0"), o mesmo
-- usado em login_tentativa.ip (V4_0_2) e em auditoria.ip. Cortar em 15 pensando
-- em IPv4 e o erro classico, e ele so aparece quando a hospedagem vira IPv6.

ALTER TABLE `terminal_batida`
    ADD COLUMN `ip` VARCHAR(45) NULL AFTER `cnpj`;

COMMIT;

-- OS DOIS INDICES SAO O RECURSO INTEIRO. Sem eles a contagem varre a tabela a
-- cada abertura de caixa do parque todo, e o teto -- que existe para proteger o
-- painel -- seria o que o derruba.
--
-- Repare que a chave de tempo entra nos dois: as consultas sao sempre
-- "<chave> nos ultimos N minutos", nunca "<chave> na historia".

ALTER TABLE `terminal_batida`
    ADD INDEX `ix_batida_teto_cnpj` (`cnpj`, `batido_em`),
    ADD INDEX `ix_batida_teto_ip` (`ip`, `batido_em`);

COMMIT;
