-- Migracao para a versao 3.0.3: a ponte pagamento -> licenca, e a regua
-- Data: 25/08/2026
-- Autor: lojadev
--
-- E isto que o membro esta ganhando: o pagamento entra e a licenca do cliente
-- se estende sozinha. E e aqui que um erro custa caro nos dois sentidos.
--
-- validade_movimento e a IDEMPOTENCIA e o RASTRO no mesmo lugar. A unicidade
-- por cobranca e o que impede o mesmo pagamento de estender dois ciclos --
-- webhook chega, conciliacao chega logo depois, e sem esta restricao o cliente
-- ganha um mes de presente a cada vez.
--
-- A COLUNA fk_cobranca ACEITA NULO porque nem todo movimento vem de cobranca:
-- o membro tambem ajusta validade a mao, e esse ajuste precisa deixar rastro
-- igual. Nulo nao conflita com nulo em indice unico do MySQL, entao varios
-- movimentos manuais convivem -- e e isso que se quer.

CREATE TABLE IF NOT EXISTS validade_movimento (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    fk_empresa INT NOT NULL,
    fk_cobranca INT NULL,
    de DATE NULL,
    para DATE NULL,
    meses INT NOT NULL DEFAULT 0,
    motivo VARCHAR(150) NULL,
    ator VARCHAR(80) NULL,
    quando DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_movimento_cobranca (fk_cobranca),
    KEY ix_movimento_empresa (fk_empresa, quando)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;

-- A regua. Cada passo e "tantos dias em relacao ao vencimento, faca isto".
-- Dia NEGATIVO e antes do vencimento -- o lembrete que evita o atraso.
--
-- ELA E CONFIGURAVEL DESDE O PRIMEIRO DIA, e nao depois: cobranca automatica
-- sem regua e corte automatico, e corte automatico sem carencia transforma
-- atraso de pagamento em loja parada.
CREATE TABLE IF NOT EXISTS regua_passo (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    dias INT NOT NULL,
    acao VARCHAR(20) NOT NULL,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    texto VARCHAR(255) NULL,
    UNIQUE KEY uk_regua_passo (dias, acao)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;

-- O padrao de fabrica. Ele importa mais do que a opcao existir: e o que vale
-- em toda instalacao que ninguem configurou -- ou seja, quase todas.
--
-- Repare no espacamento: lembra ANTES, avisa no dia, insiste duas vezes, e so
-- entao propoe suspender -- 15 dias depois do vencimento. Quem paga no dia 20
-- porque o cliente dele paga no dia 20 nao pode ter a loja parada no dia 3.
INSERT INTO regua_passo (dias, acao, ativo, texto) VALUES
    (-3, 'lembrete',  1, 'Sua mensalidade vence em breve.'),
    (0,  'aviso',     1, 'Sua mensalidade vence hoje.'),
    (3,  'insistir',  1, 'Sua mensalidade esta em atraso.'),
    (7,  'insistir',  1, 'Sua mensalidade continua em aberto.'),
    (15, 'suspender', 1, 'Aviso final antes da suspensao.')
ON DUPLICATE KEY UPDATE dias = dias;

COMMIT;

-- Suspensao. O bloqueado continua sendo o bloqueio MANUAL do membro; estas
-- duas colunas dizem que quem suspendeu foi a regua, e por que.
--
-- Sem separar os dois, tirar uma suspensao automatica apagaria um bloqueio que
-- o membro tinha posto a mao por outro motivo -- e ele so descobriria quando o
-- cliente voltasse a emitir nota.
ALTER TABLE empresa ADD COLUMN suspenso_em DATETIME NULL;

COMMIT;

ALTER TABLE empresa ADD COLUMN suspenso_motivo VARCHAR(150) NULL;

COMMIT;
