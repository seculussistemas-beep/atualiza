-- Migração para versão 2.1.2: emissor da licença assinada
-- Data: 23/08/2026
-- Autor: lojadev
--
-- Guarda o par de chaves que assina as licenças do ERP. A privada entra
-- cifrada pelo cofre do painel (shield_encrypt_secret), o mesmo que já guarda
-- a senha do certificado A1; a pública é exibida na tela para ser colada no
-- fonte do ERP antes de compilar.
--
-- Par DEDICADO, e não o A1: o A1 vence todo ano, e o vencimento dele
-- invalidaria todas as licenças emitidas e obrigaria a recompilar o ERP
-- anualmente. Além disso nem todo membro compra A1.
--
-- kid é o número da chave. Trocar o par significa gravar uma linha nova com
-- número novo e desativar a anterior — licença emitida para um número que o
-- build do ERP não carrega é RECUSADA, em vez de aceita por engano. É isso que
-- torna a troca de chave possível sem derrubar quem ainda não atualizou.
--
-- Atenção: MySQL não suporta IF NOT EXISTS para colunas. Execute e ignore
-- erros de duplicidade (1060/1061).

CREATE TABLE IF NOT EXISTS licenca_emissor (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    kid VARCHAR(20) NOT NULL,
    chave_publica TEXT NOT NULL,
    chave_privada TEXT NOT NULL,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_licenca_emissor_kid (kid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
