-- Migração para versão 2.1.1: identidade do terminal e último acesso
-- Data: 23/08/2026
-- Autor: lojadev
--
-- Por que: o terminal era identificado por MAC + NOME_COMPUTADOR, e o nome muda
-- quando o cliente formata a máquina — o ERP então recusava o terminal até que
-- alguém apagasse a linha antiga na mão. O ERP passou a casar por impressão de
-- hardware; estas colunas são onde ela mora.
--
-- ULTIMO_ACESSO é gravado com o NOW() do MySQL, nunca com o relógio do cliente:
-- é ele que diz quais terminais ainda existem de verdade, e é a base da
-- reciclagem automática de vaga.
--
-- As três são NULL: instalação que ainda não recebeu o ERP novo continua
-- funcionando igual, e o ERP detecta a ausência das colunas e grava sem elas.
--
-- Atenção: MySQL não suporta IF NOT EXISTS para colunas. Execute e ignore erros
-- de duplicidade (1060).

ALTER TABLE terminais
  ADD COLUMN FINGERPRINT VARCHAR(64) NULL DEFAULT NULL;

ALTER TABLE terminais
  ADD COLUMN ULTIMO_ACESSO DATETIME NULL DEFAULT NULL;

ALTER TABLE terminais
  ADD COLUMN VERSAO_EXE VARCHAR(20) NULL DEFAULT NULL;

-- Consulta do painel: "quais terminais desta empresa foram vistos e quando".
ALTER TABLE terminais
  ADD INDEX idx_terminais_empresa_acesso (FK_EMPRESA, ULTIMO_ACESSO);
