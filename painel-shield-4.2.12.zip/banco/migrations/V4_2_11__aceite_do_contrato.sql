-- O aceite do contrato na area do cliente -- 01/10/2026.
--
-- Uma linha por aceite, e nunca UPDATE: quando o texto muda e o cliente aceita
-- de novo, o aceite antigo fica, e e ele que prova o que valia antes.
--
-- O TEXTO INTEIRO VAI JUNTO, e nao so o hash. O modelo, o preco e o endereco
-- mudam depois; o PDF do que foi aceito tem de sair igual ao que o cliente leu.
-- O hash (SHA-256 do texto) e o que vai impresso no PDF para conferencia.
--
-- Sem DEFAULT CURRENT_TIMESTAMP em DATETIME e sem JSON: roda no MySQL 5.6
-- (4.1.44). Quem grava o aceito_em e o INSERT, com NOW().
CREATE TABLE IF NOT EXISTS `contrato_aceite` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `fk_empresa` INT(11) NOT NULL,
  `hash` CHAR(64) NOT NULL,
  `texto` LONGTEXT NOT NULL,
  `aceito_em` DATETIME NOT NULL,
  `ip` VARCHAR(45) NOT NULL DEFAULT '',
  `navegador` VARCHAR(255) NOT NULL DEFAULT '',
  `email` VARCHAR(150) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_contrato_aceite_empresa` (`fk_empresa`, `aceito_em`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
