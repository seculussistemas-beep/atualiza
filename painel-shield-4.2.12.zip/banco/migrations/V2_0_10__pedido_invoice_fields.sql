-- Adiciona campos para fatura/nota dos gateways
ALTER TABLE `pedido`
    ADD COLUMN `gateway_invoice_url` TEXT NULL AFTER `gateway_boleto_url`,
    ADD COLUMN `gateway_invoice_pdf_url` TEXT NULL AFTER `gateway_invoice_url`,
    ADD COLUMN `gateway_invoice_number` VARCHAR(80) NULL AFTER `gateway_invoice_pdf_url`,
    ADD COLUMN `gateway_due_date` DATETIME NULL AFTER `pagamento_expira_em`;

-- Preenche vencimento a partir de pagamento_expira_em quando nao existir
UPDATE `pedido`
SET `gateway_due_date` = `pagamento_expira_em`
WHERE `gateway_due_date` IS NULL AND `pagamento_expira_em` IS NOT NULL;

-- Backfill basico de invoice_url/pdf usando links existentes
UPDATE `pedido`
SET
    `gateway_invoice_url` = COALESCE(`gateway_invoice_url`, `gateway_checkout_url`, `gateway_boleto_url`),
    `gateway_invoice_pdf_url` = COALESCE(`gateway_invoice_pdf_url`, `gateway_boleto_url`)
WHERE `gateway_invoice_url` IS NULL;
