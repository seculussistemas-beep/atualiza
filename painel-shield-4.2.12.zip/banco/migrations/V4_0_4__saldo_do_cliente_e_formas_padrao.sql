-- Migracao para a versao 4.0.4: saldo do cliente e formas de recebimento de fabrica
-- Data: 04/09/2026
--
-- SALDO. O PIX sai com o valor travado no do plano, mas dinheiro entra do
-- jeito que entra: o cliente manda a mais por engano ou a menos por conta
-- propria. Antes, a mais sumia na conciliacao e a menos deixava a cobranca
-- aberta para sempre. Agora a diferenca vira SALDO do cliente -- positivo
-- desconta da proxima cobranca, negativo soma nela -- e a cobranca fecha.
-- Um numero por cliente, em centavos, e o extrato fica na auditoria.
--
-- FORMAS DE FABRICA. Nao ha "acrescentar forma": o painel oferece cada
-- provedor que sabe operar, ja na lista e aguardando configuracao. A tela
-- tambem semeia ao abrir (contas.php), mas quem instala do zero precisa achar
-- a lista pronta sem ter aberto tela nenhuma -- e por isso esta aqui.
-- INSERT ... WHERE NOT EXISTS: rodar de novo nao duplica.

ALTER TABLE `empresa`
    ADD COLUMN `saldo_centavos` INT(11) NOT NULL DEFAULT 0;

INSERT INTO `conta_recebimento` (`provedor`, `apelido`, `ambiente`, `ativo`, `aceita_pix`, `aceita_boleto`, `aceita_cartao`, `aceita_assinatura`, `criado_em`, `atualizado_em`)
SELECT 'mercadopago', 'Mercado Pago', 'producao', 0, 1, 1, 1, 1, NOW(), NOW()
 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `conta_recebimento` WHERE `provedor` = 'mercadopago');
INSERT INTO `conta_recebimento` (`provedor`, `apelido`, `ambiente`, `ativo`, `aceita_pix`, `aceita_boleto`, `aceita_cartao`, `aceita_assinatura`, `criado_em`, `atualizado_em`)
SELECT 'asaas', 'Asaas', 'producao', 0, 1, 1, 1, 1, NOW(), NOW()
 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `conta_recebimento` WHERE `provedor` = 'asaas');
INSERT INTO `conta_recebimento` (`provedor`, `apelido`, `ambiente`, `ativo`, `aceita_pix`, `aceita_boleto`, `aceita_cartao`, `aceita_assinatura`, `criado_em`, `atualizado_em`)
SELECT 'pagbank', 'PagBank', 'producao', 0, 1, 1, 1, 0, NOW(), NOW()
 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `conta_recebimento` WHERE `provedor` = 'pagbank');
INSERT INTO `conta_recebimento` (`provedor`, `apelido`, `ambiente`, `ativo`, `aceita_pix`, `aceita_boleto`, `aceita_cartao`, `aceita_assinatura`, `criado_em`, `atualizado_em`)
SELECT 'pagarme', 'Pagar.me (Stone)', 'producao', 0, 1, 1, 1, 0, NOW(), NOW()
 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `conta_recebimento` WHERE `provedor` = 'pagarme');
INSERT INTO `conta_recebimento` (`provedor`, `apelido`, `ambiente`, `ativo`, `aceita_pix`, `aceita_boleto`, `aceita_cartao`, `aceita_assinatura`, `criado_em`, `atualizado_em`)
SELECT 'cora', 'Cora', 'producao', 0, 1, 1, 0, 0, NOW(), NOW()
 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `conta_recebimento` WHERE `provedor` = 'cora');
INSERT INTO `conta_recebimento` (`provedor`, `apelido`, `ambiente`, `ativo`, `aceita_pix`, `aceita_boleto`, `aceita_cartao`, `aceita_assinatura`, `criado_em`, `atualizado_em`)
SELECT 'efi', 'Efi', 'producao', 0, 1, 0, 0, 0, NOW(), NOW()
 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `conta_recebimento` WHERE `provedor` = 'efi');
INSERT INTO `conta_recebimento` (`provedor`, `apelido`, `ambiente`, `ativo`, `aceita_pix`, `aceita_boleto`, `aceita_cartao`, `aceita_assinatura`, `criado_em`, `atualizado_em`)
SELECT 'pix_estatico', 'PIX estatico (confirmacao manual)', 'producao', 0, 1, 0, 0, 0, NOW(), NOW()
 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `conta_recebimento` WHERE `provedor` = 'pix_estatico');
-- So o dinheiro em especie nasce ligado: nao ha o que configurar nele.
INSERT INTO `conta_recebimento` (`provedor`, `apelido`, `ambiente`, `ativo`, `aceita_pix`, `aceita_boleto`, `aceita_cartao`, `aceita_assinatura`, `criado_em`, `atualizado_em`)
SELECT 'dinheiro', 'Dinheiro em especie', 'producao', 1, 0, 0, 0, 0, NOW(), NOW()
 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `conta_recebimento` WHERE `provedor` = 'dinheiro');

-- O cadastro antigo do PagBank (codigo `pagseguro`) so serve a quem ja tem
-- credencial nele. Sem credencial, e uma linha repetida na lista.
DELETE FROM `conta_recebimento`
 WHERE `provedor` = 'pagseguro' AND (`credenciais` IS NULL OR `credenciais` = '');
