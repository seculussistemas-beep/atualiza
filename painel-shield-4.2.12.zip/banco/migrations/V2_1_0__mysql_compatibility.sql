-- Migração para versão 2.1.0: Correções de compatibilidade MySQL
-- Data: 20/02/2026
-- Autor: GitHub Copilot

-- Adiciona coluna group_id na empresa (idempotente)
-- Atenção: MySQL não suporta IF NOT EXISTS para colunas/índices. Execute e ignore erros de duplicidade (1060/1061).
ALTER TABLE empresa
  ADD COLUMN group_id INT(11) NULL DEFAULT NULL;
ALTER TABLE empresa
  ADD INDEX idx_empresa_group (group_id);

-- Tabela de grupos de clientes
CREATE TABLE IF NOT EXISTS client_group (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    descricao VARCHAR(255) DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Tabela de preços por grupo
CREATE TABLE IF NOT EXISTS client_group_plan_price (
    group_id INT NOT NULL,
    plano_id INT NOT NULL,
    valor_override DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (group_id, plano_id),
    INDEX idx_cgpp_group (group_id),
    INDEX idx_cgpp_plano (plano_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
