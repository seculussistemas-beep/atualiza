-- Migracao para a versao 4.1.9: uma linha so de dinheiro e uma de PIX estatico
-- Data: 10/09/2026
--
-- Instalacoes em campo apareceram com DUAS linhas de "dinheiro em especie":
-- a da V4_0_4 e outra com o nome do catalogo, semeada pela tela de formas
-- numa janela em que ela nao enxergou a primeira. As formas manuais nao tem
-- credencial nem configuracao, entao a copia mais nova e descartavel -- desde
-- que nenhuma assinatura ou tentativa de cobranca aponte para ela. Fica a
-- mais antiga (o menor id), que e a que a V4_0_4 criou.
DELETE d2 FROM `conta_recebimento` d2
  JOIN `conta_recebimento` d1
    ON d1.`provedor` = d2.`provedor` AND d1.`id` < d2.`id`
 WHERE d2.`provedor` IN ('dinheiro', 'pix_estatico')
   AND NOT EXISTS (SELECT 1 FROM `assinatura` a WHERE a.`fk_conta` = d2.`id`)
   AND NOT EXISTS (SELECT 1 FROM `cobranca_tentativa` t WHERE t.`fk_conta` = d2.`id`);
