-- Migracao para a versao 4.0.0: recuperacao de senha por e-mail
-- Data: 03/09/2026
--
-- Ate aqui "Esqueci a senha" era um link para lugar nenhum. Quem perdia a
-- senha do painel dependia de alguem com acesso ao banco.
--
-- O TOKEN NAO E GUARDADO: guarda-se o SHA-256 dele. Quem le a tabela (backup
-- vazado, dump no e-mail errado) nao consegue montar o link. O token de
-- verdade so existe no e-mail que o usuario recebeu.
--
-- USADO_EM em vez de DELETE: o registro fica como rastro de quem pediu e
-- quando, e um token usado nunca volta a valer.

CREATE TABLE IF NOT EXISTS senha_recuperacao (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    fk_usuario INT NOT NULL,
    token_hash CHAR(64) NOT NULL,
    expira_em DATETIME NOT NULL,
    usado_em DATETIME NULL,
    ip VARCHAR(45) NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY ux_senha_recuperacao_token (token_hash),
    KEY ix_senha_recuperacao_usuario (fk_usuario, criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;
