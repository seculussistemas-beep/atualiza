-- Migracao para a versao 4.1.4: nome e e-mail dos responsaveis com 255
-- Data: 10/09/2026
-- Autor: lojadev
--
-- O fechamento passou a EXIGIR os responsaveis (quem assina, quem paga), com
-- e-mail conferido e telefone com mascara. 80 para nome e 120 para e-mail
-- eram o chute da 4.1.2; o dono do produto pediu 255, que e o que cabe num
-- e-mail de verdade. O e-mail da loja (empresa.email) acompanha.
ALTER TABLE `empresa`
    MODIFY COLUMN `responsavel_nome` VARCHAR(255) NULL,
    MODIFY COLUMN `responsavel_email` VARCHAR(255) NULL,
    MODIFY COLUMN `financeiro_nome` VARCHAR(255) NULL,
    MODIFY COLUMN `financeiro_email` VARCHAR(255) NULL,
    MODIFY COLUMN `email` VARCHAR(255) NULL;

COMMIT;
