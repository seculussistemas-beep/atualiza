-- Migracao para a versao 4.2.1: a cobranca lembra quanto de credito consumiu
-- Data: 11/09/2026
--
-- O credito do cliente era descontado ao ABRIR a cobranca e o quanto so
-- aparecia na descricao, em prosa. Cancelada ou estornada a cobranca, o
-- credito sumia: o cliente pagou a mais uma vez e perdeu o troco. Agora o
-- numero viaja na propria linha, e cancelar ou estornar o devolve.
ALTER TABLE `cobranca`
    ADD COLUMN `saldo_aplicado_centavos` INT(11) NOT NULL DEFAULT 0;
