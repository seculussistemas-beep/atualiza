-- Migracao para a versao 4.1.3: mudar no meio do contrato
-- Data: 10/09/2026
-- Autor: lojadev
--
-- Fatia 8 da reorganizacao (docs/reorganizacao-do-painel.md, secao 6).
--
-- "LIBERAR SO QUANDO PAGAR". Ao aumentar a cota de terminais, o membro pode
-- pedir que ela suba apenas quando a cobranca do ajuste for confirmada; ate
-- la o cliente continua com o que tinha. A cota pretendida fica NA COBRANCA,
-- e quem a aplica e a ponte de pagamento de sempre (shield_cobranca_estendeu_
-- validade) -- mecanicamente e o mesmo lugar onde o pagamento ja estende a
-- validade. Nulo na esmagadora maioria das cobrancas.
ALTER TABLE `cobranca`
    ADD COLUMN `libera_nterminais` INT(11) NULL;

COMMIT;

-- A COBRANCA DE AJUSTE NAO ESTENDE VALIDADE. `meses` = 0 passa a significar
-- "paga, nao move a validade": e o mes corrente proporcional de um terminal
-- ou modulo acrescentado, e nao um mes a mais de licenca. Ate aqui toda
-- cobranca sem assinatura estendia pelo menos um mes ao ser paga, e um ajuste
-- de R$ 12,50 daria trinta dias de licenca. Nao ha mudanca de esquema para
-- isso; fica registrado aqui porque e a mesma fatia.
