-- Migracao para a versao 4.0.7: modulos, terminal excedente e encargos
-- Data: 09/09/2026
-- Autor: lojadev
--
-- Tres pedidos do levantamento de 08/09/2026
-- (docs/pesquisa-cobranca-comunidade.md), e os tres sao a mesma coisa vista de
-- angulos diferentes: A MENSALIDADE DEIXA DE SER UM NUMERO SO.
--
--   modulos (9 dos 43 relatos)  -- o que o cliente contratou alem do basico;
--   terminal extra (18 relatos) -- maquina que quer trabalhar e nao cabe;
--   multa e juros (3 relatos)   -- o que o atraso acrescenta.
--
-- Ate aqui o valor vinha inteiro do plano ou da assinatura, e tudo o que
-- fugisse disso o membro somava a mao ou nao cobrava. Dezoito softwarehouses
-- cobram por terminal adicional TODO MES, na unha.

-- ------------------------------------------------------------------ encargos

-- O QUE O ATRASO ACRESCENTOU, guardado separado do principal.
--
-- Sem esta coluna o recalculo nao teria como ser idempotente: emitir de novo
-- amanha somaria juros sobre um principal ja inchado pelos juros de hoje, e em
-- duas semanas a divida dobraria sozinha. Com ela, o principal e sempre
-- `valor_centavos - encargos_centavos` e a conta refaz do zero.
--
-- NASCE ZERO e os dois percentuais nascem zero em shield_system_meta: quem
-- atualizar o painel nao passa a cobrar de ninguem sem ter aberto a tela.
ALTER TABLE `cobranca`
    ADD COLUMN `encargos_centavos` INT(11) NOT NULL DEFAULT 0 AFTER `valor_centavos`;

COMMIT;

-- ------------------------------------------------------------- terminal extra

-- O PRECO DO TERMINAL ADICIONAL E POR CLIENTE, e nao global.
--
-- No levantamento inteiro nao houve dois membros com a mesma tabela de preco, e
-- varios disseram que o valor muda de cliente para cliente ("o valor da
-- mensalidade varia de um cliente para outro, depende muito da negociacao").
-- Numero global obrigaria todo mundo a caber na media de ninguem.
--
-- ZERO E "NAO COBRO", e e o padrao. O membro que nunca preencher continua sem
-- cobrar terminal, exatamente como hoje.
ALTER TABLE `empresa`
    ADD COLUMN `valor_terminal_centavos` INT(11) NOT NULL DEFAULT 0;

COMMIT;

-- ------------------------------------------------------------------- modulos

-- O CATALOGO. Um modulo e uma coisa que o cliente contrata alem do basico:
-- Fiscal, NFS-e, TEF, Forca de Vendas, Mesas e Comandas -- os nomes vieram dos
-- proprios relatos.
--
-- Tabela e nao ENUM: a lista muda por softwarehouse, e cada membro tem a dele.
-- O painel nasce sem nenhum modulo cadastrado, porque adivinhar a lista de
-- outra pessoa seria pior do que a tela vazia.
CREATE TABLE IF NOT EXISTS `modulo` (
    `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `nome` VARCHAR(60) NOT NULL,
    `descricao` VARCHAR(150) NULL,
    `valor_centavos` INT(11) NOT NULL DEFAULT 0,
    `ativo` TINYINT(1) NOT NULL DEFAULT 1,
    `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_modulo_nome` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;

-- QUEM TEM O QUE.
--
-- O VALOR E COPIADO, e nao consultado no catalogo. E o mesmo motivo de
-- cobranca.valor_centavos ser copiado do plano (V3_0_1) e de cobranca.meses
-- congelar a duracao (V4_0_5): o preco de tabela muda, e o cliente que fechou
-- por outro valor continua pagando o que combinou. Reajuste vira uma edicao
-- explicita, cliente a cliente, e nao um efeito colateral de mexer no catalogo.
--
-- `ate` ACEITA NULO -- contratado e ainda valendo. Preenchido, o modulo saiu, e
-- a linha FICA: "quando ele deixou de ter NFS-e" e pergunta que aparece meses
-- depois, e resposta que so existe se ninguem tiver apagado a linha.
--
-- O indice unico usa `ate`: nulo nao conflita com nulo no MySQL, entao o mesmo
-- cliente pode ter contratado, cancelado e recontratado o mesmo modulo, e so
-- uma dessas linhas fica aberta. Mesmo idioma de uk_movimento_cobranca.
CREATE TABLE IF NOT EXISTS `empresa_modulo` (
    `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `fk_empresa` INT(11) NOT NULL,
    `fk_modulo` INT(11) NOT NULL,
    `valor_centavos` INT(11) NOT NULL DEFAULT 0,
    `desde` DATE NOT NULL,
    `ate` DATE NULL,
    `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_empresa_modulo_aberto` (`fk_empresa`, `fk_modulo`, `ate`),
    KEY `ix_empresa_modulo` (`fk_empresa`, `ate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;

-- SEM FOREIGN KEY, como no resto do esquema: `empresa` e MyISAM no
-- BancoCompleto.sql e nenhuma migracao a converte. Quem segura a integridade
-- aqui e o codigo, e as leituras sao todas por JOIN explicito.
