-- Migracao para a versao 4.1.1: encerrar como marca, e o prazo de teste por cliente
-- Data: 10/09/2026
-- Autor: lojadev
--
-- Fatia 5 da reorganizacao (docs/reorganizacao-do-painel.md, secoes 5 e 7).
--
-- ENCERRAR NAO E APAGAR. E uma marca, reversivel, que tira o cliente da fila e
-- para a licenca na hora -- e nada some. O apagar de verdade continua na
-- Limpeza de cadastros, onde um humano confere e confirma, porque apagar
-- empresa nao e atomico neste banco (empresa e MyISAM, terminais e InnoDB) e
-- rodando sem plateia e o pior lugar para esse defeito morder.
--
-- Quem encerra: o membro, pela ficha; ou a rotina, quando o teste venceu e
-- ninguem fechou em SHIELD_ENCERRAMENTO_DIAS dias. Os dois deixam quem e o
-- motivo aqui e uma linha no livro de auditoria.
ALTER TABLE `empresa`
    ADD COLUMN `encerrado_em` DATETIME NULL,
    ADD COLUMN `encerrado_por` VARCHAR(80) NULL,
    ADD COLUMN `encerrado_motivo` VARCHAR(150) NULL;

COMMIT;

-- O PRAZO DE TESTE E POR CLIENTE (funcoes/licenca/teste.php). Sete dias e o
-- padrao, contado do nascimento; esta data, quando preenchida, manda -- serve
-- para encurtar ou esticar, e prorrogar e move-la. Nada e gravado no
-- nascimento de proposito: lead continua sendo quem nao tem validade.
ALTER TABLE `empresa`
    ADD COLUMN `teste_ate` DATE NULL;

COMMIT;
