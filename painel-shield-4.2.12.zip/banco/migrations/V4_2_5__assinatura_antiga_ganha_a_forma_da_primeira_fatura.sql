-- Migracao para a versao 4.2.5: a assinatura antiga ganha a forma da primeira fatura
-- Data: 14/09/2026
--
-- A V4_2_4 deu forma a assinatura e deixou as existentes em NULL, que e PIX:
-- quem fechou em boleto antes dela continua recebendo PIX do segundo mes em
-- diante. A melhor pista do que foi combinado e a PRIMEIRA fatura da
-- assinatura, a de menor id: e a que o fechamento abriu com a forma escolhida
-- na tela. As do ciclo nasciam sem forma, e por isso nao servem de pista.
--
-- So onde a forma e NULL. Quem ja tem forma, gravada pelo fechamento ou por
-- Mudar o contrato depois da V4_2_4, nao muda. Primeira fatura sem forma, ou
-- com palavra que nao e forma, deixa a assinatura como esta: NULL continua PIX.
-- Rodar de novo nao acha mais nada, porque a propria condicao exclui quem ja
-- ganhou forma.
--
-- Sem BancoCompleto.sql: assinatura e cobranca nascem nas migracoes (V3_0_1),
-- e numa instalacao nova as duas estao vazias quando esta roda.
UPDATE `assinatura` a
   SET a.`forma` = (SELECT c.`forma` FROM `cobranca` c WHERE c.`fk_assinatura` = a.`id` ORDER BY c.`id` LIMIT 1)
 WHERE a.`forma` IS NULL
   AND (SELECT c.`forma` FROM `cobranca` c WHERE c.`fk_assinatura` = a.`id` ORDER BY c.`id` LIMIT 1) IN ('pix', 'boleto', 'cartao', 'dinheiro');
