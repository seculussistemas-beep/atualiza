-- Forca gateways sem credenciais a permanecerem inativos e com metodos desligados
UPDATE `gateways`
SET
    `active` = 0,
    `pix_ativo` = 0,
    `boleto_ativo` = 0,
    `cartao_ativo` = 0,
    `updated_at` = CURRENT_TIMESTAMP
WHERE
    (
        (LOWER(`gateway_name`) = 'mercadopago' AND (COALESCE(NULLIF(TRIM(`access_token`), ''), '') = '' OR COALESCE(NULLIF(TRIM(`public_key`), ''), '') = ''))
        OR (LOWER(`gateway_name`) = 'pagseguro' AND (COALESCE(NULLIF(TRIM(`ps_email`), ''), '') = '' OR COALESCE(NULLIF(TRIM(`ps_token`), ''), '') = ''))
        OR (LOWER(`gateway_name`) = 'asaas' AND (COALESCE(NULLIF(TRIM(`access_token`), ''), '') = '' OR COALESCE(NULLIF(TRIM(`wallet_id`), ''), '') = ''))
        OR (LOWER(`gateway_name`) = 'efi' AND (
            COALESCE(NULLIF(TRIM(`efi_client_id`), ''), '') = ''
            OR COALESCE(NULLIF(TRIM(`efi_client_secret`), ''), '') = ''
            OR COALESCE(NULLIF(TRIM(`efi_pix_key`), ''), '') = ''
            OR COALESCE(NULLIF(TRIM(`efi_pix_cert_base64`), ''), '') = ''
            OR COALESCE(NULLIF(TRIM(`efi_pix_cert_password`), ''), '') = ''
        ))
        OR (LOWER(`gateway_name`) = 'cora')
    );

-- Normaliza nulos para zero e ambiente para teste quando indefinido
UPDATE `gateways`
SET
    `pix_ativo` = COALESCE(`pix_ativo`, 0),
    `boleto_ativo` = COALESCE(`boleto_ativo`, 0),
    `cartao_ativo` = COALESCE(`cartao_ativo`, 0),
    `active` = COALESCE(`active`, 0),
    `producao` = CASE WHEN `producao` IN ('s', 'n') THEN `producao` ELSE 'n' END,
    `updated_at` = CURRENT_TIMESTAMP;
