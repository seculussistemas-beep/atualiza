-- Migracao para a versao 4.2.4: o rascunho do fechamento nao faz cliente, e a assinatura guarda a forma
-- Data: 14/09/2026
--
-- O RASCUNHO. Gravar rascunho e Dar inicio ao contrato passavam pela mesma
-- gravacao: assinatura ativa, primeira cobranca, modulos, cota e fechado_em. E
-- fechado_em, desde 11/09/2026, e o que faz alguem ser cliente e o que encerra
-- o teste de sete dias. Quem so guardou o formulario saia de Em avaliacao,
-- perdia a licenca do teste e recebia a segunda mensalidade emitida pelo ciclo.
-- O rascunho passa a morar aqui, como JSON do formulario, sem tocar em nada que
-- tenha efeito. rascunho_em e o que a fila mostra.
--
-- NADA E CONVERTIDO. Quem gravou rascunho antes desta versao continua com
-- fechado_em e assinatura. O livro nao diz qual botao foi clicado, e Dar inicio
-- com o provedor fora do ar deixa o mesmo rastro. A consulta que lista os
-- candidatos esta na documentacao do projeto, secao 4.1.25.
--
-- Uma coluna por comando: o BancoCompleto.sql ja traz as duas da empresa, e a
-- coluna repetida e aviso de idempotencia que pula o comando inteiro.
ALTER TABLE `empresa`
    ADD COLUMN `fechamento_rascunho` TEXT NULL DEFAULT NULL;

ALTER TABLE `empresa`
    ADD COLUMN `rascunho_em` DATETIME NULL DEFAULT NULL;

-- A FORMA DA ASSINATURA. A mensalidade do ciclo nascia sem forma, e os
-- adaptadores emitem PIX quando ela vem vazia. Quem fechou em boleto recebia
-- boleto na primeira fatura, que o fechamento abre com a forma, e PIX do
-- segundo mes em diante. NULL continua sendo PIX, como sempre foi, e nenhuma
-- assinatura existente muda de forma sozinha. Mesmo tamanho de cobranca.forma.
ALTER TABLE `assinatura`
    ADD COLUMN `forma` VARCHAR(20) NULL DEFAULT NULL;
