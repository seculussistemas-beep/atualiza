-- Migracao para a versao 4.0.5: a cobranca sabe quantos meses ela compra
-- Data: 04/09/2026
--
-- A 4.0.3 prometeu: "avulso -- paga uma vez, ganha acesso por `recorrencia`
-- meses". O motor nao cumpria. A cobranca nao guardava meses nenhum, e
-- shield_cobranca_estendeu_validade() estendia UM mes para toda cobranca sem
-- assinatura. A tela mostrava "Plano de 12 meses", o cliente pagava os doze, e
-- a validade andava um.
--
-- A COBRANCA CONGELA O QUE COMPROU, em vez de apontar para o plano. O plano
-- pode mudar de duracao ou de preco depois; o que o cliente pagou nao muda. E
-- o mesmo motivo de valor_centavos ser copiado e nao consultado.
--
-- A assinatura continua mandando quando existe: o ciclo dela e o contrato, e
-- esta coluna so vale para cobranca solta. Default 1 preserva o que ja esta no
-- banco -- toda cobranca existente estendeu um mes, e e isso que ela registra.

ALTER TABLE `cobranca`
    ADD COLUMN `meses` INT(11) NOT NULL DEFAULT 1 AFTER `valor_centavos`;
