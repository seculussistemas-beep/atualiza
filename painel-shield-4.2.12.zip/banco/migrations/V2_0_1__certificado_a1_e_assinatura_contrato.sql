ALTER TABLE `softhouse` ADD COLUMN `certificado_a1_arquivo` varchar(255) DEFAULT NULL;
ALTER TABLE `softhouse` ADD COLUMN `certificado_a1_senha_enc` text DEFAULT NULL;
ALTER TABLE `softhouse` ADD COLUMN `certificado_a1_thumbprint` varchar(128) DEFAULT NULL;
ALTER TABLE `softhouse` ADD COLUMN `certificado_a1_serial` varchar(128) DEFAULT NULL;
ALTER TABLE `softhouse` ADD COLUMN `certificado_a1_titular` varchar(255) DEFAULT NULL;
ALTER TABLE `softhouse` ADD COLUMN `certificado_a1_validade_inicio` datetime DEFAULT NULL;
ALTER TABLE `softhouse` ADD COLUMN `certificado_a1_validade_fim` datetime DEFAULT NULL;
ALTER TABLE `softhouse` ADD COLUMN `certificado_a1_atualizado_em` datetime DEFAULT NULL;

ALTER TABLE `contratos` ADD COLUMN `assinatura_status` varchar(20) NOT NULL DEFAULT 'legacy';
ALTER TABLE `contratos` ADD COLUMN `assinatura_algoritmo` varchar(30) DEFAULT NULL;
ALTER TABLE `contratos` ADD COLUMN `assinatura_payload_hash` char(64) DEFAULT NULL;
ALTER TABLE `contratos` ADD COLUMN `assinatura_valor` longtext DEFAULT NULL;
ALTER TABLE `contratos` ADD COLUMN `assinatura_cert_serial` varchar(128) DEFAULT NULL;
ALTER TABLE `contratos` ADD COLUMN `assinatura_cert_thumbprint` varchar(128) DEFAULT NULL;
ALTER TABLE `contratos` ADD COLUMN `assinatura_cert_titular` varchar(255) DEFAULT NULL;
ALTER TABLE `contratos` ADD COLUMN `assinatura_cert_validade_fim` datetime DEFAULT NULL;
ALTER TABLE `contratos` ADD COLUMN `assinatura_realizada_em` datetime DEFAULT NULL;

UPDATE `contratos`
SET `assinatura_status` = 'legacy'
WHERE `assinatura_status` IS NULL OR `assinatura_status` = '';
