-- Migracao para a versao 4.0.2: limite de tentativas de login
-- Data: 04/09/2026
--
-- Fecha o MED-5 de docs/auditoria-seguranca.md: a tela de login nao contava
-- tentativa, nao atrasava e nao bloqueava. O password_verify com bcrypt e lento
-- de proposito e ja limita a taxa, mas nao impede ataque distribuido contra uma
-- lista de e-mails -- e nao deixava rastro nenhum de que houve ataque.
--
-- UMA LINHA POR TENTATIVA FALHA, e nao um contador por chave. Contador exige
-- decidir na hora em que zerar, e errar essa decisao deixa alguem bloqueado
-- para sempre ou nunca. Com uma linha por evento, a janela e uma clausula
-- WHERE: conta o que caiu nos ultimos N minutos e pronto. Zerar apos o acerto e
-- um DELETE, e a faxina do que envelheceu tambem.
--
-- A chave guarda O QUE FOI DIGITADO, nao o usuario encontrado. Tentativa contra
-- e-mail que nao existe tambem precisa contar -- e justamente ela que aparece
-- quando alguem varre uma lista.
--
-- SEM CHAVE ESTRANGEIRA para usuario, de proposito: a maioria das linhas aqui
-- nao corresponde a usuario nenhum, e apagar um usuario nao deve arrastar o
-- registro de que tentaram entrar como ele.

CREATE TABLE IF NOT EXISTS login_tentativa (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    -- 'login' = o e-mail/usuario digitado; 'ip' = a origem da requisicao
    tipo VARCHAR(10) NOT NULL,
    chave VARCHAR(190) NOT NULL,
    ip VARCHAR(45) NULL,
    agente VARCHAR(160) NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    -- A consulta e sempre "quantas deste tipo+chave depois de tal instante";
    -- o indice espelha isso, na ordem em que o WHERE pergunta.
    KEY ix_login_tentativa_janela (tipo, chave, criado_em),
    KEY ix_login_tentativa_faxina (criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;
