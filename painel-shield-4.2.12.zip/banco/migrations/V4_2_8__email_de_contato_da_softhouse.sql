-- O e-mail de contato da softhouse -- 17/09/2026.
--
-- A area do cliente tem um "Duvidas:" no rodape com o telefone e o e-mail de
-- quem atende o cliente final. O e-mail saia sempre vazio: a tela o procurava
-- numa coluna que a softhouse nunca teve, e Minha empresa nao tinha onde
-- escreve-lo. Nasce vazio; o membro preenche em Minha empresa.
--
-- A softhouse nasce na V2_0_0, e nao na baseline: o BancoCompleto.sql nao muda.
ALTER TABLE `softhouse`
    ADD COLUMN `email` VARCHAR(255) DEFAULT NULL
    COMMENT 'contato que o cliente final ve na area do cliente';
