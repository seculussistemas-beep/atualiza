ALTER TABLE `gateways` ADD COLUMN `producao` CHAR(1) NOT NULL DEFAULT 'n';
ALTER TABLE `gateways` ADD COLUMN `pix_ativo` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `gateways` ADD COLUMN `boleto_ativo` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `gateways` ADD COLUMN `cartao_ativo` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `gateways` ADD COLUMN `webhook_url` VARCHAR(255) DEFAULT NULL;
ALTER TABLE `gateways` ADD COLUMN `webhook_token` VARCHAR(255) DEFAULT NULL;

ALTER TABLE `gateways` ADD UNIQUE KEY `uniq_gateway_name` (`gateway_name`);

INSERT INTO `gateways` (`gateway_name`, `active`, `access_token`, `public_key`, `client_id`, `client_secret`, `wallet_id`, `producao`, `pix_ativo`, `boleto_ativo`, `cartao_ativo`)
SELECT 'mercadopago', 0, NULL, NULL, NULL, NULL, NULL, 'n', 1, 1, 1
FROM DUAL WHERE NOT EXISTS (
  SELECT 1
  FROM `gateways`
  WHERE LOWER(`gateway_name`) = 'mercadopago'
);

INSERT INTO `gateways` (`gateway_name`, `active`, `access_token`, `public_key`, `client_id`, `client_secret`, `wallet_id`, `producao`, `pix_ativo`, `boleto_ativo`, `cartao_ativo`)
SELECT 'cora', 0, NULL, NULL, NULL, NULL, NULL, 'n', 0, 0, 0
FROM DUAL WHERE NOT EXISTS (
  SELECT 1
  FROM `gateways`
  WHERE LOWER(`gateway_name`) = 'cora'
);

INSERT INTO `gateways` (`gateway_name`, `active`, `access_token`, `public_key`, `client_id`, `client_secret`, `wallet_id`, `producao`, `pix_ativo`, `boleto_ativo`, `cartao_ativo`)
SELECT 'asaas', 0, NULL, NULL, NULL, NULL, NULL, 'n', 1, 1, 0
FROM DUAL WHERE NOT EXISTS (
  SELECT 1
  FROM `gateways`
  WHERE LOWER(`gateway_name`) = 'asaas'
);

UPDATE `gateways`
SET
  `active` = CASE
    WHEN LOWER(`gateway_name`) = 'mercadopago'
      AND COALESCE(NULLIF(TRIM(`access_token`), ''), '') <> ''
      AND COALESCE(NULLIF(TRIM(`public_key`), ''), '') <> ''
    THEN 1
    WHEN LOWER(`gateway_name`) = 'mercadopago' THEN 0
    ELSE `active`
  END,
  `pix_ativo` = CASE
    WHEN LOWER(`gateway_name`) = 'cora' THEN 0
    ELSE COALESCE(`pix_ativo`, 1)
  END,
  `boleto_ativo` = CASE
    WHEN LOWER(`gateway_name`) = 'cora' THEN 0
    ELSE COALESCE(`boleto_ativo`, 1)
  END,
  `cartao_ativo` = CASE
    WHEN LOWER(`gateway_name`) = 'asaas' THEN 0
    WHEN LOWER(`gateway_name`) = 'cora' THEN 0
    ELSE COALESCE(`cartao_ativo`, 1)
  END,
  `producao` = CASE
    WHEN `producao` IN ('s', 'n') THEN `producao`
    ELSE 'n'
  END,
  `updated_at` = CURRENT_TIMESTAMP;

ALTER TABLE `pedido` ADD COLUMN `gateway_nome` VARCHAR(50) DEFAULT NULL;
ALTER TABLE `pedido` ADD COLUMN `metodo_pagamento` VARCHAR(20) DEFAULT NULL;
ALTER TABLE `pedido` ADD COLUMN `gateway_external_id` VARCHAR(120) DEFAULT NULL;
ALTER TABLE `pedido` ADD COLUMN `gateway_checkout_url` TEXT DEFAULT NULL;
ALTER TABLE `pedido` ADD COLUMN `gateway_qr_code` TEXT DEFAULT NULL;
ALTER TABLE `pedido` ADD COLUMN `gateway_qr_code_base64` LONGTEXT DEFAULT NULL;
ALTER TABLE `pedido` ADD COLUMN `gateway_boleto_url` TEXT DEFAULT NULL;
ALTER TABLE `pedido` ADD COLUMN `gateway_status` VARCHAR(50) DEFAULT NULL;
ALTER TABLE `pedido` ADD COLUMN `gateway_payload` LONGTEXT DEFAULT NULL;
ALTER TABLE `pedido` ADD COLUMN `data_pagamento` DATETIME DEFAULT NULL;
ALTER TABLE `pedido` ADD COLUMN `pagamento_expira_em` DATETIME DEFAULT NULL;
ALTER TABLE `pedido` ADD COLUMN `tentativa_pagamento` INT NOT NULL DEFAULT 0;

ALTER TABLE `pedido` ADD KEY `idx_pedido_cod_transacao` (`cod_transacao`);
ALTER TABLE `pedido` ADD KEY `idx_pedido_situacao` (`situacao`);
ALTER TABLE `pedido` ADD KEY `idx_pedido_gateway_external` (`gateway_external_id`);