-- Migracao para a versao 4.0.3: planos com tipo e descricao
-- Data: 04/09/2026
--
-- A tabela `planos` guardava so recorrencia e valor, e servia a uma coisa: o
-- plano pre-pago (paga uma vez, vale N meses). A assinatura era montada a mao
-- na tela, valor e ciclo digitados a cada cliente novo -- e digitado de novo
-- a cada cliente e onde o valor sai diferente do combinado.
--
-- DOIS TIPOS NA MESMA TABELA, e nao duas tabelas: os dois sao "um preco por
-- um periodo", e o que muda e se o periodo se repete sozinho. `assinatura`
-- ja tinha `fk_plano` esperando por isto.
--
--   avulso      paga uma vez, ganha acesso por `recorrencia` meses
--   assinatura  gera um PIX a cada `recorrencia` meses, ate cancelar
--
-- A descricao e o que o membro le no <select> ("Mensal PDV", "Anual com
-- suporte") e o que vai na cobranca. Sem ela, dois planos de 12 meses com
-- valores diferentes eram indistinguiveis na tela.

ALTER TABLE `planos`
    ADD COLUMN `tipo` VARCHAR(20) NOT NULL DEFAULT 'avulso' AFTER `id`,
    ADD COLUMN `descricao` VARCHAR(80) NOT NULL DEFAULT '' AFTER `tipo`;

-- Os planos que ja existem eram todos pre-pagos; a descricao nasce da duracao
-- para nao aparecer vazia na tela.
UPDATE `planos`
   SET `descricao` = CONCAT('Plano de ', `recorrencia`, IF(`recorrencia` = '1', ' mes', ' meses'))
 WHERE `descricao` = '';
