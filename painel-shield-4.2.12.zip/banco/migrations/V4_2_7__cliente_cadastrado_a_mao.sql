-- Quem foi cadastrado A MAO no painel -- 16/09/2026.
--
-- Ate aqui toda empresa nascia da rota de licenca: criacao e primeira chamada
-- do ERP aconteciam na MESMA requisicao, entao "o teste conta do nascimento" e
-- "o teste conta da primeira maquina" eram a mesma data, e o painel nunca
-- precisou gravar nada na linha do lead para saber disso (4.1.5).
--
-- A tela de cadastrar cliente quebrou esse empate: a loja passa a existir
-- semanas antes de instalar. Para ela -- e SO para ela -- o teste comeca quando
-- a primeira maquina liga, e isso precisa ser gravado, porque nao ha de onde
-- deduzir depois. Esta coluna e a marca que autoriza aquela gravacao.
--
-- Por que uma coluna e nao a data de nascimento: o lead que chega sozinho
-- tambem tem nascimento no passado na SEGUNDA chamada em diante, e o teste da
-- API (LicencaApiTest) cobra, com razao, que ali nada seja escrito. Sem a marca
-- o painel teria de adivinhar pela data, e adivinhacao num caminho que grava e
-- exatamente o que nao se quer no lugar mais quente do sistema.
ALTER TABLE `empresa`
    ADD COLUMN `cadastro_manual` TINYINT(1) NOT NULL DEFAULT 0
    COMMENT 'cadastrado pela tela, ainda sem ERP: autoriza carimbar teste_ate na primeira maquina';
