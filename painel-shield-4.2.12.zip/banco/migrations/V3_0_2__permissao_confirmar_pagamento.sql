-- Migracao para a versao 3.0.2: permissao de confirmar pagamento a mao
-- Data: 25/08/2026
-- Autor: lojadev
--
-- Confirmar pagamento a mao e o UNICO ponto do sistema onde alguem de dentro
-- pode dar meses de licenca sem dinheiro nenhum entrar. Nao ha prova externa
-- ali: a prova e o operador. Por isso ele precisa de permissao propria, e nao
-- so de "ser administrador" -- que e o que todo mundo do escritorio acaba
-- sendo.
--
-- Nasce com 1 para quem JA e administrador: quem confirmava ontem continua
-- confirmando hoje. Reforma que tira poder de quem ja tinha vira chamado no
-- primeiro dia, e o membro nao sabe onde religar.
--
-- MySQL nao tem IF NOT EXISTS para coluna. Rodando duas vezes, o erro 1060
-- (duplicidade) e esperado e nao quebra o roteiro.
ALTER TABLE usuario ADD COLUMN pode_confirmar_pagamento TINYINT(1) NOT NULL DEFAULT 0;

COMMIT;

UPDATE usuario SET pode_confirmar_pagamento = 1 WHERE TRIM(acesso) = '1';

COMMIT;
