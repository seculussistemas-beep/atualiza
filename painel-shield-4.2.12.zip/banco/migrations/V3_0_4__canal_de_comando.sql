-- Migracao para a versao 3.0.4: captura de log e aviso ao cliente
-- Data: 25/08/2026
-- Autor: lojadev
--
-- O ERP ja bate neste painel a cada 18 horas. A resposta da licenca passa a
-- poder carregar duas coisas de volta: um PEDIDO DE LOG e um AVISO para o
-- operador da loja. E o mesmo canal, e por isso as duas entram juntas -- do
-- lado do Delphi isso transforma dois releases em um.
--
-- O PEDIDO E POR TERMINAL, e nao por cliente: o defeito costuma ser de uma
-- maquina, e mandar as tres lojas do cliente compactarem a pasta do dia gasta
-- banda de todo mundo para achar o problema de uma.
--
-- SOB DEMANDA, NUNCA AUTOMATICO. O membro pede na tela e a captura acontece na
-- proxima abertura daquele terminal. Log a cada batida gastaria banda do
-- cliente e disco do membro sem ninguem ter pedido.

ALTER TABLE terminais ADD COLUMN log_pedido_de DATE NULL;

COMMIT;

ALTER TABLE terminais ADD COLUMN log_pedido_ate DATE NULL;

COMMIT;

ALTER TABLE terminais ADD COLUMN log_pedido_em DATETIME NULL;

COMMIT;

-- O que chegou. Guarda o arquivo em disco e so o caminho aqui: log compactado
-- de uma semana passa de megabyte, e coluna BLOB nesse tamanho faz o backup do
-- banco do membro crescer sem ele entender por que.
--
-- EXPURGO E CAMPO, e nao politica na cabeca de alguem: log de suporte serve por
-- semanas, nao por anos, e hospedagem compartilhada tem cota.
CREATE TABLE IF NOT EXISTS log_capturado (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    fk_empresa INT NULL,
    fk_terminal INT NULL,
    de DATE NULL,
    ate DATE NULL,
    arquivo VARCHAR(255) NOT NULL,
    tamanho INT NOT NULL DEFAULT 0,
    versao_exe VARCHAR(20) NULL,
    chegou_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expurgo_em DATE NULL,
    KEY ix_log_terminal (fk_terminal, chegou_em),
    KEY ix_log_expurgo (expurgo_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;
