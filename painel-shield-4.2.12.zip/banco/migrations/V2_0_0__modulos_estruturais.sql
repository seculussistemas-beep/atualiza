CREATE TABLE IF NOT EXISTS `config_contratos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contrato` text NOT NULL,
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `config_contratos` (`id`, `contrato`)
VALUES
(
  1,
  '<h2>Contrato de Licenca de Uso de Software</h2><p>Edite este modelo em Configuracoes de Contrato.</p>'
);

CREATE TABLE IF NOT EXISTS `contratos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cnpj_cliente` varchar(14) NOT NULL,
  `dia_vencimento` int(2) NOT NULL,
  `data_contrato` date DEFAULT NULL,
  `validade` varchar(255) NOT NULL,
  `recorrencia` varchar(20) NOT NULL,
  `valor_adesao` decimal(10,2) DEFAULT 0.00,
  `valor_recorrente` decimal(10,2) NOT NULL,
  `contrato_anexo` varchar(255) DEFAULT NULL,
  `chave_autorizacao` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `chave_autorizacao` (`chave_autorizacao`),
  KEY `idx_cnpj_cliente` (`cnpj_cliente`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE IF NOT EXISTS `representante` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cnpj` varchar(18) NOT NULL,
  `razao` varchar(255) NOT NULL,
  `fantasia` varchar(255) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cnpj` (`cnpj`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE IF NOT EXISTS `softhouse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cnpj` varchar(18) NOT NULL,
  `razao` varchar(255) NOT NULL,
  `fantasia` varchar(255) DEFAULT NULL,
  `ie` varchar(20) DEFAULT NULL,
  `estado` char(2) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `endereco` varchar(255) NOT NULL,
  `numero` varchar(10) NOT NULL,
  `cep` varchar(9) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cnpj` (`cnpj`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

ALTER TABLE `empresa` ADD COLUMN `cnpj_representante` varchar(20) DEFAULT NULL;
