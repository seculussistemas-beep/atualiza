-- Migracao para a versao 4.1.5: os caixas do teste sao por cliente
-- Data: 10/09/2026
-- Autor: lojadev
--
-- A regra geral da avaliacao (funcoes/licenca/teste.php) diz quantos caixas
-- o teste libera para todo mundo -- tres, por padrao, e o membro muda na tela.
-- Faltava o caso da loja que testa com um caixa so, ou com cinco: o dono do
-- produto pediu "dinamico para cada cliente", como ja e a data do teste.
--
-- NULL e "vale a regra geral". Preenchida, esta coluna manda, e so e lida
-- enquanto a empresa e lead: com validade, quem manda e nterminais.
ALTER TABLE `empresa`
    ADD COLUMN `teste_terminais` INT NULL;

COMMIT;
