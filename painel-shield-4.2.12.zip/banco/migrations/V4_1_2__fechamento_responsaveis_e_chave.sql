-- Migracao para a versao 4.1.2: o fechamento numa tela so
-- Data: 10/09/2026
-- Autor: lojadev
--
-- Fatia 7 da reorganizacao (docs/reorganizacao-do-painel.md, secao 5).
--
-- RESPONSAVEIS. A tabela tinha um telefone e um e-mail e nenhuma coluna de
-- pessoa. O fechamento pergunta quem ASSINA e quem PAGA -- e o forum pediu os
-- dois separados: quem atende o telefone da cobranca raramente e o dono.
ALTER TABLE `empresa`
    ADD COLUMN `responsavel_nome` VARCHAR(80) NULL,
    ADD COLUMN `responsavel_fone` VARCHAR(20) NULL,
    ADD COLUMN `responsavel_email` VARCHAR(120) NULL,
    ADD COLUMN `financeiro_nome` VARCHAR(80) NULL,
    ADD COLUMN `financeiro_fone` VARCHAR(20) NULL,
    ADD COLUMN `financeiro_email` VARCHAR(120) NULL;

COMMIT;

-- A CHAVE DO FECHAMENTO. A tela abre com uma chave unica e o POST a manda; o
-- segundo POST com a mesma chave (F5, clique duplo, rede que voltou) devolve
-- o que o primeiro fez em vez de cadastrar duas vezes. Unica no banco, porque
-- dois POSTs simultaneos leriam "chave nunca vista" ao mesmo tempo.
ALTER TABLE `empresa`
    ADD COLUMN `fechamento_chave` VARCHAR(40) NULL,
    ADD COLUMN `fechado_em` DATETIME NULL,
    ADD UNIQUE KEY `uk_empresa_fechamento_chave` (`fechamento_chave`);

COMMIT;
