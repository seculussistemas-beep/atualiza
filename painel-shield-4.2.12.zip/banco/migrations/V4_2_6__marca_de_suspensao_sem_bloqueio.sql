-- Migracao para a versao 4.2.6: a marca de suspensao que sobrou sem bloqueio
-- Data: 14/09/2026
--
-- Ate esta data o radio Liberado/Bloqueado do Contrato do cliente gravava
-- so o bloqueado, sem tocar em suspenso_em. Quem liberou um suspenso por ali
-- ficou com a loja liberada e a marca de suspensao preenchida, e a marca
-- sozinha continuou mandando: a ficha e a lista dizem Suspenso (a situacao
-- olha suspenso_em antes do bloqueado), a regua pula o cliente para sempre
-- (ela entende que ele ja esta suspenso) e um bloqueio manual posterior seria
-- lido como divida, aceitando promessa de pagamento por cima dele.
--
-- A tela deixou de criar esse estado; esta migracao limpa o que ja esta em
-- campo. Nao existe caminho legitimo para liberado com a marca preenchida:
-- quem tira a suspensao (shield_validade_liberar) apaga as duas coisas juntas.
-- So dados, sem mudanca de esquema: o BancoCompleto.sql nao muda.
UPDATE `empresa`
   SET `suspenso_em` = NULL, `suspenso_motivo` = NULL
 WHERE `suspenso_em` IS NOT NULL
   AND UPPER(COALESCE(`bloqueado`, 'N')) <> 'S';
