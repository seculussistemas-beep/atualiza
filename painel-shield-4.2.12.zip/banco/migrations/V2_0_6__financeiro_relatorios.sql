CREATE TABLE IF NOT EXISTS `financeiro_lancamentos` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tipo` VARCHAR(12) NOT NULL,
  `titulo` VARCHAR(180) NOT NULL,
  `descricao` TEXT NULL,
  `categoria` VARCHAR(80) NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'aberta',
  `valor` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `valor_pago` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `data_emissao` DATE NULL,
  `data_vencimento` DATE NULL,
  `data_pagamento` DATETIME NULL,
  `forma_pagamento` VARCHAR(30) NULL,
  `origem_tipo` VARCHAR(20) NULL,
  `origem_chave` VARCHAR(191) NULL,
  `empresa_codigo` INT(11) NULL,
  `empresa_cnpj` VARCHAR(20) NULL,
  `pedido_cod_transacao` VARCHAR(255) NULL,
  `observacao` TEXT NULL,
  `created_by` INT(11) NULL,
  `updated_by` INT(11) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_fin_tipo_status_venc` (`tipo`, `status`, `data_vencimento`),
  KEY `idx_fin_empresa` (`empresa_codigo`, `empresa_cnpj`),
  KEY `idx_fin_pedido` (`pedido_cod_transacao`),
  KEY `idx_fin_datas` (`data_emissao`, `data_pagamento`),
  UNIQUE KEY `uniq_fin_origem` (`origem_chave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `financeiro_lancamentos`
(
  `tipo`,
  `titulo`,
  `descricao`,
  `categoria`,
  `status`,
  `valor`,
  `valor_pago`,
  `data_emissao`,
  `data_vencimento`,
  `data_pagamento`,
  `forma_pagamento`,
  `origem_tipo`,
  `origem_chave`,
  `empresa_codigo`,
  `empresa_cnpj`,
  `pedido_cod_transacao`,
  `observacao`,
  `created_by`,
  `updated_by`
)
SELECT
  'receber' AS `tipo`,
  CONCAT('Pedido ', TRIM(p.`cod_transacao`)) AS `titulo`,
  'Gerado automaticamente a partir do pedido.' AS `descricao`,
  'Licenca' AS `categoria`,
  CASE
    WHEN LOWER(TRIM(COALESCE(p.`situacao`, ''))) = 'pago' THEN 'paga'
    WHEN LOWER(TRIM(COALESCE(p.`situacao`, ''))) IN ('aguardando pagamento', 'processando pagamento', 'pending', 'in_process') THEN 'processando'
    WHEN LOWER(TRIM(COALESCE(p.`situacao`, ''))) IN ('falhou', 'cancelado', 'cancelled', 'rejected') THEN 'cancelada'
    ELSE 'aberta'
  END AS `status`,
  CASE
    WHEN LOCATE(',', TRIM(COALESCE(p.`valor`, '0'))) > 0
      THEN CAST(REPLACE(REPLACE(REPLACE(TRIM(COALESCE(p.`valor`, '0')), ' ', ''), '.', ''), ',', '.') AS DECIMAL(14,2))
    ELSE CAST(REPLACE(REPLACE(TRIM(COALESCE(p.`valor`, '0')), ' ', ''), ',', '.') AS DECIMAL(14,2))
  END AS `valor`,
  CASE
    WHEN LOWER(TRIM(COALESCE(p.`situacao`, ''))) = 'pago'
      THEN CASE
        WHEN LOCATE(',', TRIM(COALESCE(p.`valor`, '0'))) > 0
          THEN CAST(REPLACE(REPLACE(REPLACE(TRIM(COALESCE(p.`valor`, '0')), ' ', ''), '.', ''), ',', '.') AS DECIMAL(14,2))
        ELSE CAST(REPLACE(REPLACE(TRIM(COALESCE(p.`valor`, '0')), ' ', ''), ',', '.') AS DECIMAL(14,2))
      END
    ELSE 0.00
  END AS `valor_pago`,
  p.`data` AS `data_emissao`,
  p.`data` AS `data_vencimento`,
  CASE
    WHEN LOWER(TRIM(COALESCE(p.`situacao`, ''))) = 'pago'
      THEN COALESCE(p.`data_pagamento`, CONCAT(p.`data`, ' 00:00:00'))
    ELSE NULL
  END AS `data_pagamento`,
  COALESCE(NULLIF(TRIM(p.`metodo_pagamento`), ''), NULLIF(TRIM(p.`gateway_nome`), '')) AS `forma_pagamento`,
  'pedido' AS `origem_tipo`,
  CONCAT('pedido:', TRIM(p.`cod_transacao`)) AS `origem_chave`,
  e.`codigo` AS `empresa_codigo`,
  p.`cnpj` AS `empresa_cnpj`,
  p.`cod_transacao` AS `pedido_cod_transacao`,
  NULL AS `observacao`,
  NULL AS `created_by`,
  NULL AS `updated_by`
FROM `pedido` p
LEFT JOIN `empresa` e ON e.`cnpj` = p.`cnpj`
WHERE TRIM(COALESCE(p.`cod_transacao`, '')) <> ''
ON DUPLICATE KEY UPDATE
  `tipo` = VALUES(`tipo`),
  `titulo` = VALUES(`titulo`),
  `descricao` = VALUES(`descricao`),
  `categoria` = VALUES(`categoria`),
  `status` = VALUES(`status`),
  `valor` = VALUES(`valor`),
  `valor_pago` = VALUES(`valor_pago`),
  `data_emissao` = VALUES(`data_emissao`),
  `data_vencimento` = VALUES(`data_vencimento`),
  `data_pagamento` = VALUES(`data_pagamento`),
  `forma_pagamento` = VALUES(`forma_pagamento`),
  `origem_tipo` = VALUES(`origem_tipo`),
  `empresa_codigo` = VALUES(`empresa_codigo`),
  `empresa_cnpj` = VALUES(`empresa_cnpj`),
  `pedido_cod_transacao` = VALUES(`pedido_cod_transacao`),
  `observacao` = VALUES(`observacao`),
  `updated_by` = VALUES(`updated_by`),
  `updated_at` = CURRENT_TIMESTAMP;
