ALTER TABLE `representante`
  ADD COLUMN `email` varchar(255) DEFAULT NULL,
  ADD COLUMN `senha_hash` varchar(255) DEFAULT NULL,
  ADD COLUMN `perm_editar_clientes` tinyint(1) NOT NULL DEFAULT 0,
  ADD COLUMN `perm_editar_validade_licenca` tinyint(1) NOT NULL DEFAULT 0,
  ADD COLUMN `perm_editar_nterminais` tinyint(1) NOT NULL DEFAULT 0,
  ADD COLUMN `perm_editar_bloqueio` tinyint(1) NOT NULL DEFAULT 0,
  ADD COLUMN `updated_at` datetime DEFAULT NULL;

ALTER TABLE `usuario`
  ADD COLUMN `representante_id` int(11) DEFAULT NULL;

ALTER TABLE `usuario`
  ADD KEY `idx_usuario_representante_id` (`representante_id`);

UPDATE `usuario` u
JOIN `representante` r ON r.cnpj = u.cnpj
SET u.representante_id = r.id
WHERE TRIM(u.acesso) = '2'
  AND (u.representante_id IS NULL OR u.representante_id = 0);
