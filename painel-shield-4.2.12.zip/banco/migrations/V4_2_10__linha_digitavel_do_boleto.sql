-- A linha digitavel do boleto em coluna propria -- 17/09/2026.
--
-- `copia_e_cola` guardava ora o PIX, ora a linha do boleto. No boleto hibrido
-- (Cora, Inter, C6, Asaas com chave PIX) os dois existem: o PIX vai no copia e
-- cola, que o ERP desenha como QR, e a linha ficava sem lugar -- o cliente que
-- quisesse pagar o boleto no banco nao tinha o que copiar. Nasce vazia; a
-- emissao grava daqui em diante, e a consulta preenche a das cobrancas que ja
-- estao na rua quando o provedor devolve a linha na consulta.
--
-- A tentativa nasce na V3_0_1, e nao na baseline: o BancoCompleto.sql nao muda.
ALTER TABLE `cobranca_tentativa`
    ADD COLUMN `linha_digitavel` VARCHAR(60) NULL DEFAULT NULL
    COMMENT 'linha digitavel do boleto, so digitos; o PIX fica em copia_e_cola'
    AFTER `copia_e_cola`;
