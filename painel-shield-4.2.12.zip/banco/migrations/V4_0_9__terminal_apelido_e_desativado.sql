-- Migracao para a versao 4.0.9: apelido e desativacao do terminal
-- Data: 09/09/2026
-- Autor: lojadev
--
-- Duas faltas que o dono do produto apontou olhando a tela de terminais:
-- "nao da para dizer qual maquina e qual" e "trocar de maquina nao tem
-- caminho".
--
-- ------------------------------------------------------------------- apelido
--
-- COLUNA PROPRIA, e nao reaproveitar NOME_COMPUTADOR. Aquele campo e
-- SOBRESCRITO a cada batida pelos dois lados -- por
-- shield_licenca_reconciliar_terminal aqui e pelo ConciliarTerminal do ERP
-- (Model/uDadosWeb.pas) la --, entao o que o membro digitasse sumiria na
-- proxima abertura de caixa. O nome da maquina e do computador; o apelido e do
-- membro, e ninguem mais escreve nele.
--
-- O MAC e o NOME_COMPUTADOR ficam onde estao. O apelido soma, nao substitui:
-- na hora do chamado, "Caixa 2" identifica para o cliente e o MAC identifica
-- para quem for conferir.
ALTER TABLE `terminais`
    ADD COLUMN `APELIDO` VARCHAR(40) NULL AFTER `NOME_COMPUTADOR`;

COMMIT;

-- --------------------------------------------------------------- desativacao
--
-- O ATALHO QUE FALTAVA. A regra dos 30 dias ja devolve sozinha a vaga de quem
-- parou de dar sinal -- e ela e o "esquema inteligente" que resolve a troca de
-- maquina. O que nao existia era o caminho para quem NAO quer esperar um mes:
-- o cliente comprou um PC novo hoje, o velho queimou hoje, e a vaga so vaga em
-- trinta dias.
--
-- Ate aqui a unica saida era APAGAR a linha do terminal velho, e apagar leva
-- junto o historico daquela maquina.
--
-- DESATIVAR NAO E APAGAR: a linha fica, com a data e quem desativou. Terminal
-- desativado nao ocupa vaga e nao recebe licenca; se voltar a bater, a resposta
-- diz por que -- e a volta e decisao de gente, nunca automatica. Sem isso, a
-- maquina que o membro desativou de proposito se reativaria sozinha na primeira
-- vez que alguem a ligasse para copiar um arquivo.
ALTER TABLE `terminais`
    ADD COLUMN `DESATIVADO_EM` DATETIME NULL,
    ADD COLUMN `DESATIVADO_POR` VARCHAR(80) NULL;

COMMIT;

-- A cota le esta coluna em toda batida de todo caixa do parque.
ALTER TABLE `terminais`
    ADD INDEX `ix_terminais_ativos` (`FK_EMPRESA`, `DESATIVADO_EM`);

COMMIT;
