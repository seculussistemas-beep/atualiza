-- Migracao para a versao 3.0.0: telemetria do parque
-- Data: 25/08/2026
-- Autor: lojadev
--
-- Cada instalacao do parque ja bate neste painel a cada 18 horas mandando
-- CNPJ, impressao de hardware, MAC, nome do computador e VERSAO DO EXECUTAVEL.
-- Ate aqui o painel SOBRESCREVIA o registro anterior: nao existia historico de
-- nada. O dado mais valioso que o membro tem chegava e era descartado.
--
-- Guardar as batidas responde quatro perguntas que hoje so se responde ligando
-- para o cliente: quem parou de dar sinal (terminal parado e loja parada, ou
-- maquina que morreu), quem esta em qual versao do ERP, quantos terminais de
-- verdade existem contra quantos foram contratados -- isso e receita, cliente
-- rodando cinco caixas e pagando dois aparece sozinho -- e quem pediu licenca
-- e foi recusado, e por que, que hoje so existe no error_log do servidor.
--
-- A LINHA GUARDA O RESULTADO, e nao so a visita. Batida recusada e o caso mais
-- caro de diagnosticar e o mais barato de gravar.
--
-- QUANTAS existe por causa do tamanho: num membro com 300 terminais sao
-- ~146 mil linhas por ano, e hospedagem compartilhada sente. Passados 90 dias,
-- a rotina de compactacao junta as batidas de um terminal num dia numa linha
-- so, com QUANTAS dizendo quantas foram. Detalhe recente, resumo no resto.
--
-- FK_TERMINAL aceita nulo de proposito: pedido recusado antes de casar com uma
-- maquina -- CNPJ desconhecido, documento invalido -- nao tem terminal, e e
-- justamente o que se quer enxergar.

CREATE TABLE IF NOT EXISTS terminal_batida (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    fk_empresa INT NULL,
    fk_terminal INT NULL,
    cnpj VARCHAR(20) NOT NULL,
    fingerprint VARCHAR(64) NULL,
    nome_computador VARCHAR(50) NULL,
    versao_exe VARCHAR(20) NULL,
    resultado VARCHAR(20) NOT NULL,
    motivo VARCHAR(150) NULL,
    batido_em DATETIME NOT NULL,
    dia DATE NOT NULL,
    quantas INT NOT NULL DEFAULT 1,
    KEY ix_batida_empresa (fk_empresa, batido_em),
    KEY ix_batida_terminal (fk_terminal, batido_em),
    KEY ix_batida_dia (dia),
    KEY ix_batida_resultado (resultado, batido_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;
