-- Migracao para a versao 4.2.3: a conciliacao gira a fila
-- Data: 11/09/2026
--
-- A varredura que pergunta ao provedor "esta paga?" ia por vencimento mais
-- antigo primeiro, com lote fixo. Num painel com quarenta cobrancas vencidas
-- que ninguem vai pagar, elas ocupavam o lote inteiro em TODA rodada, e a
-- cobranca que venceu ontem -- justamente a que tem chance de ja estar paga --
-- nunca era conferida. Sem processo residente, essa varredura nao e rede de
-- seguranca: e a peca principal, porque webhook se perde.
--
-- Com a data da ultima conferencia a ordem passa a ser "quem esta ha mais
-- tempo sem ser olhada", e quem nunca foi olhada vem na frente. O indice e
-- para a propria ordenacao.
ALTER TABLE `cobranca`
    ADD COLUMN `conferida_em` DATETIME NULL DEFAULT NULL,
    ADD KEY `ix_cobranca_conferida` (`conferida_em`);
