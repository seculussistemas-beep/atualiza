-- Novos campos para PagSeguro
ALTER TABLE `gateways`
    ADD COLUMN `ps_email` VARCHAR(150) NULL AFTER `public_key`,
    ADD COLUMN `ps_token` VARCHAR(200) NULL AFTER `ps_email`,
    ADD COLUMN `ps_sandbox` CHAR(1) NOT NULL DEFAULT 'n' AFTER `ps_token`;

-- Novos campos para EFI (Gerencianet)
ALTER TABLE `gateways`
    ADD COLUMN `efi_client_id` VARCHAR(200) NULL AFTER `ps_sandbox`,
    ADD COLUMN `efi_client_secret` VARCHAR(200) NULL AFTER `efi_client_id`,
    ADD COLUMN `efi_pix_cert_base64` LONGTEXT NULL AFTER `efi_client_secret`,
    ADD COLUMN `efi_pix_cert_password` VARCHAR(120) NULL AFTER `efi_pix_cert_base64`,
    ADD COLUMN `efi_pix_key` VARCHAR(200) NULL AFTER `efi_pix_cert_password`,
    ADD COLUMN `efi_sandbox` CHAR(1) NOT NULL DEFAULT 'n' AFTER `efi_pix_key`;

-- Índice auxiliar
ALTER TABLE `gateways`
    ADD INDEX `idx_gateways_name` (`gateway_name`);

-- Assegura flags de métodos
UPDATE `gateways`
SET
    `pix_ativo` = COALESCE(`pix_ativo`, 1),
    `boleto_ativo` = COALESCE(`boleto_ativo`, 1),
    `cartao_ativo` = COALESCE(`cartao_ativo`, 1);

-- Cria registros padrão se não existirem
INSERT INTO `gateways` (`gateway_name`, `active`, `producao`, `pix_ativo`, `boleto_ativo`, `cartao_ativo`, `created_at`, `updated_at`)
SELECT 'pagseguro', 0, 'n', 1, 1, 1, NOW(), NOW()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `gateways` WHERE LOWER(`gateway_name`) = 'pagseguro');

INSERT INTO `gateways` (`gateway_name`, `active`, `producao`, `pix_ativo`, `boleto_ativo`, `cartao_ativo`, `created_at`, `updated_at`)
SELECT 'efi', 0, 'n', 1, 1, 0, NOW(), NOW()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `gateways` WHERE LOWER(`gateway_name`) = 'efi');
