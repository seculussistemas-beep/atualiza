-- Migracao para a versao 3.0.1: esquema de cobranca
-- Data: 25/08/2026
-- Autor: lojadev
--
-- Tabelas NOVAS, ao lado das velhas. Nada de pedido, financeiro ou contratos e
-- derrubado aqui: remover codigo se desfaz, DROP TABLE na base do membro nao.
-- As antigas ficam orfas por um ciclo inteiro e so saem depois que ninguem
-- sentir falta.
--
-- TRES INVARIANTES ATRAVESSAM ESTE ESQUEMA:
--
--   DINHEIRO E INTEIRO EM CENTAVOS. Nunca ponto flutuante, nunca DECIMAL lido
--   como float pelo PHP. A tabela `planos` que existe hoje guarda valor em
--   VARCHAR, e e exatamente o tipo de coisa que se paga depois.
--
--   RETORNO DE PROVEDOR E DADO BRUTO GUARDADO, nao campo espalhado. Foi
--   espalhando campo de gateway na tabela do negocio que a `pedido` chegou a
--   26 colunas. Aqui o retorno inteiro vai para uma coluna de texto na
--   TENTATIVA, e a cobranca fica limpa.
--
--   TUDO QUE MEXE EM DINHEIRO, VALIDADE OU BLOQUEIO DEIXA RASTRO -- inclusive
--   quando quem mexeu foi uma rotina. E para isso que a tabela auditoria serve.
--
-- A COBRANCA NAO CONHECE FORNECEDOR. Ela tem valor, vencimento e situacao; o
-- provedor mora na TENTATIVA. E isso que deixa PIX estatico e dinheiro em
-- especie entrarem como provedores manuais sem que a tela, a regua e o
-- historico precisem saber a diferenca -- e deixa provedor novo entrar sem
-- tocar em nenhuma tabela.

-- Onde o dinheiro cai. Inclui os manuais: pix_estatico e dinheiro.
CREATE TABLE IF NOT EXISTS conta_recebimento (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    provedor VARCHAR(30) NOT NULL,
    apelido VARCHAR(80) NOT NULL,
    ambiente VARCHAR(15) NOT NULL DEFAULT 'producao',
    ativo TINYINT(1) NOT NULL DEFAULT 0,
    credenciais TEXT NULL,
    aceita_pix TINYINT(1) NOT NULL DEFAULT 0,
    aceita_boleto TINYINT(1) NOT NULL DEFAULT 0,
    aceita_cartao TINYINT(1) NOT NULL DEFAULT 0,
    aceita_assinatura TINYINT(1) NOT NULL DEFAULT 0,
    webhook_segredo VARCHAR(120) NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_conta_provedor_apelido (provedor, apelido),
    KEY ix_conta_ativo (ativo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;

-- O contrato de recorrencia. MODO decide quem gera a cobranca de cada ciclo:
-- nativa = o provedor gera e o painel acompanha; manual = o painel gera.
-- Sem este campo, cliente que troca de dinheiro para cartao recorrente no meio
-- do mes vira cobranca duplicada ou mes descoberto.
CREATE TABLE IF NOT EXISTS assinatura (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    fk_empresa INT NOT NULL,
    fk_plano INT NULL,
    fk_conta INT NULL,
    modo VARCHAR(10) NOT NULL DEFAULT 'manual',
    id_no_provedor VARCHAR(120) NULL,
    valor_centavos INT NOT NULL DEFAULT 0,
    ciclo_meses INT NOT NULL DEFAULT 1,
    dia_vencimento INT NOT NULL DEFAULT 10,
    situacao VARCHAR(20) NOT NULL DEFAULT 'ativa',
    proxima_competencia DATE NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY ix_assinatura_empresa (fk_empresa),
    KEY ix_assinatura_situacao (situacao, proxima_competencia)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;

-- A cobranca. Nao conhece fornecedor nenhum.
--
-- COMPETENCIA e a chave da geracao idempotente: a rotina que cria as cobrancas
-- do ciclo roda quantas vezes quiser sem gerar duas para o mesmo mes. Sem a
-- unicidade abaixo, dois acessos ao painel no mesmo minuto cobram o cliente
-- duas vezes -- e isso o cliente ve.
CREATE TABLE IF NOT EXISTS cobranca (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    fk_empresa INT NOT NULL,
    fk_assinatura INT NULL,
    competencia DATE NULL,
    descricao VARCHAR(150) NOT NULL,
    valor_centavos INT NOT NULL,
    vencimento DATE NOT NULL,
    situacao VARCHAR(20) NOT NULL DEFAULT 'rascunho',
    forma VARCHAR(20) NULL,
    pago_em DATETIME NULL,
    valor_pago_centavos INT NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_cobranca_competencia (fk_assinatura, competencia),
    KEY ix_cobranca_empresa (fk_empresa, vencimento),
    KEY ix_cobranca_situacao (situacao, vencimento)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;

-- Cada ida ao provedor. Uma cobranca pode ter varias -- PIX que expirou e
-- boleto emitido depois sao duas tentativas da MESMA divida.
CREATE TABLE IF NOT EXISTS cobranca_tentativa (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    fk_cobranca INT NOT NULL,
    fk_conta INT NULL,
    provedor VARCHAR(30) NOT NULL,
    id_externo VARCHAR(120) NULL,
    metodo VARCHAR(20) NULL,
    situacao_provedor VARCHAR(40) NULL,
    link_pagamento VARCHAR(500) NULL,
    copia_e_cola TEXT NULL,
    retorno LONGTEXT NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY ix_tentativa_cobranca (fk_cobranca),
    KEY ix_tentativa_externo (provedor, id_externo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;

-- Webhook DISPARA a verificacao; nao a substitui. A linha guarda o evento cru e
-- se a assinatura conferiu; quem decide se houve pagamento e a consulta ao
-- provedor, depois.
--
-- A unicidade por provedor + id do evento e a idempotencia: provedor reenvia,
-- e reenvia fora de ordem.
CREATE TABLE IF NOT EXISTS webhook_evento (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    provedor VARCHAR(30) NOT NULL,
    id_evento VARCHAR(120) NOT NULL,
    tipo VARCHAR(60) NULL,
    corpo LONGTEXT NULL,
    assinatura_confere TINYINT(1) NOT NULL DEFAULT 0,
    situacao VARCHAR(20) NOT NULL DEFAULT 'recebido',
    recebido_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    processado_em DATETIME NULL,
    UNIQUE KEY uk_webhook_evento (provedor, id_evento),
    KEY ix_webhook_situacao (situacao, recebido_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;

-- Fila EM TABELA porque nao ha processo residente na hospedagem do membro.
-- Responder rapido ao webhook e trabalhar depois: o provedor precisa do 200
-- imediato, e a consulta que confirma o pagamento pode demorar.
CREATE TABLE IF NOT EXISTS trabalho (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(40) NOT NULL,
    carga TEXT NULL,
    situacao VARCHAR(20) NOT NULL DEFAULT 'pendente',
    tentativas INT NOT NULL DEFAULT 0,
    proxima_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resultado TEXT NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY ix_trabalho_fila (situacao, proxima_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;

-- O rastro. A confirmacao manual de pagamento e o unico ponto do sistema onde
-- alguem de dentro pode dar meses de licenca sem dinheiro entrar; e a validade
-- e o que decide se a loja do cliente abre. As duas coisas passam por aqui.
--
-- ATOR aceita nulo: rotina tambem deixa rastro, e "foi a regua" e uma resposta
-- tao necessaria quanto "foi o Fulano".
CREATE TABLE IF NOT EXISTS auditoria (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ator VARCHAR(80) NULL,
    fk_usuario INT NULL,
    acao VARCHAR(60) NOT NULL,
    alvo_tipo VARCHAR(40) NULL,
    alvo_id VARCHAR(40) NULL,
    antes TEXT NULL,
    depois TEXT NULL,
    detalhe VARCHAR(255) NULL,
    ip VARCHAR(45) NULL,
    quando DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY ix_auditoria_quando (quando),
    KEY ix_auditoria_alvo (alvo_tipo, alvo_id),
    KEY ix_auditoria_acao (acao, quando)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;
