-- Migracao para a versao 4.0.8: quantos terminais o plano ja cobre
-- Data: 09/09/2026
-- Autor: lojadev
--
-- CORRIGE A BASE DA COBRANCA DO TERMINAL ADICIONAL, que a 4.0.7 tinha errado.
--
-- A 4.0.7 cobrava por maquina RECUSADA pela cota, e a conta andava para tras:
-- o membro aumentava a cota para a loja trabalhar, a maquina parava de ser
-- recusada, a recusa sumia da janela e A FATURA DIMINUIA. Liberar custava menos
-- do que barrar -- o contrario do que qualquer um espera.
--
-- SAO DOIS NUMEROS, e o painel so tinha um:
--
--   terminais_inclusos -- quantos o valor do plano ja cobre;
--   nterminais         -- quantos a licenca de fato libera.
--
-- O adicional cobrado e a diferenca. Subiu a cota, subiu a fatura; baixou,
-- baixou. E literalmente o que os membros descreveram no levantamento de
-- 08/09/2026: "o valor padrao cobre ate 3 PDVs; a partir do 4o, a gente cobra
-- um valor de PDV adicional" (Delid), "ate 3 terminais valor X, e Y valor para
-- terminal adicional" (Desenvolve), "pacote minimo de 3, cada terminal e um
-- aditivo" (flaviomotta).
--
-- A RECUSA NAO SOME DO SISTEMA -- ela deixa de ser fatura e vira AVISO DE
-- VENDA: "tem maquina batendo na porta, quer liberar?". Continua sendo contada
-- em shield_composicao_batendo_na_porta.

ALTER TABLE `empresa`
    ADD COLUMN `terminais_inclusos` INT(11) NOT NULL DEFAULT 0 AFTER `nterminais`;

COMMIT;

-- O PADRAO SEGURO: nasce igual a cota de hoje.
--
-- Assim NENHUMA fatura muda sozinha na atualizacao. Todo cliente passa a ter
-- "o plano cobre exatamente o que ele tem contratado", que e a leitura correta
-- do estado atual -- ate hoje ninguem cobrava adicional nenhum, entao tudo o
-- que ele tem esta, de fato, dentro do que ele paga.
--
-- Zero como padrao teria sido a escolha ingenua: no dia seguinte a atualizacao,
-- todo cliente com 4 terminais apareceria devendo 4 adicionais, e o membro
-- descobriria pelo telefone.
--
-- Dali em diante o membro ajusta cliente a cliente: baixa o incluso para o que
-- o plano dele realmente cobre, e a diferenca comeca a ser cobrada.
UPDATE `empresa` SET `terminais_inclusos` = COALESCE(`nterminais`, 0);

COMMIT;
