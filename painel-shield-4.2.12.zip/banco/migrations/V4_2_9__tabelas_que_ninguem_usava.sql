-- As tabelas que ninguem usava -- 17/09/2026.
--
-- Uma migracao propria, deliberada, como pede a regra de nao apagar dado de
-- membro sem decidir. Saem so as que nenhum codigo le nem grava e que nao
-- guardam registro de negocio:
--
--   client_group, client_group_plan_price e empresa.group_id -- os grupos de
--   preco. O valor por grupo so entrava no pedido que plano.php gerava, e
--   plano.php saiu. A tela de grupos seguia gravando um preco que a cobranca
--   nunca usou.
--
--   representante e usuario.representante_id -- as telas de representante
--   sairam na fase 1 e nada mais grava a tabela. A coluna
--   empresa.cnpj_representante FICA: o caminho legado do ERP a grava.
--
--   etiquetas -- da tabela de precos de etiqueta da versao 2, sem leitor. Ela
--   nasce no BancoCompleto.sql e la continua, porque a V2_0_2 a altera numa
--   instalacao nova. O que impede o /update de recria-la e
--   shield_baseline_tabelas_que_sairam (funcoes/nucleo/system_bootstrap.php).
--
-- FICAM de proposito, porque podem guardar dado de membro: tarefas, contratos,
-- config_contratos, financeiro_lancamentos, pedido e gateways (o conversor de
-- contas antigas ainda le a ultima).
--
-- O ERP nao toca nenhuma das que saem: das tabelas do painel, o caminho legado
-- e o ControleWeb Licencas so usam empresa e terminais. O indice de cada coluna
-- cai junto com ela, e o erro 1091 (coluna que ja nao existe) e tolerado.
DROP TABLE IF EXISTS `client_group_plan_price`;
DROP TABLE IF EXISTS `client_group`;
DROP TABLE IF EXISTS `representante`;
DROP TABLE IF EXISTS `etiquetas`;
ALTER TABLE `empresa` DROP COLUMN `group_id`;
ALTER TABLE `usuario` DROP COLUMN `representante_id`;
