-- Migracao para a versao 4.1.6: a senha da area do cliente
-- Data: 10/09/2026
-- Autor: lojadev
--
-- A area do cliente (funcoes/licenca/area_cliente.php) abria so por link
-- assinado. O dono do produto quis tambem uma entrada pela web, com o e-mail
-- da loja e uma senha que o membro define no fechamento. A senha fica aqui,
-- em bcrypt, na propria empresa: o cliente final nao tem conta em `usuario`,
-- e nao deve ter -- aquela tabela e de quem opera o painel.
ALTER TABLE `empresa`
    ADD COLUMN `area_senha` VARCHAR(255) NULL;

COMMIT;
