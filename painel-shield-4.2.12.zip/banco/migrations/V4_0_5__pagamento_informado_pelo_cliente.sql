-- Migracao para a versao 4.0.5: o cliente avisa, pelo ERP, que pagou
-- Data: 04/09/2026
-- Autor: lojadev
--
-- A tela de Licenca do Sistema do ERP ganhou a aba Mensalidade: o cliente ve
-- a cobranca em aberto, paga (PIX, boleto, link) e -- quando o membro recebe
-- por PIX estatico ou em dinheiro, que nao tem retorno automatico -- clica em
-- "Avisar que paguei". Esse aviso mora aqui.
--
-- E AVISO, NAO PROVA. Nada aqui muda a situacao da cobranca nem estende
-- validade: quem confirma continua sendo o membro, olhando o extrato, pela
-- confirmacao manual que ja tem permissao propria e auditoria. O que muda e
-- que a lista de cobrancas passa a mostrar quem disse que pagou, e quando --
-- em vez de o cliente mandar print no WhatsApp.
--
-- As tres sao NULL: instalacao que ainda nao recebeu o ERP novo continua
-- funcionando igual, e o endpoint de licenca detecta a ausencia das colunas e
-- responde sem elas.
--
-- MySQL nao tem IF NOT EXISTS para coluna. Rodando duas vezes, o erro 1060
-- (duplicidade) e esperado e nao quebra o roteiro.

ALTER TABLE `cobranca`
    ADD COLUMN `informado_em` DATETIME NULL,
    ADD COLUMN `informado_forma` VARCHAR(20) NULL,
    ADD COLUMN `informado_obs` VARCHAR(150) NULL;
