-- Migracao para a versao 4.1.0: o contrato novo com o ERP
-- Data: 10/09/2026
-- Autor: lojadev
--
-- O lado Delphi mandou a especificacao de quatro acrescimos a conversa entre
-- o ERP e o painel (docs/erp-aviso-de-fim-de-teste.md, "O contrato que o ERP
-- mandou"). Tres deles precisam de coluna ou tabela; o quarto (a lista de
-- todas as cobrancas em aberto) e so resposta.
--
-- ------------------------------------------------------------ modulo.chave
--
-- O ERP so obedece ao que esta DENTRO da licenca assinada, e a lista de
-- modulos vai la dentro como chaves curtas ("fiscal", "os", "boleto"). O
-- catalogo de modulos do painel (V4_0_7) tem nome e preco -- coisa de venda;
-- a chave e o que o ERP entende. Modulo sem chave e so item de fatura: nao
-- desliga nada na loja, que e o que o membro que vende "suporte premium" quer.
ALTER TABLE `modulo`
    ADD COLUMN `chave` VARCHAR(20) NULL AFTER `nome`;

COMMIT;

ALTER TABLE `modulo`
    ADD UNIQUE KEY `uk_modulo_chave` (`chave`);

COMMIT;

-- ------------------------------------------------- empresa.certificado_vence
--
-- O ERP passa a dizer, na batida, quando vence o certificado digital daquela
-- loja. E informacao de gestao: nao condiciona licenca nenhuma. Dois membros
-- pediram a coluna e o filtro; o alerta em 30/15/7/3 dias sai desta data.
ALTER TABLE `empresa`
    ADD COLUMN `certificado_vence` DATE NULL;

COMMIT;

-- ------------------------------------------------ terminais.log_pedido_pasta
--
-- O pedido de log passa a poder ser "a pasta inteira": em vez de um periodo
-- de dias, o ERP manda a pasta de logs completa daquela maquina, com todos os
-- arquivos e a estrutura por dia -- e o painel mostra como pasta, que e o que
-- o suporte entende. Flag ao lado das colunas de periodo (V3_0_4); ERP que
-- nao conhece o campo `pasta` da resposta continua mandando o periodo.
ALTER TABLE `terminais`
    ADD COLUMN `log_pedido_pasta` TINYINT(1) NOT NULL DEFAULT 0 AFTER `log_pedido_ate`;

COMMIT;

-- ------------------------------------------------------ promessa_pagamento
--
-- "Mais uns dias" para o cliente apertado, pedido pela tela do ERP
-- (liberar_confianca) ou concedido pelo painel por telefone. E UMA LINHA
-- PROPRIA, nunca uma edicao de cadastro: validade_licenca continua vencida,
-- bloqueado continua como esta, a cobranca continua na regua. O unico efeito
-- e sobre o token da proxima batida, que passa a valer ate `ate` -- e so ate
-- ele, entao a promessa se liquida sozinha, sem cron.
--
-- TABELA E NAO COLUNA, porque o que este recurso vale esta na promessa
-- anterior: "ja pediu tres vezes e pagou uma" e o que decide a quarta.
--
-- `aberta` e 1 enquanto vale e NULL depois: nulo nao conflita com nulo em
-- indice unico, e e isso que garante UMA aberta por cliente no banco -- e nao
-- no PHP, porque quem le esta linha e a batida de cada caixa, e dois pedidos
-- simultaneos leriam "nao ha promessa" ao mesmo tempo.
CREATE TABLE IF NOT EXISTS `promessa_pagamento` (
    `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `fk_empresa` INT(11) NOT NULL,
    `ate` DATE NOT NULL,
    `canal` VARCHAR(12) NOT NULL DEFAULT 'erp',
    `situacao` VARCHAR(12) NOT NULL DEFAULT 'aceita',
    `quem_pediu` VARCHAR(80) NULL,
    `ator` VARCHAR(80) NULL,
    `motivo` VARCHAR(150) NULL,
    `aberta` TINYINT(1) NULL DEFAULT 1,
    `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `fechada_em` DATETIME NULL,
    UNIQUE KEY `uk_promessa_aberta` (`fk_empresa`, `aberta`),
    KEY `ix_promessa_empresa` (`fk_empresa`, `criado_em`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;
