-- Migracao para a versao 4.2.0: a fatura da assinatura carrega os proprios meses
-- Data: 11/09/2026
--
-- Ate aqui a cobranca do ciclo nascia com meses = 1 e a ponte de pagamento
-- voltava na assinatura para ler ciclo_meses. Agora os meses viajam na
-- fatura. As que ja existiam ganham o ciclo da assinatura de hoje -- e o
-- melhor palpite que ha; a partir daqui cada fatura nova ja nasce certa.
UPDATE `cobranca` c
  JOIN `assinatura` a ON a.`id` = c.`fk_assinatura`
   SET c.`meses` = a.`ciclo_meses`
 WHERE c.`meses` < a.`ciclo_meses`;
