-- Migracao para a versao 4.0.1: "Manter conectado" de verdade
-- Data: 03/09/2026
--
-- O checkbox existia na tela de login e nao fazia nada. Agora ele grava um
-- cookie de longa duracao que recria a sessao quando a do PHP expira.
--
-- SELETOR + VALIDADOR, e nao um token so: o seletor acha a linha, o validador
-- e conferido com hash_equals contra o SHA-256 guardado aqui. Quem le a tabela
-- nao monta o cookie, e a busca nao vaza tempo de comparacao.
--
-- Uma linha por navegador lembrado, para "sair de todos os aparelhos" ser um
-- DELETE por usuario quando essa tela existir.

CREATE TABLE IF NOT EXISTS sessao_lembrada (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    fk_usuario INT NOT NULL,
    seletor CHAR(24) NOT NULL,
    validador_hash CHAR(64) NOT NULL,
    expira_em DATETIME NOT NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ultimo_uso DATETIME NULL,
    ip VARCHAR(45) NULL,
    agente VARCHAR(160) NULL,
    UNIQUE KEY ux_sessao_lembrada_seletor (seletor),
    KEY ix_sessao_lembrada_usuario (fk_usuario, expira_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

COMMIT;
