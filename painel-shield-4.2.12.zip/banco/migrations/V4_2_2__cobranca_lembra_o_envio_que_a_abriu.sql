-- Migracao para a versao 4.2.2: a cobranca lembra o envio de formulario que a abriu
-- Data: 11/09/2026
--
-- O painel nao tem POST-redirect-GET em tela nenhuma e o CSRF e por sessao,
-- reutilizavel: F5 na confirmacao de "Mudar o contrato" reenvia o mesmo corpo
-- e abria uma SEGUNDA cobranca, com a mesma descricao e o mesmo valor, tambem
-- emitida no provedor. Dois PIX iguais na mao do cliente. Na troca para
-- pre-pago era pior: a cobranca duplicada carrega `meses`, entao pagar as duas
-- dava o dobro de licenca.
--
-- E a mesma ideia de `empresa.fechamento_chave`, que protege o fechamento
-- desde 10/09/2026: a tela gera a chave uma vez, o reenvio traz a mesma, e o
-- segundo envio devolve o que o primeiro fez em vez de fazer de novo.
--
-- A chave e UNICA e aceita NULL a vontade (no MariaDB indice unico nao colide
-- com NULL): cobranca que nasce do ciclo, do fechamento ou da mao continua sem
-- chave nenhuma, como antes.
ALTER TABLE `cobranca`
    ADD COLUMN `chave_idempotencia` VARCHAR(64) NULL DEFAULT NULL,
    ADD UNIQUE KEY `uk_cobranca_chave` (`chave_idempotencia`);
