ALTER TABLE `pedido`
    ADD COLUMN `gateway_subscription_id` VARCHAR(120) NULL AFTER `gateway_external_id`,
    ADD COLUMN `recorrencia_ativa` TINYINT(1) NOT NULL DEFAULT 0 AFTER `gateway_subscription_id`,
    ADD COLUMN `proxima_cobranca_em` DATETIME NULL AFTER `pagamento_expira_em`,
    ADD INDEX `idx_pedido_gateway_subscription` (`gateway_subscription_id`);
