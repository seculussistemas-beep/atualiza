-- Migracao para a versao 4.1.8: o dinheiro em especie nasce desligado
-- Data: 10/09/2026
--
-- A V4_0_4 instalava a forma "dinheiro em especie" ja ligada, a unica que
-- nascia assim. Agora nada nasce ligado: o membro liga pelo botao da linha
-- em Formas de recebimento quando quiser oferecer. Quem ja usa continua
-- podendo ligar de volta com um clique; nada e apagado.
UPDATE `conta_recebimento` SET `ativo` = 0 WHERE `provedor` = 'dinheiro';
