-- Migracao para a versao 4.1.7: a senha temporaria da area do cliente
-- Data: 10/09/2026
-- Autor: lojadev
--
-- O membro nao digita senha para o cliente: ele clica em "Resetar senha" na
-- ficha, o painel sorteia uma, mostra uma vez, e o membro manda pelo
-- WhatsApp. Ela vale 30 dias e OBRIGA a troca no primeiro acesso -- e o que
-- faz a senha sorteada nunca virar a senha definitiva de ninguem.
ALTER TABLE `empresa`
    ADD COLUMN `area_senha_temporaria` TINYINT(1) NULL,
    ADD COLUMN `area_senha_vence` DATE NULL;

COMMIT;
