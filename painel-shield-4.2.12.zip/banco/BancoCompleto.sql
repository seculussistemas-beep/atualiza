﻿-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geraÃ§Ã£o: 27/06/2025 Ã s 19:46
-- VersÃ£o do servidor: 10.11.10-MariaDB-log
-- VersÃ£o do PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de dados: `u512569378_shield`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `empresa`
--

CREATE TABLE `empresa` (
  `codigo` int(11) NOT NULL,
  `saldo_centavos` int(11) NOT NULL DEFAULT 0,
  `cnpj` varchar(20) NOT NULL,
  `razao` varchar(50) NOT NULL,
  `endereco` varchar(50) NOT NULL,
  `cidade` varchar(35) NOT NULL,
  `bairro` varchar(35) NOT NULL,
  `cep` varchar(8) NOT NULL,
  `uf` varchar(2) NOT NULL,
  `fone` varchar(20) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `data` datetime NOT NULL DEFAULT current_timestamp(),
  `nterminais` int(11) DEFAULT NULL,
  `serial` varchar(200) DEFAULT NULL,
  `validade_licenca` date DEFAULT NULL,
  `bloqueado` varchar(1) DEFAULT NULL,
  `cnpj_representante` varchar(20) DEFAULT NULL,
  `fechamento_rascunho` text DEFAULT NULL,
  `rascunho_em` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `etiquetas`
--

CREATE TABLE `etiquetas` (
  `id` int(11) NOT NULL,
  `margem_superior` float(7,2) NOT NULL,
  `margem_lateral` float(7,2) NOT NULL,
  `densidade_vertical` int(11) NOT NULL,
  `densidade_horizontal` int(11) NOT NULL,
  `altura` float(7,2) NOT NULL,
  `largura` float(7,2) NOT NULL,
  `etiquetas_por_linha` int(11) NOT NULL,
  `linhas_por_pagina` int(11) NOT NULL,
  `codigo_etiqueta` varchar(255) NOT NULL,
  `codigo_barras` varchar(255) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `preco` float(7,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `gateways`
--

CREATE TABLE `gateways` (
  `id` int(11) NOT NULL,
  `gateway_name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `producao` char(1) NOT NULL DEFAULT 'n',
  `access_token` varchar(255) DEFAULT NULL,
  `public_key` varchar(255) DEFAULT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `client_secret` varchar(255) DEFAULT NULL,
  `wallet_id` varchar(255) DEFAULT NULL,
  `ps_email` varchar(150) DEFAULT NULL,
  `ps_token` varchar(200) DEFAULT NULL,
  `ps_sandbox` char(1) NOT NULL DEFAULT 'n',
  `efi_client_id` varchar(200) DEFAULT NULL,
  `efi_client_secret` varchar(200) DEFAULT NULL,
  `efi_pix_cert_base64` longtext DEFAULT NULL,
  `efi_pix_cert_password` varchar(120) DEFAULT NULL,
  `efi_pix_key` varchar(200) DEFAULT NULL,
  `efi_sandbox` char(1) NOT NULL DEFAULT 'n',
  `pix_ativo` tinyint(1) NOT NULL DEFAULT 0,
  `boleto_ativo` tinyint(1) NOT NULL DEFAULT 0,
  `cartao_ativo` tinyint(1) NOT NULL DEFAULT 0,
  `webhook_url` varchar(255) DEFAULT NULL,
  `webhook_token` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  UNIQUE KEY `uniq_gateway_name` (`gateway_name`),
  KEY `idx_gateways_name` (`gateway_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `gateways`
--

INSERT INTO `gateways`
(`id`, `gateway_name`, `active`, `producao`, `access_token`, `public_key`, `client_id`, `client_secret`, `wallet_id`,
 `ps_email`, `ps_token`, `ps_sandbox`, `efi_client_id`, `efi_client_secret`, `efi_pix_cert_base64`, `efi_pix_cert_password`,
 `efi_pix_key`, `efi_sandbox`, `pix_ativo`, `boleto_ativo`, `cartao_ativo`, `webhook_url`, `webhook_token`, `created_at`, `updated_at`)
VALUES
(1, 'asaas', 0, 'n', NULL, NULL, NULL, NULL, NULL,
 NULL, NULL, 'n', NULL, NULL, NULL, NULL,
 NULL, 'n', 0, 0, 0, NULL, NULL, '2025-02-10 15:18:32', '2025-06-25 18:51:30');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedido`
--

CREATE TABLE `pedido` (
  `id` int(11) NOT NULL,
  `data` date NOT NULL,
  `cod_transacao` varchar(255) NOT NULL,
  `cnpj` varchar(255) NOT NULL,
  `recorrencia` varchar(255) NOT NULL,
  `valor` varchar(255) NOT NULL,
  `situacao` varchar(255) NOT NULL,
  `gateway_nome` varchar(50) DEFAULT NULL,
  `metodo_pagamento` varchar(20) DEFAULT NULL,
  `gateway_external_id` varchar(120) DEFAULT NULL,
  `gateway_checkout_url` text DEFAULT NULL,
  `gateway_qr_code` text DEFAULT NULL,
  `gateway_qr_code_base64` longtext DEFAULT NULL,
  `gateway_boleto_url` text DEFAULT NULL,
  `gateway_status` varchar(50) DEFAULT NULL,
  `gateway_payload` longtext DEFAULT NULL,
  `data_pagamento` datetime DEFAULT NULL,
  `pagamento_expira_em` datetime DEFAULT NULL,
  `tentativa_pagamento` int NOT NULL DEFAULT 0,
  `gateway_subscription_id` varchar(120) DEFAULT NULL,
  `recorrencia_ativa` tinyint(1) DEFAULT NULL,
  `proxima_cobranca_em` datetime DEFAULT NULL,
  `gateway_invoice_url` text DEFAULT NULL,
  `gateway_invoice_pdf_url` text DEFAULT NULL,
  `gateway_invoice_number` varchar(80) DEFAULT NULL,
  `gateway_due_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `planos`
--

CREATE TABLE `planos` (
  `id` int(255) NOT NULL,
  `tipo` varchar(20) NOT NULL DEFAULT 'avulso',
  `descricao` varchar(80) NOT NULL DEFAULT '',
  `recorrencia` varchar(255) NOT NULL,
  `valor` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Nenhum plano de fabrica (17/09/2026): o preco e do membro, em Configuracoes >
-- Planos. Os quatro planos com preco que nasciam aqui apareciam em "Cobrar por"
-- de todo painel novo, e o membro nao achava onde muda-los.
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `terminais`
--

CREATE TABLE `terminais` (
  `CODIGO` int(11) NOT NULL,
  `FK_EMPRESA` int(11) NOT NULL,
  `MAC` varchar(35) NOT NULL,
  `NOME_COMPUTADOR` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `data` date NOT NULL,
  `uf` varchar(255) NOT NULL,
  `acesso` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `cnpj` varchar(255) NOT NULL,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- A TABELA `usuario` NASCE VAZIA -- 16/09/2026.
--
-- Aqui havia um INSERT com o login `admin`, acesso '1' e um bcrypt FIXO: o
-- mesmo em todo painel instalado. E este arquivo NAO e dump morto --
-- shield_parse_baseline_schema recolhe os INSERT por tabela e
-- shield_sync_missing_baseline_tables os aplica depois de criar a tabela que
-- faltava. A linha voltava ate em painel JA em uso que perdesse a tabela, com a
-- senha de fabrica e o primeiro acesso ja concluido, sem mandar ninguem de
-- volta ao setup. Quebrar aquele hash uma vez, offline, valeria para o parque
-- inteiro de membros.
--
-- Quem cria o administrador e o public/install/setup.php, com a senha que o
-- membro escolhe no primeiro acesso -- ele ja tem o ramo de INSERT para quando
-- nao existe nenhum. Coberto por tests/Unidade/SenhaDeFabricaTest.php.
--

--
-- Ãndices para tabelas despejadas
--

--
-- Ãndices de tabela `empresa`
--
ALTER TABLE `empresa`
  ADD PRIMARY KEY (`codigo`);

--
-- Ãndices de tabela `etiquetas`
--
ALTER TABLE `etiquetas`
  ADD PRIMARY KEY (`id`);

--
-- Ãndices de tabela `gateways`
--
ALTER TABLE `gateways`
  ADD PRIMARY KEY (`id`);

--
-- Ãndices de tabela `pedido`
--
ALTER TABLE `pedido`
  ADD PRIMARY KEY (`id`);

--
-- Ãndices de tabela `planos`
--
ALTER TABLE `planos`
  ADD PRIMARY KEY (`id`);

--
-- Ãndices de tabela `terminais`
--
ALTER TABLE `terminais`
  ADD PRIMARY KEY (`CODIGO`);

--
-- Ãndices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `empresa`
--
ALTER TABLE `empresa`
  MODIFY `codigo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `etiquetas`
--
ALTER TABLE `etiquetas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `gateways`
--
ALTER TABLE `gateways`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `pedido`
--
ALTER TABLE `pedido`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `planos`
--
ALTER TABLE `planos`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `terminais`
--
ALTER TABLE `terminais`
  MODIFY `CODIGO` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

