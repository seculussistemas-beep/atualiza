<?php
/**
 * ---------------------------------------------------------------------
 * Sistema de Licenca Shield
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . "/../../funcoes/contrato/assinatura_a1.php";

if ($_SESSION['usuario']['acesso'] != 1) {
    header('Location: acesso_negado.php');
    exit;
}


$softhouse_data = null;
$mensagem = '';
$avisoSalvo = '';   // sucesso: flutua no canto (funcoes/ui/aviso.php); o erro segue em $mensagem

try {
    $stmt = $pdo->query("SELECT * FROM softhouse LIMIT 1");
    $softhouse_data = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erro ao buscar dados para edicao: " . $e->getMessage());
}

$corAtual = trim((string) shield_get_system_meta($pdo, 'marca_cor', '')) ?: SHIELD_MARCA_COR_PADRAO;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($softhouse_data['id']) ? (int) $softhouse_data['id'] : null;

    $cnpj = preg_replace('/[\.\/-]/', '', $_POST['cnpj'] ?? '');
    $cep = str_replace('-', '', $_POST['cep'] ?? '');

    $razao = trim((string) ($_POST['razao'] ?? ''));
    $fantasia = trim((string) ($_POST['fantasia'] ?? ''));
    $ie = trim((string) ($_POST['ie'] ?? ''));
    $estado = strtoupper(trim((string) ($_POST['estado'] ?? '')));
    $cidade = trim((string) ($_POST['cidade'] ?? ''));
    $endereco = trim((string) ($_POST['endereco'] ?? ''));
    $numero = trim((string) ($_POST['numero'] ?? ''));
    $telefone = trim((string) ($_POST['telefone'] ?? ''));
    // O CONTATO QUE O CLIENTE FINAL VE (17/09/2026): o "Duvidas:" da area do cliente.
    $email = trim((string) ($_POST['email'] ?? ''));

    $upload = $_FILES['certificado_a1'] ?? null;
    $certPassword = (string) ($_POST['certificado_a1_senha'] ?? '');

    // A cor da marca. Ela mora no shield_system_meta e nao numa coluna da
    // softhouse porque e do PAINEL, nao da empresa: e o casco que a le, e
    // uma instalacao sem softhouse cadastrada tambem precisa de cor.
    $corMarca = trim((string) ($_POST['marca_cor'] ?? ''));
    if (preg_match('/^#[0-9a-fA-F]{6}$/', $corMarca)) {
        shield_set_system_meta($pdo, 'marca_cor', strtolower($corMarca));
    }
    $newCertProvided = is_array($upload) && ((int) ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE);

    $newRelativePath = null;
    $newCertMeta = null;
    $oldRelativePath = (string) ($softhouse_data['certificado_a1_arquivo'] ?? '');

    try {
        if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            throw new RuntimeException('O e-mail de contato precisa de @ e ponto.');
        }
        if ($newCertProvided) {
            if (trim($certPassword) === '') {
                throw new RuntimeException('Informe a senha do certificado A1 para concluir o upload.');
            }

            $binary = shield_a1_read_uploaded_binary($upload);
            $newCertMeta = shield_a1_parse_pkcs12($binary, $certPassword);
            $newRelativePath = shield_a1_store_uploaded_file($upload);
            $encryptedPassword = shield_encrypt_secret($certPassword);
        }

        if ($id) {
            if ($newCertProvided && $newCertMeta !== null) {
                $sql = "UPDATE softhouse SET cnpj = ?, razao = ?, fantasia = ?, ie = ?, estado = ?, cidade = ?, endereco = ?, numero = ?, cep = ?, telefone = ?, email = ?,
                        certificado_a1_arquivo = ?, certificado_a1_senha_enc = ?, certificado_a1_thumbprint = ?, certificado_a1_serial = ?,
                        certificado_a1_titular = ?, certificado_a1_validade_inicio = ?, certificado_a1_validade_fim = ?, certificado_a1_atualizado_em = NOW()
                        WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    $cnpj,
                    $razao,
                    $fantasia,
                    $ie,
                    $estado,
                    $cidade,
                    $endereco,
                    $numero,
                    $cep,
                    $telefone,
                    $email,
                    $newRelativePath,
                    $encryptedPassword,
                    $newCertMeta['thumbprint'],
                    $newCertMeta['serial'],
                    $newCertMeta['subject_display'],
                    $newCertMeta['valid_from_db'],
                    $newCertMeta['valid_to_db'],
                    $id,
                ]);
            } else {
                $sql = "UPDATE softhouse SET cnpj = ?, razao = ?, fantasia = ?, ie = ?, estado = ?, cidade = ?, endereco = ?, numero = ?, cep = ?, telefone = ?, email = ? WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$cnpj, $razao, $fantasia, $ie, $estado, $cidade, $endereco, $numero, $cep, $telefone, $email, $id]);
            }
        } else {
            if ($newCertProvided && $newCertMeta !== null) {
                $sql = "INSERT INTO softhouse (
                            cnpj, razao, fantasia, ie, estado, cidade, endereco, numero, cep, telefone, email,
                            certificado_a1_arquivo, certificado_a1_senha_enc, certificado_a1_thumbprint, certificado_a1_serial,
                            certificado_a1_titular, certificado_a1_validade_inicio, certificado_a1_validade_fim, certificado_a1_atualizado_em
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    $cnpj,
                    $razao,
                    $fantasia,
                    $ie,
                    $estado,
                    $cidade,
                    $endereco,
                    $numero,
                    $cep,
                    $telefone,
                    $email,
                    $newRelativePath,
                    $encryptedPassword,
                    $newCertMeta['thumbprint'],
                    $newCertMeta['serial'],
                    $newCertMeta['subject_display'],
                    $newCertMeta['valid_from_db'],
                    $newCertMeta['valid_to_db'],
                ]);
            } else {
                $sql = "INSERT INTO softhouse (cnpj, razao, fantasia, ie, estado, cidade, endereco, numero, cep, telefone, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$cnpj, $razao, $fantasia, $ie, $estado, $cidade, $endereco, $numero, $cep, $telefone, $email]);
            }
        }

        if ($newCertProvided && $newRelativePath !== null && $oldRelativePath !== '') {
            shield_a1_remove_file($oldRelativePath);
        }

        $avisoSalvo = 'Dados salvos com sucesso.';
        $stmt = $pdo->query("SELECT * FROM softhouse LIMIT 1");
        $softhouse_data = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        if ($newRelativePath !== null) {
            shield_a1_remove_file($newRelativePath);
        }
        $mensagem = '<div class="alert alert-danger">Erro ao salvar os dados: ' . shield_h($e->getMessage()) . '</div>';
    }
}

$certStatus = shield_a1_status($softhouse_data['certificado_a1_validade_fim'] ?? null);
$certFileName = '';
if (!empty($softhouse_data['certificado_a1_arquivo'])) {
    $certFileName = basename((string) $softhouse_data['certificado_a1_arquivo']);
}
$runtimeValidation = shield_a1_runtime_validation(is_array($softhouse_data) ? $softhouse_data : []);
$runtimeClassMap = [
    'cert_ok' => 'success',
    'cert_required' => 'secondary',
    'cert_secret_missing' => 'warning',
    'cert_file_missing' => 'danger',
    'cert_crypto_mismatch' => 'danger',
    'cert_password_invalid' => 'danger',
    'cert_parse_error' => 'danger',
    'cert_expired' => 'danger',
];
$runtimeClass = $runtimeClassMap[$runtimeValidation['code']] ?? 'secondary';
$rotulosCert = [
    'cert_ok' => 'Certificado valido',
    'cert_required' => 'Nenhum certificado enviado',
    'cert_secret_missing' => 'Senha do certificado ausente',
    'cert_file_missing' => 'Arquivo do certificado nao encontrado',
    'cert_crypto_mismatch' => 'Chave do cofre nao bate com o certificado',
    'cert_password_invalid' => 'Senha do certificado invalida',
    'cert_parse_error' => 'Arquivo do certificado ilegivel',
    'cert_expired' => 'Certificado vencido',
];
$pilulaCert = ['success' => 'pilula-ok', 'secondary' => 'pilula-neutro', 'warning' => 'pilula-atencao', 'danger' => 'pilula-erro'][$runtimeClass] ?? 'pilula-neutro';
$ufs = ['AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR',
        'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'];
$ufAtual = strtoupper(trim((string) ($softhouse_data['estado'] ?? '')));
$cnpjAtual = preg_replace('/\D/', '', (string) ($softhouse_data['cnpj'] ?? ''));
if (strlen($cnpjAtual) === 14) {
    $cnpjAtual = preg_replace('/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/', '$1.$2.$3/$4-$5', $cnpjAtual);
}
$cepAtual = preg_replace('/\D/', '', (string) ($softhouse_data['cep'] ?? ''));
if (strlen($cepAtual) === 8) {
    $cepAtual = substr($cepAtual, 0, 5) . '-' . substr($cepAtual, 5);
}
?>
  <?php include __DIR__ . '/../../templates/estrutura.php'; ?>

  <div class="container-fluid">
    <div class="topo-tela">
      <div>
        <h1 class="h4 mb-1">Minha empresa</h1>
        <p class="text-secondary small mb-0">O que o cliente v&ecirc; na cobran&ccedil;a e no e-mail: nome, endere&ccedil;o e a sua cor.</p>
      </div>
      <a href="/softhouse.php" class="btn btn-outline-secondary btn-sm">Voltar</a>
    </div>

    <?php shield_aviso_flutuante($avisoSalvo); ?>
    <?= $mensagem; ?>

    <form action="editar_softhouse.php" method="POST" enctype="multipart/form-data" class="empresa-form" novalidate>
      <section class="card">
        <div class="card-header"><strong>Empresa</strong></div>
        <div class="card-body">
          <div class="row g-3">
            <div class="col-12 col-md-5">
              <label for="cnpj" class="form-label">CNPJ</label>
              <div class="entrada-api" id="cnpjCaixa">
                <input type="text" class="form-control" id="cnpj" name="cnpj" inputmode="numeric" placeholder="00.000.000/0001-00" value="<?= shield_h($cnpjAtual); ?>" maxlength="18" required autocomplete="off">
                <span class="api-giro" aria-hidden="true"></span>
                <button type="button" class="api-botao" id="btBuscarCnpj" title="Preencher pela Receita Federal">Buscar</button>
              </div>
              <div class="form-text api-nota" id="cnpjNota">Digite o CNPJ e clique em Buscar: o painel preenche o resto pela Receita Federal.</div>
            </div>
            <div class="col-12 col-md-7">
              <label for="razao" class="form-label">Raz&atilde;o social</label>
              <input type="text" class="form-control" id="razao" name="razao" value="<?= shield_h($softhouse_data['razao'] ?? ''); ?>" maxlength="255" required>
            </div>
            <div class="col-12 col-md-7">
              <label for="fantasia" class="form-label">Nome fantasia</label>
              <input type="text" class="form-control" id="fantasia" name="fantasia" value="<?= shield_h($softhouse_data['fantasia'] ?? ''); ?>" maxlength="255">
              <div class="form-text">&Eacute; o nome que aparece no painel e no e-mail do cliente.</div>
            </div>
            <div class="col-12 col-md-5">
              <label for="ie" class="form-label">Inscri&ccedil;&atilde;o estadual <span class="text-secondary fw-normal">(opcional)</span></label>
              <input type="text" class="form-control" id="ie" name="ie" value="<?= shield_h($softhouse_data['ie'] ?? ''); ?>" maxlength="20">
            </div>
            <div class="col-12 col-md-4">
              <label for="telefone" class="form-label">Telefone <span class="text-secondary fw-normal">(opcional)</span></label>
              <input type="text" class="form-control" id="telefone" name="telefone" inputmode="tel" placeholder="(00) 00000-0000" value="<?= shield_h($softhouse_data['telefone'] ?? ''); ?>" maxlength="20">
            </div>
            <div class="col-12 col-md-8">
              <label for="email" class="form-label">E-mail de contato <span class="text-secondary fw-normal">(opcional)</span></label>
              <input type="email" class="form-control" id="email" name="email" placeholder="suporte@suaempresa.com.br" value="<?= shield_h($softhouse_data['email'] ?? ''); ?>" maxlength="255" autocomplete="email">
              <div class="form-text">O cliente v&ecirc; o telefone e este e-mail na &aacute;rea do cliente, em D&uacute;vidas.</div>
            </div>
          </div>
        </div>
      </section>

      <section class="card">
        <div class="card-header"><strong>Endere&ccedil;o</strong></div>
        <div class="card-body">
          <div class="row g-3">
            <div class="col-12 col-md-3">
              <label for="cep" class="form-label">CEP</label>
              <div class="entrada-api" id="cepCaixa">
                <input type="text" class="form-control" id="cep" name="cep" inputmode="numeric" placeholder="00000-000" value="<?= shield_h($cepAtual); ?>" maxlength="9" required autocomplete="postal-code">
                <span class="api-giro" aria-hidden="true"></span>
              </div>
              <div class="form-text api-nota" id="cepNota">Com os 8 n&uacute;meros, o endere&ccedil;o vem sozinho.</div>
            </div>
            <div class="col-12 col-md-7">
              <label for="endereco" class="form-label">Endere&ccedil;o</label>
              <input type="text" class="form-control" id="endereco" name="endereco" value="<?= shield_h($softhouse_data['endereco'] ?? ''); ?>" maxlength="255" required autocomplete="street-address">
            </div>
            <div class="col-12 col-md-2">
              <label for="numero" class="form-label">N&uacute;mero</label>
              <input type="text" class="form-control" id="numero" name="numero" value="<?= shield_h($softhouse_data['numero'] ?? ''); ?>" maxlength="10" required>
            </div>
            <div class="col-12 col-md-8">
              <label for="cidade" class="form-label">Cidade</label>
              <input type="text" class="form-control" id="cidade" name="cidade" value="<?= shield_h($softhouse_data['cidade'] ?? ''); ?>" maxlength="255" required autocomplete="address-level2">
            </div>
            <div class="col-12 col-md-4">
              <label for="estado" class="form-label">UF</label>
              <select class="form-select" id="estado" name="estado" required>
                <option value="">&mdash;</option>
                <?php foreach ($ufs as $sigla): ?>
                  <option value="<?= $sigla; ?>"<?= $ufAtual === $sigla ? ' selected' : ''; ?>><?= $sigla; ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </div>
      </section>

      <section class="card">
        <div class="card-header"><strong>A sua cor</strong></div>
        <div class="card-body">
          <div class="row g-3 align-items-center">
            <div class="col-12 col-md-7">
              <p class="text-secondary small mb-0">
                &Eacute; ela que pinta bot&otilde;es e links do painel. O cliente final v&ecirc; o seu nome e a sua
                cor &mdash; n&atilde;o os nossos. Pago, vencido e suspenso continuam com cores pr&oacute;prias,
                para n&atilde;o mudarem de significado junto.
              </p>
            </div>
            <div class="col-12 col-md-5">
              <div class="cor-marca ms-md-auto">
                <label for="marca_cor" class="form-label mb-1">Cor da marca</label>
                <div class="cor-marca-linha">
                  <input type="color" class="form-control form-control-color" id="marca_cor" name="marca_cor" value="<?= htmlspecialchars($corAtual, ENT_QUOTES, 'UTF-8'); ?>" title="Escolher a cor">
                  <code id="marcaCorHex"><?= htmlspecialchars($corAtual, ENT_QUOTES, 'UTF-8'); ?></code>
                  <span class="btn btn-sm cor-marca-amostra" id="marcaCorAmostra" aria-hidden="true">Assim fica o bot&atilde;o</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="card">
        <div class="card-header d-flex align-items-center justify-content-between gap-2">
          <strong>Certificado A1</strong>
          <span class="pilula ms-auto <?= $pilulaCert; ?>"><?= shield_h($rotulosCert[$runtimeValidation['code']] ?? $runtimeValidation['code']); ?></span>
        </div>
        <div class="card-body">
          <p class="text-secondary small mb-3"><?= shield_h($runtimeValidation['message']); ?></p>
          <?php if (!empty($softhouse_data['certificado_a1_arquivo'])): ?>
            <dl class="perfil-lista mb-3">
              <dt>Arquivo</dt><dd><?= shield_h($certFileName); ?></dd>
              <dt>Titular</dt><dd><?= shield_h($softhouse_data['certificado_a1_titular'] ?? 'N/D'); ?></dd>
              <dt>Validade</dt>
              <dd>
                <?= shield_h(shield_format_datetime_br($softhouse_data['certificado_a1_validade_inicio'] ?? null)); ?>
                at&eacute; <?= shield_h(shield_format_datetime_br($softhouse_data['certificado_a1_validade_fim'] ?? null)); ?>
                <span class="pilula pilula-<?= $certStatus['class'] === 'success' ? 'ok' : ($certStatus['class'] === 'warning' ? 'atencao' : ($certStatus['class'] === 'danger' ? 'erro' : 'neutro')); ?> ms-2"><?= shield_h($certStatus['label']); ?><?= $certStatus['days'] !== null ? ' · ' . (int) $certStatus['days'] . ' dias' : ''; ?></span>
              </dd>
            </dl>
            <p class="text-secondary small">Para trocar, envie o arquivo novo e a senha dele.</p>
          <?php endif; ?>
          <div class="row g-3">
            <div class="col-12 col-md-7">
              <label for="certificado_a1" class="form-label">Arquivo .pfx ou .p12 <span class="text-secondary fw-normal">(at&eacute; 5 MB)</span></label>
              <input type="file" class="form-control" id="certificado_a1" name="certificado_a1" accept=".pfx,.p12">
            </div>
            <div class="col-12 col-md-5">
              <label for="certificado_a1_senha" class="form-label">Senha do certificado</label>
              <input type="password" class="form-control" id="certificado_a1_senha" name="certificado_a1_senha" autocomplete="new-password" placeholder="Obrigat&oacute;ria ao enviar arquivo novo">
            </div>
          </div>
        </div>
      </section>

      <div class="empresa-acoes">
        <button type="submit" class="btn btn-primary"><i class="fas fa-save me-1"></i>Salvar altera&ccedil;&otilde;es</button>
        <a href="/softhouse.php" class="btn btn-outline-secondary">Voltar</a>
      </div>
    </form>
  </div>

  <script>
  (function () {
    var $ = function (id) { return document.getElementById(id); };
    var so = function (s) { return String(s || '').replace(/\D/g, ''); };

    // Mascaras enquanto digita.
    $('cnpj').addEventListener('input', function () {
      var d = so(this.value).slice(0, 14), f = d;
      if (d.length > 2) f = d.slice(0, 2) + '.' + d.slice(2);
      if (d.length > 5) f = f.slice(0, 6) + '.' + d.slice(5);
      if (d.length > 8) f = f.slice(0, 10) + '/' + d.slice(8);
      if (d.length > 12) f = f.slice(0, 15) + '-' + d.slice(12);
      this.value = f;
      // So busca pelo botao: digitar nao dispara consulta.
      if (d.length !== 14) { ultimoCnpj = ''; }
    });
    $('cep').addEventListener('input', function () {
      var d = so(this.value).slice(0, 8);
      this.value = d.length > 5 ? d.slice(0, 5) + '-' + d.slice(5) : d;
      if (d.length === 8) { buscarCep(); }
    });
    $('telefone').addEventListener('input', function () {
      var d = so(this.value).slice(0, 11), f = d;
      if (d.length > 2) f = '(' + d.slice(0, 2) + ') ' + d.slice(2);
      if (d.length > 6) f = f.replace(/(\d{4,5})(\d{4})$/, '$1-$2');
      this.value = f;
    });

    // O estado de "buscando": giro no campo, nota embaixo, campo travado.
    function estado(caixa, nota, carregando, texto, classe) {
      $(caixa).classList.toggle('carregando', !!carregando);
      var n = $(nota);
      n.textContent = texto;
      n.className = 'form-text api-nota' + (classe ? ' ' + classe : '');
    }
    function preencher(id, valor) {
      if (valor === undefined || valor === null || valor === '') return;
      var el = $(id);
      el.value = String(valor);
      el.classList.add('preenchido-api');
      setTimeout(function () { el.classList.remove('preenchido-api'); }, 1600);
    }

    var buscandoCnpj = false, ultimoCnpj = '';
    function buscarCnpj() {
      var d = so($('cnpj').value);
      if (d.length !== 14 || buscandoCnpj || d === ultimoCnpj) return;
      buscandoCnpj = true;
      estado('cnpjCaixa', 'cnpjNota', true, 'Buscando na Receita Federal…');
      // A resposta costuma chegar em 200 ms, rapido demais para a pessoa
      // perceber que houve busca. Segura o giro por pelo menos 900 ms.
      var minimo = new Promise(function (ok) { setTimeout(ok, 900); });
      // A consulta vai pelo SERVIDOR (ajax_consulta.php), que tenta tres
      // fontes em cascata. O navegador nao fala com site externo nenhum.
      Promise.all([
        fetch('/ajax_consulta.php?tipo=cnpj&valor=' + d, { credentials: 'same-origin' })
          .then(function (r) { return r.json(); })
          .then(function (j) { if (!j || !j.ok) throw new Error((j && j.erro) || 'A consulta falhou.'); return j; }),
        minimo
      ])
        .then(function (res) { return res[0]; })
        .then(function (j) {
          var e = j.dados;
          ultimoCnpj = d;
          preencher('razao', e.razao);
          preencher('fantasia', e.fantasia);
          preencher('telefone', e.telefone);
          if (e.cep) { $('cep').value = e.cep; }
          preencher('endereco', e.endereco);
          preencher('numero', e.numero);
          preencher('cidade', e.cidade);
          if (e.uf) { $('estado').value = e.uf; }
          estado('cnpjCaixa', 'cnpjNota', false, 'Preenchido pela ' + j.fonte + '. Confira e ajuste o que precisar.', 'text-success');
        })
        .catch(function (erro) {
          estado('cnpjCaixa', 'cnpjNota', false, erro.message + ' Você pode preencher à mão.', 'text-danger');
        })
        .finally(function () { buscandoCnpj = false; });
    }
    $('btBuscarCnpj').addEventListener('click', function () { ultimoCnpj = ''; buscarCnpj(); });

    var buscandoCep = false, ultimoCep = '';
    function buscarCep() {
      var d = so($('cep').value);
      if (d.length !== 8 || buscandoCep || d === ultimoCep) return;
      buscandoCep = true;
      estado('cepCaixa', 'cepNota', true, 'Buscando o endereço…');
      var minimo = new Promise(function (ok) { setTimeout(ok, 700); });
      Promise.all([
        fetch('/ajax_consulta.php?tipo=cep&valor=' + d, { credentials: 'same-origin' })
          .then(function (r) { return r.json(); })
          .then(function (j) { if (!j || !j.ok) throw new Error((j && j.erro) || 'A consulta falhou.'); return j; }),
        minimo
      ])
        .then(function (res) { return res[0]; })
        .then(function (j) {
          var e = j.dados;
          ultimoCep = d;
          preencher('endereco', e.endereco);
          preencher('cidade', e.cidade);
          if (e.uf) { $('estado').value = e.uf; }
          estado('cepCaixa', 'cepNota', false, 'Endereço preenchido pelo ' + j.fonte + '. Falta só o número.', 'text-success');
          $('numero').focus();
        })
        .catch(function (erro) {
          estado('cepCaixa', 'cepNota', false, erro.message + ' Você pode preencher à mão.', 'text-danger');
        })
        .finally(function () { buscandoCep = false; });
    }

    // A cor: o codigo e a amostra acompanham o seletor.
    var cor = $('marca_cor');
    function pintar() {
      $('marcaCorHex').textContent = cor.value;
      $('marcaCorAmostra').style.background = cor.value;
      $('marcaCorAmostra').style.borderColor = cor.value;
    }
    cor.addEventListener('input', pintar);
    pintar();
  })();
  </script>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
