<?php

// Consulta de CNPJ e CEP pelo SERVIDOR -- 04/09/2026.
//
// Antes o navegador chamava a BrasilAPI e o ViaCEP direto, e quebrava com
// "Failed to fetch": bloqueador de anuncio, proxy da empresa, CSP do painel
// -- qualquer um dos tres derruba uma chamada para fora feita pela pagina.
// Pelo servidor a chamada e uma so, same-origin, e o painel decide a fonte.
//
// VARIAS FONTES EM CASCATA: a primeira que responder bem vence. Servico
// gratuito de consulta cai, muda de endereco e limita requisicao; depender de
// um so e ter a tela quebrada no dia em que ele sair do ar.
//
// So administrador logado: e ele quem edita a empresa.

require_once __DIR__ . '/../../funcoes/nucleo/sessao.php'; shield_sessao_abrir();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario']['login']) || (string) ($_SESSION['usuario']['acesso'] ?? '') !== '1') {
    http_response_code(403);
    echo json_encode(['ok' => false, 'erro' => 'Sem permissao.']);
    exit;
}

$tipo = (string) ($_GET['tipo'] ?? '');
$valor = preg_replace('/\D/', '', (string) ($_GET['valor'] ?? ''));

/** GET com timeout curto. Devolve o JSON decodificado ou null. */
function shield_consulta_get($url, $timeout = 6)
{
    $corpo = false;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_HTTPHEADER => ['Accept: application/json', 'User-Agent: PainelShield/4 (+consulta cadastral)'],
        ]);
        $corpo = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($corpo === false || $status < 200 || $status >= 300) {
            return null;
        }
    } else {
        $ctx = stream_context_create(['http' => ['timeout' => $timeout, 'header' => "Accept: application/json\r\nUser-Agent: PainelShield/4\r\n", 'ignore_errors' => true]]);
        $corpo = @file_get_contents($url, false, $ctx);
        if ($corpo === false) {
            return null;
        }
    }

    $dados = json_decode((string) $corpo, true);

    return is_array($dados) ? $dados : null;
}

function shield_titulo($s)
{
    return mb_convert_case(mb_strtolower(trim((string) $s), 'UTF-8'), MB_CASE_TITLE, 'UTF-8');
}

function shield_telefone_br($t)
{
    $d = preg_replace('/\D/', '', (string) $t);
    if (strlen($d) < 10) {
        return '';
    }
    $d = substr($d, 0, 11);

    return '(' . substr($d, 0, 2) . ') ' . preg_replace('/(\d{4,5})(\d{4})$/', '$1-$2', substr($d, 2));
}

function shield_cep_br($c)
{
    $d = preg_replace('/\D/', '', (string) $c);

    return strlen($d) === 8 ? substr($d, 0, 5) . '-' . substr($d, 5) : '';
}

if ($tipo === 'cnpj') {
    if (strlen($valor) !== 14) {
        echo json_encode(['ok' => false, 'erro' => 'CNPJ precisa ter 14 numeros.']);
        exit;
    }

    $fontes = [
        'BrasilAPI' => function ($cnpj) {
            $e = shield_consulta_get('https://brasilapi.com.br/api/cnpj/v1/' . $cnpj);
            if (!$e || empty($e['razao_social'])) {
                return null;
            }

            return [
                'razao' => (string) $e['razao_social'],
                'fantasia' => (string) ($e['nome_fantasia'] ?? ''),
                'telefone' => shield_telefone_br($e['ddd_telefone_1'] ?? ''),
                'cep' => shield_cep_br($e['cep'] ?? ''),
                'endereco' => trim(($e['descricao_tipo_de_logradouro'] ?? '') . ' ' . ($e['logradouro'] ?? '')),
                'numero' => (string) ($e['numero'] ?? ''),
                'cidade' => shield_titulo($e['municipio'] ?? ''),
                'uf' => strtoupper((string) ($e['uf'] ?? '')),
            ];
        },
        'ReceitaWS' => function ($cnpj) {
            $e = shield_consulta_get('https://receitaws.com.br/v1/cnpj/' . $cnpj);
            if (!$e || ($e['status'] ?? '') === 'ERROR' || empty($e['nome'])) {
                return null;
            }

            return [
                'razao' => (string) $e['nome'],
                'fantasia' => (string) ($e['fantasia'] ?? ''),
                'telefone' => shield_telefone_br(strtok((string) ($e['telefone'] ?? ''), '/')),
                'cep' => shield_cep_br($e['cep'] ?? ''),
                'endereco' => trim((string) ($e['logradouro'] ?? '')),
                'numero' => (string) ($e['numero'] ?? ''),
                'cidade' => shield_titulo($e['municipio'] ?? ''),
                'uf' => strtoupper((string) ($e['uf'] ?? '')),
            ];
        },
        'CNPJ.ws' => function ($cnpj) {
            $e = shield_consulta_get('https://publica.cnpj.ws/cnpj/' . $cnpj);
            if (!$e || empty($e['razao_social'])) {
                return null;
            }
            $est = $e['estabelecimento'] ?? [];

            return [
                'razao' => (string) $e['razao_social'],
                'fantasia' => (string) ($est['nome_fantasia'] ?? ''),
                'telefone' => shield_telefone_br(($est['ddd1'] ?? '') . ($est['telefone1'] ?? '')),
                'cep' => shield_cep_br($est['cep'] ?? ''),
                'endereco' => trim(($est['tipo_logradouro'] ?? '') . ' ' . ($est['logradouro'] ?? '')),
                'numero' => (string) ($est['numero'] ?? ''),
                'cidade' => shield_titulo($est['cidade']['nome'] ?? ''),
                'uf' => strtoupper((string) ($est['estado']['sigla'] ?? '')),
            ];
        },
    ];

    $tentadas = [];
    foreach ($fontes as $nome => $buscar) {
        try {
            $dados = $buscar($valor);
        } catch (Throwable $ignorado) {
            $dados = null;
        }
        $tentadas[] = $nome;
        if ($dados !== null) {
            echo json_encode(['ok' => true, 'fonte' => $nome, 'dados' => $dados], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit;
        }
    }

    echo json_encode(['ok' => false, 'erro' => 'Nenhuma fonte encontrou esse CNPJ agora (' . implode(', ', $tentadas) . ').'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($tipo === 'cep') {
    if (strlen($valor) !== 8) {
        echo json_encode(['ok' => false, 'erro' => 'CEP precisa ter 8 numeros.']);
        exit;
    }

    $fontes = [
        'ViaCEP' => function ($cep) {
            $e = shield_consulta_get('https://viacep.com.br/ws/' . $cep . '/json/');
            if (!$e || !empty($e['erro']) || empty($e['localidade'])) {
                return null;
            }

            return [
                'endereco' => (string) ($e['logradouro'] ?? ''),
                'cidade' => (string) $e['localidade'],
                'uf' => strtoupper((string) ($e['uf'] ?? '')),
            ];
        },
        'BrasilAPI' => function ($cep) {
            $e = shield_consulta_get('https://brasilapi.com.br/api/cep/v2/' . $cep);
            if (!$e || empty($e['city'])) {
                return null;
            }

            return [
                'endereco' => (string) ($e['street'] ?? ''),
                'cidade' => (string) $e['city'],
                'uf' => strtoupper((string) ($e['state'] ?? '')),
            ];
        },
    ];

    $tentadas = [];
    foreach ($fontes as $nome => $buscar) {
        try {
            $dados = $buscar($valor);
        } catch (Throwable $ignorado) {
            $dados = null;
        }
        $tentadas[] = $nome;
        if ($dados !== null) {
            echo json_encode(['ok' => true, 'fonte' => $nome, 'dados' => $dados], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit;
        }
    }

    echo json_encode(['ok' => false, 'erro' => 'Nenhuma fonte encontrou esse CEP agora (' . implode(', ', $tentadas) . ').'], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['ok' => false, 'erro' => 'Consulta desconhecida.']);
