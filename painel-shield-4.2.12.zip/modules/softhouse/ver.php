<?php
/**
 * ---------------------------------------------------------------------
 * Sistema de Licenca Shield
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . "/../../funcoes/contrato/assinatura_a1.php";

if ($_SESSION['usuario']['acesso'] != 1) {
    header('Location: acesso_negado.php');
    exit;
}


$softhouse_data = null;

try {
    $stmt = $pdo->query("SELECT * FROM softhouse LIMIT 1");
    $softhouse_data = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erro ao consultar os dados da softhouse: " . $e->getMessage());
}

$certStatus = shield_a1_status($softhouse_data['certificado_a1_validade_fim'] ?? null);
$runtimeValidation = shield_a1_runtime_validation(is_array($softhouse_data) ? $softhouse_data : []);
$runtimeClassMap = [
    'cert_ok' => 'success',
    'cert_required' => 'secondary',
    'cert_secret_missing' => 'warning',
    'cert_file_missing' => 'danger',
    'cert_crypto_mismatch' => 'danger',
    'cert_password_invalid' => 'danger',
    'cert_parse_error' => 'danger',
    'cert_expired' => 'danger',
];
$runtimeClass = $runtimeClassMap[$runtimeValidation['code']] ?? 'secondary';
?>
  <?php include __DIR__ . '/../../templates/estrutura.php'; ?>


  <div class="container-fluid">

      <div class="topo-tela">
        <div>
          <h1 class="h4 mb-1">Minha empresa</h1>
          <p class="text-secondary small mb-0">O nome, o endere&ccedil;o e a cor que o cliente v&ecirc; na cobran&ccedil;a e no e-mail.</p>
        </div>
        <a href="/editar_softhouse.php" class="btn btn-primary btn-sm">
          <i class="fas fa-edit me-1"></i>Editar
        </a>
      </div>

      <div class="card shadow mb-4" data-tour="empresa-dados">
          <div class="card-header py-3">
              <h6 class="m-0 fw-bold text-primary">DADOS QUE O CLIENTE V&Ecirc;:</h6>
          </div>
          <div class="card-body">
              <?php if ($softhouse_data): ?>
                  <div class="row">
                      <div class="col-md-6">
                          <p><strong>CNPJ:</strong> <?= shield_h($softhouse_data['cnpj']); ?></p>
                          <p><strong>Razao Social:</strong> <?= shield_h($softhouse_data['razao']); ?></p>
                          <p><strong>Nome Fantasia:</strong> <?= shield_h($softhouse_data['fantasia']); ?></p>
                          <p><strong>Inscricao Estadual:</strong> <?= shield_h($softhouse_data['ie'] ?: 'Nao preenchido'); ?></p>
                          <p><strong>Telefone:</strong> <?= shield_h($softhouse_data['telefone'] ?: 'Nao preenchido'); ?></p>
                          <p><strong>E-mail de contato:</strong> <?= shield_h(($softhouse_data['email'] ?? '') ?: 'Nao preenchido'); ?></p>
                      </div>
                      <div class="col-md-6">
                          <p><strong>Endere&ccedil;o:</strong> <?= shield_h($softhouse_data['endereco']); ?>, N <?= shield_h($softhouse_data['numero']); ?></p>
                          <p><strong>Cidade:</strong> <?= shield_h($softhouse_data['cidade']); ?></p>
                          <p><strong>Estado:</strong> <?= shield_h($softhouse_data['estado']); ?></p>
                          <p><strong>CEP:</strong> <?= shield_h($softhouse_data['cep']); ?></p>
                      </div>
                  </div>
              <?php else: ?>
                  <div class="alert alert-warning" role="alert">
                      Nenhuma informacao da softhouse foi encontrada. <a href="editar_softhouse.php" class="alert-link">Clique aqui para adicionar os dados</a>.
                  </div>
              <?php endif; ?>
          </div>
      </div>

      <div class="card shadow mb-4" data-tour="empresa-certificado">
          <div class="card-header py-3">
              <h6 class="m-0 fw-bold text-primary">CERTIFICADO A1:</h6>
          </div>
          <div class="card-body">
              <?php if ($softhouse_data && !empty($softhouse_data['certificado_a1_arquivo'])): ?>
                  <div class="row">
                      <div class="col-md-6">
                          <p><strong>Status:</strong>
                              <span class="badge text-bg-<?= shield_h($certStatus['class']); ?>"><?= shield_h($certStatus['label']); ?></span>
                          </p>
                          <p><strong>Status operacional:</strong>
                              <span class="badge text-bg-<?= shield_h($runtimeClass); ?>"><?= shield_h($runtimeValidation['code']); ?></span>
                          </p>
                          <p class="text-muted"><small><?= shield_h($runtimeValidation['message']); ?></small></p>
                          <p><strong>Titular:</strong> <?= shield_h($softhouse_data['certificado_a1_titular'] ?? 'N/D'); ?></p>
                          <p><strong>Serial:</strong> <?= shield_h($softhouse_data['certificado_a1_serial'] ?? 'N/D'); ?></p>
                          <p><strong>Thumbprint:</strong> <small><?= shield_h($softhouse_data['certificado_a1_thumbprint'] ?? 'N/D'); ?></small></p>
                      </div>
                      <div class="col-md-6">
                          <p><strong>Validade inicio:</strong> <?= shield_h(shield_format_datetime_br($softhouse_data['certificado_a1_validade_inicio'] ?? null)); ?></p>
                          <p><strong>Validade fim:</strong> <?= shield_h(shield_format_datetime_br($softhouse_data['certificado_a1_validade_fim'] ?? null)); ?></p>
                          <p><strong>Dias restantes:</strong>
                              <?php if ($certStatus['days'] !== null): ?>
                                  <?= shield_h($certStatus['days']); ?> dias
                              <?php else: ?>
                                  N/D
                              <?php endif; ?>
                          </p>
                          <p><strong>&Uacute;ltima atualiza&ccedil;&atilde;o:</strong> <?= shield_h(shield_format_datetime_br($softhouse_data['certificado_a1_atualizado_em'] ?? null)); ?></p>
                      </div>
                  </div>
              <?php else: ?>
                  <div class="alert alert-secondary mb-0">
                      Nenhum certificado A1 configurado. Acesse <a href="editar_softhouse.php">Editar</a> para enviar o arquivo.
                  </div>
              <?php endif; ?>
          </div>
      </div>

  </div>

  


<?php include __DIR__ . '/../../templates/fecha.php'; ?>
