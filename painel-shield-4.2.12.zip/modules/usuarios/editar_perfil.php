<?php

// Editar perfil -- reescrito em 03/09/2026.
//
// Dois formularios, cada um com o proprio botao e o proprio erro: os dados da
// conta e a senha. Antes a senha ficava num modal que fechava ao enviar e
// escondia a mensagem de erro; e a foto chamava uploadFoto() sem o arquivo
// que a define, o que era erro fatal ao subir qualquer imagem.
//
// SEMPRE a conta logada. O ?id= da URL antiga e ignorado: ninguem edita a
// conta de outro por aqui.
//
// A senha nova segue a mesma regra do cadastro e da recuperacao
// (funcoes/acesso/senha_forca.php): pelo menos "boa".

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/acesso/senha_forca.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca.php'; // shield_auditar

$usuarioId = (int) ($_SESSION['usuario']['id'] ?? 0);

$stmt = $pdo->prepare('SELECT id, nome, login, email, uf, acesso FROM usuario WHERE id = :id');
$stmt->execute(array(':id' => $usuarioId));
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$usuario) {
    session_destroy();
    header('Location: login.php');
    exit;
}

$ufs = array('AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR',
             'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO');

$dados = array(
    'nome' => (string) $usuario['nome'],
    'email' => (string) $usuario['email'],
    'uf' => strtoupper(trim((string) $usuario['uf'])),
);
if (!in_array($dados['uf'], $ufs, true)) {
    $dados['uf'] = '';
}
$errosDados = array();
$errosSenha = array();

$acao = (string) ($_POST['acao'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $acao === 'dados') {
    $dados['nome'] = trim((string) ($_POST['nome'] ?? ''));
    $dados['email'] = trim((string) ($_POST['email'] ?? ''));
    $dados['uf'] = strtoupper(trim((string) ($_POST['uf'] ?? '')));

    if ($dados['nome'] === '') {
        $errosDados['nome'] = 'Diga como devemos te chamar.';
    }
    if (!filter_var($dados['email'], FILTER_VALIDATE_EMAIL)) {
        $errosDados['email'] = 'Informe um e-mail valido: e para onde vai o link se voce esquecer a senha.';
    } else {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM usuario WHERE (email = :e OR login = :l) AND id <> :id');
        $stmt->execute(array(':e' => $dados['email'], ':l' => $dados['email'], ':id' => $usuarioId));
        if ((int) $stmt->fetchColumn() > 0) {
            $errosDados['email'] = 'Este e-mail ja e de outra conta.';
        }
    }
    if ($dados['uf'] !== '' && !in_array($dados['uf'], $ufs, true)) {
        $errosDados['uf'] = 'Escolha uma UF da lista.';
    }

    if ($errosDados === array()) {
        $pdo->prepare('UPDATE usuario SET nome = :n, email = :e, uf = :u WHERE id = :id')
            ->execute(array(
                ':n' => $dados['nome'],
                ':e' => $dados['email'],
                ':u' => $dados['uf'] !== '' ? $dados['uf'] : 'NA',
                ':id' => $usuarioId,
            ));
        if (function_exists('shield_auditar')) {
            shield_auditar($pdo, 'perfil_atualizado', array('alvo_tipo' => 'usuario', 'alvo_id' => $usuarioId));
        }
        // A sessao e a foto da entrada: atualiza para o topo mostrar o nome novo.
        $stmt = $pdo->prepare('SELECT * FROM usuario WHERE id = :id');
        $stmt->execute(array(':id' => $usuarioId));
        $_SESSION['usuario'] = $stmt->fetch(PDO::FETCH_ASSOC);
        header('Location: perfil.php?salvo=dados');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $acao === 'senha') {
    $atual = (string) ($_POST['senha_atual'] ?? '');
    $nova = (string) ($_POST['senha_nova'] ?? '');
    $confirmacao = (string) ($_POST['senha_confirmacao'] ?? '');

    $stmt = $pdo->prepare('SELECT senha FROM usuario WHERE id = :id');
    $stmt->execute(array(':id' => $usuarioId));
    $hashAtual = (string) $stmt->fetchColumn();

    if ($atual === '' || !password_verify($atual, $hashAtual)) {
        $errosSenha['senha_atual'] = 'A senha atual nao confere.';
    }
    if (strlen($nova) < 8) {
        $errosSenha['senha_nova'] = 'A senha precisa ter pelo menos 8 caracteres.';
    } elseif (!shield_senha_forte($nova)) {
        $errosSenha['senha_nova'] = shield_senha_regra_texto();
    } elseif (password_verify($nova, $hashAtual)) {
        $errosSenha['senha_nova'] = 'Essa ja e a sua senha atual.';
    }
    if ($errosSenha === array() && !hash_equals($nova, $confirmacao)) {
        $errosSenha['senha_confirmacao'] = 'As duas senhas nao sao iguais.';
    }

    if ($errosSenha === array()) {
        $pdo->prepare('UPDATE usuario SET senha = :s WHERE id = :id')
            ->execute(array(':s' => password_hash($nova, PASSWORD_DEFAULT), ':id' => $usuarioId));
        $_SESSION['usuario']['senha'] = null;
        if (function_exists('shield_auditar')) {
            shield_auditar($pdo, 'senha_alterada', array('alvo_tipo' => 'usuario', 'alvo_id' => $usuarioId));
        }
        header('Location: perfil.php?salvo=senha');
        exit;
    }
}

$campo = static function (array $erros, $nome) {
    return isset($erros[$nome]) ? ' is-invalid' : '';
};
$aviso = static function (array $erros, $nome) {
    return isset($erros[$nome])
        ? '<div class="invalid-feedback d-block">' . shield_h($erros[$nome]) . '</div>'
        : '';
};
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="container-fluid">
  <div class="topo-tela">
    <div>
      <h1 class="h4 mb-1">Editar perfil</h1>
      <p class="text-secondary small mb-0">Os dados que identificam a sua conta e a senha de entrada.</p>
    </div>
    <a href="/perfil.php" class="btn btn-outline-secondary btn-sm">Voltar ao perfil</a>
  </div>

  <div class="perfil-grade perfil-grade-editar">
    <section class="card">
      <div class="card-header"><strong>Dados da conta</strong></div>
      <div class="card-body">
        <form method="post" action="/editar_perfil.php" class="perfil-form" novalidate>
          <input type="hidden" name="acao" value="dados">
          <div class="row g-3">
          <div class="col-12">
            <label for="nome" class="form-label">Nome</label>
            <input id="nome" name="nome" type="text" class="form-control<?= $campo($errosDados, 'nome'); ?>" value="<?= shield_h($dados['nome']); ?>" required autocomplete="name">
            <?= $aviso($errosDados, 'nome'); ?>
          </div>
          <div class="col-12 col-md-8">
            <label for="email" class="form-label">E-mail</label>
            <input id="email" name="email" type="email" class="form-control<?= $campo($errosDados, 'email'); ?>" value="<?= shield_h($dados['email']); ?>" required autocomplete="email">
            <div class="form-text">&Eacute; para onde vai o link se voc&ecirc; esquecer a senha.</div>
            <?= $aviso($errosDados, 'email'); ?>
          </div>
          <div class="col-12 col-md-4">
            <label for="uf" class="form-label">UF</label>
            <select id="uf" name="uf" class="form-select<?= $campo($errosDados, 'uf'); ?>">
              <option value="">&mdash;</option>
              <?php foreach ($ufs as $sigla): ?>
                <option value="<?= $sigla; ?>"<?= $dados['uf'] === $sigla ? ' selected' : ''; ?>><?= $sigla; ?></option>
              <?php endforeach; ?>
            </select>
            <?= $aviso($errosDados, 'uf'); ?>
          </div>
          <div class="col-12">
            <label class="form-label">Login</label>
            <input type="text" class="form-control" value="<?= shield_h($usuario['login']); ?>" disabled>
            <div class="form-text">O login n&atilde;o muda. Entre com ele ou com o e-mail.</div>
          </div>
          </div>
          <div class="perfil-form-pe">
            <button type="submit" class="btn btn-primary"><i class="fas fa-save me-1"></i>Salvar dados</button>
            <a href="/perfil.php" class="btn btn-outline-secondary">Cancelar</a>
          </div>
        </form>
      </div>
    </section>

    <section class="card" id="senha">
      <div class="card-header"><strong>Senha</strong></div>
      <div class="card-body">
        <form method="post" action="/editar_perfil.php#senha" class="perfil-form" novalidate>
          <input type="hidden" name="acao" value="senha">
          <div class="row g-3">
          <div class="col-12 campo">
            <label for="senha_atual" class="form-label">Senha atual</label>
            <div class="senha-caixa">
              <input id="senha_atual" name="senha_atual" type="password" class="form-control<?= $campo($errosSenha, 'senha_atual'); ?>" required autocomplete="current-password">
              <button type="button" class="olho" aria-label="Mostrar senha" aria-pressed="false">
                <svg class="aberto" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>
                <svg class="fechado" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.9 17.9A10.5 10.5 0 0 1 12 19c-6.5 0-10-7-10-7a17.6 17.6 0 0 1 4.1-4.9M9.9 5.2A9.6 9.6 0 0 1 12 5c6.5 0 10 7 10 7a17.6 17.6 0 0 1-2.2 3.1"/><path d="M14.1 14.1a3 3 0 0 1-4.2-4.2"/><path d="M2 2l20 20"/></svg>
              </button>
            </div>
            <?= $aviso($errosSenha, 'senha_atual'); ?>
          </div>
          <div class="col-12 campo">
            <label for="senha_nova" class="form-label">Senha nova</label>
            <div class="senha-caixa">
              <input id="senha_nova" name="senha_nova" type="password" class="form-control<?= $campo($errosSenha, 'senha_nova'); ?>" required minlength="8" autocomplete="new-password" data-forca="forca-senha">
              <button type="button" class="olho" aria-label="Mostrar senha" aria-pressed="false">
                <svg class="aberto" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>
                <svg class="fechado" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.9 17.9A10.5 10.5 0 0 1 12 19c-6.5 0-10-7-10-7a17.6 17.6 0 0 1 4.1-4.9M9.9 5.2A9.6 9.6 0 0 1 12 5c6.5 0 10 7 10 7a17.6 17.6 0 0 1-2.2 3.1"/><path d="M14.1 14.1a3 3 0 0 1-4.2-4.2"/><path d="M2 2l20 20"/></svg>
              </button>
            </div>
            <div class="forca" id="forca-senha" data-nivel="0" aria-live="polite">
              <div class="forca-barra"><i></i><i></i><i></i><i></i></div>
              <div class="forca-texto"><b></b><span>Use 8 ou mais caracteres misturando letras, n&uacute;meros e s&iacute;mbolos, ou uma frase longa.</span></div>
            </div>
            <?= $aviso($errosSenha, 'senha_nova'); ?>
          </div>
          <div class="col-12 campo">
            <label for="senha_confirmacao" class="form-label">Repita a senha nova</label>
            <div class="senha-caixa">
              <input id="senha_confirmacao" name="senha_confirmacao" type="password" class="form-control<?= $campo($errosSenha, 'senha_confirmacao'); ?>" required minlength="8" autocomplete="new-password" data-confere="senha_nova">
              <button type="button" class="olho" aria-label="Mostrar senha" aria-pressed="false">
                <svg class="aberto" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>
                <svg class="fechado" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.9 17.9A10.5 10.5 0 0 1 12 19c-6.5 0-10-7-10-7a17.6 17.6 0 0 1 4.1-4.9M9.9 5.2A9.6 9.6 0 0 1 12 5c6.5 0 10 7 10 7a17.6 17.6 0 0 1-2.2 3.1"/><path d="M14.1 14.1a3 3 0 0 1-4.2-4.2"/><path d="M2 2l20 20"/></svg>
              </button>
            </div>
            <div class="confere"></div>
            <?= $aviso($errosSenha, 'senha_confirmacao'); ?>
          </div>
          </div>
          <div class="perfil-form-pe">
            <button type="submit" class="btn btn-primary"><i class="fas fa-key me-1"></i>Alterar senha</button>
          </div>
        </form>
      </div>
    </section>
  </div>
</div>
<?php include __DIR__ . '/../../templates/fecha.php'; ?>
