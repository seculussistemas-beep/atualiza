<?php

// Redefinir a senha -- 03/09/2026.
//
// A tela do link que veio por e-mail. O token vai no endereco (GET) na chegada
// e num campo oculto (POST) ao gravar; nos dois casos passa por
// shield_senha_token_buscar(), que so devolve token vivo e nao usado.

require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/acesso/senha_recuperacao.php';
require_once __DIR__ . '/../../templates/entrada.php';

$token = trim((string) ($_POST['token'] ?? $_GET['token'] ?? ''));
$registro = shield_senha_token_buscar($pdo, $token);
$erro = '';
$trocada = false;

if ($registro !== null && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $resultado = shield_senha_redefinir(
        $pdo,
        $token,
        (string) ($_POST['senha'] ?? ''),
        (string) ($_POST['senha_confirmacao'] ?? '')
    );

    if ($resultado['ok']) {
        $trocada = true;
    } else {
        $erro = (string) $resultado['erro'];
    }
}

shield_entrada_abrir('Nova senha');
?>
                <?php if ($trocada): ?>
                    <h2>Senha alterada</h2>
                    <p class="sub">Pronto, <?= htmlspecialchars((string) $registro['nome'], ENT_QUOTES, 'UTF-8'); ?>. A senha nova já vale.</p>
                    <a class="entrar" href="login.php" style="text-decoration:none">Entrar no painel</a>
                <?php elseif ($registro === null): ?>
                    <h2>Este link não vale mais</h2>
                    <p class="sub">Ele expira em <?= (int) SHIELD_SENHA_TOKEN_MINUTOS; ?> minutos e funciona uma única vez. Peça outro e use o mais recente.</p>
                    <a class="entrar" href="esqueci_senha.php" style="text-decoration:none">Pedir um link novo</a>
                    <div class="alt"><a href="login.php">Voltar para o login</a></div>
                <?php else: ?>
                    <h2>Escolha a senha nova</h2>
                    <p class="sub">Para a conta <strong><?= htmlspecialchars((string) $registro['email'], ENT_QUOTES, 'UTF-8'); ?></strong>.</p>

                    <?php if ($erro !== ''): ?>
                        <div class="alert alert-danger" role="alert"><?= htmlspecialchars($erro, ENT_QUOTES, 'UTF-8'); ?></div>
                    <?php endif; ?>

                    <form action="redefinir_senha.php" method="post" data-valida novalidate>
                        <input type="hidden" name="token" value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>">
                        <div class="campo">
                            <label for="senha">Senha nova</label>
                            <div class="senha-caixa">
                                <input type="password" class="senha" name="senha" id="senha" placeholder="Pelo menos <?= (int) SHIELD_SENHA_MINIMO; ?> caracteres"
                                       autocomplete="new-password" required minlength="<?= (int) SHIELD_SENHA_MINIMO; ?>" data-forca="forca-senha">
                                <?= shield_entrada_olho(); ?>
                            </div>
                            <?= shield_entrada_forca('forca-senha'); ?>
                            <div class="aviso">A senha precisa ser pelo menos boa.</div>
                        </div>
                        <div class="campo">
                            <label for="senha_confirmacao">Repita a senha</label>
                            <div class="senha-caixa">
                                <input type="password" class="senha" name="senha_confirmacao" id="senha_confirmacao" placeholder="A mesma senha"
                                       autocomplete="new-password" required minlength="<?= (int) SHIELD_SENHA_MINIMO; ?>" data-confere="senha">
                                <?= shield_entrada_olho(); ?>
                            </div>
                            <div class="confere"></div>
                            <div class="aviso">Repita a senha nova.</div>
                        </div>
                        <button type="submit" class="entrar" data-enviando="Salvando…"><span class="giro" aria-hidden="true"></span><span>Salvar a senha nova</span></button>
                    </form>
                <?php endif; ?>
<?php
shield_entrada_fechar();
