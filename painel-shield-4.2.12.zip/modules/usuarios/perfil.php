<?php

// Meu perfil -- reescrito em 03/09/2026.
//
// A tela de quem esta logado ver a propria conta: quem e, como entra, o que
// mudou por ultimo. Os dados vem do BANCO, e nao da sessao: a sessao e uma
// foto de quando a pessoa entrou.
//
// Sem foto de perfil. A pasta uploads/ ficou fora do docroot na mudanca para
// public/ e nao e servida; a foto quebrava em toda tela. O avatar com as
// iniciais, o mesmo do topo, e o suficiente para uma conta de operador.

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/acesso/sessao_lembrada.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca.php'; // shield_auditar

$usuarioId = (int) ($_SESSION['usuario']['id'] ?? 0);

$stmt = $pdo->prepare('SELECT id, nome, login, email, uf, cnpj, data, acesso FROM usuario WHERE id = :id');
$stmt->execute(array(':id' => $usuarioId));
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    session_destroy();
    header('Location: login.php');
    exit;
}

$aviso = '';
if (isset($_GET['salvo'])) {
    $aviso = array(
        'dados' => 'Dados da conta salvos.',
        'senha' => 'Senha alterada. Ela ja vale na proxima entrada.',
    )[(string) $_GET['salvo']] ?? '';
}

// "Sair de todos os aparelhos": apaga os cookies de "manter conectado" de
// todos os navegadores desta conta, inclusive este.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sair_todos'])) {
    try {
        $pdo->prepare('DELETE FROM sessao_lembrada WHERE fk_usuario = :u')->execute(array(':u' => $usuarioId));
        shield_lembrar_apagar_cookie();
        if (function_exists('shield_auditar')) {
            shield_auditar($pdo, 'sessoes_lembradas_apagadas', array('alvo_tipo' => 'usuario', 'alvo_id' => $usuarioId));
        }
    } catch (Throwable $ignorado) {
        // Base sem a tabela ainda: nao ha o que apagar.
    }
    header('Location: perfil.php?salvo=aparelhos');
    exit;
}
if (($_GET['salvo'] ?? '') === 'aparelhos') {
    $aviso = 'Todos os navegadores lembrados foram esquecidos. Na proxima visita, cada um pede a senha de novo.';
}

$papel = array('1' => 'Administrador', '3' => 'Cliente')[trim((string) $usuario['acesso'])] ?? 'Sem papel definido';
$dataCadastro = !empty($usuario['data']) ? date('d/m/Y', strtotime((string) $usuario['data'])) : '';
$uf = strtoupper(trim((string) $usuario['uf']));
$ufTexto = ($uf === '' || $uf === 'NA') ? '' : $uf;
$cnpj = preg_replace('/\D/', '', (string) $usuario['cnpj']);
$cnpjTexto = ($cnpj === '' || (int) $cnpj === 0) ? ''
    : (strlen($cnpj) === 14 ? preg_replace('/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/', '$1.$2.$3/$4-$5', $cnpj) : $cnpj);

// Quantos navegadores estao lembrados (cookie de 30 dias).
$lembrados = 0;
try {
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM sessao_lembrada WHERE fk_usuario = :u AND expira_em > NOW()');
    $stmt->execute(array(':u' => $usuarioId));
    $lembrados = (int) $stmt->fetchColumn();
} catch (Throwable $ignorado) {
    $lembrados = 0;
}

// O que esta conta fez por ultimo, do livro de auditoria. Oito cabem no
// cartao sem rolagem.
$atividade = array();
$ultimaEntrada = '';
$entradas30 = 0;
$ultimaTrocaSenha = '';
try {
    $stmt = $pdo->prepare(
        'SELECT acao, detalhe, quando FROM auditoria
          WHERE fk_usuario = :u OR ator = :a
          ORDER BY quando DESC LIMIT 8'
    );
    $stmt->execute(array(':u' => $usuarioId, ':a' => (string) $usuario['login']));
    $atividade = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();

    $stmt = $pdo->prepare(
        "SELECT MAX(quando) ultima,
                SUM(CASE WHEN quando > DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) recentes
           FROM auditoria WHERE acao = 'entrou' AND (fk_usuario = :u OR ator = :a)"
    );
    $stmt->execute(array(':u' => $usuarioId, ':a' => (string) $usuario['login']));
    $linha = $stmt->fetch(PDO::FETCH_ASSOC) ?: array();
    $ultimaEntrada = (string) ($linha['ultima'] ?? '');
    $entradas30 = (int) ($linha['recentes'] ?? 0);

    $stmt = $pdo->prepare(
        "SELECT MAX(quando) FROM auditoria
          WHERE acao IN ('senha_alterada', 'senha_redefinida') AND (fk_usuario = :u OR ator = :a)"
    );
    $stmt->execute(array(':u' => $usuarioId, ':a' => (string) $usuario['login']));
    $ultimaTrocaSenha = (string) ($stmt->fetchColumn() ?: '');
} catch (Throwable $ignorado) {
    $atividade = array();
}

$rotulosAcao = array(
    'entrou' => 'Entrou no painel',
    'perfil_atualizado' => 'Dados da conta atualizados',
    'senha_alterada' => 'Senha alterada',
    'senha_redefinida' => 'Senha redefinida pelo link de recuperacao',
    'senha_recuperacao_pedida' => 'Pediu o link de recuperacao de senha',
    'sessoes_lembradas_apagadas' => 'Saiu de todos os aparelhos',
    'email_configurado' => 'Configurou o envio de e-mail',
);
$rotuloAcao = static function ($acao) use ($rotulosAcao) {
    $acao = (string) $acao;
    return $rotulosAcao[$acao] ?? ucfirst(str_replace('_', ' ', $acao));
};
$haQuanto = static function ($quando) {
    $t = strtotime((string) $quando);
    if (!$t) {
        return '';
    }
    $d = time() - $t;
    if ($d < 60) { return 'agora ha pouco'; }
    if ($d < 3600) { return 'ha ' . (int) ($d / 60) . ' min'; }
    if ($d < 86400) { return 'ha ' . (int) ($d / 3600) . ' h'; }
    if ($d < 7 * 86400) { return 'ha ' . (int) ($d / 86400) . ' dia(s)'; }
    return date('d/m/Y H:i', $t);
};
if ($ultimaTrocaSenha !== '') {
    $ultimaTrocaSenha = $haQuanto($ultimaTrocaSenha);
}
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="container-fluid">
  <div class="topo-tela">
    <div>
      <h1 class="h4 mb-1">Meu perfil</h1>
      <p class="text-secondary small mb-0">Quem voc&ecirc; &eacute; para o painel e como entra nele.</p>
    </div>
  </div>

  <?php shield_aviso_flutuante($aviso, 'salvo'); ?>

  <div class="perfil-grade">
    <section class="card perfil-identidade">
      <div class="card-body">
        <span class="perfil-avatar" aria-hidden="true"><?= shield_h(shield_marca_iniciais($usuario['nome'])); ?></span>
        <h2 class="perfil-nome"><?= shield_h($usuario['nome']); ?></h2>
        <span class="pilula <?= trim((string) $usuario['acesso']) === '1' ? 'pilula-ok' : 'pilula-neutro'; ?>"><?= shield_h($papel); ?></span>
        <p class="perfil-desde">
          <?php if ($dataCadastro !== ''): ?>No painel desde <?= shield_h($dataCadastro); ?><?php else: ?>Conta sem data de cadastro<?php endif; ?>
        </p>
        <div class="perfil-acoes">
          <a class="btn btn-outline-primary btn-sm" href="/editar_perfil.php">Editar dados</a>
          <a class="btn btn-outline-secondary btn-sm" href="/editar_perfil.php#senha">Alterar senha</a>
        </div>
      </div>
      <?php /* Os numeros da conta. "Entrou" passou a ser registrado na auditoria em 03/09/2026;
               conta antiga mostra "sem registro" ate a proxima entrada. */ ?>
      <dl class="perfil-resumo">
        <div>
          <dt>&Uacute;ltimo acesso</dt>
          <dd><?= $ultimaEntrada !== '' ? shield_h($haQuanto($ultimaEntrada)) : '<span class="perfil-vazio">sem registro</span>'; ?></dd>
        </div>
        <div>
          <dt>Entradas em 30 dias</dt>
          <dd><?= $entradas30; ?></dd>
        </div>
        <div>
          <dt>Navegadores lembrados</dt>
          <dd><?= $lembrados; ?></dd>
        </div>
      </dl>
    </section>

    <div class="perfil-coluna">
      <section class="card">
        <div class="card-header"><strong>Acesso</strong></div>
        <div class="card-body">
          <dl class="perfil-lista">
            <dt>Login</dt><dd><?= shield_h($usuario['login']); ?></dd>
            <dt>E-mail</dt><dd><?= $usuario['email'] !== '' ? shield_h($usuario['email']) : '<span class="perfil-vazio">n&atilde;o informado</span>'; ?></dd>
            <dt>Papel</dt><dd><?= shield_h($papel); ?></dd>
            <dt>UF</dt><dd><?= $ufTexto !== '' ? shield_h($ufTexto) : '<span class="perfil-vazio">n&atilde;o informada</span>'; ?></dd>
            <?php if ($cnpjTexto !== ''): ?>
              <dt>CNPJ</dt><dd><?= shield_h($cnpjTexto); ?></dd>
            <?php endif; ?>
          </dl>
        </div>
      </section>

      <section class="card">
        <div class="card-header"><strong>Seguran&ccedil;a</strong></div>
        <div class="card-body">
          <dl class="perfil-lista">
            <dt>Senha</dt>
            <dd>&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;<?php if ($ultimaTrocaSenha !== ''): ?> <span class="perfil-vazio">&middot; alterada <?= shield_h($ultimaTrocaSenha); ?></span><?php endif; ?></dd>
            <dt>Manter conectado</dt>
            <dd class="perfil-linha-acao">
              <span>
                <?php if ($lembrados === 0): ?>Nenhum navegador lembrado.
                <?php elseif ($lembrados === 1): ?>1 navegador entra sem pedir senha por at&eacute; 30 dias.
                <?php else: ?><?= $lembrados; ?> navegadores entram sem pedir senha por at&eacute; 30 dias.<?php endif; ?>
              </span>
              <?php if ($lembrados > 0): ?>
                <form method="post" action="/perfil.php" class="d-inline" onsubmit="return confirm('Todos os navegadores lembrados, inclusive este, vão pedir a senha de novo. Continuar?');">
                  <button type="submit" name="sair_todos" value="1" class="btn btn-outline-danger btn-sm">Sair de todos os aparelhos</button>
                </form>
              <?php endif; ?>
            </dd>
          </dl>
        </div>
      </section>

      <section class="card perfil-atividade">
        <div class="card-header"><strong>Atividade recente</strong></div>
        <div class="card-body">
          <?php if ($atividade === array()): ?>
            <p class="perfil-vazio mb-0">Nada registrado ainda nesta conta.</p>
          <?php else: ?>
            <ol class="atividade">
              <?php foreach ($atividade as $a): ?>
                <li>
                  <span class="atividade-ponto" aria-hidden="true"></span>
                  <div>
                    <b><?= shield_h($rotuloAcao($a['acao'])); ?></b>
                    <?php if (!empty($a['detalhe'])): ?><small><?= shield_h($a['detalhe']); ?></small><?php endif; ?>
                  </div>
                  <time datetime="<?= shield_h($a['quando']); ?>"><?= shield_h($haQuanto($a['quando'])); ?></time>
                </li>
              <?php endforeach; ?>
            </ol>
          <?php endif; ?>
        </div>
      </section>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../../templates/fecha.php'; ?>
