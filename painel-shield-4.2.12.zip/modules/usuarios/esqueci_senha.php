<?php

// Esqueci a senha -- 03/09/2026.
//
// Publica: quem chega aqui esta do lado de fora. Pede o e-mail (ou login),
// manda o link e responde a MESMA tela para conta que existe e conta que nao
// existe -- ver includes/senha_recuperacao.php.

require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/acesso/senha_recuperacao.php';
require_once __DIR__ . '/../../funcoes/nucleo/http.php';
require_once __DIR__ . '/../../templates/entrada.php';

$identificacao = '';
$erro = '';
$semSmtp = false;
$semUrlBase = false;
$pedido = false;
$urlBase = '';
$adiado = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identificacao = trim((string) ($_POST['identificacao'] ?? ''));
    $urlBase = shield_senha_url_base();

    // SO O QUE NAO DEPENDE DE O USUARIO EXISTIR decide a tela. Ate 08/09/2026 o
    // pedido inteiro rodava aqui, e o SMTP sincrono ficava no meio: conta que
    // nao existe respondia em milissegundos, conta que existe respondia depois
    // de ate vinte segundos. A frase era a mesma para as duas; o relogio, nao.
    switch (shield_senha_pre_checagem($pdo, $identificacao, $urlBase)) {
        case 'vazio':
            $erro = 'Informe o e-mail ou o login da sua conta.';
            break;

        case 'sem_smtp':
            $semSmtp = true;
            break;

        case 'sem_url_base':
            // Como o sem_smtp: e configuracao do painel, nao segredo de
            // usuario. Calar aqui deixaria a tela dizendo "o link foi enviado"
            // para um link que nao existe, e o administrador nunca saberia.
            $semUrlBase = true;
            break;

        default:
            // A tela ja esta decidida. Procurar a conta, gravar o token e
            // mandar o e-mail ficam para depois da resposta fechada, no fim
            // deste arquivo.
            $pedido = true;
            $adiado = $identificacao;
    }
}

$e = static function ($t) {
    return htmlspecialchars((string) $t, ENT_QUOTES, 'UTF-8');
};

shield_entrada_abrir('Recuperar senha');
?>
                <?php if ($pedido): ?>
                    <div class="enviado">
                        <div class="enviado-icone" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6h16a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1z"/><path d="m3 7 9 6 9-6"/></svg>
                            <span class="enviado-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 4 4L19 7"/></svg></span>
                        </div>
                        <h2>Link enviado</h2>
                        <p class="sub">Se existir uma conta com este e-mail, a mensagem chega em instantes.</p>
                        <div class="chip"><?= $e($identificacao); ?></div>

                        <ol class="proximos">
                            <li><b>Abra a sua caixa de entrada</b><span>O assunto é "Redefinir a senha do painel". Não achou? Olhe o spam.</span></li>
                            <li><b>Clique em "Escolher a senha nova"</b><span>O botão vale por <?= (int) SHIELD_SENHA_TOKEN_MINUTOS; ?> minutos e funciona uma única vez.</span></li>
                            <li><b>Volte e entre com a senha nova</b><span>A antiga deixa de valer na hora.</span></li>
                        </ol>

                        <form method="post" action="esqueci_senha.php" class="reenvio">
                            <input type="hidden" name="identificacao" value="<?= $e($identificacao); ?>" maxlength="255">
                            <button type="submit" class="entrar secundario" id="reenviar" disabled data-espera="60">Reenviar em 60 s</button>
                        </form>
                        <div class="alt"><a href="login.php">Voltar para o login</a> &nbsp;·&nbsp; <a href="esqueci_senha.php">Usar outro e-mail</a></div>
                    </div>
                    <script>
                        // O reenvio abre depois de um minuto: da tempo de o e-mail chegar
                        // e evita o clique nervoso que enche a caixa de links iguais.
                        (function () {
                            var b = document.getElementById('reenviar');
                            var s = parseInt(b.getAttribute('data-espera'), 10);
                            var t = setInterval(function () {
                                s -= 1;
                                if (s <= 0) { clearInterval(t); b.disabled = false; b.textContent = 'Reenviar o link'; return; }
                                b.textContent = 'Reenviar em ' + s + ' s';
                            }, 1000);
                        })();
                    </script>
                <?php else: ?>
                    <h2>Recuperar senha</h2>
                    <p class="sub">Informe o e-mail da sua conta e enviamos um link para escolher a senha nova.</p>

                    <?php if ($semSmtp): ?>
                        <div class="alert alert-warning" role="alert">
                            O envio de e-mail deste painel ainda não foi configurado, então o link não tem por onde sair.
                            Quem administra o painel precisa preencher as variáveis <code>SHIELD_SMTP_*</code> no arquivo <code>.env</code>.
                        </div>
                    <?php endif; ?>
                    <?php if ($semUrlBase): ?>
                        <div class="alert alert-warning" role="alert">
                            Este painel ainda não declarou o próprio endereço, então o link de redefinição não tem para onde apontar.
                            Quem administra precisa preencher <code>SHIELD_APP_URL</code> no arquivo <code>.env</code> — por exemplo
                            <code>SHIELD_APP_URL=https://painel.suaempresa.com.br</code>.
                        </div>
                    <?php endif; ?>
                    <?php if ($erro !== ''): ?>
                        <div class="alert alert-danger" role="alert"><?= $e($erro); ?></div>
                    <?php endif; ?>

                    <form action="esqueci_senha.php" method="post" data-valida novalidate>
                        <div class="campo">
                            <label for="identificacao">E-mail ou login</label>
                            <input type="text" name="identificacao" id="identificacao" placeholder="voce@softhouse.com.br"
                                   autocomplete="username" required autofocus
                                   value="<?= $e($identificacao); ?>" maxlength="255">
                            <div class="aviso">Informe o e-mail ou o login.</div>
                        </div>
                        <button type="submit" class="entrar" data-enviando="Enviando…"><span class="giro" aria-hidden="true"></span><span>Enviar o link</span></button>
                    </form>
                    <div class="alt">Lembrou a senha? <a href="login.php">Voltar para o login</a></div>
                <?php endif; ?>
<?php
shield_entrada_fechar();

// DEPOIS DA RESPOSTA. Daqui para baixo o cliente ja recebeu a pagina, entao o
// tempo que isto leva nao entra no cronometro de quem esta do outro lado -- e
// era esse cronometro que separava conta existente de conta inexistente.
//
// Ver shield_resposta_encerrar(): sob PHP-FPM a conexao fecha de verdade; sob
// mod_php os bytes saem na hora e a conexao so encerra no fim do script, o que
// zera o tempo ate o primeiro byte mas nao o tempo total. E menos vazamento,
// nao zero, e esta escrito la por que nao da para prometer mais.
if ($adiado !== null) {
    shield_resposta_encerrar();

    try {
        $resultado = shield_senha_pedir($pdo, $adiado, $urlBase);

        // Enviado, sem usuario, sem e-mail ou no teto: a tela ja disse a mesma
        // coisa para todos. O motivo real vai para o log do servidor, que e
        // onde o administrador olha quando "nao chegou".
        if (!$resultado['enviado']) {
            error_log('[shield] recuperacao de senha nao enviada (' . $resultado['motivo'] . ')');
        }
    } catch (Throwable $falhou) {
        // A resposta ja saiu: nao ha mais tela para mostrar erro. Sem o
        // try/catch, uma excecao aqui imprimiria depois do </html>.
        error_log('[shield] recuperacao de senha falhou: ' . $falhou->getMessage());
    }
}
