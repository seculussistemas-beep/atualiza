<?php
/**
 * A area do cliente -- 10/09/2026, tarde. Tela PUBLICA, sem sessao do painel:
 * quem entra e o cliente final, pelo link assinado que o ERP recebeu na
 * resposta da licenca (ou que o membro mandou pelo WhatsApp). Ver
 * funcoes/licenca/area_cliente.php.
 *
 * O que ela faz e o mesmo que o ERP ja pode fazer pelo canal de comando:
 * ver a validade e as maquinas, ver as cobrancas em aberto com o PIX e o
 * link, avisar que pagou, conferir o pagamento no provedor, pedir prazo em
 * confianca. NADA aqui libera licenca: pagar continua passando pela ponte de
 * sempre.
 *
 * A pagina ate 10/09/2026 era a "Area do Cliente" herdada, que exigia login
 * proprio e mostrava so a validade.
 */

require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/area_cliente.php';
require_once __DIR__ . '/../../funcoes/licenca/situacao.php';
require_once __DIR__ . '/../../funcoes/licenca/parque.php';
require_once __DIR__ . '/../../funcoes/licenca/confianca.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca_motor.php';
require_once __DIR__ . '/../../funcoes/notificacao/comando_erp.php';
require_once __DIR__ . '/../../funcoes/contrato/contrato.php'; // o contrato e o aceite (01/10/2026)

if (session_status() !== PHP_SESSION_ACTIVE) {
    require_once __DIR__ . '/../../funcoes/nucleo/sessao.php'; shield_sessao_abrir();
}

// DUAS PORTAS (10/09/2026, tarde): o link (do ERP ou do WhatsApp) e a
// entrada por e-mail da loja + senha. O LINK NAO ENTRA SOZINHO: ele so
// preenche o e-mail e pede a senha -- o dono do produto nao quis link que
// abre a loja de quem o tiver na mao. A sessao e o que as acoes usam.
$token = (string) ($_GET['t'] ?? $_POST['t'] ?? '');
$segredo = shield_area_segredo();
$codigo = null;
$linkInvalido = false;
$erroEntrada = '';
$emailDoLink = '';
if ($token !== '') {
    $codigoDoLink = $segredo !== null ? shield_area_validar($token, $segredo) : null;
    $linkInvalido = $codigoDoLink === null;
    if ($codigoDoLink !== null) {
        $stmt = $pdo->prepare('SELECT email FROM empresa WHERE codigo = :c LIMIT 1');
        $stmt->execute(array(':c' => $codigoDoLink));
        $emailDoLink = (string) ($stmt->fetchColumn() ?: '');
    }
}
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['acao'] ?? '') === 'sair') {
    unset($_SESSION['area_cliente']);
    header('Location: /area_cliente.php');
    exit;
}
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['acao'] ?? '') === 'entrar') {
    require_once __DIR__ . '/../../funcoes/acesso/limite_login.php';
    $emailDigitado = trim((string) ($_POST['email'] ?? ''));
    $chaveLimite = 'area:' . $emailDigitado;
    // CINCO ERROS BLOQUEIAM POR CINCO MINUTOS (pedido do dono do produto).
    $bloqueio = shield_login_bloqueado($pdo, $chaveLimite, 5, 5);
    if ($bloqueio !== null) {
        $erroEntrada = $bloqueio;
    } else {
        $codigo = shield_area_entrar($pdo, $emailDigitado, (string) ($_POST['senha'] ?? ''));
        if ($codigo === null) {
            shield_login_registrar_falha($pdo, $chaveLimite);
            $erroEntrada = 'E-mail ou senha nao conferem, ou a senha temporaria venceu. Pe&ccedil;a uma senha nova a quem lhe atende.';
        } else {
            shield_login_limpar($pdo, $chaveLimite);
            session_regenerate_id(true);
            $_SESSION['area_cliente'] = $codigo;
        }
    }
}
if ($codigo === null && !empty($_SESSION['area_cliente'])) {
    $codigo = (int) $_SESSION['area_cliente'];
}
$empresa = null;
if ($codigo !== null) {
    $stmt = $pdo->prepare('SELECT * FROM empresa WHERE codigo = :c LIMIT 1');
    $stmt->execute(array(':c' => $codigo));
    $empresa = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}
if ($empresa === null) {
    // Link mexido responde 403 (e para robo); sem link e sem sessao e a
    // porta de entrada, que e uma pagina normal.
    if ($linkInvalido) {
        http_response_code(403);
    }
    $page_title = $linkInvalido ? 'Link inv&aacute;lido' : 'Entrar';
    $semLink = true;
}

$aviso = '';
$erro = '';
$trocaObrigatoria = $empresa !== null && !empty($empresa['area_senha_temporaria']);

// O PDF DO CONTRATO ACEITO (01/10/2026). So depois de entrar, e so o que foi
// aceito: o texto vem do registro do aceite, e nao do modelo de hoje.
if ($empresa !== null && !$trocaObrigatoria && (string) ($_GET['contrato'] ?? '') === 'pdf') {
    $aceitoPdf = shield_contrato_ultimo_aceite($pdo, (int) $empresa['codigo']);
    if ($aceitoPdf !== null) {
        shield_contrato_enviar_pdf(
            shield_contrato_pdf((string) $aceitoPdf['texto'], (string) $aceitoPdf['hash'], $aceitoPdf, $empresa),
            shield_contrato_nome_arquivo($empresa, true)
        );
    }
}

// O PDF DO BOLETO (19/10/2026), para o provedor que nao da link publico dele (o
// Inter). So a cobranca DESTA loja: shield_cobranca_boleto_pdf confere o dono, e
// sem isso o numero na URL abriria o boleto de outra. O motivo cru vai para o
// error_log; a tela publica so diz o que fazer (4.1.35).
if ($empresa !== null && !$trocaObrigatoria && isset($_GET['boleto'])) {
    try {
        shield_cobranca_enviar_pdf(shield_cobranca_boleto_pdf($pdo, (int) $_GET['boleto'], (int) $empresa['codigo']));
    } catch (Throwable $e) {
        error_log('[area_cliente] boleto ' . (int) $_GET['boleto'] . ': ' . $e->getMessage());
        $erro = 'Nao foi possivel buscar o boleto agora. Tente de novo em alguns minutos, ou use o PIX ou a linha digitavel.';
    }
}

if ($empresa !== null && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $acao = (string) ($_POST['acao'] ?? '');
    try {
        if ($acao === 'aceitar_contrato' && !$trocaObrigatoria) {
            // O "LI E ACEITO" E MARCADO, NAO SO CLICADO: o required da caixa a tela
            // confere, e o servidor confere de novo. O hash e o do texto que a tela
            // mostrou; se o membro mexeu no modelo no meio, o aceite e recusado.
            //
            // AS FRASES DO ACEITE APARECEM, e as do banco nao: o catch geral desta tela
            // troca toda mensagem por uma generica, para nao entregar SQL a quem nao e
            // do painel. PDOException e filha de RuntimeException, entao ela e
            // devolvida ao catch geral antes; o resto e frase escrita aqui.
            try {
                if (empty($_POST['li'])) {
                    throw new RuntimeException('Marque "Li e aceito" para aceitar o contrato.');
                }
                shield_contrato_aceitar(
                    $pdo,
                    $empresa,
                    (string) ($_POST['hash'] ?? ''),
                    (string) ($empresa['email'] ?? ''),
                    (string) ($_SERVER['REMOTE_ADDR'] ?? ''),
                    (string) ($_SERVER['HTTP_USER_AGENT'] ?? '')
                );
                $aviso = 'Contrato aceito. O PDF com o registro do aceite fica dispon&iacute;vel aqui.';
            } catch (PDOException $banco) {
                throw $banco;
            } catch (RuntimeException $recusa) {
                $erro = $recusa->getMessage();
            }
        } elseif ($acao === 'trocar_senha') {
            // A SENHA TEMPORARIA E TROCADA NO PRIMEIRO ACESSO: ate la a pagina
            // nao mostra nada alem deste formulario.
            $nova = (string) ($_POST['senha'] ?? '');
            if ($nova !== (string) ($_POST['senha2'] ?? '')) {
                throw new RuntimeException('As duas senhas nao conferem.');
            }
            shield_area_senha_definir($pdo, $codigo, $nova);
            $trocaObrigatoria = false;
            $empresa['area_senha_temporaria'] = null;
            $aviso = 'Senha definida. Guarde-a: &eacute; com ela que voc&ecirc; entra daqui em diante.';
        } elseif ($trocaObrigatoria) {
            throw new RuntimeException('Defina a sua senha antes de continuar.');
        } elseif ($acao === 'gerar') {
            // GERAR O CODIGO DE UMA FATURA SEM CODIGO (10/09/2026, tarde): a
            // conta e a fixa da assinatura ou a padrao; sem nenhuma, a loja
            // pede a quem a atende. Emitir e o mesmo caminho do membro.
            require_once __DIR__ . '/../../funcoes/cobranca/assinatura.php';
            $cobId = (int) ($_POST['cobranca'] ?? 0);
            $stmt = $pdo->prepare("SELECT c.id, COALESCE(a.fk_conta, 0) AS conta FROM cobranca c LEFT JOIN assinatura a ON a.id = c.fk_assinatura
                                    WHERE c.id = :id AND c.fk_empresa = :e AND c.situacao IN ('aberta', 'vencida', 'rascunho') LIMIT 1");
            $stmt->execute(array(':id' => $cobId, ':e' => $codigo));
            $linha = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!is_array($linha)) {
                throw new RuntimeException('Esta fatura nao esta em aberto.');
            }
            $contaGerar = (int) $linha['conta'] > 0 ? (int) $linha['conta'] : shield_conta_padrao($pdo);
            if ($contaGerar <= 0) {
                // Sem conta fixa nem padrao: a conta por onde a ultima fatura
                // desta loja saiu e a melhor aposta.
                $st = $pdo->prepare('SELECT t.fk_conta FROM cobranca_tentativa t JOIN cobranca c ON c.id = t.fk_cobranca
                                      WHERE c.fk_empresa = :e AND t.fk_conta IS NOT NULL ORDER BY t.id DESC LIMIT 1');
                $st->execute(array(':e' => $codigo));
                $contaGerar = (int) ($st->fetchColumn() ?: 0);
            }
            if ($contaGerar <= 0) {
                throw new RuntimeException('Esta fatura ainda não tem por onde ser paga. Peça o código a quem lhe atende.');
            }
            // JA TEM CODIGO? ENTAO NAO GERA OUTRO (11/09/2026). O botao some
            // da tela quando ha codigo, mas F5 reenvia o POST e o cliente
            // acabava com dois PIX vivos -- e o painel so olhando o ultimo, o
            // que ele provavelmente NAO copiou. Aqui a resposta e "ja esta
            // pronto", e nao um erro: para ele nada deu errado.
            $viva = shield_cobranca_tentativa_viva($pdo, $cobId);
            if ($viva !== null && (string) $viva['provedor'] === 'dinheiro') {
                // Aba antiga com o botao: a fatura em dinheiro nao tem codigo nenhum.
                $aviso = 'Esta fatura &eacute; a pagar em dinheiro a quem lhe atende.';
            } elseif ($viva !== null) {
                $aviso = 'O c&oacute;digo desta fatura j&aacute; est&aacute; pronto, logo abaixo.';
            } else {
                shield_cobranca_emitir($pdo, $cobId, $contaGerar);
                $aviso = 'C&oacute;digo gerado. Pague por ele.';
            }
        } elseif ($acao === 'informar') {
            $r = shield_comando_informar_pagamento($pdo, $empresa, (int) ($_POST['cobranca'] ?? 0),
                (string) ($_POST['forma'] ?? ''), (string) ($_POST['obs'] ?? ''), 'area do cliente');
            $aviso = $r === '' ? 'Aviso enviado. Quem recebe confere o pagamento e a licen&ccedil;a anda em seguida.' : shield_h($r);
        } elseif ($acao === 'conferir') {
            // UMA CONSULTA AO PROVEDOR POR CLIQUE, e no maximo uma a cada dois
            // minutos por cobranca: e a mesma pergunta que o webhook e a
            // conciliacao fazem, so que disparada por quem esta com o link.
            $cobId = (int) ($_POST['cobranca'] ?? 0);
            $ultima = (int) ($_SESSION['area_conferiu'][$cobId] ?? 0);
            if ($ultima > 0 && time() - $ultima < 120) {
                throw new RuntimeException('Acabou de conferir. Espere dois minutos e tente de novo.');
            }
            $_SESSION['area_conferiu'][$cobId] = time();
            $r = shield_comando_conferir_pagamento($pdo, $empresa, $cobId);
            $aviso = $r === 'paga'
                ? 'Pagamento confirmado. Obrigado!'
                : ($r === '' ? 'Esta cobran&ccedil;a n&atilde;o tem a quem perguntar; avise que pagou.' : 'O provedor ainda diz: ' . shield_h($r) . '. Pode levar alguns minutos.');
            $stmt = $pdo->prepare('SELECT * FROM empresa WHERE codigo = :c LIMIT 1');
            $stmt->execute(array(':c' => $codigo));
            $empresa = $stmt->fetch(PDO::FETCH_ASSOC) ?: $empresa;
        } elseif ($acao === 'prazo') {
            $r = shield_confianca_conceder($pdo, $empresa, (string) ($_POST['quem'] ?? 'cliente'), 'area');
            $aviso = !empty($r['ok'])
                ? 'Prazo concedido at&eacute; ' . shield_h(date('d/m/Y', strtotime((string) $r['ate']))) . '. Abra o sistema de novo para a licen&ccedil;a andar.'
                : shield_h((string) $r['motivo']);
        }
    } catch (Throwable $e) {
        // ESTA TELA E PUBLICA -- 16/09/2026. Quem a abre e o lojista, pelo link
        // assinado, e o texto cru de uma PDOException entrega nome de tabela,
        // coluna e pedaco de SQL a quem nao e do painel. O detalhe vai para o
        // log do servidor, que e onde o suporte olha; na tela fica o que a
        // pessoa pode fazer.
        error_log('[area_cliente] ' . $e->getMessage());
        $erro = 'Não consegui concluir agora. Tente de novo em instantes ou avise quem lhe atende.';
    }
}

if ($empresa !== null) {
    $situacao = shield_situacao_licenca($empresa);
    $vivos = (int) (shield_parque_vivos_por_empresa($pdo, array($codigo))[$codigo] ?? 0);
    $abertas = shield_comando_cobrancas($pdo, $empresa, 20);
    $promessa = shield_promessa_aberta($pdo, $codigo);
    $confianca = shield_confianca_oferta($pdo, $empresa);
    $contrato = shield_contrato_situacao($pdo, $empresa);
    // TODAS AS FATURAS (10/09/2026, tarde): o link e fixo, entao a pagina e o
    // extrato do cliente, e nao so o que esta em aberto.
    $fechadas = array();
    try {
        $stmt = $pdo->prepare("SELECT id, descricao, valor_pago_centavos, valor_centavos, vencimento, pago_em, situacao FROM cobranca WHERE fk_empresa = :e AND situacao IN ('paga', 'cancelada', 'estornada') ORDER BY COALESCE(pago_em, vencimento) DESC, id DESC LIMIT 36");
        $stmt->execute(array(':e' => $codigo));
        $fechadas = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
    } catch (Throwable $semTabela) {
    }
    $totalAberto = 0;
    foreach ($abertas as $c) {
        if ((string) $c['situacao'] !== 'rascunho') {
            $totalAberto += (int) $c['valor'];
        }
    }
    $page_title = 'Sua licen&ccedil;a';
}
// Quem atende: o que o membro grava em Minha empresa (shield_area_contato).
$quem = shield_area_contato($pdo);
$nomeQuem = $quem['nome'];
$foneQuem = $quem['fone'];
$emailQuem = $quem['email'];
?>
<?php
// A ENTRADA E A MESMA FOLHA DO LOGIN DO PAINEL (10/09/2026, tarde): a metade
// escura com a marca, o formulario a direita, o olho na senha. So a pagina
// de dentro tem o desenho proprio.
if (!empty($semLink) || $trocaObrigatoria) {
    require_once __DIR__ . '/../../templates/entrada.php';
    shield_entrada_abrir($trocaObrigatoria ? 'Defina a sua senha' : 'Área do cliente');
    // PARECIDA, NAO IGUAL (10/09/2026, tarde): mesma folha do login do painel,
    // mas o fundo puxa para o azul-petroleo e o texto da marca fala com o
    // lojista, para ninguem confundir com a entrada do membro.
    ?>
    <style>
        :root { --grafite-fundo: #072a33; --grafite: #0c3a46; --grafite-alto: #114857; --grafite-borda: #1a5d6d; --grafite-texto: #e6f2f4; }
        .fundo .grad { background: radial-gradient(1200px 600px at 20% 10%, rgba(2,200,240,.22), transparent 60%), radial-gradient(900px 500px at 80% 90%, rgba(0,105,127,.35), transparent 60%); }
        .marca .logo { filter: drop-shadow(0 0 18px rgba(2,200,240,.35)); }
    </style>
    <script>
        (function () {
            var h = document.querySelector('.marca h1'), p = document.querySelector('.marca p'), ul = document.querySelector('.marca ul');
            if (h) { h.textContent = 'Bem-vindo à sua área.'; }
            if (p) { p.textContent = 'Aqui você acompanha a licença do seu sistema, vê as faturas e resolve o pagamento sem ligar para ninguém.'; }
            if (ul) { ul.innerHTML = '<li><i>✓</i>Veja até quando o sistema está liberado</li><li><i>✓</i>Pague por PIX, boleto ou cartão</li><li><i>✓</i>Avise que pagou ou peça um prazo</li>'; }
        })();
    </script>
    <?php
    if ($trocaObrigatoria) {
        ?>
                <h2>Defina a sua senha</h2>
                <p class="sub"><?= shield_h((string) $empresa['razao']); ?> · você entrou com uma senha temporária. Escolha a sua para continuar.</p>
                <?php if ($erro !== ''): ?><div class="alert alert-danger" role="alert"><?= shield_h($erro); ?></div><?php endif; ?>
                <form action="/area_cliente.php" method="post" data-valida novalidate>
                    <input type="hidden" name="acao" value="trocar_senha">
                    <div class="campo">
                        <label for="senha">Nova senha</label>
                        <div class="senha-caixa">
                            <input type="password" class="senha" name="senha" id="senha" placeholder="mínimo 6" autocomplete="new-password" required minlength="6" maxlength="72" autofocus>
                            <?= shield_entrada_olho(); ?>
                        </div>
                        <div class="aviso">Pelo menos 6 caracteres.</div>
                    </div>
                    <div class="campo">
                        <label for="senha2">Repita a senha</label>
                        <div class="senha-caixa">
                            <input type="password" class="senha" name="senha2" id="senha2" placeholder="a mesma senha" autocomplete="new-password" required minlength="6" maxlength="72">
                            <?= shield_entrada_olho(); ?>
                        </div>
                        <div class="aviso">Repita a senha.</div>
                    </div>
                    <button type="submit" class="entrar" data-enviando="Guardando…"><span class="giro" aria-hidden="true"></span><span>Guardar e continuar</span></button>
                </form>
        <?php
    } else {
        ?>
                <h2>Área do cliente</h2>
                <p class="sub"><?= $nomeQuem !== '' ? shield_h($nomeQuem) . ' · ' : ''; ?>entre com o e-mail da loja e a senha que a sua softwarehouse definiu.</p>
                <?php if ($linkInvalido): ?>
                    <div class="alert alert-warning" role="status">Este link foi alterado ou não vale mais. Entre com o e-mail e a senha, ou peça o link a quem lhe atende.</div>
                <?php endif; ?>
                <?php if ($erroEntrada !== ''): ?><div class="alert alert-danger" role="alert"><?= $erroEntrada; ?></div><?php endif; ?>
                <form action="/area_cliente.php" method="post" data-valida novalidate>
                    <input type="hidden" name="acao" value="entrar">
                    <div class="campo">
                        <label for="email">E-mail da loja</label>
                        <input type="email" name="email" id="email" placeholder="loja@exemplo.com.br" autocomplete="username" required maxlength="255"
                               value="<?= shield_h((string) ($_POST['email'] ?? $emailDoLink)); ?>">
                        <div class="aviso">Informe o e-mail da loja.</div>
                    </div>
                    <div class="campo">
                        <label for="senha">Senha</label>
                        <div class="senha-caixa">
                            <input type="password" class="senha" name="senha" id="senha" placeholder="Sua senha" autocomplete="current-password" required minlength="6" maxlength="72" <?= $emailDoLink !== '' ? 'autofocus' : ''; ?>>
                            <?= shield_entrada_olho(); ?>
                        </div>
                        <div class="aviso">Informe a senha.</div>
                    </div>
                    <button type="submit" class="entrar" data-enviando="Entrando…"><span class="giro" aria-hidden="true"></span><span>Entrar</span></button>
                </form>
                <div class="alt">Esqueceu a senha? Peça uma nova a quem lhe atende.</div>
        <?php
    }
    shield_entrada_fechar();
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?= $page_title; ?></title>
    <link rel="icon" href="/img/favicon-32.png" sizes="32x32">
    <link rel="stylesheet" href="/vendor/bootstrap5/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/icones.css?v=<?= (int) @filemtime(__DIR__ . '/../../public/css/icones.css'); ?>">
    <link rel="stylesheet" href="/css/painel.css?v=<?= (int) @filemtime(__DIR__ . '/../../public/css/painel.css'); ?>">
    <style>
        /* A pagina do cliente: um fundo com a faixa da marca no alto, a folha no meio. */
        body { background: #eef1f5; min-height: 100vh; }
        body::before { content: ""; position: fixed; inset: 0 0 auto 0; height: 13.75rem; background: linear-gradient(135deg, #0b5f6e, #0e7c8c 55%, #12a3b0); z-index: -1; }
        .area { max-width: 56.25rem; margin: 0 auto; padding: 1.5rem 1rem 3rem; }
        .cabeca { color: #fff; display: flex; align-items: center; gap: 1rem; flex-wrap: wrap; padding: .25rem 0 1.25rem; }
        .cabeca img { width: 3.375rem; height: 3.375rem; filter: drop-shadow(0 2px 6px rgba(0,0,0,.25)); }
        .cabeca .quem { font-size: .8rem; opacity: .8; letter-spacing: .04em; text-transform: uppercase; }
        .cabeca h1 { font-size: 1.35rem; margin: 0; font-weight: 700; }
        .cabeca .num { font-size: .85rem; opacity: .85; }
        .tiles { display: grid; grid-template-columns: repeat(auto-fit, minmax(12.5rem, 1fr)); gap: .9rem; margin-bottom: 1rem; }
        .tile { background: #fff; border-radius: .8rem; padding: 1rem 1.1rem; box-shadow: 0 6px 20px rgba(11,95,110,.10); display: flex; gap: .9rem; align-items: center; }
        .tile .ico { width: 2.625rem; height: 2.625rem; border-radius: .7rem; display: grid; place-items: center; color: #0e7c8c; background: #e3f4f6; font-size: 1.1rem; flex: 0 0 auto; }
        .tile .rotulo { font-size: .72rem; text-transform: uppercase; letter-spacing: .06em; color: #6b7280; }
        .tile .valor { font-size: 1.25rem; font-weight: 700; line-height: 1.2; }
        .tile .sub { font-size: .8rem; color: #6b7280; }
        .folha { background: #fff; border-radius: .8rem; box-shadow: 0 6px 20px rgba(11,95,110,.08); margin-bottom: 1rem; overflow: hidden; }
        .folha > .titulo { padding: .85rem 1.1rem; font-weight: 700; border-bottom: 1px solid #eef1f5; display: flex; align-items: center; justify-content: space-between; }
        .folha > .corpo { padding: 1.1rem; }
        .fatura { border: 1px solid #e5e7eb; border-left: .35rem solid #0e7c8c; border-radius: .7rem; padding: 1rem 1.1rem; margin-bottom: .85rem; }
        .fatura.vencida { border-left-color: #dc2626; }
        .fatura .nome { font-weight: 700; font-size: 1.02rem; }
        .fatura .vlr { font-size: 1.35rem; font-weight: 700; white-space: nowrap; }
        .copia { font-family: ui-monospace, Consolas, monospace; font-size: .76rem; word-break: break-all; background: #f6f8fa; border: 1px dashed #cfd6de; border-radius: .5rem; padding: .6rem .7rem; }
        .qr-pix { display: block; width: 12.5rem; height: 12.5rem; background: #fff; border: 1px solid #e5e7eb; border-radius: .5rem; image-rendering: pixelated; }
        .pagar { display: flex; flex-wrap: wrap; gap: 1rem; align-items: stretch; }
        .pagar .qr-pix { flex: 0 0 auto; align-self: flex-start; }
        /* Coluna da direita da altura do QR: o aviso de pagamento desce para o pe. */
        .pagar-dados { flex: 1 1 16rem; min-width: 0; display: flex; flex-direction: column; }
        .pagar-aviso { margin-top: auto; padding-top: .75rem; }
        .pagar-aviso:empty { display: none; }
        .num { font-variant-numeric: tabular-nums; }
        .btn-marca { background: #0e7c8c; border-color: #0e7c8c; color: #fff; }
        .btn-marca:hover { background: #0b5f6e; border-color: #0b5f6e; color: #fff; }
        .entrada { max-width: 26.25rem; margin: 3rem auto 0; background: #fff; border-radius: .9rem; box-shadow: 0 12px 34px rgba(11,95,110,.18); padding: 2rem 2rem 1.5rem; }
        .rodape { font-size: .8rem; color: #6b7280; text-align: center; }
        table.hist td, table.hist th { vertical-align: middle; }
    </style>
</head>
<body>
<div class="area">
    <?php /* entrada e troca de senha: acima, na folha do painel. */ ?>
    <?php if (false): ?>
    <?php else: ?>
        <div class="cabeca">
            <img src="/img/escudo-256.png" alt="">
            <div class="flex-grow-1">
                <div class="quem"><?= $nomeQuem !== '' ? shield_h($nomeQuem) . ' &middot; ' : ''; ?>&aacute;rea do cliente</div>
                <h1><?= shield_h((string) $empresa['razao']); ?></h1>
                <div class="num"><?= shield_h(shield_cnpj((string) $empresa['cnpj'])); ?></div>
            </div>
            <form method="post" action="/area_cliente.php">
                <input type="hidden" name="acao" value="sair">
                <button class="btn btn-sm btn-outline-light">Sair</button>
            </form>
        </div>

        <?php if ($aviso !== ''): ?><div class="alert alert-success"><?= $aviso; ?></div><?php endif; ?>
        <?php if ($erro !== ''): ?><div class="alert alert-danger"><?= shield_h($erro); ?></div><?php endif; ?>

        <div class="tiles">
            <div class="tile">
                <div class="ico"><i class="fas fa-shield-alt"></i></div>
                <div>
                    <div class="rotulo">Licen&ccedil;a</div>
                    <div><span class="pilula pilula-<?= shield_h((string) $situacao['cor']); ?>"><?= $situacao['rotulo']; ?></span></div>
                    <div class="sub"><?= $situacao['detalhe']; ?></div>
                    <?php if ($promessa !== null): ?><div class="sub" style="color: var(--atencao)">prazo em confian&ccedil;a at&eacute; <?= shield_h(date('d/m/Y', strtotime((string) $promessa['ate']))); ?></div><?php endif; ?>
                </div>
            </div>
            <div class="tile">
                <div class="ico"><i class="fas fa-desktop"></i></div>
                <div>
                    <div class="rotulo">Caixas</div>
                    <div class="valor num"><?= $vivos; ?> <span class="fw-normal text-secondary" style="font-size: .9rem">de <?= (int) $empresa['nterminais']; ?></span></div>
                    <div class="sub">trabalhando agora, de contratados</div>
                </div>
            </div>
            <div class="tile">
                <div class="ico"><i class="fas fa-money-bill-wave"></i></div>
                <div>
                    <div class="rotulo">Em aberto</div>
                    <div class="valor num">R$ <?= shield_h(shield_dinheiro($totalAberto)); ?></div>
                    <div class="sub"><?= count($abertas) === 0 ? 'nada a pagar' : count($abertas) . ' fatura' . (count($abertas) === 1 ? '' : 's'); ?></div>
                </div>
            </div>
        </div>

        <?php /* O CONTRATO (01/10/2026). Pendente, vem antes das faturas, com o texto inteiro
                 e o "li e aceito"; aceito, vira uma linha com o PDF. Nao bloqueia nada: pagar
                 continua igual com o aceite pendente. */ ?>
        <?php if ($contrato['pendente']): ?>
            <div class="folha" id="contrato">
                <div class="titulo">
                    <span><?= $contrato['aceite'] !== null ? 'O contrato foi atualizado' : 'Contrato'; ?></span>
                    <span class="small text-secondary fw-normal">leia e aceite</span>
                </div>
                <div class="corpo">
                    <?php if ($contrato['aceite'] !== null): ?>
                        <p class="small text-secondary">
                            Voc&ecirc; aceitou a vers&atilde;o anterior em <?= shield_h(date('d/m/Y', strtotime((string) $contrato['aceite']['aceito_em']))); ?>.
                            O texto mudou desde ent&atilde;o; o aceite anterior continua guardado.
                        </p>
                    <?php endif; ?>
                    <div style="max-height: 24rem; overflow: auto; border: 1px solid #e5e7eb; border-radius: .6rem; padding: 1rem 1.1rem; background: #fafbfc; font-size: .9rem; line-height: 1.5">
                        <?php $primeira = true; ?>
                        <?php foreach (explode("\n", (string) $contrato['texto']) as $linhaContrato): ?>
                            <?php $limpa = trim($linhaContrato); ?>
                            <?php if ($limpa === ''): ?>
                                <div style="height: .55rem"></div>
                            <?php elseif ($primeira): ?>
                                <?php $primeira = false; ?>
                                <div class="fw-bold mb-2" style="font-size: 1rem"><?= shield_h($limpa); ?></div>
                            <?php elseif (strncmp($limpa, '# ', 2) === 0): ?>
                                <div class="fw-bold mt-2"><?= shield_h(trim(substr($limpa, 2))); ?></div>
                            <?php else: ?>
                                <div><?= shield_h($limpa); ?></div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    <form method="post" action="/area_cliente.php#contrato" class="mt-3">
                        <input type="hidden" name="acao" value="aceitar_contrato">
                        <input type="hidden" name="hash" value="<?= shield_h((string) $contrato['hash']); ?>">
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" id="li" name="li" value="1" required>
                            <label class="form-check-label" for="li">Li e aceito o contrato acima</label>
                        </div>
                        <button class="btn btn-marca btn-sm">Aceitar o contrato</button>
                        <div class="small text-secondary mt-2">
                            O aceite fica registrado com a data, a hora e o endere&ccedil;o de onde voc&ecirc; acessou.
                        </div>
                    </form>
                </div>
            </div>
        <?php elseif ($contrato['aplica'] && $contrato['aceite'] !== null): ?>
            <div class="folha">
                <div class="corpo py-2 d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <span class="small">
                        <i class="fas fa-check-circle me-1" style="color: var(--ok)"></i>
                        <?php $aceitoEm = strtotime((string) $contrato['aceite']['aceito_em']); ?>
                        Contrato aceito em <?= date('d/m/Y', $aceitoEm); ?> &agrave;s <?= date('H:i', $aceitoEm); ?>
                    </span>
                    <a class="btn btn-sm btn-outline-secondary" href="/area_cliente.php?contrato=pdf" target="_blank">
                        <i class="fas fa-file-download me-1"></i>Baixar o PDF
                    </a>
                </div>
            </div>
        <?php endif; ?>

        <div class="folha">
            <div class="titulo"><span>Faturas em aberto</span><span class="small text-secondary fw-normal">pague a mais antiga primeiro</span></div>
            <div class="corpo">
                <?php if ($abertas === array()): ?>
                    <p class="text-secondary mb-0"><i class="fas fa-check-circle me-1" style="color: var(--ok)"></i>Nada em aberto. Tudo em dia.</p>
                <?php endif; ?>
                <?php foreach ($abertas as $c): ?>
                    <?php
                    $vencida = (string) $c['situacao'] === 'vencida';
                    // A FATURA EM DINHEIRO NAO TEM CODIGO E NAO E PARA TER (14/09/2026):
                    // ela nasce aberta com a tentativa DIN<id>. Sem esta marca a tela
                    // oferecia gerar um codigo que o clique dizia "ja pronto" e nao havia.
                    $emDinheiro = (string) $c['provedor'] === 'dinheiro';
                    // O ROTULO SAI DO CONTEUDO (17/09/2026). O boleto hibrido leva o PIX no
                    // copia e cola, e a tela o chamava "Linha digitavel" porque a forma era
                    // boleto; a linha dele, que agora tem campo proprio, vem ao lado.
                    $codigos = \Shield\Cobranca\CodigoDePagamento::paraCopiar((string) $c['copia_e_cola'], (string) ($c['linha_digitavel'] ?? ''));
                    $temCodigo = $codigos !== array() || (string) $c['link'] !== '' || $emDinheiro;
                    $formaPag = (string) ($c['metodo'] ?: ($c['forma'] ?: 'pix'));
                    $nomes = array('pix' => 'PIX', 'boleto' => 'boleto', 'cartao' => 'cart&atilde;o', 'dinheiro' => 'dinheiro');
                    $automatico = (string) $c['provedor'] !== '' && empty($c['manual']);
                    ?>
                    <div class="fatura<?= $vencida ? ' vencida' : ''; ?>">
                        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                            <div>
                                <div class="nome"><?= shield_h((string) $c['descricao']); ?></div>
                                <div class="small text-secondary">vence <?= shield_h(date('d/m/Y', strtotime((string) $c['vencimento']))); ?>
                                    <?php if ($vencida): ?><span class="pilula pilula-erro ms-1">vencida</span><?php endif; ?>
                                    <?php if (!empty($c['informado_em'])): ?><span class="pilula pilula-atencao ms-1">voc&ecirc; avisou que pagou</span><?php endif; ?>
                                </div>
                            </div>
                            <div class="vlr num">R$ <?= shield_h(shield_dinheiro((int) $c['valor'])); ?></div>
                        </div>
                        <?php if (!$temCodigo): ?>
                            <?php /* SEM CODIGO AINDA: a loja pode gerar o dela, pela conta do contrato. */ ?>
                            <form method="post" action="/area_cliente.php" class="d-flex flex-wrap gap-2 align-items-center mt-3">
                                <input type="hidden" name="acao" value="gerar">
                                <input type="hidden" name="cobranca" value="<?= (int) $c['id']; ?>">
                                <button class="btn btn-marca btn-sm"><i class="fas fa-bolt me-1"></i>Gerar o c&oacute;digo para pagar</button>
                                <span class="small text-secondary">Esta fatura ainda n&atilde;o tem c&oacute;digo. Gere o seu e pague na hora.</span>
                            </form>
                        <?php else: ?>
                            <?php if ($emDinheiro): ?>
                                <div class="small text-secondary mt-3"><i class="fas fa-money-bill-wave me-1"></i>Fatura a pagar em dinheiro a quem lhe atende.</div>
                            <?php endif; ?>
                            <?php
                            $rotulos = array('pix' => 'PIX copia e cola', 'linha' => 'Linha digit&aacute;vel do boleto', 'codigo' => 'C&oacute;digo para pagar');
                            $botoes = array('pix' => 'Copiar o PIX', 'linha' => 'Copiar a linha', 'codigo' => 'Copiar o c&oacute;digo');
                            // O QR SAI DO PROPRIO COPIA E COLA (05/10/2026): e o mesmo BR Code,
                            // entao o painel o desenha sozinho, para qualquer provedor, sem
                            // depender da imagem que cada gateway manda (ou nao manda). Quem
                            // abre no celular continua copiando; quem abre no computador le
                            // com o celular. So o codigo PIX vira QR: a linha do boleto, nao.
                            $qrPix = '';
                            foreach ($codigos as $codigo) {
                                if ($codigo['tipo'] === 'pix') {
                                    $qrPix = (string) $codigo['valor'];
                                    break;
                                }
                            }
                            ?>
                            <?php /* O QR A ESQUERDA, O TEXTO E OS BOTOES AO LADO (06/10/2026): embaixo do
                                     QR sobrava a largura inteira da fatura vazia. Em tela estreita o
                                     bloco da direita desce para baixo do QR (flex-wrap). */ ?>
                            <div class="pagar mt-3">
                                <?php if ($qrPix !== ''): ?>
                                    <?php $areaTemQr = true; ?>
                                    <canvas class="qr-pix" width="200" height="200" data-qr="<?= shield_h($qrPix); ?>" aria-label="QR code do PIX"></canvas>
                                <?php endif; ?>
                                <div class="pagar-dados">
                            <?php foreach ($codigos as $n => $codigo): ?>
                                <div class="<?= $n > 0 ? 'mt-3' : ''; ?>">
                                    <div class="small text-secondary mb-1"><?= $rotulos[$codigo['tipo']]; ?></div>
                                    <div class="copia" id="codigo<?= (int) $c['id']; ?>_<?= (int) $n; ?>"><?= shield_h($codigo['valor']); ?></div>
                                </div>
                            <?php endforeach; ?>
                            <div class="d-flex flex-wrap gap-2 mt-2 align-items-center">
                                <?php foreach ($codigos as $n => $codigo): ?>
                                    <button type="button" class="btn btn-marca btn-sm"
                                            onclick="navigator.clipboard.writeText(document.getElementById('codigo<?= (int) $c['id']; ?>_<?= (int) $n; ?>').innerText).then(function(){ this.innerText='Copiado'; }.bind(this))"><i class="fas fa-copy me-1"></i><?= count($codigos) > 1 ? $botoes[$codigo['tipo']] : 'Copiar'; ?></button>
                                <?php endforeach; ?>
                                <?php if ((string) $c['link'] !== ''): ?>
                                    <a class="btn btn-outline-primary btn-sm" target="_blank" rel="noopener" href="<?= shield_h((string) $c['link']); ?>"><i class="fas fa-external-link-alt me-1"></i>Abrir para pagar</a>
                                <?php elseif (shield_cobranca_tem_pdf_do_painel(array('metodo_emitido' => $formaPag, 'link' => '', 'provedor' => (string) $c['provedor']))): ?>
                                    <a class="btn btn-outline-primary btn-sm" target="_blank" rel="noopener" href="/area_cliente.php?boleto=<?= (int) $c['id']; ?>"><i class="fas fa-file-download me-1"></i>Baixar o boleto</a>
                                <?php endif; ?>
                            </div>
                            <?php /* O AVISO DE PAGAMENTO EMBAIXO, na linha de baixo do QR (06/10/2026):
                                     copiar fica colado ao codigo, e o "ja paguei" fecha o bloco.
                                     Junto dos botoes de copiar, sobrava um vao embaixo. */ ?>
                            <div class="pagar-aviso d-flex flex-wrap gap-2 align-items-center">
                                <?php if ($automatico): ?>
                                    <form method="post" action="/area_cliente.php" class="d-inline">
                                        <input type="hidden" name="acao" value="conferir">
                                        <input type="hidden" name="cobranca" value="<?= (int) $c['id']; ?>">
                                        <button class="btn btn-sm btn-outline-secondary" title="Pergunta ao provedor se o pagamento entrou">J&aacute; paguei, conferir</button>
                                    </form>
                                <?php elseif (empty($c['informado_em'])): ?>
                                    <form method="post" action="/area_cliente.php" class="d-flex flex-wrap gap-2 align-items-center">
                                        <input type="hidden" name="acao" value="informar">
                                        <input type="hidden" name="cobranca" value="<?= (int) $c['id']; ?>">
                                        <input type="hidden" name="forma" value="<?= shield_h($formaPag); ?>">
                                        <input type="text" name="obs" class="form-control form-control-sm" style="width: 12rem" maxlength="150" placeholder="observa&ccedil;&atilde;o (opcional)">
                                        <button class="btn btn-sm btn-outline-secondary">Avisar que paguei por <?= $nomes[$formaPag] ?? shield_h($formaPag); ?></button>
                                    </form>
                                <?php endif; ?>
                            </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>

                <?php if ($confianca !== null && !empty($confianca['disponivel']) && $promessa === null): ?>
                    <form method="post" action="/area_cliente.php" class="d-flex flex-wrap gap-2 align-items-center mt-3 pt-3 border-top"
                          onsubmit="return confirm('Pedir <?= (int) $confianca['dias']; ?> dias de prazo? A licença continua até lá e a fatura fica em aberto.');">
                        <input type="hidden" name="acao" value="prazo">
                        <input type="text" name="quem" class="form-control form-control-sm" style="width: 14rem" maxlength="80" placeholder="seu nome" required>
                        <button class="btn btn-sm btn-outline-secondary"><i class="fas fa-hourglass-half me-1"></i>Preciso de <?= (int) $confianca['dias']; ?> dias de prazo</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>

        <div class="folha">
            <div class="titulo"><span>Hist&oacute;rico</span></div>
            <div class="corpo p-0">
                <?php if ($fechadas === array()): ?>
                    <p class="text-secondary small p-3 mb-0">Nenhuma fatura encerrada ainda.</p>
                <?php else: ?>
                    <div class="table-responsive">
                    <table class="table table-sm mb-0 hist">
                        <thead><tr><th class="ps-3">Fatura</th><th>Vencimento</th><th>Situa&ccedil;&atilde;o</th><th class="text-end pe-3">Valor</th></tr></thead>
                        <tbody>
                        <?php foreach ($fechadas as $p): ?>
                            <?php $sit = (string) $p['situacao']; ?>
                            <tr>
                                <td class="ps-3"><?= shield_h((string) $p['descricao']); ?></td>
                                <td class="text-secondary small num"><?= shield_h(date('d/m/Y', strtotime((string) $p['vencimento']))); ?></td>
                                <td>
                                    <?php if ($sit === 'paga'): ?>
                                        <span class="pilula pilula-ok">paga</span>
                                        <?php if (!empty($p['pago_em'])): ?><span class="small text-secondary">em <?= shield_h(date('d/m/Y', strtotime((string) $p['pago_em']))); ?></span><?php endif; ?>
                                    <?php elseif ($sit === 'estornada'): ?>
                                        <span class="pilula pilula-atencao">estornada</span>
                                    <?php else: ?>
                                        <span class="pilula pilula-neutro">cancelada</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end num pe-3">R$ <?= shield_h(shield_dinheiro((int) ($sit === 'paga' && (int) $p['valor_pago_centavos'] > 0 ? $p['valor_pago_centavos'] : $p['valor_centavos']))); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <p class="rodape mb-0">
            <?php if ($foneQuem !== '' || $emailQuem !== ''): ?>
                D&uacute;vidas: <?= shield_h(trim($foneQuem . ($foneQuem !== '' && $emailQuem !== '' ? ' · ' : '') . $emailQuem)); ?>.
            <?php endif; ?>
        </p>
    <?php endif; ?>
</div>
<?php if (!empty($areaTemQr)): ?>
    <script src="/js/qr.js?v=<?= (int) @filemtime(__DIR__ . '/../../public/js/qr.js'); ?>"></script>
    <script>
    (function () {
      var lista = document.querySelectorAll('canvas[data-qr]');
      for (var i = 0; i < lista.length; i++) {
        // QR que nao cabe (texto absurdo) some, e o copia e cola continua ali.
        try { shieldQr.desenhar(lista[i], lista[i].getAttribute('data-qr'), 200); }
        catch (e) { lista[i].style.display = 'none'; }
      }
    }());
    </script>
<?php endif; ?>
</body>
</html>
