<?php
/**
 * Emissao de licenca em ARQUIVO, para cliente sem internet.
 *
 * E a mesma licenca assinada que a API entrega -- mesmo formato, mesma chave,
 * mesmo conferente do lado do ERP. So muda o canal: em vez de HTTP, o membro
 * baixa o arquivo e manda por WhatsApp, e-mail ou pen drive, e o cliente larga
 * numa pasta que o ERP olha.
 *
 * DUAS diferencas em relacao a licenca da API, e as duas sao deliberadas:
 *
 *   PRAZO ESCOLHIDO. A licenca online vale poucos dias porque se renova
 *   sozinha; para quem nunca fica online isso obrigaria a mandar arquivo toda
 *   semana. Aqui o prazo e escolhido na emissao -- e nunca passa da validade
 *   que o cliente comprou.
 *
 *   SEM RENOVACAO. O arquivo nao se renova; quando vencer, o membro emite
 *   outro. Por isso prazo longo e decisao com peso: enquanto ele durar, NAO HA
 *   COMO REVOGAR aquela instalacao -- ela nao conversa com o painel.
 *
 * A licenca e amarrada a IMPRESSAO DE HARDWARE de uma maquina. Cada caixa
 * precisa do arquivo dele; e isso que faz a quantidade contratada valer
 * tambem offline.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/licenca_assinada.php';
require_once __DIR__ . '/../../funcoes/licenca/situacao.php';   // shield_cnpj
require_once __DIR__ . '/../../funcoes/licenca/parque.php';     // shield_parque_ha_quanto
require_once __DIR__ . '/../../funcoes/licenca/licenca_arquivo.php'; // shield_licenca_arquivo_conteudo

// Prazos oferecidos. Nao e campo livre de proposito: digitar data abre espaco
// para o engano de dez anos, que nao se desfaz.
const SHIELD_ARQUIVO_PRAZOS = [
    1  => '1 mes',
    2  => '2 meses',
    3  => '3 meses',
    6  => '6 meses',
    12 => '12 meses',
];

$erro = '';
$aviso = '';
$empresa = null;
$terminais = [];

$busca = trim((string) ($_GET['busca'] ?? $_POST['busca'] ?? ''));
$codigoEmpresa = (int) ($_GET['empresa'] ?? $_POST['empresa'] ?? 0);
$impressao = trim((string) ($_POST['impressao'] ?? ''));
$meses = (int) ($_POST['meses'] ?? 0);

// Todas as empresas, para escolher direto no <select>. A busca por texto
// continua para quem tem centenas de clientes e prefere digitar.
$todasEmpresas = $pdo->query('SELECT codigo, razao, cnpj FROM empresa ORDER BY razao')->fetchAll(PDO::FETCH_ASSOC) ?: [];

$achadas = [];
if ($busca !== '' && $codigoEmpresa <= 0) {
    $stmt = $pdo->prepare(
        "SELECT codigo, cnpj, razao, cidade, uf, nterminais, validade_licenca, bloqueado
           FROM empresa
          WHERE REPLACE(REPLACE(REPLACE(cnpj, '.', ''), '/', ''), '-', '') LIKE :d
             OR razao LIKE :r
          ORDER BY razao LIMIT 20"
    );
    $stmt->execute([
        ':d' => '%' . preg_replace('/\D+/', '', $busca) . '%',
        ':r' => '%' . $busca . '%',
    ]);
    $achadas = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    if (count($achadas) === 1) {
        $codigoEmpresa = (int) $achadas[0]['codigo'];
        $achadas = [];
    }
}

if ($codigoEmpresa > 0) {
    $stmt = $pdo->prepare(
        'SELECT codigo, cnpj, razao, cidade, uf, nterminais, validade_licenca, bloqueado
           FROM empresa WHERE codigo = :c'
    );
    $stmt->execute([':c' => $codigoEmpresa]);
    $empresa = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

    if ($empresa !== null) {
        $stmt = $pdo->prepare(
            'SELECT CODIGO, NOME_COMPUTADOR, APELIDO, FINGERPRINT, ULTIMO_ACESSO, VERSAO_EXE
               FROM terminais WHERE FK_EMPRESA = :c ORDER BY CODIGO'
        );
        $stmt->execute([':c' => $codigoEmpresa]);
        $terminais = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['gerar'])) {
    try {
        if ($empresa === null) {
            throw new RuntimeException('Escolha a empresa.');
        }
        if (!isset(SHIELD_ARQUIVO_PRAZOS[$meses])) {
            throw new RuntimeException('Escolha o prazo.');
        }
        if (shield_licenca_parte_impressao($impressao, 'M') === ''
            && shield_licenca_parte_impressao($impressao, 'B') === ''
            && shield_licenca_parte_impressao($impressao, 'D') === '') {
            throw new RuntimeException(
                'A identidade da maquina nao parece valida. Ela sai da tela '
                . 'Licenca do Sistema, no ERP, pelo botao F4 - Copiar.'
            );
        }

        $validade = trim((string) ($empresa['validade_licenca'] ?? ''));
        if ($validade === '') {
            throw new RuntimeException(
                'Esta empresa ainda nao tem validade de licenca. Insira a '
                . 'validade antes de emitir o arquivo.'
            );
        }

        $emissor = shield_licenca_emissor_ativo($pdo);
        if ($emissor === null) {
            throw new RuntimeException('O painel ainda nao tem par de chaves.');
        }

        // O terminal e reconciliado pelo MESMO caminho da API: se a maquina ja
        // esta na lista ele a encontra, se e nova ele a registra, e se a cota
        // esta cheia ele recusa. Emitir arquivo acima da cota seria abrir pela
        // porta de tras o que a API fecha pela frente.
        $pdo->beginTransaction();
        try {
            $terminal = shield_licenca_reconciliar_terminal(
                $pdo,
                (int) $empresa['codigo'],
                (int) ($empresa['nterminais'] ?? 0),
                $impressao,
                '',
                'ARQUIVO',
                ''
            );
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        if ((string) $terminal['status'] === 'excedente') {
            throw new RuntimeException(
                'Esta maquina passa da quantidade de terminais contratada ('
                . (string) $terminal['motivo'] . '). Aumente a quantidade '
                . 'antes de emitir.'
            );
        }

        // A MONTAGEM MORA EM funcoes/licenca/licenca_arquivo.php -- 14/09/2026.
        // Aqui ela vivia entre header() e exit, sem teste, e o contrato_ate
        // levava a validade inteira com o arquivo vencendo antes: o caixa
        // offline lia a data do contrato e parava sem aviso. Ver o cabecalho
        // de la.
        $montado = shield_licenca_arquivo_conteudo($empresa, $terminal, $impressao, $meses);
        $conteudo = $montado['conteudo'];
        $ate = $montado['ate'];
        $limitado = $montado['limitado'];

        $token = shield_licenca_assinar($emissor, $conteudo);

        $nome = 'licenca_' . preg_replace('/\D+/', '', (string) $empresa['cnpj'])
              . '_' . $ate->format('Ymd') . '.lic';

        error_log(sprintf(
            '[licenca] arquivo emitido para %s terminal=%d ate=%s%s',
            (string) $empresa['cnpj'],
            (int) $terminal['terminal'],
            $ate->format('Y-m-d'),
            $limitado ? ' (limitado pela validade)' : ''
        ));

        // Buffers limpos antes do arquivo: qualquer aviso do PHP impresso antes
        // entraria no .lic e a assinatura nao conferiria do outro lado.
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        // Ver comentario igual em modules/clientes/logs.php.
        shield_csrf_sem_filtro();
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $nome . '"');
        header('Content-Length: ' . strlen($token));
        echo $token;
        exit;
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
}
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <h1 class="h4 mb-1">Licen&ccedil;a em arquivo</h1>
        <p class="text-secondary small mb-0">
            Para cliente <strong>sem internet</strong>: voc&ecirc; gera o arquivo aqui e manda por WhatsApp, e-mail ou pen drive.
            O cliente larga na pasta <code>licenca\entrada</code> do sistema, ou abre pela tela Licen&ccedil;a do Sistema.
        </p>
    </div>
    <?php if ($empresa !== null): ?>
        <div class="acoes-pagina">
            <a href="/licenca_arquivo.php" class="btn btn-sm btn-outline-secondary"><i class="fas fa-arrow-left me-1"></i>Outro cliente</a>
        </div>
    <?php endif; ?>
</div>

<?php if ($erro !== ''): ?>
    <div class="alert alert-danger"><?= shield_h($erro); ?></div>
<?php endif; ?>

<div class="card mb-3" data-tour="lic-cliente">
    <div class="card-header">1. Escolha o cliente</div>
    <div class="card-body py-3">
        <form method="get" class="row g-2 align-items-end" autocomplete="off">
            <input type="hidden" name="r" value="licenca_arquivo">
            <div class="col-12 col-lg-5">
                <label class="form-label small mb-1" for="empresaSel">Cliente</label>
                <select id="empresaSel" name="empresa" class="form-select form-select-sm">
                    <option value="">Escolha na lista</option>
                    <?php foreach ($todasEmpresas as $te): ?>
                        <option value="<?= (int) $te['codigo']; ?>" <?= $empresa !== null && (int) $empresa['codigo'] === (int) $te['codigo'] ? 'selected' : ''; ?>>
                            <?= shield_h((string) $te['razao']); ?> &middot; <?= shield_h(shield_cnpj((string) $te['cnpj'])); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-sm-8 col-lg-4">
                <label class="form-label small mb-1" for="busca">ou procure por CNPJ / nome</label>
                <input type="text" id="busca" name="busca" class="form-control form-control-sm"
                       placeholder="CNPJ ou parte do nome" value="<?= shield_h($busca); ?>" maxlength="255">
            </div>
            <div class="col-12 col-sm-4 col-lg-3">
                <button class="btn btn-primary btn-sm w-100" type="submit"><i class="fas fa-search"></i> Abrir</button>
            </div>
        </form>

        <?php if ($achadas !== []): ?>
            <div class="table-responsive mt-3">
                <table class="lista">
                    <thead><tr>
                        <th scope="col">Empresa</th>
                        <th scope="col" class="meio">Cidade</th>
                        <th scope="col" class="meio" style="width:1%">A&ccedil;&otilde;es</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($achadas as $a): ?>
                        <tr>
                            <td class="identidade" data-r="Empresa">
                                <div>
                                    <span class="nome"><?= shield_h((string) $a['razao']); ?></span>
                                    <span class="apoio"><?= shield_h(shield_cnpj((string) $a['cnpj'])); ?></span>
                                </div>
                            </td>
                            <td class="meio" data-r="Cidade"><?= shield_h(trim((string) $a['cidade'] . ' - ' . (string) $a['uf'], ' -')); ?></td>
                            <td class="meio" data-r="A&ccedil;&otilde;es">
                                <a class="btn btn-sm btn-outline-primary" href="/licenca_arquivo.php?empresa=<?= (int) $a['codigo']; ?>">Escolher</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php elseif ($busca !== '' && $empresa === null): ?>
            <div class="form-text mt-2">Nenhuma empresa com &ldquo;<?= shield_h($busca); ?>&rdquo;.</div>
        <?php endif; ?>
    </div>
</div>

<?php if ($empresa !== null): ?>
<?php
$temValidade = trim((string) ($empresa['validade_licenca'] ?? '')) !== '';
$corteSumido = strtotime('-' . SHIELD_PARQUE_DIAS_SUMIDO . ' days');
?>
<form method="post" id="formLic">
    <input type="hidden" name="empresa" value="<?= (int) $empresa['codigo']; ?>">

    <div class="row g-3 mb-3">
        <div class="col-12 col-lg-4">
            <div class="card numero faixa<?= $temValidade ? '' : '-erro'; ?> h-100">
                <div class="rotulo">Cliente</div>
                <div class="valor" style="font-size:1.05rem"><?= shield_h((string) $empresa['razao']); ?></div>
                <div class="nota"><?= shield_h(shield_cnpj((string) $empresa['cnpj'])); ?></div>
            </div>
        </div>
        <div class="col-6 col-lg-4">
            <div class="card numero faixa<?= $temValidade ? '-ok' : '-erro'; ?> h-100">
                <div class="rotulo">Licen&ccedil;a v&aacute;lida at&eacute;</div>
                <div class="valor num"><?= $temValidade ? date('d/m/Y', strtotime((string) $empresa['validade_licenca'])) : '&mdash;'; ?></div>
                <div class="nota"><?= $temValidade ? 'o arquivo nunca passa desta data' : 'sem validade: insira em Clientes antes'; ?></div>
            </div>
        </div>
        <div class="col-6 col-lg-4">
            <div class="card numero faixa h-100">
                <div class="rotulo">Terminais contratados</div>
                <div class="valor num"><?= ($empresa['nterminais'] ?? null) === null ? '&mdash;' : (int) $empresa['nterminais']; ?></div>
                <div class="nota"><?= ($empresa['nterminais'] ?? null) === null ? 'quantidade n&atilde;o informada &middot; ' : ''; ?><?= count($terminais); ?> m&aacute;quina(s) j&aacute; conhecida(s)</div>
            </div>
        </div>
    </div>

    <div class="card mb-3" data-tour="lic-maquina">
        <div class="card-header">2. Qual m&aacute;quina</div>
        <?php if ($terminais !== []): ?>
            <div class="table-responsive">
                <table class="lista">
                    <thead><tr>
                        <th scope="col" style="width:1%"></th>
                        <th scope="col">M&aacute;quina</th>
                        <th scope="col">Identidade</th>
                        <th scope="col" class="meio">&Uacute;ltimo sinal</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($terminais as $tm):
                        $fp = trim((string) $tm['FINGERPRINT']);
                        $visto = trim((string) ($tm['ULTIMO_ACESSO'] ?? ''));
                        $sumido = ($visto === '') || (strtotime($visto) < $corteSumido);
                    ?>
                        <tr>
                            <td class="meio sem-rotulo">
                                <input class="form-check-input marcador" type="radio" name="escolha"
                                       value="<?= shield_h($fp); ?>" id="tm<?= (int) $tm['CODIGO']; ?>"
                                       <?= $fp === '' ? 'disabled' : ''; ?> <?= $impressao !== '' && $impressao === $fp ? 'checked' : ''; ?>>
                            </td>
                            <td class="identidade par" data-r="M&aacute;quina">
                                <div>
                                    <label class="nome" for="tm<?= (int) $tm['CODIGO']; ?>" style="cursor:pointer"><?= shield_h(shield_terminal_rotulo($tm)); ?></label>
                                    <span class="pilula pilula-<?= $sumido ? 'erro' : 'ok'; ?>"><?= $sumido ? 'sem sinal' : 'vivo'; ?></span>
                                    <?php if (shield_terminal_maquina_atras($tm) !== ''): ?>
                                        <span class="apoio d-block"><?= shield_h(shield_terminal_maquina_atras($tm)); ?></span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td data-r="Identidade" class="num small">
                                <?= $fp !== '' ? shield_h($fp) : '<span class="text-secondary">sem identidade gravada</span>'; ?>
                            </td>
                            <td class="meio" data-r="&Uacute;ltimo sinal"><?= shield_h(shield_parque_ha_quanto($visto)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
        <div class="card-body py-3 <?= $terminais !== [] ? 'border-top' : ''; ?>">
            <label class="form-label small mb-1" for="impressao">
                <?= $terminais !== [] ? 'Ou cole a identidade de uma m&aacute;quina que nunca esteve online' : 'Identidade da m&aacute;quina'; ?>
            </label>
            <input type="text" name="impressao" class="form-control form-control-sm num" id="impressao"
                   placeholder="M:xxxxxxxx;B:xxxxxxxx;D:xxxxxxxx" value="<?= shield_h($impressao); ?>" maxlength="120">
            <div class="form-text">Sai da tela Licen&ccedil;a do Sistema, no ERP, pelo bot&atilde;o <code>F4 &middot; Copiar</code>. Placa de rede, placa-m&atilde;e e disco.</div>
        </div>
    </div>

    <div class="card" data-tour="lic-prazo">
        <div class="card-header">3. Prazo e arquivo</div>
        <div class="card-body py-3">
            <div class="row g-2 align-items-end">
                <div class="col-12 col-sm-5 col-lg-3">
                    <label class="form-label small mb-1" for="meses">Prazo do arquivo</label>
                    <select name="meses" id="meses" class="form-select form-select-sm" required>
                        <option value="">Escolha</option>
                        <?php foreach (SHIELD_ARQUIVO_PRAZOS as $m => $rot): ?>
                            <option value="<?= (int) $m; ?>" <?= $meses === $m ? 'selected' : ''; ?>><?= shield_h($rot); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12 col-sm-7 col-lg-3">
                    <span class="form-label small mb-1 d-block">&nbsp;</span>
                    <button type="submit" name="gerar" value="1" class="btn btn-primary btn-sm w-100" <?= $temValidade ? '' : 'disabled'; ?>>
                        <i class="fas fa-file-download me-1"></i>Gerar arquivo .lic
                    </button>
                </div>
                <div class="col-12 col-lg-6">
                    <span class="form-text">
                        <strong>O arquivo n&atilde;o se renova e n&atilde;o se revoga</strong>: enquanto durar, aquela m&aacute;quina
                        trabalha sem falar com o painel. Prazo curto &eacute; a sua al&ccedil;a. Nunca passa da validade da licen&ccedil;a.
                    </span>
                </div>
            </div>
        </div>
    </div>
</form>
<?php endif; ?>

<script>
document.querySelectorAll('.marcador').forEach(function (r) {
  r.addEventListener('change', function () { document.getElementById('impressao').value = this.value; });
});
var sel = document.getElementById('empresaSel');
if (sel) {
  // Escolheu na lista: abre direto, sem precisar do botao.
  sel.addEventListener('change', function () { if (sel.value) { window.location.href = '/licenca_arquivo.php?empresa=' + sel.value; } });
}
</script>
<?php include __DIR__ . '/../../templates/fecha.php'; ?>
