<?php
/**
 * ---------------------------------------------------------------------
 * Sistema de Licenca Shield — Emissor da licenca assinada
 * ---------------------------------------------------------------------
 *
 * Gera e mostra o par de chaves que assina as licencas do ERP. A publica e
 * colada no Service/uLicencaEmissor.pas antes de compilar; a privada fica
 * cifrada no cofre do painel e nunca e exibida.
 *
 * A tela CONFERE SOZINHA: assina uma amostra e valida com openssl_verify ali
 * mesmo. Quem abrir sabe na hora se o OpenSSL do servidor faz o que o ERP
 * espera, em vez de descobrir quando a primeira loja nao abrir.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/licenca_assinada.php';
require_once __DIR__ . '/../../funcoes/nucleo/cofre.php';

if ($_SESSION['usuario']['acesso'] != 1) {
    header('Location: acesso_negado.php');
    exit;
}

$aviso = null;
$erro = null;

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['acao'] ?? '') === 'gerar') {
    try {
        shield_licenca_gerar_par($pdo);
        $aviso = 'Par de chaves gerado. Cole a chave publica no ERP e recompile — '
            . 'ate isso ser feito, as licencas novas nao serao reconhecidas pelos clientes.';
    } catch (Throwable $e) {
        $erro = 'Nao foi possivel gerar o par: ' . $e->getMessage();
    }
}

$emissor = null;

// O endereco do servico sai do proprio pedido: assim o bloco que o membro copia
// ja aponta para o painel dele. Digitado a mao e o campo que mais erra, e o
// sintoma e mudo -- o ERP simplesmente nao acha o servico.
$esquema = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = (string) ($_SERVER['HTTP_HOST'] ?? '');
$base = rtrim(str_replace(chr(92), '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? ''))), '/');
$urlServico = $host === ''
    ? 'https://SEU-PAINEL/api/licenca.php'
    : $esquema . '://' . $host . $base . '/api/licenca.php';
try {
    $emissor = shield_licenca_emissor_ativo($pdo);
} catch (Throwable $e) {
    $erro = 'Nao foi possivel ler o emissor: ' . $e->getMessage()
        . ' — a atualizacao do banco (2.1.2) ja foi executada?';
}

/**
 * Auto-conferencia: assina uma amostra e valida com a publica. E o mesmo
 * caminho que o ERP percorre, feito aqui para nao depender de ninguem abrir
 * uma loja para descobrir que o OpenSSL do servidor nao coopera.
 */
$conferencia = null;
if (is_array($emissor)) {
    try {
        $amostra = [
            'cnpj' => '00000000000000', 'fingerprint' => 'M:aaaaaaaa;B:bbbbbbbb;D:cccccccc',
            'terminal' => 0, 'status' => 'ativa', 'nterminais' => 1,
            'valido_ate' => (new DateTimeImmutable('today'))->format('Y-m-d'),
            'servidor_em' => (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s\Z'),
            'carencia' => SHIELD_LICENCA_CARENCIA_DIAS, 'emissor' => 'conferencia',
        ];
        $token = shield_licenca_assinar($emissor, $amostra);
        $partes = explode('.', $token);

        $assinatura = base64_decode(strtr($partes[2], '-_', '+/') . str_repeat('=', (4 - strlen($partes[2]) % 4) % 4), true);
        $ok = openssl_verify(
            $partes[0] . '.' . $partes[1],
            (string) $assinatura,
            (string) $emissor['chave_publica'],
            OPENSSL_ALGO_SHA256
        );

        $conferencia = [
            'ok' => $ok === 1,
            'tamanho' => strlen($token),
            'detalhe' => $ok === 1
                ? 'assinou e conferiu com a propria chave publica'
                : 'openssl_verify devolveu ' . var_export($ok, true),
        ];
    } catch (Throwable $e) {
        $conferencia = ['ok' => false, 'tamanho' => 0, 'detalhe' => $e->getMessage()];
    }
}

// A FALHA DE CIFRA DIZ A CAUSA E O CAMINHO (15/09/2026). "Falha de integridade"
// era tudo o que aparecia quando a crypto_key nao era a de quando o par foi
// gerado -- e nesse estado nenhuma licenca sai e nenhum bloqueio chega as lojas.
$explicacaoCofre = shield_cofre_falha_explicada(
    is_array($conferencia) && !$conferencia['ok'] ? (string) $conferencia['detalhe'] : (string) $erro
);

/** A constante do Delphi, pronta para copiar. */
function shield_licenca_como_pascal(string $pem): string
{
    $linhas = preg_split('/\r\n|\r|\n/', trim($pem)) ?: [];
    $saida = [];
    foreach ($linhas as $i => $linha) {
        $saida[] = "  '" . $linha . "'#13#10" . ($i === count($linhas) - 1 ? ';' : ' +');
    }

    return "  LICENCA_CHAVE_PUBLICA =\n" . implode("\n", $saida);
}
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <h1 class="h4 mb-1">Chaves da licen&ccedil;a</h1>
        <p class="text-secondary small mb-0">
            O par que assina toda licen&ccedil;a que sai deste painel. A <strong>p&uacute;blica</strong> vai dentro do ERP;
            a <strong>privada</strong> fica cifrada aqui e nunca aparece.
        </p>
    </div>
    <div class="acoes-pagina">
        <button type="button" class="btn btn-sm <?= is_array($emissor) ? 'btn-outline-danger' : 'btn-primary'; ?>"
                data-bs-toggle="modal" data-bs-target="#modalGerar">
            <i class="fas fa-key me-1"></i><?= is_array($emissor) ? 'Gerar par novo' : 'Gerar par de chaves'; ?>
        </button>
    </div>
</div>

<?php if ($aviso !== null): ?>
    <div class="alert alert-success"><?= shield_h($aviso); ?></div>
<?php endif; ?>
<?php if ($erro !== null): ?>
    <div class="alert alert-danger"><?= shield_h($erro); ?></div>
<?php endif; ?>
<?php if ($explicacaoCofre !== ''): ?>
    <div class="alert alert-danger">
        <strong>Este painel n&atilde;o consegue assinar licen&ccedil;a.</strong>
        <?= shield_h($explicacaoCofre); ?>
    </div>
<?php endif; ?>

<?php if (!is_array($emissor)): ?>
    <div class="card mb-3">
        <div class="vazio">
            <i class="fas fa-key"></i>
            Nenhum par gerado ainda. Enquanto n&atilde;o houver, o servi&ccedil;o de licen&ccedil;a responde que n&atilde;o h&aacute;
            emissor e os clientes seguem pela via de sempre &mdash; nada para de funcionar.
        </div>
    </div>
<?php else: ?>

<div class="row g-3 mb-3" data-tour="chaves-estado">
    <div class="col-6 col-lg-3">
        <div class="card numero faixa h-100">
            <div class="rotulo">N&uacute;mero da chave (kid)</div>
            <div class="valor num"><?= shield_h((string) $emissor['kid']); ?></div>
            <div class="nota">o ERP confere este n&uacute;mero antes da assinatura</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="card numero faixa h-100">
            <div class="rotulo">Gerada em</div>
            <div class="valor num" style="font-size:1.2rem"><?= shield_h(date('d/m/Y H:i', strtotime((string) $emissor['criado_em']))); ?></div>
            <div class="nota">RSA-SHA256</div>
        </div>
    </div>
    <div class="col-12 col-lg-6">
        <?php $ok = is_array($conferencia) && $conferencia['ok']; ?>
        <div class="card numero faixa<?= $ok ? '-ok' : '-erro'; ?> h-100">
            <div class="rotulo">Auto-confer&ecirc;ncia</div>
            <div class="valor" style="font-size:1.2rem">
                <span class="pilula pilula-<?= $ok ? 'ok' : 'erro'; ?>"><?= $ok ? 'OK' : 'FALHOU'; ?></span>
                <?php if (is_array($conferencia)): ?>
                    <span class="text-secondary" style="font-size:.9rem; font-weight:400"><?= shield_h((string) $conferencia['detalhe']); ?></span>
                <?php endif; ?>
            </div>
            <div class="nota">
                O painel assinou uma licen&ccedil;a de amostra e conferiu com a pr&oacute;pria chave p&uacute;blica &mdash;
                o mesmo caminho que o ERP percorre<?= $ok ? ' (token de ' . (int) $conferencia['tamanho'] . ' caracteres)' : ''; ?>.
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-xl-7">
        <div class="card h-100" data-tour="chaves-erp">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>1. Cole no ERP, em <code>Service/uLicencaEmissor.pas</code></span>
                <button type="button" class="btn btn-sm btn-outline-secondary js-copiar" data-codigo="<?= shield_h("  LICENCA_KID = '" . (string) $emissor['kid'] . "';\n\n" . shield_licenca_como_pascal((string) $emissor['chave_publica']) . "\n\n  LICENCA_URL = '" . $urlServico . "';"); ?>">
                    <i class="fas fa-copy"></i> Copiar
                </button>
            </div>
            <div class="card-body">
                <p class="small text-secondary">
                    Depois, <strong>recompile o ERP</strong>. A chave p&uacute;blica &eacute; a raiz de confian&ccedil;a e mora no
                    execut&aacute;vel, n&atilde;o em configura&ccedil;&atilde;o: sem ela l&aacute; dentro, o ERP n&atilde;o reconhece licen&ccedil;a nenhuma.
                </p>
                <pre class="log-linhas mb-0" style="max-height:none"><code>  LICENCA_KID = '<?= shield_h((string) $emissor['kid']); ?>';

<?= shield_h(shield_licenca_como_pascal((string) $emissor['chave_publica'])); ?>

  LICENCA_URL = '<?= shield_h($urlServico); ?>';</code></pre>
            </div>
        </div>
    </div>
    <div class="col-xl-5">
        <div class="card h-100" data-tour="chaves-pem">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>2. Chave p&uacute;blica, em PEM</span>
                <button type="button" class="btn btn-sm btn-outline-secondary js-copiar" data-codigo="<?= shield_h((string) $emissor['chave_publica']); ?>">
                    <i class="fas fa-copy"></i> Copiar
                </button>
            </div>
            <?php /* O corpo e uma coluna flex e a chave CRESCE: os dois cartoes tem a mesma
                     altura (h-100), mas o da esquerda e mais alto, e este ficava com um
                     vazio embaixo do texto em monitor grande. Agora a caixa da chave
                     ocupa o que sobrar. */ ?>
            <div class="card-body d-flex flex-column">
                <p class="small text-secondary">O mesmo conte&uacute;do, no formato que qualquer ferramenta OpenSSL l&ecirc;.</p>
                <textarea class="form-control form-control-sm dado flex-grow-1" rows="9" readonly onclick="this.select();" style="min-height: 12rem; resize: none;"><?= shield_h((string) $emissor['chave_publica']); ?></textarea>
                <div class="form-text">A chave privada fica cifrada no cofre do painel e n&atilde;o &eacute; exibida em lugar nenhum.</div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="card" data-tour="chaves-cota">
    <div class="card-header">Como funciona a cota</div>
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-6">
                <strong class="d-block mb-1"><i class="fas fa-desktop me-1 text-secondary"></i>O terminal &eacute; a m&aacute;quina, n&atilde;o o nome</strong>
                <span class="small text-secondary">Reconhecido pela impress&atilde;o de hardware (placa de rede, placa-m&atilde;e e disco &mdash; duas de tr&ecirc;s bastam). M&aacute;quina formatada continua sendo o mesmo terminal.</span>
            </div>
            <div class="col-md-6">
                <strong class="d-block mb-1"><i class="fas fa-hourglass-half me-1 text-secondary"></i>Vaga de quem sumiu &eacute; reaproveitada</strong>
                <span class="small text-secondary">Terminal sem sinal h&aacute; mais de <?= SHIELD_LICENCA_DIAS_FANTASMA; ?> dias deixa de ocupar vaga, e ela volta sozinha quando outra m&aacute;quina chega.</span>
            </div>
            <div class="col-md-6">
                <strong class="d-block mb-1"><i class="fas fa-lock me-1 text-secondary"></i>Quem j&aacute; tem vaga nunca a perde</strong>
                <span class="small text-secondary">S&oacute; o rec&eacute;m-chegado &eacute; recusado quando a cota est&aacute; cheia de terminais vivos.</span>
            </div>
            <div class="col-md-6">
                <strong class="d-block mb-1"><i class="fas fa-calendar-day me-1 text-secondary"></i>A licen&ccedil;a vale <?= SHIELD_LICENCA_CARENCIA_DIAS; ?> dias</strong>
                <span class="small text-secondary">E nunca passa do fim do contrato. Instala&ccedil;&atilde;o que para de conversar com o painel expira sozinha.</span>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalGerar" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="post" class="modal-content">
            <input type="hidden" name="acao" value="gerar">
            <div class="modal-header">
                <h2 class="modal-title h6 mb-0"><?= is_array($emissor) ? 'Gerar um par NOVO' : 'Gerar o par de chaves'; ?></h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <?php if (is_array($emissor)): ?>
                    <p class="mb-2"><strong>Isto invalida as licen&ccedil;as j&aacute; emitidas</strong> at&eacute; o ERP ser recompilado com a chave p&uacute;blica nova.</p>
                    <p class="small text-secondary mb-0">Toda loja com o execut&aacute;vel antigo vai recusar a licen&ccedil;a nova. S&oacute; gere se voc&ecirc; vai recompilar e distribuir o ERP em seguida.</p>
                <?php else: ?>
                    <p class="small text-secondary mb-0">O painel gera o par RSA, guarda a privada cifrada e mostra a p&uacute;blica para voc&ecirc; colar no ERP.</p>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn <?= is_array($emissor) ? 'btn-danger' : 'btn-primary'; ?> btn-sm"><i class="fas fa-key me-1"></i>Gerar</button>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
