<?php
/**
 * ---------------------------------------------------------------------
 * Sistema de Licença Shield
 * ---------------------------------------------------------------------
 * 
 * Projeto desenvolvido por: Dhones Meneses (Equipe LojaDev)
 * Website: https://lojadodesenvolvedor.com.br 
 * 
 * Descrição:
 * Este sistema foi criado para gerenciar licenças de softwares desenvolvidos em Delphi,
 * com foco no projeto Dev PDV Delphi. Ele oferece funcionalidades como controle de planos,
 * gestão de usuários, integração com gateways de pagamento e geração de relatórios.
 * 
 * Licenciamento:
 * Este software é licenciado exclusivamente para usuários do projeto Dev PDV Delphi.
 * É proibida a distribuição, modificação ou uso não autorizado deste sistema.
 * 
 * 
 * Observação:
 * Este arquivo faz parte do Sistema de Licença Shield. Certifique-se de manter os créditos
 * do desenvolvedor ao utilizar este Sistema.
 * 
 * ---------------------------------------------------------------------
 */
// adicionar_plano.php

require_once __DIR__ . '/../../funcoes/nucleo/sessao.php'; shield_sessao_abrir();

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario']['login'])) {
    header('Location: /login.php');
    exit;
}

// Inclui o arquivo de conexão com o banco de dados
require_once __DIR__ . '/../../banco.php';

$error = '';
$success = false;

// O formulario de plano novo mora na lista. Esta pagina so processa o POST;
// quem chegar por GET vai para la, onde o formulario esta.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /listar_planos.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtém os dados do formulário
    $recorrencia = isset($_POST['recorrencia']) ? trim($_POST['recorrencia']) : '';
    $valor_input = isset($_POST['valor']) ? trim($_POST['valor']) : ''; // Pega o valor como o usuário digitou
    $tipo = (($_POST['tipo'] ?? '') === 'assinatura') ? 'assinatura' : 'avulso';
    // A recorrencia tem de caber no tipo (assinatura: 1/3/6/12; pre-pago ate
    // 36) -- ate 09/09/2026 a assinatura era forcada a "1" aqui, e anual,
    // semestral e trimestral nao existiam. Nenhum plano passa de R$ 999.999,00.
    require_once __DIR__ . '/../../funcoes/planos/ciclo.php';
    $recusaCiclo = shield_plano_recorrencia_recusa($tipo, $recorrencia);
    $valorTeto = str_replace(',', '.', $valor_input);
    if (is_numeric($valorTeto) && (float) $valorTeto > 999999) {
        $error = "O valor maximo de um plano e R$ 999.999,00.";
    } elseif ($recusaCiclo !== null) {
        $error = $recusaCiclo;
    }
    $descricao = substr(trim((string) ($_POST['descricao'] ?? '')), 0, 80);

    // Validação básica
    if ($error !== '') {
        // ja tem erro (teto)
    } elseif (empty($recorrencia) || empty($valor_input)) {
        $error = "Por favor, preencha todos os campos.";
    } else {
        // Substitui a vírgula pelo ponto para formato numérico compatível com BD
        $valor_formatado = str_replace(',', '.', $valor_input);

        // Validação extra para garantir que o resultado é um número
        if (!is_numeric($valor_formatado)) {
            $error = "O valor inserido (R$) não é um número válido. Por favor, use apenas números e uma vírgula ou ponto.";
        } else {
            try {
                // Plano novo e sempre um plano novo (08/10/2026): a regra, e por
                // que o formulario deixou de atualizar o plano de mesma duracao,
                // mora em funcoes/planos/criar.php.
                require_once __DIR__ . '/../../funcoes/planos/criar.php';
                $resultado = shield_plano_criar($pdo, $tipo, $descricao, $recorrencia, $valor_formatado);

                // Volta para a lista nos tres casos: o F5 de la nao reenvia o
                // formulario, e o aviso ou a recusa aparecem onde ele mora.
                header('Location: /listar_planos.php?msg=' . ($resultado === 'ok' ? 'success' : $resultado));
                exit;

            } catch (PDOException $e) {
                $error = "Erro ao processar plano: " . $e->getMessage();
            }
        }
    }
}
?>
    <?php include __DIR__ . '/../../templates/estrutura.php'; ?>
    <style>
        .card { margin-bottom: 20px; }
        .icon-label { margin-right: 5px; color: var(--marca); }
    </style>


    <div class="container-fluid mt-4">
        <h1 class="h3 mb-4 text-gray-800">Adicionar Novo Plano</h1>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger" role="alert">
                <?= htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 fw-bold text-primary">
                    <i class="fas fa-calendar icon-label"></i> Novo Plano
                </h6>
            </div>
            <div class="card-body">
                <form action="adicionar_plano.php" method="post">
                    <div class="mb-3">
                        <label for="recorrencia">
                            <i class="fas fa-sync-alt icon-label"></i> Recorrência (meses)
                        </label>
                        <select name="recorrencia" id="recorrencia" class="form-control" required>
                            <option value="">Selecione...</option>
                            <?php for ($i = 1; $i <= 24; $i++): ?>
                                <option value="<?= $i; ?>" <?= (isset($_POST['recorrencia']) && $_POST['recorrencia'] == $i) ? 'selected' : '' ?>>
                                    <?= $i; ?> <?= $i == 1 ? 'Mês' : 'Meses'; ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="valor">
                            <i class="fas fa-money-bill-wave icon-label"></i> Valor (R$)
                        </label>
                        <input type="text" name="valor" id="valor" class="form-control" placeholder="Ex: 50,00"
                               value="<?= isset($_POST['valor']) ? htmlspecialchars($_POST['valor']) : '' ?>" maxlength="15" required>
                    </div>
                    <div class="mb-3">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-save"></i> Salvar Plano
                        </button>
                        <a href="/listar_planos.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Cancelar
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
