<?php
/**
 * ---------------------------------------------------------------------
 * Sistema de Licença Shield
 * ---------------------------------------------------------------------
 * 
 * Projeto desenvolvido por: Dhones Meneses (Equipe LojaDev)
 * Website: https://lojadodesenvolvedor.com.br
 * 
 * Descrição:
 * Este sistema foi criado para gerenciar licenças de softwares desenvolvidos em Delphi,
 * com foco no projeto Dev PDV Delphi. Ele oferece funcionalidades como controle de planos,
 * gestão de usuários, integração com gateways de pagamento e geração de relatórios.
 * 
 * Licenciamento:
 * Este software é licenciado exclusivamente para usuários do projeto Dev PDV Delphi.
 * É proibida a distribuição, modificação ou uso não autorizado deste sistema.
 * 
 * 
 * Observação:
 * Este arquivo faz parte do Sistema de Licença Shield. Certifique-se de manter os créditos
 * do desenvolvedor ao utilizar este Sistema.
 * 
 * ---------------------------------------------------------------------
 */
// excluir_plano.php

require_once __DIR__ . '/../../funcoes/nucleo/sessao.php'; shield_sessao_abrir();

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario']['login'])) {
    header('Location: /login.php');
    exit;
}

// Inclui o arquivo de conexão com o banco de dados (deve definir o objeto PDO, $pdo)
require_once __DIR__ . '/../../banco.php';

// Verifica se o parâmetro "id" foi passado via GET e se é numérico
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: /listar_planos.php");
    exit;
}

$id = (int) $_GET['id'];

// Se o formulário for submetido, processa a confirmação
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['confirmar']) && $_POST['confirmar'] === 'sim') {
        // O DELETE saiu daqui para shield_excluir_plano, que grava no livro
        // o que o plano valia -- 09/09/2026.
        require_once __DIR__ . '/../../funcoes/empresa/exclusao.php';
        shield_excluir_plano($pdo, $id);
        header("Location: /listar_planos.php?msg=deleted");
        exit;
    } else {
        // Se o usuário clicar em "Não", redireciona para a listagem de planos
        header("Location: /listar_planos.php");
        exit;
    }
}
?>
  <?php include __DIR__ . '/../../templates/estrutura.php'; ?>
  <style>
      .card {
          margin-top: 40px;
      }
  </style>

  
  <!-- Begin Page Content -->
  <div class="container-fluid mt-4">
      <div class="row justify-content-center">
          <div class="col-lg-6">
              <div class="card shadow">
                  <div class="card-header">
                      <h6 class="m-0 fw-bold text-danger">
                          <i class="fas fa-exclamation-triangle"></i> Confirmar Exclusão
                      </h6>
                  </div>
                  <div class="card-body">
                      <p>Tem certeza que deseja excluir este plano?</p>
                      <form action="excluir_plano.php?id=<?= $id; ?>" method="post">
                          <div class="mb-3">
                              <button type="submit" name="confirmar" value="sim" class="btn btn-danger">
                                  <i class="fas fa-check"></i> Sim, excluir
                              </button>
                              <a href="/listar_planos.php" class="btn btn-secondary">
                                  <i class="fas fa-times"></i> Não, cancelar
                              </a>
                          </div>
                      </form>
                  </div>
              </div>
          </div>
      </div>
  </div>
  <!-- End of Page Content -->

  <!-- Bootstrap core JavaScript (caminhos absolutos) -->
<?php include __DIR__ . '/../../templates/fecha.php'; ?>
