<?php
/**
 * ---------------------------------------------------------------------
 * Sistema de Licença Shield
 * ---------------------------------------------------------------------
 * 
 * Projeto desenvolvido por: Dhones Meneses (Equipe LojaDev)
 * Website: https://lojadodesenvolvedor.com.br 
 * 
 * Descrição:
 * Este sistema foi criado para gerenciar licenças de softwares desenvolvidos em Delphi,
 * com foco no projeto Dev PDV Delphi. Ele oferece funcionalidades como controle de planos,
 * gestão de usuários, integração com gateways de pagamento e geração de relatórios.
 * 
 * Licenciamento:
 * Este software é licenciado exclusivamente para usuários do projeto Dev PDV Delphi.
 * É proibida a distribuição, modificação ou uso não autorizado deste sistema.
 * 
 * 
 * Observação:
 * Este arquivo faz parte do Sistema de Licença Shield. Certifique-se de manter os créditos
 * do desenvolvedor ao utilizar este Sistema.
 * 
 * ---------------------------------------------------------------------
 */
// editar_plano.php

require_once __DIR__ . '/../../funcoes/nucleo/sessao.php'; shield_sessao_abrir();

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario']['login'])) {
    header("Location: /login.php");
    exit;
}

// Inclui o arquivo de conexão com o banco de dados
require_once __DIR__ . '/../../banco.php';

$error = '';

// O formulario mora no modal da lista. Quem chega por GET vai para la.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /listar_planos.php');
    exit;
}

// A SENHA DE QUEM ESTA LOGADO confirma a mudanca. Plano e preco de tabela:
// alterar sem querer muda o que todo cliente novo paga.
$senhaConfirma = (string) ($_POST['senha'] ?? '');
$usuarioLogado = (int) ($_SESSION['usuario']['id'] ?? 0);
$stmtSenha = $pdo->prepare('SELECT senha FROM usuario WHERE id = :id');
$stmtSenha->execute(array(':id' => $usuarioLogado));
$hashLogado = (string) $stmtSenha->fetchColumn();
if ($senhaConfirma === '' || $hashLogado === '' || !password_verify($senhaConfirma, $hashLogado)) {
    header('Location: /listar_planos.php?msg=senha');
    exit;
}

// A REGRA MORA EM funcoes/planos/criar.php (08/10/2026), como a do criar: a
// duracao pode repetir a de outro plano, o nome nao se repete no mesmo tipo e
// o tipo nao muda. Toda resposta volta para a lista, onde o formulario (o modal
// de edicao) mora -- a pagina propria de edicao que existia aqui so aparecia no
// erro e dependia de uma lista de "duracoes ocupadas" que nunca era montada.
$id = (int) ($_POST['id'] ?? 0);
$recorrencia = trim((string) ($_POST['recorrencia'] ?? ''));
$valor = str_replace(',', '.', trim((string) ($_POST['valor'] ?? '')));
if ($id <= 0 || $recorrencia === '' || !is_numeric($valor) || (float) $valor <= 0 || (float) $valor > 999999) {
    header('Location: /listar_planos.php?msg=erro');
    exit;
}

require_once __DIR__ . '/../../funcoes/planos/criar.php';
try {
    $resultado = shield_plano_editar($pdo, $id, (string) ($_POST['descricao'] ?? ''), $recorrencia, $valor);
} catch (PDOException $e) {
    error_log('editar_plano: ' . $e->getMessage());
    $resultado = 'erro';
}
$mensagens = array('ok' => 'success', 'sem_nome' => 'sem_nome', 'nome_repetido' => 'nome_repetido');
header('Location: /listar_planos.php?msg=' . ($mensagens[$resultado] ?? 'erro'));
exit;
