<?php
/**
 * ---------------------------------------------------------------------
 * Sistema de Licença Shield
 * ---------------------------------------------------------------------
 * 
 * Projeto desenvolvido por: Dhones Meneses (Equipe LojaDev)
 * Website: https://lojadodesenvolvedor.com.br 
 * 
 * Descrição:
 * Este sistema foi criado para gerenciar licenças de softwares desenvolvidos em Delphi,
 * com foco no projeto Dev PDV Delphi. Ele oferece funcionalidades como controle de planos,
 * gestão de usuários, integração com gateways de pagamento e geração de relatórios.
 * 
 * Licenciamento:
 * Este software é licenciado exclusivamente para usuários do projeto Dev PDV Delphi.
 * É proibida a distribuição, modificação ou uso não autorizado deste sistema.
 * 
 * 
 * Observação:
 * Este arquivo faz parte do Sistema de Licença Shield. Certifique-se de manter os créditos
 * do desenvolvedor ao utilizar este Sistema.
 * 
 * ---------------------------------------------------------------------
 */
// Inclua o arquivo de verificação de sessão
require_once __DIR__ . '/../../verificar_sesao.php';

// Inclua o arquivo de configuração do banco de dados (que define $pdo)
require_once __DIR__ . '/../../banco.php';

require_once __DIR__ . '/../../funcoes/cobranca/cobranca.php';   // shield_centavos, shield_dinheiro
require_once __DIR__ . '/../../funcoes/planos/ciclo.php';        // shield_plano_ciclos, shield_plano_ciclo_rotulo
$ciclosAssinatura = shield_plano_ciclos('assinatura');

try {
    // Do mais curto ao mais longo: e assim que se compara preco por mes.
    $stmt = $pdo->query("SELECT * FROM planos ORDER BY tipo DESC, CAST(recorrencia AS UNSIGNED) ASC");
    $planos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erro ao buscar planos: " . $e->getMessage());
}

$aviso = '';
$erro = '';
if (($_GET['msg'] ?? '') === 'success') {
    $aviso = 'Plano gravado.';
} elseif (($_GET['msg'] ?? '') === 'deleted') {
    $aviso = 'Plano exclu&iacute;do.';
} elseif (($_GET['msg'] ?? '') === 'senha') {
    $erro = 'A senha n&atilde;o confere. O plano n&atilde;o foi alterado.';
} elseif (($_GET['msg'] ?? '') === 'erro') {
    $erro = 'N&atilde;o foi poss&iacute;vel gravar o plano.';
} elseif (($_GET['msg'] ?? '') === 'sem_nome') {
    $erro = 'D&ecirc; um nome ao plano: &eacute; ele que separa dois planos de mesma dura&ccedil;&atilde;o na hora de escolher.';
} elseif (($_GET['msg'] ?? '') === 'nome_repetido') {
    $erro = 'J&aacute; existe outro plano com esse nome. Use outro nome, ou mude o plano que j&aacute; existe pelo Editar da linha dele.';
}
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <h1 class="h4 mb-1">Planos</h1>
        <p class="text-secondary small mb-0">
            O que voc&ecirc; vende. <strong>Assinatura</strong> gera um PIX a cada ciclo at&eacute; cancelar;
            <strong>pr&eacute;-pago</strong> paga uma vez e vale por um per&iacute;odo.
        </p>
    </div>
</div>

<?php shield_aviso_flutuante($aviso, 'msg'); ?>
<?php if ($erro !== ''): ?>
    <div class="alert alert-danger"><?= $erro; ?></div>
<?php endif; ?>

<div class="card mb-3">
    <div class="card-header">Novo plano</div>
    <div class="card-body py-3">
        <form method="post" action="/adicionar_plano.php" class="row g-2 align-items-start" autocomplete="off">
            <div class="col-12 col-lg-3">
                <span class="form-label small mb-1 d-block">Tipo</span>
                <div class="dois-lados" role="radiogroup" aria-label="Tipo do plano">
                    <input type="radio" name="tipo" id="tipo_ass" value="assinatura" checked>
                    <label for="tipo_ass">Assinatura</label>
                    <input type="radio" name="tipo" id="tipo_avu" value="avulso">
                    <label for="tipo_avu">Pr&eacute;-pago</label>
                </div>
            </div>
            <div class="col-12 col-lg-3">
                <label class="form-label small mb-1" for="descricao">Nome do plano</label>
                <input type="text" name="descricao" id="descricao" class="form-control form-control-sm" maxlength="80"
                       placeholder="Ex.: Mensal PDV" required>
            </div>
            <div class="col-6 col-lg-2">
                <label class="form-label small mb-1" for="recorrencia"><span id="rotuloMeses">A cada</span></label>
                <?php /* AS OPCOES MUDAM COM O TIPO -- 09/09/2026. Assinatura: mensal,
                         trimestral, semestral, anual (4 dos 43 pediram; antes o campo vinha
                         pregado em 1). Pre-pago: 1 a 36 meses. A lista e a mesma que o POST
                         aceita (funcoes/planos/ciclo.php); o JS so esconde o que nao cabe. */ ?>
                <select name="recorrencia" id="recorrencia" class="form-select form-select-sm" required>
                    <?php foreach (shield_plano_ciclos('avulso') as $m => $rotulo): ?>
                        <option value="<?= $m; ?>" data-ass="<?= isset($ciclosAssinatura[$m]) ? '1' : '0'; ?>"><?= $m; ?> <?= $m == 1 ? 'm&ecirc;s' : 'meses'; ?><?= isset($ciclosAssinatura[$m]) ? ' &middot; ' . shield_h($rotulo) : ''; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-6 col-lg-2">
                <label class="form-label small mb-1" for="valor">Valor (R$)</label>
                <input type="text" name="valor" id="valor" class="form-control form-control-sm num dinheiro" placeholder="149,00" required
                       data-teto="999999" title="At&eacute; R$ 999.999,00" maxlength="15">
            </div>
            <div class="col-12 col-lg-2 d-flex align-items-end" style="min-height: 3.6rem">
                <button type="submit" class="btn btn-primary btn-sm w-100"><i class="fas fa-plus-circle"></i> Criar</button>
            </div>
            <div class="col-12">
                <span class="form-text" id="ajudaTipo"></span>
            </div>
        </form>
    </div>
</div>
<script>
(function () {
  var ass = document.getElementById('tipo_ass'), avu = document.getElementById('tipo_avu');
  var rot = document.getElementById('rotuloMeses'), ajuda = document.getElementById('ajudaTipo');
  var rec = document.getElementById('recorrencia');
  function aplicar() {
    var a = ass.checked;
    rot.textContent = a ? 'A cada' : 'Vale por';
    // Assinatura so nos ciclos com nome (mensal, trimestral, semestral,
    // anual): "assinatura a cada 5 meses" nao e produto. O pre-pago aceita
    // qualquer prazo. A lista vem do PHP; aqui so se esconde o que nao cabe.
    filtrarCiclos(rec, a);
    // So o plano escolhido em "Cobrar por" compra meses (14/09/2026): a cobranca avulsa
    // ao lado dele nao move a validade, e dizer so "aparece em Cobrar por" deixava
    // entender que qualquer cobranca ali renovava o pre-pago.
    ajuda.textContent = a
      ? 'Assinatura: ao atribuir a um cliente, nasce um PIX deste valor a cada ciclo (mensal, trimestral, semestral ou anual), no dia que voce escolher.'
      : 'Pre-pago: o cliente paga uma vez e ganha acesso pelo periodo. Aparece em "Cobrar por" na Nova cobranca, e so escolhido ali compra os meses: a cobranca avulsa, de valor livre, nao move a validade.';
  }
  ass.addEventListener('change', aplicar); avu.addEventListener('change', aplicar); aplicar();
}());

// Esconde no <select> as opcoes que nao cabem no tipo, e move a escolha para
// a primeira valida se a atual sumiu. Usado pelos dois formularios (criar e
// editar). Opcao escondida por CSS ainda pode ser escolhida pelo teclado em
// alguns navegadores; por isso o POST valida de novo.
// `manter` e o ciclo que o plano JA tem: assinatura antiga "a cada 4 meses"
// continua editavel sem ser empurrada para outro ciclo sem ninguem pedir.
function filtrarCiclos(sel, assinatura, manter) {
  var primeira = null, atualSumiu = false;
  Array.prototype.forEach.call(sel.options, function (o) {
    var cabe = !assinatura || o.getAttribute('data-ass') === '1' || (manter && o.value === String(manter));
    o.hidden = !cabe;
    o.disabled = !cabe;
    if (cabe && primeira === null) { primeira = o.value; }
    if (!cabe && o.selected) { atualSumiu = true; }
  });
  if (atualSumiu && primeira !== null) { sel.value = primeira; }
}
</script>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span>Planos cadastrados</span>
        <span class="text-secondary small fw-normal"><?= count($planos); ?> plano<?= count($planos) == 1 ? '' : 's'; ?></span>
    </div>
    <div class="table-responsive">
        <table class="lista">
            <thead>
                <tr>
                    <th scope="col">Plano</th>
                    <th scope="col" class="meio">Tipo</th>
                    <th scope="col" class="num">Valor</th>
                    <th scope="col" class="num">Por m&ecirc;s</th>
                    <th scope="col" class="meio" style="width:1%">A&ccedil;&otilde;es</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($planos)): ?>
                <tr><td colspan="5" class="sem-rotulo"><div class="vazio"><i class="fas fa-calendar"></i>Nenhum plano ainda. Crie o primeiro acima.</div></td></tr>
            <?php endif; ?>
            <?php foreach ($planos as $plano):
                $meses = max(1, (int) $plano['recorrencia']);
                $centavos = shield_centavos((string) $plano['valor']);
                $assinatura = ((string) ($plano['tipo'] ?? 'avulso')) === 'assinatura';
                $nomePlano = trim((string) ($plano['descricao'] ?? '')) !== '' ? (string) $plano['descricao'] : 'Plano de ' . $meses . ' ' . ($meses == 1 ? 'mes' : 'meses');
            ?>
                <tr>
                    <td class="identidade" data-r="Plano">
                        <div>
                            <span class="nome"><?= shield_h($nomePlano); ?></span>
                            <span class="apoio">
                                <?php if ($assinatura): ?>
                                    um PIX <?= shield_h(shield_plano_ciclo_rotulo($meses)); ?>
                                <?php else: ?>
                                    paga uma vez, vale por <?= $meses; ?> <?= $meses == 1 ? 'm&ecirc;s' : 'meses'; ?>
                                <?php endif; ?>
                            </span>
                        </div>
                    </td>
                    <td class="meio" data-r="Tipo">
                        <span class="pilula pilula-<?= $assinatura ? 'ok' : 'neutro'; ?>"><?= $assinatura ? 'assinatura' : 'pr&eacute;-pago'; ?></span>
                    </td>
                    <td class="num" data-r="Valor"><strong>R$ <?= shield_h(shield_dinheiro($centavos)); ?></strong></td>
                    <td class="num" data-r="Por m&ecirc;s">R$ <?= shield_h(shield_dinheiro((int) round($centavos / $meses))); ?></td>
                    <td class="meio" data-r="A&ccedil;&otilde;es">
                        <span class="acoes">
                            <button type="button" class="acao" title="Editar o plano"
                                    data-bs-toggle="modal" data-bs-target="#modalEditarPlano"
                                    data-id="<?= (int) $plano['id']; ?>" data-tipo="<?= $assinatura ? 'assinatura' : 'avulso'; ?>"
                                    data-descricao="<?= shield_h($nomePlano); ?>" data-recorrencia="<?= $meses; ?>"
                                    data-valor="<?= shield_h(shield_dinheiro($centavos)); ?>">
                                <i class="fas fa-edit"></i></button>
                            <button type="button" class="acao perigo" data-bs-toggle="modal" data-bs-target="#modalExcluirPlano"
                                    data-id="<?= (int) $plano['id']; ?>" data-nome="<?= shield_h($nomePlano); ?> &middot; R$ <?= shield_h(shield_dinheiro($centavos)); ?>"
                                    title="Excluir o plano">
                                <i class="fas fa-trash"></i></button>
                        </span>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php /* Editar num modal, com a senha: mudar o valor de um plano muda o que
         todo cliente novo vai pagar, e um clique distraido nao pode fazer
         isso. A senha e a do usuario logado, conferida em editar_plano.php. */ ?>
<div class="modal fade" id="modalEditarPlano" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="post" action="/editar_plano.php" class="modal-content" autocomplete="off">
            <input type="hidden" name="id" id="edId" value="">
            <div class="modal-header">
                <h2 class="modal-title h6 mb-0">Editar plano</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-12">
                        <span class="form-label small mb-1 d-block">Tipo</span>
                        <?php /* O tipo nao muda depois de criado: assinatura e pre-pago sao
                                 produtos diferentes, e trocar um no outro embaralharia quem
                                 ja esta assinado nele. Para o outro tipo, cria-se um plano. */ ?>
                        <input type="radio" name="tipo" id="edTipoAss" value="assinatura" class="d-none">
                        <input type="radio" name="tipo" id="edTipoAvu" value="avulso" class="d-none">
                        <div class="campo-fixo"><span id="edTipoRotulo"></span></div>
                        <div class="form-text">O tipo n&atilde;o muda. Para o outro tipo, crie um plano novo.</div>
                    </div>
                    <div class="col-12">
                        <label class="form-label small mb-1" for="edDescricao">Nome do plano</label>
                        <input type="text" name="descricao" id="edDescricao" class="form-control form-control-sm" maxlength="80" required>
                    </div>
                    <div class="col-6">
                        <label class="form-label small mb-1" for="edRecorrencia">Meses</label>
                        <select name="recorrencia" id="edRecorrencia" class="form-select form-select-sm" required>
                            <?php foreach (shield_plano_ciclos('avulso') as $m => $rotulo): ?>
                                <option value="<?= $m; ?>" data-ass="<?= isset($ciclosAssinatura[$m]) ? '1' : '0'; ?>"><?= $m; ?> <?= $m == 1 ? 'm&ecirc;s' : 'meses'; ?><?= isset($ciclosAssinatura[$m]) ? ' &middot; ' . shield_h($rotulo) : ''; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-6">
                        <label class="form-label small mb-1" for="edValor">Valor (R$)</label>
                        <input type="text" name="valor" id="edValor" class="form-control form-control-sm num dinheiro" required data-teto="999999" title="At&eacute; R$ 999.999,00" maxlength="15">
                    </div>
                    <div class="col-12">
                        <label class="form-label small mb-1" for="edSenha">Sua senha, para confirmar</label>
                        <input type="password" name="senha" id="edSenha" class="form-control form-control-sm" autocomplete="current-password" required>
                        <div class="form-text">Mudar um plano muda o que os pr&oacute;ximos clientes pagam. Cobran&ccedil;as j&aacute; abertas n&atilde;o mudam.</div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save me-1"></i>Gravar</button>
            </div>
        </form>
    </div>
</div>
<script>
(function () {
  var m = document.getElementById('modalEditarPlano');
  if (!m) { return; }
  var edAss = document.getElementById('edTipoAss'), edAvu = document.getElementById('edTipoAvu');
  var edRec = document.getElementById('edRecorrencia');
  var cicloAtual = '';
  function travaEd() {
    filtrarCiclos(edRec, edAss.checked, cicloAtual);
  }
  edAss.addEventListener('change', travaEd); edAvu.addEventListener('change', travaEd);
  m.addEventListener('show.bs.modal', function (ev) {
    var b = ev.relatedTarget;
    document.getElementById('edId').value = b.getAttribute('data-id');
    document.getElementById(b.getAttribute('data-tipo') === 'assinatura' ? 'edTipoAss' : 'edTipoAvu').checked = true;
    document.getElementById('edTipoRotulo').textContent = b.getAttribute('data-tipo') === 'assinatura' ? 'Assinatura' : 'Pre-pago';
    document.getElementById('edDescricao').value = b.getAttribute('data-descricao');
    cicloAtual = b.getAttribute('data-recorrencia');
    document.getElementById('edRecorrencia').value = cicloAtual;
    document.getElementById('edValor').value = b.getAttribute('data-valor');
    document.getElementById('edSenha').value = '';
    travaEd();
  });
  m.addEventListener('shown.bs.modal', function () { document.getElementById('edDescricao').focus(); });
}());
</script>

<div class="modal fade" id="modalExcluirPlano" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title h6 mb-0">Excluir plano</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <p class="mb-1">Excluir o plano de <strong id="excluirPlanoNome"></strong>?</p>
                <p class="small text-secondary mb-0">Ele some de &laquo;Cobrar por&raquo;. Cobran&ccedil;as j&aacute; abertas com ele n&atilde;o mudam.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <a class="btn btn-danger btn-sm" id="excluirPlanoLink" href="#"><i class="fas fa-trash me-1"></i>Excluir</a>
            </div>
        </div>
    </div>
</div>
<script>
(function () {
  var m = document.getElementById('modalExcluirPlano');
  if (!m) { return; }
  m.addEventListener('show.bs.modal', function (ev) {
    var b = ev.relatedTarget;
    document.getElementById('excluirPlanoNome').textContent = b.getAttribute('data-nome');
    document.getElementById('excluirPlanoLink').href = '/excluir_plano.php?id=' + b.getAttribute('data-id');
  });
}());
</script>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
