<?php
/**
 * ---------------------------------------------------------------------
 * Sistema de Licenca Shield
 * ---------------------------------------------------------------------
 *
 * Projeto desenvolvido por: Dhones Meneses (Equipe LojaDev)
 * Website: https://lojadodesenvolvedor.com.br
 *
 * Descricao:
 * Este sistema foi criado para gerenciar licencas de softwares desenvolvidos em Delphi,
 * com foco no projeto Dev PDV Delphi. Ele oferece funcionalidades como controle de planos,
 * gestao de usuarios, integracao com gateways de pagamento e geracao de relatorios.
 *
 * Licenciamento:
 * Este software e licenciado exclusivamente para usuarios do projeto Dev PDV Delphi.
 * E proibida a distribuicao, modificacao ou uso nao autorizado deste sistema.
 *
 * ---------------------------------------------------------------------
 *
 * A LISTA DE CLIENTES -- 25/08/2026.
 *
 * Era uma grade de cartoes de quatro por linha. Cartao mostra POUCO e ocupa
 * MUITO: cabiam 12 clientes numa tela inteira, e para comparar dois era
 * preciso varrer o olho na diagonal. Quem opera o painel faz uma pergunta de
 * cada vez -- "quem esta vencendo?", "quem tem caixa a mais rodando?", "quem
 * me deve?" --, e essas perguntas se respondem em COLUNA, nunca em cartao.
 *
 * Esta e a tela de REFERENCIA das listagens. Os componentes que ela usa
 * (`.lista`, `.selo`, `.identidade`, `.acoes`) moram no painel.css e NAO
 * aqui: parque, terminais e cobrancas mostram a mesma coisa -- uma linha por
 * registro, um sinal de estado, dois numeros e um punhado de acoes. Componente
 * escrito dentro da tela e o que fez o painel ter duas gramaticas visuais.
 *
 * DUAS DECISOES QUE PARECEM DETALHE E NAO SAO:
 *
 * 1. Os agregados (caixas dando sinal, valor em aberto) saem em DUAS consultas
 *    para a pagina inteira, nao uma por linha. Uma consulta por cliente seriam
 *    50 idas ao banco por pagina, e a lentidao so apareceria na base do membro
 *    -- a de dev tem nove clientes e mente.
 *
 * 2. Quem decide o que e "vencido" e o `includes/situacao.php`, o MESMO que a
 *    ficha do cliente usa. Lista que conta diferente da tela que ela abre e o
 *    defeito que a Central de Notificacoes do ERP ja pagou caro.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/situacao.php';
require_once __DIR__ . '/../../funcoes/ui/lista_ui.php';
require_once __DIR__ . '/../../funcoes/licenca/parque.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca_motor.php';
require_once __DIR__ . '/../../funcoes/licenca/certificado.php'; // o certificado que o ERP informa

$filter_cnpj = isset($_GET['filter_cnpj']) ? trim($_GET['filter_cnpj']) : '';
$filter_nome = isset($_GET['filter_nome']) ? trim($_GET['filter_nome']) : '';
$filter_tipo_validade = isset($_GET['filter_tipo_validade']) ? trim($_GET['filter_tipo_validade']) : '';
$filter_uf = isset($_GET['filter_uf']) ? trim($_GET['filter_uf']) : '';
$filter_representante_cnpj = isset($_GET['representante_cnpj']) ? trim($_GET['representante_cnpj']) : '';
// Aceita 'AAAA-MM' (vence naquele mes) ou 'atrasadas'. Vem das fichas do
// Inicio; formato invalido e ignorado, nunca chega ao SQL.
$filter_vence = isset($_GET['vence']) ? trim($_GET['vence']) : '';
// Janelas de acao (a licenca aqui e mensal: o que importa e o DIA, nao o mes)
// ou um dia especifico do mes. Formato invalido e ignorado, nunca chega ao SQL.
if ($filter_vence !== ''
    && !in_array($filter_vence, array('atrasadas', 'hoje', 'semana', 'mes'), true)
    && !preg_match('/^dia-([1-9]|[12]\d|3[01])$/', $filter_vence)) {
    $filter_vence = '';
}

$whereClauses = array();
$params = array();
$page_title = 'Clientes';
$subtitulo = '';

// O LEAD NAO E CLIENTE. Quem ainda esta nos sete dias de avaliacao vive na
// tela Em avaliacao; aqui entra quem tem validade (ou ja teve e foi
// encerrado). A regra mora em situacao.php -- esta tela nao escreve a propria.
$whereClauses[] = shield_situacao_onde_cliente();

if ($filter_cnpj !== '') {
    $whereClauses[] = 'cnpj LIKE :filter_cnpj';
    $params[':filter_cnpj'] = '%' . $filter_cnpj . '%';
}
if ($filter_nome !== '') {
    $whereClauses[] = 'razao LIKE :filter_nome';
    $params[':filter_nome'] = '%' . $filter_nome . '%';
}
/* A clausula da SITUACAO fica marcada porque a faixa de numeros la em cima
   precisa contar o parque SEM ela: os seis recortes tem de continuar mostrando
   o mesmo total enquanto a pessoa pula de um para outro. Se a contagem
   respeitasse o proprio recorte, clicar em "vencidas" zeraria os outros cinco e
   a faixa deixaria de servir para escolher. Os demais filtros -- nome, CNPJ,
   UF, representante -- CONTAM, porque esses a pessoa escolheu de proposito e
   espera que o numero acompanhe. */
$idxSituacao = null;
// FAIXAS EXCLUSIVAS -- 10/09/2026, fatia 4 da reorganizacao. O filtro e o
// MESMO CASE que conta as faixas e que a pilula da linha responde em PHP
// (shield_situacao_caso_sql): cada cliente cai numa faixa so, e clicar num
// numero abre uma lista com aquele numero. Antes cada faixa tinha um WHERE
// proprio e se sobrepunham -- "bloqueadas" contava quem a regua suspendeu.
try {
    $pdo->query('SELECT 1 FROM assinatura LIMIT 1');
    $temAssinaturaLista = true;
} catch (Throwable $semTabela) {
    $temAssinaturaLista = false;   // base sem o modulo: ninguem renova sozinho
}
$faixaFiltro = shield_situacao_chave_do_filtro($filter_tipo_validade);
if ($filter_tipo_validade !== '' && $faixaFiltro === '') {
    $filter_tipo_validade = '';
}
if ($faixaFiltro !== '') {
    $whereClauses[] = '(' . shield_situacao_caso_sql('', $temAssinaturaLista) . ') = :faixa';
    $params[':faixa'] = $faixaFiltro;
    end($whereClauses);
    $idxSituacao = key($whereClauses);
}
if ($filter_vence !== '') {
    $temValidade = "validade_licenca IS NOT NULL";
    if ($filter_vence === 'atrasadas') {
        $whereClauses[] = $temValidade . ' AND validade_licenca < CURDATE()';
        $subtitulo = 'venceram e continuam rodando';
    } elseif ($filter_vence === 'hoje') {
        $whereClauses[] = $temValidade . ' AND validade_licenca = CURDATE()';
        $subtitulo = 'vencem hoje';
    } elseif ($filter_vence === 'semana') {
        $whereClauses[] = $temValidade . ' AND validade_licenca > CURDATE()'
            . ' AND validade_licenca <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)';
        $subtitulo = 'vencem nos próximos 7 dias';
    } elseif ($filter_vence === 'mes') {
        // Do OITAVO dia ao fim do mes: a ficha "em 7 dias" ja cobre o comeco,
        // e duas janelas que se sobrepoem fazem a soma das fichas mentir.
        $whereClauses[] = $temValidade
            . ' AND validade_licenca > DATE_ADD(CURDATE(), INTERVAL 7 DAY)'
            . ' AND validade_licenca <= LAST_DAY(CURDATE())';
        $subtitulo = 'vencem depois desta semana, ainda neste mês';
    } else {
        // dia-N: o dia combinado com o cliente, que volta todo mês.
        $dia = (int) substr($filter_vence, 4);
        $whereClauses[] = $temValidade . ' AND DAY(validade_licenca) = :dia';
        $params[':dia'] = $dia;
        $subtitulo = 'vencem no dia ' . $dia . ' de cada mês';
    }
}
// O CERTIFICADO DIGITAL -- 10/09/2026. O ERP passou a informar quando vence;
// dois membros pediram o filtro "vencido ou vencendo". `cert=vencido`,
// `cert=30` (vence em ate 30 dias, inclui vencido), `cert=sem`.
$filter_cert = isset($_GET['cert']) ? trim((string) $_GET['cert']) : '';
if (!in_array($filter_cert, array('', 'vencido', '30', 'sem'), true)) {
    $filter_cert = '';
}
if ($filter_cert === 'vencido') {
    $whereClauses[] = 'certificado_vence IS NOT NULL AND certificado_vence < CURDATE()';
    $subtitulo = 'com o certificado digital vencido';
} elseif ($filter_cert === '30') {
    $whereClauses[] = 'certificado_vence IS NOT NULL AND certificado_vence <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)';
    $subtitulo = 'com o certificado digital vencido ou vencendo em 30 dias';
} elseif ($filter_cert === 'sem') {
    $whereClauses[] = 'certificado_vence IS NULL';
    $subtitulo = 'sem certificado digital informado pelo ERP';
}
if ($filter_uf !== '') {
    $whereClauses[] = 'uf LIKE :filter_uf';
    $params[':filter_uf'] = '%' . $filter_uf . '%';
}
if ($filter_representante_cnpj !== '') {
    $whereClauses[] = 'cnpj_representante = :representante_cnpj';
    $params[':representante_cnpj'] = $filter_representante_cnpj;
    // Sem o nome: a tabela `representante` saiu (17/09/2026), nada a gravava.
    $subtitulo = 'somente os do representante ' . $filter_representante_cnpj;
}

// ENCERRADAS SO NO PROPRIO RECORTE (10/09/2026): em "Todas" e nos outros
// filtros elas nao aparecem -- encerrado e quem saiu, e so a faixa
// "encerradas" e a Limpeza os mostram. A clausula entra DEPOIS de copiar o
// WHERE do resumo, senao a propria faixa "encerradas" contaria zero.
$clausesLista = $whereClauses;
if ($faixaFiltro !== 'encerrado') {
    $clausesLista[] = 'encerrado_em IS NULL';
}
$whereSQL = count($clausesLista) > 0 ? ' WHERE ' . implode(' AND ', $clausesLista) : '';

// A BUSCA FICA GUARDADA (10/09/2026, tarde): quem filtrou, abriu a ficha e
// clicou em Voltar chegava na lista limpa. O "Voltar" da ficha e das telas
// do cliente volta para ESTA busca (shield_voltar_cliente); clicar em
// Clientes na lateral abre limpo, porque a lateral nao manda a query.
if (session_status() === PHP_SESSION_ACTIVE) {
    // Sem o `r=` que o roteador acrescenta: a URL guardada e a da tela.
    parse_str((string) ($_SERVER['QUERY_STRING'] ?? ''), $buscaGuardada);
    unset($buscaGuardada['r'], $buscaGuardada['page']);
    $_SESSION['clientes_ultima_busca'] = http_build_query($buscaGuardada);
}

/* O WHERE da faixa: tudo menos a situacao. Os parametros sao filtrados pelo
   que a clausula que SOBROU realmente cita -- com EMULATE_PREPARES desligado,
   mandar um parametro que a consulta nao usa e erro, e nao aviso. */
$clausesResumo = $whereClauses;
if ($idxSituacao !== null) {
    unset($clausesResumo[$idxSituacao]);
}
$whereResumo = count($clausesResumo) > 0 ? ' WHERE ' . implode(' AND ', $clausesResumo) : '';
$paramsResumo = array();
foreach ($params as $chaveParam => $valorParam) {
    if (preg_match('/' . preg_quote($chaveParam, '/') . '\b/', $whereResumo)) {
        $paramsResumo[$chaveParam] = $valorParam;
    }
}

/* ORDENACAO -- lista serve para COMPARAR, e comparar exige poder ordenar. A
   lista branca e obrigatoria: nome de coluna vindo da URL entra direto no SQL
   e nao ha como parametrizar `ORDER BY`. */
$ordens = array(
    'nome'     => 'razao',
    'id'       => 'codigo',
    'validade' => 'validade_licenca',
    'uf'       => 'uf',
);
// A ORDEM PADRAO E ALFABETICA (10/09/2026, tarde): a lista se abre com o
// telefone tocando, e quem liga diz o nome, nao o codigo.
$ord = (isset($_GET['ord']) && isset($ordens[$_GET['ord']])) ? $_GET['ord'] : 'nome';
$dir = isset($_GET['dir'])
    ? (strtolower($_GET['dir']) === 'asc' ? 'ASC' : 'DESC')
    : ($ord === 'nome' ? 'ASC' : 'DESC');
// Validade vazia e "sem licenca", nao "a mais antiga": vai para o fim nas duas
// direcoes, senao ordenar por vencimento enche a primeira pagina de quem nem
// licenca tem -- e a pergunta era justamente quem esta vencendo.
$orderBy = $ord === 'validade'
    ? "(validade_licenca IS NULL) ASC, validade_licenca " . $dir
    : $ordens[$ord] . ' ' . $dir;

$recordsPerPage = 25;
$page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
if ($page < 1) { $page = 1; }
$offset = ($page - 1) * $recordsPerPage;

$erro = '';
$empresas = array();
$totalRecords = 0;
$totalPages = 1;
$vivosPorEmpresa = array();
$cadastradasPorEmpresa = array();
$ultimoSinalPorEmpresa = array();
$renovamSozinho = array();
$abertoPorEmpresa = array();

/* As regras do teste UMA vez, e nao por linha: shield_teste_config vai ao
   banco ler dias e caixas, e a lista tem 25 linhas por pagina. */
$cfgTeste = shield_teste_config($pdo);

/* As faixas, EXCLUSIVAS e somando o total, numa consulta so -- a mesma
   funcao que o Inicio usa (shield_situacao_contar). Faixa zerada nao derruba
   a tela: a funcao devolve zeros e o numero apagado se explica. */
$resumo = shield_situacao_contar($pdo, $whereResumo, $paramsResumo);
// "Todo o parque" e quem ainda esta: as encerradas ficam so no numero delas.
$resumo['todas'] = max(0, (int) $resumo['todas'] - (int) ($resumo['encerrado'] ?? 0));

try {
    $stmt_count = $pdo->prepare('SELECT COUNT(*) FROM empresa' . $whereSQL);
    $stmt_count->execute($params);
    $totalRecords = (int) $stmt_count->fetchColumn();
    $totalPages = max(1, (int) ceil($totalRecords / $recordsPerPage));

    $stmt_data = $pdo->prepare(
        'SELECT e.* FROM empresa e' . $whereSQL . ' ORDER BY ' . $orderBy . ' LIMIT :offset, :porPagina'
    );
    foreach ($params as $chave => $valor) {
        $stmt_data->bindValue($chave, $valor);
    }
    $stmt_data->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt_data->bindValue(':porPagina', $recordsPerPage, PDO::PARAM_INT);
    $stmt_data->execute();
    $empresas = $stmt_data->fetchAll(PDO::FETCH_ASSOC) ?: array();

    /* Os dois agregados, para a PAGINA inteira. O `IN` e montado com os ids ja
       lidos do banco (inteiros vindos da PK), nunca com texto da URL. */
    $ids = array();
    foreach ($empresas as $e) { $ids[] = (int) $e['codigo']; }
    if ($ids) {
        // UM LUGAR DE CONTAR -- 10/09/2026, fatia 1 da reorganizacao. As tres
        // perguntas (caixas vivos, renova sozinho, quanto deve) saem das mesmas
        // funcoes que a ficha do cliente usa; criterio proprio aqui faria a
        // lista e a ficha discordarem sobre o mesmo cliente.
        $vivosPorEmpresa = shield_parque_vivos_por_empresa($pdo, $ids);
        $cadastradasPorEmpresa = shield_parque_cadastradas_por_empresa($pdo, $ids);
        $ultimoSinalPorEmpresa = shield_parque_ultimo_sinal_por_empresa($pdo, $ids);
        $renovamSozinho = shield_renovam_sozinho($pdo, $ids);
        $abertoPorEmpresa = shield_cobranca_em_aberto_por_empresa($pdo, $ids);
    }
} catch (Throwable $e) {
    $erro = $e->getMessage();
}

if (!function_exists('shield_url_lista')) {
    /** Esta tela com um parametro trocado. Apelido de `shield_url_com`, que
     *  vive em includes/lista_ui.php desde que a tela de Assinaturas passou a
     *  precisar do mesmo comportamento. */
    function shield_url_lista(array $troca = array())
    {
        return shield_url_com('clientes.php', $troca);
    }
}

if (!function_exists('shield_cabecalho_ordem')) {
    /** Cabecalho de coluna que ordena. Apelido de `shield_th_ordem`. */
    function shield_cabecalho_ordem($chave, $rotulo, $ordAtual, $dirAtual, $classe = '')
    {
        shield_th_ordem('clientes.php', $chave, $rotulo, $ordAtual, $dirAtual, $classe);
    }
}

?>

<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<?php
/* A FAIXA DE RECORTE -- 08/09/2026.
 *
 * Antes daqui saia um titulo, um subtitulo e a contagem; os seis recortes do
 * parque moravam escondidos num <select> chamado "Situacao". Para saber quantas
 * licencas estavam vencidas era preciso ADIVINHAR que o recorte existia, abrir
 * o campo, escolher e esperar a lista. O numero so aparecia depois de filtrar.
 *
 * Agora os seis numeros estao na tela, e cada um LEVA ao recorte que conta.
 * Numero que conta uma coisa e leva a outra e pior que numero nenhum, porque
 * quem clica confere -- por isso a contagem usa exatamente as mesmas clausulas
 * do WHERE da lista.
 *
 * O recorte em que se esta fica ACESO. Sem isso a pessoa clica, a lista muda e
 * nada na tela diz em que fatia ela caiu.
 *
 * Numero zerado perde o peso, e os que pedem acao ganham cor. Um vermelho
 * aceso o tempo todo vira paisagem: ele so precisa existir quando ha o que
 * olhar. Padrao da casa, o mesmo da Central. */
$recorteBase = array();
foreach (array('filter_nome', 'filter_cnpj', 'filter_uf', 'representante_cnpj', 'vence', 'cert', 'ord', 'dir') as $chaveRecorte) {
    if (isset($_GET[$chaveRecorte]) && trim((string) $_GET[$chaveRecorte]) !== '') {
        $recorteBase[$chaveRecorte] = (string) $_GET[$chaveRecorte];
    }
}
$linkRecorte = static function ($valor) use ($recorteBase) {
    $q = $recorteBase;
    if ($valor !== '') {
        $q['filter_tipo_validade'] = $valor;
    }
    return '/clientes.php' . ($q === array() ? '' : '?' . http_build_query($q));
};
// Sete recortes: os seis de shield_situacao_faixas mais "todo o parque".
// "Suspensas por atraso" e faixa propria (fatia 4): a saida e outra -- o
// pagamento desfaz --, e "bloqueadas por voce" volta a ser so o que voce fez.
//
// A faixa "sem licenca" MUDOU DE DONO em 11/09/2026. Ela era "a vender", e o
// que havia nela era o lead -- que agora vive em Em avaliacao. Quem sobra aqui
// e so quem fechou contrato e ainda nao pagou a primeira fatura, entao o
// rotulo passou a dizer isso.
$recortes = array(
    array('', 'todas', 'todo o<br>parque', ''),
    array('em_dia', 'valido', 'em dia<br>com a licen&ccedil;a', ''),
    array('proximos', 'vence', 'vencendo em<br>at&eacute; ' . SHIELD_VENCE_EM_BREVE . ' dias', 'atencao'),
    array('vencido', 'vencido', 'vencidas e<br>ainda rodando', 'critico'),
    array('sem_licenca', 'sem_licenca', 'aguardando o<br>1&ordm; pagamento', 'venda'),
    array('suspenso', 'suspenso', 'suspensas<br>por atraso', 'critico'),
    array('bloqueado', 'bloqueado', 'bloqueadas<br>por voc&ecirc;', 'critico'),
    array('encerrado', 'encerrado', 'encerradas<br>(a limpar)', ''),
);
?>
<?php /* `faixa-recorte`, e nao `faixa`: esse nome ja era o modificador dos cartoes
         de numero (.numero.faixa, a barra colorida a esquerda). Batizar a banda
         igual pintou de preto todo cartao que tinha a barra -- em Visao do
         cliente e em Licenca em arquivo. */ ?>
<div class="faixa-recorte">
    <header class="faixa-topo">
        <img class="faixa-simbolo" src="/img/escudo-256.png?v=<?= (int) @filemtime(__DIR__ . '/../../public/img/escudo-256.png'); ?>" alt="" aria-hidden="true">
        <div class="faixa-dizer">
            <h1 class="faixa-titulo"><?= shield_h($page_title); ?></h1>
            <p class="faixa-sub">
                <?= $subtitulo !== ''
                    ? shield_h($subtitulo)
                    : 'Quem fechou contrato: quem est&aacute; rodando, quem venceu e quem voc&ecirc; parou. Quem ainda est&aacute; avaliando fica em Em avalia&ccedil;&atilde;o.'; ?>
            </p>
        </div>
        <span class="faixa-contagem">
            <?= number_format($totalRecords, 0, ',', '.'); ?>
            <?= $filter_tipo_validade !== '' ? 'no recorte' : ('cliente' . ($totalRecords == 1 ? '' : 's')); ?>
            <?php if ($totalPages > 1): ?>
                &middot; p&aacute;g. <?= (int) $page; ?>/<?= (int) $totalPages; ?>
            <?php endif; ?>
        </span>
    </header>

    <div class="faixa-numeros">
        <?php foreach ($recortes as $r): ?>
            <?php
            list($valorR, $chaveR, $rotuloR, $tomR) = $r;
            $classes = 'faixa-numero';
            if ($tomR !== '') { $classes .= ' ' . $tomR; }
            if ($filter_tipo_validade === $valorR) { $classes .= ' aceso'; }
            if ((int) $resumo[$chaveR] === 0) { $classes .= ' zerado'; }
            ?>
            <a class="<?= $classes; ?>" href="<?= shield_h($linkRecorte($valorR)); ?>"
               <?= $filter_tipo_validade === $valorR ? 'aria-current="true"' : ''; ?>>
                <span class="n"><?= number_format((int) $resumo[$chaveR], 0, ',', '.'); ?></span>
                <span class="r"><?= $rotuloR; ?></span>
            </a>
        <?php endforeach; ?>
    </div>
</div>

<?php if ($erro !== ''): ?>
    <div class="alert alert-danger">N&atilde;o consegui montar a lista: <?= shield_h($erro); ?></div>
<?php endif; ?>

<div class="card mb-3" data-tour="clientes-filtro">
    <div class="card-body py-3">
        <form method="get" action="/clientes.php" class="row g-2 align-items-end">
            <?php if ($filter_representante_cnpj !== ''): ?>
                <input type="hidden" name="representante_cnpj" value="<?= shield_h($filter_representante_cnpj); ?>">
            <?php endif; ?>
            <?php if ($filter_vence !== ''): ?>
                <input type="hidden" name="vence" value="<?= shield_h($filter_vence); ?>">
            <?php endif; ?>
            <?php if ($filter_cert !== ''): ?>
                <input type="hidden" name="cert" value="<?= shield_h($filter_cert); ?>">
            <?php endif; ?>
            <div class="col-12 col-sm-6 col-lg-3">
                <label class="form-label small mb-1" for="filter_nome">Nome da empresa</label>
                <input type="text" class="form-control form-control-sm" id="filter_nome" name="filter_nome" maxlength="255"
                       value="<?= shield_h($filter_nome); ?>" placeholder="Parte do nome">
            </div>
            <div class="col-12 col-sm-6 col-lg-2">
                <label class="form-label small mb-1" for="filter_cnpj">CNPJ/CPF</label>
                <input type="text" class="form-control form-control-sm num" id="filter_cnpj" name="filter_cnpj" maxlength="14" inputmode="numeric"
                       oninput="this.value=this.value.replace(/\D/g,'').slice(0,14)"
                       value="<?= shield_h($filter_cnpj); ?>" placeholder="S&oacute; os n&uacute;meros">
            </div>
            <?php /* O <select> voltou ao lado dos numeros -- os dois movem o MESMO
                     parametro. A faixa e para quem ve o numero e clica; o campo e para
                     quem esta com a mao no formulario e quer combinar situacao com nome
                     ou UF sem sair dele. O vocabulario e o das pilulas da lista, para a
                     escolha aqui e o selo la embaixo falarem a mesma lingua. */ ?>
            <div class="col-8 col-sm-6 col-lg-3">
                <label class="form-label small mb-1" for="filter_tipo_validade">Situa&ccedil;&atilde;o da licen&ccedil;a</label>
                <select name="filter_tipo_validade" id="filter_tipo_validade" class="form-select form-select-sm">
                    <option value="">Todas</option>
                    <option value="em_dia" <?= $filter_tipo_validade === 'em_dia' ? 'selected' : ''; ?>>V&aacute;lida</option>
                    <option value="proximos" <?= $filter_tipo_validade === 'proximos' ? 'selected' : ''; ?>>Vence em at&eacute; <?= SHIELD_VENCE_EM_BREVE; ?> dias</option>
                    <option value="vencido" <?= $filter_tipo_validade === 'vencido' ? 'selected' : ''; ?>>Vencida</option>
                    <option value="sem_licenca" <?= $filter_tipo_validade === 'sem_licenca' ? 'selected' : ''; ?>>Aguardando o 1&ordm; pagamento</option>
                    <option value="suspenso" <?= $filter_tipo_validade === 'suspenso' ? 'selected' : ''; ?>>Suspensa por atraso</option>
                    <option value="bloqueado" <?= $filter_tipo_validade === 'bloqueado' ? 'selected' : ''; ?>>Bloqueada por voc&ecirc;</option>
                    <option value="encerrado" <?= $filter_tipo_validade === 'encerrado' ? 'selected' : ''; ?>>Encerrada</option>
                </select>
            </div>
            <?php /* UF saiu da busca em 10/09/2026: ninguem procura cliente por estado. O parametro segue aceito. */ ?>
            <?php /* Os dois botoes no CANTO direito, assentados na base dos campos, e
                     sem esticar: botao que cresce para preencher coluna vira uma barra
                     azul sem motivo. */ ?>
            <div class="col-12 col-lg-3 ms-lg-auto d-flex gap-2 justify-content-lg-end">
                <button type="submit" class="btn btn-primary btn-sm">
                    <i class="fas fa-search"></i> Filtrar
                </button>
                <a href="/clientes.php" class="btn btn-outline-secondary btn-sm">Limpar</a>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="lista">
            <thead>
                <tr>
                    <th scope="col" style="width:1%"><span class="visually-hidden">Situa&ccedil;&atilde;o</span></th>
                    <?php shield_cabecalho_ordem('nome', 'Cliente', $ord, $dir); ?>
                    <?php shield_cabecalho_ordem('validade', 'Licen&ccedil;a', $ord, $dir); ?>
                    <th scope="col" class="meio">
                        <?php /* O ERP informa na batida (10/09/2026). Cabecalho com o filtro
                                 ao lado, porque "quem esta vencendo" e a pergunta inteira. */ ?>
                        Certificado
                        <a href="/clientes.php?cert=30" class="apoio ms-1" title="S&oacute; vencido ou vencendo em 30 dias"><i class="fas fa-search"></i></a>
                    </th>
                    <th scope="col" class="meio">Caixas</th>
                    <th scope="col" class="num meio">Em aberto</th>
                    <th scope="col" class="meio">A&ccedil;&otilde;es</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$empresas): ?>
                <tr>
                    <td colspan="7" class="sem-rotulo">
                        <div class="vazio">
                            <i class="fas fa-users"></i>
                            <?php if ($filter_cnpj !== '' || $filter_nome !== '' || $filter_tipo_validade !== '' || $filter_uf !== ''): ?>
                                Nenhum cliente com esses filtros.
                                <a href="/clientes.php">Limpar e ver todos</a>.
                            <?php else: ?>
                                Ainda n&atilde;o h&aacute; clientes. Eles aparecem aqui sozinhos
                                quando o ERP se registra pela primeira vez.
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endif; ?>
            <?php foreach ($empresas as $empresa):
                $id = (int) $empresa['codigo'];
                $s = shield_situacao_licenca($empresa, isset($renovamSozinho[$id]));
                $contratados = (int) ($empresa['nterminais'] ?? 0);
                $vivos = isset($vivosPorEmpresa[$id]) ? $vivosPorEmpresa[$id] : 0;
                $registrados = (int) ($cadastradasPorEmpresa[$id] ?? 0);
                // Quem esta em avaliacao e medido pela cota do TESTE: o lead
                // nasce com nterminais nulo e a lista dizia "sem quantidade
                // contratada" a quem a tela de avaliacao ao lado mostra "1 / 3".
                $cotaTeste = shield_teste_vigente($empresa, $cfgTeste)
                    ? shield_teste_terminais_de($empresa, $cfgTeste) : 0;
                $p = shield_situacao_parque($vivos, $contratados, $cotaTeste);
                $aberto = isset($abertoPorEmpresa[$id]) ? $abertoPorEmpresa[$id] : 0;
                $cidade = trim((string) ($empresa['cidade'] ?? ''));
                $uf = trim((string) ($empresa['uf'] ?? ''));
                $lugar = trim($cidade . ($cidade !== '' && $uf !== '' ? '/' : '') . $uf);
                $nome = (string) ($empresa['razao'] ?? '');
            ?>
                <tr>
                    <td class="meio sem-rotulo">
                        <span class="selo <?= $s['cor']; ?>" title="<?= $s['rotulo']; ?>">
                            <i class="fas <?= $s['icone']; ?>"></i>
                        </span>
                    </td>
                    <td class="identidade" data-r="Cliente">
                        <div>
                            <?php /* Sem link no nome (10/09/2026, tarde): as acoes ao lado ja levam a ficha. */ ?>
                            <span class="nome"><?= shield_h($nome); ?></span>
                            <?php /* So o CNPJ leva `.dado`: a cidade ao lado e texto para
                                     LER, e mono em nome de cidade fica errado. */ ?>
                            <span class="apoio">
                                <span class="dado"><?= shield_h(shield_cnpj($empresa['cnpj'] ?? '')); ?></span>
                                <?= $lugar !== '' ? '&middot; ' . shield_h($lugar) : ''; ?>
                            </span>
                            <?php
                            // O TELEFONE NA LISTA -- 10/09/2026, fatia 2 da reorganizacao.
                            // A lista e a tela que se abre com o telefone tocando; o
                            // numero ficava so na ficha, um clique adiante. Com mascara
                            // desde 14/09/2026, como o CNPJ logo acima.
                            $fone = trim((string) ($empresa['fone'] ?? ''));
                            ?>
                            <?php if ($fone !== ''): ?>
                                <span class="apoio d-block">
                                    <?php /* O clique abre o WhatsApp do numero (06/10/2026): "tel:" no
                                             computador nao discava nada. Numero sem DDD fica texto. */ ?>
                                    <?php $zap = shield_whatsapp_url($fone); ?>
                                    <?php if ($zap !== null): ?>
                                        <a class="dado" href="<?= shield_h($zap); ?>" target="_blank" rel="noopener" title="Abrir no WhatsApp"><?= shield_h(shield_telefone($fone)); ?></a>
                                    <?php else: ?>
                                        <span class="dado"><?= shield_h(shield_telefone($fone)); ?></span>
                                    <?php endif; ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td data-r="Licen&ccedil;a">
                        <span class="pilula pilula-<?= $s['cor']; ?>"><?= $s['rotulo']; ?></span>
                        <?php if ($s['detalhe'] !== ''): ?>
                            <span class="apoio d-inline-block ms-1"><?= $s['detalhe']; ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="meio" data-r="Certificado">
                        <?php $cert = shield_certificado_situacao($empresa['certificado_vence'] ?? null); ?>
                        <?php if ($cert['dias'] === null): ?>
                            <span class="text-secondary apoio">&mdash;</span>
                        <?php else: ?>
                            <span class="pilula pilula-<?= $cert['cor']; ?>"
                                  title="Certificado digital: <?= shield_h(date('d/m/Y', strtotime((string) $empresa['certificado_vence']))); ?>">
                                <?= shield_h($cert['rotulo']); ?>
                            </span>
                        <?php endif; ?>
                    </td>
                    <td class="meio" data-r="Caixas"
                        title="<?= $vivos; ?> deram sinal nos &uacute;ltimos <?= SHIELD_PARQUE_DIAS_SUMIDO; ?> dias &middot; <?= $registrados; ?> registrado<?= $registrados == 1 ? '' : 's'; ?> &middot; <?= $contratados; ?> contratado<?= $contratados == 1 ? '' : 's'; ?><?= $p['nota'] !== '' ? ' (' . $p['nota'] . ')' : ''; ?>">
                        <span class="pilula pilula-<?= $p['cor']; ?>">
                            <?= $vivos; ?><?= $contratados > 0 ? ' / ' . $contratados : ($cotaTeste > 0 ? ' / ' . $cotaTeste : ''); ?>
                        </span>
                        <?php
                        // A NOTA E O ULTIMO SINAL SAEM DO title -- 10/09/2026, fatia 2.
                        // `title` so aparece com o mouse parado em cima, e nao aparece
                        // nunca no toque; "acima do contratado" e "nenhum caixa deu
                        // sinal" sao justamente o que a pessoa abre a lista para ver.
                        // O title fica, com a frase longa, para quem quiser.
                        $ultimoSinal = (string) ($ultimoSinalPorEmpresa[$id] ?? '');
                        ?>
                        <?php if ($registrados === 0): ?>
                            <span class="apoio d-block">nenhuma m&aacute;quina cadastrada</span>
                        <?php else: ?>
                            <?php /* "sem sinal" e o que a linha do ultimo sinal ja diz; repetir
                                     e ruido. As outras notas (acima do contratado, nenhum caixa
                                     deu sinal, sem quantidade contratada) ficam. */ ?>
                            <?php if ($p['nota'] !== '' && $p['nota'] !== 'sem sinal'): ?>
                                <span class="apoio d-block" style="color: var(--<?= $p['cor']; ?>)"><?= shield_h($p['nota']); ?></span>
                            <?php endif; ?>
                            <span class="apoio d-block">
                                <?= $ultimoSinal !== '' ? 'sinal ' . shield_h(shield_parque_ha_quanto($ultimoSinal)) : 'nunca deu sinal'; ?>
                            </span>
                        <?php endif; ?>
                    </td>
                    <?php /* NO CENTRO, COMO O CABECALHO (14/09/2026). O cabecalho alinhava a
                             direita e o traco ia ao centro por conta propria, e os dois
                             pareciam de colunas diferentes. O traco e o mesmo do certificado. */ ?>
                    <td class="num meio" data-r="Em aberto">
                        <?php if ($aberto > 0): ?>
                            <strong style="color: var(--erro)">R$ <?= shield_h(shield_dinheiro($aberto)); ?></strong>
                        <?php else: ?>
                            <span class="text-secondary apoio">&mdash;</span>
                        <?php endif; ?>
                    </td>
                    <td class="meio" data-r="A&ccedil;&otilde;es">
                        <?php /* DUAS LINHAS (10/09/2026, tarde): em cima o que se OLHA (ficha,
                                 terminais, monitoramento); embaixo o que se MEXE (cobrancas,
                                 cadastro, logs). Seis icones numa linha so viravam um borrao. */ ?>
                        <span class="d-inline-flex flex-column align-items-center gap-1">
                            <span class="acoes">
                                <a class="acao" href="/ver_empresa.php?id=<?= $id; ?>"
                                   title="Abrir a ficha" aria-label="Abrir a ficha de <?= shield_h($nome); ?>">
                                    <i class="fas fa-eye"></i></a>
                                <a class="acao" href="/terminais.php?empresa=<?= $id; ?>"
                                   title="Terminais deste cliente" aria-label="Terminais de <?= shield_h($nome); ?>">
                                    <i class="fas fa-desktop"></i></a>
                                <a class="acao" href="/parque.php?empresa=<?= $id; ?>"
                                   title="Monitoramento deste cliente" aria-label="Monitoramento de <?= shield_h($nome); ?>">
                                    <i class="fas fa-broadcast-tower"></i></a>
                            </span>
                            <span class="acoes">
                                <a class="acao" href="/cobrancas.php?empresa=<?= $id; ?>"
                                   title="Cobran&ccedil;as deste cliente" aria-label="Cobran&ccedil;as de <?= shield_h($nome); ?>">
                                    <i class="fas fa-money-bill-wave"></i></a>
                                <a class="acao" href="/editar_empresa.php?id=<?= $id; ?>"
                                   title="Editar o cadastro" aria-label="Editar o cadastro de <?= shield_h($nome); ?>">
                                    <i class="fas fa-edit"></i></a>
                                <a class="acao" href="/logs_cliente.php?empresa=<?= $id; ?>"
                                   title="Logs que este cliente mandou" aria-label="Logs de <?= shield_h($nome); ?>">
                                    <i class="fas fa-file-download"></i></a>
                            </span>
                        </span>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($totalPages > 1): ?>
    <nav class="mt-3" aria-label="P&aacute;ginas">
        <ul class="pagination pagination-sm justify-content-center mb-0">
            <li class="page-item <?= $page <= 1 ? 'disabled' : ''; ?>">
                <a class="page-link" href="<?= shield_h(shield_url_lista(array('page' => $page - 1))); ?>">&laquo;</a>
            </li>
            <?php
            // Numa base com centenas de clientes, uma pagina por numero enche a
            // tela de algarismos. Mostra uma janela em volta da atual, com as
            // duas pontas sempre alcancaveis.
            $de = max(1, $page - 2);
            $ate = min($totalPages, $page + 2);
            if ($de > 1): ?>
                <li class="page-item"><a class="page-link" href="<?= shield_h(shield_url_lista(array('page' => 1))); ?>">1</a></li>
                <?php if ($de > 2): ?><li class="page-item disabled"><span class="page-link">&hellip;</span></li><?php endif; ?>
            <?php endif; ?>
            <?php for ($i = $de; $i <= $ate; $i++): ?>
                <li class="page-item <?= $i == $page ? 'active' : ''; ?>">
                    <a class="page-link" href="<?= shield_h(shield_url_lista(array('page' => $i))); ?>"><?= $i; ?></a>
                </li>
            <?php endfor; ?>
            <?php if ($ate < $totalPages): ?>
                <?php if ($ate < $totalPages - 1): ?><li class="page-item disabled"><span class="page-link">&hellip;</span></li><?php endif; ?>
                <li class="page-item"><a class="page-link" href="<?= shield_h(shield_url_lista(array('page' => $totalPages))); ?>"><?= $totalPages; ?></a></li>
            <?php endif; ?>
            <li class="page-item <?= $page >= $totalPages ? 'disabled' : ''; ?>">
                <a class="page-link" href="<?= shield_h(shield_url_lista(array('page' => $page + 1))); ?>">&raquo;</a>
            </li>
        </ul>
    </nav>
<?php endif; ?>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
