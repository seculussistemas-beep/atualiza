<?php

// A busca do topo (Ctrl+K) -- reescrita em 03/09/2026.
//
// Responde a quem esta com o telefone na mao: "aqui e da Padaria Trigo e
// Mel, o caixa PDV-02 travou". Procura CLIENTE por nome ou CNPJ e TERMINAL
// pelo nome da maquina ou MAC, e devolve o suficiente para pular direto para
// a ficha certa.
//
// So administrador: cliente logado (acesso 3) nao pode listar os outros.

require_once __DIR__ . '/../../funcoes/nucleo/sessao.php'; shield_sessao_abrir();

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario']['login'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Nao autenticado']);
    exit;
}

$acesso = (string) ($_SESSION['usuario']['acesso'] ?? '');
if ($acesso !== '1') {
    http_response_code(403);
    echo json_encode(['ok' => false, 'message' => 'Sem permissao']);
    exit;
}

require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/parque.php';

$q = trim((string) ($_GET['q'] ?? $_GET['term'] ?? ''));
if (mb_strlen($q) < 2) {
    echo json_encode(['ok' => true, 'q' => $q, 'clientes' => [], 'terminais' => [], 'data' => []]);
    exit;
}

$like = '%' . $q . '%';
$digitos = preg_replace('/\D/', '', $q);
$corte = date('Y-m-d H:i:s', strtotime('-' . SHIELD_PARQUE_DIAS_SUMIDO . ' days'));

// Clientes: nome OU CNPJ. O CNPJ vem sem pontuacao no banco; se a pessoa
// digitou "12.345", compara pelos digitos.
$sql = "SELECT codigo, razao, cnpj, cidade, uf, validade_licenca, bloqueado
          FROM empresa
         WHERE razao LIKE :nome" . ($digitos !== '' ? ' OR cnpj LIKE :cnpj' : '') . "
         ORDER BY razao ASC
         LIMIT 8";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':nome', $like, PDO::PARAM_STR);
if ($digitos !== '') {
    $stmt->bindValue(':cnpj', '%' . $digitos . '%', PDO::PARAM_STR);
}
$stmt->execute();

$clientes = [];
foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $validade = trim((string) ($row['validade_licenca'] ?? ''));
    $situacao = 'sem_licenca';
    if (trim((string) ($row['bloqueado'] ?? '')) === 'S') {
        $situacao = 'bloqueado';
    } elseif ($validade !== '' && $validade !== '0000-00-00') {
        $situacao = $validade < date('Y-m-d') ? 'vencida' : 'em_dia';
    }
    $cnpj = preg_replace('/\D/', '', (string) ($row['cnpj'] ?? ''));
    $clientes[] = [
        'id' => (int) $row['codigo'],
        'razao' => (string) ($row['razao'] ?? ''),
        'cnpj' => strlen($cnpj) === 14
            ? preg_replace('/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/', '$1.$2.$3/$4-$5', $cnpj)
            : (string) ($row['cnpj'] ?? ''),
        'lugar' => trim(trim((string) ($row['cidade'] ?? '')) . ' ' . trim((string) ($row['uf'] ?? ''))),
        'situacao' => $situacao,
        'url' => '/ver_empresa.php?id=' . (int) $row['codigo'],
    ];
}

// Terminais: nome da maquina ou MAC, com o cliente dono e se esta dando sinal.
$terminais = [];
try {
    // PELO APELIDO TAMBEM -- 09/09/2026. O membro batizou a maquina de
    // "Caixa 2" e digitar isso nao achava nada. A consulta mora em
    // shield_parque_buscar_terminais, onde tem teste.
    foreach (shield_parque_buscar_terminais($pdo, $q, 5) as $row) {
        $ultimo = (string) ($row['ULTIMO_ACESSO'] ?? '');
        $terminais[] = [
            'id' => (int) $row['CODIGO'],
            'nome' => shield_terminal_rotulo($row),
            // O nome de fabrica atras do apelido; vazio quando e o proprio.
            'maquina' => shield_terminal_maquina_atras($row),
            'mac' => (string) ($row['MAC'] ?? ''),
            'razao' => (string) ($row['razao'] ?? ''),
            'empresa' => (int) ($row['FK_EMPRESA'] ?? 0),
            'vivo' => $ultimo !== '' && $ultimo >= $corte,
            'ha_quanto' => function_exists('shield_parque_ha_quanto') ? shield_parque_ha_quanto($ultimo) : '',
            // O MAC e o unico que a lista de terminais filtra sem ambiguidade:
            // apelido e nome de fabrica se repetem entre lojas.
            'url' => '/terminais.php?q=' . rawurlencode((string) (($row['MAC'] ?? '') ?: ($row['NOME_COMPUTADOR'] ?? ''))),
        ];
    }
} catch (Throwable $ignorado) {
    // Base sem a tabela de terminais ainda: a busca de clientes continua.
}

echo json_encode([
    'ok' => true,
    'q' => $q,
    'clientes' => $clientes,
    'terminais' => $terminais,
    // Formato antigo, para quem ainda ler `data`.
    'data' => array_map(static function ($c) { return ['razao' => $c['razao'], 'cnpj' => $c['cnpj']]; }, $clientes),
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
