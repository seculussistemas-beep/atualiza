<?php
/**
 * Em avaliacao -- 10/09/2026, fatia 6 da reorganizacao
 * (docs/reorganizacao-do-painel.md, secao 5).
 *
 * A fila de quem ainda nao e cliente: o ERP ligou, o painel cadastrou sozinho,
 * a loja esta nos sete dias de teste com tres caixas. Aqui o membro ve o que
 * precisa para vender -- maquinas, versao, ultimo sinal, dias que faltam, e
 * quem esta BATENDO NA PORTA alem das tres -- e tem duas saidas: ENCERRAR
 * (marca, reversivel, sem apagar) e DAR INICIO AO CONTRATO, que leva ao
 * fechamento numa tela so. Quem ja gravou o rascunho do contrato continua aqui,
 * com a data do rascunho, e o mesmo link vira "Concluir o contrato" (14/09/2026).
 *
 * Prorrogar e mover a data do teste. Sem contador, sem segunda regra.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/situacao.php';    // shield_cnpj
require_once __DIR__ . '/../../funcoes/licenca/avaliacao.php';
require_once __DIR__ . '/../../funcoes/licenca/encerramento.php';

$aviso = '';   // flutua e some: so confirma o clique
$fica = '';    // fica na tela: diz para onde o cadastro foi
$recusa = '';  // nada mudou; sumir sozinho seria ninguem saber disso
$erro = '';
$ator = (string) ($_SESSION['usuario']['nome'] ?? $_SESSION['usuario']['login'] ?? '');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $codigo = (int) ($_POST['codigo'] ?? 0);
    $acao = (string) ($_POST['acao'] ?? '');
    try {
        if ($acao === 'encerrar') {
            // ENCERRAR FICA NA TELA (14/09/2026): a linha some da fila, e a frase
            // e a unica coisa que diz para onde ela foi e que nada foi apagado.
            if (shield_empresa_encerrar($pdo, $codigo, $ator, 'encerrado na avaliacao')) {
                $fica = 'Encerrado. Ele sai desta fila e passa a aparecer em Clientes, na faixa "encerradas", e na Limpeza de cadastros. Nada foi apagado: reabre pela ficha dele.';
            } else {
                $recusa = 'Este cadastro ja estava encerrado.';
            }
        } elseif ($acao === 'regras') {
            // AS REGRAS DO TESTE sao do membro (10/09/2026): dias e caixas. Valem
            // para quem esta em teste AGORA, porque a conta e feita na hora.
            shield_teste_definir($pdo, (int) ($_POST['dias'] ?? 7), (int) ($_POST['terminais'] ?? 3));
            $aviso = 'Regras do teste gravadas. Valem ja para quem esta em avaliacao.';
        } elseif ($acao === 'terminais') {
            // OS CAIXAS DO TESTE SAO POR LOJA (10/09/2026, tarde): a regra
            // geral diz tres; esta loja testa com o que for digitado aqui.
            $n = (int) ($_POST['n'] ?? 0);
            if (shield_avaliacao_definir_terminais($pdo, $codigo, $n, $ator)) {
                $aviso = $n > 0 ? 'O teste desta loja passa a liberar ' . $n . ' caixa' . ($n == 1 ? '' : 's') . '. Vale na proxima abertura do ERP.' : 'O teste desta loja volta a regra geral.';
            } else {
                $recusa = 'Este cadastro ja tem validade; a cota dele e do contrato.';
            }
        } elseif ($acao === 'prorrogar') {
            if (shield_avaliacao_prorrogar($pdo, $codigo, (string) ($_POST['ate'] ?? ''), $ator)) {
                $aviso = 'O teste passa a valer ate ' . date('d/m/Y', strtotime((string) $_POST['ate'])) . '.';
            } else {
                $recusa = 'Data ilegivel; o teste ficou como estava.';
            }
        }
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
}

$fila = shield_avaliacao_lista($pdo);
$regras = shield_teste_config($pdo);
$page_title = 'Em avaliação';
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <div class="trilha"><span>Ainda n&atilde;o &eacute; cliente</span><span>/</span><span>Em avalia&ccedil;&atilde;o</span></div>
        <h1 class="h4 mb-1">Em avalia&ccedil;&atilde;o</h1>
        <p class="text-secondary small mb-0">
            O ERP ligou, o painel cadastrou sozinho, a loja tem <?= (int) $regras['dias']; ?> dias com
            <?= (int) $regras['terminais']; ?> caixa<?= $regras['terminais'] == 1 ? '' : 's'; ?>. Deu in&iacute;cio ao contrato, sai daqui e vira cliente; o rascunho do contrato n&atilde;o tira daqui. Quem passa do prazo sem fechar &eacute; encerrado sozinho
            <?= SHIELD_ENCERRAMENTO_DIAS; ?> dias depois do fim do teste, ou <?= SHIELD_ENCERRAMENTO_DIAS_RASCUNHO; ?> quando h&aacute; rascunho do contrato salvo &mdash; sem apagar nada.
        </p>
    </div>
    <?php /* Quem fechou o negocio antes de instalar entra por aqui (16/09/2026):
             cadastrar a mao nao registra maquina nenhuma, e o teste so comeca
             quando a loja ligar de verdade. */ ?>
    <div class="acoes-pagina">
        <a href="/novo_cliente.php" class="btn btn-primary btn-sm">
            <i class="fas fa-plus-circle me-1"></i>Cadastrar cliente
        </a>
    </div>
</div>

<?php shield_aviso_flutuante($aviso); ?>
<?php if ($fica !== ''): ?>
    <div class="alert alert-success"><?= shield_h($fica); ?></div>
<?php endif; ?>
<?php if ($recusa !== ''): ?>
    <div class="alert alert-warning"><?= shield_h($recusa); ?></div>
<?php endif; ?>
<?php if ($erro !== ''): ?>
    <div class="alert alert-danger"><?= shield_h($erro); ?></div>
<?php endif; ?>

<?php /* AS REGRAS DO TESTE SAO DO MEMBRO (10/09/2026): quem nao quer tres caixas
         no teste poe um. Vale ja para quem esta em avaliacao, porque a conta e
         feita na hora e nada fica gravado no cadastro do lead. */ ?>
<div class="card mb-3" data-tour="aval-regras">
    <div class="card-body py-2 d-flex align-items-end justify-content-between flex-wrap gap-3">
        <form method="post" action="/avaliacao.php" class="d-flex align-items-end flex-wrap gap-3">
            <input type="hidden" name="acao" value="regras">
            <div>
                <label for="regra_dias" class="small text-secondary d-block">Dias de teste</label>
                <input type="number" min="1" max="90" id="regra_dias" name="dias" class="form-control form-control-sm" style="width: 6rem" value="<?= (int) $regras['dias']; ?>">
            </div>
            <div>
                <label for="regra_terminais" class="small text-secondary d-block">Caixas no teste</label>
                <input type="number" min="1" max="99" id="regra_terminais" name="terminais" class="form-control form-control-sm" style="width: 6rem" value="<?= (int) $regras['terminais']; ?>">
            </div>
            <button type="submit" class="btn btn-sm btn-outline-secondary">Gravar</button>
            <span class="small text-secondary">Valem para todos em avalia&ccedil;&atilde;o.<br>Para um s&oacute;, mova a data na linha.</span>
        </form>
        <?php /* BUSCA NA FILA (10/09/2026): por nome ou CNPJ, sem sair da tela. */ ?>
        <div>
            <label for="buscaFila" class="small text-secondary d-block">Procurar na fila</label>
            <input type="search" id="buscaFila" class="form-control form-control-sm" style="width: 16rem" placeholder="nome ou CNPJ"
                   oninput="var q=this.value.toLowerCase().replace(/[^a-z0-9]/g,''); document.querySelectorAll('table.lista tbody tr').forEach(function(tr){ var t=tr.innerText.toLowerCase().replace(/[^a-z0-9]/g,''); tr.hidden = q !== '' && t.indexOf(q) === -1; });" maxlength="255">
        </div>
    </div>
</div>

<div class="card" data-tour="aval-fila">
    <?php if (empty($fila)): ?>
        <div class="vazio">
            <i class="fas fa-hourglass-half"></i>
            Ningu&eacute;m em avalia&ccedil;&atilde;o. Quando um ERP novo ligar, a loja aparece aqui sozinha.
        </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="lista">
            <thead>
                <tr>
                    <th scope="col">Loja</th>
                    <th scope="col" class="meio">Teste</th>
                    <th scope="col" class="meio">Prorrogar at&eacute;</th>
                    <th scope="col" class="meio">M&aacute;quinas</th>
                    <th scope="col" class="meio">&Uacute;ltimo sinal</th>
                    <th scope="col" class="meio" style="width:1%">A&ccedil;&otilde;es</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($fila as $l): ?>
                <?php
                $id = (int) $l['codigo'];
                $dias = $l['dias_restantes'];
                $fone = trim((string) ($l['fone'] ?? ''));
                $cidade = trim((string) ($l['cidade'] ?? ''));
                $lugar = trim($cidade . ($cidade !== '' && trim((string) ($l['uf'] ?? '')) !== '' ? '/' : '') . trim((string) ($l['uf'] ?? '')));
                $batendo = (int) $l['batendo_na_porta'];
                $temRascunho = trim((string) ($l['rascunho_em'] ?? '')) !== '';
                ?>
                <tr>
                    <td class="identidade" data-r="Loja">
                        <div>
                            <a class="nome" href="/ver_empresa.php?id=<?= $id; ?>"><?= shield_h((string) ($l['razao'] ?: '(sem razao social)')); ?></a>
                            <span class="apoio">
                                <span class="dado"><?= shield_h(shield_cnpj((string) $l['cnpj'])); ?></span>
                                <?= $lugar !== '' ? '&middot; ' . shield_h($lugar) : ''; ?>
                            </span>
                            <?php if ($fone !== ''): ?>
                                <span class="apoio d-block"><a class="dado" href="tel:<?= shield_h(preg_replace('/[^0-9+]/', '', $fone)); ?>"><?= shield_h(shield_telefone($fone)); ?></a></span>
                            <?php endif; ?>
                            <span class="apoio d-block">apareceu em <?= shield_h(date('d/m/Y', strtotime((string) $l['data']))); ?></span>
                            <?php /* O RASCUNHO DO CONTRATO (14/09/2026): a loja continua na fila, e a marca diz que ja
                                     ha meio caminho andado, e de quando -- para ninguem ligar de novo do zero. */ ?>
                            <?php if ($temRascunho): ?>
                                <span class="d-block mt-1"><span class="pilula pilula-neutro">rascunho do contrato salvo <?= shield_h(date('d/m', strtotime((string) $l['rascunho_em']))); ?></span></span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td class="meio" data-r="Teste">
                        <?php if ($dias === null && $l['teste_fim'] !== null): ?>
                            <span class="pilula pilula-erro">venceu <?= shield_h(date('d/m', strtotime((string) $l['teste_fim']))); ?></span>
                        <?php elseif ($dias === null): ?>
                            <span class="pilula pilula-neutro">sem data de onde contar</span>
                        <?php elseif ($dias === 0): ?>
                            <span class="pilula pilula-atencao">&uacute;ltimo dia</span>
                        <?php else: ?>
                            <span class="pilula pilula-<?= $dias <= 2 ? 'atencao' : 'ok'; ?>"><?= $dias; ?> dia<?= $dias == 1 ? '' : 's'; ?></span>
                        <?php endif; ?>
                        <?php if ($l['teste_fim'] !== null && $dias !== null): ?>
                            <span class="apoio d-block">at&eacute; <?= shield_h(date('d/m/Y', strtotime((string) $l['teste_fim']))); ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="meio" data-r="Prorrogar at&eacute;">
                        <?php /* Prorrogar E mover a data. Coluna propria (10/09/2026): dentro de
                                 "Teste" o campo empurrava a pilula e a data para tres linhas. */ ?>
                        <form method="post" action="/avaliacao.php" class="d-flex gap-1 justify-content-center">
                            <input type="hidden" name="acao" value="prorrogar">
                            <input type="hidden" name="codigo" value="<?= $id; ?>">
                            <input type="date" name="ate" class="form-control form-control-sm" style="width: 10rem"
                                   value="<?= shield_h((string) ($l['teste_fim'] ?? date('Y-m-d'))); ?>" aria-label="Novo fim do teste">
                            <button class="btn btn-sm btn-outline-secondary" title="Mover a data do teste">ok</button>
                        </form>
                    </td>
                    <td class="meio" data-r="M&aacute;quinas">
                        <?php /* "vivos / cota", e a cota se muda ali mesmo: os caixas do teste sao por loja. */ ?>
                        <?php /* "vivos / cota". A cota e por loja e se muda num modal (10/09/2026, tarde):
                                 campo dentro da celula ficava feio e apertado. */ ?>
                        <?php /* "0 de 3 trabalhando": vivos AGORA sobre a cota do teste. A linha de
                                 baixo diz quantas ja se cadastraram, que e outro numero. */ ?>
                        <span class="pilula pilula-<?= $l['vivos'] > 0 ? 'ok' : 'neutro'; ?>" title="Caixas dando sinal agora, de quantos o teste libera"><?= (int) $l['vivos']; ?> / <?= (int) $l['teste_terminais']; ?></span>
                        <span class="apoio d-block text-nowrap">sinal agora / cota do teste</span>
                        <button type="button" class="btn btn-link btn-sm p-0 d-block mx-auto small" style="text-decoration: none"
                                onclick='cotaAbrir(<?= json_encode(array('codigo' => $id, 'n' => (int) $l['teste_terminais'], 'razao' => (string) $l['razao']), JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE); ?>)'>mudar cota</button>
                        <span class="apoio d-block"><?= (int) $l['maquinas']; ?> cadastrada<?= $l['maquinas'] == 1 ? '' : 's'; ?><?= !empty($l['versao']) ? ' &middot; v' . shield_h((string) $l['versao']) : ''; ?></span>
                        <?php if ($batendo > 0): ?>
                            <?php /* A mesma palavra da lista de clientes: ja e argumento de venda. */ ?>
                            <span class="apoio d-block" style="color: var(--atencao)"><?= $batendo; ?> batendo na porta</span>
                        <?php endif; ?>
                    </td>
                    <td class="meio" data-r="&Uacute;ltimo sinal"><?= shield_h(shield_parque_ha_quanto((string) ($l['ultimo_sinal'] ?? ''))); ?></td>
                    <td class="meio" data-r="A&ccedil;&otilde;es">
                        <span class="acoes">
                            <a class="acao" href="/fechamento.php?id=<?= $id; ?>" title="<?= $temRascunho ? 'Concluir o contrato' : 'Dar in&iacute;cio ao contrato'; ?>"
                               aria-label="<?= $temRascunho ? 'Concluir o contrato' : 'Dar inicio ao contrato'; ?> de <?= shield_h((string) $l['razao']); ?>">
                                <i class="fas fa-file-signature"></i></a>
                            <form method="post" action="/avaliacao.php" class="d-inline"
                                  onsubmit="return confirm('Encerrar esta avaliação? A licença para de sair na hora. Nada é apagado, e dá para reabrir na ficha.');">
                                <input type="hidden" name="acao" value="encerrar">
                                <input type="hidden" name="codigo" value="<?= $id; ?>">
                                <button class="acao" title="Encerrar (marca; nada e apagado)"
                                        aria-label="Encerrar a avaliacao de <?= shield_h((string) $l['razao']); ?>">
                                    <i class="fas fa-times-circle"></i></button>
                            </form>
                        </span>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php /* O MODAL DA COTA: um so para a tela, preenchido pela linha. */ ?>
<div class="modal fade" id="modalCota" tabindex="-1" aria-labelledby="modalCotaTitulo" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <form method="post" action="/avaliacao.php" class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title h6" id="modalCotaTitulo">Caixas do teste</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="acao" value="terminais">
                <input type="hidden" name="codigo" id="cota_codigo" value="0">
                <p class="small text-secondary mb-2" id="cota_loja"></p>
                <label for="cota_n" class="form-label">Quantos caixas o teste desta loja libera</label>
                <input type="number" min="1" max="99" name="n" id="cota_n" class="form-control num" value="3" required>
                <small class="form-text text-muted">A regra geral vale para as outras. Vale na pr&oacute;xima abertura do ERP.</small>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary btn-sm">Gravar</button>
            </div>
        </form>
    </div>
</div>
<script>
function cotaAbrir(l) {
    document.getElementById('cota_codigo').value = l.codigo;
    document.getElementById('cota_n').value = l.n;
    document.getElementById('cota_loja').innerText = l.razao;
    bootstrap.Modal.getOrCreateInstance(document.getElementById('modalCota')).show();
    setTimeout(function () { document.getElementById('cota_n').select(); }, 300);
}
</script>
<?php include __DIR__ . '/../../templates/fecha.php'; ?>
