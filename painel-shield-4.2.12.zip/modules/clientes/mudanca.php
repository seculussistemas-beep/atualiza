<?php
/**
 * Mudar no meio do contrato -- 10/09/2026, fatia 8 da reorganizacao
 * (docs/reorganizacao-do-painel.md, secao 6).
 *
 * Dois passos, na mesma pagina: a pessoa digita O NUMERO FINAL (e marca os
 * modulos), a tela mostra o antes e o depois com a data, o mes corrente como
 * pergunta (avulsa proporcional, valor editavel, caixa desmarcavel), a opcao
 * de so liberar quando pagar e o aviso ao reduzir -- e so entao confirma.
 * Quem faz e funcoes/empresa/mudanca.php.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/situacao.php';
require_once __DIR__ . '/../../funcoes/empresa/mudanca.php';
require_once __DIR__ . '/../../funcoes/planos/ciclo.php';
require_once __DIR__ . '/../../templates/contexto_cliente.php'; // shield_voltar_cliente

use Shield\Cobranca\Registro;

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
try {
    $lido = shield_mudanca_atual($pdo, $id);
} catch (Throwable $e) {
    header('Location: /clientes.php');
    exit;
}
$empresa = $lido['empresa'];
$atual = $lido['atual'];
$ctx = $lido['ctx'];
$ator = (string) ($_SESSION['usuario']['nome'] ?? $_SESSION['usuario']['login'] ?? '');

$catalogo = $pdo->query('SELECT id, nome, valor_centavos FROM modulo WHERE ativo = 1 ORDER BY nome')->fetchAll(PDO::FETCH_ASSOC) ?: array();
$contas = shield_contas_para_escolher(array_values(array_filter(shield_cobranca_contas($pdo, true), static function ($c) {
    return Registro::para((string) $c['provedor']) !== null;
})));

/* AS FORMAS DE CADA CONTA, UMA RESPOSTA SO (14/09/2026): shield_conta_formas
   cruza o que o provedor faz com o "Cobra por" de Formas de recebimento. Os
   selects de conta desta tela levam isso em data-formas, e o select de forma
   ao lado ja nasce so com as que servem -- montado aqui, e nao pelo JS depois
   de a pagina abrir, para a forma nao trocar diante do membro. Conta 0
   (nenhuma ligada) so registra: ali valem as tres. */
$formasConta = array(0 => array('pix', 'boleto', 'cartao'));
foreach ($contas as $c) {
    $formasConta[(int) $c['id']] = shield_conta_formas($c);
}
/* A conta que o select vai MOSTRAR: a sugerida, se ela esta na lista; senao a
   primeira, que e a que o navegador escolhe sozinho -- e a forma tem de ser a dela. */
$contaNaTela = static function ($sugerida) use ($contas) {
    foreach ($contas as $c) {
        if ((int) $c['id'] === (int) $sugerida) {
            return (int) $sugerida;
        }
    }

    return $contas ? (int) $contas[0]['id'] : 0;
};
$opcoesForma = static function ($contaId, $escolhida = '') use ($formasConta) {
    $serve = $formasConta[(int) $contaId] ?? array();
    if (!in_array((string) $escolhida, $serve, true)) {
        $escolhida = $serve[0] ?? '';
    }
    $html = '';
    foreach (array('pix' => 'PIX', 'boleto' => 'Boleto', 'cartao' => 'Cart&atilde;o', 'dinheiro' => 'Dinheiro') as $f => $r) {
        $ok = in_array($f, $serve, true);
        $html .= '<option value="' . $f . '"' . ($ok ? '' : ' hidden disabled') . ($f === $escolhida ? ' selected' : '') . '>' . $r . '</option>';
    }

    return $html;
};

$passo = 'pedir';
$erro = '';
$resultado = null;
$novo = $atual;
$conta = null;

/* A CHAVE DO ENVIO -- 11/09/2026. A tela nao tem POST-redirect-GET e o CSRF e
   por sessao (reutilizavel), entao F5 na pagina de resultado reenvia o mesmo
   corpo e abria uma SEGUNDA cobranca, tambem emitida. Ela vem do formulario
   justamente para o reenvio trazer a MESMA, como no fechamento. Os dois
   formularios levam NOMES diferentes (chave e chave_modo): sao duas acoes na
   mesma pagina, e um nome so faria a segunda herdar a cobranca da primeira --
   o campo do ajuste se repovoa do proprio POST. */
$chaveEnvio = bin2hex(random_bytes(16));

$contaFeita = null;
$modoFeito = null;
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['acao'] ?? '') === 'modo') {
    // COMO PAGA (10/09/2026, tarde): assinatura <-> pre-pago, valendo quando o
    // periodo pago terminar. Ver shield_mudanca_modo.
    try {
        $modoFeito = shield_mudanca_modo($pdo, $id, array(
            'modo' => (string) ($_POST['modo'] ?? 'assinatura'),
            'valor_centavos' => shield_centavos((string) ($_POST['valor_modo'] ?? '')),
            'meses' => (int) ($_POST['meses'] ?? 12),
            'ciclo_meses' => (int) ($_POST['ciclo_meses'] ?? 1),
            'dia_vencimento' => (int) ($_POST['dia_vencimento'] ?? 10),
            'conta' => (int) ($_POST['conta_modo'] ?? 0),
            'forma' => (string) ($_POST['forma_modo'] ?? 'pix'),
            'chave' => (string) ($_POST['chave_modo'] ?? ''),
        ), $ator);
        $lido = shield_mudanca_atual($pdo, $id);
        $ctx = $lido['ctx'];
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
} elseif (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['acao'] ?? '') === 'trocar_conta') {
    // POR ONDE O DINHEIRO ENTRA (10/09/2026, tarde): a conta do fechamento e
    // fixa; trocar e aqui, e leva junto o que esta na rua.
    try {
        $contaFeita = shield_mudanca_trocar_conta($pdo, $id, (int) ($_POST['conta_nova'] ?? 0), $ator);
        $lido = shield_mudanca_atual($pdo, $id);
        $ctx = $lido['ctx'];
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
} elseif (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $pedido = array(
        // A TELA MANDA INCLUSOS + ADICIONAIS (10/09/2026, noite); o contratado e a soma.
        'nterminais' => isset($_POST['adicionais'])
            ? max(0, (int) ($_POST['inclusos'] ?? 0)) + max(0, (int) $_POST['adicionais'])
            : (int) ($_POST['nterminais'] ?? $atual['nterminais']),
        'inclusos' => (int) ($_POST['inclusos'] ?? $atual['inclusos']),
        'valor_terminal' => shield_centavos((string) ($_POST['valor_terminal'] ?? '')),
        'modulos' => (array) ($_POST['modulos'] ?? array()),
    );
    $novo = shield_mudanca_novo($pdo, $atual, $pedido);
    $conta = shield_mudanca_calcular($atual, $novo, $ctx);
    $passo = 'confirmar';

    if (($_POST['acao'] ?? '') === 'aplicar') {
        try {
            if ($novo['inclusos'] > $novo['nterminais'] && $novo['nterminais'] > 0) {
                throw new RuntimeException('Inclusos no plano nao pode passar do contratado.');
            }
            $resultado = shield_mudanca_aplicar($pdo, $id, $novo, array(
                'cobrar_agora' => !empty($_POST['cobrar_agora']),
                'valor_avulsa' => shield_centavos((string) ($_POST['valor_avulsa'] ?? '')),
                'liberar_ao_pagar' => !empty($_POST['liberar_ao_pagar']),
                'vencimento' => (string) ($_POST['vencimento'] ?? date('Y-m-d', strtotime('+5 days'))),
                'forma' => (string) ($_POST['forma'] ?? 'pix'),
                'conta' => (int) ($_POST['conta'] ?? 0),
                'chave' => (string) ($_POST['chave'] ?? ''),
            ), $ator);
            $passo = 'feito';
        } catch (Throwable $e) {
            $erro = $e->getMessage();
        }
    }
}
$page_title = 'Mudar o contrato';
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <div class="trilha"><a href="/clientes.php">Clientes</a><span>/</span><a href="/ver_empresa.php?id=<?= $id; ?>"><?= shield_h((string) $empresa['razao']); ?></a><span>/</span><span>Mudar o contrato</span></div>
        <h1 class="h4 mb-1">Mudar o contrato &mdash; <?= shield_h((string) $empresa['razao']); ?></h1>
        <p class="text-secondary small mb-0">
            <?php if ($ctx['modo'] === 'assinatura'): ?>
                Assinatura de R$ <?= shield_h(shield_dinheiro($ctx['base'])); ?> <?= shield_h(shield_plano_ciclo_rotulo((int) ($ctx['assinatura']['ciclo_meses'] ?? 1))); ?>;
                pr&oacute;xima cobran&ccedil;a em <?= shield_h(date('d/m/Y', strtotime($ctx['proxima']))); ?>.
            <?php else: ?>
                Pr&eacute;-pago: n&atilde;o h&aacute; mensalidade para reajustar; o que muda sai como cobran&ccedil;a avulsa.
            <?php endif; ?>
            <?= (int) $ctx['vivos']; ?> caixa(s) dando sinal agora.
        </p>
    </div>
    <?php /* O VOLTAR QUE FALTAVA (14/09/2026): so a trilha levava de volta, e as outras
             telas do cliente (ficha, editar, cobrancas) tem o botao no mesmo canto. */ ?>
    <div class="acoes-pagina">
        <a href="<?= shield_h(shield_voltar_cliente($id)); ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i>Voltar
        </a>
    </div>
</div>

<?php if ($erro !== ''): ?><div class="alert alert-danger"><?= shield_h($erro); ?></div><?php endif; ?>

<?php if ($passo === 'feito'): ?>
    <div class="card"><div class="card-body">
        <h2 class="h6"><i class="fas fa-check-circle me-1" style="color: var(--ok)"></i>Contrato alterado.</h2>
        <p class="mb-2">
            Mensalidade de R$ <?= shield_h(shield_dinheiro($resultado['conta']['antes'])); ?> para
            <strong>R$ <?= shield_h(shield_dinheiro($resultado['conta']['depois'])); ?></strong>
            <?= $ctx['proxima'] !== '' ? 'a partir da cobran&ccedil;a de ' . shield_h(date('d/m/Y', strtotime($ctx['proxima']))) : ''; ?>.
            <?php if ($resultado['pendente']): ?>
                A cota s&oacute; sobe para <?= (int) $novo['nterminais']; ?> quando a cobran&ccedil;a do ajuste for confirmada; at&eacute; l&aacute; o cliente continua com <?= (int) $atual['nterminais']; ?>.
            <?php endif; ?>
            <?php if ($resultado['cobranca']): ?>
                A cobran&ccedil;a do m&ecirc;s corrente est&aacute; <a href="/cobrancas.php?empresa=<?= $id; ?>">em cobran&ccedil;as</a>.
            <?php endif; ?>
        </p>
        <?php if ($resultado['aviso'] !== ''): ?><div class="alert alert-warning"><?= shield_h($resultado['aviso']); ?></div><?php endif; ?>
        <a href="/ver_empresa.php?id=<?= $id; ?>" class="btn btn-sm btn-primary">Voltar &agrave; ficha</a>
    </div></div>

<?php else: ?>
<form method="post" action="/mudanca_contrato.php?id=<?= $id; ?>" autocomplete="off" id="formMudanca">
    <?php /* Reenviada pelo F5, ela diz que e o MESMO envio: a avulsa do ajuste
             nasce uma vez so. Vem do POST quando ja existe, para o segundo
             passo (confirmar -> aplicar) nao trocar de chave no meio. */ ?>
    <input type="hidden" name="chave" value="<?= shield_h((string) ($_POST['chave'] ?? ($chaveEnvio . '-ajuste'))); ?>">
    <input type="hidden" name="id" value="<?= $id; ?>">
    <div class="row g-3">
        <div class="col-lg-6">
            <div class="card h-100"><div class="card-header" data-tour="mud-fica">Como fica</div><div class="card-body">
                <?php /* O NUMERO FINAL, nao a diferenca: "quero que fique 6". */ ?>
                <div class="row g-2 align-items-end">
                    <?php /* Os tres rotulos numa linha so (text-nowrap): rotulo em duas linhas desalinhava os campos. */ ?>
                    <div class="col-4"><label class="form-label small mb-1" for="inclusos">Inclusos no plano</label>
                        <input type="number" min="0" max="99" class="form-control form-control-sm num" id="inclusos" name="inclusos" value="<?= (int) $novo['inclusos']; ?>">
                        <small class="text-secondary">hoje: <?= (int) $atual['inclusos']; ?></small></div>
                    <div class="col-4"><label class="form-label small mb-1" for="adicionais">Terminais adicionais</label>
                        <input type="number" min="0" max="99" class="form-control form-control-sm num" id="adicionais" name="adicionais" value="<?= max(0, (int) $novo['nterminais'] - (int) $novo['inclusos']); ?>">
                        <small class="text-secondary">hoje: <?= max(0, (int) $atual['nterminais'] - (int) $atual['inclusos']); ?></small></div>
                    <div class="col-4"><label class="form-label small mb-1" for="valor_terminal">Extra (R$/m&ecirc;s)</label>
                        <input class="form-control form-control-sm num dinheiro" id="valor_terminal" name="valor_terminal" data-teto="999999" value="<?= shield_h(shield_dinheiro($novo['valor_terminal'])); ?>">
                        <?php /* A mesma linha "hoje:" dos vizinhos: sem ela o campo descia (align-items-end). */ ?>
                        <small class="text-secondary">hoje: R$ <?= shield_h(shield_dinheiro((int) $atual['valor_terminal'])); ?></small></div>
                </div>
                <?php if ($catalogo): ?>
                    <div class="small text-secondary mt-3 mb-1">M&oacute;dulos (m&oacute;dulo n&atilde;o para caixa)</div>
                    <?php foreach ($catalogo as $m): ?>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="modulos[]" id="mod<?= (int) $m['id']; ?>" value="<?= (int) $m['id']; ?>" <?= isset($novo['modulos'][(int) $m['id']]) ? 'checked' : ''; ?>>
                            <label class="form-check-label small" for="mod<?= (int) $m['id']; ?>">
                                <?= shield_h((string) $m['nome']); ?> &middot; R$ <?= shield_h(shield_dinheiro(isset($atual['modulos'][(int) $m['id']]) ? $atual['modulos'][(int) $m['id']] : (int) $m['valor_centavos'])); ?>/m&ecirc;s
                                <?= isset($atual['modulos'][(int) $m['id']]) ? '<span class="pilula pilula-neutro">j&aacute; tem</span>' : ''; ?>
                            </label>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                <?php /* O botao "Ver o que muda" saiu: a previa se refaz sozinha ao mexer. Sem JS, o Enter no campo envia. */ ?>
                <button type="submit" name="acao" value="previa" class="btn btn-sm btn-outline-primary mt-3" hidden>Ver o que muda</button>
            </div></div>
        </div>

        <div class="col-lg-6">
            <div class="card h-100"><div class="card-header">Antes de confirmar</div><div class="card-body" id="previaMudanca">
            <?php if ($conta === null): ?>
                <p class="text-secondary small mb-0">Mude um n&uacute;mero ou marque um m&oacute;dulo: a conta aparece aqui na hora.</p>
            <?php else: ?>
                <p class="mb-2">
                    Mensalidade: <strong>R$ <?= shield_h(shield_dinheiro($conta['antes'])); ?> &rarr; R$ <?= shield_h(shield_dinheiro($conta['depois'])); ?></strong>
                    <?= $ctx['proxima'] !== '' ? '<span class="text-secondary">a partir da cobran&ccedil;a de ' . shield_h(date('d/m/Y', strtotime($ctx['proxima']))) . '</span>' : ''; ?>
                </p>

                <?php if ($conta['reduz']): ?>
                    <div class="alert alert-warning py-2 small">
                        <strong>Reduzindo.</strong>
                        <?php if ($conta['param'] > 0): ?>
                            <?= $conta['param']; ?> m&aacute;quina(s) que trabalham hoje param de abrir &mdash; as mais novas.
                        <?php else: ?>
                            Nenhuma m&aacute;quina viva para de abrir.
                        <?php endif; ?>
                        N&atilde;o h&aacute; devolu&ccedil;&atilde;o do m&ecirc;s corrente.
                    </div>
                <?php endif; ?>

                <?php if ($conta['delta'] > 0): ?>
                    <?php /* O MES CORRENTE COMO PERGUNTA, nao como regra. */ ?>
                    <div class="border rounded p-2 mb-2">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="cobrar_agora" id="cobrar_agora" value="1" checked>
                            <label class="form-check-label" for="cobrar_agora">Cobrar o m&ecirc;s corrente agora, proporcional</label>
                        </div>
                        <?php /* TRES LINHAS, TRES RESPOSTAS (10/09/2026, noite): o que nasce agora, o que
                                 muda na mensalidade e o que acontece desmarcado. */ ?>
                        <div class="small text-secondary mb-2">
                            <div><strong>Marcado:</strong> nasce agora uma cobran&ccedil;a avulsa de R$ <?= shield_h(shield_dinheiro($conta['proporcional'])); ?>, s&oacute; a diferen&ccedil;a (R$ <?= shield_h(shield_dinheiro($conta['delta'])); ?>) pelos <?= (int) $conta['dias_restantes']; ?> dias que faltam at&eacute; a pr&oacute;xima mensalidade. Ela n&atilde;o mexe na licen&ccedil;a.</div>
                            <div>A pr&oacute;xima mensalidade j&aacute; sai com o valor novo; esta avulsa cobre s&oacute; o que falta deste m&ecirc;s.</div>
                            <div><strong>Desmarcado:</strong> nada &eacute; cobrado agora; o valor novo entra s&oacute; na pr&oacute;xima mensalidade.</div>
                        </div>
                        <div class="row g-2 align-items-end">
                            <div class="col-4"><label class="form-label small mb-1" for="valor_avulsa">Valor (R$)</label>
                                <input class="form-control form-control-sm num dinheiro" id="valor_avulsa" name="valor_avulsa" data-teto="999999" value="<?= shield_h(shield_dinheiro($conta['proporcional'])); ?>"></div>
                            <div class="col-4"><label class="form-label small mb-1" for="vencimento">Vence em</label>
                                <input type="date" class="form-control form-control-sm" id="vencimento" name="vencimento" value="<?= date('Y-m-d', strtotime('+5 days')); ?>"></div>
                            <div class="col-4"><label class="form-label small mb-1" for="conta">Emitir por</label>
                                <?php /* SEM "SO REGISTRAR" (10/09/2026, noite): a avulsa sai pela conta da
                                         assinatura ou pela padrao. Sem conta nenhuma ligada, fica em rascunho. */ ?>
                                <?php $contaAvulsa = is_array($ctx['assinatura'] ?? null) && (int) ($ctx['assinatura']['fk_conta'] ?? 0) > 0 ? (int) $ctx['assinatura']['fk_conta'] : shield_conta_padrao($pdo); ?>
                                <?php /* A CONTA QUE O MEMBRO JA ESCOLHEU VOLTA quando a previa se refaz: o fetch
                                         reenvia o formulario inteiro, e sem isto o select voltava para a sugerida
                                         enquanto a forma do POST ficava -- a forma de uma conta desenhada ao lado
                                         de outra. */ ?>
                                <?php $contaAvulsa = $contaNaTela(isset($_POST['conta']) ? (int) $_POST['conta'] : $contaAvulsa); ?>
                                <select class="form-select form-select-sm" id="conta" name="conta" onchange="mudFormas(this, document.getElementById('forma'))">
                                    <?php if ($contas === array()): ?><option value="0" data-formas="pix,boleto,cartao">nenhuma conta ligada (fica em rascunho)</option><?php endif; ?>
                                    <?php foreach ($contas as $c): ?>
                                        <option value="<?= (int) $c['id']; ?>" <?= (int) $c['id'] === $contaAvulsa ? 'selected' : ''; ?> data-formas="<?= shield_h(implode(',', $formasConta[(int) $c['id']])); ?>"><?= shield_h(shield_conta_rotulo($c)); ?></option>
                                    <?php endforeach; ?>
                                </select></div>
                        </div>
                        <?php /* A FORMA DA AVULSA (14/09/2026): era um hidden "pix" fixo, e a conta de
                                 dinheiro ou uma conta sem PIX no "Cobra por" recusava na emissao com a
                                 frase "o provedor nao respondeu". Escolha unica, so as formas da conta. */ ?>
                        <div class="row g-2 align-items-end mt-1">
                            <div class="col-4"><label class="form-label small mb-1" for="forma">Forma</label>
                                <select class="form-select form-select-sm" id="forma" name="forma"><?= $opcoesForma($contaAvulsa, (string) ($_POST['forma'] ?? '')); ?></select></div>
                        </div>
                        <?php if ((int) $novo['nterminais'] > (int) $atual['nterminais']): ?>
                            <div class="form-check mt-2">
                                <input class="form-check-input" type="checkbox" name="liberar_ao_pagar" id="liberar_ao_pagar" value="1">
                                <label class="form-check-label small" for="liberar_ao_pagar">
                                    S&oacute; liberar os <?= (int) $novo['nterminais']; ?> caixas quando esta cobran&ccedil;a for paga (at&eacute; l&aacute;, continua com <?= (int) $atual['nterminais']; ?>)
                                </label>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php elseif ($conta['delta'] === 0): ?>
                    <p class="small text-secondary">A mensalidade n&atilde;o muda.</p>
                <?php endif; ?>

                <button type="submit" name="acao" value="aplicar" class="btn btn-primary btn-sm"><i class="fas fa-check me-1"></i>Confirmar a mudan&ccedil;a</button>
                <a href="/ver_empresa.php?id=<?= $id; ?>" class="btn btn-outline-secondary btn-sm">Cancelar</a>
            <?php endif; ?>
            </div></div>
        </div>
    </div>
</form>
<script>
// A FORMA SEGUE A CONTA (14/09/2026). Cada <option> de conta traz em
// data-formas o que ela cobra (shield_conta_formas, a mesma lista que o
// servidor confere); o select de forma ao lado mostra so essas. A escolhida
// que nao serve mais cai na primeira que serve -- e so no clique: ao abrir, o
// PHP ja desenhou as opcoes certas, para nada trocar diante do membro.
function mudFormas(conta, forma) {
    if (!conta || !forma) { return; }
    var op = conta.options[conta.selectedIndex];
    var faz = op ? (op.getAttribute('data-formas') || '').split(',') : [];
    var primeira = null;
    Array.prototype.forEach.call(forma.options, function (o) {
        var serve = faz.indexOf(o.value) !== -1;
        o.hidden = !serve; o.disabled = !serve;
        if (serve && primeira === null) { primeira = o; }
    });
    var atual = forma.options[forma.selectedIndex];
    if ((!atual || atual.disabled) && primeira) { primeira.selected = true; }
}
// A CONTA SE REFAZ SOZINHA (10/09/2026, tarde): mexeu num numero ou num
// modulo, o painel pede a previa ao proprio servidor e troca so o cartao
// "Antes de confirmar". A regra continua em um lugar (shield_mudanca_calcular);
// aqui nao ha calculo nenhum, so o pedido. O botao "Ver o que muda" fica para
// quem esta sem JavaScript.
(function () {
    var f = document.getElementById('formMudanca'), alvo = document.getElementById('previaMudanca');
    if (!f || !alvo || !window.fetch) { return; }
    var pendente = null;
    function refazer() {
        var dados = new FormData(f);
        dados.set('acao', 'previa');
        alvo.style.opacity = '.5';
        fetch(f.action, { method: 'POST', body: dados, credentials: 'same-origin' })
            .then(function (r) { return r.text(); })
            .then(function (html) {
                var doc = new DOMParser().parseFromString(html, 'text/html');
                var novo = doc.getElementById('previaMudanca');
                if (novo) { alvo.innerHTML = novo.innerHTML; }
                alvo.style.opacity = '';
                if (window.shieldMascaraDinheiro) { window.shieldMascaraDinheiro(alvo); }
            })
            .catch(function () { alvo.style.opacity = ''; });
    }
    f.addEventListener('change', function (ev) {
        if (ev.target && ev.target.closest('#previaMudanca')) { return; }   // os campos da previa nao refazem a previa
        clearTimeout(pendente); pendente = setTimeout(refazer, 150);
    });
    f.addEventListener('input', function (ev) {
        if (ev.target && ev.target.type === 'number') { clearTimeout(pendente); pendente = setTimeout(refazer, 400); }
    });
})();
</script>

<?php
/* COMO PAGA -- 10/09/2026, tarde: assinatura ou pre-pago, com os numeros. A
   mudanca vale quando o periodo ja pago terminar; a tela diz a data. */
$validadeAtual = trim((string) ($empresa['validade_licenca'] ?? ''));
$fimPeriodo = ($validadeAtual !== '' && $validadeAtual !== '0000-00-00' && substr($validadeAtual, 0, 10) > date('Y-m-d')) ? substr($validadeAtual, 0, 10) : date('Y-m-d');
$assAtual = $ctx['assinatura'];
$contaModoSugerida = is_array($assAtual) && (int) ($assAtual['fk_conta'] ?? 0) > 0 ? (int) $assAtual['fk_conta'] : shield_conta_padrao($pdo);
?>
<div class="card mt-3" id="como-paga" data-tour="mud-modo">
    <div class="card-header">Como paga</div>
    <div class="card-body">
        <?php if ($modoFeito !== null): ?>
            <div class="alert alert-success py-2 small mb-3">
                <?php if ($modoFeito['modo'] === 'prepago'): ?>
                    Pr&eacute;-pago gravado. A fatura do per&iacute;odo vence em <strong><?= shield_h(date('d/m/Y', strtotime($modoFeito['fim']))); ?></strong>, quando o per&iacute;odo atual termina.
                    Paga, a licen&ccedil;a anda a partir dessa data; n&atilde;o paga, fica esperando.
                <?php else: ?>
                    Assinatura gravada. A primeira mensalidade &eacute; a do m&ecirc;s em que o per&iacute;odo atual termina (<?= shield_h(date('m/Y', strtotime($modoFeito['fim']))); ?>), no dia escolhido; a cobran&ccedil;a nasce sozinha sete dias antes.
                <?php endif; ?>
                <?php if ($modoFeito['aviso'] !== ''): ?><span class="d-block" style="color: var(--atencao)"><?= shield_h($modoFeito['aviso']); ?></span><?php endif; ?>
            </div>
        <?php endif; ?>
        <?php
        // O HISTORICO do "como paga": as trocas ficam no livro de auditoria.
        $historicoModo = array();
        try {
            $st = $pdo->prepare("SELECT criado_em, ator, detalhe FROM auditoria WHERE acao = 'contrato_trocou_modo' AND alvo_tipo = 'empresa' AND alvo_id = :e ORDER BY id DESC LIMIT 6");
            $st->execute(array(':e' => (string) $id));
            $historicoModo = $st->fetchAll(PDO::FETCH_ASSOC) ?: array();
        } catch (Throwable $semTabela) {
        }
        ?>
        <?php /* TRES FATOS NUMA LINHA e o texto na largura toda (10/09/2026, tarde): o
                 historico numa coluna a parte deixava um buraco a direita do texto. */ ?>
        <div class="row g-3 mb-2" data-tour="mud-hoje">
            <div class="col-md-4">
                <div class="small text-secondary">Sistema hoje</div>
                <div><strong><?= is_array($assAtual) ? 'Assinatura' : 'Pr&eacute;-pago'; ?></strong>
                    <?= is_array($assAtual) ? '&middot; R$ ' . shield_h(shield_dinheiro((int) $assAtual['valor_centavos'])) . ' ' . shield_h(shield_plano_ciclo_rotulo((int) $assAtual['ciclo_meses'])) . ((int) $assAtual['ciclo_meses'] > 1 ? ' (R$ ' . shield_h(shield_dinheiro((int) $ctx['mensal'])) . ' por m&ecirc;s)' : '') . ', vence dia ' . (int) $assAtual['dia_vencimento'] : ''; ?></div>
            </div>
            <div class="col-md-4">
                <div class="small text-secondary">Per&iacute;odo pago</div>
                <div>at&eacute; <strong><?= shield_h(date('d/m/Y', strtotime($fimPeriodo))); ?></strong><?= $fimPeriodo === date('Y-m-d') ? ' <span class="text-secondary">(vencido: o que voc&ecirc; gravar vale de hoje)</span>' : ''; ?></div>
            </div>
            <div class="col-md-4">
                <div class="small text-secondary">Hist&oacute;rico</div>
                <?php if ($historicoModo === array()): ?>
                    <div class="small text-secondary">Nenhuma mudan&ccedil;a de "como paga" registrada.</div>
                <?php else: ?>
                    <ul class="list-unstyled small mb-0">
                        <?php foreach ($historicoModo as $h): ?>
                            <li><span class="text-secondary num"><?= shield_h(date('d/m/Y', strtotime((string) $h['criado_em']))); ?></span> &middot; <?= shield_h((string) $h['detalhe']); ?><?= trim((string) $h['ator']) !== '' ? ' <span class="text-secondary">(' . shield_h((string) $h['ator']) . ')</span>' : ''; ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
        <div class="small text-secondary mb-3">
            O que voc&ecirc; gravar abaixo <strong>come&ccedil;a quando esse per&iacute;odo terminar</strong>. Exemplos:
            faltando um m&ecirc;s de um pr&eacute;-pago e o cliente pediu mais seis, grave um pr&eacute;-pago de 6: a fatura vence no fim do m&ecirc;s que falta e, paga, os seis meses entram em seguida.
            Assinatura que vira pr&eacute;-pago para de gerar mensalidade; pr&eacute;-pago que vira assinatura ganha a primeira mensalidade no m&ecirc;s em que acabar.
            Os m&oacute;dulos e os caixas fora do plano que est&atilde;o em "Como fica" entram na conta &mdash; ajuste l&aacute; antes, se for o caso.
        </div>
        <form method="post" action="/mudanca_contrato.php?id=<?= $id; ?>" class="row g-2 align-items-end" id="formModo">
            <input type="hidden" name="id" value="<?= $id; ?>">
            <input type="hidden" name="acao" value="modo">
            <input type="hidden" name="chave_modo" value="<?= shield_h($chaveEnvio . '-modo'); ?>">
            <div class="col-12">
                <div class="dois-lados" role="radiogroup" aria-label="Como paga">
                    <input type="radio" name="modo" id="modo_ass" value="assinatura" <?= is_array($assAtual) ? 'checked' : ''; ?> onchange="modoMostrar()">
                    <label for="modo_ass" class="desliga">Assinatura</label>
                    <input type="radio" name="modo" id="modo_pre" value="prepago" <?= is_array($assAtual) ? '' : 'checked'; ?> onchange="modoMostrar()">
                    <label for="modo_pre">Pr&eacute;-pago</label>
                </div>
            </div>
            <div class="col-6 col-md-3"><label class="form-label small mb-1" for="valor_modo">Valor mensal (R$)</label>
                <input class="form-control form-control-sm num dinheiro" id="valor_modo" name="valor_modo" data-teto="999999" maxlength="15" required
                       value="<?= is_array($assAtual) ? shield_h(shield_dinheiro((int) $ctx['mensal'])) : ''; ?>" placeholder="0,00" onfocus="this.select()"></div>
            <div class="col-6 col-md-3 so-ass"><label class="form-label small mb-1" for="ciclo_meses">Cobra a cada</label>
                <select class="form-select form-select-sm" id="ciclo_meses" name="ciclo_meses">
                    <?php /* CHAVE => ROTULO (11/09/2026): percorrer so os valores dava quatro
                             opcoes com value="0", todas "mensal". Achado da auditoria. */ ?>
                    <?php foreach (shield_plano_ciclos('assinatura') as $cm => $rotuloCiclo): ?>
                        <option value="<?= (int) $cm; ?>" <?= is_array($assAtual) && (int) $assAtual['ciclo_meses'] === (int) $cm ? 'selected' : ''; ?>><?= shield_h($rotuloCiclo); ?></option>
                    <?php endforeach; ?>
                </select></div>
            <?php /* ATE 31 (23/09/2026, pedido de membro que cobra no dia 30). O teto era 28
                     "porque 29, 30 e 31 nao existem em todo mes", mas quem resolve isso e
                     shield_assinatura_vencimento, que ja corta o dia pelo ultimo do mes: dia 30
                     vence 28/02 (ou 29) e volta a 30 em marco. O teto so tirava do membro o dia
                     que ele combinou com o cliente. */ ?>
            <div class="col-6 col-md-2 so-ass"><label class="form-label small mb-1" for="dia_vencimento">Dia do vencimento</label>
                <input type="number" min="1" max="31" class="form-control form-control-sm num" id="dia_vencimento" name="dia_vencimento" value="<?= is_array($assAtual) ? (int) $assAtual['dia_vencimento'] : 10; ?>">
                <div class="form-text small">Em m&ecirc;s mais curto, vence no &uacute;ltimo dia dele.</div></div>
            <div class="col-6 col-md-3 so-pre"><label class="form-label small mb-1" for="meses">Meses pagos de uma vez</label>
                <select class="form-select form-select-sm" id="meses" name="meses">
                    <?php foreach (array(1, 3, 6, 12, 24) as $mm): ?>
                        <option value="<?= $mm; ?>" <?= $mm === 12 ? 'selected' : ''; ?>><?= $mm; ?> <?= $mm === 1 ? 'm&ecirc;s' : 'meses'; ?></option>
                    <?php endforeach; ?>
                </select></div>
            <?php $contaModoSugerida = $contaNaTela($contaModoSugerida); ?>
            <div class="col-6 col-md-3"><label class="form-label small mb-1" for="conta_modo">Conta de recebimento</label>
                <select class="form-select form-select-sm" id="conta_modo" name="conta_modo" onchange="mudFormas(this, document.getElementById('forma_modo'))">
                    <?php foreach ($contas as $c): ?>
                        <option value="<?= (int) $c['id']; ?>" <?= (int) $c['id'] === $contaModoSugerida ? 'selected' : ''; ?> data-formas="<?= shield_h(implode(',', $formasConta[(int) $c['id']])); ?>"><?= shield_h(shield_conta_rotulo($c)); ?></option>
                    <?php endforeach; ?>
                </select></div>
            <div class="col-6 col-md-2"><label class="form-label small mb-1" for="forma_modo">Forma</label>
                <?php /* SO AS FORMAS DA CONTA AO LADO, UMA ESCOLHA (14/09/2026). Eram as quatro
                         fixas, e "Boleto" numa conta que so cobra por PIX so aparecia como erro depois. */ ?>
                <select class="form-select form-select-sm" id="forma_modo" name="forma_modo"><?= $opcoesForma($contaModoSugerida, is_array($assAtual) ? (string) ($assAtual['forma'] ?? '') : ''); ?></select></div>
            <div class="col-12">
                <button type="submit" class="btn btn-primary btn-sm" onclick="return confirm('Gravar como este cliente paga? A mudança vale quando o período atual terminar.');"><i class="fas fa-check me-1"></i>Gravar como paga</button>
                <span class="small text-secondary ms-2 so-pre">A fatura do pr&eacute;-pago nasce agora, com m&oacute;dulos e caixas fora do plano vezes os meses, vencendo no fim do per&iacute;odo atual.</span>
                <span class="small text-secondary ms-2 so-ass">Assinatura j&aacute; existente: os n&uacute;meros novos valem a partir da pr&oacute;xima mensalidade.</span>
            </div>
        </form>
    </div>
</div>
<script>
function modoMostrar() {
    var pre = document.getElementById('modo_pre').checked;
    document.querySelectorAll('#formModo .so-pre').forEach(function (e) { e.hidden = !pre; });
    document.querySelectorAll('#formModo .so-ass').forEach(function (e) { e.hidden = pre; });
}
modoMostrar();
</script>

<?php
/* POR ONDE O DINHEIRO ENTRA -- 10/09/2026, tarde. A conta escolhida no
   fechamento fica fixa na assinatura e o ciclo emite nela todo mes. Trocar e
   aqui, e a troca avisa o que vai acontecer com o que esta na rua. */
$previaConta = shield_mudanca_conta_previa($pdo, $id, 0);
$contaAtualLinha = $previaConta['conta_atual'] > 0 ? shield_cob_conta($pdo, $previaConta['conta_atual']) : null;
// O SELECT JA VEM NA CONTA DE HOJE (pedido de 10/09/2026): a fixa da assinatura
// ou, sem fixa, a padrao. O membro so muda se quiser.
$contaSugerida = $previaConta['conta_atual'] > 0 ? (int) $previaConta['conta_atual'] : shield_conta_padrao($pdo);
$contaPadraoLinha = $contaAtualLinha === null && $contaSugerida > 0 ? shield_cob_conta($pdo, $contaSugerida) : null;
?>
<div class="card mt-3" data-tour="mud-conta">
    <div class="card-header">Por onde o dinheiro entra</div>
    <div class="card-body">
        <?php if ($contaFeita !== null): ?>
            <div class="alert alert-success py-2 small mb-2">
                Conta trocada.
                <?php if (count($contaFeita['reemitidas']) > 0): ?>
                    <?= count($contaFeita['reemitidas']); ?> cobran&ccedil;a(s) cancelada(s) no provedor antigo e emitida(s) no novo, com o mesmo vencimento.
                <?php endif; ?>
                As pr&oacute;ximas mensalidades saem pela conta nova.
            </div>
            <?php foreach ($contaFeita['falhas'] as $cobId => $motivo): ?>
                <div class="alert alert-warning py-2 small mb-2">
                    A cobran&ccedil;a <?= (int) $cobId; ?> <strong>ficou na conta antiga</strong>: <?= shield_h($motivo); ?>
                    <a href="/cobrancas.php?empresa=<?= $id; ?>&situacao=abertas">Abrir as cobran&ccedil;as</a>.
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        <form method="post" action="/mudanca_contrato.php?id=<?= $id; ?>" class="row g-2 align-items-end"
              onsubmit="return confirm('Trocar a conta de recebimento deste contrato? <?= count($previaConta['reemitir']) > 0 ? count($previaConta['reemitir']) . ' cobrança(s) em aberto será(ão) cancelada(s) no provedor antigo e emitida(s) no novo, com o mesmo vencimento e o mesmo valor. ' : ''; ?>As próximas mensalidades saem pela conta nova.');">
            <input type="hidden" name="id" value="<?= $id; ?>">
            <input type="hidden" name="acao" value="trocar_conta">
            <div class="col-md-4">
                <div class="small text-secondary">Hoje</div>
                <div><?= $contaAtualLinha !== null ? shield_h(shield_conta_rotulo($contaAtualLinha)) : ($contaPadraoLinha !== null ? shield_h(shield_conta_rotulo($contaPadraoLinha)) . ' <span class="text-secondary small">(a padr&atilde;o; sem conta fixa)</span>' : '<span class="text-secondary">sem conta fixa nem padr&atilde;o</span>'); ?></div>
            </div>
            <div class="col-md-5">
                <label class="form-label small mb-1" for="conta_nova">Trocar para</label>
                <select class="form-select form-select-sm" id="conta_nova" name="conta_nova" required>
                    <?php foreach ($contas as $c): ?>
                        <?php /* O que cada conta cobra no proprio rotulo (14/09/2026): e o que decide se a troca passa. */ ?>
                        <option value="<?= (int) $c['id']; ?>" <?= (int) $c['id'] === $contaSugerida ? 'selected' : ''; ?>><?= shield_h(shield_conta_rotulo($c)); ?><?= $formasConta[(int) $c['id']] ? ' (' . implode(', ', array_map(static function ($f) { return array('pix' => 'PIX', 'boleto' => 'Boleto', 'cartao' => 'Cart&atilde;o', 'dinheiro' => 'Dinheiro')[$f] ?? $f; }, $formasConta[(int) $c['id']])) . ')' : ''; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-sm btn-outline-primary w-100"><i class="fas fa-sync-alt me-1"></i>Trocar a conta</button>
            </div>
            <div class="col-12 small text-secondary">
                <?php if (count($previaConta['reemitir']) > 0): ?>
                    <strong style="color: var(--atencao)">Aten&ccedil;&atilde;o:</strong>
                    <?php foreach ($previaConta['reemitir'] as $c): ?>
                        <span class="d-block">&middot; <?= shield_h((string) $c['descricao']); ?>, R$ <?= shield_h(shield_dinheiro((int) $c['valor_centavos'])); ?>,
                            vence <?= shield_h(date('d/m/Y', strtotime((string) $c['vencimento']))); ?> &mdash; se j&aacute; n&atilde;o estiver na conta nova, o c&oacute;digo atual ser&aacute; cancelado onde est&aacute; e um novo emitido nela, mesmo vencimento, mesmo valor<?= (string) $c['situacao'] === 'vencida' ? ' (vencida: entra com multa e juros de hoje, se configurados)' : ''; ?>.</span>
                    <?php endforeach; ?>
                <?php else: ?>
                    Nenhuma cobran&ccedil;a emitida em aberto. S&oacute; as pr&oacute;ximas mudam de conta<?= $previaConta['rascunhos'] > 0 ? ' (' . (int) $previaConta['rascunhos'] . ' rascunho(s) inclu&iacute;do(s))' : ''; ?>.
                <?php endif; ?>
                A conta nova precisa fazer a forma das cobran&ccedil;as na rua (PIX, boleto, cart&atilde;o); sen&atilde;o a troca &eacute; recusada e nada muda.
                Entrando ou saindo do dinheiro em esp&eacute;cie, a forma muda junto.
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
