<?php

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';

if (!isset($_SESSION['usuario']) || ($_SESSION['usuario']['acesso'] ?? '') != 1) {
    header('Location: acesso_negado.php');
    exit;
}

if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    header('Location: clientes.php');
    exit;
}


$id = (int) $_GET['id'];
$error = '';

try {
    $stmtEmpresa = $pdo->prepare("SELECT * FROM empresa WHERE codigo = :codigo LIMIT 1");
    $stmtEmpresa->execute([':codigo' => $id]);
    $empresa = $stmtEmpresa->fetch(PDO::FETCH_ASSOC);

    if (!$empresa) {
        die('Empresa nao encontrada.');
    }
} catch (PDOException $exception) {
    die('Erro ao carregar dados da empresa: ' . $exception->getMessage());
}

// shield_centavos e shield_dinheiro: o campo mostra "25,00" e o banco guarda
// 2500. O parser aceita "1.234,56", "1234.56" e "R$ 10" -- o operador digita do
// jeito dele.
require_once __DIR__ . '/../../funcoes/cobranca/cobranca.php';
// O CADASTRO EDITA AQUI TAMBEM (10/09/2026, tarde): endereco, telefones, e-mail
// e os dois responsaveis sao os mesmos campos do fechamento, com a mesma
// normalizacao. Depois de dar inicio ao contrato nao havia onde corrigir um
// telefone errado.
require_once __DIR__ . '/../../funcoes/empresa/fechamento.php';
require_once __DIR__ . '/../../funcoes/licenca/situacao.php';   // shield_cnpj
require_once __DIR__ . '/../../templates/contexto_cliente.php';  // shield_voltar_cliente
require_once __DIR__ . '/../../funcoes/empresa/empresa.php';     // shield_empresa_representante

$form = [
    // VAZIA CONTINUA VAZIA -- 14/09/2026. O formulario nao manda mais
    // nterminais (fatia 8) e o POST regrava o que foi carregado: carregar NULL
    // como "0" fazia cada Salvar do cadastro gravar zero, que e "sem limite" e
    // nao herda a cota do teste no primeiro pagamento (funcoes/licenca/validade.php).
    'nterminais' => ($empresa['nterminais'] ?? null) === null ? '' : (string) $empresa['nterminais'],
    'terminais_inclusos' => (string) ($empresa['terminais_inclusos'] ?? '0'),
    'valor_terminal' => shield_dinheiro((int) ($empresa['valor_terminal_centavos'] ?? 0)),
    'validade_licenca' => !empty($empresa['validade_licenca']) ? date('Y-m-d', strtotime((string) $empresa['validade_licenca'])) : '',
    'bloqueado' => strtoupper((string) ($empresa['bloqueado'] ?? 'N')) === 'S' ? 'S' : 'N',
    'cnpj_representante' => (string) ($empresa['cnpj_representante'] ?? ''),
];
foreach (array_keys(shield_fechamento_campos_cadastro()) as $campoCad) {
    if ($campoCad === 'razao') { continue; }
    $form[$campoCad] = trim((string) ($empresa[$campoCad] ?? ''));
}
$form['area_senha'] = '';
// O ESTADO DE ANTES, congelado agora -- 09/09/2026. Ele e o "antes" da
// linha de auditoria la embaixo, e tem de ser tirado daqui, do $form ja
// normalizado: comparar direto contra a coluna do banco marcaria mudanca falsa
// toda vez (validade_licenca volta como datetime e nterminais como int).
$formOriginal = $form;

// MODULOS -- 09/09/2026. O catalogo com o que ESTE cliente ja tem
// marcado, numa consulta so. `ate IS NULL` e o contrato aberto; linha fechada
// fica no banco para responder "quando ele deixou de ter NFS-e".
$modulos = [];
try {
    $stmt = $pdo->prepare(
        'SELECT m.id, m.nome, m.valor_centavos,
                em.id AS contrato, em.valor_centavos AS valor_cliente
           FROM modulo m
           LEFT JOIN empresa_modulo em
                  ON em.fk_modulo = m.id AND em.fk_empresa = :emp AND em.ate IS NULL
          WHERE m.ativo = 1 OR em.id IS NOT NULL
          ORDER BY m.nome'
    );
    $stmt->execute([':emp' => $id]);
    $modulos = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $semTabela) {
    // Base sem a 4.0.7: a secao nao aparece e o resto da tela funciona igual.
    $modulos = [];
}

// QUANTAS ESTAO TRABALHANDO AGORA -- 09/09/2026. Sem este numero, o
// membro baixa a cota de 4 para 3 sem saber que isso vai parar um caixa que
// esta vendendo neste momento. O aviso e a metade barata do problema; a outra
// metade e ele ver o real ao lado do contratado, que era o pedido original.
require_once __DIR__ . '/../../funcoes/licenca/parque.php';
// A MESMA funcao da lista e da ficha (fatia 9, 10/09/2026). Este SQL proprio
// usava ">" onde a funcao usa ">=": a maquina no exato limite era viva numa
// tela e sumida na outra.
$vivosAgora = 0;
try {
    $vivosAgora = (int) (shield_parque_vivos_por_empresa($pdo, [$id])[$id] ?? 0);
} catch (Throwable $ignorado) {
    $vivosAgora = 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // TERMINAIS, INCLUSOS, PRECO DO EXTRA E MODULOS NAO SE EDITAM MAIS AQUI --
    // 10/09/2026, fatia 8. "Um endereco onde se mexe": quem muda o contrato e
    // /mudanca_contrato.php, que mostra o antes e o depois e cobra o mes
    // corrente. Esta tela so os mostra; o POST mantem o que esta gravado.
    $form['nterminais'] = trim((string) ($_POST['nterminais'] ?? $form['nterminais']));
    $form['terminais_inclusos'] = trim((string) ($_POST['terminais_inclusos'] ?? $form['terminais_inclusos']));
    $form['valor_terminal'] = trim((string) ($_POST['valor_terminal'] ?? $form['valor_terminal']));
    $form['validade_licenca'] = trim((string) ($_POST['validade_licenca'] ?? ''));
    $form['bloqueado'] = strtoupper(trim((string) ($_POST['bloqueado'] ?? 'N')));
    $form['cnpj_representante'] = trim((string) ($_POST['cnpj_representante'] ?? ''));
    // O cadastro passa pela normalizacao do fechamento (digitos no telefone,
    // CEP so numeros, UF maiuscula, tamanho da coluna).
    $cadastroNorm = shield_fechamento_normalizar(array_merge($_POST, array('razao' => (string) $empresa['razao'])));
    foreach (array_keys(shield_fechamento_campos_cadastro()) as $campoCad) {
        if ($campoCad === 'razao') { continue; }
        $form[$campoCad] = $cadastroNorm[$campoCad];
    }
    $form['area_senha'] = $cadastroNorm['area_senha'];
    if ($form['fone'] !== '' && !in_array(strlen($form['fone']), array(10, 11), true)) {
        $error = 'Telefone da loja incompleto: precisa de DDD e numero.';
    } elseif ($form['email'] !== '' && filter_var($form['email'], FILTER_VALIDATE_EMAIL) === false) {
        $error = 'E-mail da loja precisa de @ e ponto.';
    } elseif ($form['area_senha'] !== '' && strlen($form['area_senha']) < 6) {
        $error = 'A senha da area do cliente precisa de pelo menos 6 caracteres.';
    } elseif ($form['area_senha'] !== '' && $form['email'] === '') {
        $error = 'A senha da area do cliente precisa do e-mail da loja: e com ele que o cliente entra.';
    }
    foreach (array('responsavel' => 'quem assina', 'financeiro' => 'quem paga') as $quemCad => $rotuloCad) {
        if ($error !== '') { break; }
        if ($form[$quemCad . '_fone'] !== '' && !in_array(strlen($form[$quemCad . '_fone']), array(10, 11), true)) {
            $error = 'Telefone de ' . $rotuloCad . ' incompleto: precisa de DDD e numero.';
        } elseif ($form[$quemCad . '_email'] !== '' && filter_var($form[$quemCad . '_email'], FILTER_VALIDATE_EMAIL) === false) {
            $error = 'E-mail de ' . $rotuloCad . ' precisa de @ e ponto.';
        }
    }

    $nTerminais = null;
    $validadeLicencaDb = null;
    $bloqueado = $form['bloqueado'];
    $cnpjRepresentanteDb = null;

    if ($form['nterminais'] === '') {
        $nTerminais = null;   // nao informada: grava NULL de volta (ver o $form la em cima)
    } elseif (!ctype_digit($form['nterminais'])) {
        $error = 'Numero de terminais invalido. Informe um inteiro igual ou maior que zero.';
    } else {
        $nTerminais = (int) $form['nterminais'];
        if ($nTerminais < 0) {
            $error = 'Numero de terminais invalido. Informe um inteiro igual ou maior que zero.';
        }
    }

    if ($error === '' && $form['validade_licenca'] !== '') {
        $date = DateTime::createFromFormat('Y-m-d', $form['validade_licenca']);
        $isValidDate = $date && $date->format('Y-m-d') === $form['validade_licenca'];
        if (!$isValidDate) {
            $error = 'Data de validade da licenca invalida.';
        } else {
            $validadeLicencaDb = $form['validade_licenca'];
        }
    }

    if ($error === '' && !in_array($bloqueado, ['S', 'N'], true)) {
        $error = 'Status de bloqueio invalido.';
    }

    // SEM CONFERIR NA TABELA `representante` (17/09/2026), que nada grava: o
    // numero que o ERP poe na coluna travava o Salvar. Ver shield_empresa_representante.
    $representante = shield_empresa_representante($form['cnpj_representante'], (string) ($empresa['cnpj_representante'] ?? ''));
    if ($error === '' && $representante['erro'] !== '') {
        $error = $representante['erro'];
    }
    $cnpjRepresentanteDb = $representante['valor'];

    if ($error === '') {
        try {
            $setsCad = '';
            $paramsCad = [];
            foreach (array_keys(shield_fechamento_campos_cadastro()) as $campoCad) {
                if ($campoCad === 'razao') { continue; }
                $setsCad .= ', ' . $campoCad . ' = :c_' . $campoCad;
                // Coluna NOT NULL recebe '' e nao NULL: em servidor estrito o NULL e erro 1048.
                $paramsCad[':c_' . $campoCad] = shield_fechamento_valor_cadastro($campoCad, $form[$campoCad]);
            }
            if ($form['area_senha'] !== '') {
                $setsCad .= ', area_senha = :c_area_senha, area_senha_temporaria = 0, area_senha_vence = NULL';
                $paramsCad[':c_area_senha'] = password_hash($form['area_senha'], PASSWORD_DEFAULT);
            }
            $stmtUpdate = $pdo->prepare(
                "UPDATE empresa
                 SET nterminais = :nterminais,
                     terminais_inclusos = :inclusos,
                     valor_terminal_centavos = :valor_terminal,
                     validade_licenca = :validade_licenca,
                     bloqueado = :bloqueado,
                     cnpj_representante = :cnpj_representante" . $setsCad . "
                 WHERE codigo = :codigo"
            );

            $stmtUpdate->execute([
                ':nterminais' => $nTerminais,
                ':inclusos' => max(0, (int) $form['terminais_inclusos']),
                ':valor_terminal' => max(0, shield_centavos($form['valor_terminal'])),
                ':validade_licenca' => $validadeLicencaDb,
                ':bloqueado' => $bloqueado,
                ':cnpj_representante' => $cnpjRepresentanteDb,
                ':codigo' => $id,
            ] + $paramsCad);

            // LIBERAR AQUI TIRA A SUSPENSAO JUNTO -- 14/09/2026. O radio gravava
            // so o bloqueado: o suspenso liberado por esta tela ficava com a
            // marca de suspensao preenchida, e a marca sozinha continuava
            // mandando -- a ficha seguia "Suspenso", a regua nunca mais o
            // suspendia e um bloqueio manual posterior virava divida no token.
            // A mesma funcao do "liberar" da regua: so age com a marca presente
            // e grava cliente_liberado no livro.
            if ($bloqueado === 'N') {
                require_once __DIR__ . '/../../funcoes/licenca/validade.php';
                shield_validade_liberar($pdo, $id, 'liberado no Contrato do cliente');
            }

            // FICA NO LIVRO. Estes cinco campos decidem se a loja do cliente
            // trabalha -- a cota de terminais vira `excedente` no token
            // assinado, e o ERP traduz isso em caixa que nao abre. Ate aqui
            // nenhuma tela de cliente auditava nada.
            //
            // Depois do UPDATE e antes do redirect, de proposito: linha no
            // livro sem gravacao no banco seria pior do que nenhuma. E a funcao
            // nunca lanca -- ver o "falha aberto" dela --, entao o membro nunca
            // perde a gravacao por causa da auditoria.
            // OS MODULOS DO CLIENTE. Contratar COPIA o valor de tabela; cancelar
            // carimba `ate` e mantem a linha. Nada aqui apaga historico: "o que
            // ele pagava em marco" e pergunta que aparece meses depois.
            // Os modulos so mudam pela tela de mudanca (fatia 8); o formulario
            // daqui nao os manda mais, e sem o marcador nada e tocado.
            foreach (isset($_POST['editar_modulos']) ? $modulos : [] as $m) {
                $marcado = in_array((string) $m['id'], (array) ($_POST['modulos'] ?? []), true);
                $tinha = $m['contrato'] !== null;

                if ($marcado && !$tinha) {
                    $pdo->prepare(
                        'INSERT INTO empresa_modulo (fk_empresa, fk_modulo, valor_centavos, desde)
                         VALUES (:e, :m, :v, CURDATE())'
                    )->execute([':e' => $id, ':m' => (int) $m['id'], ':v' => (int) $m['valor_centavos']]);
                } elseif (!$marcado && $tinha) {
                    $pdo->prepare('UPDATE empresa_modulo SET ate = CURDATE() WHERE id = :c')
                        ->execute([':c' => (int) $m['contrato']]);
                }
            }

            require_once __DIR__ . '/../../funcoes/empresa/empresa.php';
            shield_empresa_auditar_cadastro($pdo, $id, $formOriginal, [
                'nterminais'         => $nTerminais,
                'terminais_inclusos' => max(0, (int) $form['terminais_inclusos']),
                'valor_terminal'     => shield_dinheiro(max(0, shield_centavos($form['valor_terminal']))),
                'validade_licenca'   => (string) $validadeLicencaDb,
                'bloqueado'          => $bloqueado,
                'cnpj_representante' => (string) $cnpjRepresentanteDb,
            ]);

            header('Location: ver_empresa.php?id=' . urlencode((string) $id) . '&status=updated');
            exit;
        } catch (PDOException $exception) {
            $error = 'Erro ao atualizar a empresa: ' . $exception->getMessage();
        }
    }
}

// O QUE ESTES CAMPOS FAZEM COM O DINHEIRO, calculado aqui para a tela poder
// mostrar antes de o membro gravar -- 09/09/2026. Sem este numero, cota
// e preco de terminal parecem cadastro; com ele, viram a conta que sao.
$adicionalTerminais = 0;
$qtdAdicional = max(0, (int) $form['nterminais'] - (int) $form['terminais_inclusos']);
if ((int) $form['nterminais'] > 0) {
    $adicionalTerminais = $qtdAdicional * max(0, shield_centavos($form['valor_terminal']));
}

$adicionalModulos = 0;
foreach ($modulos as $m) {
    if ($m['contrato'] !== null) {
        $adicionalModulos += (int) $m['valor_cliente'];
    }
}
$adicionalTotal = $adicionalTerminais + $adicionalModulos;

/** Telefone guardado como digitos, mostrado como (00)00000-0000 (o mesmo do fechamento). */
function contrato_fone($d)
{
    $d = preg_replace('/\D+/', '', (string) $d);
    if (strlen($d) < 10) {
        return $d;
    }

    return '(' . substr($d, 0, 2) . ')' . substr($d, 2, strlen($d) - 6) . '-' . substr($d, -4);
}
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <p class="trilha mb-1">
            <a href="/clientes.php">Clientes</a> &rsaquo;
            <a href="/ver_empresa.php?id=<?= urlencode((string) $id); ?>"><?= shield_h((string) $empresa['razao']); ?></a>
        </p>
        <h1 class="h4 mb-1">Contrato do cliente</h1>
        <p class="text-secondary small mb-0">
            O que ele contratou, o que ele paga e como falar com ele. Raz&atilde;o social e CNPJ
            vieram do ERP e n&atilde;o mudam aqui.
        </p>
    </div>
    <div class="acoes-pagina">
        <a href="<?= shield_h(shield_voltar_cliente($id)); ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i>Voltar
        </a>
    </div>
</div>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger"><?= shield_h($error); ?></div>
<?php endif; ?>

<?php /* O GUARDA ANTES DE GRAVAR. Baixar a cota abaixo do que esta trabalhando
         desliga caixa que esta vendendo agora, e ate 09/09/2026 a tela gravava
         calada. O aviso diz QUANTOS: "voce tem certeza?" sem numero ninguem le.

         Os sinais de maior vao como entidade HTML. Escritos crus, o filtro que
         injeta o campo anti-CSRF enxergava neles o fim da etiqueta <form> e
         enfiava o campo no meio do atributo -- ver CsrfInjetorTest. O filtro
         foi corrigido no mesmo dia, mas atributo sem `>` cru nao depende
         daquela correcao para continuar valendo. */ ?>
<form action="editar_empresa.php?id=<?= urlencode((string) $id); ?>" method="post">

<div class="row g-3">
    <div class="col-xl-7 coluna-empilhada">

        <div class="card" data-tour="contrato-maquinas">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>M&aacute;quinas e m&oacute;dulos</span>
                <?php /* UM ENDERECO ONDE SE MEXE (fatia 8): mudar terminais e modulos
                         e em Mudar o contrato, que mostra o antes e o depois com a
                         data, cobra o mes corrente e avisa quantas maquinas param. */ ?>
                <a href="/mudanca_contrato.php?id=<?= urlencode((string) $id); ?>" class="btn btn-sm btn-primary">
                    <i class="fas fa-sliders-h me-1"></i>Mudar o contrato
                </a>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-sm-4">
                        <div class="small text-secondary">Contratadas</div>
                        <div class="h5 mb-0 num" id="nterminais" data-vivos="<?= (int) $vivosAgora; ?>"><?= $form['nterminais'] !== '' ? shield_h($form['nterminais']) : 'n&atilde;o informado'; ?></div>
                        <small class="form-text text-muted">a licen&ccedil;a libera</small>
                    </div>
                    <div class="col-sm-4">
                        <div class="small text-secondary">Inclusas no plano</div>
                        <div class="h5 mb-0 num"><?= shield_h($form['terminais_inclusos']); ?></div>
                        <small class="form-text text-muted">a mensalidade j&aacute; cobre</small>
                    </div>
                    <div class="col-sm-4">
                        <div class="small text-secondary">Cada extra custa</div>
                        <div class="h5 mb-0 num">R$ <?= shield_h($form['valor_terminal']); ?></div>
                        <small class="form-text text-muted">por m&ecirc;s</small>
                    </div>
                </div>

                <p class="small text-secondary mt-3 mb-0">
                    <strong><?= (int) $vivosAgora; ?></strong> dando sinal agora.
                    <?php if ($form['nterminais'] === ''): ?>
                        Quantidade contratada n&atilde;o informada: fora do teste, a licen&ccedil;a n&atilde;o limita caixas at&eacute; ela ser gravada em Mudar o contrato.
                    <?php elseif ((int) $form['nterminais'] === 0): ?>
                        Contratadas em zero libera todas &mdash; &eacute; o cliente em demonstra&ccedil;&atilde;o.
                    <?php elseif ($qtdAdicional > 0 && $adicionalTerminais > 0): ?>
                        Fora do plano: <strong><?= $qtdAdicional; ?></strong>,
                        somando <strong>R$ <?= shield_dinheiro($adicionalTerminais); ?></strong> por m&ecirc;s.
                    <?php elseif ($qtdAdicional > 0): ?>
                        H&aacute; <?= $qtdAdicional; ?> fora do plano, mas sem pre&ccedil;o definido &mdash; nada &eacute; cobrado.
                    <?php else: ?>
                        Tudo dentro do plano.
                    <?php endif; ?>
                </p>

                <?php if ($vivosAgora > 0 && (int) $form['nterminais'] > 0 && $vivosAgora > (int) $form['nterminais']): ?>
                    <p class="small mt-2 mb-0" style="color: var(--atencao)">
                        <?= $vivosAgora - (int) $form['nterminais']; ?> m&aacute;quina(s) trabalhando al&eacute;m do
                        contratado. As <strong>mais antigas</strong> ficam; as demais recebem
                        &quot;terminal acima do contratado&quot; ao abrir.
                    </p>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($modulos !== []): ?>
        <div class="card">
            <div class="card-header">M&oacute;dulos contratados</div>
            <div class="card-body">
                <?php $algum = false; ?>
                <?php foreach ($modulos as $m): ?>
                    <?php if ($m['contrato'] === null) { continue; } $algum = true; ?>
                    <div class="small">
                        <i class="fas fa-check me-1" style="color: var(--ok)"></i><?= shield_h((string) $m['nome']); ?>
                        <span class="text-muted">&mdash; R$ <?= shield_dinheiro((int) $m['valor_cliente']); ?>/m&ecirc;s</span>
                        <?php if ((int) $m['valor_cliente'] !== (int) $m['valor_centavos']): ?>
                            <span class="pilula pilula-neutro" title="valor combinado com este cliente">combinado</span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
                <?php if (!$algum): ?><p class="small text-secondary mb-0">Nenhum. Marque em <a href="/mudanca_contrato.php?id=<?= urlencode((string) $id); ?>">Mudar o contrato</a>.</p><?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="card" data-tour="contrato-cadastro">
            <div class="card-header">Cadastro</div>
            <div class="card-body">
                <?php /* OS MESMOS CAMPOS DO FECHAMENTO (10/09/2026, tarde), para corrigir depois
                         o que foi digitado la. Razao e CNPJ ficam a vista, travados. */ ?>
                <div class="row g-2 mb-3">
                    <div class="col-12"><label class="form-label small mb-1" for="razao_visivel">Raz&atilde;o social</label>
                        <input class="form-control form-control-sm" id="razao_visivel" value="<?= shield_h((string) $empresa['razao']); ?>" readonly></div>
                    <div class="col-12"><label class="form-label small mb-1" for="cnpj_visivel">CNPJ</label>
                        <input class="form-control form-control-sm num" id="cnpj_visivel" value="<?= shield_h(shield_cnpj((string) $empresa['cnpj'])); ?>" readonly></div>
                    <div class="col-8"><label class="form-label small mb-1" for="endereco">Endere&ccedil;o</label>
                        <input class="form-control form-control-sm" id="endereco" name="endereco" maxlength="50" value="<?= shield_h($form['endereco']); ?>"></div>
                    <div class="col-4"><label class="form-label small mb-1" for="cep">CEP</label>
                        <input class="form-control form-control-sm num" id="cep" name="cep" maxlength="9" value="<?= shield_h($form['cep']); ?>" placeholder="8 d&iacute;gitos" onblur="fechCep(this.value)">
                        <small class="text-secondary" id="cepNota"></small></div>
                    <div class="col-5"><label class="form-label small mb-1" for="bairro">Bairro</label>
                        <input class="form-control form-control-sm" id="bairro" name="bairro" maxlength="35" value="<?= shield_h($form['bairro']); ?>"></div>
                    <div class="col-5"><label class="form-label small mb-1" for="cidade">Cidade</label>
                        <input class="form-control form-control-sm" id="cidade" name="cidade" maxlength="35" value="<?= shield_h($form['cidade']); ?>"></div>
                    <div class="col-2"><label class="form-label small mb-1" for="uf">UF</label>
                        <input class="form-control form-control-sm" id="uf" name="uf" maxlength="2" value="<?= shield_h($form['uf']); ?>"></div>
                    <div class="col-5"><label class="form-label small mb-1" for="fone">Telefone da loja</label>
                        <input class="form-control form-control-sm num fone" id="fone" name="fone" maxlength="14" placeholder="(00)00000-0000" value="<?= shield_h(contrato_fone($form['fone'])); ?>"></div>
                    <div class="col-4"><label class="form-label small mb-1" for="email">E-mail da loja</label>
                        <input type="email" class="form-control form-control-sm" id="email" name="email" maxlength="255" value="<?= shield_h($form['email']); ?>"></div>
                    <div class="col-3"><label class="form-label small mb-1" for="area_senha">Senha do cliente</label>
                        <input type="password" class="form-control form-control-sm" id="area_senha" name="area_senha" maxlength="72" autocomplete="new-password"
                               placeholder="<?= !empty($empresa['area_senha']) ? 'j&aacute; definida; digite para trocar' : 'm&iacute;nimo 6'; ?>" title="O cliente entra na &aacute;rea dele com o e-mail da loja e esta senha"></div>
                </div>

                <div class="small text-secondary mb-1">Quem assina</div>
                <div class="row g-2 mb-2">
                    <div class="col-5"><input class="form-control form-control-sm" id="responsavel_nome" name="responsavel_nome" maxlength="255" placeholder="Nome" value="<?= shield_h($form['responsavel_nome']); ?>"></div>
                    <div class="col-3"><input class="form-control form-control-sm num fone" id="responsavel_fone" name="responsavel_fone" maxlength="14" placeholder="(00)00000-0000" value="<?= shield_h(contrato_fone($form['responsavel_fone'])); ?>"></div>
                    <div class="col-4"><input type="email" class="form-control form-control-sm" id="responsavel_email" name="responsavel_email" maxlength="255" placeholder="E-mail" value="<?= shield_h($form['responsavel_email']); ?>"></div>
                </div>
                <div class="small text-secondary mb-1">Quem paga (recebe a cobran&ccedil;a)</div>
                <div class="row g-2 mb-3">
                    <div class="col-5"><input class="form-control form-control-sm" id="financeiro_nome" name="financeiro_nome" maxlength="255" placeholder="Nome" value="<?= shield_h($form['financeiro_nome']); ?>"></div>
                    <div class="col-3"><input class="form-control form-control-sm num fone" id="financeiro_fone" name="financeiro_fone" maxlength="14" placeholder="(00)00000-0000" value="<?= shield_h(contrato_fone($form['financeiro_fone'])); ?>"></div>
                    <div class="col-4"><input type="email" class="form-control form-control-sm" id="financeiro_email" name="financeiro_email" maxlength="255" placeholder="E-mail" value="<?= shield_h($form['financeiro_email']); ?>"></div>
                </div>

                <div class="mb-3">
                    <label for="cnpj_representante" class="form-label">CNPJ do representante</label>
                    <input type="text" id="cnpj_representante" name="cnpj_representante" class="form-control"
                           value="<?= shield_h($form['cnpj_representante']); ?>" maxlength="18"
                           placeholder="em branco se n&atilde;o houver">
                </div>

            </div>
        </div>
    </div>

    <div class="col-xl-5 coluna-empilhada">

        <div class="card numero<?= $adicionalTotal > 0 ? ' faixa-atencao' : ''; ?>">
            <div class="rotulo">Al&eacute;m da mensalidade</div>
            <div class="valor num">R$ <?= shield_dinheiro($adicionalTotal); ?></div>
            <div class="nota">
                <?php if ($adicionalTotal === 0): ?>
                    Este cliente paga s&oacute; o plano.
                <?php else: ?>
                    <?php if ($adicionalModulos > 0): ?>m&oacute;dulos R$ <?= shield_dinheiro($adicionalModulos); ?><?php endif; ?>
                    <?php if ($adicionalModulos > 0 && $adicionalTerminais > 0): ?> &middot; <?php endif; ?>
                    <?php if ($adicionalTerminais > 0): ?>m&aacute;quinas R$ <?= shield_dinheiro($adicionalTerminais); ?><?php endif; ?>
                    <br>Entra na pr&oacute;xima cobran&ccedil;a do ciclo.
                <?php endif; ?>
            </div>
        </div>

        <div class="card" data-tour="contrato-licenca">
            <div class="card-header">Licen&ccedil;a</div>
            <div class="card-body">
                <div class="mb-3">
                    <label for="validade_licenca" class="form-label">V&aacute;lida at&eacute;</label>
                    <?php /* TRAVADA POR PADRAO (10/09/2026, tarde): a validade anda pelo pagamento.
                             Mexer a mao e excecao, e pede destravar de proposito. */ ?>
                    <input type="date" id="validade_licenca" name="validade_licenca" class="form-control" readonly
                           value="<?= shield_h($form['validade_licenca']); ?>">
                    <div class="form-check mt-1">
                        <input class="form-check-input" type="checkbox" id="destravarValidade"
                               onchange="var v=document.getElementById('validade_licenca'); v.readOnly=!this.checked; if(this.checked){v.focus();}">
                        <label class="form-check-label small" for="destravarValidade">Ajustar &agrave; m&atilde;o (a validade normalmente anda sozinha, quando o cliente paga)</label>
                    </div>
                    <small class="form-text text-muted">
                        Em branco limpa a validade. O ERP guarda a licen&ccedil;a por at&eacute;
                        <?= (int) (defined('SHIELD_LICENCA_CARENCIA_DIAS') ? SHIELD_LICENCA_CARENCIA_DIAS : 7); ?>
                        dias, ent&atilde;o mudar aqui leva at&eacute; esse tempo para chegar na loja.
                    </small>
                </div>

                <label class="form-label">Acesso</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="bloqueado" id="bloqueadoNao" value="N" <?= ($form['bloqueado'] !== 'S') ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="bloqueadoNao">Liberado</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="bloqueado" id="bloqueadoSim" value="S" <?= ($form['bloqueado'] === 'S') ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="bloqueadoSim">Bloqueado</label>
                </div>
                <small class="form-text text-muted">
                    Bloqueio manual &eacute; para o que n&atilde;o &eacute; d&iacute;vida &mdash; fraude, troca de
                    CNPJ, lit&iacute;gio. Atraso de pagamento quem trata &eacute; a
                    <a href="/regua.php">r&eacute;gua</a>. Marcar Liberado num cliente suspenso tira a suspens&atilde;o tamb&eacute;m.
                </small>
            </div>
        </div>

        <div class="card">
            <div class="card-body d-flex gap-2 justify-content-end">
                <a href="ver_empresa.php?id=<?= urlencode((string) $id); ?>" class="btn btn-secondary btn-sm">Cancelar</a>
                <button type="submit" class="btn btn-primary btn-sm">Salvar</button>
            </div>
        </div>
    </div>
</div>

</form>

<script>
// CEP pelo ViaCEP, do navegador do membro (o mesmo do fechamento).
function fechCep(texto) {
  var cep = String(texto || '').replace(/\D/g, '');
  var nota = document.getElementById('cepNota');
  if (cep.length !== 8) { return; }
  nota.textContent = 'buscando...';
  fetch('https://viacep.com.br/ws/' + cep + '/json/').then(function (r) { return r.json(); }).then(function (d) {
    if (!d || d.erro) { nota.textContent = 'CEP nao encontrado; preencha a mao'; return; }
    var poe = function (id, v) { var el = document.getElementById(id); if (el && v) { el.value = v; } };
    poe('endereco', d.logradouro); poe('bairro', d.bairro); poe('cidade', d.localidade); poe('uf', d.uf);
    nota.textContent = 'endereco preenchido pelo CEP; confira o numero';
  }).catch(function () { nota.textContent = 'sem resposta do ViaCEP; preencha a mao'; });
}
</script>
<?php include __DIR__ . '/../../templates/fecha.php'; ?>
