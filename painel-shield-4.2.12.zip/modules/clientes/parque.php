<?php
/**
 * Parque - 25/08/2026.
 *
 * O dado desta tela ja chegava e era jogado fora. Cada instalacao bate no
 * painel a cada 18 horas dizendo quem e, em que maquina esta e em qual versao
 * do ERP -- e o painel sobrescrevia o registro anterior.
 *
 * Ela responde tres perguntas que hoje se responde ligando para o cliente:
 *
 *   QUEM PAROU DE DAR SINAL. Terminal parado e loja parada ou maquina morta.
 *   O membro fica sabendo antes de o cliente ligar.
 *
 *   QUEM ESTA EM QUAL VERSAO. E quem nunca atualiza -- que e quem abre chamado
 *   por defeito ja corrigido.
 *
 *   QUANTOS CAIXAS DE VERDADE contra quantos foram contratados. Este numero e
 *   RECEITA, nao suporte: cliente rodando cinco e pagando dois aparece sozinho.
 *
 * NAO e a tela de Terminais. Aquela e cadastro -- quais maquinas existem, quem
 * apagar. Esta e sinal vital: quem esta vivo, ha quanto tempo, em que versao.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/parque.php';
require_once __DIR__ . '/../../funcoes/licenca/situacao.php';
require_once __DIR__ . '/../../templates/contexto_cliente.php';

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

// Sem cron garantido na hospedagem do membro, quem dispara a poda do historico
// e quem abre a tela. Ela sai no maximo uma vez por dia.
shield_parque_compactar($pdo);

$situacao = (string) ($_GET['situacao'] ?? '');
$versaoFiltro = (string) ($_GET['versao'] ?? '');
$empresaFiltro = shield_empresa_contexto_id($_GET) ?? 0;
$empresaSelecionada = null;
if ($empresaFiltro > 0) {
    $stmtEmpresa = $pdo->prepare('SELECT codigo, razao FROM empresa WHERE codigo = :codigo LIMIT 1');
    $stmtEmpresa->execute(array(':codigo' => $empresaFiltro));
    $empresaSelecionada = $stmtEmpresa->fetch(PDO::FETCH_ASSOC) ?: null;
    if (!$empresaSelecionada) {
        $empresaFiltro = 0;
    }
}

$erro = '';
$resumo = array();
$versoes = array();
$terminais = array();
$recusas = array();

try {
    $resumo = shield_parque_resumo($pdo, array('empresa' => $empresaFiltro));
    $versoes = shield_parque_versoes($pdo, array('empresa' => $empresaFiltro));
    $terminais = shield_parque_terminais($pdo, array(
        'situacao' => $situacao,
        'versao' => $versaoFiltro,
        'empresa' => $empresaFiltro,
    ));
    $recusas = shield_parque_recusas($pdo, 7, 30, $empresaFiltro);
} catch (Throwable $e) {
    $erro = $e->getMessage();
}

// Vazio de PRIMEIRA VEZ e vazio POR FILTRO sao estados diferentes e pedem
// textos diferentes: um ensina o proximo passo, o outro oferece tirar o filtro.
// A empresa e o ESCOPO da tela, nao um filtro dela: cliente sem terminal
// nenhum nao esta "sem resultado por causa do filtro", esta sem terminal --
// e oferecer "ver todos" ali leva a uma tela igualmente vazia.
$semFiltro = ($situacao === '' && $versaoFiltro === '');

$corteSumido = strtotime('-' . SHIELD_PARQUE_DIAS_SUMIDO . ' days');

// A versao MAIS NOVA primeiro, sempre. A consulta ordena por quantidade, o que
// responde "qual versao domina" -- mas quem abre esta tela quer saber quem ja
// esta na ultima e quem ficou para tras, e nessa leitura a ordem por
// quantidade esconde a versao nova justamente quando ela e nova (poucos
// terminais). A reordenacao e aqui, e nao na consulta, por dois motivos: a
// funcao serve outras telas, e `version_compare` sabe que 3.0.10 vem depois de
// 3.0.9, coisa que ORDER BY sobre texto nao sabe.
usort($versoes, function ($a, $b) {
    $va = (string) $a['versao'];
    $vb = (string) $b['versao'];
    // "(nao informada)" nao e versao: vai para o fim, nunca para o topo.
    $ia = $va === '' || $va[0] < '0' || $va[0] > '9';
    $ib = $vb === '' || $vb[0] < '0' || $vb[0] > '9';
    if ($ia !== $ib) {
        return $ia ? 1 : -1;
    }

    return version_compare($vb, $va);
});

$escopo = $empresaSelecionada !== null;

?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>


<div class="topo-tela">
    <div>
        <div class="trilha">
            <a href="/clientes.php">Clientes</a><span>/</span>
            <?php if ($escopo): ?>
                <a href="/ver_empresa.php?id=<?= (int) $empresaFiltro; ?>"><?= shield_h((string) $empresaSelecionada['razao']); ?></a><span>/</span>
            <?php endif; ?>
            <span>Monitoramento</span>
        </div>
        <h1 class="h4 mb-1">Monitoramento do parque</h1>
        <p class="text-secondary small mb-0">
            Sinal, vers&atilde;o e uso da cota. Sem sinal h&aacute; mais de
            <?= (int) SHIELD_PARQUE_DIAS_SUMIDO; ?> dias vira alerta &mdash; e isso n&atilde;o
            libera uma vaga de licen&ccedil;a de imediato.
        </p>
    </div>
    <div class="acoes-pagina">
        <a href="<?= shield_h(shield_voltar_cliente((int) $empresaFiltro)); ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i>Voltar
        </a>
    </div>
</div>

<?php if ($escopo): ?>
    <?php /* A barra "Cliente em foco" saiu em 10/09/2026: a trilha e a lateral ja dizem onde se esta. */ ?>
<?php endif; ?>

<?php if ($erro !== ''): ?>
    <div class="alert alert-danger">Falha ao ler o parque: <?= shield_h($erro); ?></div>
<?php endif; ?>

<div class="row g-3 mb-3" data-tour="parque-numeros">
    <div class="col-6 col-xl-3">
        <a class="indicador ok" href="<?= shield_h(shield_url_com_empresa('/parque.php', $empresaFiltro, array('situacao' => 'vivo'))); ?>">
            <i class="fas fa-broadcast-tower fundo"></i>
            <div class="rotulo">Terminais vivos</div>
            <div class="valor"><?= (int) ($resumo['vivos'] ?? 0); ?><span class="parte">/<?= (int) ($resumo['terminais'] ?? 0); ?></span></div>
            <div class="nota">deram sinal nos &uacute;ltimos <?= (int) SHIELD_PARQUE_DIAS_SUMIDO; ?> dias</div>
        </a>
    </div>
    <div class="col-6 col-xl-3">
        <a class="indicador <?= ((int) ($resumo['sumidos'] ?? 0)) > 0 ? 'erro' : 'ok'; ?>"
           href="<?= shield_h(shield_url_com_empresa('/parque.php', $empresaFiltro, array('situacao' => 'sumido'))); ?>">
            <i class="fas fa-exclamation-triangle fundo"></i>
            <div class="rotulo">Sem sinal</div>
            <div class="valor"><?= (int) ($resumo['sumidos'] ?? 0); ?></div>
            <div class="nota">
                <?= ((int) ($resumo['sumidos'] ?? 0)) > 0 ? 'loja parada ou m&aacute;quina trocada' : 'todas responderam'; ?>
            </div>
        </a>
    </div>
    <div class="col-6 col-xl-3">
        <div class="indicador marca">
            <i class="fas fa-layer-group fundo"></i>
            <div class="rotulo">Vers&otilde;es no parque</div>
            <div class="valor"><?= (int) ($resumo['versoes'] ?? 0); ?></div>
            <div class="nota">
                <?php if (!empty($versoes)): ?>
                    a mais nova &eacute; a <?= shield_h((string) $versoes[0]['versao']); ?>
                <?php else: ?>
                    nenhum terminal registrado
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="indicador <?= ((int) ($resumo['excedentes'] ?? 0)) > 0 ? 'venda' : ''; ?>">
            <i class="fas fa-shopping-cart fundo"></i>
            <div class="rotulo">Caixas al&eacute;m do contratado</div>
            <div class="valor"><?= (int) ($resumo['excedentes'] ?? 0); ?></div>
            <div class="nota"><?= (int) ($resumo['contratados'] ?? 0); ?> contratados no total</div>
        </div>
    </div>
</div>

<div class="row g-3">
    <?php /* As maquinas vem primeiro: e a resposta da tela. As versoes sao
             recorte, e recorte fica do lado, nao na frente. */ ?>
    <div class="col-12">
        <?php
        /* AGRUPADO POR CLIENTE, como em Terminais (10/09/2026, tarde): a lista
           corrida de maquinas de todo mundo nao se lia. Dentro de um cliente,
           a tabela e uma so. A linha e uma funcao para as duas listas serem a
           mesma. */
        $filtrosParque = '<div class="btn-group btn-group-sm" role="group" aria-label="Filtro de situacao">'
            . '<a href="' . shield_h(shield_url_com_empresa('/parque.php', $empresaFiltro)) . '" class="btn btn-outline-secondary ' . ($situacao === '' ? 'active' : '') . '">Todos</a>'
            . '<a href="' . shield_h(shield_url_com_empresa('/parque.php', $empresaFiltro, array('situacao' => 'vivo'))) . '" class="btn btn-outline-secondary ' . ($situacao === 'vivo' ? 'active' : '') . '">Vivos</a>'
            . '<a href="' . shield_h(shield_url_com_empresa('/parque.php', $empresaFiltro, array('situacao' => 'sumido'))) . '" class="btn btn-outline-secondary ' . ($situacao === 'sumido' ? 'active' : '') . '">Sem sinal</a>'
            /* O recorte que a Central abre pelo "Ver quem" (11/09/2026). Sem o
               botao aqui, quem chegava pelo link nao via em que filtro estava. */
            . '<a href="' . shield_h(shield_url_com_empresa('/parque.php', $empresaFiltro, array('situacao' => 'excedente'))) . '" class="btn btn-outline-secondary ' . ($situacao === 'excedente' ? 'active' : '') . '">Acima da cota</a>'
            . '</div>';
        $cabecalhoParque = static function () {
            /* A SITUACAO SAIU DO CANTO (14/09/2026). Com `width:1%` a coluna
               encolhia ate a pilula e a encostava na borda direita, com o vao
               todo no meio da tabela. As tres colunas do meio dividem a
               largura por igual, e como todo grupo tem as mesmas quatro,
               cada coluna fica no mesmo lugar em todos os grupos abertos. */
            echo '<thead><tr><th scope="col">M&aacute;quina</th><th scope="col" class="meio" style="width:20%">Vers&atilde;o</th>'
                . '<th scope="col" class="meio" style="width:20%">&Uacute;ltimo sinal</th><th scope="col" class="meio" style="width:20%">Situa&ccedil;&atilde;o</th></tr></thead>';
        };
        $linhaParque = static function (array $t) use ($corteSumido) {
            $visto = trim((string) ($t['ULTIMO_ACESSO'] ?? ''));
            $sumido = ($visto === '') || (strtotime($visto) < $corteSumido);
            echo '<tr><td class="identidade" data-r="M&aacute;quina"><div><span class="nome">' . shield_h((string) ($t['NOME_COMPUTADOR'] ?? '')) . '</span>'
                . '<span class="apoio">' . shield_h((string) ($t['MAC'] ?? '')) . '</span></div></td>'
                . '<td class="meio" data-r="Vers&atilde;o">' . shield_h((string) ($t['VERSAO_EXE'] ?? '')) . '</td>'
                . '<td class="meio" data-r="&Uacute;ltimo sinal">' . shield_h(shield_parque_ha_quanto($visto)) . '</td>'
                . '<td class="meio text-nowrap" data-r="Situa&ccedil;&atilde;o"><span class="pilula pilula-' . ($sumido ? 'erro' : 'ok') . ' text-nowrap">' . ($sumido ? 'sem sinal' : 'vivo') . '</span></td></tr>';
        };
        $gruposParque = array();
        foreach ($terminais as $t) {
            $k = (string) ($t['FK_EMPRESA'] ?? $t['fk_empresa'] ?? $t['razao'] ?? '');
            if (!isset($gruposParque[$k])) {
                $gruposParque[$k] = array('razao' => (string) ($t['razao'] ?? 'sem cliente'), 'cnpj' => (string) ($t['cnpj'] ?? ''), 'linhas' => array(), 'vivos' => 0);
            }
            $gruposParque[$k]['linhas'][] = $t;
            $visto = trim((string) ($t['ULTIMO_ACESSO'] ?? ''));
            if ($visto !== '' && strtotime($visto) >= $corteSumido) {
                $gruposParque[$k]['vivos']++;
            }
        }
        ?>
        <?php /* Sem `mb-3` (14/09/2026): o `g-3` da linha ja separa os cartoes, e as
                 duas margens somadas davam o dobro do vao das outras telas. */ ?>
        <div class="card" data-tour="parque-lista">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                <span>M&aacute;quinas monitoradas</span>
                <?= $filtrosParque; ?>
            </div>
            <?php if (empty($terminais)): ?>
                <div class="card-body p-0"><div class="vazio"><i class="fas fa-desktop"></i>
                    <?php if ($semFiltro): ?>
                        Nenhum terminal deu sinal ainda. A m&aacute;quina aparece aqui sozinha quando o ERP abrir com a licen&ccedil;a assinada ligada.
                    <?php else: ?>
                        Nenhum terminal com este filtro. <a href="<?= shield_h(shield_url_com_empresa('/parque.php', $empresaFiltro)); ?>">Ver todos</a>.
                    <?php endif; ?>
                </div></div>
            <?php elseif ($escopo): ?>
                <div class="table-responsive"><table class="lista folga"><?php $cabecalhoParque(); ?><tbody>
                    <?php foreach ($terminais as $t) { $linhaParque($t); } ?>
                </tbody></table></div>
            <?php else: ?>
                <div class="card-body p-2">
                <div class="grupos-terminais">
                <?php foreach ($gruposParque as $k => $g): ?>
                    <?php $total = count($g['linhas']); $sumidos = $total - $g['vivos']; ?>
                    <details class="card grupo-terminais">
                        <summary>
                            <span class="grupo-nome"><i class="fas fa-building"></i> <?= shield_h($g['razao']); ?>
                                <?php if ($g['cnpj'] !== ''): ?><span class="apoio ms-2 num"><?= shield_h(shield_cnpj($g['cnpj'])); ?></span><?php endif; ?></span>
                            <span class="grupo-resumo">
                                <?php if ($g['vivos'] > 0): ?><span class="pilula pilula-ok"><?= (int) $g['vivos']; ?> viva<?= $g['vivos'] == 1 ? '' : 's'; ?></span><?php endif; ?>
                                <?php if ($sumidos > 0): ?><span class="pilula pilula-erro"><?= $sumidos; ?> sem sinal</span><?php endif; ?>
                                <span class="grupo-total num"><?= $total; ?> m&aacute;quina<?= $total == 1 ? '' : 's'; ?></span>
                                <i class="fas fa-sort-down grupo-seta"></i>
                            </span>
                        </summary>
                        <div class="table-responsive"><table class="lista folga"><?php $cabecalhoParque(); ?><tbody>
                            <?php foreach ($g['linhas'] as $t) { $linhaParque($t); } ?>
                        </tbody></table></div>
                    </details>
                <?php endforeach; ?>
                </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="col-12">
        <?php /* VERSOES DO ERP embaixo, na largura toda: e uma contagem geral do parque, nao uma coluna ao lado. */ ?>
        <div class="card" data-tour="parque-versoes">
            <div class="card-header">Vers&otilde;es do ERP nos terminais</div>
            <div class="card-body p-0">
                <?php if (empty($versoes)): ?>
                    <div class="vazio"><i class="fas fa-layer-group"></i> Nenhum terminal registrado ainda.</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <?php /* "Ultimo sinal" no centro (14/09/2026), como na tabela das maquinas
                                 logo acima: a direita ele era a unica coluna da tela alinhada por
                                 outra regra. */ ?>
                        <table class="lista folga">
                            <thead><tr><th scope="col">Vers&atilde;o</th><th scope="col" class="meio" style="width:20%">Terminais</th><th scope="col" class="meio" style="width:20%">&Uacute;ltimo sinal</th></tr></thead>
                            <tbody>
                            <?php foreach ($versoes as $i => $v): ?>
                                <tr>
                                    <td class="identidade" data-r="Vers&atilde;o"><div class="d-flex align-items-center gap-2 flex-wrap">
                                        <a class="nome" href="<?= shield_h(shield_url_com_empresa('/parque.php', $empresaFiltro, array('versao' => (string) $v['versao']))); ?>"><?= shield_h((string) $v['versao']); ?></a>
                                        <?php if ($i === 0 && $v['versao'] !== '(nao informada)'): ?><span class="pilula pilula-ok">mais nova</span><?php endif; ?>
                                    </div></td>
                                    <td class="meio" data-r="Terminais"><?= (int) $v['terminais']; ?></td>
                                    <td class="meio" data-r="&Uacute;ltimo sinal"><?= shield_h(shield_parque_ha_quanto($v['visto'] ?? '')); ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="card mt-3" data-tour="parque-recusados">
    <div class="card-header">Pedidos recusados nos &uacute;ltimos 7 dias</div>
    <div class="card-body p-0">
        <?php if (empty($recusas)): ?>
            <div class="vazio">
                <i class="fas fa-check-circle"></i>
                Nenhum pedido de licen&ccedil;a foi recusado na semana.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="lista folga">
                    <thead>
                        <tr>
                            <th scope="col">Quando</th>
                            <th scope="col">Cliente</th>
                            <th scope="col">M&aacute;quina</th>
                            <th scope="col">Motivo</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($recusas as $r): ?>
                        <tr>
                            <td class="text-nowrap" data-r="Quando"><?= shield_h(date('d/m H:i', strtotime((string) $r['batido_em']))); ?></td>
                            <td class="identidade" data-r="Cliente">
                                <div>
                                    <span class="nome"><?= shield_h((string) ($r['razao'] ?? '')); ?></span>
                                    <span class="apoio"><?= shield_h(shield_cnpj((string) $r['cnpj'])); ?></span>
                                </div>
                            </td>
                            <td data-r="M&aacute;quina"><?= shield_h((string) ($r['nome_computador'] ?? '')); ?></td>
                            <td data-r="Motivo">
                                <span class="pilula pilula-atencao"><?= shield_h((string) $r['resultado']); ?></span>
                                <?= shield_h((string) ($r['motivo'] ?? '')); ?>
                                <?php if ((int) ($r['quantas'] ?? 1) > 1): ?>
                                    <span class="text-secondary">(<?= (int) $r['quantas']; ?>x)</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
