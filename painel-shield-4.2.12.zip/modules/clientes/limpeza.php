<?php
/**
 * Limpeza de cadastros: quem chegou pelo auto-cadastro, nunca comprou e nao da
 * sinal ha SHIELD_LIMPEZA_DIAS dias.
 *
 * A REGRA MORA EM funcoes/empresa/limpeza.php (17/09/2026): quem e candidata e o
 * apagar, que passa por shield_excluir_empresa e grava no livro o que saiu. Esta
 * tela dava o proprio DELETE, e era o ultimo apagar do painel sem rastro.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/situacao.php';   // shield_cnpj
require_once __DIR__ . '/../../funcoes/empresa/limpeza.php';

$aviso = '';
$erro = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $r = shield_limpeza_apagar($pdo, (array) ($_POST['codigo'] ?? []));
    if ($r['erro'] !== '') {
        $erro = $r['erro'];
    } elseif ($r['apagadas'] > 0) {
        $aviso = $r['apagadas'] . ' empresa(s) removida(s), com os terminais delas.'
            . ($r['fora'] > 0 ? ' ' . $r['fora'] . ' marcada(s) ja nao se qualificava(m) e ficou(aram).' : '');
    } elseif ($r['fora'] > 0) {
        $erro = 'As empresas marcadas ja nao se qualificam para limpeza.';
    } else {
        $erro = 'Nenhuma empresa marcada.';
    }
}

$candidatas = shield_limpeza_candidatas($pdo);
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <h1 class="h4 mb-1">Limpeza de cadastros</h1>
        <p class="text-secondary small mb-0">
            Quem chegou pelo cadastro autom&aacute;tico, nunca comprou e n&atilde;o d&aacute; sinal h&aacute; mais de
            <?= SHIELD_LIMPEZA_DIAS; ?> dias. Quem ainda d&aacute; sinal <strong>n&atilde;o aparece</strong> &mdash; est&aacute; testando.
        </p>
    </div>
    <div class="acoes-pagina">
        <a href="/avaliacao.php" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-hourglass-half me-1"></i>Ver quem est&aacute; em avalia&ccedil;&atilde;o
        </a>
    </div>
</div>

<?php shield_aviso_flutuante($aviso); ?>
<?php if ($erro !== ''): ?>
    <div class="alert alert-danger"><?= shield_h($erro); ?></div>
<?php endif; ?>

<form method="post" id="formLimpeza">
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <span>Candidatas &agrave; limpeza</span>
        <span class="text-secondary small fw-normal"><?= count($candidatas); ?> empresa<?= count($candidatas) == 1 ? '' : 's'; ?></span>
    </div>
    <div class="table-responsive">
        <table class="lista">
            <thead>
                <tr>
                    <th scope="col" style="width:1%" class="meio">
                        <input type="checkbox" class="form-check-input" id="todas" title="Marcar todas" <?= $candidatas === [] ? 'disabled' : ''; ?>>
                    </th>
                    <th scope="col">Empresa</th>
                    <th scope="col" class="meio">M&aacute;quinas</th>
                    <th scope="col" class="meio">Chegou em</th>
                    <th scope="col" class="meio">&Uacute;ltimo sinal</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($candidatas === []): ?>
                <tr>
                    <td colspan="5" class="sem-rotulo">
                        <div class="vazio">
                            <i class="fas fa-broom"></i>
                            Nada a limpar. Nenhuma empresa sem licen&ccedil;a passou de <?= SHIELD_LIMPEZA_DIAS; ?> dias sem dar sinal.
                        </div>
                    </td>
                </tr>
            <?php endif; ?>
            <?php foreach ($candidatas as $c):
                $cidade = trim((string) $c['cidade'] . ($c['cidade'] && $c['uf'] ? '/' : '') . (string) $c['uf']);
                $diasSemSinal = !empty($c['visto']) ? (int) ((time() - strtotime((string) $c['visto'])) / 86400) : null;
            ?>
                <tr>
                    <td class="meio sem-rotulo">
                        <input type="checkbox" class="form-check-input" name="codigo[]" value="<?= (int) $c['codigo']; ?>"
                               aria-label="Marcar <?= shield_h((string) $c['razao']); ?>">
                    </td>
                    <td class="identidade" data-r="Empresa">
                        <div>
                            <a class="nome d-inline" href="/ver_empresa.php?id=<?= (int) $c['codigo']; ?>"><?= shield_h((string) ($c['razao'] ?: '(sem razao social)')); ?></a>
                            <?php if (!empty($c['encerrado_em'])): ?>
                                <span class="pilula pilula-neutro ms-1" style="vertical-align: middle"
                                      title="encerrado em <?= shield_h(date('d/m/Y', strtotime((string) $c['encerrado_em']))); ?> por <?= shield_h((string) ($c['encerrado_por'] ?? '')); ?><?= trim((string) ($c['encerrado_motivo'] ?? '')) !== '' ? ' -- ' . shield_h((string) $c['encerrado_motivo']) : ''; ?>">encerrada</span>
                            <?php endif; ?>
                            <span class="apoio">
                                <?= shield_h(shield_cnpj((string) $c['cnpj'])); ?>
                                <?= $cidade !== '' ? '&middot; ' . shield_h($cidade) : ''; ?>
                            </span>
                        </div>
                    </td>
                    <td class="meio" data-r="M&aacute;quinas"><?= (int) $c['maquinas']; ?></td>
                    <td class="meio" data-r="Chegou em"><?= $c['data'] ? date('d/m/Y', strtotime((string) $c['data'])) : '&mdash;'; ?></td>
                    <td class="meio" data-r="&Uacute;ltimo sinal">
                        <?php if (empty($c['visto'])): ?>
                            <span class="pilula pilula-erro">nunca deu sinal</span>
                        <?php else: ?>
                            <?= date('d/m/Y', strtotime((string) $c['visto'])); ?>
                            <span class="apoio d-block">h&aacute; <?= $diasSemSinal; ?> dias</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if ($candidatas !== []): ?>
        <div class="card-body border-top py-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
            <span class="small text-secondary">
                Apaga o cadastro e os terminais. Se o cliente voltar um dia, ele se cadastra de novo
                como instala&ccedil;&atilde;o nova &mdash; nada fica bloqueado.
            </span>
            <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modalLimpar" id="btLimpar" disabled>
                <i class="fas fa-trash me-1"></i>Remover as marcadas <span class="pilula pilula-neutro ms-1" id="qtMarcadas">0</span>
            </button>
        </div>
    <?php endif; ?>
</div>

<div class="modal fade" id="modalLimpar" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title h6 mb-0">Remover cadastros</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <p class="mb-1">Remover <strong id="modalQt">0</strong> empresa(s) e os terminais delas?</p>
                <p class="small text-secondary mb-0">N&atilde;o h&aacute; como desfazer. Quem voltar se cadastra de novo pelo ERP.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash me-1"></i>Remover</button>
            </div>
        </div>
    </div>
</div>
</form>

<script>
(function () {
  var todas = document.getElementById('todas');
  var caixas = document.querySelectorAll('input[name="codigo[]"]');
  var bt = document.getElementById('btLimpar'), qt = document.getElementById('qtMarcadas'), mq = document.getElementById('modalQt');
  function contar() {
    var n = 0;
    caixas.forEach(function (c) { if (c.checked) { n++; } });
    if (bt) { bt.disabled = n === 0; qt.textContent = n; mq.textContent = n; }
  }
  if (todas) {
    todas.addEventListener('change', function () {
      caixas.forEach(function (c) { c.checked = todas.checked; });
      contar();
    });
  }
  caixas.forEach(function (c) { c.addEventListener('change', contar); });
  contar();
}());
</script>
<?php include __DIR__ . '/../../templates/fecha.php'; ?>
