<?php
/**
 * Ficha do cliente - 25/08/2026.
 *
 * TUDO NUMA PAGINA: quem e, licenca, terminais, cobrancas, o que ficou
 * combinado e os logs que ele mandou.
 *
 * E isso que a tela existe para resolver. Quando o telefone toca, o membro nao
 * quer navegar por cinco telas para juntar o quadro: ele quer ver, de uma vez,
 * se a licenca esta valendo, se ha algo em aberto, se os caixas dele estao
 * dando sinal e o que foi combinado da ultima vez.
 *
 * A ordem dos blocos e a ordem das perguntas: primeiro o que decide se o
 * sistema dele abre, depois dinheiro, depois maquina, depois historia.
 *
 * NENHUM BLOCO INVENTA CONTA PROPRIA. Cada um le da mesma funcao que a tela
 * dedicada usa -- ficha que conta diferente da tela que ela abre e o defeito
 * que a Central de Notificacoes do ERP ja pagou.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/parque.php';
require_once __DIR__ . '/../../funcoes/planos/ciclo.php';       // shield_plano_ciclo_rotulo
require_once __DIR__ . '/../../funcoes/cobranca/assinatura.php';  // shield_assinatura_por_mes
require_once __DIR__ . '/../../funcoes/licenca/situacao.php';
require_once __DIR__ . '/../../funcoes/licenca/area_cliente.php';   // o link que o cliente abre
require_once __DIR__ . '/../../funcoes/cobranca/cobranca_motor.php';
require_once __DIR__ . '/../../funcoes/notificacao/comando_erp.php';
require_once __DIR__ . '/../../funcoes/licenca/certificado.php'; // certificado digital informado pelo ERP
require_once __DIR__ . '/../../funcoes/licenca/confianca.php';   // liberacao em confianca aberta
require_once __DIR__ . '/../../funcoes/contrato/contrato.php';   // o contrato e o aceite (01/10/2026)
require_once __DIR__ . '/../../templates/contexto_cliente.php';

if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    header('Location: /clientes.php');
    exit;
}

$id = (int) $_GET['id'];
$erro = '';
$aviso = '';
// A decisao da promessa diz ate quando a loja trabalha, e o pedido de log diz
// quando ele chega: dez segundos no canto, e nao cinco (funcoes/ui/aviso.php).
$avisoDemorado = false;

// Pedir o log daqui e o caminho curto: o membro esta olhando a ficha do cliente
// que ligou, e a alternativa e ir ate outra tela e procura-lo de novo.
// ENCERRAR / REABRIR -- 10/09/2026, fatia 5. Marca reversivel; nada e apagado.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array((string) ($_POST['acao'] ?? ''), array('encerrar', 'reabrir'), true)) {
    require_once __DIR__ . '/../../funcoes/licenca/encerramento.php';
    $ator = (string) ($_SESSION['usuario']['nome'] ?? $_SESSION['usuario']['login'] ?? '');
    $codigoAcao = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
    if (($_POST['acao'] ?? '') === 'encerrar') {
        shield_empresa_encerrar($pdo, $codigoAcao, $ator, (string) ($_POST['motivo'] ?? ''));
    } else {
        shield_empresa_reabrir($pdo, $codigoAcao, $ator);
    }
    header('Location: /ver_empresa.php?id=' . $codigoAcao);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'promessa') {
    // O PEDIDO DE PRAZO que veio do ERP (ou da area do cliente): aceitar ou
    // recusar. Aceito, o token da proxima batida vale ate a data; recusado,
    // o ERP mostra "nao foi aceito" por tres dias.
    try {
        $decisao = shield_promessa_decidir($pdo, (int) ($_POST['promessa'] ?? 0), ($_POST['decisao'] ?? '') === 'aceitar',
            (string) ($_SESSION['usuario']['nome'] ?? $_SESSION['usuario']['login'] ?? ''));
        $avisoDemorado = true;
        $aviso = shield_promessa_frase($pdo, (int) ($_POST['promessa'] ?? 0), $decisao);
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'area_senha_reset') {
    // RESETAR A SENHA DA AREA (10/09/2026, tarde): o painel sorteia, mostra
    // uma vez, o membro manda ao cliente. Vale 30 dias e obriga a troca no
    // primeiro acesso. A senha inicial continua sendo a do fechamento.
    try {
        $senhaNova = shield_area_senha_resetar($pdo, $id);
        shield_auditar($pdo, 'area_senha_resetada', array('alvo_tipo' => 'empresa', 'alvo_id' => (int) $id,
            'ator' => (string) ($_SESSION['usuario']['nome'] ?? ''), 'detalhe' => 'senha temporaria da area do cliente sorteada (vale 30 dias)'));
        $avisoArea = $senhaNova;
    } catch (Throwable $e) {
        $erroArea = $e->getMessage();
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'pedir_log') {
    try {
        shield_comando_pedir_log($pdo, (int) ($_POST['terminal'] ?? 0),
                                 date('Y-m-d', strtotime('-2 days')), date('Y-m-d'));
        $avisoDemorado = true;
        $aviso = 'Log pedido. Ele chega na pr&oacute;xima vez que aquela m&aacute;quina '
            . 'abrir o sistema &mdash; at&eacute; 18 horas.';
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
}

try {
    $stmt = $pdo->prepare('SELECT * FROM empresa WHERE codigo = :id LIMIT 1');
    $stmt->execute(array(':id' => $id));
    $empresa = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!is_array($empresa)) {
        header('Location: /clientes.php?status=nao_encontrada');
        exit;
    }

    $terminais = shield_parque_terminais($pdo, array('empresa' => $id));

    $stmt = $pdo->prepare(
        'SELECT * FROM cobranca WHERE fk_empresa = :id ORDER BY vencimento DESC LIMIT 12'
    );
    $stmt->execute(array(':id' => $id));
    $cobrancas = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();

    $stmt = $pdo->prepare(
        'SELECT a.*, e.razao, p.descricao AS plano_nome, c.apelido AS conta_apelido
           FROM assinatura a
           LEFT JOIN empresa e ON e.codigo = a.fk_empresa
           LEFT JOIN planos p ON p.id = a.fk_plano
           LEFT JOIN conta_recebimento c ON c.id = a.fk_conta
          WHERE a.fk_empresa = :id ORDER BY a.id DESC LIMIT 3'
    );
    $stmt->execute(array(':id' => $id));
    $assinaturas = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();

    $stmt = $pdo->prepare(
        'SELECT * FROM validade_movimento WHERE fk_empresa = :id ORDER BY quando DESC LIMIT 8'
    );
    $stmt->execute(array(':id' => $id));
    $movimentos = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();

    $stmt = $pdo->prepare(
        'SELECT l.*, t.NOME_COMPUTADOR, t.APELIDO FROM log_capturado l
           LEFT JOIN terminais t ON t.CODIGO = l.fk_terminal
          WHERE l.fk_empresa = :id ORDER BY l.chegou_em DESC LIMIT 5'
    );
    $stmt->execute(array(':id' => $id));
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
} catch (Throwable $e) {
    $erro = $e->getMessage();
    $empresa = $empresa ?? array();
    $terminais = $terminais ?? array();
    $cobrancas = $cobrancas ?? array();
    $assinaturas = $assinaturas ?? array();
    $movimentos = $movimentos ?? array();
    $logs = $logs ?? array();
}

$validade = trim((string) ($empresa['validade_licenca'] ?? ''));

// A FICHA NAO REFAZ CONTA NENHUMA -- 10/09/2026, fatia 1 da
// reorganizacao. Situacao, caixas vivos, "renova sozinho" e o que o cliente
// deve saem das MESMAS funcoes que a lista de clientes usa. Antes esta tela
// tinha um laco proprio para os vivos, um SQL proprio para o em aberto e
// decidia bloqueio/suspensao por conta propria: o mesmo cliente podia sair de
// um jeito na lista e de outro aqui, e quem conferia era o membro.
$sit = shield_situacao_licenca($empresa, isset(shield_renovam_sozinho($pdo, array($id))[$id]));
$bloqueado = $sit['chave'] === 'bloqueado';
$suspenso = $sit['chave'] === 'suspenso';
$contratados = (int) ($empresa['nterminais'] ?? 0);
// NULL e "ninguem gravou" e zero e "sem limite" (14/09/2026): as duas liberam
// todas as maquinas hoje, mas so a primeira herda a cota do teste no primeiro
// pagamento (funcoes/licenca/validade.php). "/0" nas duas escondia a diferenca.
$cotaVazia = ($empresa['nterminais'] ?? null) === null;
$vivos = (int) (shield_parque_vivos_por_empresa($pdo, array($id))[$id] ?? 0);
// So para pintar cada linha da lista de maquinas como "vivo" / "sem sinal";
// o NUMERO de vivos ja veio da funcao acima.
$corte = strtotime('-' . SHIELD_PARQUE_DIAS_SUMIDO . ' days');

// QUEM DIZ A COR DO PARQUE E A FUNCAO, e nao este arquivo -- 09/09/2026.
// O cartao logo abaixo refazia a comparacao a mao e, no estouro,
// escrevia `faixa-ok`: a tarja de SUCESSO justamente no caso em que a funcao
// manda `atencao`. O mesmo cliente saia laranja na lista e verde aqui.
//
// E a mesma licao que o cartao de Licenca ja tinha aprendido tres blocos
// abaixo, com 10 dias contra 15. Quem confere uma tela contra a outra e o
// membro, e ele nao tem como saber qual das duas esta certa.
// A COTA DO TESTE ENTRA AQUI TAMBEM, pelo mesmo motivo do paragrafo acima: a
// lista passou a medir o lead em avaliacao pela cota do teste (11/09/2026), e
// ficha que medisse por outra coisa recriaria a divergencia.
$cfgTeste = shield_teste_config($pdo);
$cotaTeste = shield_teste_vigente($empresa, $cfgTeste) ? shield_teste_terminais_de($empresa, $cfgTeste) : 0;
$parque = shield_situacao_parque($vivos, $contratados, $cotaTeste);

// Traduz a cor da situacao para a tarja do cartao. Usado pelos dois cartoes que
// mostram situacao: Licenca e Caixas.
$faixa = array('ok' => '', 'atencao' => '-atencao', 'erro' => '-erro',
               'neutro' => '', 'venda' => '-atencao');

// O saldo devedor sai de uma consulta PROPRIA, e nao da soma das cobrancas
// mostradas logo abaixo -- aquela lista traz so as 12 mais recentes, e um
// cliente com 15 titulos teria as antigas em aberto fora da conta. A lista de
// clientes soma todas; se aqui somasse 12, as duas telas discordariam sobre o
// mesmo cliente, que e o defeito que a Central de Notificacoes do ERP pagou.
$emAberto = (int) (shield_cobranca_em_aberto_por_empresa($pdo, array($id))[$id] ?? 0);

$corSituacao = array(
    SHIELD_COB_PAGA => 'ok', SHIELD_COB_VENCIDA => 'erro',
    SHIELD_COB_ABERTA => 'atencao', SHIELD_COB_RASCUNHO => 'neutro',
    SHIELD_COB_CANCELADA => 'neutro', SHIELD_COB_ESTORNADA => 'atencao',
);
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <div class="trilha"><a href="/clientes.php">Clientes</a><span>/</span><span>Vis&atilde;o do cliente</span></div>
        <h1 class="h4 mb-1"><?= shield_h((string) ($empresa['razao'] ?? 'Cliente')); ?></h1>
        <p class="text-secondary small mb-0 num">
            <?= shield_h(shield_cnpj((string) ($empresa['cnpj'] ?? ''))); ?>
            <?php if (!empty($empresa['cidade'])): ?>
                &middot; <?= shield_h((string) $empresa['cidade']); ?>/<?= shield_h((string) ($empresa['uf'] ?? '')); ?>
            <?php endif; ?>
        </p>
    </div>
    <?php
    // Nenhum destino do cliente mora aqui em cima: todos vivem na barra logo
    // abaixo, inclusive editar. Botao repetido nos dois lugares ensina que um
    // dos dois faz outra coisa.
    ?>
    <div class="acoes-pagina">
        <a href="<?= shield_h(shield_voltar_cliente(0)); ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i>Voltar
        </a>
    </div>
</div>

<?php /* A barra "Visao 360" saiu da ficha em 10/09/2026: repetia os icones da
         lista, e cada cartao daqui ja tem o seu "gerenciar" / "ver todas".
         Nas outras telas do cliente ela fica, porque la e o unico caminho. */ ?>

<?php /* Sucesso flutua no canto e some sozinho (funcoes/ui/aviso.php). A senha
         sorteada da area, mais abaixo, NAO: aparece uma vez e e para copiar. */ ?>
<?php if (($_GET['ok'] ?? '') === 'assinatura'): ?>
    <?php /* Demorado: diz QUANDO a mudanca vale, e nao so que gravou. */ ?>
    <?php shield_aviso_flutuante('Assinatura alterada. Vale a partir do pr&oacute;ximo PIX.', 'ok', true); ?>
<?php endif; ?>
<?php if (($_GET['ok'] ?? '') === 'cadastrado'): ?>
    <?php /* Veio da tela de cadastrar cliente (16/09/2026). Demorado porque diz o
             passo que falta: a loja existe, mas ainda nao tem licenca nem contrato. */ ?>
    <?php shield_aviso_flutuante(
        'Cliente cadastrado. Ele ainda n&atilde;o tem licen&ccedil;a: quando a loja instalar o ERP com este CNPJ,'
        . ' ela cai neste cadastro. Para cobrar, d&ecirc; in&iacute;cio ao contrato.',
        'ok',
        true
    ); ?>
<?php endif; ?>
<?php shield_aviso_flutuante($aviso, '', $avisoDemorado); ?>
<?php if ($erro !== ''): ?>
    <div class="alert alert-danger"><?= shield_h($erro); ?></div>
<?php endif; ?>

<?php $promessaPendente = shield_promessa_pendente($pdo, $id); ?>
<?php if ($promessaPendente !== null): ?>
    <?php /* O PEDIDO DE PRAZO PENDENTE vem antes de tudo: e uma pessoa esperando resposta. */ ?>
    <div class="card mb-3" style="border-left: .28rem solid var(--atencao)">
        <div class="card-body d-flex align-items-center flex-wrap gap-3">
            <div class="flex-grow-1">
                <strong><i class="fas fa-hourglass-half me-1" style="color: var(--atencao)"></i>Pedido de prazo:</strong>
                o cliente pede para pagar at&eacute; <strong><?= shield_h(date('d/m/Y', strtotime((string) $promessaPendente['ate']))); ?></strong>
                <?php if (trim((string) ($promessaPendente['quem_pediu'] ?? '')) !== ''): ?>(pedido por <?= shield_h((string) $promessaPendente['quem_pediu']); ?>)<?php endif; ?>
                <?php if (trim((string) ($promessaPendente['motivo'] ?? '')) !== ''): ?><span class="d-block small text-secondary">&ldquo;<?= shield_h((string) $promessaPendente['motivo']); ?>&rdquo;</span><?php endif; ?>
                <span class="d-block small text-secondary">Aceitando, a licen&ccedil;a vale at&eacute; l&aacute; e a cobran&ccedil;a continua em aberto. Nada muda no cadastro.</span>
            </div>
            <form method="post" action="/ver_empresa.php?id=<?= $id; ?>" class="d-flex gap-2">
                <input type="hidden" name="acao" value="promessa">
                <input type="hidden" name="promessa" value="<?= (int) $promessaPendente['id']; ?>">
                <button class="btn btn-sm btn-primary" name="decisao" value="aceitar"><i class="fas fa-check me-1"></i>Aceitar</button>
                <button class="btn btn-sm btn-outline-secondary" name="decisao" value="recusar"><i class="fas fa-times me-1"></i>Recusar</button>
            </form>
        </div>
    </div>
<?php endif; ?>

<div class="row g-3 mb-4" data-tour="ficha-numeros">
    <div class="col-6 col-xl-3">
        <?php /* $sit vem de cima: o MESMO funil da lista de clientes. Antes este
                 cartao usava 10 dias e a lista 15, e o mesmo cliente saia laranja
                 numa tela e verde na outra. */ ?>
        <?php
        // Na lista de clientes o detalhe E a data, porque la nao ha outro
        // lugar que a mostre. Aqui a data ja e o numero grande do cartao, e
        // repeti-la logo abaixo so faz o membro ler duas vezes a mesma coisa.
        $dataLicenca = $validade !== '' ? date('d/m/Y', strtotime($validade)) : '';
        $detalhe = trim((string) $sit['detalhe']);
        if ($dataLicenca !== '' && strpos($detalhe, $dataLicenca) !== false) {
            $detalhe = '';
        }
        ?>
        <div class="card numero faixa<?= $faixa[$sit['cor']]; ?>">
            <div class="rotulo">Licen&ccedil;a</div>
            <div class="valor num"><?= $dataLicenca !== '' ? shield_h($dataLicenca) : '&mdash;'; ?></div>
            <div class="nota">
                <span class="pilula pilula-<?= $sit['cor']; ?>"><?= $sit['rotulo']; ?></span>
                <?= $detalhe !== '' ? ' ' . $detalhe : ''; ?>
                <?php
                // O certificado digital, informado pelo ERP na batida (10/09/2026).
                // Dentro do cartao da licenca porque e a mesma pergunta do membro
                // ("o que vai parar nesta loja?"), e nao um quinto cartao.
                $cert = shield_certificado_situacao($empresa['certificado_vence'] ?? null);
                ?>
                <?php if ($cert['dias'] !== null): ?>
                    <?php
                    // A ULTIMA RENOVACAO (08/10/2026): o livro guarda a data de antes,
                    // e e ela que responde "ele renovou ou so mudou de certificado?".
                    $renovacoes = shield_certificado_renovacoes($pdo, $id, 1);
                    ?>
                    <span class="d-block mt-1">
                        certificado digital:
                        <span class="pilula pilula-<?= $cert['cor']; ?>"><?= shield_h($cert['rotulo']); ?></span>
                        <?php if ($renovacoes): ?>
                            <span class="text-secondary small">&middot; renovado em <?= shield_h(date('d/m/Y', strtotime((string) $renovacoes[0]['quando']))); ?>
                                (antes vencia em <?= shield_h(date('d/m/Y', strtotime((string) $renovacoes[0]['antes']))); ?>)</span>
                        <?php endif; ?>
                    </span>
                <?php endif; ?>
                <?php
                // A liberacao em confianca / promessa de pagamento aberta: e o
                // unico lugar onde ela aparece para gente, e o membro precisa
                // saber por que a loja esta abrindo com a validade vencida.
                $promessaAberta = shield_promessa_aberta($pdo, $id);
                ?>
                <?php if ($promessaAberta !== null): ?>
                    <span class="d-block mt-1" style="color: var(--atencao)">
                        <i class="fas fa-check-circle"></i>
                        liberado em confian&ccedil;a at&eacute; <?= shield_h(date('d/m/Y', strtotime((string) $promessaAberta['ate']))); ?>
                        <?= trim((string) ($promessaAberta['quem_pediu'] ?? '')) !== '' ? '(pedido por ' . shield_h((string) $promessaAberta['quem_pediu']) . ')' : ''; ?>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="card numero faixa<?= $faixa[$parque['cor']]; ?>">
            <div class="rotulo">Caixas dando sinal</div>
            <div class="valor num"><?= $vivos; ?><span class="text-muted h6">/<?= $contratados > 0 ? $contratados : ($cotaTeste > 0 ? $cotaTeste : ($cotaVazia ? '&mdash;' : '0')); ?></span></div>
            <div class="nota">
                <?php /* O total cadastrado sai SEMPRE, e nao so quando esta
                        dentro da cota: era justamente no estouro que ele sumia
                        da tela, e e ali que o membro precisa dele para saber
                        quantas maquinas existem contra quantas deram sinal. */ ?>
                <?php if ($contratados > 0 && $vivos > $contratados): ?>
                    <?= $vivos - $contratados; ?> al&eacute;m do contratado &middot;
                <?php elseif ($contratados === 0 && $cotaTeste > 0): ?>
                    <?php /* Sem contrato o numero de baixo e a cota do teste, e
                            a tela tem de dizer isso: "1/3" sozinho parece
                            contrato. */ ?>
                    <?= shield_h($parque['nota']); ?> &middot;
                <?php elseif ($cotaVazia): ?>
                    quantidade contratada n&atilde;o informada &middot;
                <?php elseif ($contratados === 0): ?>
                    zero contratado libera todas &middot;
                <?php endif; ?>
                <?= count($terminais); ?> m&aacute;quina(s) cadastrada(s)
            </div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="card numero faixa<?= $emAberto > 0 ? '-atencao' : ''; ?>">
            <div class="rotulo">Em aberto</div>
            <div class="valor num">R$ <?= shield_h(shield_dinheiro($emAberto)); ?></div>
            <div class="nota">soma do que n&atilde;o foi pago</div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <?php $encerrado = $sit['chave'] === 'encerrado'; ?>
        <div class="card numero faixa<?= ($bloqueado || $suspenso) ? '-erro' : ($encerrado ? '' : '-ok'); ?>">
            <div class="rotulo">Situa&ccedil;&atilde;o</div>
            <div class="valor">
                <?php if ($encerrado): ?>
                    <span class="pilula pilula-neutro">encerrado</span>
                <?php elseif ($suspenso): ?>
                    <span class="pilula pilula-erro">suspenso</span>
                <?php elseif ($bloqueado): ?>
                    <span class="pilula pilula-erro">bloqueado</span>
                <?php else: ?>
                    <span class="pilula pilula-ok">ativo</span>
                <?php endif; ?>
            </div>
            <div class="nota">
                <?php if ($encerrado): ?>
                    <?php /* ENCERRADO E MARCA (fatia 5): o cadastro esta aqui, a licenca
                             nao sai. Apagar de verdade e na Limpeza, com gente conferindo. */ ?>
                    em <?= shield_h(date('d/m/Y', strtotime((string) $empresa['encerrado_em']))); ?>
                    por <?= shield_h((string) ($empresa['encerrado_por'] ?? '')); ?>
                    <?= trim((string) ($empresa['encerrado_motivo'] ?? '')) !== '' ? '&middot; ' . shield_h((string) $empresa['encerrado_motivo']) : ''; ?>
                    <form method="post" action="/ver_empresa.php?id=<?= $id; ?>" class="mt-1">
                        <input type="hidden" name="acao" value="reabrir">
                        <button class="btn btn-sm btn-outline-secondary"><i class="fas fa-arrow-left me-1"></i>Reabrir</button>
                    </form>
                <?php elseif ($suspenso): ?>
                    <?= shield_h((string) ($empresa['suspenso_motivo'] ?? '')); ?>
                    &middot; vale na loja desde
                    <?= shield_h(date('d/m/Y', strtotime(shield_validade_quando_vale($empresa['suspenso_em'])))); ?>
                <?php elseif ($bloqueado): ?>
                    bloqueio manual
                <?php else: ?>
                    nada impedindo
                <?php endif; ?>
                <?php if (!$encerrado): ?>
                    <?php /* ENCERRAR e marca reversivel (fatia 5): tira da fila e para
                             a licenca na hora, sem apagar nada. Apagar de verdade
                             continua na Limpeza, com gente conferindo. */ ?>
                    <form method="post" action="/ver_empresa.php?id=<?= $id; ?>" class="mt-1"
                          onsubmit="return confirm('Encerrar este cliente? A licença para de sair na hora. Nada é apagado, e dá para reabrir aqui mesmo.');">
                        <input type="hidden" name="acao" value="encerrar">
                        <input type="hidden" name="motivo" value="encerrado pela ficha">
                        <button class="btn btn-sm btn-outline-secondary" title="Marca como encerrado; nada e apagado">
                            <i class="fas fa-times-circle me-1"></i>Encerrar
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php /* A AREA DO CLIENTE (10/09/2026, tarde): o mesmo link que o ERP recebe na
         resposta da licenca. Copiar e mandar pelo WhatsApp e o caminho para
         quem nao tem o botao no ERP ainda. O link e FIXO e e desta loja: o
         cliente guarda um so. */ ?>
<?php $linkArea = shield_area_url((int) $id); ?>
<?php if ($linkArea !== ''): ?>
<?php
// O primeiro telefone PREENCHIDO: com `??`, um financeiro_fone vazio ('')
// ganhava do telefone da loja e o botao sumia.
$foneArea = '';
foreach (array('financeiro_fone', 'responsavel_fone', 'fone') as $campoFone) {
    if (trim((string) ($empresa[$campoFone] ?? '')) !== '') {
        $foneArea = (string) $empresa[$campoFone];
        break;
    }
}
$zapArea = shield_whatsapp_url($foneArea, 'Ola! Aqui esta a sua area do cliente, com a licenca e as cobrancas: ' . $linkArea);
?>
<div class="card mb-3" data-tour="ficha-area">
    <div class="card-body py-2 d-flex align-items-center flex-wrap gap-2">
        <span class="small text-secondary" style="min-width: 9rem"><i class="fas fa-link me-1"></i>&Aacute;rea do cliente</span>
        <input type="text" class="form-control form-control-sm flex-grow-1" style="min-width: 16rem" id="linkArea" value="<?= shield_h($linkArea); ?>" readonly onfocus="this.select()">
        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="navigator.clipboard.writeText(document.getElementById('linkArea').value).then(function(){ this.innerText='Copiado'; }.bind(this))"><i class="fas fa-copy me-1"></i>Copiar</button>
        <a class="btn btn-sm btn-outline-secondary" target="_blank" rel="noopener" href="<?= shield_h($linkArea); ?>"><i class="fas fa-external-link-alt me-1"></i>Abrir</a>
        <?php if ($zapArea !== null): ?>
            <a class="btn btn-sm btn-outline-secondary" target="_blank" rel="noopener" href="<?= shield_h($zapArea); ?>">Mandar no WhatsApp</a>
        <?php endif; ?>
        <span class="small text-secondary w-100">Link fixo deste cliente: ele guarda e volta quando quiser. V&ecirc; a licen&ccedil;a, as m&aacute;quinas e todas as faturas com o PIX; avisa que pagou e pede prazo. O ERP recebe o mesmo link.</span>
        <?php /* A ENTRADA POR SENHA: e-mail da loja + senha definida aqui ou no fechamento. */ ?>
        <form method="post" action="/ver_empresa.php?id=<?= $id; ?>" class="d-flex align-items-center flex-wrap gap-2 w-100"
              onsubmit="return confirm('Sortear uma senha nova para a área do cliente? A senha atual deixa de valer. A nova vale 30 dias e o cliente troca no primeiro acesso.');">
            <input type="hidden" name="acao" value="area_senha_reset">
            <button class="btn btn-sm btn-outline-secondary"><i class="fas fa-key me-1"></i>Resetar senha</button>
            <span class="small text-secondary"><?= trim((string) ($empresa['email'] ?? '')) !== '' ? 'entra com <strong>' . shield_h((string) $empresa['email']) . '</strong>' : '<span style="color: var(--atencao)">sem e-mail da loja no cadastro: preencha para o cliente poder entrar</span>'; ?>
                &middot; senha <?= !empty($empresa['area_senha']) ? (!empty($empresa['area_senha_temporaria']) ? 'tempor&aacute;ria at&eacute; ' . shield_h(date('d/m/Y', strtotime((string) $empresa['area_senha_vence']))) : 'definida') : 'ainda n&atilde;o definida'; ?></span>
            <?php if (!empty($erroArea)): ?><span class="small" style="color: var(--erro)"><?= shield_h($erroArea); ?></span><?php endif; ?>
        </form>
        <?php if (!empty($avisoArea)): ?>
            <?php $zapSenha = shield_whatsapp_url($foneArea, 'Ola! Sua area do cliente: ' . $linkArea . "\nE-mail: " . (string) ($empresa['email'] ?? '') . "\nSenha temporaria: " . $avisoArea . "\nEla vale 30 dias; no primeiro acesso voce escolhe a sua."); ?>
            <div class="alert alert-success w-100 mb-0">
                <div>Senha tempor&aacute;ria: <strong class="num" id="senhaTemp"><?= shield_h($avisoArea); ?></strong>. Vale 30 dias; o cliente troca no primeiro acesso.</div>
                <div class="d-flex align-items-center flex-wrap gap-2 mt-2">
                    <strong>Copie agora: ela n&atilde;o aparece de novo.</strong>
                    <button type="button" class="btn btn-sm btn-outline-secondary" onclick="navigator.clipboard.writeText(document.getElementById('senhaTemp').innerText).then(function(){ this.innerText='Copiada'; }.bind(this))"><i class="fas fa-copy me-1"></i>Copiar</button>
                    <?php if ($zapSenha !== null): ?>
                        <a class="btn btn-sm btn-outline-secondary" target="_blank" rel="noopener" href="<?= shield_h($zapSenha); ?>">Mandar no WhatsApp</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<div class="row g-3 ficha-quatro">
    <div class="col-xl-6">
        <div class="card h-100 rola-lista">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Terminais</span>
                <a href="<?= shield_h(shield_url_com_empresa('/terminais.php', $id)); ?>" class="small">gerenciar</a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($terminais)): ?>
                    <div class="vazio">
                        <p class="mb-1"><strong>Nenhuma m&aacute;quina deu sinal ainda.</strong></p>
                        <p class="mb-0 small">
                            Assim que o ERP dele abrir com a licen&ccedil;a assinada ligada, a
                            m&aacute;quina aparece aqui sozinha.
                        </p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                    <table class="lista">
                        <thead><tr>
                            <th scope="col">M&aacute;quina</th>
                            <th scope="col" class="meio">Vers&atilde;o</th>
                            <th scope="col" class="meio">&Uacute;ltimo sinal</th>
                            <th scope="col" class="meio" style="width:1%">Log</th>
                        </tr></thead>
                        <tbody>
                        <?php foreach ($terminais as $t): ?>
                            <?php
                            $visto = trim((string) ($t['ULTIMO_ACESSO'] ?? ''));
                            $sumido = ($visto === '') || (strtotime($visto) < $corte);
                            ?>
                            <tr>
                                <td class="identidade par" data-r="M&aacute;quina">
                                    <div>
                                        <?php /* O apelido na frente, o nome de fabrica atras -- a mesma
                                                 regra da tela de terminais (shield_terminal_rotulo). */ ?>
                                        <span class="nome"><?= shield_h(shield_terminal_rotulo($t)); ?></span>
                                        <span class="pilula pilula-<?= $sumido ? 'erro' : 'ok'; ?>">
                                            <?= $sumido ? 'sem sinal' : 'vivo'; ?>
                                        </span>
                                        <?php if (shield_terminal_maquina_atras($t) !== ''): ?>
                                            <span class="apoio d-block"><?= shield_h(shield_terminal_maquina_atras($t)); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="meio" data-r="Vers&atilde;o"><?= shield_h((string) ($t['VERSAO_EXE'] ?? '')); ?></td>
                                <td class="meio" data-r="&Uacute;ltimo sinal"><?= shield_h(shield_parque_ha_quanto($visto)); ?></td>
                                <td class="meio" data-r="Log">
                                    <?php if (!empty($t['log_pedido_de'])): ?>
                                        <span class="pilula pilula-neutro acao-log">pedido</span>
                                    <?php else: ?>
                                        <form method="post" action="/ver_empresa.php?id=<?= $id; ?>" class="d-inline">
                                            <input type="hidden" name="acao" value="pedir_log">
                                            <input type="hidden" name="terminal" value="<?= (int) $t['CODIGO']; ?>">
                                            <button class="btn btn-sm btn-outline-secondary acao-log"
                                                    title="O log chega na proxima abertura desta maquina">
                                                pedir
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-xl-6">
        <?php
        // MONITORAMENTO NA FICHA (10/09/2026, tarde): o mesmo recorte da tela de
        // Monitoramento, so para esta loja. Calculado do que a ficha ja tem.
        $corteVivo = strtotime('-3 days');
        $vivosFicha = 0; $caladasFicha = 0; $versoesFicha = array(); $ultimoSinalFicha = '';
        foreach ($terminais as $tf) {
            $visto = trim((string) ($tf['ULTIMO_ACESSO'] ?? ''));
            if ($visto !== '' && strtotime($visto) >= $corteVivo) { $vivosFicha++; } else { $caladasFicha++; }
            $vf = trim((string) ($tf['VERSAO_EXE'] ?? ''));
            if ($vf !== '') { $versoesFicha[$vf] = ($versoesFicha[$vf] ?? 0) + 1; }
            if ($visto !== '' && ($ultimoSinalFicha === '' || $visto > $ultimoSinalFicha)) { $ultimoSinalFicha = $visto; }
        }
        krsort($versoesFicha, SORT_NATURAL);
        ?>
        <div class="card h-100 rola-lista">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Monitoramento</span>
                <a href="<?= shield_h(shield_url_com_empresa('/parque.php', $id)); ?>" class="small">ver o parque</a>
            </div>
            <div class="card-body">
                <?php if (empty($terminais)): ?>
                    <div class="vazio"><i class="fas fa-broadcast-tower"></i> Nenhuma m&aacute;quina deu sinal ainda.</div>
                <?php else: ?>
                    <?php /* DUAS PERGUNTAS, DUAS LINHAS (10/09/2026, noite): quantas maquinas
                             respondem, e que versao cada uma roda. Antes era um bloco so. */ ?>
                    <div class="row g-2 mb-2 small">
                        <div class="col-4"><div class="text-secondary">Trabalhando</div><div class="h5 mb-0 num" style="color: var(--<?= $vivosFicha > 0 ? 'ok' : 'texto-fraco'; ?>)"><?= $vivosFicha; ?></div></div>
                        <div class="col-4"><div class="text-secondary">Sem sinal</div><div class="h5 mb-0 num" style="color: var(--<?= $caladasFicha > 0 ? 'erro' : 'texto-fraco'; ?>)"><?= $caladasFicha; ?></div></div>
                        <div class="col-4"><div class="text-secondary">&Uacute;ltimo sinal</div><div class="fw-bold"><?= $ultimoSinalFicha !== '' ? shield_h(shield_parque_ha_quanto($ultimoSinalFicha)) : 'nunca'; ?></div></div>
                    </div>
                    <table class="lista">
                        <thead><tr><th scope="col">Vers&atilde;o do ERP</th><th scope="col" class="meio">M&aacute;quinas</th></tr></thead>
                        <tbody>
                        <?php $primeiraV = true; foreach ($versoesFicha as $vf => $qt): ?>
                            <tr>
                                <td data-r="Vers&atilde;o"><span class="num"><?= shield_h((string) $vf); ?></span><?= $primeiraV ? ' <span class="pilula pilula-ok">mais nova</span>' : ''; ?></td>
                                <td class="meio" data-r="M&aacute;quinas"><?= (int) $qt; ?></td>
                            </tr>
                            <?php $primeiraV = false; endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-xl-6">
        <div class="card h-100 rola-lista">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Cobran&ccedil;as</span>
                <a href="<?= shield_h(shield_url_com_empresa('/cobrancas.php', $id, array('situacao' => 'todas'))); ?>" class="small">ver todas</a>
            </div>
            <div class="card-body p-0">
                <?php /* A assinatura era um quinto cartao sozinho na linha (10/09/2026, tarde);
                         virou a primeira linha daqui. Mudar e em Mudar o contrato. */ ?>
                <?php foreach ($assinaturas as $a): if ((string) $a['situacao'] !== 'ativa') { continue; } ?>
                    <div class="small px-3 py-2 border-bottom text-truncate" title="Assinatura: R$ <?= shield_h(shield_dinheiro((int) $a['valor_centavos'])); ?> <?= shield_h(shield_plano_ciclo_rotulo((int) $a['ciclo_meses'])); ?>, todo dia <?= (int) $a['dia_vencimento']; ?>; quem gera o PIX: <?= !empty($a['conta_apelido']) ? shield_h((string) $a['conta_apelido']) : 'ningu&eacute;m (rascunho)'; ?>">
                        <i class="fas fa-sync-alt me-1" style="color: var(--ok)"></i>
                        <strong>Assinatura</strong> &middot; R$ <?= shield_h(shield_dinheiro((int) $a['valor_centavos'])); ?>
                        <?= shield_h(shield_plano_ciclo_rotulo((int) $a['ciclo_meses'])); ?><?= (int) $a['ciclo_meses'] > 1 ? ' (R$ ' . shield_h(shield_dinheiro(shield_assinatura_por_mes($a))) . ' por m&ecirc;s)' : ''; ?>, todo dia <?= (int) $a['dia_vencimento']; ?>
                        &middot; quem gera o PIX: <?= !empty($a['conta_apelido']) ? shield_h((string) $a['conta_apelido']) : 'ningu&eacute;m (rascunho)'; ?>
                    </div>
                <?php endforeach; ?>
                <?php /* O CONTRATO (01/10/2026): logo abaixo da assinatura, porque e o mesmo
                         assunto -- o que foi combinado. So aparece com o aceite ligado e o
                         contrato iniciado; o PDF e o do que foi aceito, ou a minuta. */ ?>
                <?php $contratoFicha = shield_contrato_situacao($pdo, (array) $empresa); ?>
                <?php if ($contratoFicha['aplica']): ?>
                    <div class="small px-3 py-2 border-bottom d-flex justify-content-between align-items-center gap-2">
                        <span class="text-truncate">
                            <?php if (!$contratoFicha['pendente']): ?>
                                <?php $aceitoFicha = strtotime((string) $contratoFicha['aceite']['aceito_em']); ?>
                                <i class="fas fa-check-circle me-1" style="color: var(--ok)"></i>
                                <strong>Contrato</strong> &middot; aceito em <?= date('d/m/Y', $aceitoFicha); ?> &agrave;s <?= date('H:i', $aceitoFicha); ?>
                                <?= (string) $contratoFicha['aceite']['ip'] !== '' ? '&middot; IP ' . shield_h((string) $contratoFicha['aceite']['ip']) : ''; ?>
                            <?php else: ?>
                                <i class="fas fa-hourglass-half me-1" style="color: var(--atencao)"></i>
                                <strong>Contrato</strong> &middot;
                                <?= $contratoFicha['aceite'] !== null ? 'texto mudou, aguardando o aceite de novo' : 'aguardando o aceite do cliente'; ?>
                            <?php endif; ?>
                        </span>
                        <a href="/contrato_pdf.php?empresa=<?= (int) $empresa['codigo']; ?>" target="_blank" class="text-nowrap"
                           title="<?= $contratoFicha['aceite'] !== null ? 'O PDF do que foi aceito' : 'A minuta, com o texto de hoje'; ?>">PDF</a>
                    </div>
                <?php endif; ?>
                <?php if (empty($cobrancas)): ?>
                    <div class="vazio">
                        <i class="fas fa-money-bill-wave"></i>
                        Nenhuma cobran&ccedil;a para este cliente.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                    <table class="lista">
                        <thead><tr>
                            <th scope="col">Descri&ccedil;&atilde;o</th>
                            <th scope="col" class="num">Valor</th>
                            <th scope="col" class="meio">Vence</th>
                            <th scope="col" class="meio" style="width:1%">Situa&ccedil;&atilde;o</th>
                        </tr></thead>
                        <tbody>
                        <?php foreach ($cobrancas as $c): ?>
                            <tr>
                                <td data-r="Descri&ccedil;&atilde;o"><?= shield_h((string) $c['descricao']); ?>
                                    <?php /* O CLIENTE AVISOU QUE PAGOU (pelo ERP ou pela area dele): e aqui que o
                                             membro ve, e vai conferir na tela de cobrancas. Fica na descricao, e nao
                                             na coluna da situacao, que e estreita e quebrava a linha. */ ?>
                                    <?php if (!empty($c['informado_em']) && !in_array((string) $c['situacao'], array('paga', 'cancelada', 'estornada'), true)): ?>
                                        <span class="apoio d-block" style="color: var(--atencao)" title="Confira o pagamento na tela de cobran&ccedil;as"><i class="fas fa-info-circle"></i> avisou que pagou <?= shield_h(date('d/m', strtotime((string) $c['informado_em']))); ?><?= trim((string) ($c['informado_forma'] ?? '')) !== '' ? ' por ' . shield_h((string) $c['informado_forma']) : ''; ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="num" data-r="Valor">R$ <?= shield_h(shield_dinheiro((int) $c['valor_centavos'])); ?></td>
                                <td class="meio" data-r="Vence"><?= shield_h(date('d/m/Y', strtotime((string) $c['vencimento']))); ?></td>
                                <td class="meio" data-r="Situa&ccedil;&atilde;o">
                                    <span class="pilula pilula-<?= $corSituacao[$c['situacao']] ?? 'neutro'; ?>">
                                        <?= shield_h((string) $c['situacao']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-xl-6">
        <div class="card h-100 rola-lista">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Logs que ele mandou</span>
                <a href="<?= shield_h(shield_url_com_empresa('/logs_cliente.php', $id)); ?>" class="small">todos os logs</a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($logs)): ?>
                    <div class="vazio"><i class="fas fa-file-download"></i> Nenhum log recebido ainda. Pe&ccedil;a um em "todos os logs".</div>
                <?php else: ?>
                <div class="table-responsive">
                <table class="lista">
                    <thead><tr>
                        <th scope="col">M&aacute;quina</th>
                        <th scope="col" class="num">Per&iacute;odo</th>
                        <th scope="col" class="num">Chegou</th>
                        <th scope="col" class="meio">A&ccedil;&otilde;es</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($logs as $l): ?>
                        <tr>
                            <td data-r="M&aacute;quina"><?= shield_h(shield_terminal_rotulo($l)); ?></td>
                            <td class="num" data-r="Per&iacute;odo">
                                <?= $l['de'] ? shield_h(date('d/m', strtotime((string) $l['de']))) : '?'; ?>
                                a <?= $l['ate'] ? shield_h(date('d/m', strtotime((string) $l['ate']))) : '?'; ?>
                            </td>
                            <td class="num" data-r="Chegou"><?= shield_h(date('d/m H:i', strtotime((string) $l['chegou_em']))); ?></td>
                            <td class="meio" data-r="A&ccedil;&otilde;es">
                                <span class="acoes">
                                    <a class="acao" title="Ler este log"
                                       href="<?= shield_h(shield_url_com_empresa('/logs_cliente.php', $id, array('ver' => (int) $l['id']))); ?>">
                                        <i class="fas fa-file-download"></i></a>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if ($movimentos): ?>
    <div class="col-xl-6">
        <div class="card h-100">
            <div class="card-header">Hist&oacute;rico da validade</div>
            <div class="card-body p-0">
                <div class="table-responsive">
                <?php /* TUDO NO CENTRO (14/09/2026). As datas alinhavam a direita e o
                         traco do "De" vazio caia longe do cabecalho, parecendo de outra
                         coluna. `num meio` guarda os algarismos de largura fixa do `num`
                         e centraliza, porque `.meio` vem depois no CSS. */ ?>
                <table class="lista">
                    <thead><tr>
                        <th scope="col" class="num meio">Quando</th>
                        <th scope="col" class="num meio">De</th>
                        <th scope="col" class="num meio">Para</th>
                        <th scope="col" class="meio">Quem</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($movimentos as $m): ?>
                        <tr>
                            <td class="num meio" data-r="Quando"><?= shield_h(date('d/m/Y', strtotime((string) $m['quando']))); ?></td>
                            <?php /* O TRACO FICA FORA DO shield_h (14/09/2026). Passado por ele, o
                                     `&mdash;` virava `&amp;mdash;` e a tela escrevia a palavra
                                     "&mdash;" onde devia haver um traco. De vazio e cliente sem
                                     validade antes daquele pagamento. E as datas saem no mesmo
                                     formato do "Quando" ao lado, e nao em ano-mes-dia. */ ?>
                            <td class="num meio" data-r="De"><?= trim((string) ($m['de'] ?? '')) !== ''
                                ? shield_h(date('d/m/Y', strtotime((string) $m['de']))) : '&mdash;'; ?></td>
                            <td class="num meio" data-r="Para"><?= trim((string) ($m['para'] ?? '')) !== ''
                                ? shield_h(date('d/m/Y', strtotime((string) $m['para']))) : '&mdash;'; ?></td>
                            <td class="identidade meio" data-r="Quem">
                                <div>
                                    <span class="nome"><?= shield_h((string) ($m['ator'] ?? '')); ?></span>
                                    <span class="apoio"><?= shield_h((string) ($m['motivo'] ?? '')); ?></span>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

</div>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
