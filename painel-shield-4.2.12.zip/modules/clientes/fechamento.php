<?php
/**
 * O fechamento numa tela so -- 10/09/2026, fatia 7 da reorganizacao
 * (docs/reorganizacao-do-painel.md, secao 5, passo 5).
 *
 * Seis blocos numerados, TODOS VISIVEIS: nao e assistente de paginas, porque
 * numa ligacao o cliente pula de assunto. A conta aparece na hora ("1 fora do
 * plano, R$ 25,00 por mes"). O valor e digitado -- nao precisa de plano
 * cadastrado antes. O botao confere tudo antes de gravar qualquer coisa, e a
 * chave unica no formulario faz F5 nao cadastrar duas vezes.
 *
 * Quem faz e funcoes/empresa/fechamento.php; aqui so se desenha e se le o
 * POST. Cadastrar NAO libera o ERP, e isso esta escrito ao lado do botao.
 *
 * DOIS BOTOES, DUAS COISAS (14/09/2026): "Gravar rascunho" guarda o formulario
 * e a loja continua em avaliacao; so "Dar inicio ao contrato" faz o cliente. A
 * tela reabre com o rascunho, e com contrato ja iniciado nem desenha o
 * formulario: manda para Mudar o contrato.
 *
 * SEM A CAIXA DE EMITIR (14/09/2026, noite): o Dar inicio sempre gera a primeira
 * fatura. A caixa nao fica travada porque o servidor nao le mais o campo, e um
 * checkbox cinza marcado so repetiria o que o bloco 6 ja diz em texto.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/situacao.php';    // shield_cnpj
require_once __DIR__ . '/../../funcoes/empresa/fechamento.php';
require_once __DIR__ . '/../../funcoes/licenca/teste.php';

use Shield\Cobranca\Registro;

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM empresa WHERE codigo = :c LIMIT 1');
$stmt->execute(array(':c' => $id));
$empresa = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$empresa) {
    header('Location: /avaliacao.php');
    exit;
}

$erros = array();
$aviso = '';
$resultado = null;
$ator = (string) ($_SESSION['usuario']['nome'] ?? $_SESSION['usuario']['login'] ?? '');

// O que a tela mostra: comeca com o que o ERP mandou (o cadastro), depois o
// RASCUNHO GUARDADO por cima dos padroes (14/09/2026), depois o que a pessoa
// digitou (o POST que falhou na conferencia).
$n = shield_fechamento_normalizar(array_merge($empresa, array(
    'chave' => bin2hex(random_bytes(16)),
    'nterminais' => max(1, (int) ($empresa['nterminais'] ?? 0) ?: shield_teste_terminais_de($empresa, shield_teste_config($pdo))),
    'terminais_inclusos' => (int) ($empresa['terminais_inclusos'] ?? 0) ?: max(1, (int) ($empresa['nterminais'] ?? 0) ?: shield_teste_terminais_de($empresa, shield_teste_config($pdo))),
    'valor_terminal_centavos' => (int) ($empresa['valor_terminal_centavos'] ?? 0),
    'vencimento' => date('Y-m-d', strtotime('+7 days')),
    'ciclo_meses' => 1, 'meses' => 12,
), shield_fechamento_rascunho_ler($empresa)));

// CONTRATO JA INICIADO NAO REABRE AQUI (14/09/2026). So no GET: o F5 de um
// envio que deu certo ainda precisa chegar a resposta "ja tinha sido gravado".
$recusaInicio = ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' ? shield_fechamento_ja_iniciado($pdo, $empresa) : null;
$avisoRascunho = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $post = $_POST;
    $post['valor_centavos'] = shield_centavos((string) ($post['valor'] ?? ''));
    $post['valor_terminal_centavos'] = shield_centavos((string) ($post['valor_terminal'] ?? ''));
    $n = shield_fechamento_normalizar($post);
    try {
        $erros = shield_fechamento_validar($pdo, $n);
        if ($erros === array()) {
            $resultado = shield_fechamento_gravar($pdo, $id, $n, $ator);
            $aviso = $resultado['aviso'];
            // O RASCUNHO VOLTA PARA O FORMULARIO, preenchido, com o aviso no canto:
            // quem guardou metade da ligacao continua de onde parou. A frase sai do
            // botao clicado, e nao de 'emitida'.
            if (($resultado['salvar'] ?? '') === 'rascunho') {
                $resultado = null;
                $avisoRascunho = 'Rascunho gravado. A loja continua em Em avalia&ccedil;&atilde;o, com o teste valendo, e nada foi ao provedor. Para virar cliente, clique em &quot;Dar in&iacute;cio ao contrato&quot;.'
                    . ($n['area_senha'] !== '' ? ' A senha da &aacute;rea do cliente n&atilde;o fica no rascunho: digite de novo ao dar in&iacute;cio.' : '');
                $relida = $pdo->prepare('SELECT * FROM empresa WHERE codigo = :c LIMIT 1');
                $relida->execute(array(':c' => $id));
                $empresa = $relida->fetch(PDO::FETCH_ASSOC) ?: $empresa;
            }
        }
    } catch (Throwable $e) {
        $erros['geral'] = $e->getMessage();
    }
}

$modulos = $pdo->query('SELECT id, nome, chave, valor_centavos FROM modulo WHERE ativo = 1 ORDER BY nome')->fetchAll(PDO::FETCH_ASSOC) ?: array();
$contas = shield_contas_para_escolher(array_values(array_filter(shield_cobranca_contas($pdo, true), static function ($c) {
    return Registro::para((string) $c['provedor']) !== null;
})));
$previa = shield_fechamento_previa($pdo, $n);
/** Telefone guardado como digitos, mostrado como (00)00000-0000. */
function fech_fone($d)
{
    $d = preg_replace('/\D+/', '', (string) $d);
    if (strlen($d) < 10) {
        return $d;
    }

    return '(' . substr($d, 0, 2) . ')' . substr($d, 2, strlen($d) - 6) . '-' . substr($d, -4);
}
$page_title = 'Fechamento';
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <div class="trilha"><a href="/avaliacao.php">Em avalia&ccedil;&atilde;o</a><span>/</span><span>Fechamento</span></div>
        <h1 class="h4 mb-1">Dar in&iacute;cio ao contrato &mdash; <?= shield_h((string) $empresa['razao']); ?></h1>
        <p class="text-secondary small mb-0 num"><?= shield_h(shield_cnpj((string) $empresa['cnpj'])); ?></p>
        <?php /* DE QUANDO E O RASCUNHO (14/09/2026): e o que diz que a tela abriu preenchida com ele. */ ?>
        <?php if ($resultado === null && trim((string) ($empresa['rascunho_em'] ?? '')) !== ''): ?>
            <p class="text-secondary small mb-0">Rascunho do contrato salvo em <?= shield_h(date('d/m/Y H:i', strtotime((string) $empresa['rascunho_em']))); ?>. A loja continua em avalia&ccedil;&atilde;o at&eacute; o &quot;Dar in&iacute;cio ao contrato&quot;.</p>
        <?php endif; ?>
    </div>
</div>
<?php shield_aviso_flutuante($avisoRascunho, '', true); ?>

<?php if ($resultado !== null): ?>
    <?php /* A FRASE SAI DO BOTAO (14/09/2026). Aqui so chega o Dar inicio -- o rascunho volta para
             o formulario --, e ele faz o cliente com ou sem emissao. Decidir por 'emitida' chamava
             de "rascunho" o contrato cujo provedor caiu, e mandava para um botao verde que saiu. */ ?>
    <div class="card mb-3">
        <div class="card-body">
            <h2 class="h6 mb-2"><i class="fas fa-check-circle me-1" style="color: var(--ok)"></i>
                <?= $resultado['repetido'] ? 'Este fechamento j&aacute; tinha sido gravado.' : 'Contrato iniciado.'; ?></h2>
            <p class="mb-2">
                A loja saiu de &quot;Em avalia&ccedil;&atilde;o&quot; e j&aacute; aparece em Clientes.
                <?php /* O QUE "GERAR A FATURA" FOI, pela conta (14/09/2026, noite): so o gateway fala com
                         provedor; o PIX na chave monta o codigo aqui, e o dinheiro so abre a fatura. */ ?>
                <?php $provedorFatura = (string) (shield_cobranca_conta($pdo, (int) $n['conta'])['provedor'] ?? ''); ?>
                <?php if ($resultado['emitida'] && $provedorFatura === 'dinheiro'): ?>
                    A primeira fatura est&aacute; aberta, a receber no balc&atilde;o: d&ecirc; baixa em Cobran&ccedil;as quando o dinheiro entrar.
                <?php elseif ($resultado['emitida'] && $provedorFatura === 'pix_estatico'): ?>
                    A primeira fatura est&aacute; aberta com o PIX copia e cola na sua chave: mande ao cliente e confirme em Cobran&ccedil;as quando cair no extrato.
                <?php elseif ($resultado['emitida']): ?>
                    A primeira fatura foi emitida no provedor.
                <?php else: ?>
                    <strong>A primeira fatura n&atilde;o saiu</strong> e ficou em rascunho: emita em Cobran&ccedil;as.
                <?php endif; ?>
                <?php if (!empty($n['liberar_agora']) && !$resultado['repetido']): ?>
                    <strong>A licen&ccedil;a j&aacute; vale at&eacute; <?= shield_h(date('d/m/Y', strtotime((string) $n['vencimento']))); ?></strong>, o vencimento da primeira fatura.
                <?php else: ?>
                    <strong>A licen&ccedil;a s&oacute; anda quando o pagamento entrar.</strong>
                <?php endif; ?>
            </p>
            <?php if ($aviso !== ''): ?>
                <div class="alert alert-warning mb-2"><?= shield_h($aviso); ?></div>
            <?php endif; ?>
            <a href="/ver_empresa.php?id=<?= $id; ?>" class="btn btn-sm btn-primary">Abrir a ficha do cliente</a>
            <?php if ($resultado['emitida']): ?>
                <a href="/cobrancas.php?empresa=<?= $id; ?>" class="btn btn-sm btn-outline-secondary">Ver a fatura</a>
            <?php else: ?>
                <a href="/cobrancas.php?empresa=<?= $id; ?>" class="btn btn-sm btn-warning"><i class="fas fa-exclamation-triangle me-1"></i>Emitir a fatura em Cobran&ccedil;as</a>
            <?php endif; ?>
            <a href="/avaliacao.php" class="btn btn-sm btn-outline-secondary">Voltar &agrave; fila</a>
        </div>
    </div>
<?php elseif ($recusaInicio !== null): ?>
    <?php /* Contrato ja iniciado: desenhar o formulario de novo abriria um segundo contrato. */ ?>
    <div class="card mb-3">
        <div class="card-body">
            <p class="mb-2"><?= shield_h($recusaInicio); ?></p>
            <a href="/mudanca_contrato.php?id=<?= $id; ?>" class="btn btn-sm btn-primary">Mudar o contrato</a>
            <a href="/ver_empresa.php?id=<?= $id; ?>" class="btn btn-sm btn-outline-secondary">Abrir a ficha do cliente</a>
        </div>
    </div>
<?php else: ?>

<?php if ($erros !== array()): ?>
    <div class="alert alert-danger">
        <strong>Nada foi gravado.</strong> Confira:
        <ul class="mb-0">
            <?php foreach ($erros as $campo => $msg): ?><li><?= shield_h($msg); ?></li><?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="post" action="/fechamento.php?id=<?= $id; ?>" id="fechamento" autocomplete="off">
    <input type="hidden" name="id" value="<?= $id; ?>">
    <?php /* A CHAVE: o segundo POST com a mesma devolve o que o primeiro fez. */ ?>
    <input type="hidden" name="chave" value="<?= shield_h($n['chave']); ?>">

    <div class="row g-3">
        <div class="col-12">
            <div class="card" data-tour="fech-1"><div class="card-header">1. Cadastro</div><div class="card-body">
                <?php /* Ja preenchido com o que o ERP mandou, agora editavel. */ ?>
                <div class="row g-2">
                    <div class="col-12"><label class="form-label small mb-1" for="razao">Raz&atilde;o social</label>
                        <?php /* RAZAO E CNPJ NAO MUDAM AQUI: sao a identidade que o ERP mandou. Ficam a
                             vista, travados; a razao vai escondida para o POST nao a perder. */ ?>
                        <input class="form-control form-control-sm" id="razao" value="<?= shield_h($n['razao']); ?>" readonly>
                        <input type="hidden" name="razao" value="<?= shield_h($n['razao']); ?>"></div>
                    <div class="col-12"><label class="form-label small mb-1" for="cnpj_visivel">CNPJ</label>
                        <input class="form-control form-control-sm num" id="cnpj_visivel" value="<?= shield_h(shield_cnpj((string) $empresa['cnpj'])); ?>" readonly></div>
                    <div class="col-8"><label class="form-label small mb-1" for="endereco">Endere&ccedil;o</label>
                        <input class="form-control form-control-sm" id="endereco" name="endereco" maxlength="50" value="<?= shield_h($n['endereco']); ?>"></div>
                    <div class="col-4"><label class="form-label small mb-1" for="cep">CEP</label>
                        <input class="form-control form-control-sm num<?= isset($erros['cep']) ? ' is-invalid' : ''; ?>" id="cep" name="cep" maxlength="9" value="<?= shield_h($n['cep']); ?>" placeholder="8 d&iacute;gitos" onblur="fechCep(this.value)">
                        <small class="text-secondary" id="cepNota"></small></div>
                    <div class="col-5"><label class="form-label small mb-1" for="bairro">Bairro</label>
                        <input class="form-control form-control-sm" id="bairro" name="bairro" maxlength="35" value="<?= shield_h($n['bairro']); ?>"></div>
                    <div class="col-5"><label class="form-label small mb-1" for="cidade">Cidade</label>
                        <input class="form-control form-control-sm" id="cidade" name="cidade" maxlength="35" value="<?= shield_h($n['cidade']); ?>"></div>
                    <div class="col-2"><label class="form-label small mb-1" for="uf">UF</label>
                        <input class="form-control form-control-sm" id="uf" name="uf" maxlength="2" value="<?= shield_h($n['uf']); ?>"></div>
                    <div class="col-5"><label class="form-label small mb-1" for="fone">Telefone da loja</label>
                        <input class="form-control form-control-sm num fone" id="fone" name="fone" maxlength="14" placeholder="(00)00000-0000" value="<?= shield_h(fech_fone($n['fone'])); ?>"></div>
                    <div class="col-4"><label class="form-label small mb-1" for="email">E-mail da loja</label>
                        <input type="email" class="form-control form-control-sm<?= isset($erros['email']) ? ' is-invalid' : ''; ?>" id="email" name="email" maxlength="255" value="<?= shield_h($n['email']); ?>"></div>
                    <?php /* A SENHA DA AREA DO CLIENTE (10/09/2026, tarde): o cliente entra na web
                             com o e-mail da loja e esta senha. Vazia, nao mexe na que ja existe. */ ?>
                    <div class="col-3"><label class="form-label small mb-1" for="area_senha">Senha da &aacute;rea do cliente</label>
                        <input type="password" class="form-control form-control-sm<?= isset($erros['area_senha']) ? ' is-invalid' : ''; ?>" id="area_senha" name="area_senha" maxlength="72" autocomplete="new-password"
                               placeholder="<?= !empty($empresa['area_senha']) ? 'j&aacute; definida; digite para trocar' : 'm&iacute;nimo 6'; ?>" title="O cliente entra na &aacute;rea dele com o e-mail da loja e esta senha"></div>
                </div>
            </div></div>
        </div>

        <div class="col-lg-6">
            <div class="card h-100" data-tour="fech-2"><div class="card-header d-flex justify-content-between align-items-center">
                <span>2. Respons&aacute;veis</span>
                <button type="button" class="btn btn-sm btn-outline-secondary" onclick="['nome','fone','email'].forEach(function(c){document.getElementById('financeiro_'+c).value=document.getElementById('responsavel_'+c).value;})">
                    <i class="fas fa-copy me-1"></i>quem assina tamb&eacute;m paga</button>
            </div><div class="card-body">
                <div class="row g-2">
                    <div class="col-12 small text-secondary">Quem assina</div>
                    <div class="col-5"><input class="form-control form-control-sm<?= isset($erros['responsavel_nome']) ? ' is-invalid' : ''; ?>" id="responsavel_nome" name="responsavel_nome" maxlength="255" placeholder="Nome" required value="<?= shield_h($n['responsavel_nome']); ?>"></div>
                    <div class="col-3"><input class="form-control form-control-sm num fone<?= isset($erros['responsavel_fone']) ? ' is-invalid' : ''; ?>" id="responsavel_fone" name="responsavel_fone" maxlength="14" placeholder="(00)00000-0000" required value="<?= shield_h(fech_fone($n['responsavel_fone'])); ?>"></div>
                    <div class="col-4"><input type="email" class="form-control form-control-sm<?= isset($erros['responsavel_email']) ? ' is-invalid' : ''; ?>" id="responsavel_email" name="responsavel_email" maxlength="255" placeholder="E-mail" required value="<?= shield_h($n['responsavel_email']); ?>"></div>
                    <div class="col-12 small text-secondary mt-3">Quem paga (recebe a cobran&ccedil;a)</div>
                    <div class="col-5"><input class="form-control form-control-sm<?= isset($erros['financeiro_nome']) ? ' is-invalid' : ''; ?>" id="financeiro_nome" name="financeiro_nome" maxlength="255" placeholder="Nome" required value="<?= shield_h($n['financeiro_nome']); ?>"></div>
                    <div class="col-3"><input class="form-control form-control-sm num fone<?= isset($erros['financeiro_fone']) ? ' is-invalid' : ''; ?>" id="financeiro_fone" name="financeiro_fone" maxlength="14" placeholder="(00)00000-0000" required value="<?= shield_h(fech_fone($n['financeiro_fone'])); ?>"></div>
                    <div class="col-4"><input type="email" class="form-control form-control-sm<?= isset($erros['financeiro_email']) ? ' is-invalid' : ''; ?>" id="financeiro_email" name="financeiro_email" maxlength="255" placeholder="E-mail" required value="<?= shield_h($n['financeiro_email']); ?>"></div>
                </div>
                <p class="small text-secondary mt-3 mb-0">
                    <strong>Quem assina</strong> &eacute; quem responde pelo contrato: recebe os avisos de licen&ccedil;a e de fim de teste.
                    <strong>Quem paga</strong> recebe a fatura, o PIX e os lembretes da r&eacute;gua. Quase sempre s&atilde;o pessoas diferentes;
                    se for a mesma, o bot&atilde;o acima copia. Telefone com DDD e e-mail v&aacute;lido nos dois: &eacute; por eles que o painel fala com a loja.
                </p>
            </div></div>
        </div>

        <div class="col-lg-6">
            <div class="card h-100" data-tour="fech-3"><div class="card-header">3. O que ele vai contratar</div><div class="card-body">
                <div class="row g-2 align-items-end">
                    <?php /* INCLUSOS PRIMEIRO, DEPOIS OS ADICIONAIS (10/09/2026, noite): o membro pensa
                             "o plano cobre 3, ele quer mais 2", nao "5 no total". nterminais e a soma. */ ?>
                    <div class="col-4"><label class="form-label small mb-1" for="terminais_inclusos">Inclusos no plano</label>
                        <input type="number" min="0" max="99" class="form-control form-control-sm num" id="terminais_inclusos" name="terminais_inclusos" value="<?= (int) $n['terminais_inclusos']; ?>" oninput="fechConta()"></div>
                    <div class="col-4"><label class="form-label small mb-1" for="terminais_adicionais">Terminais adicionais</label>
                        <input type="number" min="0" max="99" class="form-control form-control-sm num" id="terminais_adicionais" name="terminais_adicionais" value="<?= max(0, (int) $n['nterminais'] - (int) $n['terminais_inclusos']); ?>" oninput="fechConta()"></div>
                    <div class="col-4"><label class="form-label small mb-1" for="valor_terminal">Cada terminal fora do plano (R$/m&ecirc;s)</label>
                        <input class="form-control form-control-sm num dinheiro" id="valor_terminal" name="valor_terminal" data-teto="999999" value="<?= shield_h(shield_dinheiro($n['valor_terminal_centavos'])); ?>" oninput="fechConta()"></div>
                </div>
                <?php if ($modulos): ?>
                    <div class="small text-secondary mt-3 mb-1">M&oacute;dulos</div>
                    <?php /* Ate quatro linhas de modulos; dai rola (10/09/2026, noite). */ ?>
                    <div class="row g-1" style="max-height: 7.2rem; overflow-y: auto">
                    <?php foreach ($modulos as $m): ?>
                        <div class="col-6 form-check ms-0 ps-4" style="min-width: 0">
                            <input class="form-check-input" type="checkbox" name="modulos[]" id="mod<?= (int) $m['id']; ?>" value="<?= (int) $m['id']; ?>"
                                   data-centavos="<?= (int) $m['valor_centavos']; ?>" <?= in_array((int) $m['id'], $n['modulos'], true) ? 'checked' : ''; ?> onchange="fechConta()">
                            <label class="form-check-label small d-block" style="overflow-wrap: anywhere" for="mod<?= (int) $m['id']; ?>">
                                <?= shield_h((string) $m['nome']); ?> &middot; R$ <?= shield_h(shield_dinheiro((int) $m['valor_centavos'])); ?>/m&ecirc;s
                                <?= trim((string) ($m['chave'] ?? '')) !== '' ? '<code>' . shield_h((string) $m['chave']) . '</code>' : '<span class="text-secondary">s&oacute; fatura</span>'; ?>
                            </label>
                        </div>
                    <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="small text-secondary mt-3 mb-0">Sem m&oacute;dulos no cat&aacute;logo para ele contratar. <a href="/modulos.php">Criar</a>.</p>
                <?php endif; ?>
            </div></div>
        </div>

        <div class="col-lg-6">
            <div class="card h-100" data-tour="fech-4"><div class="card-header">4. Como ele paga</div><div class="card-body">
                <div class="d-flex gap-3 mb-2">
                    <div class="form-check"><input class="form-check-input" type="radio" name="modo" id="modo_ass" value="assinatura" <?= $n['modo'] === 'assinatura' ? 'checked' : ''; ?> onchange="fechModo()">
                        <label class="form-check-label" for="modo_ass">Assinatura</label></div>
                    <div class="form-check"><input class="form-check-input" type="radio" name="modo" id="modo_pre" value="prepago" <?= $n['modo'] === 'prepago' ? 'checked' : ''; ?> onchange="fechModo()">
                        <label class="form-check-label" for="modo_pre">Pr&eacute;-pago</label></div>
                </div>
                <div class="row g-2 align-items-end">
                    <div class="col-4"><label class="form-label small mb-1" for="valor" id="rotuloValor">Mensalidade (R$)</label>
                        <input class="form-control form-control-sm num dinheiro<?= isset($erros['valor_centavos']) ? ' is-invalid' : ''; ?>" id="valor" name="valor" value="<?= $n['valor_centavos'] > 0 ? shield_h(shield_dinheiro($n['valor_centavos'])) : ''; ?>" placeholder="149,00" oninput="fechConta()"></div>
                    <div class="col-4" id="blocoCiclo"><label class="form-label small mb-1" for="ciclo_meses">A cada</label>
                        <select class="form-select form-select-sm" id="ciclo_meses" name="ciclo_meses" onchange="fechConta()">
                            <?php foreach (shield_plano_ciclos('assinatura') as $mes => $rotulo): ?>
                                <option value="<?= $mes; ?>" <?= $n['ciclo_meses'] === $mes ? 'selected' : ''; ?>><?= shield_h($rotulo); ?></option>
                            <?php endforeach; ?>
                        </select></div>
                    <div class="col-4" id="blocoMeses" hidden><label class="form-label small mb-1" for="meses">Vale por (meses)</label>
                        <?php /* Quatro periodos padrao mais o "+" para digitar qualquer quantidade. */ ?>
                        <div class="d-flex gap-1">
                            <select class="form-select form-select-sm" id="meses_lista" onchange="var l=document.getElementById('meses'); l.hidden=this.value!=='+'; if(this.value!=='+'){l.value=this.value;} fechConta()">
                                <?php foreach (array(1, 3, 6, 12) as $p): ?>
                                    <option value="<?= $p; ?>" <?= $n['meses'] === $p ? 'selected' : ''; ?>><?= $p; ?></option>
                                <?php endforeach; ?>
                                <option value="+" <?= !in_array($n['meses'], array(1, 3, 6, 12), true) ? 'selected' : ''; ?>>outro</option>
                            </select>
                            <input type="number" min="1" max="36" class="form-control form-control-sm num" id="meses" name="meses" value="<?= (int) $n['meses']; ?>" style="width: 5rem" oninput="fechConta()" <?= in_array($n['meses'], array(1, 3, 6, 12), true) ? 'hidden' : ''; ?>>
                        </div></div>
                    <div class="col-4"><label class="form-label small mb-1" for="vencimento" id="rotuloVence">Primeiro vencimento</label>
                        <input type="date" class="form-control form-control-sm<?= isset($erros['vencimento']) ? ' is-invalid' : ''; ?>" id="vencimento" name="vencimento" min="<?= date('Y-m-d'); ?>" value="<?= shield_h($n['vencimento']); ?>"></div>
                </div>
                <?php /* A CONTA NA HORA: base, modulos, terminal fora do plano, total. */ ?>
                <div class="mt-3 small" id="previa">
                    <div class="text-secondary">A cobran&ccedil;a do ciclo sai assim:</div>
                    <div id="previaItens" class="row g-0"></div>
                    <div class="fw-bold">Total: R$ <span id="previaTotal"><?= shield_h(shield_dinheiro($previa['total'])); ?></span><span id="previaPorMes"> por m&ecirc;s</span></div>
                    <div class="text-secondary" id="previaCiclo" hidden>Esse &eacute; o valor de <strong>cada cobran&ccedil;a do ciclo</strong>: <span id="previaPorMesValor"></span> por m&ecirc;s vezes <span id="previaVezes"></span> meses.</div>
                    <div class="text-secondary" id="previaNotaPre" hidden>Pr&eacute;-pago: o acesso vale pelos meses escolhidos <strong>a partir do pagamento</strong>; m&oacute;dulos e terminal fora do plano entram pelo per&iacute;odo inteiro.</div>
                </div>
            </div></div>
        </div>

        <div class="col-lg-6">
            <div class="card h-100" data-tour="fech-5"><div class="card-header">5. Por onde o dinheiro entra</div><div class="card-body">
                <label class="form-label small mb-1" for="conta">Conta de recebimento</label>
                <select class="form-select form-select-sm mb-2<?= isset($erros['conta']) ? ' is-invalid' : ''; ?>" id="conta" name="conta" onchange="fechConta()">
                    <?php /* CONTA OBRIGATORIA (10/09/2026): nao existe "ninguem agora". A opcao vazia so
                             existe para o select nao escolher sozinho; o motor recusa 0. */ ?>
                    <option value="0" disabled <?= $n['conta'] === 0 ? 'selected' : ''; ?>>Escolha a conta&hellip;</option>
                    <?php foreach ($contas as $c): ?>
                        <?php /* O "COBRA POR" DA CONTA, e nao so o que o provedor faz (14/09/2026): o
                                 Asaas faz cartao, mas a conta com cartao desmarcado nao cobra por ele.
                                 A lista e a de shield_conta_formas, a mesma que o servidor confere. */ ?>
                        <?php $prov = Registro::para((string) $c['provedor']); $cap = $prov ? $prov->capacidades($c) : array(); $faz = shield_conta_formas($c); ?>
                        <option value="<?= (int) $c['id']; ?>" <?= $n['conta'] === (int) $c['id'] ? 'selected' : ''; ?>
                                data-pix="<?= in_array('pix', $faz, true) ? 1 : 0; ?>" data-boleto="<?= in_array('boleto', $faz, true) ? 1 : 0; ?>" data-cartao="<?= in_array('cartao', $faz, true) ? 1 : 0; ?>"
                                data-manual="<?= empty($cap['automatico']) ? 1 : 0; ?>" data-dinheiro="<?= (string) $c['provedor'] === 'dinheiro' ? 1 : 0; ?>">
                            <?= shield_h(shield_conta_rotulo($c)); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php /* SO ENTAO aparecem as formas que aquela conta faz. */ ?>
                <div class="d-flex gap-3" id="formas">
                    <?php foreach (array('pix' => 'PIX', 'boleto' => 'Boleto', 'cartao' => 'Cart&atilde;o', 'dinheiro' => 'Dinheiro (voc&ecirc; d&aacute; baixa ao receber)') as $f => $r): ?>
                        <div class="form-check"><input class="form-check-input" type="radio" name="forma" id="forma_<?= $f; ?>" value="<?= $f; ?>" <?= $n['forma'] === $f ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="forma_<?= $f; ?>"><?= $r; ?></label></div>
                    <?php endforeach; ?>
                </div>
                <?php if (isset($erros['forma'])): ?><div class="small" style="color: var(--erro)"><?= shield_h($erros['forma']); ?></div><?php endif; ?>
                <p class="small text-secondary mt-2 mb-0" id="avisoManual" hidden>
                    Esta conta n&atilde;o confirma sozinha: quem d&aacute; baixa &eacute; voc&ecirc;, olhando o extrato.
                </p>
                <?php /* O que cada escolha faz, para o bloco nao ficar mudo (10/09/2026). */ ?>
                <div class="small text-secondary mt-3">
                    <div><strong>Escolhida a conta,</strong> s&oacute; aparecem as formas que ela faz. A primeira fatura sai por ela no &quot;Dar in&iacute;cio ao contrato&quot; (bloco 6).</div>
                    <div><strong>Boleto</strong> pede o CEP do cliente; <strong>PIX</strong> n&atilde;o pede nada.</div>
                </div>
            </div></div>
        </div>

        <div class="col-12">
            <div class="card" data-tour="fech-6"><div class="card-header">6. Primeira cobran&ccedil;a</div><div class="card-body">
                <?php /* A CAIXA DE EMITIR SAIU (14/09/2026, noite): o contrato so comeca gerando a fatura. O
                         que isso e depende da conta, e e o que a frase diz -- nenhuma das tres pode faltar
                         por nao haver provedor do outro lado. */ ?>
                <p class="small mb-2" id="notaFatura">
                    <strong>A primeira fatura sai junto com o in&iacute;cio do contrato</strong>, pela conta do bloco 5.
                    Conta de gateway: o c&oacute;digo &eacute; emitido no provedor. PIX na sua chave: o copia e cola &eacute; montado com a sua chave, e voc&ecirc; confirma pelo extrato.
                    Dinheiro: a fatura fica aberta, a receber no balc&atilde;o. Para guardar sem emitir nada, use <strong>Gravar rascunho</strong>.
                </p>
                <?php /* A CORTESIA DA PRIMEIRA FATURA (11/09/2026). Desmarcada e o
                         comportamento de sempre; marcada, a licenca ja vale ate o
                         vencimento da primeira cobranca. E a UNICA caixa do painel
                         que da licenca sem dinheiro, e por isso ela diz tudo o que
                         faz -- inclusive o que acontece se ele nao pagar. */ ?>
                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox" name="liberar_agora" id="liberar_agora" value="1" <?= !empty($n['liberar_agora']) ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="liberar_agora">
                        Liberar o sistema agora, sem esperar o primeiro pagamento
                    </label>
                </div>
                <p class="small text-secondary mb-3">
                    Marcada, a licen&ccedil;a passa a valer <strong>at&eacute; o vencimento da primeira
                    fatura</strong>: o cliente j&aacute; trabalha e paga depois. Pagando, a validade
                    segue dali e ele n&atilde;o perde dia nenhum; n&atilde;o pagando, ela vence sozinha e a
                    r&eacute;gua assume. Vale <strong>s&oacute; para esta primeira</strong> &mdash; depois disso,
                    quem precisa de prazo pede pela promessa de pagamento.
                </p>
                <p class="small text-secondary mb-3">
                    <strong>Gravar rascunho</strong> guarda o que est&aacute; preenchido e mais nada: a loja continua em
                    avalia&ccedil;&atilde;o com o teste valendo, nada vai ao provedor, a caixa acima n&atilde;o vale e a
                    senha da &aacute;rea do cliente n&atilde;o fica guardada. A tela reabre preenchida pela fila.
                </p>
                <p class="small text-secondary mb-3">
                    <strong>Dar in&iacute;cio ao contrato</strong> confere tudo antes de gravar. Grava cadastro, respons&aacute;veis, contrato,
                    a assinatura (ou o pr&eacute;-pago) e a primeira fatura de uma vez, e <strong>s&oacute; ent&atilde;o</strong>
                    gera a fatura pela conta escolhida. A loja vira cliente na hora e o teste acaba. Se a conta n&atilde;o
                    responder nessa hora, o contrato fica iniciado e a fatura fica em rascunho, com o aviso de onde emitir.
                    Desmarcada a caixa, <strong>cadastrar n&atilde;o libera o ERP</strong>: a licen&ccedil;a s&oacute; anda
                    quando o pagamento entrar.
                </p>
                <?php /* DOIS BOTOES, OS DOIS SEMPRE LIGADOS (14/09/2026). A caixa de emitir apagava um
                         deles porque o rascunho era so "iniciar sem emitir"; agora o rascunho nao faz
                         contrato, e o Dar inicio sempre gera a fatura (a caixa de emitir saiu na mesma noite).
                         FORMNOVALIDATE no rascunho: sem ele o navegador barra o clique pelos `required`
                         dos responsaveis e pelo `min` do vencimento antes de o POST sair. */ ?>
                <div class="d-flex align-items-center gap-2">
                    <a href="/avaliacao.php" class="btn btn-outline-secondary">Voltar &agrave; fila</a>
                    <span class="flex-grow-1"></span>
                    <button type="submit" class="btn btn-outline-primary" id="btRascunho" name="salvar" value="rascunho" formnovalidate><i class="fas fa-save me-1"></i>Gravar rascunho</button>
                    <button type="submit" class="btn btn-primary" id="btIniciar" name="salvar" value="iniciar"><i class="fas fa-file-signature me-1"></i>Dar in&iacute;cio ao contrato</button>
                </div>
            </div></div>
        </div>
    </div>
</form>

<script>
// CEP PELO VIACEP, direto do navegador do membro: o painel nao fala com
// ninguem, e sem internet o campo simplesmente fica como estava.
function fechCep(texto) {
  var cep = String(texto || '').replace(/\D/g, '');
  var nota = document.getElementById('cepNota');
  if (cep.length !== 8) { return; }
  nota.textContent = 'buscando...';
  fetch('https://viacep.com.br/ws/' + cep + '/json/').then(function (r) { return r.json(); }).then(function (d) {
    if (!d || d.erro) { nota.textContent = 'CEP nao encontrado; preencha a mao'; return; }
    var poe = function (id, v) { var el = document.getElementById(id); if (el && v) { el.value = v; } };
    poe('endereco', d.logradouro); poe('bairro', d.bairro); poe('cidade', d.localidade); poe('uf', d.uf);
    nota.textContent = 'endereco preenchido pelo CEP; confira o numero';
  }).catch(function () { nota.textContent = 'sem resposta do ViaCEP; preencha a mao'; });
}
function fechCentavos(texto) {
  var t = String(texto || '').replace(/\./g, '').replace(',', '.');
  var v = parseFloat(t); return isNaN(v) ? 0 : Math.round(v * 100);
}
function fechReais(c) { return (c / 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
function fechModo() {
  var ass = document.getElementById('modo_ass').checked;
  document.getElementById('blocoCiclo').hidden = !ass;
  document.getElementById('blocoMeses').hidden = ass;
  document.getElementById('rotuloValor').textContent = ass ? 'Mensalidade (R$)' : 'Valor do período (R$)';
  document.getElementById('rotuloVence').textContent = ass ? 'Primeiro vencimento' : 'Data de pagamento';
  document.getElementById('previaNotaPre').hidden = ass;
  document.getElementById('previaPorMes').hidden = !ass;
  fechConta();
}
function fechConta() {
  var ass = document.getElementById('modo_ass').checked;
  var base = fechCentavos(document.getElementById('valor').value);
  // A MESMA CONTA DO SERVIDOR (shield_fechamento_previa): no pre-pago o valor
  // digitado ja e o do periodo e so os itens multiplicam; na assinatura o
  // digitado e o MENSAL e tudo multiplica pelo ciclo (11/09/2026).
  var vezes = ass ? Math.max(1, parseInt(document.getElementById('ciclo_meses').value, 10) || 1)
                  : Math.max(1, parseInt(document.getElementById('meses').value, 10) || 1);
  var itens = [], total = ass ? base * vezes : base, porMes = ass ? base : Math.round(base / vezes);
  {
    document.querySelectorAll('input[name="modulos[]"]:checked').forEach(function (m) {
      var c = parseInt(m.getAttribute('data-centavos'), 10) || 0;
      itens.push('Módulo ' + m.nextElementSibling.textContent.trim().split('·')[0].trim() + (vezes > 1 ? ' x' + vezes : '') + ': R$ ' + fechReais(c * vezes)); total += c * vezes; porMes += c;
    });
    var inc = parseInt(document.getElementById('terminais_inclusos').value, 10) || 0;
    var extras = Math.max(0, parseInt(document.getElementById('terminais_adicionais').value, 10) || 0);
    var vt = fechCentavos(document.getElementById('valor_terminal').value);
    if (extras > 0 && vt > 0) { itens.push('Caixas fora do plano (' + extras + ' × R$ ' + fechReais(vt) + (vezes > 1 ? ' x' + vezes : '') + '): R$ ' + fechReais(extras * vt * vezes)); total += extras * vt * vezes; porMes += extras * vt; }
  }
  document.getElementById('previaItens').innerHTML = [(ass ? 'Mensalidade' : 'Período') + ': R$ ' + fechReais(base) + (ass && vezes > 1 ? ' x' + vezes : '')].concat(itens).map(function (i) { return '<div class="col-6">' + i + '</div>'; }).join('');
  document.getElementById('previaTotal').textContent = fechReais(total);
  // Ciclo maior que um: o total e por ciclo, e a linha de baixo diz o mensal.
  var cicloLongo = ass && vezes > 1;
  document.getElementById('previaPorMes').textContent = cicloLongo ? ' por ciclo' : (ass ? ' por mês' : '');
  document.getElementById('previaCiclo').hidden = !cicloLongo;
  if (cicloLongo) { document.getElementById('previaPorMesValor').textContent = 'R$ ' + fechReais(porMes); document.getElementById('previaVezes').textContent = vezes; }

  // As formas que a conta faz; sem conta, todas (so registra).
  var sel = document.getElementById('conta'); var o = sel.options[sel.selectedIndex];
  var semConta = !sel.value || sel.value === '0';
  // Dinheiro em especie nao emite codigo nenhum: a unica forma dele e "dinheiro".
  var dinheiro = !semConta && o.getAttribute('data-dinheiro') === '1';
  var primeiraOk = null;
  ['pix', 'boleto', 'cartao', 'dinheiro'].forEach(function (f) {
    var ok = f === 'dinheiro' ? dinheiro : (!dinheiro && (semConta || o.getAttribute('data-' + f) === '1'));
    var r = document.getElementById('forma_' + f); r.disabled = !ok; r.parentElement.hidden = !ok;
    if (ok && primeiraOk === null) { primeiraOk = r; }
    if (!ok && r.checked) { r.checked = false; }
  });
  if (primeiraOk && !document.querySelector('input[name=forma]:checked')) { primeiraOk.checked = true; }
  document.getElementById('avisoManual').hidden = semConta || o.getAttribute('data-manual') !== '1';
}
fechModo();
</script>
<?php endif; ?>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
