<?php

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/empresa/exclusao.php'; // o que apaga e o que fica, na mesma regra

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}



$fkEmpresa = shield_empresa_contexto_id($_GET);
$q = trim((string) ($_GET['q'] ?? $_POST['q'] ?? ''));
$page = isset($_GET['page']) && filter_var($_GET['page'], FILTER_VALIDATE_INT)
    ? (int) $_GET['page']
    : (isset($_POST['page']) && filter_var($_POST['page'], FILTER_VALIDATE_INT) ? (int) $_POST['page'] : null);
$page = ($page !== null && $page > 0) ? $page : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fkEmpresa = shield_empresa_contexto_id($_POST);
}

if ($fkEmpresa === null || $fkEmpresa <= 0) {
    header('Location: /terminais.php?status=error');
    exit;
}

try {
    $stmtEmpresa = $pdo->prepare("SELECT codigo, razao FROM empresa WHERE codigo = :codigo LIMIT 1");
    $stmtEmpresa->execute([':codigo' => $fkEmpresa]);
    $empresa = $stmtEmpresa->fetch(PDO::FETCH_ASSOC);

    if (!$empresa) {
        header('Location: /terminais.php?status=error');
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (($_POST['confirmar'] ?? '') !== 'sim') {
            header('Location: ' . shield_bulk_redirect_url('confirm_required', $fkEmpresa, $q, $page));
            exit;
        }

        // O DELETE saiu daqui para shield_excluir_terminais_da_empresa, que
        // grava no livro quantas e quais maquinas sumiram -- 09/09/2026.
        // DESDE 14/09/2026 ELA SO APAGA O QUE NAO OCUPA VAGA, e o que ficou e
        // perguntado DEPOIS de apagar: e a contagem do que sobrou de verdade, e
        // nao a promessa da confirmacao, que pode ter envelhecido na aba.
        $apagados = shield_excluir_terminais_da_empresa($pdo, $fkEmpresa);
        $ficam = shield_terminais_apagaveis_da_empresa($pdo, $fkEmpresa)['ficam'];

        if ($ficam['trabalhando'] + $ficam['calada'] === 0) {
            header('Location: ' . shield_bulk_redirect_url('deleted_all', $fkEmpresa, $q, $page));
            exit;
        }

        // So inteiros na URL: a frase e montada na lista de terminais.
        header('Location: ' . shield_url_com_empresa('/terminais.php', $fkEmpresa, array(
            'q' => $q,
            'page' => ($page !== null && $page > 1) ? $page : null,
            'status' => 'deleted_parcial',
            'apagados' => (int) $apagados,
            'ficam_trabalhando' => (int) $ficam['trabalhando'],
            'ficam_caladas' => (int) $ficam['calada'],
        )));
        exit;
    }

    // A CONFIRMACAO DIZ O QUE VAI E O QUE FICA (14/09/2026), pela mesma funcao
    // que apaga. O COUNT(*) de antes prometia "todos", e o apagar deixa as que
    // ainda ocupam vaga.
    $previa = shield_terminais_apagaveis_da_empresa($pdo, $fkEmpresa);
    $totalTerminais = count($previa['apagaveis']);
    $ficamTrabalhando = (int) $previa['ficam']['trabalhando'];
    $ficamCaladas = (int) $previa['ficam']['calada'];
} catch (PDOException $exception) {
    header('Location: ' . shield_bulk_redirect_url('error', $fkEmpresa, $q, $page));
    exit;
}
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>


<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Excluir Terminais da Empresa</h1>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 fw-bold text-danger"><i class="fas fa-exclamation-triangle me-2"></i>Confirmacao Necessaria</h6>
        </div>
        <div class="card-body">
            <p>Empresa: <strong><?= shield_h($empresa['razao']); ?></strong></p>
            <p>Terminais que ser&atilde;o removidos: <strong><?= shield_h($totalTerminais); ?></strong>
                <span class="text-secondary">(vaga livre ou desativada)</span></p>

            <?php $ficamTotal = $ficamTrabalhando + $ficamCaladas; ?>
            <?php if ($ficamTotal > 0): ?>
                <?php /* O QUE FICA E POR QUE, ANTES DO CLIQUE (14/09/2026): quem abriu
                         "excluir todos" precisa saber que nem todos vao. */ ?>
                <div class="alert alert-warning">
                    <?= $ficamTotal === 1 ? 'Fica' : 'Ficam'; ?> <strong><?= $ficamTotal; ?></strong>, porque ainda <?= $ficamTotal === 1 ? 'ocupa' : 'ocupam'; ?> vaga:
                    <?php if ($ficamTrabalhando > 0): ?>
                        <?= $ficamTrabalhando; ?> trabalhando (sinal nos &uacute;ltimos <?= SHIELD_PARQUE_DIAS_SUMIDO; ?> dias:
                        apagar n&atilde;o adianta, o ERP cadastra de novo na pr&oacute;xima abertura)<?= $ficamCaladas > 0 ? ';' : '.'; ?>
                    <?php endif; ?>
                    <?php if ($ficamCaladas > 0): ?>
                        <?= $ficamCaladas; ?> calada<?= $ficamCaladas === 1 ? '' : 's'; ?>
                        (libere a vaga na lista de terminais e apague depois).
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if ($totalTerminais <= 0): ?>
                <div class="alert alert-info">Nenhum terminal desta empresa pode ser apagado agora.</div>
                <a href="<?= shield_h(shield_bulk_redirect_url('', $fkEmpresa, $q, $page)); ?>" class="btn btn-secondary">Voltar</a>
            <?php else: ?>
                <div class="alert alert-danger">
                    Esta a&ccedil;&atilde;o &eacute; irrevers&iacute;vel e remove os terminais desta empresa com a vaga livre ou desativados.
                </div>

                <form method="post" action="excluir_terminais_empresa.php" class="mt-3">
                    <input type="hidden" name="empresa" value="<?= shield_h($fkEmpresa); ?>">
                    <?php if ($q !== ''): ?>
                        <input type="hidden" name="q" value="<?= shield_h($q); ?>">
                    <?php endif; ?>
                    <?php if ($page !== null && $page > 1): ?>
                        <input type="hidden" name="page" value="<?= shield_h($page); ?>">
                    <?php endif; ?>

                    <div class="form-check mb-3">
                        <input type="checkbox" class="form-check-input" id="confirmar" name="confirmar" value="sim">
                        <label for="confirmar" class="form-check-label">Sim, tenho certeza que desejo excluir estes terminais</label>
                    </div>

                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash-alt me-1"></i> Excluir os que n&atilde;o ocupam vaga
                    </button>
                    <a href="<?= shield_h(shield_bulk_redirect_url('', $fkEmpresa, $q, $page)); ?>" class="btn btn-secondary">Cancelar</a>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>



<?php include __DIR__ . '/../../templates/fecha.php'; ?>
