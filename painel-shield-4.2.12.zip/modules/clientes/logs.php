<?php
/**
 * Logs do cliente - 25/08/2026.
 *
 * Pedir, ler e filtrar o log daquele terminal.
 *
 * O QUE ISTO SUBSTITUI: "compacta a pasta C:\Sistema\logs\<data> e manda". Boa
 * parte dos clientes nao consegue, e o suporte fica sem o unico arquivo que
 * responde a pergunta.
 *
 * A TELA MOSTRA O LOG LIDO, e nao so oferece o zip: obrigar a baixar e
 * descompactar para ver onde o sistema parou e devolver ao membro o trabalho
 * que este trabalho existe para tirar.
 *
 * O log do ERP grava um passo ANTES de cada etapa que pode travar, entao o
 * ultimo passo do arquivo e onde parou. E por isso que a leitura vem com o fim
 * primeiro.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/situacao.php';   // shield_cnpj
require_once __DIR__ . '/../../funcoes/notificacao/comando_erp.php';
require_once __DIR__ . '/../../funcoes/licenca/parque.php'; // shield_terminal_rotulo
require_once __DIR__ . '/../../templates/contexto_cliente.php';

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

$erro = '';
$aviso = '';
$empresaFiltro = shield_empresa_contexto_id($_GET);
$empresaSelecionada = null;
if ($empresaFiltro !== null) {
    $stmtEmpresa = $pdo->prepare('SELECT codigo, razao FROM empresa WHERE codigo = :codigo LIMIT 1');
    $stmtEmpresa->execute(array(':codigo' => $empresaFiltro));
    $empresaSelecionada = $stmtEmpresa->fetch(PDO::FETCH_ASSOC) ?: null;
    if (!$empresaSelecionada) {
        $empresaFiltro = null;
    }
}
$urlLogs = shield_url_com_empresa('/logs_cliente.php', $empresaFiltro);

shield_comando_expurgar_logs($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $acao = (string) ($_POST['acao'] ?? '');
        $terminalAcao = (int) ($_POST['terminal'] ?? 0);
        if ($empresaFiltro !== null) {
            $stmtTerminalContexto = $pdo->prepare(
                'SELECT 1 FROM terminais WHERE CODIGO = :terminal AND FK_EMPRESA = :empresa LIMIT 1'
            );
            $stmtTerminalContexto->execute(array(':terminal' => $terminalAcao, ':empresa' => $empresaFiltro));
            if (!$stmtTerminalContexto->fetchColumn()) {
                throw new RuntimeException('O terminal selecionado n&atilde;o pertence ao cliente em foco.');
            }
        }
        if ($acao === 'pedir') {
            $de = (string) ($_POST['de'] ?? date('Y-m-d', strtotime('-2 days')));
            $ate = (string) ($_POST['ate'] ?? date('Y-m-d'));
            // A PASTA INTEIRA -- 10/09/2026. O periodo continua indo junto:
            // ERP que ainda nao conhece o pedido de pasta manda o periodo.
            $pastaInteira = !empty($_POST['pasta_inteira']);
            shield_comando_pedir_log($pdo, $terminalAcao, $de, $ate, $pastaInteira);
            $aviso = 'Pedido registrado. ' . ($pastaInteira ? 'A pasta de logs inteira' : 'O log')
                . ' chega na pr&oacute;xima vez que aquele terminal abrir o sistema &mdash; at&eacute; 18 horas.';
        } elseif ($acao === 'cancelar') {
            shield_comando_cancelar_pedido($pdo, $terminalAcao);
            $aviso = 'Pedido cancelado.';
        }
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
}

// Baixar o zip passa por aqui, e nao por link direto: a pasta e barrada por
// .htaccess justamente para o arquivo de um cliente nao ficar acessivel a
// quem adivinhar o nome.
$baixar = (int) ($_GET['baixar'] ?? 0);
if ($baixar > 0) {
    $sqlBaixar = 'SELECT * FROM log_capturado WHERE id = :id';
    $paramsBaixar = array(':id' => $baixar);
    if ($empresaFiltro !== null) {
        $sqlBaixar .= ' AND fk_empresa = :empresa';
        $paramsBaixar[':empresa'] = $empresaFiltro;
    }
    $stmt = $pdo->prepare($sqlBaixar . ' LIMIT 1');
    $stmt->execute($paramsBaixar);
    $l = $stmt->fetch(PDO::FETCH_ASSOC);
    $caminho = $l ? shield_comando_pasta_logs() . '/' . basename((string) $l['arquivo']) : '';

    if ($l && is_file($caminho)) {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: application/zip');
        header('Content-Length: ' . filesize($caminho));
        // Descarta o filtro do CSRF antes de transmitir: ele segura a
        // resposta inteira na memoria, e aqui a resposta e um arquivo.
        shield_csrf_sem_filtro();
        header('Content-Disposition: attachment; filename="' . basename($caminho) . '"');
        readfile($caminho);
        exit;
    }
    $erro = 'Aquele arquivo nao esta mais no disco.';
}

$verId = (int) ($_GET['ver'] ?? 0);
$modulo = trim((string) ($_GET['modulo'] ?? ''));
$nivel = trim((string) ($_GET['nivel'] ?? ''));
// Um arquivo especifico do zip (caminho dentro dele), escolhido na arvore de
// pastas -- 10/09/2026, quando o ERP passou a mandar a pasta inteira.
$arquivoEscolhido = trim((string) ($_GET['arquivo'] ?? ''));
$linhas = array();
$arquivosNoZip = array();
$pastasNoZip = array();   // pasta => [ [nome, tamanho, texto?], ... ]
$verLinha = null;

if ($verId > 0) {
    $sqlVer =
        'SELECT l.*, e.razao, t.NOME_COMPUTADOR, t.APELIDO
           FROM log_capturado l
           LEFT JOIN empresa e ON e.codigo = l.fk_empresa
           LEFT JOIN terminais t ON t.CODIGO = l.fk_terminal
          WHERE l.id = :id';
    $paramsVer = array(':id' => $verId);
    if ($empresaFiltro !== null) {
        $sqlVer .= ' AND l.fk_empresa = :empresa';
        $paramsVer[':empresa'] = $empresaFiltro;
    }
    $stmt = $pdo->prepare($sqlVer . ' LIMIT 1');
    $stmt->execute($paramsVer);
    $verLinha = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

    $caminho = $verLinha ? shield_comando_pasta_logs() . '/' . basename((string) $verLinha['arquivo']) : '';
    if ($verLinha && is_file($caminho)) {
        $zip = new ZipArchive();
        if ($zip->open($caminho) === true) {
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $nome = (string) $zip->getNameIndex($i);
                if (substr($nome, -1) === '/') {
                    continue;   // entrada de pasta, sem conteudo
                }
                $arquivosNoZip[] = $nome;

                // A ARVORE: pasta (o dia, no ERP) -> arquivos. E o que o suporte
                // entende -- "compacta a pasta do dia e manda" era a instrucao
                // por telefone. Texto e so o que parece texto; o resto (xml,
                // pdf, binario) fica listado com o tamanho e sai no zip.
                $stat = $zip->statIndex($i);
                $pasta = strpos($nome, '/') !== false ? dirname($nome) : '';
                $amostra = (string) $zip->getFromIndex($i, 512);
                $ehTexto = $amostra === '' || preg_match('/^[\x09\x0A\x0D\x20-\x7E\x80-\xFF]*$/', $amostra) === 1;
                $pastasNoZip[$pasta][] = array(
                    'nome' => $nome,
                    'base' => basename($nome),
                    'tamanho' => (int) ($stat['size'] ?? 0),
                    'texto' => $ehTexto,
                );

                if ($arquivoEscolhido !== '' && $nome !== $arquivoEscolhido) {
                    continue;
                }
                if ($modulo !== '' && stripos($nome, $modulo) === false) {
                    continue;
                }
                if (!$ehTexto) {
                    continue;
                }

                $conteudo = (string) $zip->getFromIndex($i);
                foreach (explode("\n", $conteudo) as $l) {
                    $l = rtrim($l, "\r");
                    if ($l === '') {
                        continue;
                    }
                    if ($nivel !== '' && stripos($l, '[' . $nivel) === false) {
                        continue;
                    }
                    $linhas[] = array('arquivo' => $nome, 'texto' => $l);
                }
            }
            $zip->close();
        }
        ksort($pastasNoZip);

        // O fim primeiro: o ultimo passo gravado e onde o sistema parou.
        $linhas = array_slice(array_reverse($linhas), 0, 800);
    }
}

$sqlCapturados =
    'SELECT l.*, e.razao, e.cnpj, t.NOME_COMPUTADOR, t.APELIDO
       FROM log_capturado l
       LEFT JOIN empresa e ON e.codigo = l.fk_empresa
       LEFT JOIN terminais t ON t.CODIGO = l.fk_terminal
      ' . ($empresaFiltro !== null ? 'WHERE l.fk_empresa = :empresa ' : '')
    . 'ORDER BY l.chegou_em DESC LIMIT 60';
$stmtCapturados = $pdo->prepare($sqlCapturados);
$stmtCapturados->execute($empresaFiltro !== null ? array(':empresa' => $empresaFiltro) : array());
$capturados = $stmtCapturados->fetchAll(PDO::FETCH_ASSOC) ?: array();

$sqlTerminais =
    'SELECT t.CODIGO, t.NOME_COMPUTADOR, t.APELIDO, t.VERSAO_EXE, t.ULTIMO_ACESSO,
            t.log_pedido_de, t.log_pedido_ate, t.log_pedido_em, t.log_pedido_pasta, e.razao
       FROM terminais t LEFT JOIN empresa e ON e.codigo = t.FK_EMPRESA
      ' . ($empresaFiltro !== null ? 'WHERE t.FK_EMPRESA = :empresa ' : '')
    . 'ORDER BY e.razao, COALESCE(NULLIF(t.APELIDO, \'\'), t.NOME_COMPUTADOR)';
$stmtTerminais = $pdo->prepare($sqlTerminais);
$stmtTerminais->execute($empresaFiltro !== null ? array(':empresa' => $empresaFiltro) : array());
$terminais = $stmtTerminais->fetchAll(PDO::FETCH_ASSOC) ?: array();

$escopo = $empresaSelecionada !== null;
$pendentes = array_values(array_filter($terminais, static function ($t) {
    return !empty($t['log_pedido_de']);
}));
// O pedido mais novo em cima: quem abre esta tela acabou de pedir alguma coisa
// e quer ver aquilo, nao o que pediu na terca passada.
usort($pendentes, static function ($a, $b) {
    return strcmp((string) ($b['log_pedido_em'] ?? ''), (string) ($a['log_pedido_em'] ?? ''));
});
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>


<div class="topo-tela">
    <div>
        <div class="trilha">
            <a href="/clientes.php">Clientes</a><span>/</span>
            <?php if ($escopo): ?>
                <a href="/ver_empresa.php?id=<?= (int) $empresaFiltro; ?>"><?= shield_h((string) $empresaSelecionada['razao']); ?></a><span>/</span>
            <?php endif; ?>
            <span>Logs</span>
        </div>
        <h1 class="h4 mb-1">Logs do cliente</h1>
        <p class="text-secondary small mb-0">
            Pe&ccedil;a e leia o diagn&oacute;stico de cada ERP, sem depender do envio manual de arquivos.
        </p>
    </div>
    <div class="acoes-pagina">
        <a href="<?= shield_h(shield_voltar_cliente((int) $empresaFiltro)); ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i>Voltar
        </a>
    </div>
</div>

<?php if ($escopo): ?>
    <?php /* A barra "Cliente em foco" saiu em 10/09/2026: a trilha e a lateral ja dizem onde se esta. */ ?>
<?php endif; ?>

<?php shield_aviso_flutuante($aviso); ?>
<?php if ($erro !== ''): ?>
    <div class="alert alert-danger"><?= shield_h($erro); ?></div>
<?php endif; ?>

<?php if ($verLinha !== null): ?>
    <?php /* O LOG ABRE NUM MODAL (10/09/2026, tarde), com a lista de arquivos do zip para escolher. */ ?>
    <div class="modal fade" id="modalLog" tabindex="-1" aria-labelledby="modalLogTitulo" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <div class="modal-content">
        <div class="modal-header d-flex justify-content-between align-items-center flex-wrap gap-2">
            <span id="modalLogTitulo" class="h6 mb-0">
                <?= shield_h(shield_terminal_rotulo($verLinha) ?: 'Máquina'); ?>
                <span class="text-secondary fw-normal small">
                    &middot; <?= shield_h((string) ($verLinha['razao'] ?? '')); ?>
                    &middot; <?= $verLinha['de'] ? shield_h(date('d/m', strtotime((string) $verLinha['de']))) : '?'; ?>
                    a <?= $verLinha['ate'] ? shield_h(date('d/m', strtotime((string) $verLinha['ate']))) : '?'; ?>
                </span>
            </span>
            <span class="d-flex gap-2">
                <a href="<?= shield_h(shield_url_com_empresa('/logs_cliente.php', $empresaFiltro, array('baixar' => (int) $verLinha['id']))); ?>"
                   class="btn btn-sm btn-outline-secondary">
                    <i class="fas fa-file-download me-1"></i>Baixar o zip
                </a>
                <a href="<?= shield_h($urlLogs); ?>" class="btn btn-sm btn-outline-secondary">Fechar</a>
            </span>
        </div>
        <div class="modal-body">
            <form method="get" action="/logs_cliente.php" class="row g-2 align-items-end mb-3">
                <input type="hidden" name="ver" value="<?= (int) $verLinha['id']; ?>">
                <?php if ($arquivoEscolhido !== ''): ?>
                    <input type="hidden" name="arquivo" value="<?= shield_h($arquivoEscolhido); ?>">
                <?php endif; ?>
                <?php if ($empresaFiltro !== null): ?>
                    <input type="hidden" name="empresa" value="<?= (int) $empresaFiltro; ?>">
                <?php endif; ?>
                <div class="col-12 col-sm-5 col-lg-3">
                    <label class="form-label small mb-1" for="modulo">M&oacute;dulo</label>
                    <select id="modulo" name="modulo" class="form-select form-select-sm">
                        <option value="">Todos</option>
                        <?php foreach (array_unique(array_map(
                            static function ($n) { return basename($n, '.log'); },
                            $arquivosNoZip)) as $m): ?>
                            <option value="<?= shield_h($m); ?>" <?= $modulo === $m ? 'selected' : ''; ?>>
                                <?= shield_h($m); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12 col-sm-4 col-lg-2">
                    <label class="form-label small mb-1" for="nivel">N&iacute;vel</label>
                    <select id="nivel" name="nivel" class="form-select form-select-sm">
                        <option value="">Todos</option>
                        <?php foreach (array('ERRO', 'AVISO', 'PASSO', 'INFO') as $n): ?>
                            <option value="<?= $n; ?>" <?= $nivel === $n ? 'selected' : ''; ?>><?= $n; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12 col-sm-3 col-lg-2">
                    <button class="btn btn-primary btn-sm w-100">
                        <i class="fas fa-search"></i> Filtrar
                    </button>
                </div>
                <div class="col-12 col-lg-5">
                    <p class="text-secondary small mb-0">
                        Do fim para o come&ccedil;o: o ERP grava um passo <strong>antes</strong> de cada
                        etapa que pode travar, ent&atilde;o a primeira linha aqui &eacute; onde ele parou.
                    </p>
                </div>
            </form>

            <?php /* O TERMINAL VEM PRIMEIRO (11/09/2026): e a resposta da tela. A
                     arvore e o mapa para trocar de arquivo, e mapa fica depois do
                     lugar aonde se queria chegar. */ ?>
            <?php if (empty($linhas)): ?>
                <div class="vazio">
                    <i class="fas fa-file-download"></i>
                    <?= $arquivosNoZip ? 'Nenhuma linha com este filtro.' : 'O zip n&atilde;o abriu.'; ?>
                </div>
            <?php else: ?>
                <div class="log-linhas mb-3">
                    <?php if ($arquivoEscolhido !== ''): ?>
                        <?php /* Qual arquivo esta na tela. Sem isto, com a arvore
                                 fechada, as linhas nao dizem de onde vieram. */ ?>
                        <div class="log-qual"><?= shield_h($arquivoEscolhido); ?></div>
                    <?php endif; ?>
                    <?php foreach ($linhas as $l): ?>
                        <div class="<?= stripos($l['texto'], '[ERRO') !== false ? 'log-erro'
                            : (stripos($l['texto'], '[AVISO') !== false ? 'log-aviso' : ''); ?>"><?= shield_h($l['texto']); ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($arquivosNoZip): ?>
                <?php /* A PASTA COMO PASTA -- 10/09/2026. Com a pasta inteira vindo
                         do ERP, a lista chata de linhas nao diz de que dia e de que
                         arquivo se esta lendo. A arvore e o mapa; clicar num arquivo
                         mostra so ele, e "tudo" volta ao fim-primeiro de sempre.

                         FECHADA, E DEPOIS DO TERMINAL -- 11/09/2026. Uma pasta de
                         logs do ERP traz 20 arquivos por dia; com tres dias abertos
                         de uma vez, o mapa ocupava duas telas e empurrava para
                         baixo justamente o que se veio ler. Cada dia agora e um
                         <details>: abre quem o membro clicar, e o dia do arquivo
                         escolhido ja vem aberto para ele nao se perder. */ ?>
                <div class="log-arvore small">
                    <div class="mb-2">
                        <a href="<?= shield_h(shield_url_com_empresa('/logs_cliente.php', $empresaFiltro, array('ver' => (int) $verLinha['id']))); ?>"
                           class="<?= $arquivoEscolhido === '' ? 'fw-bold' : ''; ?>">
                            <i class="fas fa-copy me-1"></i>tudo (<?= count($arquivosNoZip); ?> arquivos)
                        </a>
                    </div>
                    <?php foreach ($pastasNoZip as $pasta => $arquivos): ?>
                        <?php
                        $temOEscolhido = false;
                        foreach ($arquivos as $a) {
                            if ($arquivoEscolhido !== '' && $a['nome'] === $arquivoEscolhido) {
                                $temOEscolhido = true;
                                break;
                            }
                        }
                        ?>
                        <details class="log-pasta"<?= $temOEscolhido ? ' open' : ''; ?>>
                            <summary>
                                <span><i class="fas fa-layer-group me-1"></i><?= shield_h($pasta !== '' ? $pasta : '(raiz)'); ?></span>
                                <span class="text-secondary num"><?= count($arquivos); ?> arquivo<?= count($arquivos) == 1 ? '' : 's'; ?></span>
                            </summary>
                            <ul class="list-unstyled mb-0">
                                <?php foreach ($arquivos as $a): ?>
                                    <li>
                                        <?php if ($a['texto']): ?>
                                            <a href="<?= shield_h(shield_url_com_empresa('/logs_cliente.php', $empresaFiltro, array('ver' => (int) $verLinha['id'], 'arquivo' => $a['nome']))); ?>"
                                               class="<?= $arquivoEscolhido === $a['nome'] ? 'fw-bold' : ''; ?>"><?= shield_h($a['base']); ?></a>
                                        <?php else: ?>
                                            <span class="text-secondary" title="N&atilde;o &eacute; texto: est&aacute; no zip"><?= shield_h($a['base']); ?></span>
                                        <?php endif; ?>
                                        <span class="text-secondary num"><?= $a['tamanho'] >= 1024 ? round($a['tamanho'] / 1024) . ' KB' : $a['tamanho'] . ' B'; ?></span>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </details>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    </div>
    </div>
    <script>
    // Abre ja aberto; fechar volta para a lista (a URL leva o ?ver=).
    document.addEventListener('DOMContentLoaded', function () {
        var m = document.getElementById('modalLog');
        if (!m || !window.bootstrap) { return; }
        var inst = bootstrap.Modal.getOrCreateInstance(m);
        inst.show();
        m.addEventListener('hidden.bs.modal', function () { window.location.href = <?= json_encode($urlLogs); ?>; });
    });
    </script>
<?php endif; ?>

<?php /* PEDIR E ESPERAR EM CIMA, LADO A LADO; o que ja chegou embaixo, por cliente
         (10/09/2026, tarde). */ ?>
<div class="row g-3">
    <div class="col-xl-6">
        <div class="card h-100" data-tour="logs-pedir">
            <div class="card-header">Pedir o log</div>
            <div class="card-body">
                <p class="text-secondary small">
                    O pedido &eacute; <strong>por m&aacute;quina</strong>, e n&atilde;o por cliente: o defeito
                    costuma ser de uma s&oacute;, e mandar as tr&ecirc;s lojas compactarem a pasta gasta
                    banda de todo mundo.
                </p>

                <?php if (empty($terminais)): ?>
                    <div class="vazio">
                        <i class="fas fa-desktop"></i>
                        <?php if ($escopo): ?>
                            Este cliente ainda n&atilde;o tem m&aacute;quina cadastrada, ent&atilde;o n&atilde;o h&aacute;
                            de quem pedir.
                            <a href="<?= shield_h(shield_url_com_empresa('/terminais.php', $empresaFiltro)); ?>">Ver os terminais</a>.
                        <?php else: ?>
                            Nenhuma m&aacute;quina cadastrada ainda.
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <form method="post" action="<?= shield_h($urlLogs); ?>" class="row g-2">
                        <input type="hidden" name="acao" value="pedir">
                        <div class="col-12">
                            <label class="form-label small mb-1" for="terminal">Terminal</label>
                            <?php /* So as maquinas DESTE cliente: a consulta ja filtra por
                                     FK_EMPRESA, e o POST confere de novo antes de gravar. */ ?>
                            <select id="terminal" name="terminal" class="form-select form-select-sm" required>
                                <?php foreach ($terminais as $t): ?>
                                    <option value="<?= (int) $t['CODIGO']; ?>" <?= $t['log_pedido_de'] ? 'disabled' : ''; ?>>
                                        <?php if (!$escopo): ?><?= shield_h((string) ($t['razao'] ?? '')); ?> &middot; <?php endif; ?>
                                        <?= shield_h(shield_terminal_rotulo($t)); ?><?= shield_terminal_maquina_atras($t) !== '' ? ' (' . shield_h(shield_terminal_maquina_atras($t)) . ')' : ''; ?>
                                        <?php if ($t['log_pedido_de']): ?>
                                            &mdash; j&aacute; pedido
                                        <?php elseif (!empty($t['ULTIMO_ACESSO'])): ?>
                                            &mdash; sinal <?= shield_h(date('d/m H:i', strtotime((string) $t['ULTIMO_ACESSO']))); ?>
                                        <?php else: ?>
                                            &mdash; nunca deu sinal
                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label small mb-1" for="de">De</label>
                            <input id="de" type="date" name="de" class="form-control form-control-sm"
                                   value="<?= shield_h(date('Y-m-d', strtotime('-2 days'))); ?>">
                        </div>
                        <div class="col-6">
                            <label class="form-label small mb-1" for="ate">At&eacute;</label>
                            <input id="ate" type="date" name="ate" class="form-control form-control-sm"
                                   value="<?= shield_h(date('Y-m-d')); ?>">
                        </div>
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="pasta_inteira" name="pasta_inteira" value="1" checked>
                                <label class="form-check-label small" for="pasta_inteira">
                                    A pasta de logs inteira, com todos os dias e arquivos
                                </label>
                            </div>
                            <p class="text-secondary small mb-2">
                                Desmarcado, s&oacute; os <code>.log</code> do per&iacute;odo acima. ERP antigo manda o
                                per&iacute;odo de qualquer jeito.
                            </p>
                            <button class="btn btn-primary btn-sm">
                                <i class="fas fa-file-download me-1"></i>Pedir o log
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>

    </div>
    <div class="col-xl-6">
        <div class="card h-100" data-tour="logs-fila">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Aguardando log</span>
                <?php if ($pendentes): ?>
                    <span class="pilula pilula-atencao"><?= count($pendentes); ?></span>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <?php if (empty($pendentes)): ?>
                    <div class="vazio">
                        <i class="fas fa-hourglass-half"></i>
                        Nenhum pedido na fila.
                    </div>
                <?php else: ?>
                    <p class="text-secondary small">
                        O log sai na pr&oacute;xima vez que a m&aacute;quina abrir o sistema &mdash;
                        at&eacute; 18 horas.
                    </p>
                    <?php /* QUATRO NA TELA, o resto rola (10/09/2026, tarde): o cartao fica da altura do "Pedir o log". */ ?>
                    <ul class="list-unstyled mb-0" style="max-height: 17rem; overflow-y: auto">
                    <?php foreach ($pendentes as $t): ?>
                        <li class="pedido-log">
                            <div>
                                <strong class="small d-block"><?= shield_h(shield_terminal_rotulo($t)); ?></strong>
                                <?php /* O cliente aparece mesmo dentro de um: a fila e o unico
                                         lugar da tela onde se olha para pedidos, e quem esta
                                         com o telefone na mao precisa dizer o nome da loja. */ ?>
                                <span class="text-secondary small d-block"><?= shield_h((string) ($t['razao'] ?? '')); ?></span>
                                <span class="text-secondary small num">
                                    <?php if (!empty($t['log_pedido_pasta'])): ?>
                                        pasta inteira
                                    <?php else: ?>
                                        <?= shield_h(date('d/m', strtotime((string) $t['log_pedido_de']))); ?>
                                        a <?= shield_h(date('d/m', strtotime((string) $t['log_pedido_ate']))); ?>
                                    <?php endif; ?>
                                    &middot; sinal
                                    <?= $t['ULTIMO_ACESSO']
                                        ? shield_h(date('d/m H:i', strtotime((string) $t['ULTIMO_ACESSO'])))
                                        : 'nunca'; ?>
                                </span>
                            </div>
                            <form method="post" action="<?= shield_h($urlLogs); ?>">
                                <input type="hidden" name="acao" value="cancelar">
                                <input type="hidden" name="terminal" value="<?= (int) $t['CODIGO']; ?>">
                                <button class="btn btn-sm btn-outline-secondary">cancelar</button>
                            </form>
                        </li>
                    <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
$cabecalhoLogs = static function () use ($escopo) {
    echo '<thead><tr><th scope="col">M&aacute;quina</th><th scope="col" class="meio">Per&iacute;odo</th><th scope="col" class="meio">Tamanho</th>'
        . '<th scope="col" class="meio">Chegou</th><th scope="col" class="meio" style="width:1%">A&ccedil;&otilde;es</th></tr></thead>';
};
$linhaLog = static function (array $l) use ($empresaFiltro) {
    echo '<tr><td class="identidade par" data-r="M&aacute;quina"><div><span class="nome">' . shield_h(shield_terminal_rotulo($l)) . '</span>'
        . '<span class="apoio">' . shield_h(trim(shield_terminal_maquina_atras($l) . ' ' . (string) ($l['versao_exe'] ?? ''))) . '</span></div></td>'
        . '<td class="meio" data-r="Per&iacute;odo">' . ($l['de'] ? shield_h(date('d/m', strtotime((string) $l['de']))) : '?') . ' a ' . ($l['ate'] ? shield_h(date('d/m', strtotime((string) $l['ate']))) : '?') . '</td>'
        . '<td class="meio" data-r="Tamanho">' . shield_h(number_format(((int) $l['tamanho']) / 1024, 0, ',', '.')) . ' KB</td>'
        . '<td class="meio" data-r="Chegou">' . shield_h(date('d/m H:i', strtotime((string) $l['chegou_em']))) . '</td>'
        . '<td class="meio" data-r="A&ccedil;&otilde;es"><span class="acoes">'
        . '<a class="acao" title="Ler este log" href="' . shield_h(shield_url_com_empresa('/logs_cliente.php', $empresaFiltro, array('ver' => (int) $l['id']))) . '"><i class="fas fa-eye"></i></a>'
        . '<a class="acao" title="Baixar o zip" href="' . shield_h(shield_url_com_empresa('/logs_cliente.php', $empresaFiltro, array('baixar' => (int) $l['id']))) . '"><i class="fas fa-file-download"></i></a>'
        . '</span></td></tr>';
};
$gruposLogs = array();
foreach ($capturados as $l) {
    $k = (string) ($l['fk_empresa'] ?? $l['razao'] ?? '');
    if (!isset($gruposLogs[$k])) {
        $gruposLogs[$k] = array('razao' => (string) ($l['razao'] ?? 'sem cliente'), 'cnpj' => (string) ($l['cnpj'] ?? ''), 'linhas' => array());
    }
    $gruposLogs[$k]['linhas'][] = $l;
}
?>
<div class="card mt-3" data-tour="logs-chegou">
    <div class="card-header">O que j&aacute; chegou</div>
    <?php if (empty($capturados)): ?>
        <div class="card-body p-0"><div class="vazio"><i class="fas fa-file-download"></i>
            Nenhum log recebido ainda. Pe&ccedil;a o de um terminal acima &mdash; ele chega na pr&oacute;xima vez que aquela m&aacute;quina abrir o sistema.
        </div></div>
    <?php elseif ($escopo): ?>
        <div class="table-responsive"><table class="lista"><?php $cabecalhoLogs(); ?><tbody>
            <?php foreach ($capturados as $l) { $linhaLog($l); } ?>
        </tbody></table></div>
    <?php else: ?>
        <div class="card-body p-2">
        <div class="grupos-terminais">
        <?php foreach ($gruposLogs as $k => $g): ?>
            <?php $total = count($g['linhas']); ?>
            <details class="card grupo-terminais">
                <summary>
                    <span class="grupo-nome"><i class="fas fa-building"></i> <?= shield_h($g['razao']); ?>
                        <?php if ($g['cnpj'] !== ''): ?><span class="apoio ms-2 num"><?= shield_h(shield_cnpj($g['cnpj'])); ?></span><?php endif; ?></span>
                    <span class="grupo-resumo">
                        <span class="grupo-total num"><?= $total; ?> log<?= $total == 1 ? '' : 's'; ?></span>
                        <i class="fas fa-sort-down grupo-seta"></i>
                    </span>
                </summary>
                <div class="table-responsive"><table class="lista"><?php $cabecalhoLogs(); ?><tbody>
                    <?php foreach ($g['linhas'] as $l) { $linhaLog($l); } ?>
                </tbody></table></div>
            </details>
        <?php endforeach; ?>
        </div>
        </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
