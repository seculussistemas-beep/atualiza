<?php
/**
 * Certificados digitais -- 19/10/2026. Quem esta com o certificado vencido ou
 * vencendo, um cliente por linha. A regra mora em funcoes/licenca/certificado.php
 * (a mesma do bloco da Central e do badge) e funcoes/licenca/certificado_lista.php.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/certificado_lista.php';

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

$recortes = shield_certificado_recortes();
$recorte = (string) ($_GET['recorte'] ?? 'vencendo');
if (!isset($recortes[$recorte])) {
    $recorte = 'vencendo';
}

$lista = shield_certificado_lista($pdo, $recorte);
$contagens = shield_certificado_contagens($pdo);
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <h1 class="h4 mb-1">Certificados digitais</h1>
        <p class="text-secondary small mb-0">
            O certificado de cada cliente, pela data que o ERP da loja informa. Sem ele a loja para de emitir nota:
            quem est&aacute; mais perto de vencer vem primeiro.
        </p>
    </div>
    <div class="acoes-pagina">
        <a href="/clientes.php" class="btn btn-sm btn-outline-secondary"><i class="fas fa-building me-1"></i>Clientes</a>
    </div>
</div>

<div class="card mb-3" data-tour="certificados">
    <div class="card-body py-3">
        <div class="btn-group btn-group-sm flex-wrap" role="group" aria-label="Quais certificados mostrar">
            <?php foreach ($recortes as $chave => $rotulo): ?>
                <a class="btn btn-outline-secondary <?= $recorte === $chave ? 'active' : ''; ?>"
                   href="/certificados.php<?= $chave === 'vencendo' ? '' : '?recorte=' . $chave; ?>"><?= $rotulo; ?> &middot; <?= (int) ($contagens[$chave] ?? 0); ?></a>
            <?php endforeach; ?>
        </div>
        <?php if ($recorte === 'sem'): ?>
            <p class="small text-secondary mb-0 mt-2">
                Clientes cujo ERP ainda n&atilde;o informou a data do certificado. A data chega quando a loja abre
                o ERP numa vers&atilde;o que a envia; at&eacute; l&aacute;, estes n&atilde;o aparecem nos outros recortes.
            </p>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="lista">
            <thead>
                <tr>
                    <th scope="col">Cliente</th>
                    <th scope="col" class="meio">Vence em</th>
                    <th scope="col" class="meio">Situa&ccedil;&atilde;o</th>
                    <th scope="col" class="num">A&ccedil;&otilde;es</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$lista['linhas']): ?>
                <tr><td colspan="4" class="text-secondary small">
                    <?= $recorte === 'sem' ? 'Todo cliente tem a data do certificado informada.' : 'Nenhum certificado neste recorte.'; ?>
                </td></tr>
            <?php endif; ?>
            <?php foreach ($lista['linhas'] as $l): ?>
                <?php
                $cnpj = (string) ($l['cnpj'] ?? '');
                $fone = trim((string) ($l['fone'] ?? ''));
                $vence = trim((string) ($l['certificado_vence'] ?? ''));
                $sit = $vence !== '' ? shield_certificado_situacao($vence) : null;
                ?>
                <tr>
                    <td class="identidade" data-r="Cliente">
                        <div>
                            <a class="nome" href="/ver_empresa.php?id=<?= (int) $l['codigo']; ?>"><?= shield_h((string) ($l['razao'] ?? 'Cliente')); ?></a>
                            <span class="apoio">
                                <?= shield_h($cnpj !== '' ? shield_cnpj($cnpj) : ''); ?>
                                <?php if ($fone !== ''): ?> &middot; <?php $zap = shield_whatsapp_url($fone); ?><?php if ($zap !== null): ?><a href="<?= shield_h($zap); ?>" target="_blank" rel="noopener" title="Abrir no WhatsApp"><?= shield_h(shield_telefone($fone)); ?></a><?php else: ?><?= shield_h(shield_telefone($fone)); ?><?php endif; ?><?php endif; ?>
                            </span>
                        </div>
                    </td>
                    <td class="meio" data-r="Vence em"><?= $vence !== '' ? shield_h(date('d/m/Y', strtotime($vence))) : '&mdash;'; ?></td>
                    <td class="meio" data-r="Situa&ccedil;&atilde;o">
                        <?php if ($sit !== null): ?>
                            <span class="pilula pilula-<?= shield_h((string) $sit['cor']); ?>"><?= shield_h((string) $sit['rotulo']); ?></span>
                        <?php else: ?><span class="pilula pilula-neutro">n&atilde;o informado</span><?php endif; ?>
                    </td>
                    <td class="num" data-r="A&ccedil;&otilde;es">
                        <a class="btn btn-sm btn-outline-secondary" href="/ver_empresa.php?id=<?= (int) $l['codigo']; ?>"
                           title="A ficha deste cliente"><i class="fas fa-eye me-1"></i>Ficha</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if ($lista['cortada']): ?>
        <div class="card-body py-2 small text-secondary">Mostrando os 500 primeiros deste recorte.</div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
