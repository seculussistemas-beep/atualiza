<?php

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/parque.php';
require_once __DIR__ . '/../../funcoes/licenca/estado_terminal.php'; // os quatro estados da maquina
require_once __DIR__ . '/../../templates/contexto_cliente.php';

// Cadastro e exclusao de maquinas alteram a base que alimenta a licenca.
// Mantem a mesma fronteira do Monitoramento do parque: so administrador.
if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}



$fkEmpresa = shield_empresa_contexto_id($_GET);

$q = trim((string) ($_GET['q'] ?? ''));

// Vivo/sem sinal sai da MESMA coluna e do MESMO corte que o monitoramento usa
// (SHIELD_PARQUE_DIAS_SUMIDO). Cadastro que chama de sumido quem o parque
// chama de vivo e o tipo de divergencia que ninguem percebe ate o cliente
// reclamar de uma maquina que "some" numa tela e nao na outra.
// OS QUATRO ESTADOS -- 10/09/2026, fatia 3 da reorganizacao. O filtro e a
// pilula da linha leem a mesma regra (funcoes/licenca/estado_terminal.php).
// "vivo" e "sumido" continuam aceitos: sao os nomes que o parque e o painel
// ainda usam nos links. Sem filtro, VAGA LIVRE fica de fora: e a maquina que
// ja devolveu a vaga sozinha, e so aparece quando alguem a procura.
$situacao = trim((string) ($_GET['situacao'] ?? ''));
$situacao = array('vivo' => 'trabalhando', 'sumido' => 'calada')[$situacao] ?? $situacao;
if (!isset(shield_terminal_estados()[$situacao])) {
    $situacao = '';
}
$cortes = shield_terminal_cortes();
$corteSumido = $cortes[':corte3'];
$statusParam = trim((string) ($_GET['status'] ?? ''));
$page = isset($_GET['page']) && filter_var($_GET['page'], FILTER_VALIDATE_INT)
    ? (int) $_GET['page']
    : 1;
if ($page < 1) {
    $page = 1;
}

$recordsPerPage = 20;

// APELIDO E DESATIVACAO -- 09/09/2026.
//
// A DESATIVACAO SO VALE PARA QUEM ESTA SEM SINAL, e a guarda e no servidor e
// nao so na tela: desativar a maquina que esta vendendo agora e desligar o
// caixa da loja pelo painel, sem querer. Quem sabe que ela morreu espera os
// SHIELD_PARQUE_DIAS_SUMIDO dias -- que e o mesmo corte que a coluna "sem
// sinal" ja mostra, entao o membro ve o estado antes de agir.
//
// REATIVAR confere a cota (shield_licenca_reativar_terminal, 14/09/2026): com
// os outros vivos enchendo a cota, devolver a maquina ao ar tiraria um caixa.
//
// A TROCA DE COMPUTADOR E A EXCECAO -- 14/09/2026, pedido do dono. Quem troca
// o computador da loja esperava tres dias com o novo recusado por cota cheia.
// A maquina TRABALHANDO libera a vaga quando o mesmo cliente tem outra maquina
// recusada por cota cheia que ainda esta de fora, com o nome do computador
// digitado. A regra inteira mora em shield_terminal_trocar_computador
// (funcoes/licenca/estado_terminal.php), que confere de novo tudo o que o
// botao conferiu; aqui so se chama.
$avisoTerminal = '';
// Frase com consequencia ou passo fica dez segundos em vez de cinco (4.1.26).
$avisoTerminalDemorado = false;
$erroTerminal = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acaoT = (string) ($_POST['acao_terminal'] ?? '');
    $codigoT = (int) ($_POST['terminal'] ?? 0);

    try {
        if ($acaoT !== '' && $codigoT > 0) {
            $stmtT = $pdo->prepare('SELECT CODIGO, NOME_COMPUTADOR, ULTIMO_ACESSO, DESATIVADO_EM
                                      FROM terminais WHERE CODIGO = :c LIMIT 1');
            $stmtT->execute([':c' => $codigoT]);
            $alvo = $stmtT->fetch(PDO::FETCH_ASSOC);

            if (!$alvo) {
                throw new RuntimeException('Terminal nao encontrado.');
            }

            if ($acaoT === 'apelido') {
                $apelido = substr(trim((string) ($_POST['apelido'] ?? '')), 0, 40);
                $pdo->prepare('UPDATE terminais SET APELIDO = :a WHERE CODIGO = :c')
                    ->execute([':a' => $apelido !== '' ? $apelido : null, ':c' => $codigoT]);
                $avisoTerminal = $apelido !== ''
                    ? 'Apelido gravado: ' . $apelido . '.'
                    : 'Apelido removido.';
            } elseif ($acaoT === 'desativar') {
                $visto = trim((string) ($alvo['ULTIMO_ACESSO'] ?? ''));
                $semSinal = ($visto === '') || (strtotime($visto) < strtotime($corteSumido));
                if (!$semSinal) {
                    throw new RuntimeException(
                        'Esta maquina deu sinal nos ultimos ' . SHIELD_PARQUE_DIAS_SUMIDO
                        . ' dias. So da para liberar a vaga de quem parou de trabalhar.'
                    );
                }

                $pdo->prepare('UPDATE terminais SET DESATIVADO_EM = NOW(), DESATIVADO_POR = :q
                                WHERE CODIGO = :c AND DESATIVADO_EM IS NULL')
                    ->execute([
                        ':q' => substr((string) ($_SESSION['usuario']['nome'] ?? $_SESSION['usuario']['login'] ?? ''), 0, 80),
                        ':c' => $codigoT,
                    ]);
                $avisoTerminal = 'Vaga liberada. A maquina fica no historico e nao recebe mais licenca.';
            } elseif ($acaoT === 'trocar') {
                // O cliente vem do foco da tela; na lista de todos os clientes,
                // da linha em que o botao foi clicado. A funcao confere que a
                // maquina e dele, que trabalha, o nome digitado e a recusa por
                // cota cheia, e grava o livro com o nome e a maquina recusada --
                // por isso o bloco generico logo abaixo pula esta acao.
                $empresaTroca = $fkEmpresa !== null ? (int) $fkEmpresa : (int) ($_POST['empresa_terminal'] ?? 0);
                $troca = shield_terminal_trocar_computador($pdo, $codigoT, $empresaTroca, (string) ($_POST['nome_confirmado'] ?? ''));
                // Quem entra e a de fora mais antiga, que pode ser uma maquina ja
                // cadastrada e nao a nova (shield_licenca_tem_vaga): o aviso diz o
                // nome que a funcao decidiu, e nao o da recusa que abriu o botao.
                $recusada = trim((string) ($troca['recusa']['nome_computador'] ?? ''));
                $entra = trim((string) ($troca['entra'] ?? ''));
                $avisoTerminalDemorado = true;
                // SEM RECUSA E A LIBERACAO DA MAQUINA EM USO (01/10/2026): nao ha quem
                // entre, entao a frase nao promete maquina nenhuma.
                $avisoTerminal = $troca['recusa'] === null
                    ? 'Vaga de ' . shield_terminal_rotulo($troca['terminal'])
                        . ' liberada agora: ela para de receber licen&ccedil;a na pr&oacute;xima abertura do ERP, e a vaga'
                        . ' fica livre para outra m&aacute;quina do cliente. D&aacute; para reativar depois, se houver vaga.'
                    : 'Vaga de ' . shield_terminal_rotulo($troca['terminal'])
                    . ' liberada para a troca de computador: ela para de receber licen&ccedil;a. '
                    . ($entra !== '' && $entra !== $recusada
                        ? 'Quem entra na vaga &eacute; ' . shield_h($entra) . ', a m&aacute;quina cadastrada mais antiga que estava de fora'
                          . ($recusada !== '' ? ' (' . shield_h($recusada) . ' continua esperando)' : '') . ', na pr&oacute;xima abertura do ERP.'
                        : 'A m&aacute;quina nova' . ($entra !== '' ? ' (' . shield_h($entra) . ')' : '') . ' entra na pr&oacute;xima abertura do ERP.');
            } elseif ($acaoT === 'reativar') {
                // REATIVAR CONFERE A COTA -- 14/09/2026. A linha desativada com
                // menos de 30 dias sem sinal voltava a contar na hora, com o
                // CODIGO antigo, e derrubava o caixa vivo mais novo. A recusa
                // sobe como excecao e cai no $erroTerminal logo abaixo, sem
                // linha de reativacao no livro.
                require_once __DIR__ . '/../../funcoes/licenca/licenca_assinada.php';
                shield_licenca_reativar_terminal($pdo, $codigoT);
                $avisoTerminal = 'Terminal reativado. Ele volta a disputar vaga na proxima abertura.';
            }

            // A troca de computador ja gravou o livro dela, com o nome digitado e
            // a maquina recusada: gravar aqui de novo seria uma troca com duas linhas.
            if ($avisoTerminal !== '' && !in_array($acaoT, array('apelido', 'trocar'), true)) {
                require_once __DIR__ . '/../../funcoes/cobranca/cobranca.php';
                if (function_exists('shield_auditar')) {
                    shield_auditar($pdo, 'terminal_' . $acaoT, [
                        'alvo_tipo' => 'terminal',
                        'alvo_id' => $codigoT,
                        'detalhe' => (string) $alvo['NOME_COMPUTADOR'],
                    ]);
                }
            }
        }
    } catch (Throwable $e) {
        $erroTerminal = $e->getMessage();
    }
}

$statusMessages = [
    'deleted_one' => ['class' => 'success', 'text' => 'Terminal excluido com sucesso.'],
    'deleted_all' => ['class' => 'success', 'text' => 'Todos os terminais da empresa selecionada foram excluidos.'],
    'error' => ['class' => 'danger', 'text' => 'Nao foi possivel concluir a operacao solicitada.'],
    'confirm_required' => ['class' => 'warning', 'text' => 'Confirme a exclusao para continuar.'],
    // A TRAVA DO SERVIDOR (14/09/2026): so chega aqui quem apagou por aba velha
    // ou formulario montado, porque a lixeira nem aparece nesses estados. E
    // faixa, e nao aviso que some: e recusa. A linha da maquina ja mostra o
    // estado de agora.
    'recusado_apagar' => ['class' => 'warning', 'text' => 'Terminal nao apagado: ele deu sinal nos ultimos '
        . SHIELD_PARQUE_DIAS_SUMIDO . ' dias ou ainda ocupa vaga. So se apaga maquina com a vaga livre ou desativada; a calada tem a vaga liberada primeiro.'],
];

// "EXCLUIR TODOS" QUE DEIXOU MAQUINA PARA TRAS (14/09/2026). Os numeros chegam
// na URL como inteiros, nunca como texto: a frase e montada aqui, e a URL nao
// consegue por palavra nenhuma na tela.
$apagadosEmMassa = max(0, (int) ($_GET['apagados'] ?? 0));
$ficaramTrabalhando = max(0, (int) ($_GET['ficam_trabalhando'] ?? 0));
$ficaramCaladas = max(0, (int) ($_GET['ficam_caladas'] ?? 0));
$ficaramPartes = array();
if ($ficaramTrabalhando > 0) {
    $ficaramPartes[] = $ficaramTrabalhando . ' trabalhando (sinal nos &uacute;ltimos ' . SHIELD_PARQUE_DIAS_SUMIDO
        . ' dias: apagar n&atilde;o adianta, o ERP cadastra de novo na pr&oacute;xima abertura)';
}
if ($ficaramCaladas > 0) {
    $ficaramPartes[] = $ficaramCaladas . ' calada' . ($ficaramCaladas === 1 ? '' : 's')
        . ' (ainda ocupa' . ($ficaramCaladas === 1 ? '' : 'm') . ' vaga: libere a vaga na linha e apague depois)';
}

try {
    $stmtEmpresas = $pdo->query("SELECT codigo, razao FROM empresa ORDER BY razao ASC");
    $empresas = $stmtEmpresas->fetchAll(PDO::FETCH_ASSOC);

    $baseSql = "FROM terminais t
                LEFT JOIN empresa e ON e.codigo = t.fk_empresa
                WHERE 1=1";
    $params = [];

    if ($fkEmpresa !== null) {
        $baseSql .= " AND t.fk_empresa = :fk_empresa";
        $params[':fk_empresa'] = $fkEmpresa;
    }

    if ($q !== '') {
        $baseSql .= " AND (t.mac LIKE :q OR t.nome_computador LIKE :q OR t.APELIDO LIKE :q OR e.razao LIKE :q)";
        $params[':q'] = '%' . $q . '%';
    }

    // Os cartoes contam ANTES do filtro de situacao. Se contassem depois,
    // "sem sinal" mostraria zero justamente quando se esta olhando os vivos,
    // e o cartao viraria eco do filtro em vez de informacao.
    // Um numero por estado, pela MESMA regra SQL que filtra a lista.
    $somas = array();
    foreach (array_keys(shield_terminal_estados()) as $estadoChave) {
        $somas[] = 'SUM(CASE WHEN ' . shield_terminal_estado_sql($estadoChave) . ' THEN 1 ELSE 0 END) AS ' . $estadoChave;
    }
    $stmtSinal = $pdo->prepare('SELECT COUNT(*) AS todos, ' . implode(', ', $somas) . ' ' . $baseSql);
    foreach ($params as $chave => $valor) {
        $stmtSinal->bindValue($chave, $chave === ':fk_empresa' ? (int) $valor : (string) $valor,
                              $chave === ':fk_empresa' ? PDO::PARAM_INT : PDO::PARAM_STR);
    }
    $stmtSinal->execute();
    $sinal = $stmtSinal->fetch(PDO::FETCH_ASSOC) ?: array();
    $totalCadastrados = (int) ($sinal['todos'] ?? 0);
    $totais = array();
    foreach (array_keys(shield_terminal_estados()) as $estadoChave) {
        $totais[$estadoChave] = (int) ($sinal[$estadoChave] ?? 0);
    }
    $totalVivos = $totais['trabalhando'];

    $baseSql .= ' AND ' . shield_terminal_estado_sql($situacao !== '' ? $situacao : 'sem_vaga_livre');

    $stmtCount = $pdo->prepare("SELECT COUNT(*) " . $baseSql);
    $stmtCount->execute($params);
    $totalRecords = (int) $stmtCount->fetchColumn();

    $totalPages = (int) ceil($totalRecords / $recordsPerPage);
    if ($totalPages < 1) {
        $totalPages = 1;
    }
    if ($page > $totalPages) {
        $page = $totalPages;
    }

    $offset = ($page - 1) * $recordsPerPage;
    if ($offset < 0) {
        $offset = 0;
    }

    // LEFT JOIN deixa o cadastro e o monitoramento enxergarem a mesma base.
    // Se uma empresa foi removida por um caminho antigo, o terminal ainda pode
    // ser revisado e limpo daqui, em vez de ficar invisivel para sempre.
    $listSql = "SELECT t.codigo AS terminal_codigo, t.fk_empresa, t.mac, t.nome_computador,
                       t.ULTIMO_ACESSO, t.VERSAO_EXE, t.APELIDO, t.DESATIVADO_EM,
                       COALESCE(NULLIF(TRIM(e.razao), ''), 'Cliente removido') AS razao,
                       /* A LOJA POR TRAS DA MAQUINA (11/09/2026): sem estes campos a
                          linha marcava de verde um caixa que abre e nao opera, porque a
                          empresa esta bloqueada. Ver shield_terminal_loja_parada. */
                       e.validade_licenca, e.bloqueado, e.suspenso_em, e.encerrado_em,
                       e.teste_ate, e.teste_terminais, e.fechado_em, e.data
                " . $baseSql . "
                ORDER BY t.codigo DESC
                LIMIT :offset, :limit";

    $stmtTerminais = $pdo->prepare($listSql);
    foreach ($params as $key => $value) {
        if ($key === ':fk_empresa') {
            $stmtTerminais->bindValue($key, (int) $value, PDO::PARAM_INT);
        } else {
            $stmtTerminais->bindValue($key, (string) $value, PDO::PARAM_STR);
        }
    }
    $stmtTerminais->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmtTerminais->bindValue(':limit', $recordsPerPage, PDO::PARAM_INT);
    $stmtTerminais->execute();

    $terminais = $stmtTerminais->fetchAll(PDO::FETCH_ASSOC);

    // A TROCA DE COMPUTADOR (14/09/2026). A linha trabalhando so ganha o botao
    // quando o mesmo cliente tem outra maquina recusada por cota cheia que ainda
    // esta de fora. Uma consulta para a pagina inteira, a mesma que o POST refaz.
    // A resposta vai NA LINHA porque shield_terminal_acoes decide pela linha, e a
    // coluna "Acoes" pergunta a ela: calculada so no botao, a coluna nao a veria.
    $recusasPorCota = shield_parque_recusas_por_cota($pdo, array_column($terminais, 'fk_empresa'));
    foreach ($terminais as $i => $linhaTerminal) {
        $terminais[$i]['recusa_por_cota'] = shield_terminal_recusa_para_troca(
            $recusasPorCota[(int) $linhaTerminal['fk_empresa']] ?? array(),
            (int) $linhaTerminal['terminal_codigo']
        );
    }
    $numTerminaisPagina = count($terminais);

    if ($totalRecords > 0) {
        $firstRecord = $offset + 1;
        $lastRecord = $offset + $numTerminaisPagina;
    } else {
        $firstRecord = 0;
        $lastRecord = 0;
    }
} catch (PDOException $exception) {
    die('Erro ao consultar terminais: ' . $exception->getMessage());
}

$empresaSelecionada = null;
if ($fkEmpresa !== null) {
    foreach ($empresas as $empresaItem) {
        if ((int) $empresaItem['codigo'] === $fkEmpresa) {
            $empresaSelecionada = $empresaItem;
            break;
        }
    }
}

$baseQuery = [
    'empresa' => $fkEmpresa,
    'q' => $q,
    'situacao' => $situacao,
];

/** URL desta mesma tela trocando so uma coisa. */
function shield_terminais_filtro(array $base, array $troca)
{
    return shield_terminais_url(array_merge($base, $troca, array('page' => 1)));
}
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>


<?php
$escopo = $empresaSelecionada !== null;
// Limpar limpa os filtros, NAO o cliente em foco (10/09/2026, tarde): dentro
// de um cliente, "todos os clientes" e o item Terminais da lateral.
$limpar = $escopo ? shield_url_com_empresa('/terminais.php', $fkEmpresa) : '/terminais.php';
?>

<div class="topo-tela">
    <div>
        <div class="trilha">
            <a href="/clientes.php">Clientes</a><span>/</span>
            <?php if ($escopo): ?>
                <a href="/ver_empresa.php?id=<?= $fkEmpresa; ?>"><?= shield_h((string) $empresaSelecionada['razao']); ?></a><span>/</span>
            <?php endif; ?>
            <span>Terminais</span>
        </div>
        <h1 class="h4 mb-1">Terminais</h1>
        <p class="text-secondary small mb-0">
            As m&aacute;quinas cadastradas e se cada uma deu sinal nos &uacute;ltimos
            <?= SHIELD_PARQUE_DIAS_SUMIDO; ?> dias.
        </p>
    </div>
    <div class="acoes-pagina">
        <?php /* So o Voltar. A contagem ja esta no cartao "Cadastrados" logo abaixo,
                 e o monitoramento esta na lateral -- os dois aqui eram repeticao. */ ?>
        <a href="<?= shield_h(shield_voltar_cliente((int) $fkEmpresa)); ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i>Voltar
        </a>
    </div>
</div>

<?php if ($escopo): ?>
    <?php /* A barra "Cliente em foco" saiu em 10/09/2026: a trilha e a lateral ja dizem onde se esta. */ ?>
<?php endif; ?>

<?php /* SUCESSO FLUTUA; ERRO E "CONFIRME" FICAM (14/09/2026). Excluido e
         apelido gravado sao resposta a um clique e somem sozinhos no canto
         (funcoes/ui/aviso.php); os outros dois pedem alguma coisa de quem
         esta olhando, e continuam aqui. */ ?>
<?php if (isset($statusMessages[$statusParam]) && $statusMessages[$statusParam]['class'] === 'success'): ?>
    <?php shield_aviso_flutuante($statusMessages[$statusParam]['text'], 'status'); ?>
<?php elseif (isset($statusMessages[$statusParam])): ?>
    <div class="alert alert-<?= shield_h($statusMessages[$statusParam]['class']); ?>">
        <?= shield_h($statusMessages[$statusParam]['text']); ?>
    </div>
<?php endif; ?>

<?php if ($statusParam === 'deleted_parcial'): ?>
    <?php /* O QUE FOI APAGADO FLUTUA; O QUE FICOU FICA NA TELA (14/09/2026): pede uma
             coisa a quem le -- liberar a vaga das caladas -- e some em cinco segundos
             nao daria tempo. Com zero apagado nao ha aviso, so a faixa. */ ?>
    <?php shield_aviso_flutuante($apagadosEmMassa === 1 ? '1 terminal apagado.' : ($apagadosEmMassa > 1 ? $apagadosEmMassa . ' terminais apagados.' : ''), 'status'); ?>
    <?php if ($ficaramPartes): ?>
        <?php $ficaramTotal = $ficaramTrabalhando + $ficaramCaladas; ?>
        <div class="alert alert-warning">
            <?= $ficaramTotal === 1 ? 'Ficou 1 terminal' : 'Ficaram ' . $ficaramTotal . ' terminais'; ?> deste cliente, porque ainda <?= $ficaramTotal === 1 ? 'ocupa' : 'ocupam'; ?> vaga:
            <?= implode('; ', $ficaramPartes); ?>.
        </div>
    <?php endif; ?>
<?php endif; ?>
<?php shield_aviso_flutuante($avisoTerminal, '', $avisoTerminalDemorado); ?>
<?php if ($erroTerminal !== ''): ?>
    <div class="alert alert-danger"><?= shield_h($erroTerminal); ?></div>
<?php endif; ?>

<?php /* Os QUATRO ESTADOS antes da tabela (fatia 3). Cada numero filtra a
         lista, e os quatro somam o cadastrado -- faixas exclusivas. A "calada"
         e o que a tela chamava de "sem sinal" e a cota ainda contava; a "vaga
         livre" e o que ja devolveu a vaga e fica atras do filtro. */ ?>
<div class="row g-3 mb-3" data-tour="terminais-numeros">
    <?php
    $notas = array(
        'trabalhando' => 'deram sinal nos &uacute;ltimos ' . SHIELD_PARQUE_DIAS_SUMIDO . ' dias',
        // A QUEBRA E ESCRITA, e nao deixada a largura (14/09/2026): a nota
        // quebrava num lugar num quarto de tela e em outro com a janela um
        // pouco maior. Assim as duas linhas tem quase o mesmo tamanho nos
        // tres cartoes, em qualquer largura em que caibam.
        'calada' => 'sem sinal, mas ainda<br>ocupam vaga at&eacute; o ' . SHIELD_LICENCA_DIAS_FANTASMA . '&ordm; dia',
        'vaga_livre' => 'sem sinal h&aacute; ' . SHIELD_LICENCA_DIAS_FANTASMA . '+ dias:<br>a vaga voltou sozinha',
        'desativada' => 'vaga liberada &agrave; m&atilde;o;<br>reativa se foi engano',
    );
    $classeIndicador = array('ok' => 'ok', 'atencao' => 'atencao', 'neutro' => 'marca', 'erro' => 'erro');
    ?>
    <?php foreach (shield_terminal_estados() as $estadoChave => $estado): ?>
        <div class="col-6 col-lg-3">
            <a class="indicador <?= $classeIndicador[$estado['cor']] ?? 'marca'; ?><?= $situacao === $estadoChave ? ' ativo' : ''; ?>"
               href="<?= shield_h(shield_terminais_filtro($baseQuery, array('situacao' => $situacao === $estadoChave ? '' : $estadoChave))); ?>">
                <i class="fas <?= $estado['icone']; ?> fundo"></i>
                <div class="rotulo"><?= ucfirst($estado['rotulo']); ?></div>
                <div class="valor"><?= $totais[$estadoChave]; ?><span class="parte">/<?= $totalCadastrados; ?></span></div>
                <div class="nota"><?= $notas[$estadoChave]; ?></div>
            </a>
        </div>
    <?php endforeach; ?>
</div>

<div class="card mb-3" data-tour="terminais-filtro">
    <div class="card-body py-3">
        <form method="get" action="/terminais.php" class="row g-2 align-items-end" id="filtroTerminais" autocomplete="off">
            <?php if ($escopo): ?>
                <?php
                // Dentro de um cliente o seletor de empresa sai do ar de proposito.
                // Trocar de empresa por um <select> que continua dizendo "Terminais
                // de FULANO" no titulo e na barra e o caminho curto para o membro
                // apagar a maquina do cliente errado. Para trocar, sai-se do escopo.
                ?>
                <input type="hidden" name="empresa" value="<?= $fkEmpresa; ?>">
                <div class="col-12 col-lg-4">
                    <label class="form-label small mb-1">Cliente</label>
                    <div class="campo-fixo">
                        <span><?= shield_h((string) $empresaSelecionada['razao']); ?></span>
                    </div>
                </div>
            <?php else: ?>
                <div class="col-12 col-lg-4">
                    <label class="form-label small mb-1" for="empresa">Cliente</label>
                    <select name="empresa" id="empresa" class="form-select form-select-sm">
                        <option value="">Todos os clientes</option>
                        <?php foreach ($empresas as $empresaItem): ?>
                            <option value="<?= shield_h($empresaItem['codigo']); ?>"
                                <?= ($fkEmpresa !== null && $fkEmpresa === (int) $empresaItem['codigo']) ? 'selected' : ''; ?>>
                                <?= shield_h($empresaItem['razao']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php endif; ?>

            <div class="col-12 col-sm-6 col-lg-2">
                <label class="form-label small mb-1" for="q">MAC ou computador</label>
                <input id="q" name="q" class="form-control form-control-sm" value="<?= shield_h($q); ?>" maxlength="60"
                       placeholder="Ex.: 00:11:22 ou PDV-01">
            </div>
            <div class="col-12 col-sm-6 col-lg-3">
                <label class="form-label small mb-1" for="situacao">Estado</label>
                <select name="situacao" id="situacao" class="form-select form-select-sm">
                    <option value="">Todas menos vaga livre</option>
                    <?php foreach (shield_terminal_estados() as $estadoChave => $estado): ?>
                        <option value="<?= $estadoChave; ?>" <?= $situacao === $estadoChave ? 'selected' : ''; ?>><?= ucfirst($estado['rotulo']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-lg-3 d-flex gap-2">
                <button type="submit" class="btn btn-primary btn-sm flex-grow-1">
                    <i class="fas fa-search"></i> Filtrar
                </button>
                <a href="<?= shield_h($limpar); ?>" class="btn btn-outline-secondary btn-sm" id="btLimpar">Limpar</a>
            </div>
        </form>
    </div>
</div>

<?php
/**
 * As linhas de uma lista de terminais. Uma funcao porque o mesmo HTML serve
 * a lista corrida (dentro de um cliente) e cada grupo (fora dele) -- e uma
 * coluna a mais num lugar e a menos no outro e o tipo de diferenca que so se
 * ve depois, quando alguem corrige um e esquece o outro.
 */
function shield_terminais_linhas(array $terminais, $corteSumido, $fkEmpresa, $q, $situacao, $page, $comAcoes)
{
    foreach ($terminais as $terminal):
        $visto = trim((string) ($terminal['ULTIMO_ACESSO'] ?? ''));
        // O ESTADO VEM DA FUNCAO, a mesma que filtrou a lista (fatia 3).
        $estado = shield_terminal_estado($terminal);
        // A MAQUINA DA SINAL E A LOJA ESTA PARADA? Sao duas perguntas.
        $parada = shield_terminal_loja_parada($terminal);
        // OS BOTOES DA LINHA vem de shield_terminal_acoes, a mesma funcao que
        // shield_terminais_com_acoes pergunta para decidir se a coluna existe:
        // um if solto aqui podia desenhar botao numa coluna que o cabecalho ja
        // tinha tirado.
        $acoes = shield_terminal_acoes($terminal);

        $deleteQuery = array('codigo' => $terminal['terminal_codigo']);
        if ($fkEmpresa !== null) {
            $deleteQuery['empresa'] = $fkEmpresa;
        }
        if ($q !== '') {
            $deleteQuery['q'] = $q;
        }
        if ($situacao !== '') {
            $deleteQuery['situacao'] = $situacao;
        }
        if ($page > 1) {
            $deleteQuery['page'] = $page;
        }
        $deleteUrl = 'excluir_terminal.php?' . http_build_query($deleteQuery);
        ?>
        <?php
        $desativado = trim((string) ($terminal['DESATIVADO_EM'] ?? '')) !== '';
        $apelido = trim((string) ($terminal['APELIDO'] ?? ''));
        ?>
        <tr<?= $desativado ? ' class="text-secondary"' : ''; ?>>
            <td class="identidade par" data-r="Computador">
                <div>
                    <?php /* O APELIDO NA FRENTE, o nome da maquina atras. Quem
                             liga e o cliente dizendo "o caixa 2 nao abre"; o
                             nome do computador so serve depois, para conferir. */ ?>
                    <span class="nome"><?= $apelido !== '' ? shield_h($apelido) : shield_h((string) $terminal['nome_computador']); ?></span>
                    <span class="pilula pilula-<?= $estado['cor']; ?>"><?= shield_h($estado['rotulo']); ?></span>
                    <?php if ($parada !== null): ?>
                        <?php /* A SEGUNDA PILULA E A LOJA, nao a maquina (11/09/2026).
                                 "Trabalhando" responde "deu sinal e ocupa vaga"; com a
                                 empresa bloqueada o painel manda `status = bloqueada` e o
                                 ERP abre sem deixar fazer nada. Duas perguntas, duas
                                 respostas, lado a lado -- e nao um estado inventado, que
                                 faria a lista e os contadores discordarem. */ ?>
                        <span class="pilula pilula-<?= $parada['cor']; ?>"><?= $parada['rotulo']; ?></span>
                    <?php endif; ?>
                    <span class="apoio">#<?= (int) $terminal['terminal_codigo']; ?></span>
                </div>
                <?php if ($parada !== null && $estado['chave'] === 'trabalhando'): ?>
                    <div class="apoio" style="color: var(--<?= $parada['cor']; ?>)">
                        d&aacute; sinal, mas o painel responde n&atilde;o: o ERP abre e n&atilde;o opera
                    </div>
                <?php endif; ?>
                <?php if ($apelido !== ''): ?>
                    <div class="apoio"><?= shield_h((string) $terminal['nome_computador']); ?></div>
                <?php endif; ?>
                <?php /* "sem sinal ha 10 dias - ocupa vaga ate 09/10": so na calada,
                         que e a unica em que a tela diz uma coisa e a cota faz outra. */ ?>
                <?php if ($estado['detalhe'] !== '' && $estado['chave'] !== 'trabalhando'): ?>
                    <div class="apoio" style="color: var(--<?= $estado['cor'] === 'neutro' ? 'neutro' : $estado['cor']; ?>)"><?= shield_h($estado['detalhe']); ?></div>
                <?php endif; ?>
                <form method="post" class="d-flex gap-1 mt-1" style="max-width: 15rem">
                    <input type="hidden" name="acao_terminal" value="apelido">
                    <input type="hidden" name="terminal" value="<?= (int) $terminal['terminal_codigo']; ?>">
                    <input type="text" name="apelido" class="form-control form-control-sm" maxlength="40"
                           value="<?= shield_h($apelido); ?>" placeholder="apelido, ex. Caixa 2">
                    <button class="btn btn-sm btn-outline-secondary" title="Gravar apelido">ok</button>
                </form>
            </td>
            <?php /* SEM QUEBRA (14/09/2026): com a largura fixa a coluna para de
                     alargar sozinha, e pouco acima do modo cartao o MAC descia em
                     duas linhas nos hifens. */ ?>
            <td class="meio text-nowrap" data-r="MAC"><?= shield_h((string) $terminal['mac']); ?></td>
            <td class="meio" data-r="Vers&atilde;o">
                <?= $terminal['VERSAO_EXE'] !== null && $terminal['VERSAO_EXE'] !== ''
                    ? shield_h((string) $terminal['VERSAO_EXE']) : '&mdash;'; ?>
            </td>
            <td class="meio" data-r="&Uacute;ltimo sinal"><?= shield_h(shield_parque_ha_quanto($visto)); ?></td>
            <?php if ($comAcoes): ?>
            <td class="meio" data-r="A&ccedil;&otilde;es">
                <span class="acoes">
                    <?php /* LIBERAR A VAGA so aparece para quem esta sem sinal.
                             Botao que desliga o caixa de uma loja nao pode estar
                             a um clique de distancia numa maquina que trabalha
                             -- a guarda tambem esta no servidor, la em cima. */ ?>
                    <?php if (in_array('reativar', $acoes, true)): ?>
                        <form method="post" class="d-inline">
                            <input type="hidden" name="acao_terminal" value="reativar">
                            <input type="hidden" name="terminal" value="<?= (int) $terminal['terminal_codigo']; ?>">
                            <button class="acao" title="Reativar: volta a disputar vaga">
                                <i class="fas fa-arrow-left"></i></button>
                        </form>
                    <?php elseif (in_array('liberar', $acoes, true)): ?>
                        <form method="post" class="d-inline"
                              onsubmit="return confirm('Liberar a vaga desta maquina? Ela para de receber licenca e a vaga fica livre para outra. Da para reativar depois.');">
                            <input type="hidden" name="acao_terminal" value="desativar">
                            <input type="hidden" name="terminal" value="<?= (int) $terminal['terminal_codigo']; ?>">
                            <button class="acao" title="Liberar a vaga desta maquina">
                                <i class="fas fa-times-circle"></i></button>
                        </form>
                    <?php elseif (in_array('trocar', $acoes, true)): ?>
                        <?php /* TROCAR DE COMPUTADOR (14/09/2026): a unica acao de uma maquina
                                 trabalhando, e so quando o cliente tem outra maquina de fora por
                                 cota cheia. Nao e formulario na linha: abre o modal que pede o
                                 nome do computador digitado, e o POST confere tudo de novo. */ ?>
                        <?php /* SEM RECUSA, LIBERAR AGORA (01/10/2026): o mesmo modal, o mesmo
                                 nome digitado, outro texto -- o modal le data-recusada vazio. */ ?>
                        <?php $recusaLinha = (array) ($terminal['recusa_por_cota'] ?? array()); ?>
                        <?php $comRecusa = trim((string) ($recusaLinha['batido_em'] ?? '')) !== ''; ?>
                        <button type="button" class="acao perigo"
                                title="<?= $comRecusa ? 'Trocar de computador: liberar a vaga desta m&aacute;quina' : 'Liberar a vaga agora (m&aacute;quina em uso, como a do suporte numa convers&atilde;o)'; ?>"
                                aria-label="<?= $comRecusa ? 'Trocar de computador: liberar a vaga de ' : 'Liberar agora a vaga de '; ?><?= shield_h((string) $terminal['nome_computador']); ?>"
                                data-bs-toggle="modal" data-bs-target="#modalTrocar"
                                data-codigo="<?= (int) $terminal['terminal_codigo']; ?>"
                                data-empresa="<?= (int) $terminal['fk_empresa']; ?>"
                                data-nome="<?= shield_h((string) $terminal['nome_computador']); ?>"
                                data-rotulo="<?= shield_h(shield_terminal_rotulo($terminal)); ?>"
                                data-cliente="<?= shield_h((string) $terminal['razao']); ?>"
                                data-com-recusa="<?= $comRecusa ? '1' : ''; ?>"
                                data-recusada="<?= shield_h(trim((string) ($recusaLinha['nome_computador'] ?? ''))); ?>"
                                data-recusada-em="<?= $comRecusa ? shield_h(date('d/m H:i', strtotime((string) $recusaLinha['batido_em']))) : ''; ?>">
                            <i class="fas <?= $comRecusa ? 'fa-sync-alt' : 'fa-times-circle'; ?>"></i></button>
                    <?php endif; ?>
                    <?php /* APAGAR so o que ja nao trabalha: vaga livre e desativada.
                             Maquina trabalhando ou calada tem historico que ainda
                             serve; apagar e uma linha InnoDB e e seguro, mas nao
                             precisa estar a um clique numa maquina que abre caixa. */ ?>
                    <?php if (in_array('apagar', $acoes, true)): ?>
                    <button type="button" class="acao perigo"
                            title="Excluir terminal"
                            aria-label="Excluir o terminal <?= shield_h((string) $terminal['nome_computador']); ?>"
                            data-bs-toggle="modal" data-bs-target="#modalExcluir"
                            data-codigo="<?= (int) $terminal['terminal_codigo']; ?>"
                            data-nome="<?= shield_h((string) $terminal['nome_computador']); ?>"
                            data-mac="<?= shield_h((string) $terminal['mac']); ?>"
                            data-cliente="<?= shield_h((string) $terminal['razao']); ?>">
                        <i class="fas fa-trash"></i></button>
                    <?php endif; ?>
                </span>
            </td>
            <?php endif; ?>
        </tr>
    <?php endforeach;
}

/**
 * A coluna "Acoes" existe quando alguma linha da tabela tem botao. A maquina
 * trabalhando nao tem nenhum (shield_terminal_acoes), e ela e quase todo o
 * parque: a coluna aparecia vazia em todo grupo saudavel.
 */
function shield_terminais_com_acoes(array $terminais)
{
    foreach ($terminais as $terminal) {
        if (shield_terminal_acoes($terminal) !== array()) {
            return true;
        }
    }

    return false;
}

/* AS TRES COLUNAS DO MEIO TEM LARGURA FIXA (14/09/2026). Cada grupo e uma
   tabela propria, e com largura automatica cada uma punha o MAC num lugar:
   dois grupos abertos, um embaixo do outro, e as colunas andavam em
   zigue-zague. Com a mesma porcentagem os grupos se alinham; o computador
   leva o resto, porque carrega apelido, pilulas e o campo do apelido. */
function shield_terminais_cabecalho($comAcoes)
{
    ?>
    <thead>
        <tr>
            <th scope="col">Computador</th>
            <th scope="col" class="meio" style="width:18%">MAC</th>
            <th scope="col" class="meio" style="width:12%">Vers&atilde;o</th>
            <th scope="col" class="meio" style="width:16%">&Uacute;ltimo sinal</th>
            <?php if ($comAcoes): ?>
                <th scope="col" class="meio" style="width:1%">A&ccedil;&otilde;es</th>
            <?php endif; ?>
        </tr>
    </thead>
    <?php
}

/* Fora de um cliente, as maquinas vem AGRUPADAS por cliente e cada grupo
   abre no clique. Dezessete linhas com o nome do cliente repetido em cada
   uma nao se leem; sete cabecalhos com o total e o estado de cada um, sim. */
$grupos = array();
if (!$escopo) {
    foreach ($terminais as $t) {
        $chave = (int) $t['fk_empresa'];
        if (!isset($grupos[$chave])) {
            $grupos[$chave] = array('razao' => (string) $t['razao'], 'vivos' => 0, 'estados' => array(), 'linhas' => array());
        }
        $estadoLinha = shield_terminal_estado($t)['chave'];
        $grupos[$chave]['estados'][$estadoLinha] = ($grupos[$chave]['estados'][$estadoLinha] ?? 0) + 1;
        if ($estadoLinha === 'trabalhando') {
            $grupos[$chave]['vivos']++;
        }
        $grupos[$chave]['linhas'][] = $t;
    }
    uasort($grupos, static function ($a, $b) {
        return strcasecmp($a['razao'], $b['razao']);
    });
}
?>

<?php if (empty($terminais)): ?>
    <div class="card">
        <div class="vazio">
            <i class="fas fa-desktop"></i>
            <?php if ($q !== '' || $situacao !== ''): ?>
                Nenhum terminal com esses filtros.
                <a href="<?= shield_h($limpar); ?>">Limpar e ver todos</a>.
            <?php else: ?>
                Nenhuma m&aacute;quina cadastrada ainda. Ela aparece aqui sozinha
                na primeira vez que o ERP abrir com a licen&ccedil;a assinada.
            <?php endif; ?>
        </div>
    </div>
<?php elseif ($escopo): ?>
    <div class="card">
        <div class="table-responsive">
            <?php $comAcoes = shield_terminais_com_acoes($terminais); ?>
            <table class="lista folga">
                <?php shield_terminais_cabecalho($comAcoes); ?>
                <tbody>
                <?php shield_terminais_linhas($terminais, $corteSumido, $fkEmpresa, $q, $situacao, $page, $comAcoes); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php else: ?>
    <div class="grupos-terminais">
    <?php foreach ($grupos as $codigo => $g): ?>
        <?php $total = count($g['linhas']); $sumidos = $total - $g['vivos']; ?>
        <details class="card grupo-terminais">
            <summary>
                <span class="grupo-nome">
                    <i class="fas fa-building"></i>
                    <?= shield_h($g['razao']); ?>
                </span>
                <span class="grupo-resumo">
                    <?php foreach (shield_terminal_estados() as $estadoChave => $estado): ?>
                        <?php if (!empty($g['estados'][$estadoChave])): ?>
                            <span class="pilula pilula-<?= $estado['cor']; ?>"><?= (int) $g['estados'][$estadoChave]; ?> <?= $estado['rotulo']; ?></span>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    <span class="grupo-total num"><?= $total; ?> m&aacute;quina<?= $total == 1 ? '' : 's'; ?></span>
                    <i class="fas fa-sort-down grupo-seta"></i>
                </span>
            </summary>
            <div class="table-responsive">
                <?php $comAcoes = shield_terminais_com_acoes($g['linhas']); ?>
                <table class="lista folga">
                    <?php shield_terminais_cabecalho($comAcoes); ?>
                    <tbody>
                    <?php shield_terminais_linhas($g['linhas'], $corteSumido, $fkEmpresa, $q, $situacao, $page, $comAcoes); ?>
                    </tbody>
                </table>
            </div>
        </details>
    <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php /* Confirmar aqui, sem sair da tela: a outra pagina fazia o membro
         perder a lista e o filtro para responder uma pergunta de um sim. O POST
         continua indo para excluir_terminal.php, que confere o cliente em foco
         antes de apagar. */ ?>
<div class="modal fade" id="modalExcluir" tabindex="-1" aria-labelledby="modalExcluirTitulo" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="post" action="/excluir_terminal.php" class="modal-content">
            <input type="hidden" name="confirmar" value="sim">
            <input type="hidden" name="codigo" id="excluirCodigo" value="">
            <?php if ($fkEmpresa !== null): ?>
                <input type="hidden" name="empresa" value="<?= (int) $fkEmpresa; ?>">
            <?php endif; ?>
            <?php if ($q !== ''): ?>
                <input type="hidden" name="q" value="<?= shield_h($q); ?>">
            <?php endif; ?>
            <?php if ($page > 1): ?>
                <input type="hidden" name="page" value="<?= (int) $page; ?>">
            <?php endif; ?>
            <div class="modal-header">
                <h2 class="modal-title h6 mb-0" id="modalExcluirTitulo">Excluir terminal</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <p class="mb-2">
                    Apagar <strong id="excluirNome"></strong>
                    <span class="text-secondary">(<span id="excluirMac" class="num"></span>)</span>
                    de <strong id="excluirCliente"></strong>?
                </p>
                <p class="text-secondary small mb-0">
                    A m&aacute;quina some do cadastro e do monitoramento. Se o ERP dela abrir de novo
                    com a licen&ccedil;a ligada, ela se cadastra sozinha outra vez.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-danger btn-sm">
                    <i class="fas fa-trash me-1"></i>Excluir
                </button>
            </div>
        </form>
    </div>
</div>

<?php /* TROCAR DE COMPUTADOR (14/09/2026). A pergunta e digitar o nome do
         computador, e nao um "sim": o botao desliga um caixa que esta vendendo,
         e o nome obriga a olhar qual e. So o nome do Windows vale, nunca o
         apelido (shield_terminal_nome_confere). O modal so fecha no X e no
         Cancelar -- fundo estatico e Esc desligado --, porque um clique fora
         por engano jogaria fora o que foi digitado. O confirmar nasce
         desabilitado e o JS o acorda quando o nome bate; o POST confere de
         novo, porque JavaScript se desliga. */ ?>
<div class="modal fade" id="modalTrocar" tabindex="-1" aria-labelledby="modalTrocarTitulo" aria-hidden="true"
     data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
        <form method="post" class="modal-content" id="formTrocar" autocomplete="off">
            <input type="hidden" name="acao_terminal" value="trocar">
            <input type="hidden" name="terminal" id="trocarCodigo" value="">
            <input type="hidden" name="empresa_terminal" id="trocarEmpresa" value="">
            <div class="modal-header">
                <h2 class="modal-title h6 mb-0" id="modalTrocarTitulo">Trocar de computador</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <p class="mb-2" id="trocarTextoTroca">
                    Liberar a vaga de <strong id="trocarRotulo"></strong> em <strong id="trocarCliente"></strong>
                    para a m&aacute;quina nova <strong id="trocarRecusada"></strong>, recusada por cota cheia
                    em <span id="trocarRecusadaEm" class="num"></span>.
                </p>
                <?php /* SEM RECUSA (01/10/2026): o caso da maquina tecnica. O texto diz para que
                         serve, porque o botao agora existe em todo caixa trabalhando. */ ?>
                <p class="mb-2 d-none" id="trocarTextoAgora">
                    Liberar agora a vaga de <strong id="trocarRotuloAgora"></strong> em <strong id="trocarClienteAgora"></strong>.
                    &Eacute; para a m&aacute;quina que n&atilde;o deve ocupar a cota, como a do suporte depois de uma
                    convers&atilde;o de banco: ela n&atilde;o precisa esperar os tr&ecirc;s dias sem sinal.
                </p>
                <div class="alert alert-warning small mb-3">
                    A m&aacute;quina desta linha <strong>para na pr&oacute;xima abertura do ERP</strong>: deixa de
                    receber licen&ccedil;a e n&atilde;o opera mais. Confirme s&oacute; com ela j&aacute; fora de uso,
                    e nunca no caixa da loja. Se foi engano, reative esta m&aacute;quina: com a cota cheia, reativar &eacute; recusado.
                </div>
                <label class="form-label small mb-1" for="trocarNome">
                    Para confirmar, digite o nome do computador: <strong class="num" id="trocarNomeMostra"></strong>
                </label>
                <input type="text" class="form-control form-control-sm" id="trocarNome" name="nome_confirmado"
                       maxlength="50" autocomplete="off" autocapitalize="characters" spellcheck="false">
                <div class="form-text">O nome do Windows, e n&atilde;o o apelido. Mai&uacute;scula ou min&uacute;scula tanto faz.</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-danger btn-sm" id="trocarConfirmar" disabled>
                    <i class="fas fa-sync-alt me-1"></i>Liberar a vaga
                </button>
            </div>
        </form>
    </div>
</div>

<script>
(function () {
  var modal = document.getElementById('modalExcluir');
  if (modal) {
    modal.addEventListener('show.bs.modal', function (ev) {
      var b = ev.relatedTarget;
      if (!b) { return; }
      document.getElementById('excluirCodigo').value = b.getAttribute('data-codigo');
      document.getElementById('excluirNome').textContent = b.getAttribute('data-nome');
      document.getElementById('excluirMac').textContent = b.getAttribute('data-mac');
      document.getElementById('excluirCliente').textContent = b.getAttribute('data-cliente');
    });
  }

  // TROCAR DE COMPUTADOR: o confirmar so acorda quando o nome digitado bate com
  // o do computador, sem diferenca de caixa nem de espaco nas pontas -- a mesma
  // conta de shield_terminal_nome_confere, que o POST refaz.
  var trocar = document.getElementById('modalTrocar');
  if (trocar) {
    var campo = document.getElementById('trocarNome');
    var confirmar = document.getElementById('trocarConfirmar');
    var esperado = '';
    var normal = function (s) { return String(s || '').trim().toUpperCase(); };
    var conferir = function () { confirmar.disabled = esperado === '' || normal(campo.value) !== esperado; };
    trocar.addEventListener('show.bs.modal', function (ev) {
      var b = ev.relatedTarget;
      if (!b) { return; }
      var nome = b.getAttribute('data-nome') || '';
      document.getElementById('trocarCodigo').value = b.getAttribute('data-codigo');
      document.getElementById('trocarEmpresa').value = b.getAttribute('data-empresa');
      document.getElementById('trocarRotulo').textContent = b.getAttribute('data-rotulo') || nome;
      document.getElementById('trocarCliente').textContent = b.getAttribute('data-cliente');
      document.getElementById('trocarRecusada').textContent = b.getAttribute('data-recusada') || 'sem nome';
      document.getElementById('trocarRecusadaEm').textContent = b.getAttribute('data-recusada-em');
      // Com recusa e a troca de computador; sem, a liberacao da maquina em uso
      // (01/10/2026). O POST e o mesmo: quem decide qual dos dois e o servidor.
      var comRecusa = b.getAttribute('data-com-recusa') === '1';
      document.getElementById('trocarTextoTroca').classList.toggle('d-none', !comRecusa);
      document.getElementById('trocarTextoAgora').classList.toggle('d-none', comRecusa);
      document.getElementById('trocarRotuloAgora').textContent = b.getAttribute('data-rotulo') || nome;
      document.getElementById('trocarClienteAgora').textContent = b.getAttribute('data-cliente');
      document.getElementById('modalTrocarTitulo').textContent = comRecusa ? 'Trocar de computador' : 'Liberar a vaga agora';
      document.getElementById('trocarNomeMostra').textContent = nome;
      // Abrir de novo sempre comeca vazio: o nome digitado para uma maquina nao
      // pode ficar valendo para a proxima linha clicada.
      esperado = normal(nome);
      campo.value = '';
      conferir();
    });
    // O foco vai ao campo quando o modal termina de abrir: antes disso o
    // Bootstrap devolve o foco ao proprio modal.
    trocar.addEventListener('shown.bs.modal', function () { campo.focus(); });
    campo.addEventListener('input', conferir);
    document.getElementById('formTrocar').addEventListener('submit', function (ev) {
      conferir();
      if (confirmar.disabled) { ev.preventDefault(); return; }
      // Duplo clique nao manda dois POST: o segundo so leria "ja estava liberada".
      confirmar.disabled = true;
    });
  }

  // Limpar esvazia os campos ANTES de navegar. Quando nao havia filtro na URL,
  // o destino era a mesma pagina e o navegador devolvia o texto digitado --
  // parecia que o botao nao fazia nada.
  var limpar = document.getElementById('btLimpar');
  var form = document.getElementById('filtroTerminais');
  if (limpar && form) {
    limpar.addEventListener('click', function () {
      form.querySelectorAll('input[type="search"], input[type="text"]').forEach(function (i) { i.value = ''; });
      form.querySelectorAll('select').forEach(function (s) { s.selectedIndex = 0; });
    });
  }
}());
</script>

<?php if ($totalPages > 1): ?>
    <?php
    $startPage = max(1, $page - 2);
    $endPage = min($totalPages, $page + 2);
    ?>
    <nav class="mt-3" aria-label="P&aacute;ginas de terminais">
        <ul class="pagination pagination-sm justify-content-center mb-0">
            <li class="page-item <?= $page <= 1 ? 'disabled' : ''; ?>">
                <a class="page-link" href="<?= shield_h(shield_terminais_url($baseQuery + array('page' => max(1, $page - 1)))); ?>">&laquo;</a>
            </li>
            <?php for ($i = $startPage; $i <= $endPage; $i++): ?>
                <li class="page-item <?= $i === $page ? 'active' : ''; ?>">
                    <a class="page-link" href="<?= shield_h(shield_terminais_url($baseQuery + array('page' => $i))); ?>"><?= $i; ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?= $page >= $totalPages ? 'disabled' : ''; ?>">
                <a class="page-link" href="<?= shield_h(shield_terminais_url($baseQuery + array('page' => min($totalPages, $page + 1)))); ?>">&raquo;</a>
            </li>
        </ul>
    </nav>
<?php endif; ?>

<?php if ($escopo && ($q !== '' || $totais['vaga_livre'] + $totais['desativada'] > 0)): ?>
    <?php
    // A limpeza em massa desce para o pe da tela. Botao que apaga o parque
    // inteiro de um cliente ao lado do "Filtrar" e acidente esperando data.
    // DESDE 14/09/2026 ELA SO LEVA O QUE NAO OCUPA VAGA (vaga livre e
    // desativada), e o botao aparece quando ha alguma. Antes dependia da lista
    // visivel, que esconde a vaga livre, e sumia justo no cliente em que so havia
    // o que apagar. Com busca os cartoes contam so o que casou e a limpeza e do
    // cliente inteiro: o botao fica, e a confirmacao diz os numeros.
    $bulkParams = array('empresa' => $fkEmpresa, 'q' => $q, 'page' => $page);
    ?>
    <p class="text-end mt-3 mb-0">
        <a href="excluir_terminais_empresa.php?<?= shield_h(http_build_query($bulkParams)); ?>"
           class="btn btn-outline-danger btn-sm">
            <i class="fas fa-trash-alt me-1"></i>Excluir os terminais deste cliente que n&atilde;o ocupam vaga
        </a>
    </p>
<?php endif; ?>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
