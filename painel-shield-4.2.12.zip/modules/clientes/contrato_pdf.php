<?php
/**
 * O PDF do contrato de um cliente, para o membro -- 01/10/2026.
 *
 * Com aceite, sai o texto QUE FOI ACEITO, guardado no registro, com o aceite no
 * fim -- e nao o modelo de hoje, que pode ter mudado. Sem aceite, sai o texto de
 * agora marcado como minuta: e o que o membro usa para conferir o modelo antes
 * de ligar o aceite.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/contrato/contrato.php';

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

$codigo = (int) ($_GET['empresa'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM empresa WHERE codigo = :c LIMIT 1');
$stmt->execute(array(':c' => $codigo));
$empresa = $stmt->fetch(PDO::FETCH_ASSOC);
if (!is_array($empresa)) {
    http_response_code(404);
    echo 'Cliente nao encontrado.';
    exit;
}

$s = shield_contrato_situacao($pdo, $empresa);
// "?minuta=1" pede o texto de hoje mesmo com aceite antigo: e o que o membro abre
// para ver o que o cliente vai ler quando o aceite estiver pendente de novo.
$aceite = empty($_GET['minuta']) ? $s['aceite'] : null;
$texto = $aceite !== null ? (string) $aceite['texto'] : $s['texto'];
$hash = $aceite !== null ? (string) $aceite['hash'] : $s['hash'];

shield_contrato_enviar_pdf(
    shield_contrato_pdf($texto, $hash, $aceite, $empresa),
    shield_contrato_nome_arquivo($empresa, $aceite !== null)
);
