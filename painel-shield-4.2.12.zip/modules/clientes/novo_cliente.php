<?php
/**
 * Cadastrar cliente a mao - 16/09/2026, pedido de um membro.
 *
 * "Ja fechei o valor da ativacao, mas so instalo semana que vem -- da para
 * deixar o cliente cadastrado?" Ate aqui nao dava: a empresa so nascia quando
 * o ERP dela ligava, e a volta era abrir o ERP numa base limpa no proprio
 * computador -- o que registrava a MAQUINA DO MEMBRO como terminal da loja e
 * fazia o teste comecar ali, semanas antes de a loja existir de verdade.
 *
 * A REGRA DE NEGOCIO MORA EM funcoes/empresa/cadastro.php, e nao aqui: a tela
 * so conduz. Ela recusa com a frase que a funcao devolve, sem inventar texto
 * proprio -- a mesma recusa serve para quem um dia chamar a funcao de outro
 * lugar (importacao, API).
 *
 * NAO LIBERA LICENCA. A loja nasce sem validade, como a que chega sozinha:
 * quem libera e o pagamento ou a cortesia da primeira fatura. Aqui so se deixa
 * a loja pronta para o contrato.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/empresa/cadastro.php';
require_once __DIR__ . '/../../funcoes/ui/aviso.php';

$erro = '';
$form = array(
    'cnpj' => '', 'razao' => '', 'fone' => '', 'email' => '',
    'teste' => 'primeira_maquina', 'teste_ate' => '',
);
$regras = shield_teste_config($pdo);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    foreach (array_keys($form) as $campo) {
        $form[$campo] = trim((string) ($_POST[$campo] ?? ''));
    }

    try {
        $codigo = shield_cliente_cadastrar($pdo, $form);
        // A ficha do cliente e o lugar certo de cair: dali se da inicio ao
        // contrato, que e o passo seguinte de quem acabou de cadastrar.
        header('Location: /ver_empresa.php?id=' . (int) $codigo . '&ok=cadastrado');
        exit;
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
}

$page_title = 'Cadastrar cliente';
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <div class="trilha"><span>Ainda n&atilde;o &eacute; cliente</span><span>/</span><span>Cadastrar cliente</span></div>
        <h1 class="h4 mb-1">Cadastrar cliente</h1>
        <p class="text-secondary small mb-0">
            Para quem fechou o neg&oacute;cio antes de instalar. A loja entra na lista agora, sem m&aacute;quina nenhuma,
            e quando o ERP dela ligar com este CNPJ ela cai neste mesmo cadastro.
        </p>
    </div>
</div>

<?php if ($erro !== ''): ?>
    <div class="alert alert-warning"><?= shield_h($erro); ?></div>
<?php endif; ?>

<div class="card mb-3">
    <div class="card-body">
        <form method="post" action="/novo_cliente.php" class="row g-3" autocomplete="off">
            <div class="col-12 col-lg-4">
                <label class="form-label small mb-1" for="cnpj">CNPJ <span class="text-danger">*</span></label>
                <input id="cnpj" name="cnpj" class="form-control form-control-sm" required
                       inputmode="numeric" maxlength="18" placeholder="00.000.000/0000-00"
                       value="<?= shield_h($form['cnpj']); ?>">
                <div class="form-text small">
                    Tem de ser o MESMO que est&aacute; no cadastro da empresa dentro do ERP &mdash; &eacute; por ele que
                    o painel reconhece a loja quando ela instalar. Pode digitar com ou sem pontua&ccedil;&atilde;o.
                </div>
            </div>
            <div class="col-12 col-lg-5">
                <label class="form-label small mb-1" for="razao">Nome do cliente <span class="text-danger">*</span></label>
                <input id="razao" name="razao" class="form-control form-control-sm" required maxlength="50"
                       value="<?= shield_h($form['razao']); ?>">
                <div class="form-text small">Como voc&ecirc; chama essa loja. O ERP n&atilde;o troca este nome depois.</div>
            </div>
            <div class="col-12 col-lg-3">
                <label class="form-label small mb-1" for="fone">Telefone</label>
                <input id="fone" name="fone" class="form-control form-control-sm" maxlength="20"
                       value="<?= shield_h($form['fone']); ?>">
            </div>
            <div class="col-12 col-lg-5">
                <label class="form-label small mb-1" for="email">E-mail</label>
                <input id="email" name="email" type="email" class="form-control form-control-sm" maxlength="120"
                       value="<?= shield_h($form['email']); ?>">
                <div class="form-text small">
                    O que faltar aqui &mdash; endere&ccedil;o, bairro, cidade &mdash; o pr&oacute;prio ERP preenche
                    na primeira vez que a loja ligar.
                </div>
            </div>

            <div class="col-12">
                <h2 class="h6 mb-1">Per&iacute;odo de teste</h2>
                <label class="marcar d-block small mb-1">
                    <input type="radio" name="teste" value="primeira_maquina" <?= $form['teste'] === 'primeira_maquina' ? 'checked' : ''; ?>>
                    Come&ccedil;a quando a primeira m&aacute;quina ligar
                    <span class="text-secondary">&mdash; <?= (int) $regras['dias']; ?> dias a partir da instala&ccedil;&atilde;o. &Eacute; o que voc&ecirc; quer se ainda n&atilde;o sabe o dia.</span>
                </label>
                <label class="marcar d-block small mb-1">
                    <input type="radio" name="teste" value="data" <?= $form['teste'] === 'data' ? 'checked' : ''; ?>>
                    Termina numa data que eu escolho
                    <input type="date" name="teste_ate" class="form-control form-control-sm d-inline-block ms-1"
                           style="max-width: 11rem" value="<?= shield_h($form['teste_ate']); ?>">
                </label>
                <label class="marcar d-block small mb-2">
                    <input type="radio" name="teste" value="sem" <?= $form['teste'] === 'sem' ? 'checked' : ''; ?>>
                    Sem teste
                    <span class="text-secondary">&mdash; j&aacute; vendi; vou dar in&iacute;cio ao contrato agora.</span>
                </label>
            </div>

            <div class="col-12">
                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-plus-circle me-1"></i>Cadastrar</button>
                <a href="/avaliacao.php" class="btn btn-outline-secondary btn-sm">Voltar</a>
                <span class="form-text d-block mt-2">
                    A loja nasce <strong>sem licen&ccedil;a</strong>, como qualquer outra: quem libera o sistema &eacute; o
                    pagamento, ou a caixa de libera&ccedil;&atilde;o no in&iacute;cio do contrato.
                </span>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
