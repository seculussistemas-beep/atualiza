<?php

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}



$codigo = isset($_GET['codigo']) && filter_var($_GET['codigo'], FILTER_VALIDATE_INT)
    ? (int) $_GET['codigo']
    : (isset($_POST['codigo']) && filter_var($_POST['codigo'], FILTER_VALIDATE_INT) ? (int) $_POST['codigo'] : 0);

$fkEmpresa = shield_empresa_contexto_id($_GET);
if ($fkEmpresa === null) {
    $fkEmpresa = shield_empresa_contexto_id($_POST);
}

$q = trim((string) ($_GET['q'] ?? $_POST['q'] ?? ''));
$page = isset($_GET['page']) && filter_var($_GET['page'], FILTER_VALIDATE_INT)
    ? (int) $_GET['page']
    : (isset($_POST['page']) && filter_var($_POST['page'], FILTER_VALIDATE_INT) ? (int) $_POST['page'] : null);
$page = ($page !== null && $page > 0) ? $page : null;
$error = '';

if ($codigo <= 0) {
    header('Location: ' . shield_terminal_redirect_url('error', $fkEmpresa, $q, $page));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['confirmar'] ?? '') === 'sim') {
        try {
            // O DELETE saiu daqui para shield_excluir_terminal, que grava no
            // livro nome, MAC e apelido da maquina -- 09/09/2026. O cliente em
            // foco continua sendo guarda: link antigo nao apaga maquina alheia.
            require_once __DIR__ . '/../../funcoes/empresa/exclusao.php';
            if (shield_excluir_terminal($pdo, $codigo, $fkEmpresa)) {
                header('Location: ' . shield_terminal_redirect_url('deleted_one', $fkEmpresa, $q, $page));
                exit;
            }

            header('Location: ' . shield_terminal_redirect_url('error', $fkEmpresa, $q, $page));
            exit;
        } catch (PDOException $exception) {
            header('Location: ' . shield_terminal_redirect_url('error', $fkEmpresa, $q, $page));
            exit;
        } catch (RuntimeException $recusa) {
            // A MAQUINA TRABALHA OU AINDA OCUPA VAGA (14/09/2026): a funcao
            // recusou e nada foi apagado. Volta para a lista, que ja mostra o
            // estado de agora, com a faixa dizendo por que. O catch do banco
            // fica ANTES: PDOException tambem e RuntimeException, e erro de
            // banco nao pode virar "maquina trabalhando".
            header('Location: ' . shield_terminal_redirect_url('recusado_apagar', $fkEmpresa, $q, $page));
            exit;
        }
    }

    $error = 'Voce precisa confirmar a exclusao marcando a caixa de selecao.';
}
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>


<div class="container-fluid mt-4">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 fw-bold text-danger">Excluir Terminal</h6>
        </div>
        <div class="card-body">
            <?php if ($error !== ''): ?>
                <div class="alert alert-danger"><?= shield_h($error); ?></div>
            <?php else: ?>
                <p>Tem certeza de que deseja excluir o terminal <strong>#<?= shield_h($codigo); ?></strong>?</p>
                <p class="text-danger">Esta acao e irreversivel.</p>
            <?php endif; ?>

            <form method="post" action="excluir_terminal.php">
                <input type="hidden" name="codigo" value="<?= shield_h($codigo); ?>">
                <?php if ($fkEmpresa !== null && $fkEmpresa > 0): ?>
                    <input type="hidden" name="empresa" value="<?= shield_h($fkEmpresa); ?>">
                <?php endif; ?>
                <?php if ($q !== ''): ?>
                    <input type="hidden" name="q" value="<?= shield_h($q); ?>">
                <?php endif; ?>
                <?php if ($page !== null && $page > 1): ?>
                    <input type="hidden" name="page" value="<?= shield_h($page); ?>">
                <?php endif; ?>

                <div class="form-check mb-3">
                    <input type="checkbox" class="form-check-input" id="confirmar" name="confirmar" value="sim">
                    <label class="form-check-label" for="confirmar">Sim, tenho certeza</label>
                </div>

                <button type="submit" class="btn btn-danger">Excluir Terminal</button>
                <a href="<?= shield_h(shield_terminal_redirect_url(null, $fkEmpresa, $q, $page)); ?>" class="btn btn-secondary">Cancelar</a>
            </form>
        </div>
    </div>
</div>



<?php include __DIR__ . '/../../templates/fecha.php'; ?>
