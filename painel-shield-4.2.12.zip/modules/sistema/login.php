<?php

require_once __DIR__ . '/../../banco.php';

require_once __DIR__ . '/../../funcoes/nucleo/sessao.php'; shield_sessao_abrir();

$error = '';
$setup_message = '';
$softhouse_pending_message = '';
$register_message = '';
$hasUsers = false;

try {
    if (function_exists('shield_table_exists') && shield_table_exists($pdo, 'usuario')) {
        $hasUsers = (int) $pdo->query('SELECT COUNT(*) FROM usuario')->fetchColumn() > 0;
    }
} catch (Throwable $exception) {
    $hasUsers = false;
}

if (!$hasUsers) {
    $register_message = 'Nenhum usuario cadastrado. Clique em Cadastrar para definir e-mail e senha de acesso.';
}

if (isset($_GET['setup']) && $_GET['setup'] === 'done') {
    $setup_message = 'Cadastro inicial concluido com sucesso. Entre com seu usuario administrador.';
}
if (isset($_GET['cadastro']) && $_GET['cadastro'] === 'ok') {
    $setup_message = 'Acesso criado. Entre com o e-mail e a senha que você acabou de cadastrar.';
}
if (isset($_GET['softhouse']) && $_GET['softhouse'] === 'pending') {
    $softhouse_pending_message = 'A sua empresa ainda nao esta cadastrada. Voce pode concluir depois, em Minha empresa.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cadastrar']) && !$hasUsers) {
    header('Location: /install/setup.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['entrar']) && $hasUsers) {
    $loginInput = trim((string) ($_POST['login'] ?? ''));
    $senha = trim((string) ($_POST['senha'] ?? ''));

    require_once __DIR__ . '/../../funcoes/acesso/limite_login.php';
    $bloqueio = shield_login_bloqueado($pdo, $loginInput);

    if ($loginInput === '' || $senha === '') {
        $error = 'O e-mail/login e a senha sao obrigatorios.';
    } elseif ($bloqueio !== null) {
        // Barra ANTES de conferir a senha. Conferir e depois recusar gastaria
        // o bcrypt a cada tentativa -- que e o custo que o atacante quer impor
        // ao servidor -- e ainda vazaria, pelo tempo de resposta, se a senha
        // estava certa.
        $error = $bloqueio;
    } else {
        $stmt = $pdo->prepare('SELECT * FROM usuario WHERE login = :credential OR email = :credential LIMIT 1');
        $stmt->bindValue(':credential', $loginInput, PDO::PARAM_STR);
        $stmt->execute();

        // Um caminho so para as duas formas de falhar -- usuario inexistente e
        // senha errada. Antes eram dois blocos com mensagens DIFERENTES, e a
        // diferenca entregava quais e-mails tem conta no painel: bastava varrer
        // uma lista e ler a resposta, sem acertar senha nenhuma. Como um bloco
        // so, as duas nao tem como divergir de novo numa edicao futura.
        $usuario = $stmt->rowCount() === 1 ? $stmt->fetch(PDO::FETCH_ASSOC) : null;

        if (is_array($usuario) && password_verify($senha, (string) ($usuario['senha'] ?? ''))) {
                session_regenerate_id(true);
                $_SESSION['usuario'] = $usuario;

                // Entrou: zera o que havia contra este login e este IP. Sem
                // isto, quem errou quatro vezes e acertou na quinta seguiria a
                // um passo do bloqueio pelo resto da janela.
                shield_login_limpar($pdo, $loginInput);
                shield_login_faxina($pdo);

                // Fica no livro: e o "ultimo acesso" do perfil (03/09/2026).
                try {
                    require_once __DIR__ . '/../../funcoes/cobranca/cobranca.php';
                    if (function_exists('shield_auditar')) {
                        shield_auditar($pdo, 'entrou', array(
                            'alvo_tipo' => 'usuario',
                            'alvo_id' => (int) $usuario['id'],
                            'detalhe' => substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 120),
                        ));
                    }
                } catch (Throwable $ignorado) {
                    // Auditoria nunca impede a entrada.
                }

                // "Manter conectado": cookie de 30 dias que recria a sessao
                // quando a do PHP expirar (ver includes/sessao_lembrada.php).
                if (!empty($_POST['lembrar'])) {
                    try {
                        require_once __DIR__ . '/../../funcoes/acesso/sessao_lembrada.php';
                        shield_lembrar_gravar_cookie(shield_lembrar_criar(
                            $pdo,
                            (int) $usuario['id'],
                            (string) ($_SERVER['REMOTE_ADDR'] ?? ''),
                            (string) ($_SERVER['HTTP_USER_AGENT'] ?? '')
                        ));
                    } catch (Throwable $ignorado) {
                        // Migracao pendente ou banco fora: entra sem lembrar.
                    }
                }

                header('Location: index.php');
                exit;
            }

        $error = 'Usuario ou senha invalidos.';
        shield_login_registrar_falha($pdo, $loginInput);
    }
}
?>
<?php
require_once __DIR__ . '/../../templates/entrada.php';
shield_entrada_abrir($hasUsers ? 'Entrar' : 'Primeiro acesso');
?>
                <h2><?= $hasUsers ? 'Entrar' : 'Primeiro acesso'; ?></h2>
                <?php /* QUEM ENTRA AQUI E A EQUIPE DO PAINEL (14/09/2026): "cadastrado pela
                         softhouse" falava com o cliente da softhouse, que o cadastro pelo login
                         trazia para ca. O cliente final entra pelo link da area dele. */ ?>
                <p class="sub"><?= $hasUsers ? 'Use o e-mail ou login de acesso ao painel.' : 'Ainda não há usuário. Cadastre o administrador para começar.'; ?></p>

                <?php if (!empty($setup_message)): ?>
                    <div class="alert alert-success" role="status"><?= htmlspecialchars($setup_message, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
                <?php if (!empty($softhouse_pending_message)): ?>
                    <div class="alert alert-warning" role="status"><?= htmlspecialchars($softhouse_pending_message, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
                <?php if (!empty($register_message)): ?>
                    <div class="alert alert-info" role="status"><?= htmlspecialchars($register_message, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>

                <form action="login.php" method="post" id="loginForm" data-valida novalidate>
                    <?php if ($hasUsers): ?>
                        <div class="campo">
                            <label for="login">E-mail ou login</label>
                            <input type="text" name="login" id="login" placeholder="voce@softhouse.com.br" autocomplete="username" required minlength="3"
                                   value="<?= isset($_POST['login']) ? htmlspecialchars((string) $_POST['login'], ENT_QUOTES, 'UTF-8') : ''; ?>" maxlength="255">
                            <div class="aviso">Informe seu e-mail ou login.</div>
                        </div>
                        <div class="campo">
                            <label for="senha">Senha</label>
                            <div class="senha-caixa">
                                <input type="password" class="senha" name="senha" id="senha" placeholder="Sua senha" autocomplete="current-password" required minlength="4">
                                <?= shield_entrada_olho(); ?>
                            </div>
                            <div class="aviso">Informe sua senha.</div>
                        </div>
                        <div class="linha">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="lembrar" name="lembrar">
                                <label class="form-check-label" for="lembrar">Manter conectado</label>
                            </div>
                            <a href="esqueci_senha.php">Esqueci a senha</a>
                        </div>
                        <?php /* O valor vai num hidden: o botao e desabilitado no submit e botao desabilitado nao entra no POST. */ ?>
                        <input type="hidden" name="entrar" value="1">
                        <button type="submit" class="entrar" data-enviando="Entrando…"><span class="giro" aria-hidden="true"></span><span>Entrar no painel</span></button>
                    <?php else: ?>
                        <button type="submit" name="cadastrar" value="1" class="entrar">Cadastrar administrador</button>
                    <?php endif; ?>
                </form>
                <?php /* SEM O CADASTRO DE CLIENTE (14/09/2026, confirmado pelo dono): a conta
                         que ele criava (acesso '3') caia na area do cliente, que desde 10/09/2026
                         so abre com o e-mail e a senha da LOJA. A conta nova nao abria nada. */ ?>
<?php
shield_entrada_fechar();
