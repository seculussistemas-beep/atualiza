<?php
/**
 * Inicio -- 25/08/2026.
 *
 * DUAS PERGUNTAS, NESTA ORDEM: como esta a minha carteira, e o que precisa de
 * mim hoje.
 *
 * A versao anterior respondia so a segunda, e o comentario que estava aqui
 * defendia isso -- "o membro nao abre o painel para saber quanto faturou".
 * Estava incompleto: ele nao abre SO por isso, mas tocar um negocio de
 * licencas sem nunca ver o retrato dele e dirigir olhando o retrovisor. A
 * fila de trabalho continua inteira, agora DEPOIS do retrato, que e a ordem
 * em que a pergunta se faz.
 *
 * A CAMADA DE RETRATO NAO INVENTA CONTA NENHUMA: sai de
 * `funcoes/ui/painel_numeros.php`, que classifica pelo MESMO funil da lista de
 * clientes e da ficha. Painel que conta diferente da tela que ele abre e o
 * defeito que a Central de Notificacoes do ERP ja pagou.
 *
 * BLOCO SEM DADO SE EXPLICA, e nunca vira retangulo em branco. Nao e capricho:
 * na base de dev NAO HA cobranca, assinatura nem movimento de validade -- zero
 * linhas nas tres --, entao o caminho "sem dado" e o unico que se ve aqui, e
 * seria tambem o primeiro que o membro veria no dia em que instalasse. Ele
 * precisa dizer o que faz o dado aparecer.
 *
 * O GRAFICO E SVG ESCRITO A MAO. O painel roda no servidor do membro, que pode
 * nao ter internet de saida: CDN de biblioteca de grafico e uma tela em branco
 * esperando um arquivo que nunca chega. Mesma regra dos paineis novos do ERP.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/licenca/parque.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca_motor.php';
require_once __DIR__ . '/../../funcoes/licenca/situacao.php';
require_once __DIR__ . '/../../funcoes/ui/painel_numeros.php';
require_once __DIR__ . '/../../funcoes/nucleo/cofre.php';
require_once __DIR__ . '/../../funcoes/licenca/certificado.php';

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

// "Limpar agora" da nota de falhas resolvidas (16/09/2026). Da por visto o que
// ja passou; erro novo volta a aparecer. Redirect depois do POST: F5 nao repete.
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && (string) ($_POST['acao'] ?? '') === 'limpar_falhas') {
    shield_licenca_falhas_limpar($pdo);
    header('Location: /index.php');
    exit;
}

$softhousePendente = !shield_has_softhouse($pdo);
$erro = '';
$erroTipo = '';

// A poda do historico de batidas roda no maximo uma vez por dia, e quem a
// dispara e quem abre o painel: nao ha cron garantido na hospedagem do membro.
try {
    shield_parque_compactar($pdo);
} catch (Throwable $ignorado) {
    // Faxina que falha nao pode impedir a tela de abrir.
}

$vencidos = array();
$semLicenca = array();
$acabando = array();
$aReceber = array();
$sumidos = array();
$certificados = array();
$parque = array('terminais' => 0, 'vivos' => 0, 'sumidos' => 0,
                'excedentes' => 0, 'contratados' => 0, 'versoes' => 0);
$versoes = array();
$carteira = array('faixas' => array(), 'total' => 0);
$dinheiro = array('disponivel' => false, 'recebido_mes' => 0, 'recebimentos' => 0,
                  'a_receber' => 0, 'titulos' => 0, 'vencido' => 0);
$meses = array();
$atividade = array();
$clientesComRecusa = 0;
$vencimentos = array('atrasadas' => 0, 'hoje' => 0, 'proximos7' => 0,
                     'ate_fim_do_mes' => 0, 'dias' => array(), 'maior_dia' => 0,
                     'mensais' => 0, 'com_recorrencia' => 0, 'total' => 0);

try {
    $carteira = shield_painel_carteira($pdo);
    $dinheiro = shield_painel_dinheiro($pdo);
    $meses = shield_painel_meses($pdo, 12);
    $atividade = shield_painel_atividade($pdo, 30);
    $clientesComRecusa = shield_painel_clientes_com_recusa($pdo, 30);
    $vencimentos = shield_painel_vencimentos($pdo);
    $parque = shield_parque_resumo($pdo);
    $versoes = shield_parque_versoes($pdo);

    $stmt = $pdo->query(
        "SELECT codigo, razao, cnpj, validade_licenca
           FROM empresa
          WHERE validade_licenca IS NOT NULL
            AND validade_licenca < CURDATE()
          ORDER BY validade_licenca DESC LIMIT 6"
    );
    $vencidos = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();

    // A pergunta mora em painel_numeros.php desde 14/09/2026: foi esta consulta
    // que derrubou a Central no MySQL 8, e escrita aqui ela nao cabia num teste
    // com a sessao em modo estrito.
    $semLicenca = shield_painel_sem_licenca($pdo, 6);

    // QUEM O FUNIL CHAMA DE "VENCE", e nao uma janela propria. Com renovacao
    // mensal a diferenca e enorme: na janela de 15 dias ha 11 clientes, e 9
    // deles tem assinatura ativa -- a barra logo acima os conta como "Em dia"
    // e este bloco os listava como pendencia. Dois numeros certos na mesma
    // tela dizendo coisas diferentes sobre o mesmo cliente.
    //
    // Filtrar em PHP e nao em SQL e deliberado: a regra de "quem renova
    // sozinho nao e alarme" mora no funil, e reescreve-la aqui como JOIN seria
    // a terceira definicao de vencendo neste repositorio.
    $stmt = $pdo->prepare(
        "SELECT codigo, razao, cnpj, validade_licenca, bloqueado, suspenso_em
           FROM empresa
          WHERE validade_licenca IS NOT NULL
            AND validade_licenca BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL :dias DAY)
          ORDER BY validade_licenca"
    );
    $stmt->bindValue(':dias', SHIELD_VENCE_EM_BREVE, PDO::PARAM_INT);
    $stmt->execute();
    $auto = shield_renovam_sozinho($pdo);
    $acabando = array();
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $e) {
        $s = shield_situacao_licenca($e, isset($auto[(int) $e['codigo']]));
        if ($s['chave'] === 'vence') {
            $acabando[] = $e;
            if (count($acabando) >= 6) { break; }
        }
    }

    if (shield_cobranca_tabelas_existem($pdo)) {
        $stmt = $pdo->prepare(
            'SELECT c.id, c.descricao, c.valor_centavos, c.vencimento, c.situacao,
                    e.razao, e.codigo AS empresa
               FROM cobranca c LEFT JOIN empresa e ON e.codigo = c.fk_empresa
              WHERE c.situacao IN (:aberta, :vencida)
              ORDER BY c.vencimento LIMIT 6'
        );
        $stmt->execute(array(':aberta' => SHIELD_COB_ABERTA, ':vencida' => SHIELD_COB_VENCIDA));
        $aReceber = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
    }

    // DO MAIS RECENTE PARA O MAIS ANTIGO -- o inverso do que a tela do Parque
    // quer. La a ordem por tempo parado serve para faxina; aqui isto e fila de
    // trabalho, e quem parou ONTEM e a noticia: da para ligar antes de o
    // cliente ligar. Quem parou ha quatro meses e maquina desativada, e
    // ocupava as seis linhas do bloco.
    $sumidos = shield_parque_terminais($pdo, array('situacao' => 'sumido'));
    usort($sumidos, function ($a, $b) {
        return strcmp((string) ($b['ULTIMO_ACESSO'] ?? ''), (string) ($a['ULTIMO_ACESSO'] ?? ''));
    });
    $sumidos = array_slice($sumidos, 0, 6);

    // O CERTIFICADO DIGITAL VIRA DECISAO (05/10/2026): a NF-e da loja para no dia
    // em que ele vence, e o ERP so avisa a loja. O membro ve aqui antes do
    // telefonema -- e e venda: renovar o A1 costuma ser servico dele.
    $certificados = shield_certificado_vencendo($pdo, 30, 6);

} catch (Throwable $e) {
    $erro = $e->getMessage();
    $erroTipo = shield_banco_erro_tipo($e);
}

if (!function_exists('shield_ha')) {
    /** Ha quanto tempo, em palavra de gente. */
    function shield_ha($data)
    {
        $dias = (int) (new DateTimeImmutable('today'))
            ->diff(new DateTimeImmutable(substr((string) $data, 0, 10)))->format('%r%a');
        if ($dias === 0) {
            return 'hoje';
        }

        return $dias > 0 ? 'em ' . $dias . ' dia(s)' : 'h&aacute; ' . abs($dias) . ' dia(s)';
    }
}

$ativos = (int) ($carteira['faixas']['valido'] ?? 0) + (int) ($carteira['faixas']['vence'] ?? 0);
$totalClientes = (int) $carteira['total'];
$totalPendente = count($vencidos) + count($semLicenca) + count($acabando)
    + count($aReceber) + count($sumidos) + count($certificados);

// Serie so vira grafico se tiver o que mostrar -- linha reta no zero ocupa o
// lugar da frase que explicaria por que nao ha dado.
$temMeses = shield_painel_tem_serie($meses, array('renovacoes', 'recebido'));
$temAtividade = shield_painel_tem_serie($atividade, array('ok', 'recusa'));

// CONSULTA DE LICENCA COM ERRO (15/09/2026): o ERP segue com a ultima licenca
// guardada e nenhum bloqueio chega a loja, entao a Central tem de dizer.
$falhasLicenca = shield_licenca_falhas_recentes($pdo);
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <div class="trilha"><span>Central de opera&ccedil;&atilde;o</span></div>
        <h1 class="h4 mb-0">Central de opera&ccedil;&atilde;o</h1>
        <p class="text-secondary small mb-0">
            Carteira de licen&ccedil;as, sa&uacute;de dos ERPs e as pr&oacute;ximas decis&otilde;es do dia
        </p>
    </div>
    <?php /* So quando. Os atalhos para Clientes e Monitorar sairam: estao na
             lateral, a um clique, e aqui so repetiam. O nome de quem olha saiu em
             06/10/2026: ja esta na bolinha da conta, no canto, e aqui so repetia.
             O relogio anda no navegador -- e o que diz "esta tela esta viva". */ ?>
    <div class="acoes-pagina">
        <span class="quem-agora">
            <span class="text-secondary"><?= date('d/m/Y'); ?> &middot;</span>
            <span class="num" id="relogioAgora"><?= date('H:i:s'); ?></span>
        </span>
    </div>
</div>

<?php if ($erro !== ''): ?>
    <?php /* O QUE FAZER VEM ANTES DO DETALHE -- 14/09/2026. A primeira instalacao
             em MySQL 8 mostrou so a frase do banco, e o membro nao tinha como
             saber que a saida estava com a hospedagem. O detalhe fica, pequeno e
             escapado: e ele que o suporte pede, a tela e so de administrador, e
             a mensagem do PDO traz o codigo e a frase do servidor, nunca a
             consulta nem a senha. */ ?>
    <div class="alert alert-danger">
        <strong>N&atilde;o consegui montar o in&iacute;cio.</strong>
        <?php if ($erroTipo === 'modo'): ?>
            O banco de dados desta hospedagem est&aacute; num modo mais r&iacute;gido do que o
            painel usa, e o ajuste que o painel faz ao conectar n&atilde;o bastou. Pe&ccedil;a ao
            suporte da hospedagem para tirar <code>NO_ZERO_DATE</code>, <code>NO_ZERO_IN_DATE</code>
            e <code>ONLY_FULL_GROUP_BY</code> do <code>sql_mode</code> do banco e recarregue esta
            p&aacute;gina. Se continuar, mande esta tela ao suporte do painel.
        <?php else: ?>
            Recarregue a p&aacute;gina. Se continuar, mande esta tela ao suporte do painel.
        <?php endif; ?>
        <div class="small mt-2 text-break">Detalhe t&eacute;cnico, para o suporte: <?= shield_h($erro); ?></div>
    </div>
<?php endif; ?>

<?php if ($falhasLicenca !== null): ?>
    <?php /* CONSULTA DE LICENCA COM ERRO (15/09/2026). Recusa sai assinada e nao conta
             aqui; erro e o painel que nao conseguiu responder. O caso que trouxe este
             aviso: a chave privada ilegivel depois de instalar do zero sobre o banco
             antigo, dias sem nenhum bloqueio chegar as lojas e sem nada na Central. */ ?>
    <?php $explicaFalha = shield_cofre_falha_explicada($falhasLicenca['motivo']); ?>
    <?php if ((int) $falhasLicenca['lojas_ainda_com_erro'] > 0): ?>
    <div class="alert alert-danger">
        <strong><?= (int) $falhasLicenca['lojas_ainda_com_erro']; ?> loja(s) sem conseguir licen&ccedil;a</strong>:
        <?= (int) $falhasLicenca['quantas']; ?> consulta(s) deram erro nas &uacute;ltimas 24 horas,
        a &uacute;ltima em <?= shield_h(date('d/m H:i', strtotime($falhasLicenca['ultima_em']))); ?>.
        Enquanto der erro, essas lojas seguem com a &uacute;ltima licen&ccedil;a que receberam, por at&eacute; 7 dias, e nenhum
        bloqueio do painel chega a elas.
        <?php if ($explicaFalha !== ''): ?>
            <div class="mt-2"><?= shield_h($explicaFalha); ?> <a href="/emissor_licenca.php" class="alert-link">Abrir Chaves</a>.</div>
        <?php else: ?>
            <div class="small mt-2 text-break">Motivo registrado, para o suporte: <?= shield_h($falhasLicenca['motivo']); ?></div>
        <?php endif; ?>
    </div>
    <?php else: ?>
    <?php /* JA PASSOU (16/09/2026): toda loja que errou voltou a assinar depois. Fica
             como nota, nao como alarme, e some sozinha quando o erro sair da janela
             de 24 h -- membro leu o vermelho como defeito fixo na tela. */ ?>
    <div class="alert alert-secondary small">
        <strong>Resolvido:</strong> <?= (int) $falhasLicenca['quantas']; ?> consulta(s) de licen&ccedil;a deram erro nas
        &uacute;ltimas 24 horas (a &uacute;ltima em <?= shield_h(date('d/m H:i', strtotime($falhasLicenca['ultima_em']))); ?>),
        e desde ent&atilde;o o painel assinou <?= (int) $falhasLicenca['assinadas_depois']; ?> consulta(s) &mdash; nenhuma loja
        continua sem licen&ccedil;a. Esta nota some sozinha 24 horas depois do &uacute;ltimo erro.
        <form method="post" action="/index.php" class="d-inline ms-2">
            <input type="hidden" name="acao" value="limpar_falhas">
            <button type="submit" class="btn btn-outline-secondary btn-sm py-0">Limpar agora</button>
        </form>
    </div>
    <?php endif; ?>
<?php endif; ?>

<?php if ($softhousePendente): ?>
    <div class="alert alert-warning">
        O cadastro da sua empresa est&aacute; incompleto &mdash; &eacute; dele que sai o seu nome
        na cobran&ccedil;a e no e-mail do cliente.
        <a href="/editar_softhouse.php" class="alert-link">Completar agora</a>.
    </div>
<?php endif; ?>

<!-- ============================================================ o retrato -->
<div class="row g-3 mb-3" data-tour="inicio-numeros">
    <div class="col-6 col-xl-3">
        <a class="indicador ok" href="/clientes.php?filter_tipo_validade=em_dia">
            <i class="fas fa-building fundo"></i>
            <div class="rotulo">Clientes com licen&ccedil;a</div>
            <div class="valor"><?= $ativos; ?><span class="parte"> / <?= $totalClientes; ?></span></div>
            <div class="nota">
                <?php if ($totalClientes > $ativos): ?>
                    <?= $totalClientes - $ativos; ?> sem licen&ccedil;a v&aacute;lida
                <?php else: ?>
                    a carteira inteira em dia
                <?php endif; ?>
            </div>
        </a>
    </div>
    <div class="col-6 col-xl-3">
        <a class="indicador <?= (int) $parque['sumidos'] > 0 ? 'atencao' : 'marca'; ?>" href="/parque.php">
            <i class="fas fa-desktop fundo"></i>
            <div class="rotulo">Caixas dando sinal</div>
            <div class="valor"><?= (int) $parque['vivos']; ?><span class="parte"> / <?= (int) $parque['terminais']; ?></span></div>
            <div class="nota">
                <?php if ((int) $parque['sumidos'] > 0): ?>
                    <?= (int) $parque['sumidos']; ?> parado<?= (int) $parque['sumidos'] == 1 ? '' : 's'; ?>
                    h&aacute; mais de <?= SHIELD_PARQUE_DIAS_SUMIDO; ?> dias
                <?php else: ?>
                    todo o parque respondendo
                <?php endif; ?>
            </div>
        </a>
    </div>
    <div class="col-6 col-xl-3">
        <?php if ($dinheiro['disponivel']): ?>
            <a class="indicador ok" href="/cobrancas.php">
                <i class="fas fa-money-bill-wave fundo"></i>
                <div class="rotulo">Recebido em <?= date('m/Y'); ?></div>
                <div class="valor">R$ <?= shield_h(shield_dinheiro((int) $dinheiro['recebido_mes'])); ?></div>
                <div class="nota">
                    <?= (int) $dinheiro['recebimentos']; ?>
                    recebimento<?= (int) $dinheiro['recebimentos'] == 1 ? '' : 's'; ?> no m&ecirc;s
                </div>
            </a>
        <?php else: ?>
            <a class="indicador" href="/formas_recebimento.php">
                <i class="fas fa-money-bill-wave fundo"></i>
                <div class="rotulo">Recebido no m&ecirc;s</div>
                <div class="valor"><span class="parte">&mdash;</span></div>
                <div class="nota">voc&ecirc; ainda n&atilde;o cobra pelo painel</div>
            </a>
        <?php endif; ?>
    </div>
    <div class="col-6 col-xl-3">
        <?php if ($dinheiro['disponivel']): ?>
            <a class="indicador <?= (int) $dinheiro['vencido'] > 0 ? 'erro' : 'atencao'; ?>" href="/cobrancas.php">
                <i class="fas fa-hourglass-half fundo"></i>
                <div class="rotulo">A receber</div>
                <div class="valor">R$ <?= shield_h(shield_dinheiro((int) $dinheiro['a_receber'])); ?></div>
                <div class="nota">
                    <?php if ((int) $dinheiro['vencido'] >= (int) $dinheiro['a_receber']): ?>
                        tudo j&aacute; vencido &mdash;
                        <?= (int) $dinheiro['titulos']; ?> t&iacute;tulo<?= (int) $dinheiro['titulos'] == 1 ? '' : 's'; ?>
                    <?php elseif ((int) $dinheiro['vencido'] > 0): ?>
                        R$ <?= shield_h(shield_dinheiro((int) $dinheiro['vencido'])); ?> j&aacute; vencido
                    <?php else: ?>
                        <?= (int) $dinheiro['titulos']; ?> t&iacute;tulo<?= (int) $dinheiro['titulos'] == 1 ? '' : 's'; ?> em aberto
                    <?php endif; ?>
                </div>
            </a>
        <?php else: ?>
            <a class="indicador" href="/parque.php">
                <i class="fas fa-layer-group fundo"></i>
                <div class="rotulo">Vers&otilde;es no parque</div>
                <div class="valor"><?= (int) $parque['versoes']; ?></div>
                <div class="nota">quanto mais vers&otilde;es, mais dif&iacute;cil o suporte</div>
            </a>
        <?php endif; ?>
    </div>
</div>

<?php if ((int) $parque['excedentes'] > 0): ?>
    <a class="oportunidade" href="/parque.php?situacao=excedente">
        <i class="fas fa-plus-circle"></i>
        <div>
            <strong><?= (int) $parque['excedentes']; ?>
                caixa<?= (int) $parque['excedentes'] == 1 ? '' : 's'; ?>
                rodando al&eacute;m do contratado.</strong>
            &Eacute; o &uacute;nico n&uacute;mero desta tela que &eacute; receita e n&atilde;o suporte:
            cliente com cinco caixas pagando dois aparece aqui sozinho.
        </div>
        <span class="btn btn-sm btn-primary flex-shrink-0">Ver quem</span>
    </a>
<?php endif; ?>

<div class="row g-3 mb-3">
    <!-- ------------------------------------------------- a carteira inteira -->
    <div class="col-xl-7">
        <div class="card h-100" data-tour="inicio-carteira">
            <div class="cabeca">
                <h2>Carteira de licen&ccedil;as</h2>
                <a class="acessorio" href="/clientes.php">ver a lista</a>
            </div>
            <div class="card-body pt-2">
            <?php if ($totalClientes === 0): ?>
                <div class="sem-dado">
                    <i class="fas fa-building"></i>
                    <div>Nenhum cliente ainda. Eles aparecem aqui sozinhos assim que
                        o ERP se registrar pela primeira vez.</div>
                </div>
            <?php else: ?>
                <div class="carteira-barra">
                    <?php foreach ($carteira['faixas'] as $chave => $quantos):
                        if ($quantos < 1) { continue; }
                        $f = shield_painel_rotulo_faixa($chave);
                        $pc = round($quantos * 100 / $totalClientes, 2);
                        $destino = $f['filtro'] !== ''
                            ? '/clientes.php?filter_tipo_validade=' . $f['filtro'] : '/clientes.php';
                    ?>
                        <a class="<?= $f['cor']; ?>" style="width: <?= $pc; ?>%" href="<?= $destino; ?>"
                           title="<?= $quantos; ?> &middot; <?= $f['rotulo']; ?>"
                           aria-label="<?= $quantos; ?> <?= $f['rotulo']; ?>"></a>
                    <?php endforeach; ?>
                </div>
                <div class="carteira-legenda">
                    <?php foreach ($carteira['faixas'] as $chave => $quantos):
                        if ($quantos < 1) { continue; }
                        $f = shield_painel_rotulo_faixa($chave);
                        $destino = $f['filtro'] !== ''
                            ? '/clientes.php?filter_tipo_validade=' . $f['filtro'] : '/clientes.php';
                    ?>
                        <a href="<?= $destino; ?>">
                            <span class="ponto <?= $f['cor']; ?>"></span>
                            <b><?= $quantos; ?></b> <?= $f['rotulo']; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
                <p class="small text-secondary mb-0 mt-2">
                    Cada faixa abre a lista j&aacute; filtrada.
                    &ldquo;Vencendo&rdquo; s&atilde;o os pr&oacute;ximos <?= SHIELD_VENCE_EM_BREVE; ?> dias.
                </p>

                <?php
                $v = $vencimentos;
                $temRegua = ($v['total'] > 0);
                if ($temRegua): ?>
                    <hr class="my-3">
                    <div class="d-flex justify-content-between align-items-baseline mb-1">
                        <h3 class="h6 mb-0">Vencimentos deste m&ecirc;s</h3>
                        <?php if ($v['mensais'] > 0): ?>
                            <span class="small text-secondary">
                                <?= $v['mensais']; ?> de <?= $v['total']; ?> renovam todo m&ecirc;s
                            </span>
                        <?php endif; ?>
                    </div>
                    <p class="small text-secondary mb-2">
                        Cada cliente tem um dia combinado, e ele volta todo m&ecirc;s.
                        Clique para ver quem &eacute;.
                    </p>

                    <div class="fichas mb-3">
                        <?php if ($v['atrasadas'] > 0): ?>
                            <a class="ficha erro" href="/clientes.php?vence=atrasadas"
                               title="venceram e continuam rodando">
                                <span class="qtd"><?= $v['atrasadas']; ?></span>
                                <span class="quando">atrasada<?= $v['atrasadas'] == 1 ? '' : 's'; ?></span>
                            </a>
                        <?php endif; ?>
                        <a class="ficha<?= $v['hoje'] > 0 ? ' atencao' : ''; ?>"
                           href="/clientes.php?vence=hoje" title="vencem hoje">
                            <span class="qtd"><?= $v['hoje']; ?></span>
                            <span class="quando">hoje</span>
                        </a>
                        <a class="ficha" href="/clientes.php?vence=semana"
                           title="vencem nos proximos 7 dias">
                            <span class="qtd"><?= $v['proximos7']; ?></span>
                            <span class="quando">em 7 dias</span>
                        </a>
                        <?php
                        // Nos ultimos sete dias do mes esta janela NAO EXISTE:
                        // ela comeca no oitavo dia e o mes acaba antes. Mostrar
                        // uma ficha com 0 ali nao e "nenhum cliente", e uma
                        // pergunta sem sentido ocupando lugar.
                        $cabeJanela = (int) date('t') - (int) date('j') > 7;
                        if ($cabeJanela): ?>
                            <a class="ficha" href="/clientes.php?vence=mes"
                               title="vencem depois desta semana, ainda neste m&ecirc;s">
                                <span class="qtd"><?= $v['ate_fim_do_mes']; ?></span>
                                <span class="quando">depois, no m&ecirc;s</span>
                            </a>
                        <?php endif; ?>
                    </div>

                    <?php if ($v['dias']): ?>
                        <?php
                        // A REGUA. Cada risco e um dia do mes; a altura diz
                        // quantos clientes caem nele. Serve para o membro ver
                        // que a carga dele se concentra em 5, 10, 15 e 20 --
                        // e para decidir se aceita mais um cliente no dia 10.
                        $ultimoDia = (int) date('t');
                        $hojeDia = (int) date('j');
                        ?>
                        <div class="regua" aria-label="Clientes por dia de vencimento no m&ecirc;s">
                            <?php for ($d = 1; $d <= $ultimoDia; $d++):
                                $n = isset($v['dias'][$d]) ? $v['dias'][$d] : 0;
                                $alt = $v['maior_dia'] > 0 ? round($n * 100 / $v['maior_dia']) : 0;
                                // Nada de "passou": o dia 5 nao ficou para
                                // tras, ele volta em setembro. So o hoje marca.
                                $classe = ($d === $hojeDia) ? ' hoje' : '';
                            ?>
                                <span class="dia<?= $classe; ?><?= $n === 0 ? ' zero' : ''; ?>"
                                      title="dia <?= $d; ?>: <?= $n; ?> cliente<?= $n == 1 ? '' : 's'; ?>">
                                    <span class="risco" style="height: <?= max($alt, 3); ?>%"></span>
                                </span>
                            <?php endfor; ?>
                        </div>
                        <div class="regua-legenda">
                            <span>dia 1</span>
                            <span class="marca-hoje">hoje &eacute; dia <?= $hojeDia; ?></span>
                            <span>dia <?= $ultimoDia; ?></span>
                        </div>
                        <p class="small text-secondary mb-0 mt-1">
                            Cada risco &eacute; um dia do m&ecirc;s e a altura diz quantos clientes
                            renovam nele &mdash; todo m&ecirc;s, sempre nos mesmos dias.
                        </p>
                        <?php
                        // O pico e a informacao que ninguem tem hoje: sem ele
                        // o membro so descobre a concentracao no dia em que
                        // ela vira fila.
                        $pico = array_keys($v['dias'], $v['maior_dia']);
                        if ($v['maior_dia'] > 1 && $pico): ?>
                            <p class="small text-secondary mb-0 mt-2">
                                O seu dia mais cheio &eacute; o
                                <strong><?= (int) $pico[0]; ?></strong>,
                                com <?= $v['maior_dia']; ?> vencimentos.
                            </p>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- -------------------------------------------------- versoes no parque -->
    <div class="col-xl-5">
        <div class="card h-100" data-tour="inicio-versoes">
            <div class="cabeca">
                <h2>Vers&otilde;es rodando</h2>
                <a class="acessorio" href="/parque.php">ver o parque</a>
            </div>
            <div class="card-body pt-2">
            <?php if (!$versoes): ?>
                <div class="sem-dado">
                    <i class="fas fa-layer-group"></i>
                    <div>Nenhum terminal registrado ainda.</div>
                </div>
            <?php else:
                $maiorVersao = 0;
                foreach ($versoes as $v) { $maiorVersao = max($maiorVersao, (int) $v['terminais']); }
                // A referencia e a versao MAIS ALTA, e nao a mais numerosa: o
                // que interessa e quem ficou para tras, nao quem e maioria.
                $nomes = array();
                foreach ($versoes as $v) {
                    if (preg_match('/^\d/', (string) $v['versao'])) { $nomes[] = (string) $v['versao']; }
                }
                usort($nomes, 'version_compare');
                $topo = $nomes ? end($nomes) : '';
            ?>
                <div class="ranking">
                    <?php foreach (array_slice($versoes, 0, 6) as $v):
                        $semNome = !preg_match('/^\d/', (string) $v['versao']);
                        $atual = ((string) $v['versao'] === $topo);
                        $pc = $maiorVersao > 0 ? round((int) $v['terminais'] * 100 / $maiorVersao) : 0;
                    ?>
                        <div class="linha <?= $atual ? 'destaque' : ($semNome ? 'fraca' : ''); ?>">
                            <span<?= $semNome ? ' class="text-secondary"' : ''; ?>><?= shield_h((string) $v['versao']); ?></span>
                            <span class="trilho"><span class="preenche" style="width: <?= $pc; ?>%"></span></span>
                            <span class="qtd"><?= (int) $v['terminais']; ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
                <p class="small text-secondary mb-0 mt-3">
                    <?php if ($topo !== ''): ?>
                        Em verde, a mais nova que algu&eacute;m est&aacute; rodando (<?= shield_h($topo); ?>).
                        Quem ficou para tr&aacute;s s&oacute; recebe a corre&ccedil;&atilde;o no pr&oacute;ximo update.
                    <?php else: ?>
                        Nenhum terminal informou a vers&atilde;o ainda.
                    <?php endif; ?>
                </p>
            <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <!-- ------------------------------------------- renovacoes e recebimento -->
    <div class="col-xl-7">
        <div class="card h-100" data-tour="inicio-renovacoes">
            <div class="cabeca">
                <h2>Renova&ccedil;&otilde;es e recebimento</h2>
                <span class="acessorio text-secondary">12 meses</span>
            </div>
            <div class="card-body pt-2">
            <?php if (!$temMeses): ?>
                <div class="sem-dado">
                    <i class="fas fa-calendar-alt"></i>
                    <div>
                        Ainda n&atilde;o houve renova&ccedil;&atilde;o nem recebimento registrado.
                        Este gr&aacute;fico se preenche sozinho conforme voc&ecirc; estender
                        validades e dar baixa em cobran&ccedil;as.
                    </div>
                </div>
            <?php else:
                // DUAS FAIXAS, e nao duas series num eixo so. Antes o eixo
                // pertencia as renovacoes ("7" e "0" na lateral) e a linha do
                // dinheiro flutuava sem referencia -- a unica pista era a
                // legenda com o maior mes, e com ela ninguem le os outros
                // onze. Cada faixa agora declara o proprio topo.
                //
                // Isto NAO e eixo duplo: eixo duplo e a armadilha oposta, em
                // que as duas series dividem o desenho e o leitor cruza o que
                // nao deve ser cruzado.
                $W = 640; $L = 46; $R = 8;
                $largura = $W - $L - $R;
                $passo = $largura / max(1, count($meses));
                $maxRen = 1; $maxRec = 1;
                foreach ($meses as $m) {
                    $maxRen = max($maxRen, (int) $m['renovacoes']);
                    $maxRec = max($maxRec, (int) $m['recebido']);
                }
                $temRecebido = $maxRec > 1;

                /** O topo do eixo em ordem de grandeza. O centavo exato mora
                 *  no title de cada barra; aqui ele so ocuparia espaco. */
                $curto = function ($centavos) {
                    $reais = $centavos / 100;
                    if ($reais >= 1000) {
                        return 'R$ ' . number_format($reais / 1000, 1, ',', '.') . ' mil';
                    }

                    return 'R$ ' . number_format($reais, 0, ',', '.');
                };
            ?>
                <?php if ($temRecebido): ?>
                    <?php /* `serie-titulo` e `maior`, e nao `faixa-titulo` e `topo`: os dois
                             nomes ja eram do casco. `.topo` e a barra do alto (min-height de
                             3.5rem, fundo, view-transition-name) e virava um bloco cinza de 56px
                             encostado no grafico; `.faixa-titulo` e o h1 da banda de Clientes,
                             que a regra daqui encolhia (14/09/2026). */ ?>
                    <div class="serie-titulo">
                        <span>Recebido</span>
                        <span class="maior">maior m&ecirc;s: <?= shield_h($curto($maxRec)); ?></span>
                    </div>
                    <svg class="grafico" viewBox="0 0 <?= $W; ?> 96" role="img"
                         aria-label="Recebido por m&ecirc;s nos &uacute;ltimos 12 meses">
                        <line class="eixo" x1="<?= $L; ?>" y1="86" x2="<?= $W - $R; ?>" y2="86"></line>
                        <?php foreach ($meses as $i => $m):
                            $bw = max(4, $passo * .56);
                            $bh = 78 * (int) $m['recebido'] / $maxRec;
                            $bx = $L + $passo * $i + ($passo - $bw) / 2;
                            if ($bh <= 0) { continue; } ?>
                            <rect class="barra ganho" x="<?= round($bx, 1); ?>" y="<?= round(86 - $bh, 1); ?>"
                                  width="<?= round($bw, 1); ?>" height="<?= round($bh, 1); ?>" rx="2">
                                <title><?= shield_h($m['rotulo']); ?>: R$ <?= shield_h(shield_dinheiro((int) $m['recebido'])); ?></title>
                            </rect>
                        <?php endforeach; ?>
                        <text class="rotulo" x="<?= $L - 6; ?>" y="14" text-anchor="end"><?= shield_h($curto($maxRec)); ?></text>
                        <text class="rotulo" x="<?= $L - 6; ?>" y="86" text-anchor="end">0</text>
                    </svg>
                <?php endif; ?>

                <div class="serie-titulo<?= $temRecebido ? ' mt-2' : ''; ?>">
                    <span>Renova&ccedil;&otilde;es</span>
                    <span class="maior">maior m&ecirc;s: <?= $maxRen; ?></span>
                </div>
                <svg class="grafico" viewBox="0 0 <?= $W; ?> 96" role="img"
                     aria-label="Renova&ccedil;&otilde;es por m&ecirc;s nos &uacute;ltimos 12 meses">
                    <line class="eixo" x1="<?= $L; ?>" y1="70" x2="<?= $W - $R; ?>" y2="70"></line>
                    <?php foreach ($meses as $i => $m):
                        $bw = max(4, $passo * .56);
                        $bh = 62 * (int) $m['renovacoes'] / $maxRen;
                        $bx = $L + $passo * $i + ($passo - $bw) / 2;
                    ?>
                        <?php if ($bh > 0): ?>
                            <rect class="barra" x="<?= round($bx, 1); ?>" y="<?= round(70 - $bh, 1); ?>"
                                  width="<?= round($bw, 1); ?>" height="<?= round($bh, 1); ?>" rx="2">
                                <title><?= shield_h($m['rotulo']); ?>: <?= (int) $m['renovacoes']; ?> renova&ccedil;&atilde;o(oes)</title>
                            </rect>
                        <?php endif; ?>
                        <text class="rotulo" x="<?= round($L + $passo * $i + $passo / 2, 1); ?>"
                              y="88" text-anchor="middle"><?= shield_h($m['rotulo']); ?></text>
                    <?php endforeach; ?>
                    <text class="rotulo" x="<?= $L - 6; ?>" y="14" text-anchor="end"><?= $maxRen; ?></text>
                    <text class="rotulo" x="<?= $L - 6; ?>" y="70" text-anchor="end">0</text>
                </svg>
            <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ------------------------------------------------ atividade do parque -->
    <div class="col-xl-5">
        <div class="card h-100" data-tour="inicio-consultas">
            <div class="cabeca">
                <h2>Consultas de licen&ccedil;a</h2>
                <span class="acessorio text-secondary">30 dias</span>
            </div>
            <?php /* Coluna flex: e o que deixa o grafico (.grafico-elastico) ocupar a
                     altura que o h-100 da ao cartao, em vez de um vao embaixo da legenda. */ ?>
            <div class="card-body pt-2 d-flex flex-column">
                <p class="small text-secondary mb-2">
                    Toda vez que um caixa abre, ele pergunta ao painel se pode operar.
                    <strong>Aceita</strong> &eacute; licen&ccedil;a em dia;
                    <strong>recusada</strong> &eacute; caixa que perguntou e levou n&atilde;o
                    &mdash; loja parada at&eacute; algu&eacute;m resolver.
                </p>
            <?php if (!$temAtividade): ?>
                <div class="sem-dado">
                    <i class="fas fa-broadcast-tower"></i>
                    <div>
                        Nenhuma consulta de licen&ccedil;a registrada. Ela aparece aqui
                        assim que os caixas come&ccedil;arem a perguntar ao painel.
                    </div>
                </div>
            <?php else:
                // Queda no total = os caixas pararam de perguntar. Subida das
                // recusas = eles perguntam e levam nao. Problemas OPOSTOS, e
                // por isso as duas series ficam separadas em vez de somadas.
                //
                // O DESENHO ESTICA ATE O PE DO CARTAO (14/09/2026). O cartao tem a
                // altura do vizinho (h-100) e o SVG de proporcao fixa deixava um
                // vao em branco embaixo da legenda. H perdeu a faixa das datas
                // (150 -> 132) porque elas sairam do SVG: texto dentro de desenho
                // esticado com preserveAspectRatio="none" sai deformado. A
                // proporcao 460/132 vira o MINIMO no CSS (.grafico-elastico), entao
                // o grafico nunca fica menor que antes. Mudou H aqui, muda la.
                $W = 460; $H = 132; $L = 6; $R = 6; $T = 8; $B = 1;
                $largura = $W - $L - $R; $altura = $H - $T - $B;
                $passo = $largura / max(1, count($atividade));
                $maxDia = 1; $totalOk = 0; $totalRec = 0;
                foreach ($atividade as $d) {
                    $maxDia = max($maxDia, (int) $d['ok'] + (int) $d['recusa']);
                    $totalOk += (int) $d['ok'];
                    $totalRec += (int) $d['recusa'];
                }
            ?>
                <div class="grafico-elastico">
                <svg class="grafico" viewBox="0 0 <?= $W; ?> <?= $H; ?>" preserveAspectRatio="none" role="img"
                     aria-label="Consultas de licen&ccedil;a por dia nos &uacute;ltimos 30 dias">
                    <?php /* non-scaling-stroke: esticado, o eixo engrossaria junto com o desenho. */ ?>
                    <line class="eixo" x1="<?= $L; ?>" y1="<?= $T + $altura; ?>"
                          x2="<?= $W - $R; ?>" y2="<?= $T + $altura; ?>" vector-effect="non-scaling-stroke"></line>
                    <?php foreach ($atividade as $i => $d):
                        $bw = max(2, $passo * .68);
                        $bx = $L + $passo * $i + ($passo - $bw) / 2;
                        $hOk = $altura * (int) $d['ok'] / $maxDia;
                        $hRe = $altura * (int) $d['recusa'] / $maxDia;
                        $base = $T + $altura;
                        if ($hOk > 0): ?>
                            <rect class="barra" x="<?= round($bx, 1); ?>" y="<?= round($base - $hOk, 1); ?>"
                                  width="<?= round($bw, 1); ?>" height="<?= round($hOk, 1); ?>" rx="1">
                                <title><?= shield_h($d['rotulo']); ?>: <?= (int) $d['ok']; ?> aceita(s)</title>
                            </rect>
                        <?php endif;
                        if ($hRe > 0): ?>
                            <rect class="aviso" x="<?= round($bx, 1); ?>" y="<?= round($base - $hOk - $hRe, 1); ?>"
                                  width="<?= round($bw, 1); ?>" height="<?= round($hRe, 1); ?>" rx="1">
                                <title><?= shield_h($d['rotulo']); ?>: <?= (int) $d['recusa']; ?> recusada(s)</title>
                            </rect>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </svg>
                </div>
                <div class="grafico-dias">
                    <?php foreach ($atividade as $i => $d):
                        // De 7 em 7 dias, contando de tras para frente, para
                        // que a ultima marca caia sempre em "hoje".
                        if ((count($atividade) - 1 - $i) % 7 !== 0) { continue; }
                        $ehHoje = ($i === count($atividade) - 1);
                        // Em % da largura, e nao em px: o desenho estica e a data
                        // tem de continuar embaixo do mesmo dia.
                        $onde = round(($L + $passo * $i + $passo / 2) * 100 / $W, 2);
                    ?>
                        <span<?= $ehHoje ? ' class="fim"' : ''; ?> style="left: <?= $onde; ?>%"><?= $ehHoje ? 'hoje' : shield_h($d['rotulo']); ?></span>
                    <?php endforeach; ?>
                </div>
                <div class="carteira-legenda mt-1">
                    <span class="d-inline-flex align-items-baseline gap-1 small">
                        <span class="ponto" style="background: var(--marca)"></span>
                        <?php /* Singular so no 1: com a contagem consertada o primeiro caixa do parque
                                 aparece sozinho, e "1 aceitas" era a primeira coisa que se lia. Zero
                                 continua no plural, que e o certo em portugues. */ ?>
                        <b><?= number_format($totalOk, 0, ',', '.'); ?></b> aceita<?= $totalOk == 1 ? '' : 's'; ?>
                    </span>
                    <span class="d-inline-flex align-items-baseline gap-1 small">
                        <span class="ponto erro"></span>
                        <b><?= number_format($totalRec, 0, ',', '.'); ?></b> recusadas
                        <?php if ($clientesComRecusa > 0): ?>
                            <span class="text-secondary">
                                &mdash; de <?= $clientesComRecusa; ?>
                                cliente<?= $clientesComRecusa == 1 ? '' : 's'; ?>
                            </span>
                        <?php endif; ?>
                    </span>
                </div>
            <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- ================================================ o que precisa de voce -->
<div class="topo-tela mt-4">
    <div>
        <h2 class="h5 mb-0">Pr&oacute;ximas decis&otilde;es</h2>
        <p class="text-secondary small mb-0">
            Cada bloco &eacute; uma decis&atilde;o: abrir o cliente e seguir a a&ccedil;&atilde;o indicada. Bloco vazio &eacute; boa not&iacute;cia.
        </p>
    </div>
    <?php if ($totalPendente > 0): ?>
        <span class="pilula pilula-atencao"><?= (int) $totalPendente; ?> ponto<?= $totalPendente == 1 ? '' : 's'; ?> para olhar</span>
    <?php endif; ?>
</div>

<?php if ($totalPendente === 0): ?>
    <div class="card">
        <div class="vazio">
            <i class="fas fa-check-circle"></i>
            <p class="mb-1"><strong>Nada esperando por voc&ecirc;.</strong></p>
            <p class="mb-0 small">
                Nenhuma licen&ccedil;a vencida, ningu&eacute;m sem licen&ccedil;a, nada a receber
                e todo terminal dando sinal.
            </p>
        </div>
    </div>
<?php endif; ?>

<div class="row g-3 listas-decisao">
    <?php if ($vencidos): ?>
    <div class="col-xl-6">
        <div class="card h-100">
            <div class="cabeca">
                <h2>Licen&ccedil;as vencidas</h2>
                <a class="acessorio" href="/clientes.php?filter_tipo_validade=vencido">ver todas</a>
            </div>
            <div class="table-responsive">
                <table class="lista">
                    <thead><tr>
                        <th scope="col">Cliente</th>
                        <th scope="col" class="num">Venceu</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($vencidos as $c): ?>
                        <tr>
                            <td class="identidade" data-r="Cliente">
                                <div>
                                    <a class="nome" href="/ver_empresa.php?id=<?= (int) $c['codigo']; ?>"><?= shield_h((string) $c['razao']); ?></a>
                                    <span class="apoio"><?= shield_h(shield_cnpj($c['cnpj'])); ?></span>
                                </div>
                            </td>
                            <td class="num" data-r="Venceu">
                                <span class="pilula pilula-erro"><?= shield_ha($c['validade_licenca']); ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($semLicenca): ?>
    <div class="col-xl-6">
        <div class="card h-100">
            <div class="cabeca">
                <h2>Chegaram e ainda n&atilde;o t&ecirc;m licen&ccedil;a</h2>
                <?php /* Para Em avaliacao, e nao para a lista de clientes: o lead
                         saiu de la em 11/09/2026 e o link ficaria vazio. */ ?>
                <a class="acessorio" href="/avaliacao.php">ver todos</a>
            </div>
            <div class="card-body py-2">
                <p class="small text-secondary mb-0">
                    Instalaram, o sistema se cadastrou sozinho e est&aacute; esperando voc&ecirc;
                    definir a validade. &Eacute; o seu canal de venda.
                </p>
            </div>
            <div class="table-responsive">
                <table class="lista">
                    <thead><tr>
                        <th scope="col">Cliente</th>
                        <th scope="col" class="num">Situa&ccedil;&atilde;o</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($semLicenca as $c): ?>
                        <tr>
                            <td class="identidade" data-r="Cliente">
                                <div>
                                    <a class="nome" href="/ver_empresa.php?id=<?= (int) $c['codigo']; ?>"><?= shield_h((string) $c['razao']); ?></a>
                                    <span class="apoio"><?= shield_h(shield_cnpj($c['cnpj'])); ?></span>
                                </div>
                            </td>
                            <td class="num" data-r="Situa&ccedil;&atilde;o">
                                <span class="pilula pilula-venda">sem licen&ccedil;a</span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($acabando): ?>
    <div class="col-xl-6">
        <div class="card h-100">
            <div class="cabeca">
                <h2>Licen&ccedil;as vencendo</h2>
                <a class="acessorio" href="/clientes.php?filter_tipo_validade=proximos">ver todas</a>
            </div>
            <div class="table-responsive">
                <table class="lista">
                    <thead><tr>
                        <th scope="col">Cliente</th>
                        <th scope="col" class="num">Vence</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($acabando as $c): ?>
                        <tr>
                            <td class="identidade" data-r="Cliente">
                                <div>
                                    <a class="nome" href="/ver_empresa.php?id=<?= (int) $c['codigo']; ?>"><?= shield_h((string) $c['razao']); ?></a>
                                    <span class="apoio"><?= shield_h(date('d/m/Y', strtotime((string) $c['validade_licenca']))); ?></span>
                                </div>
                            </td>
                            <td class="num" data-r="Vence">
                                <span class="pilula pilula-atencao"><?= shield_ha($c['validade_licenca']); ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($certificados): ?>
    <div class="col-xl-6">
        <div class="card h-100">
            <div class="cabeca">
                <h2>Certificados digitais vencendo</h2>
                <a class="acessorio" href="/clientes.php?cert=30">ver todos</a>
            </div>
            <div class="table-responsive">
                <table class="lista">
                    <thead><tr>
                        <th scope="col">Cliente</th>
                        <th scope="col" class="num">Certificado</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($certificados as $c): ?>
                        <?php $cert = shield_certificado_situacao($c['certificado_vence']); ?>
                        <tr>
                            <td class="identidade" data-r="Cliente">
                                <div>
                                    <a class="nome" href="/ver_empresa.php?id=<?= (int) $c['codigo']; ?>"><?= shield_h((string) $c['razao']); ?></a>
                                    <span class="apoio"><?= shield_h(date('d/m/Y', strtotime((string) $c['certificado_vence']))); ?></span>
                                </div>
                            </td>
                            <td class="num" data-r="Certificado">
                                <span class="pilula pilula-<?= shield_h($cert['cor']); ?>"><?= shield_h($cert['rotulo']); ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($aReceber): ?>
    <div class="col-xl-6">
        <div class="card h-100">
            <div class="cabeca">
                <h2>A receber</h2>
                <a class="acessorio" href="/cobrancas.php">ver todas</a>
            </div>
            <div class="table-responsive">
                <table class="lista">
                    <thead><tr>
                        <th scope="col">Cliente</th>
                        <th scope="col" class="num">Valor</th>
                        <th scope="col" class="num">Vence</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($aReceber as $c):
                        $atrasada = strtotime((string) $c['vencimento']) < strtotime('today'); ?>
                        <tr>
                            <td class="identidade" data-r="Cliente">
                                <div>
                                    <a class="nome" href="/ver_empresa.php?id=<?= (int) $c['empresa']; ?>"><?= shield_h((string) $c['razao']); ?></a>
                                    <span class="apoio"><?= shield_h((string) $c['descricao']); ?></span>
                                </div>
                            </td>
                            <td class="num" data-r="Valor">R$ <?= shield_h(shield_dinheiro((int) $c['valor_centavos'])); ?></td>
                            <td class="num" data-r="Vence">
                                <span class="pilula pilula-<?= $atrasada ? 'erro' : 'atencao'; ?>"><?php
                                    // "ha 46 dias" sob um cabecalho que diz
                                    // VENCE nao diz se ja passou ou se falta.
                                    echo $atrasada
                                        ? 'venceu ' . shield_ha($c['vencimento'])
                                        : shield_ha($c['vencimento']);
                                ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($sumidos): ?>
    <div class="col-xl-6">
        <div class="card h-100">
            <div class="cabeca">
                <h2>Terminais que pararam de dar sinal</h2>
                <a class="acessorio" href="/parque.php?situacao=sumido">ver o parque</a>
            </div>
            <div class="card-body py-2">
                <p class="small text-secondary mb-0">
                    Terminal parado &eacute; loja parada, ou m&aacute;quina que morreu.
                    Voc&ecirc; fica sabendo antes de o cliente ligar.
                </p>
            </div>
            <div class="table-responsive">
                <table class="lista">
                    <thead><tr>
                        <th scope="col">Cliente</th>
                        <th scope="col">M&aacute;quina</th>
                        <th scope="col" class="num">&Uacute;ltimo sinal</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($sumidos as $t): ?>
                        <tr>
                            <td data-r="Cliente"><?= shield_h((string) ($t['razao'] ?? '')); ?></td>
                            <td data-r="M&aacute;quina" class="text-secondary"><?= shield_h((string) ($t['NOME_COMPUTADOR'] ?? '')); ?></td>
                            <td class="num" data-r="&Uacute;ltimo sinal">
                                <span class="pilula pilula-neutro"><?= shield_h(shield_parque_ha_quanto($t['ULTIMO_ACESSO'] ?? '')); ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

</div>

<script>
(function () {
  var r = document.getElementById('relogioAgora');
  if (!r) { return; }
  function d(n) { return (n < 10 ? '0' : '') + n; }
  setInterval(function () {
    var a = new Date();
    r.textContent = d(a.getHours()) + ':' + d(a.getMinutes()) + ':' + d(a.getSeconds());
  }, 1000);
}());
</script>
<?php include __DIR__ . '/../../templates/fecha.php'; ?>
