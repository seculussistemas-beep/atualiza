<?php

require_once __DIR__ . '/../../funcoes/nucleo/system_bootstrap.php';
shield_enforce_installation_guard();

require_once __DIR__ . '/../../funcoes/nucleo/sessao.php'; shield_sessao_abrir();
$_SESSION = [];

// Sair tambem esquece este navegador: o cookie de "manter conectado" some do
// banco e do navegador, senao a proxima visita entraria de novo sozinha.
require_once __DIR__ . '/../../funcoes/acesso/sessao_lembrada.php';
if (!empty($_COOKIE[SHIELD_LEMBRAR_COOKIE])) {
    try {
        require_once __DIR__ . '/../../banco.php';
        shield_lembrar_esquecer($pdo, (string) $_COOKIE[SHIELD_LEMBRAR_COOKIE]);
    } catch (Throwable $ignorado) {
        // Banco fora: o cookie e apagado do navegador mesmo assim.
    }
    shield_lembrar_apagar_cookie();
}

if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

session_destroy();
header('Location: login.php');
exit;
