<?php

require_once __DIR__ . '/../../funcoes/nucleo/system_bootstrap.php';
shield_enforce_installation_guard();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Acesso Negado</title>
    <link rel="stylesheet" href="/vendor/bootstrap5/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/icones.css?v=<?= (int) @filemtime(__DIR__ . '/../../public/css/icones.css'); ?>">
    <link rel="stylesheet" href="/css/painel.css">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="card shadow-sm">
            <div class="card-body text-center">
                <h1 class="h4 text-danger mb-3">Acesso negado</h1>
                <p class="mb-4">Voc&ecirc; n&atilde;o possui permiss&atilde;o para acessar esta p&aacute;gina.</p>
                <a href="index.php" class="btn btn-primary">Voltar ao dashboard</a>
            </div>
        </div>
    </div>
    <script src="/vendor/bootstrap5/js/bootstrap.bundle.min.js"></script>
</body>
</html>
