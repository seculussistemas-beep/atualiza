<?php
/**
 * Atualizacao do painel - 25/08/2026.
 *
 * O motor esta em includes/atualizador.php; aqui e so a tela que o conduz.
 *
 * O DOWNLOAD VAI EM FATIAS, por requisicao, e nao numa tacada: hospedagem
 * compartilhada corta a requisicao no limite de tempo dela, e um download que
 * recomeca do zero a cada corte nunca termina. Quem repete a chamada e o laco
 * de JS no fim -- sem cron e sem processo residente, que e o que o membro tem.
 *
 * NENHUMA das etapas anteriores toca na pasta do painel. A troca e a ultima, e
 * so acontece no botao "Instalar agora".
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/atualizacao/atualizador.php';

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

$acao = (string) ($_REQUEST['acao'] ?? '');
$emJson = in_array($acao, array('baixar', 'conferir', 'aplicar', 'enviar_manifesto', 'enviar'), true);

// As etapas que o JS conduz respondem JSON. O buffer sai antes do cabecalho
// porque um unico byte de HTML na frente estraga a resposta -- e o mesmo
// cuidado do emissor de .lic.
if ($emJson) {
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
}

$erro = '';
$aviso = '';
$erroPasta = '';
$manifesto = null;
$avaliacao = null;

$urlGravada = shield_atu_url($pdo);
$instalada = shield_atu_versao_instalada();

// Restos da troca anterior. Sai no acesso SEGUINTE, nunca junto da troca.
if (!$emJson) {
    shield_atu_limpar_restos();
}

/**
 * O manifesto que a tela usa: o ENVIADO pelo navegador, se houver um no estado
 * (16/09/2026), senao o do endereco gravado. Null com o motivo.
 *
 * O enviado vence porque conferir e instalar nao podem ir a rede atras de um
 * manifesto que o membro nem publicou -- ele subiu o zip justamente por nao ter
 * onde publicar.
 */
function shield_atu_tela_manifesto(PDO $pdo, &$erro)
{
    $enviado = shield_atu_estado()['manifesto_enviado'] ?? null;
    if (is_array($enviado) && !empty($enviado['sha256'])) {
        return $enviado;
    }

    $url = shield_atu_url_do_manifesto(shield_atu_url($pdo));
    if ($url === '') {
        $erro = 'Nenhum endereco de atualizacao configurado.';
        return null;
    }

    return shield_atu_ler_manifesto($url, $erro);
}

// ---------------------------------------------------------------- acoes ---

if ($acao === 'gravar_url' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    shield_atu_definir_url($pdo, (string) ($_POST['url'] ?? ''));
    // Endereco novo invalida o que estava baixado do endereco velho.
    shield_atu_zerar_estado();
    header('Location: /atualizacao.php?ok=url');
    exit;
}

if ($acao === 'esquecer' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    shield_atu_zerar_estado();
    header('Location: /atualizacao.php?ok=limpo');
    exit;
}

// O ENVIO PELO NAVEGADOR (16/09/2026, pedido de um membro sem cPanel). Dois
// passos, os dois POST com o token no cabecalho X-CSRF-Token (o router recusa
// POST sem ele): primeiro o versao.json inteiro, depois o zip em fatias no
// corpo cru -- php://input, e nao $_FILES, porque o upload_max_filesize de
// fabrica (2 MB) e menor que o pacote e nao se mexe nele por FTP.
if ($acao === 'enviar_manifesto' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $m = shield_atu_manifesto_de_texto((string) file_get_contents('php://input'), '', $erro);
    if ($m === null) {
        echo json_encode(array('ok' => false, 'erro' => $erro));
        exit;
    }
    $avaliacaoEnvio = shield_atu_avaliar($m, shield_get_system_meta($pdo, SHIELD_ATU_META_SHA_INSTALADO, ''));
    if (empty($avaliacaoEnvio['ha'])) {
        echo json_encode(array('ok' => false, 'erro' => (string) $avaliacaoEnvio['motivo']));
        exit;
    }
    // Manifesto novo descarta o que estava baixado do endereco ou de outro envio.
    shield_atu_zerar_estado();
    shield_atu_gravar_estado(array('versao' => $m['versao'], 'manifesto_enviado' => $m, 'baixados' => 0, 'total' => (int) $m['tamanho']));
    echo json_encode(array('ok' => true, 'versao' => $m['versao'], 'total' => (int) $m['tamanho'],
                           'reinstalar' => !empty($avaliacaoEnvio['reinstalar'])));
    exit;
}

if ($acao === 'enviar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $m = shield_atu_estado()['manifesto_enviado'] ?? null;
    if (!is_array($m)) {
        echo json_encode(array('ok' => false, 'erro' => 'Envie o versao.json antes do pacote.'));
        exit;
    }
    $passo = shield_atu_receber_fatia($m, (int) ($_GET['posicao'] ?? -1), (string) file_get_contents('php://input'), $erro);
    if ($passo === null) {
        // De onde o arquivo esta, para o envio continuar dali quando a fatia
        // anterior chegou e a resposta dela se perdeu (16/10/2026).
        $parte = shield_atu_pasta() . '/baixando.part';
        echo json_encode(array('ok' => false, 'erro' => $erro, 'continuar' => is_file($parte) ? (int) filesize($parte) : 0));
        exit;
    }
    shield_atu_gravar_estado(array_merge(shield_atu_estado(), array('baixados' => $passo['baixados'], 'total' => $passo['total'])));
    echo json_encode(array(
        'ok' => true, 'baixados' => $passo['baixados'], 'total' => $passo['total'], 'completo' => $passo['completo'],
        'porcento' => $passo['total'] > 0 ? (int) floor($passo['baixados'] * 100 / $passo['total']) : 0,
    ));
    exit;
}

if ($acao === 'baixar') {
    $m = shield_atu_tela_manifesto($pdo, $erro);
    if ($m === null) {
        echo json_encode(array('ok' => false, 'erro' => $erro));
        exit;
    }

    $passo = shield_atu_baixar_fatia($m, $erro);
    if ($passo === null) {
        echo json_encode(array('ok' => false, 'erro' => $erro));
        exit;
    }

    shield_atu_gravar_estado(array(
        'versao' => $m['versao'],
        'baixados' => $passo['baixados'],
        'total' => $passo['total'],
    ));

    echo json_encode(array(
        'ok' => true,
        'baixados' => $passo['baixados'],
        'total' => $passo['total'],
        'completo' => $passo['completo'],
        'porcento' => $passo['total'] > 0
            ? (int) floor($passo['baixados'] * 100 / $passo['total']) : 0,
    ));
    exit;
}

if ($acao === 'conferir') {
    $m = shield_atu_tela_manifesto($pdo, $erro);
    if ($m === null) {
        echo json_encode(array('ok' => false, 'erro' => $erro));
        exit;
    }
    if (!shield_atu_conferir($m, $erro) || !shield_atu_extrair($erro)) {
        // Pacote recusado nao fica guardado fingindo que serve.
        shield_atu_zerar_estado();
        echo json_encode(array('ok' => false, 'erro' => $erro));
        exit;
    }

    // O sha256 do pacote conferido fica no estado: e ele que o instalar grava como
    // "pacote instalado", para a mesma versao publicada de novo ser reconhecida.
    shield_atu_gravar_estado(array_merge(shield_atu_estado(), array('versao' => $m['versao'], 'sha256' => $m['sha256'])));

    echo json_encode(array('ok' => true, 'versao' => $m['versao']));
    exit;
}

if ($acao === 'aplicar') {
    $relatorio = array();
    if (!shield_atu_aplicar($erro, $relatorio)) {
        echo json_encode(array('ok' => false, 'erro' => $erro));
        exit;
    }

    $shaAplicado = (string) (shield_atu_estado()['sha256'] ?? '');
    if ($shaAplicado !== '') {
        shield_set_system_meta($pdo, SHIELD_ATU_META_SHA_INSTALADO, $shaAplicado);
    }
    shield_atu_zerar_estado();
    echo json_encode(array('ok' => true, 'arquivos' => (int) ($relatorio['arquivos'] ?? 0)));
    exit;
}

if ($acao === 'procurar') {
    $manifesto = shield_atu_tela_manifesto($pdo, $erro);
    if ($manifesto !== null) {
        $avaliacao = shield_atu_avaliar($manifesto, shield_get_system_meta($pdo, SHIELD_ATU_META_SHA_INSTALADO, ''));
    }
}

$estado = shield_atu_estado();
$temPacotePronto = shield_atu_pasta_pronta() !== '';
$pastaOk = shield_atu_garantir_pasta($erroPasta);

$marca = (string) ($_GET['ok'] ?? '');
if ($marca === 'url') {
    $aviso = 'Endereco gravado.';
} elseif ($marca === 'limpo') {
    $aviso = 'O que estava baixado foi descartado.';
}
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>


<div class="topo-tela">
    <div>
        <h1 class="h4 mb-1">Atualiza&ccedil;&atilde;o do painel</h1>
        <p class="text-secondary small mb-0">
            Traz a vers&atilde;o nova <strong>deste painel</strong> (telas, motor de cobran&ccedil;a, API de licen&ccedil;a) sem FTP.
            N&atilde;o mexe no ERP Delphi &mdash; ele tem o atualizador dele.
        </p>
    </div>
    <div class="acoes-pagina">
        <span class="pilula pilula-neutro">instalada: <?= shield_h($instalada); ?></span>
    </div>
</div>

<?php shield_aviso_flutuante($aviso, 'ok'); ?>
<?php if ($erro !== ''): ?>
    <div class="alert alert-danger"><?= shield_h($erro); ?></div>
<?php endif; ?>
<?php if (!$pastaOk): ?>
    <div class="alert alert-warning">
        <strong>A atualiza&ccedil;&atilde;o n&atilde;o vai conseguir gravar.</strong>
        <?= shield_h($erroPasta); ?>
    </div>
<?php endif; ?>

<div class="card mb-3" data-tour="atu-como">
    <div class="card-header">Como funciona</div>
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-6 col-xl-3">
                <strong class="d-block mb-1"><span class="pilula pilula-neutro me-1 align-middle" style="min-width: 1.6rem; justify-content: center">1</span>Endere&ccedil;o</strong>
                <span class="small text-secondary">Voc&ecirc; publica um <code>versao.json</code> e o pacote <code>.zip</code> num endere&ccedil;o seu, e grava esse endere&ccedil;o abaixo. O painel s&oacute; olha para l&aacute;.</span>
            </div>
            <div class="col-md-6 col-xl-3">
                <strong class="d-block mb-1"><span class="pilula pilula-neutro me-1 align-middle" style="min-width: 1.6rem; justify-content: center">2</span>Procurar</strong>
                <span class="small text-secondary">O painel l&ecirc; o manifesto e compara a vers&atilde;o oferecida com a instalada. Nada muda ainda.</span>
            </div>
            <div class="col-md-6 col-xl-3">
                <strong class="d-block mb-1"><span class="pilula pilula-neutro me-1 align-middle" style="min-width: 1.6rem; justify-content: center">3</span>Baixar e conferir</strong>
                <span class="small text-secondary">O pacote desce em fatias (hospedagem compartilhada corta requisi&ccedil;&atilde;o longa) e a soma sha256 &eacute; conferida. Ainda nada muda.</span>
            </div>
            <div class="col-md-6 col-xl-3">
                <strong class="d-block mb-1"><span class="pilula pilula-neutro me-1 align-middle" style="min-width: 1.6rem; justify-content: center">4</span>Instalar</strong>
                <span class="small text-secondary">S&oacute; no bot&atilde;o. Cada arquivo trocado vai para <code>estagio/backup/</code> antes; se algum falhar, tudo volta. <code>config/</code> e <code>uploads/</code> n&atilde;o s&atilde;o tocados.</span>
            </div>
        </div>
    </div>
</div>

<div class="card mb-3" data-tour="atu-origem">
    <div class="card-header">De onde vem a atualiza&ccedil;&atilde;o</div>
    <div class="card-body py-3">
        <form method="post" action="/atualizacao.php" class="row g-2 align-items-end" autocomplete="off">
            <input type="hidden" name="acao" value="gravar_url">
            <div class="col-12 col-lg-9">
                <label class="form-label small mb-1" for="urlAtu">Endere&ccedil;o do manifesto</label>
                <input type="url" id="urlAtu" name="url" class="form-control form-control-sm"
                       placeholder="https://seusite.com.br/versao.json" value="<?= shield_h($urlGravada); ?>">
            </div>
            <div class="col-12 col-lg-3">
                <button type="submit" class="btn btn-primary btn-sm w-100"><i class="fas fa-save me-1"></i>Gravar</button>
            </div>
            <div class="col-12">
                <span class="form-text">
                    Pode ser o endere&ccedil;o do <code>versao.json</code> ou o do pr&oacute;prio <code>.zip</code> &mdash; neste caso o manifesto &eacute; procurado ao lado.
                </span>
            </div>
        </form>
    </div>
</div>

<?php /* O ENVIO PELO NAVEGADOR (16/09/2026): para quem nao tem onde publicar o zip.
         Sobe o versao.json e o zip em fatias e cai no "Instalar agora" de sempre. */ ?>
<div class="card mb-3" data-tour="atu-envio">
    <div class="card-header">Ou envie o pacote daqui mesmo</div>
    <div class="card-body py-3">
        <div class="row g-2 align-items-end">
            <div class="col-12 col-lg-5">
                <label class="form-label small mb-1" for="envZip">O pacote <code>.zip</code></label>
                <input type="file" id="envZip" class="form-control form-control-sm" accept=".zip,application/zip">
            </div>
            <div class="col-12 col-lg-4">
                <label class="form-label small mb-1" for="envJson">O <code>versao.json</code> que veio com ele</label>
                <input type="file" id="envJson" class="form-control form-control-sm" accept=".json,application/json">
            </div>
            <div class="col-12 col-lg-3">
                <button type="button" id="btEnviar" class="btn btn-outline-primary btn-sm w-100"><i class="fas fa-clipboard-check me-1"></i>Enviar e conferir</button>
            </div>
            <div class="col-12">
                <span class="form-text">
                    Para quem n&atilde;o tem onde publicar os dois arquivos. Sobem em fatias (n&atilde;o dependem do limite de upload da
                    hospedagem), a soma sha256 do manifesto &eacute; conferida e o pacote fica pronto para o bot&atilde;o de instalar. Nada muda antes dele.
                </span>
            </div>
            <div class="col-12 d-none" id="progressoEnvio">
                <div class="progress" style="height:1.4rem"><div id="barraEnvio" class="progress-bar" style="width:0%">0%</div></div>
                <p id="passoEnvio" class="small text-muted mt-2 mb-0"></p>
            </div>
        </div>
    </div>
</div>

    <?php if ($urlGravada !== ''): ?>
    <div class="card mb-3">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span>O que h&aacute; de novo</span>
            <a href="/atualizacao.php?acao=procurar" class="btn btn-sm btn-outline-primary">
                <i class="fas fa-sync-alt me-1"></i>Procurar agora
            </a>
        </div>
        <div class="card-body">
            <?php if ($manifesto === null): ?>
                <p class="text-muted mb-0">Clique em <strong>Procurar agora</strong> para consultar o servidor.</p>
            <?php else: ?>
                <p class="mb-1">
                    <strong>Vers&atilde;o oferecida:</strong> <?= shield_h($manifesto['versao']); ?>
                    &nbsp;&middot;&nbsp; <?= shield_h(number_format($manifesto['tamanho'] / 1048576, 1, ',', '.')); ?> MB
                    <?php if ($manifesto['obrigatoria']): ?>
                        &nbsp;<span class="badge text-bg-warning">obrigat&oacute;ria</span>
                    <?php endif; ?>
                </p>
                <?php if ($manifesto['notas'] !== ''): ?>
                    <p class="mb-2"><?= nl2br(shield_h($manifesto['notas'])); ?></p>
                <?php endif; ?>

                <?php if (empty($avaliacao['ha'])): ?>
                    <div class="alert alert-info mb-0"><?= shield_h((string) $avaliacao['motivo']); ?></div>
                <?php else: ?>
                    <?php if (!empty($avaliacao['reinstalar'])): ?>
                        <div class="alert alert-warning mb-2"><?= shield_h((string) $avaliacao['motivo']); ?>
                            O painel j&aacute; est&aacute; nesta vers&atilde;o, mas o arquivo publicado mudou depois de instalado.</div>
                    <?php endif; ?>
                    <hr>
                    <div id="progresso" class="mb-2 d-none">
                        <div class="progress" style="height:1.4rem">
                            <div id="barra" class="progress-bar" style="width:0%">0%</div>
                        </div>
                        <p id="passo" class="small text-muted mt-2 mb-0"></p>
                    </div>
                    <button id="btBaixar" class="btn btn-primary btn-sm">
                        <i class="fas fa-file-download me-1"></i>Baixar e conferir
                    </button>
                    <p class="small text-muted mt-2 mb-0">
                        Baixar <strong>n&atilde;o altera nada</strong>. O painel s&oacute; muda no
                        bot&atilde;o de instalar, que aparece quando o pacote estiver conferido.
                    </p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($temPacotePronto): ?>
    <div class="card mb-3 borda-ok">
        <div class="card-header">Pacote conferido, pronto para instalar</div>
        <div class="card-body">
            <p>
                O pacote <?= shield_h((string) ($estado['versao'] ?? '')); ?> foi baixado inteiro e a
                soma sha256 confere. Instalar troca os arquivos do painel; cada um vira
                <code>estagio/backup/</code> antes, e falhando qualquer um <strong>tudo volta</strong>.
            </p>
            <p class="small text-muted">
                O que &eacute; da instala&ccedil;&atilde;o &mdash; <code>config/</code> e
                <code>uploads/</code> &mdash; n&atilde;o &eacute; tocado.
            </p>
            <button id="btAplicar" class="btn btn-primary btn-sm">
                <i class="fas fa-check me-1"></i>Instalar agora
            </button>
            <form method="post" action="/atualizacao.php" class="d-inline">
                <input type="hidden" name="acao" value="esquecer">
                <button type="submit" class="btn btn-outline-secondary btn-sm">Descartar o pacote</button>
            </form>
            <p id="passoAplicar" class="small mt-2 mb-0"></p>
        </div>
    </div>
    <?php endif; ?>

<script>
(function () {
  var btBaixar = document.getElementById('btBaixar');
  var btAplicar = document.getElementById('btAplicar');
  var caixa = document.getElementById('progresso');
  var barra = document.getElementById('barra');
  var passo = document.getElementById('passo');

  // A RESPOSTA QUE NAO E JSON TRAZ O MOTIVO (16/10/2026). Com o banco fora, o
  // servidor responde a frase do banco.php ("Erro ao conectar ao banco... -- o que
  // pode ser"), e o r.json() a jogava fora: a tela dizia so "nao respondeu".
  function lerResposta(r) {
    return r.text().then(function (texto) {
      try { return JSON.parse(texto); } catch (e) {
        var limpo = texto.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 700);
        var erro = new Error(limpo || ('O servidor respondeu HTTP ' + r.status + ' sem texto.'));
        erro.doServidor = true;
        throw erro;
      }
    });
  }

  function chamar(acao) {
    return fetch('/atualizacao.php?acao=' + acao, { credentials: 'same-origin' }).then(lerResposta);
  }

  function falhou(texto) {
    passo.className = 'small text-danger mt-2 mb-0';
    passo.textContent = texto;
    btBaixar.disabled = false;
  }

  // Uma fatia por chamada: quem decide quanto cabe em cada requisicao e o
  // servidor do membro, entao o laco so repete ate o arquivo fechar.
  function fatia() {
    chamar('baixar').then(function (d) {
      if (!d.ok) { return falhou(d.erro || 'Falhou o download.'); }
      barra.style.width = d.porcento + '%';
      barra.textContent = d.porcento + '%';
      if (!d.completo) { passo.textContent = 'Baixando...'; return fatia(); }
      passo.textContent = 'Conferindo tamanho e sha256...';
      chamar('conferir').then(function (c) {
        if (!c.ok) { return falhou(c.erro || 'O pacote foi recusado.'); }
        passo.className = 'small text-success mt-2 mb-0';
        passo.textContent = 'Pacote conferido. Recarregando...';
        window.location = '/atualizacao.php';
      }).catch(function (e) { falhou(e && e.doServidor ? e.message : 'A conferencia nao respondeu.'); });
    }).catch(function (e) { falhou(e && e.doServidor ? e.message : 'O servidor nao respondeu. Tente de novo.'); });
  }

  if (btBaixar) {
    btBaixar.addEventListener('click', function () {
      btBaixar.disabled = true;
      caixa.classList.remove('d-none');
      passo.className = 'small text-muted mt-2 mb-0';
      passo.textContent = 'Comecando...';
      fatia();
    });
  }

  // O ENVIO PELO NAVEGADOR. O manifesto vai inteiro; o zip, em fatias de 512 KB
  // no corpo cru, uma por requisicao, com a posicao na URL -- o servidor so
  // encosta a fatia que continua de onde parou. O token vai no cabecalho.
  var btEnviar = document.getElementById('btEnviar');
  if (btEnviar) {
    var envZip = document.getElementById('envZip');
    var envJson = document.getElementById('envJson');
    var caixaEnvio = document.getElementById('progressoEnvio');
    var barraEnvio = document.getElementById('barraEnvio');
    var passoEnvio = document.getElementById('passoEnvio');
    var FATIA = 512 * 1024;
    var csrf = <?= json_encode(shield_csrf_token()); ?>;

    function postar(acao, corpo, extra) {
      return fetch('/atualizacao.php?acao=' + acao + (extra || ''), {
        method: 'POST', credentials: 'same-origin', body: corpo,
        headers: { 'X-CSRF-Token': csrf, 'Content-Type': 'application/octet-stream' }
      }).then(lerResposta);
    }
    // A FATIA QUE TROPECA TENTA DE NOVO (16/10/2026, visto num membro): o envio faz
    // uma requisicao por fatia, e hospedagem com limite de conexoes ou processos
    // recusa uma delas no meio ("2002 Operation not permitted"). Esperar e repetir
    // costuma passar; o servidor so encosta a fatia que continua de onde parou,
    // entao repetir nunca duplica bytes.
    var ESPERAS = [2000, 5000, 10000, 20000];
    function falhouEnvio(texto) {
      passoEnvio.className = 'small text-danger mt-2 mb-0';
      passoEnvio.textContent = texto;
      btEnviar.disabled = false;
    }
    function fatiaEnvio(arquivo, posicao, tentativa) {
      tentativa = tentativa || 0;
      if (posicao >= arquivo.size) {
        passoEnvio.textContent = 'Conferindo tamanho e sha256...';
        return chamar('conferir').then(function (c) {
          if (!c.ok) { return falhouEnvio(c.erro || 'O pacote foi recusado.'); }
          passoEnvio.className = 'small text-success mt-2 mb-0';
          passoEnvio.textContent = 'Pacote conferido. Recarregando...';
          window.location = '/atualizacao.php';
        }).catch(function (e) { falhouEnvio(e && e.doServidor ? e.message : 'A conferencia nao respondeu.'); });
      }
      var pedaco = arquivo.slice(posicao, Math.min(posicao + FATIA, arquivo.size));
      postar('enviar', pedaco, '&posicao=' + posicao).then(function (d) {
        if (!d.ok) {
          // A fatia anterior chegou mas a resposta se perdeu: o servidor diz de onde
          // continuar, e o envio segue dali em vez de parar.
          if (typeof d.continuar === 'number' && d.continuar !== posicao && tentativa < ESPERAS.length) {
            return fatiaEnvio(arquivo, d.continuar, tentativa + 1);
          }
          return falhouEnvio(d.erro || 'O envio falhou.');
        }
        barraEnvio.style.width = d.porcento + '%';
        barraEnvio.textContent = d.porcento + '%';
        passoEnvio.className = 'small text-muted mt-2 mb-0';
        passoEnvio.textContent = 'Enviando... ' + d.porcento + '%';
        fatiaEnvio(arquivo, d.baixados, 0);
      }).catch(function (e) {
        if (tentativa < ESPERAS.length) {
          var espera = ESPERAS[tentativa];
          passoEnvio.className = 'small text-warning mt-2 mb-0';
          passoEnvio.textContent = 'O servidor recusou uma parte do envio. Tentando de novo em ' + (espera / 1000)
            + ' s (tentativa ' + (tentativa + 1) + ' de ' + ESPERAS.length + ')...';
          return setTimeout(function () { fatiaEnvio(arquivo, posicao, tentativa + 1); }, espera);
        }
        falhouEnvio(e && e.doServidor ? e.message : 'O servidor nao respondeu durante o envio. Tente de novo.');
      });
    }
    btEnviar.addEventListener('click', function () {
      var zip = envZip.files[0];
      var json = envJson.files[0];
      if (!zip || !json) { caixaEnvio.classList.remove('d-none'); return falhouEnvio('Escolha o .zip e o versao.json.'); }
      btEnviar.disabled = true;
      caixaEnvio.classList.remove('d-none');
      passoEnvio.className = 'small text-muted mt-2 mb-0';
      passoEnvio.textContent = 'Lendo o manifesto...';
      json.text().then(function (texto) {
        return postar('enviar_manifesto', texto);
      }).then(function (d) {
        if (!d.ok) { return falhouEnvio(d.erro || 'O manifesto foi recusado.'); }
        if (d.total !== zip.size) {
          return falhouEnvio('O versao.json diz ' + d.total + ' bytes e o zip escolhido tem ' + zip.size + '. Sao de pacotes diferentes.');
        }
        passoEnvio.textContent = 'Enviando a versao ' + d.versao + (d.reinstalar ? ' (reinstalacao)' : '') + '...';
        fatiaEnvio(zip, 0);
      }).catch(function (e) { falhouEnvio(e && e.doServidor ? e.message : 'O servidor nao respondeu. Tente de novo.'); });
    });
  }

  if (btAplicar) {
    var aviso = document.getElementById('passoAplicar');
    btAplicar.addEventListener('click', function () {
      btAplicar.disabled = true;
      aviso.className = 'small text-muted mt-2 mb-0';
      aviso.textContent = 'Trocando os arquivos...';
      chamar('aplicar').then(function (d) {
        if (!d.ok) {
          aviso.className = 'small text-danger mt-2 mb-0';
          aviso.textContent = d.erro || 'Nao foi possivel instalar.';
          btAplicar.disabled = false;
          return;
        }
        aviso.className = 'small text-success mt-2 mb-0';
        aviso.textContent = d.arquivos + ' arquivo(s) trocado(s). Recarregando...';
        setTimeout(function () { window.location = '/atualizacao.php'; }, 1200);
      }).catch(function () {
        aviso.className = 'small text-danger mt-2 mb-0';
        aviso.textContent = 'O servidor nao respondeu durante a troca.';
        btAplicar.disabled = false;
      });
    });
  }
})();
</script>
<?php include __DIR__ . '/../../templates/fecha.php'; ?>
