<?php
/**
 * Cobrancas - 25/08/2026.
 *
 * O que esta aberto, vencido e pago; emitir, reenviar e confirmar a mao.
 *
 * DUAS COISAS QUE A TELA NAO FAZ, e as duas de proposito:
 *
 *   NAO SUSPENDE NINGUEM. Cobranca vencida e uma linha vermelha aqui; ela nao
 *   desliga o caixa de loja nenhuma. A regua e a suspensao sao da fase
 *   seguinte, e mesmo la a decisao nao sai daqui.
 *
 *   NAO EDITA COBRANCA PAGA. Correcao e estorno mais cobranca nova, com
 *   motivo. Editar o valor de algo que ja foi pago apaga a unica versao da
 *   historia que bate com o extrato do banco.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca_motor.php';
require_once __DIR__ . '/../../funcoes/cobranca/lista.php';    // a lista, a busca e os grupos por cliente
require_once __DIR__ . '/../../funcoes/cobranca/nova_cobranca.php'; // "Cobrar por": a avulsa nao estende, o plano compra meses
require_once __DIR__ . '/../../funcoes/cobranca/encargos.php'; // shield_encargos_pendentes, na lista
require_once __DIR__ . '/../../funcoes/planos/ciclo.php';     // shield_plano_ciclo_rotulo, em "Cobrar por"
require_once __DIR__ . '/../../funcoes/licenca/situacao.php';   // shield_cnpj
require_once __DIR__ . '/../../funcoes/cobranca/assinatura.php';  // shield_assinatura_competencia
require_once __DIR__ . '/../../templates/contexto_cliente.php';
require_once __DIR__ . '/../../funcoes/licenca/confianca.php';   // a promessa de pagamento, na linha

use Shield\Cobranca\CodigoDePagamento;
use Shield\Cobranca\Registro;

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

$erro = '';
$aviso = '';
// Dez segundos para a frase que traz data, consequencia ou passo a dar (4.1.24);
// a confirmacao curta de clique continua com cinco.
$avisoDemorado = false;
$resposta = '';   // a resposta do provedor ao Consultar: fica na tela
$podeConfirmar = shield_pode_confirmar_pagamento($pdo);
$empresaFiltro = shield_empresa_contexto_id($_GET);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = (string) ($_POST['acao'] ?? '');
    $cobrancaId = (int) ($_POST['cobranca'] ?? 0);

    try {
        if ($acao === 'promessa') {
            // O PEDIDO DE PRAZO SE RESPONDE AQUI TAMBEM (10/09/2026, noite): e
            // na cobranca vencida que ele aparece. Aceito, o token anda ate a
            // data e a loja segue; recusado, a licenca vencida bloqueia sozinha
            // e o cliente so pede de novo cinco horas depois.
            $decisao = shield_promessa_decidir($pdo, (int) ($_POST['promessa'] ?? 0), ($_POST['decisao'] ?? '') === 'aceitar',
                (string) ($_SESSION['usuario']['nome'] ?? $_SESSION['usuario']['login'] ?? 'painel'));
            $avisoDemorado = true;
            $aviso = shield_promessa_frase($pdo, (int) ($_POST['promessa'] ?? 0), $decisao);
        } elseif ($acao === 'abrir') {
            // COBRAR POR -- 14/09/2026. A avulsa nao move a validade e so o plano compra
            // meses; a assinatura nasce no fechamento; o valor do plano vem do cadastro.
            // A conta manda na forma e e conferida ANTES de abrir, pronta ou nao (a chave
            // do PIX na chave), e o F5 devolve a cobranca do mesmo envio sem emitir de novo.
            // Tudo isso mora em shield_cobranca_nova_abrir para ser provado fora da tela:
            // a suite nao tem POST logado, e o defeito so aparecia no pagamento.
            $nova = shield_cobranca_nova_abrir($pdo, $_POST);
            if ($nova['repetido']) {
                $aviso = 'Esta cobranca ja tinha sido aberta por este envio. Nada foi duplicado.';
            } elseif ($nova['dinheiro']) {
                // Nao ha codigo para mandar, e o passo seguinte e da pessoa: dez segundos.
                $avisoDemorado = true;
                $aviso = 'Cobranca aberta, a receber em dinheiro. Nao ha codigo para mandar: quando o dinheiro entrar, confirme o recebimento na linha dela.';
            } elseif ($nova['emitida']) {
                $aviso = 'Cobranca aberta e emitida.';
            } else {
                $aviso = 'Cobranca aberta. Emita quando quiser.';
            }
        } elseif ($acao === 'emitir') {
            shield_cobranca_emitir($pdo, $cobrancaId, (int) ($_POST['conta'] ?? 0));
            $aviso = 'Cobranca emitida.';
        } elseif ($acao === 'reemitir') {
            // Cancela o codigo antigo no provedor e emite o de hoje, com os
            // encargos de hoje. Ver shield_cobranca_reemitir.
            shield_cobranca_reemitir($pdo, $cobrancaId, (int) ($_POST['conta'] ?? 0));
            $avisoDemorado = true;
            $aviso = 'Cobranca reemitida com os encargos de hoje. O codigo antigo foi cancelado; mande o novo ao cliente.';
        } elseif ($acao === 'consultar') {
            $r = shield_cobranca_consultar($pdo, $cobrancaId);
            // Resposta a uma pergunta, e nao sucesso: fica na tela em cinza, e o
            // $aviso (que agora flutua e some) nao a leva junto.
            $resposta = $r === null
                ? 'Esta cobranca ainda nao foi emitida em provedor nenhum.'
                : 'O provedor respondeu: ' . $r->situacao
                    . ($r->situacaoProvedor !== '' ? ' (' . $r->situacaoProvedor . ')' : '');
        } elseif ($acao === 'confirmar') {
            $noProvedor = shield_cobranca_confirmar_manual(
                $pdo,
                $cobrancaId,
                shield_centavos((string) ($_POST['valor_pago'] ?? '')),
                (string) ($_POST['forma_pago'] ?? 'pix'),
                (string) ($_POST['observacao'] ?? '')
            );
            // O que aconteceu no provedor vai junto (15/10/2026): quando ele nao deu
            // baixa, e a frase que diz ao membro para fazer la.
            if (is_string($noProvedor)) {
                $avisoDemorado = true;
            }
            $aviso = 'Pagamento confirmado e registrado no livro de auditoria.'
                . (is_string($noProvedor) ? ' ' . $noProvedor : '');
        } elseif ($acao === 'cancelar') {
            // O motivo e obrigatorio como no estorno: some uma divida, e o livro
            // de auditoria precisa dizer por que. O required da tela nao basta.
            $motivo = trim((string) ($_POST['motivo'] ?? ''));
            if ($motivo === '') {
                throw new RuntimeException('Cancelamento sem motivo nao entra.');
            }
            shield_cobranca_cancelar($pdo, $cobrancaId, substr($motivo, 0, 150));
            $avisoDemorado = true;
            $aviso = 'Cobranca cancelada, tambem no provedor. Se era valor errado, abra outra com o valor certo.';
        } elseif ($acao === 'regerar') {
            shield_assinatura_regerar($pdo, $cobrancaId);
            $avisoDemorado = true;
            $aviso = 'Mensalidade gerada de novo, com o mesmo vencimento. Paga, ela estende a licenca como as outras.';
        } elseif ($acao === 'ajustar_saldo') {
            // O CREDITO SE AJUSTA AQUI (14/10/2026), onde ele aparece. Mexe em
            // dinheiro do cliente, entao pede a mesma permissao de confirmar
            // pagamento, e o motivo vai para o livro.
            if (!$podeConfirmar) {
                throw new RuntimeException('Seu usuario nao pode ajustar credito de cliente.');
            }
            $delta = shield_saldo_ajustar($pdo, (int) ($_POST['empresa'] ?? 0),
                shield_centavos((string) ($_POST['saldo_novo'] ?? '')), (string) ($_POST['motivo'] ?? ''));
            $aviso = $delta === 0 ? 'O credito ja era esse valor.' : 'Credito ajustado e registrado no livro.';
        } elseif ($acao === 'estornar') {
            shield_cobranca_estornar($pdo, $cobrancaId, (string) ($_POST['motivo'] ?? ''));
            $avisoDemorado = true;
            $aviso = 'Estorno lancado. O registro anterior continua no livro.';
        }
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
}

// Abre em TODAS, da mais recente para a mais antiga: quem entra aqui quer
// ver o que aconteceu por ultimo, e o filtro "em aberto" esta a um clique.
$filtro = (string) ($_GET['situacao'] ?? 'todas');
// A BUSCA (10/09/2026, tarde): nome ou CNPJ do cliente, ou a descricao. A consulta
// mora em shield_cobranca_lista desde 14/09/2026: a daqui casava TODA cobranca
// quando a busca nao tinha digito (ver funcoes/cobranca/lista.php).
$busca = substr(trim((string) ($_GET['q'] ?? '')), 0, 255);
$resultadoLista = shield_cobranca_lista($pdo, array('situacao' => $filtro, 'empresa' => $empresaFiltro, 'q' => $busca));
$lista = $resultadoLista['linhas'];
$listaCortada = $resultadoLista['cortada'];
$pedemPrazo = shield_cobranca_pedem_prazo_contar($pdo);

// AS PROMESSAS ACEITAS (aberta = 1): a loja ganhou dias e a tela tem de dizer onde.
$promessasAceitas = array();
try {
    $st = $pdo->query("SELECT * FROM promessa_pagamento WHERE aberta = 1 AND ate >= CURDATE()");
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) ?: array() as $pa) {
        $promessasAceitas[(int) $pa['fk_empresa']] = $pa;
    }
} catch (Throwable $semTabela) {
}

// OS PEDIDOS DE PRAZO PENDENTES dos clientes desta lista, numa consulta so.
$promessasPendentes = array();
try {
    $st = $pdo->query("SELECT * FROM promessa_pagamento WHERE situacao = 'pendente' ORDER BY id DESC");
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) ?: array() as $pp) {
        if (!isset($promessasPendentes[(int) $pp['fk_empresa']])) { $promessasPendentes[(int) $pp['fk_empresa']] = $pp; }
    }
} catch (Throwable $semTabela) {
}

$contas = array_values(array_filter(
    shield_cobranca_contas($pdo, true),
    static function ($c) {
        return Registro::para((string) $c['provedor']) !== null;
    }
));

// validade_licenca entra aqui porque a faixa da assinatura le a data (10/09/2026, tarde):
// sem ela todo cliente parecia "aguardando o primeiro pagamento".
$clientes = $pdo->query('SELECT codigo, razao, cnpj, validade_licenca FROM empresa ORDER BY razao')
                ->fetchAll(PDO::FETCH_ASSOC) ?: array();

$empresaSelecionada = null;
if ($empresaFiltro !== null) {
    foreach ($clientes as $cliente) {
        if ((int) $cliente['codigo'] === $empresaFiltro) {
            $empresaSelecionada = $cliente;
            break;
        }
    }
}

$urlCobrancas = shield_url_com_empresa('/cobrancas.php', $empresaFiltro);
$escopo = $empresaSelecionada !== null;
$saldoCliente = $escopo ? shield_saldo_ler($pdo, $empresaFiltro) : 0;

/* AGRUPADA POR CLIENTE -- 14/09/2026, no molde de Terminais e Monitoramento.
 *
 * Fora de um cliente, duzentas linhas com o nome repetido nao se leem; um
 * bloco por cliente, FECHADO, com quanto venceu e quanto vai vencer no
 * cabecalho, sim. Dentro de um cliente continua a lista corrida: a faixa do
 * contrato logo acima ja diz de quem e, e um grupo so seria um cabecalho a mais.
 */
$agrupar = !$escopo && $lista !== array();
$grupos = $agrupar
    ? shield_cobranca_grupos($lista, shield_cobranca_resumo_por_empresa($pdo, array_column($lista, 'fk_empresa')))
    : array();

// OS GRUPOS NASCEM FECHADOS, como em Terminais -- nem a busca que acha um cliente so
// abre o dele. A unica excecao e o grupo da acao que acabou de rodar: o membro
// tinha aberto aquele bloco para clicar, o POST devolve a tela inteira, e fechado
// a linha que se mexeu sumiria de vista junto com o aviso do que houve.
$empresaDaAcao = 0;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $empresaDaAcao = (int) ($_POST['empresa'] ?? 0);
    $cobrancaDaAcao = (int) ($_POST['cobranca'] ?? 0);
    foreach ($cobrancaDaAcao > 0 ? $lista : array() as $linhaAcao) {
        if ((int) $linhaAcao['id'] === $cobrancaDaAcao) {
            $empresaDaAcao = (int) $linhaAcao['fk_empresa'];
            break;
        }
    }
}

/* ------------------------------------------------------ como se cobra --
 *
 * Sao dois negocios diferentes, e a tela tratava os dois como "digite o
 * valor":
 *
 *   PLANO      o cliente paga UMA VEZ e ganha acesso por N meses. A conta
 *              que importa e a data em que esse acesso termina.
 *   ASSINATURA nasce uma cobranca a cada ciclo, sozinha. A conta que
 *              importa e o dia do vencimento e o valor do ciclo.
 *
 * Escolher um dos dois preenche valor, descricao e data -- que era o passo
 * onde o membro errava, porque tinha de lembrar de cabeca quanto custa cada
 * plano.
 */
$planos = array();
try {
    // O MESMO FILTRO QUE O POST CONFERE (SHIELD_PLANO_PREPAGO_ATIVO_SQL, 14/09/2026):
    // escrito duas vezes, a lista e a gravacao divergiam, e o id de um plano de
    // assinatura mandado a mao gravava os meses dele.
    $planos = $pdo->query(
        'SELECT id, recorrencia, valor, descricao FROM planos
          WHERE ' . SHIELD_PLANO_PREPAGO_ATIVO_SQL . '
          ORDER BY CAST(recorrencia AS UNSIGNED)'
    )->fetchAll(PDO::FETCH_ASSOC) ?: array();
} catch (Throwable $semPlanos) {
    // Base antiga sem a tabela: a tela abre com a cobranca avulsa de sempre.
}


$assinaturaAtiva = null;
if ($escopo) {
    $stmtAss = $pdo->prepare(
        "SELECT a.*, e.razao, p.descricao AS plano_nome, c.apelido AS conta_apelido
           FROM assinatura a
           LEFT JOIN empresa e ON e.codigo = a.fk_empresa
           LEFT JOIN planos p ON p.id = a.fk_plano
           LEFT JOIN conta_recebimento c ON c.id = a.fk_conta
          WHERE a.fk_empresa = :e AND a.situacao = 'ativa'
          ORDER BY a.id DESC LIMIT 1"
    );
    $stmtAss->execute(array(':e' => $empresaFiltro));
    $assinaturaAtiva = $stmtAss->fetch(PDO::FETCH_ASSOC) ?: null;
}

/* As formas que cada conta ACEITA. Oferecer boleto numa conta que so faz PIX
   produz uma emissao que falha do lado do provedor, com uma mensagem que o
   membro nao tem como entender. Sem conta escolhida a forma e so um rotulo na
   cobranca aberta, entao ali valem as tres. */
$formasPorConta = array(0 => array('pix', 'boleto', 'cartao'));
// A conta que nao esta pronta (o PIX na chave sem chave) vem apagada no Emitir: uma
// pergunta por conta, e nao uma por linha da lista.
$contaNaoPronta = array();
foreach ($contas as $c) {
    // A MESMA LISTA QUE O SERVIDOR CONFERE (14/09/2026): o "Cobra por" da
    // conta cruzado com o que o provedor faz. So o flag deixava a Efi com
    // boleto marcado oferecer boleto. Dinheiro em especie devolve "dinheiro",
    // e a forma Dinheiro so acende com ela escolhida.
    $formasPorConta[(int) $c['id']] = shield_conta_formas($c);
    $contaNaoPronta[(int) $c['id']] = shield_conta_pronta_recusa($c);
}

$rotuloForma = array('pix' => 'PIX', 'boleto' => 'Boleto', 'cartao' => 'Cart&atilde;o', 'dinheiro' => 'Dinheiro');

/* A CONTA E A FORMA QUE A NOVA COBRANCA MOSTRA AO ABRIR -- 14/09/2026.
 *
 * A conta manda na forma, e o PHP desenha as duas ja casadas: acertar por JS
 * depois de pintar e a forma trocando diante do membro. A conta e a padrao se ela
 * esta na lista, senao a primeira, que e a que o navegador mostra sozinho -- e a
 * forma tem de ser a DELA. So o POST de "abrir" que voltou com erro devolve o que
 * o membro escolheu: o modal de Emitir tambem manda `conta`, e a nova cobranca nao
 * tem nada com ele.
 *
 * DINHEIRO EM ESPECIE ENTROU (14/09/2026, o dono): fora daqui, a avulsa a receber
 * no balcao nao tinha como nascer -- sem conta ela ficava em rascunho em PIX, e o
 * rascunho em PIX nao emite no dinheiro. Vem depois das automaticas
 * (shield_contas_para_escolher), e shield_conta_padrao nunca o escolhe: ele so abre
 * selecionado quando e a unica conta ligada, e ai nao ha outra por onde cobrar.
 */
$contasNova = shield_contas_para_escolher($contas);
$idsNova = array_map('intval', array_column($contasNova, 'id'));
$voltouDoAbrir = $_SERVER['REQUEST_METHOD'] === 'POST' && $erro !== '' && (string) ($_POST['acao'] ?? '') === 'abrir';
$contaNova = $voltouDoAbrir ? (int) ($_POST['conta'] ?? 0) : shield_conta_padrao($pdo);
if (!in_array($contaNova, $idsNova, true)) {
    $contaNova = $idsNova ? $idsNova[0] : 0;
}
$formaNova = $voltouDoAbrir ? (string) ($_POST['forma'] ?? '') : '';
if (!in_array($formaNova, $formasPorConta[$contaNova], true)) {
    $formaNova = $formasPorConta[$contaNova][0] ?? '';
}
$vencimentoPadrao = date('Y-m-d', strtotime('+7 days'));

/* A CHAVE DO ENVIO -- 14/09/2026, no molde de Mudar o contrato. O CSRF e por
   sessao e nao ha POST-redirect-GET, entao F5 depois de abrir reenviava o mesmo
   corpo e abria outra cobranca igual. Nasce nova a cada desenho, e nao repovoada
   do POST com erro: a tela nao devolve valor nem descricao digitados, e quem
   redigitasse outro valor com a chave velha receberia a cobranca antiga. */
$chaveNova = bin2hex(random_bytes(16));

$cor = array(
    SHIELD_COB_RASCUNHO => 'secondary', SHIELD_COB_ABERTA => 'info',
    SHIELD_COB_PAGA => 'success', SHIELD_COB_VENCIDA => 'danger',
    SHIELD_COB_CANCELADA => 'secondary', SHIELD_COB_ESTORNADA => 'warning',
);
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>


<div class="container-fluid">
    <?php /* topo-tela, o mesmo das outras dezessete telas. Esta era a unica com
             cabecalho-operacao, um nome orfao que fazia a mesma coisa -- e por
             isso ficou de fora quando o cabecalho virou a banda escura. */ ?>
    <div class="topo-tela">
        <div>
            <div class="trilha"><a href="/clientes.php">Clientes</a><span>/</span><span>Cobran&ccedil;as</span></div>
            <h1 class="h4">Cobran&ccedil;as</h1>
            <p>Abra, acompanhe e concilie o que o cliente deve ou j&aacute; pagou.</p>
            <?php /* Filtros e busca ficam A ESQUERDA, sob o titulo (10/09/2026, noite). A visao
                     das assinaturas subiu para o canto direito em 14/09/2026: ver o bloco de acoes. */ ?>
            <div class="d-flex flex-wrap align-items-center gap-2 mt-2">
        <div class="btn-group btn-group-sm" role="group" aria-label="Filtro de situacao" data-tour="cob-filtro">
            <a href="<?= shield_h(shield_url_com_empresa('/cobrancas.php', $empresaFiltro, array('situacao' => 'todas'))); ?>" class="btn btn-outline-secondary <?= $filtro === 'todas' ? 'active' : ''; ?>">Todas</a>
            <a href="<?= shield_h(shield_url_com_empresa('/cobrancas.php', $empresaFiltro, array('situacao' => 'abertas'))); ?>" class="btn btn-outline-secondary <?= $filtro === 'abertas' ? 'active' : ''; ?>">Em aberto</a>
            <a href="<?= shield_h(shield_url_com_empresa('/cobrancas.php', $empresaFiltro, array('situacao' => 'paga'))); ?>" class="btn btn-outline-secondary <?= $filtro === 'paga' ? 'active' : ''; ?>">Pagas</a>
            <?php /* CANCELADAS TEM FILTRO PROPRIO (01/10/2026): sairam de Todas para nao
                     "poluir a listagem", e o registro continua a um clique. */ ?>
            <a href="<?= shield_h(shield_url_com_empresa('/cobrancas.php', $empresaFiltro, array('situacao' => 'cancelada'))); ?>" class="btn btn-outline-secondary <?= $filtro === 'cancelada' ? 'active' : ''; ?>">Canceladas</a>
            <?php /* PEDEM PRAZO (01/10/2026): so aparece quando ha pedido esperando, ou quando
                     se esta nele -- botao permanente para um caso raro seria ruido. E o
                     destino do badge ambar da lateral; o numero dos dois sai da mesma conta. */ ?>
            <?php if ($pedemPrazo > 0 || $filtro === 'prazo'): ?>
                <a href="<?= shield_h(shield_url_com_empresa('/cobrancas.php', $empresaFiltro, array('situacao' => 'prazo'))); ?>"
                   class="btn btn-outline-secondary <?= $filtro === 'prazo' ? 'active' : ''; ?>"
                   title="Clientes que pediram prazo pelo sistema e esperam a sua resposta">Pedem prazo<?= $pedemPrazo > 0 ? ' &middot; ' . (int) $pedemPrazo : ''; ?></a>
            <?php endif; ?>
        </div>
        <form method="get" action="/cobrancas.php" class="d-inline-flex gap-1">
            <?php if ($empresaFiltro !== null): ?><input type="hidden" name="empresa" value="<?= (int) $empresaFiltro; ?>"><?php endif; ?>
            <input type="hidden" name="situacao" value="<?= shield_h($filtro); ?>">
            <input type="search" name="q" class="form-control form-control-sm" style="width: 14rem" maxlength="255" placeholder="cliente, CNPJ ou descri&ccedil;&atilde;o" value="<?= shield_h($busca); ?>">
            <button class="btn btn-sm btn-outline-secondary" title="Buscar" aria-label="Buscar"><i class="fas fa-search"></i></button>
            <?php if ($busca !== ''): ?>
                <?php /* Limpar tira a busca e fica no mesmo recorte e no mesmo cliente: sem ele,
                         apagar o texto a mao e buscar de novo era o unico caminho de volta. */ ?>
                <a href="<?= shield_h(shield_url_com_empresa('/cobrancas.php', $empresaFiltro, array('situacao' => $filtro))); ?>" class="btn btn-sm btn-outline-secondary" title="Limpar a busca" aria-label="Limpar a busca"><i class="fas fa-times"></i></a>
            <?php endif; ?>
        </form>
            </div>
        </div>
        <?php /* AS ASSINATURAS SUBIRAM PARA O CANTO (14/09/2026, pedido do dono): na linha da
                 trilha, em cima do Voltar. Ao lado da busca o botao parecia mais um filtro da
                 lista, e ele e outra tela. `em-coluna` estica o bloco na altura da faixa e
                 separa os dois; em tela estreita volta a ser fileira (painel.css). */ ?>
        <div class="acoes-pagina em-coluna">
        <a href="/assinaturas.php" class="btn btn-sm btn-outline-secondary" title="S&oacute; para olhar: quem paga como, quanto entra por m&ecirc;s e quanto j&aacute; entrou">
            <i class="fas fa-sync-alt me-1"></i>Assinaturas e pr&eacute;-pagos
        </a>
        <a href="<?= shield_h(shield_voltar_cliente((int) $empresaFiltro)); ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i>Voltar
        </a>
        </div>
    </div>

    <?php if ($empresaSelecionada): ?>
    <?php /* A barra "Cliente em foco" saiu em 10/09/2026: a trilha e a lateral ja dizem onde se esta. */ ?>
        <?php if ($assinaturaAtiva): ?>
            <?php
            $contasPixAss = array_values(array_filter($contas, static function ($c) {
                return !empty($c['aceita_pix']);
            }));
            ?>
            <div class="card mb-3" data-tour="cob-faixa">
                <div class="card-body py-2 d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <?php
                    // A ASSINATURA SO E "ATIVA" DEPOIS DO PRIMEIRO PAGAMENTO (10/09/2026,
                    // tarde): antes disso ela esta esperando; com a mensalidade vencida,
                    // esta vencida. A palavra sai da validade da empresa.
                    $validadeAss = trim((string) ($empresaSelecionada['validade_licenca'] ?? ''));
                    $validadeAss = ($validadeAss === '' || $validadeAss === '0000-00-00') ? '' : substr($validadeAss, 0, 10);
                    // "Aguardando o primeiro" so vale para quem NUNCA pagou; a lista
                    // desta tela e filtrada, entao a pergunta vai ao banco.
                    $jaPagou = shield_cobranca_ja_pagou($pdo, (int) $empresaSelecionada['codigo']);
                    if (!$jaPagou && $validadeAss === '') {
                        $estadoAss = array('atencao', 'Assinatura aguardando o primeiro pagamento');
                    } elseif ($validadeAss === '' || $validadeAss < date('Y-m-d')) {
                        $estadoAss = array('erro', 'Assinatura com mensalidade vencida' . ($validadeAss !== '' ? ' &middot; licen&ccedil;a at&eacute; ' . date('d/m/Y', strtotime($validadeAss)) : ''));
                    } else {
                        $estadoAss = array('ok', 'Assinatura ativa &middot; licen&ccedil;a at&eacute; ' . date('d/m/Y', strtotime($validadeAss)));
                    }
                    ?>
                    <div class="small">
                        <div><i class="fas fa-sync-alt me-1" style="color: var(--<?= $estadoAss[0]; ?>)"></i><strong><?= $estadoAss[1]; ?></strong></div>
                        <div class="text-secondary">R$ <?= shield_h(shield_dinheiro((int) $assinaturaAtiva['valor_centavos'])); ?> <?= shield_h(shield_plano_ciclo_rotulo((int) ($assinaturaAtiva['ciclo_meses'] ?? 1))); ?><?= (int) ($assinaturaAtiva['ciclo_meses'] ?? 1) > 1 ? ' (R$ ' . shield_h(shield_dinheiro(shield_assinatura_por_mes($assinaturaAtiva))) . ' por m&ecirc;s)' : ''; ?>, todo dia <?= (int) $assinaturaAtiva['dia_vencimento']; ?><?= !empty($assinaturaAtiva['plano_nome']) ? ' &middot; ' . shield_h((string) $assinaturaAtiva['plano_nome']) : ''; ?></div>
                        <div class="text-secondary">quem gera o PIX: <?= !empty($assinaturaAtiva['conta_apelido']) ? shield_h((string) $assinaturaAtiva['conta_apelido']) : 'ningu&eacute;m (rascunho)'; ?></div>
                        <?php $promFaixa = shield_promessa_aberta($pdo, (int) $empresaSelecionada['codigo']); if ($promFaixa !== null): ?>
                            <div style="color: var(--ok)"><i class="fas fa-calendar-day me-1"></i>prazo aceito: a loja trabalha at&eacute; <strong><?= shield_h(date('d/m/Y', strtotime((string) $promFaixa['ate']))); ?></strong> (+<?= max(0, (int) round((strtotime((string) $promFaixa['ate']) - strtotime('today')) / 86400)); ?> dias) com a fatura em aberto</div>
                        <?php endif; ?>
                    </div>
                    <?php /* "Editar assinatura" saiu daqui (10/09/2026): mudar como paga e em Mudar o
                             contrato, e o lapis da lista ja leva la. */ ?>
                </div>
            </div>
        <?php else: ?>
            <?php
            // SEM ASSINATURA = PRE-PAGO (ou lead). A faixa diz ate quando o
            // sistema esta liberado, que e o que o membro quer saber ao abrir.
            $validadeSel = trim((string) ($empresaSelecionada['validade_licenca'] ?? ''));
            $validadeSel = ($validadeSel === '' || $validadeSel === '0000-00-00') ? '' : substr($validadeSel, 0, 10);
            ?>
            <div class="card mb-3">
                <div class="card-body py-2 d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div class="small">
                        <?php if ($validadeSel !== '' && $validadeSel >= date('Y-m-d')): ?>
                            <div><i class="fas fa-calendar-alt me-1" style="color: var(--ok)"></i><strong>Pr&eacute;-pago ativo</strong></div>
                            <div class="text-secondary">sistema dispon&iacute;vel at&eacute; <strong><?= shield_h(date('d/m/Y', strtotime($validadeSel))); ?></strong></div>
                        <?php elseif ($validadeSel !== ''): ?>
                            <div><i class="fas fa-calendar-alt me-1" style="color: var(--erro)"></i><strong>Pr&eacute;-pago vencido</strong></div>
                            <div class="text-secondary">venceu em <?= shield_h(date('d/m/Y', strtotime($validadeSel))); ?>; a pr&oacute;xima fatura paga libera de novo</div>
                            <?php $promFaixa = shield_promessa_aberta($pdo, (int) $empresaSelecionada['codigo']); if ($promFaixa !== null): ?>
                                <div style="color: var(--ok)"><i class="fas fa-calendar-day me-1"></i>prazo aceito: a loja trabalha at&eacute; <strong><?= shield_h(date('d/m/Y', strtotime((string) $promFaixa['ate']))); ?></strong> com a fatura em aberto</div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div><i class="fas fa-calendar-alt me-1 text-secondary"></i><strong>Sem contrato ainda</strong></div>
                            <div class="text-secondary">em avalia&ccedil;&atilde;o</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if (($_GET['ok'] ?? '') === 'assinatura'): ?>
            <?php shield_aviso_flutuante('Assinatura alterada. Vale a partir do pr&oacute;ximo PIX.', 'ok', true); ?>
        <?php endif; ?>
        <?php if ($saldoCliente !== 0): ?>
            <div class="alert <?= $saldoCliente > 0 ? 'alert-success' : 'alert-warning'; ?> py-2 small">
                <?php if ($saldoCliente > 0): ?>
                    Este cliente tem <strong>R$ <?= shield_h(shield_dinheiro($saldoCliente)); ?> de cr&eacute;dito</strong>
                    (pagou a mais). A pr&oacute;xima cobran&ccedil;a nasce com esse desconto.
                <?php else: ?>
                    Este cliente <strong>deve R$ <?= shield_h(shield_dinheiro(abs($saldoCliente))); ?></strong>
                    de uma cobran&ccedil;a paga a menos. A pr&oacute;xima cobran&ccedil;a nasce com esse valor somado.
                <?php endif; ?>
                <?php if ($podeConfirmar): ?>
                    <?php /* AJUSTAR O CREDITO (14/10/2026): antes so pelo banco. Grava o
                             valor novo -- 0 zera --, com motivo, no livro. */ ?>
                    <details class="mt-2">
                        <summary>Ajustar o cr&eacute;dito</summary>
                        <form method="post" class="d-flex flex-wrap gap-2 align-items-end mt-2">
                            <input type="hidden" name="acao" value="ajustar_saldo">
                            <input type="hidden" name="empresa" value="<?= (int) $empresaFiltro; ?>">
                            <div>
                                <label class="form-label small mb-1" for="saldoNovo">Cr&eacute;dito novo (R$)</label>
                                <input type="text" id="saldoNovo" name="saldo_novo" class="form-control form-control-sm num dinheiro" value="0,00" required style="width: 8rem">
                            </div>
                            <div class="flex-grow-1">
                                <label class="form-label small mb-1" for="saldoMotivo">Motivo</label>
                                <input type="text" id="saldoMotivo" name="motivo" class="form-control form-control-sm" maxlength="150" required
                                       placeholder="Ex.: eram juros do atraso, e n&atilde;o pagamento a mais">
                            </div>
                            <button class="btn btn-sm btn-outline-secondary">Gravar</button>
                        </form>
                        <div class="form-text">0,00 zera. A diferen&ccedil;a fica no livro de auditoria com o motivo.</div>
                    </details>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php /* A RESPOSTA DO PROVEDOR FICA; O RESTO FLUTUA (14/09/2026). "Consultar"
             e uma pergunta, e a resposta e o que se veio ler: nao pode sumir em
             cinco segundos, e nao e verde -- "ainda nao foi emitida" em verde
             ensinava a ignorar o verde de quando ha dinheiro. Com variavel
             propria, a cor deixou de ser adivinhada pelo texto da frase. */ ?>
    <?php shield_aviso_flutuante($aviso, '', $avisoDemorado); ?>
    <?php if ($resposta !== ''): ?>
        <div class="alert alert-secondary"><?= shield_h($resposta); ?></div>
    <?php endif; ?>
    <?php if ($erro !== ''): ?>
        <div class="alert alert-danger"><?= shield_h($erro); ?></div>
    <?php endif; ?>

    <?php if (empty($contas)): ?>
        <div class="alert alert-warning">
            Nenhuma conta de recebimento ativa. Ligue uma em
            <a href="/formas_recebimento.php" class="alert-link">Formas de recebimento</a>
            &mdash; sem conta n&atilde;o h&aacute; como emitir.
        </div>
    <?php endif; ?>

    <?php /* Quem ja tem assinatura raramente abre cobranca a mao: o PIX do mes
             nasce sozinho. Para esse cliente o formulario vem FECHADO, e abre
             no clique; para quem ainda nao tem (a primeira cobranca), aberto. */ ?>
    <?php /* SEMPRE FECHADA (10/09/2026, tarde): a tela e a lista; abrir cobranca a mao e excecao. */ ?>
    <details class="card mb-3 grupo-terminais" data-tour="cob-nova">
        <summary>
            <span class="grupo-nome"><i class="fas fa-plus-circle"></i> Nova cobran&ccedil;a</span>
            <span class="grupo-resumo">
                <?php if ($assinaturaAtiva): ?><span class="grupo-total">o PIX do m&ecirc;s nasce sozinho; abra s&oacute; para algo fora da assinatura</span><?php endif; ?>
                <i class="fas fa-sort-down grupo-seta"></i>
            </span>
        </summary>
        <div class="card-body">
            <?php /* A AVULSA NAO COMPOE, e a tela precisa dizer -- 09/09/2026.
                     Modulos contratados e terminal alem do plano entram so na
                     cobranca do ciclo. Somar mensalidade a uma compra de doze
                     meses, ou a uma hora de suporte, seria escolher um preco no
                     lugar do membro. Sem esta linha ele descobria a diferenca
                     comparando dois PIX. */ ?>
            <p class="small text-secondary mb-2">
                Vale o que voc&ecirc; digitar. M&oacute;dulos e terminal adicional entram s&oacute; na
                mensalidade do ciclo &mdash; aqui n&atilde;o somam.
            </p>
            <form method="post" action="<?= shield_h($urlCobrancas); ?>" class="row g-2 align-items-start" id="formCobranca" autocomplete="off">
                <input type="hidden" name="acao" value="abrir">
                <input type="hidden" name="assinatura" id="assinatura" value="0">
                <?php /* "assinatura" nao vale mais nada no POST (shield_cobranca_dados_da_origem a zera);
                         fica porque o JS da origem ainda escreve nele. */ ?>
                <input type="hidden" name="chave" value="<?= shield_h($chaveNova); ?>">

                <div class="col-12 col-lg-4">
                    <label class="form-label small mb-1" for="empresa">Cliente</label>
                    <?php if ($escopo): ?>
                        <?php
                        // Mesmo motivo da tela de terminais: com o titulo, a barra e a
                        // lista inteira falando de um cliente, um <select> aqui abre a
                        // porta para lancar a cobranca na empresa errada.
                        ?>
                        <input type="hidden" name="empresa" value="<?= (int) $empresaFiltro; ?>">
                        <div class="campo-fixo">
                            <span><?= shield_h((string) $empresaSelecionada['razao']); ?></span>
                        </div>
                    <?php else: ?>
                        <select id="empresa" name="empresa" class="form-select form-select-sm" required>
                            <option value="">Escolha o cliente</option>
                            <?php foreach ($clientes as $cli): ?>
                                <option value="<?= (int) $cli['codigo']; ?>">
                                    <?= shield_h((string) $cli['razao']); ?> &middot; <?= shield_h(shield_cnpj((string) $cli['cnpj'])); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    <?php endif; ?>
                </div>

                <div class="col-12 col-lg-5">
                    <?php /* OS MESES DO PERSONALIZADO MORAM AQUI, AO LADO DE "COBRAR POR" (17/09/2026).
                             Como coluna propria na fileira de baixo, somavam 14 colunas com o botao: a
                             fileira parava antes da borda e "Abrir cobranca" descia sozinho. Aqui dentro
                             as duas fileiras fecham 12, com ou sem eles (CobrancasTelaTest). */ ?>
                    <div class="row g-2">
                        <div class="col">
                            <label class="form-label small mb-1" for="origem">Cobrar por</label>
                            <?php /* Os tres jeitos ficam agrupados e sempre visiveis, inclusive
                                     o que este cliente ainda nao tem: escondido, "assinatura"
                                     parecia nao existir no painel, e o membro cobrava a mao
                                     todo mes uma coisa que nasceria sozinha. */ ?>
                            <select id="origem" name="origem" class="form-select form-select-sm">
                                <optgroup label="Uma vez s&oacute;">
                                    <?php /* A AVULSA NAO E "MENSALIDADE" (14/09/2026): instalacao e backup chegavam ao ERP
                                             e a area do cliente com esse nome, ao lado da mensalidade de verdade. */ ?>
                                    <option value="avulsa" data-descricao="Cobran&ccedil;a avulsa" data-valor="" data-meses="0">
                                        Cobran&ccedil;a avulsa &middot; valor livre
                                    </option>
                                </optgroup>
                                <?php /* A ASSINATURA SAIU DAQUI (10/09/2026, tarde): a mensalidade nasce sozinha
                                         pelo ciclo, e mudar de plano e em Mudar o contrato. */ ?>
                                <?php if (false && $assinaturaAtiva): ?>
                                    <option value="assinatura"
                                            data-assinatura="<?= (int) $assinaturaAtiva['id']; ?>"
                                            data-descricao="Mensalidade"
                                            data-valor="<?= shield_h(shield_dinheiro((int) $assinaturaAtiva['valor_centavos'])); ?>"
                                            data-dia="<?= (int) $assinaturaAtiva['dia_vencimento']; ?>"
                                            data-forma="pix"
                                            data-meses="0">
                                        Assinatura ativa &middot; R$ <?= shield_h(shield_dinheiro((int) $assinaturaAtiva['valor_centavos'])); ?>
                                        a cada <?= (int) $assinaturaAtiva['ciclo_meses']; ?> <?= ((int) $assinaturaAtiva['ciclo_meses']) == 1 ? 'm&ecirc;s' : 'meses'; ?>
                                    </option>
                                <?php else: ?>
                                    <?php /* ASSINATURA NOVA NAO NASCE MAIS AQUI -- 10/09/2026, fatia 7.
                                             Nasce no fechamento (Em avaliacao > Dar inicio ao contrato), o
                                             unico lugar que sabe o contrato inteiro. Aqui fica so a
                                             cobranca avulsa e o pre-pago. */ ?>
                                <?php endif; ?>
                                <optgroup label="Paga uma vez, vale por um per&iacute;odo">
                                    <?php /* PERIODO PERSONALIZADO (17/09/2026, pedido de membro): o negocio fechado
                                             fora da tabela de planos. Meses e valor digitados aqui; pago, compra os
                                             meses como um plano (shield_cobranca_dados_da_origem). */ ?>
                                    <option value="personalizado" data-descricao="" data-valor="" data-meses="0">
                                        Per&iacute;odo personalizado &middot; voc&ecirc; digita os meses e o valor
                                    </option>
                                <?php if (empty($planos)): ?>
                                    <option value="" disabled>Nenhum plano cadastrado (Configura&ccedil;&otilde;es &gt; Planos)</option>
                                <?php endif; ?>
                                <?php foreach ($planos as $pl): ?>
                                    <?php
                                    $meses = max(1, (int) $pl['recorrencia']);
                                    $emCentavos = shield_centavos((string) $pl['valor']);
                                    // "mes" perde o circunflexo no plural; "meses", nunca "meses" com acento.
                                    $rotuloMeses = $meses . ' ' . ($meses == 1 ? 'm&ecirc;s' : 'meses');
                                    ?>
                                    <?php $nomePlano = trim((string) ($pl['descricao'] ?? '')) !== '' ? (string) $pl['descricao'] : 'Plano de ' . $rotuloMeses; ?>
                                    <option value="plano:<?= (int) $pl['id']; ?>"
                                            data-descricao="<?= shield_h($nomePlano); ?>"
                                            data-valor="<?= shield_h(shield_dinheiro($emCentavos)); ?>"
                                            data-meses="<?= $meses; ?>">
                                        <?= shield_h($nomePlano); ?> &middot; <?= $rotuloMeses; ?>
                                        &middot; R$ <?= shield_h(shield_dinheiro($emCentavos)); ?>
                                    </option>
                                <?php endforeach; ?>
                                </optgroup>
                            </select>
                        </div>

                        <?php /* SO NO PERIODO PERSONALIZADO. Nasce DESABILITADO: escondido e obrigatorio,
                                 ele travaria o envio de todas as outras escolhas (o navegador recusa enviar
                                 formulario com campo invalido); desabilitado nem e validado nem vai no POST. */ ?>
                        <div class="col-auto d-none" id="blocoMeses">
                            <label class="form-label small mb-1" for="meses">Meses de licen&ccedil;a</label>
                            <input id="meses" name="meses" disabled required type="number" min="1"
                                   max="<?= (int) SHIELD_PLANO_PREPAGO_MAX_MESES; ?>" step="1" value="1"
                                   class="form-control form-control-sm num" style="width: 7rem">
                        </div>
                    </div>
                </div>

                <div class="col-12 col-lg-3">
                    <label class="form-label small mb-1" for="descricao">Descri&ccedil;&atilde;o</label>
                    <input id="descricao" type="text" name="descricao" class="form-control form-control-sm"
                           value="Cobran&ccedil;a avulsa" maxlength="150">
                </div>

                <div class="col-6 col-lg-2">
                    <label class="form-label small mb-1" for="valor">Valor</label>
                    <input id="valor" type="text" name="valor" class="form-control form-control-sm num dinheiro"
                           placeholder="149,00" required>
                </div>

                <div class="col-6 col-lg-2">
                    <label class="form-label small mb-1" for="vencimento">Vence em</label>
                    <input id="vencimento" type="date" name="vencimento" class="form-control form-control-sm"
                           value="<?= shield_h($vencimentoPadrao); ?>" required>
                </div>

                <div class="col-12 col-sm-8 col-lg-3">
                    <?php /* A CONTA VEM ANTES E MANDA NA FORMA (14/09/2026, pedido do dono). Era o
                             contrario: a forma escondia as contas que nao a faziam, e o Asaas com cartao
                             desmarcado em "Cobra por" seguia oferecendo cartao. Como em Mudar o contrato. */ ?>
                    <label class="form-label small mb-1" for="conta">Quem gera o PIX / boleto</label>
                    <?php /* SEM "NINGUEM AGORA" (10/09/2026, noite): a cobranca sai por uma conta.
                             A padrao ja vem escolhida; sem conta ligada, fica em rascunho, e ali a
                             forma e so um rotulo: valem as tres. */ ?>
                    <select id="conta" name="conta" class="form-select form-select-sm">
                        <?php if ($contasNova === array()): ?><option value="0" data-formas="pix,boleto,cartao">nenhuma conta ligada (fica em rascunho)</option><?php endif; ?>
                        <?php foreach ($contasNova as $c): ?>
                            <option value="<?= (int) $c['id']; ?>" <?= (int) $c['id'] === $contaNova ? 'selected' : ''; ?>
                                    data-formas="<?= shield_h(implode(',', $formasPorConta[(int) $c['id']] ?? array())); ?>">
                                <?php /* O rotulo diz "confirmacao manual": e o que avisa que ninguem vai dar baixa sozinho. */ ?>
                                <?= shield_h(shield_conta_rotulo($c)); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-12 col-sm-4 col-lg-2">
                    <label class="form-label small mb-1" for="forma">Como o cliente paga</label>
                    <?php /* SO AS FORMAS DA CONTA AO LADO, UMA ESCOLHA (shield_conta_formas, a mesma
                             lista que o POST confere). As que ela nao cobra vao hidden e disabled, e nao
                             fora do HTML: trocar de conta so as reacende. Desenhadas aqui, e nao pelo JS
                             na carga, para a forma nao trocar diante do membro. */ ?>
                    <select id="forma" name="forma" class="form-select form-select-sm">
                        <?php foreach (array('pix', 'boleto', 'cartao', 'dinheiro') as $f): ?>
                            <?php $serveNova = in_array($f, $formasPorConta[$contaNova], true); ?>
                            <option value="<?= $f; ?>"<?= $serveNova ? '' : ' hidden disabled'; ?><?= $f === $formaNova ? ' selected' : ''; ?>><?= $rotuloForma[$f]; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-12 col-lg-3">
                    <?php /* Rotulo vazio na mesma altura dos outros: com o botao preso ao
                             pe da coluna, a mensagem de erro de um campo vizinho o
                             empurrava para baixo e a fileira quebrava. */ ?>
                    <span class="form-label small mb-1 d-none d-lg-block">&nbsp;</span>
                    <button type="submit" class="btn btn-primary btn-sm w-100">
                        <i class="fas fa-plus-circle me-1"></i>Abrir cobran&ccedil;a
                    </button>
                </div>

                <div class="col-12">
                    <div class="form-text mt-0">
                        <?php /* So no plano e no personalizado: o que dura N meses e o ACESSO, nao o prazo de
                                 pagar. Vai nesta linha, que ja existe, para nao empurrar
                                 a fileira de campos quando aparece. */ ?>
                        <strong class="d-none" id="notaAcesso"></strong>
                        <?php /* SO NA AVULSA (14/09/2026): ela nao compra mes nenhum. Nasce visivel porque a
                                 avulsa e a origem que abre escolhida; o JS so a esconde no plano. CURTA E
                                 POSITIVA (14/09/2026, o dono): a versao que apontava Mudar o contrato fazia
                                 parecer que a avulsa nao servia para instalacao ou backup, que e o uso dela. */ ?>
                        <span id="notaAvulsa"><strong>Avulsa:</strong> cobra uma vez (instala&ccedil;&atilde;o, backup, visita) e n&atilde;o mexe na licen&ccedil;a.
                            Para vender meses de licen&ccedil;a, escolha um plano em Cobrar por, ou o per&iacute;odo personalizado.<br></span>
                        <?php /* Sem esta linha, "a cobranca nasceu e nao ha nada para mandar" parecia defeito. */ ?>
                        <strong>Dinheiro em esp&eacute;cie</strong> n&atilde;o gera c&oacute;digo: a cobran&ccedil;a fica a receber e voc&ecirc; confirma quando o dinheiro entrar.<br>
                        <strong>Quem gera</strong> &eacute; a conta que cria o PIX ou o boleto de verdade
                        (a sua chave, ou um provedor configurado em <a href="/formas_recebimento.php">Formas de recebimento</a>).<br>
                        Se o provedor n&atilde;o responder, a cobran&ccedil;a fica em rascunho e voc&ecirc; gera depois pelo raio na lista.
                    </div>
                </div>
            </form>
        </div>
    </details>

    <script>
    (function () {
      var origem = document.getElementById('origem');
      if (!origem) { return; }

      var descricao = document.getElementById('descricao');
      var valor = document.getElementById('valor');
      var vencimento = document.getElementById('vencimento');
      var notaAcesso = document.getElementById('notaAcesso');
      var assinatura = document.getElementById('assinatura');
      var conta = document.getElementById('conta');
      var forma = document.getElementById('forma');
      var notaAvulsa = document.getElementById('notaAvulsa');
      var blocoMeses = document.getElementById('blocoMeses');
      var campoMeses = document.getElementById('meses');

      var padrao = <?= json_encode($vencimentoPadrao); ?>;

      function doisDigitos(n) { return (n < 10 ? '0' : '') + n; }
      function iso(d) {
        return d.getFullYear() + '-' + doisDigitos(d.getMonth() + 1) + '-' + doisDigitos(d.getDate());
      }
      function br(d) {
        return doisDigitos(d.getDate()) + '/' + doisDigitos(d.getMonth() + 1) + '/' + d.getFullYear();
      }

      // A CONTA MANDA NA FORMA (14/09/2026), como mudFormas em Mudar o contrato.
      // Cada conta traz em data-formas o que ela cobra; a forma mostra so essas, e
      // a escolhida que nao serve mais cai na primeira que serve. So no clique: ao
      // abrir, o PHP ja desenhou as opcoes da conta escolhida. Conta sem forma
      // nenhuma deixa tudo apagado, e o POST recusa com a frase que diz onde marcar.
      function mudarFormas() {
        var op = conta.options[conta.selectedIndex];
        var faz = op ? (op.getAttribute('data-formas') || '').split(',') : [];
        var primeira = null;
        Array.prototype.forEach.call(forma.options, function (o) {
          var serve = faz.indexOf(o.value) !== -1;
          o.hidden = !serve;
          o.disabled = !serve;
          if (serve && primeira === null) { primeira = o; }
        });
        var atual = forma.options[forma.selectedIndex];
        if ((!atual || atual.disabled) && primeira) { primeira.selected = true; }
      }

      function aplicarOrigem(soMeses) {
        var o = origem.options[origem.selectedIndex];
        var personalizado = origem.value === 'personalizado';
        // No personalizado os meses vem do campo, e nao da opcao.
        var meses = personalizado
          ? Math.max(0, parseInt(campoMeses.value || '0', 10) || 0)
          : parseInt(o.getAttribute('data-meses') || '0', 10);

        // O campo de meses so vale no personalizado: desabilitado, ele sai da
        // validacao do navegador e do POST das outras escolhas.
        blocoMeses.classList.toggle('d-none', !personalizado);
        campoMeses.disabled = !personalizado;

        assinatura.value = o.getAttribute('data-assinatura') || '0';
        // Sem data-descricao, o nome neutro: "Mensalidade" numa instalacao chegava assim ao ERP.
        // \u00e7, e nao o c cedilha cru: este arquivo e todo ASCII (no HTML o acento vai por entidade).
        // Trocar os meses nao apaga a descricao que o membro escreveu a mao.
        var escritaAMao = soMeses === true && descricao.value.indexOf('Per\u00edodo de ') !== 0;
        if (personalizado && !escritaAMao) {
          descricao.value = 'Per\u00edodo de ' + meses + (meses === 1 ? ' m\u00eas' : ' meses');
        } else if (!personalizado) descricao.value = o.getAttribute('data-descricao') || 'Cobran\u00e7a avulsa';
        // A nota da avulsa some no plano, que compra os meses dele e ganha a nota do acesso.
        notaAvulsa.classList.toggle('d-none', origem.value !== 'avulsa');

        var v = o.getAttribute('data-valor') || '';
        if (v) { valor.value = v; }
        // Plano e assinatura tem preco de cadastro: o campo mostra, nao edita.
        valor.readOnly = v !== '';
        valor.classList.toggle('campo-travado', v !== '');

        // A FORMA NAO E DA ORIGEM (14/09/2026): e da conta, e so a troca de conta mexe
        // nela. A trava "assinatura e sempre PIX" morreu com a opcao de assinatura
        // (10/09/2026, tarde), e select desabilitado nem iria no POST.

        if (meses > 0) {
          // O plano vence para PAGAR em poucos dias; o que dura N meses e o
          // acesso. Somar os meses no vencimento poria o cliente pagando no
          // fim do periodo que ele ja usou.
          var fim = new Date();
          fim.setMonth(fim.getMonth() + meses);
          vencimento.value = padrao;
          notaAcesso.textContent = 'Acesso at\u00e9 ' + br(fim) + ' (' + meses + (meses === 1 ? ' m\u00eas' : ' meses') + '). ';
          notaAcesso.classList.remove('d-none');
        } else {
          notaAcesso.classList.add('d-none');
          if (o.getAttribute('data-dia')) {
            // Assinatura: cai no dia dela, neste mes se ainda nao passou.
            var dia = parseInt(o.getAttribute('data-dia'), 10);
            var alvo = new Date();
            if (alvo.getDate() > dia) { alvo.setMonth(alvo.getMonth() + 1); }
            alvo.setDate(dia);
            vencimento.value = iso(alvo);
          }
        }
      }

      origem.addEventListener('change', aplicarOrigem);
      campoMeses.addEventListener('input', function () { aplicarOrigem(true); });
      conta.addEventListener('change', mudarFormas);
      // Na carga so a origem: conta e forma ja vieram casadas do PHP.
      aplicarOrigem();
    }());
    </script>

    <div class="card" data-tour="cob-lista">
        <div class="card-header">
            <?= $filtro === 'abertas' ? 'Em aberto' : ($filtro === 'paga' ? 'Pagas' : ($filtro === 'prazo' ? 'Pedem prazo' : ($filtro === 'cancelada' ? 'Canceladas' : 'Todas'))); ?>
            <?php if ($agrupar): ?><span class="text-secondary small ms-1">&middot; <?= count($grupos); ?> cliente<?= count($grupos) == 1 ? '' : 's'; ?></span><?php endif; ?>
        </div>
        <div class="card-body p-0">
            <?php if (empty($lista)): ?>
                <div class="vazio">
                    <i class="fas fa-money-bill-wave"></i>
                    <?php if ($busca !== ''): ?>
                        <?php /* Com busca, "nenhuma cobranca para este cliente" mentia: quem nao achou
                                 nada foi o texto digitado. */ ?>
                        Nada encontrado para &ldquo;<?= shield_h($busca); ?>&rdquo;.
                        <a href="<?= shield_h(shield_url_com_empresa('/cobrancas.php', $empresaFiltro, array('situacao' => $filtro))); ?>">Limpar a busca</a>.
                    <?php elseif ($filtro === 'abertas'): ?>
                        Nada em aberto. Quando houver cobran&ccedil;a a receber, ela aparece aqui.
                    <?php elseif ($filtro === 'paga'): ?>
                        Nenhuma cobran&ccedil;a paga ainda.
                    <?php elseif ($filtro === 'cancelada'): ?>
                        Nenhuma cobran&ccedil;a cancelada.
                    <?php elseif ($filtro === 'prazo'): ?>
                        Nenhum pedido de prazo esperando resposta. Quando um cliente pedir pelo sistema, ele aparece aqui e o menu acende.
                    <?php else: ?>
                        <?= $escopo ? 'Nenhuma cobran&ccedil;a para este cliente.' : 'Nenhuma cobran&ccedil;a ainda.'; ?>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <?php if ($listaCortada): ?>
                    <?php /* O CORTE DIZ QUE CORTOU (14/09/2026). Agrupada, a lista sem aviso mostraria
                             um cliente com parte das faturas como se fossem todas. O dinheiro do
                             cabecalho de cada grupo nao sofre o corte: vem do banco. */ ?>
                    <div class="alert alert-warning py-2 small m-2 mb-0">
                        Mostrando as <?= SHIELD_COB_LISTA_LIMITE; ?> cobran&ccedil;as mais recentes; as mais antigas ficaram de fora.
                        Busque pelo cliente ou abra s&oacute; ele para ver todas. O valor no cabe&ccedil;alho de cada cliente conta todas.
                    </div>
                <?php endif; ?>
                <?php
                // Um bloco por cliente fora de um cliente; dentro de um, um bloco so e sem
                // cabecalho, como sempre foi. O MESMO laco de linhas serve aos dois: coluna a
                // mais num e a menos no outro so se ve depois, quando alguem corrige um so.
                $blocos = $agrupar ? $grupos : array(0 => array('linhas' => $lista));
                ?>
                <?php if ($agrupar): ?><div class="grupos-terminais p-2"><?php endif; ?>
                <?php foreach ($blocos as $codigoGrupo => $g): ?>
                <?php if ($agrupar): ?>
                    <?php
                    $totalGrupo = count($g['linhas']);
                    $aVencer = $g['aberto'] - $g['vencido'];
                    $qtdAVencer = $g['qtd_aberto'] - $g['qtd_vencido'];
                    // Pedido de prazo e prazo aceito aparecem na linha da primeira fatura em aberto
                    // (4.1.12). Com o grupo fechado a linha nao se ve: o cabecalho avisa -- e so
                    // quando essa linha esta na lista, senao o aviso levaria a um bloco sem botao.
                    $pedePrazo = $g['em_aberto_na_lista'] > 0 && isset($promessasPendentes[$codigoGrupo]);
                    $prazoAceito = $g['em_aberto_na_lista'] > 0 ? ($promessasAceitas[$codigoGrupo] ?? null) : null;
                    ?>
                    <?php /* Fechado sempre (preferencia do dono), menos o da acao que acabou de rodar. */ ?>
                    <?php /* No recorte "Pedem prazo" o grupo nasce aberto (01/10/2026): aceitar e
                             recusar moram na linha da fatura, dentro dele, e fechado o membro via
                             a pilula "pede prazo" no cabecalho sem saber onde responder. */ ?>
                    <details class="card grupo-terminais grupo-cobrancas"<?= (($empresaDaAcao > 0 && $codigoGrupo === $empresaDaAcao) || $filtro === 'prazo') ? ' open' : ''; ?>>
                        <summary>
                            <span class="grupo-nome"><i class="fas fa-building"></i> <?= shield_h($g['razao']); ?>
                                <?php if ($g['cnpj'] !== ''): ?><span class="apoio ms-2 num"><?= shield_h(shield_cnpj($g['cnpj'])); ?></span><?php endif; ?></span>
                            <span class="grupo-resumo">
                                <?php /* O RESUMO NUNCA FICA VAZIO (14/09/2026, pedido do dono): cliente com tudo pago
                                         mostrava so "2 cobrancas", e de relance nao se sabia se devia. Quantas e quanto
                                         vem do banco (shield_cobranca_resumo_por_empresa), e nao das linhas: o corte da
                                         lista deixaria de fora justamente a vencida mais antiga. */ ?>
                                <?php if ($g['qtd_vencido'] > 0): ?><span class="pilula pilula-erro"><?= (int) $g['qtd_vencido']; ?> vencida<?= $g['qtd_vencido'] == 1 ? '' : 's'; ?> &middot; R$ <?= shield_h(shield_dinheiro($g['vencido'])); ?></span><?php endif; ?>
                                <?php /* "A VENCER", e nao "em aberto" (14/09/2026, o dono): o filtro "Em aberto" desta tela
                                         inclui as vencidas, e a pilula amarela so conta as que ainda nao venceram. */ ?>
                                <?php if ($qtdAVencer > 0): ?><span class="pilula pilula-atencao"><?= (int) $qtdAVencer; ?> a vencer &middot; R$ <?= shield_h(shield_dinheiro($aVencer)); ?></span><?php endif; ?>
                                <?php if ($g['qtd_aberto'] === 0): ?><span class="pilula pilula-ok" title="Nada aberto nem vencido">em dia</span><?php endif; ?>
                                <?php if ($g['rascunhos'] > 0): ?><span class="pilula pilula-neutro"><?= (int) $g['rascunhos']; ?> a emitir</span><?php endif; ?>
                                <?php if ($pedePrazo): ?><span class="pilula pilula-atencao">pede prazo</span><?php endif; ?>
                                <?php if ($prazoAceito !== null): ?><span class="pilula pilula-ok">prazo at&eacute; <?= shield_h(date('d/m', strtotime((string) $prazoAceito['ate']))); ?></span><?php endif; ?>
                                <?php if ($g['avisou']): ?><span class="pilula pilula-atencao">avisou que pagou</span><?php endif; ?>
                                <span class="grupo-total num"><?= $totalGrupo; ?> cobran&ccedil;a<?= $totalGrupo == 1 ? '' : 's'; ?></span>
                                <i class="fas fa-sort-down grupo-seta"></i>
                            </span>
                        </summary>
                        <?php /* A LINHA "SO AS COBRANCAS DESTE CLIENTE" SAIU (14/09/2026, pedido do dono): era uma
                                 faixa a mais entre o cabecalho e as faturas. O caminho para o cliente passou a ser
                                 o olho de cada fatura, que abre a ficha. */ ?>
                <?php endif; ?>
                <div class="table-responsive">
                <table class="lista">
                    <thead><tr>
                        <th scope="col" style="width:1%"><span class="visually-hidden">Situa&ccedil;&atilde;o</span></th>
                        <th scope="col"><?= $agrupar ? 'Cobran&ccedil;a' : 'Cliente'; ?></th>
                        <th scope="col">Emitida por</th>
                        <th scope="col" class="num">Valor</th>
                        <th scope="col" class="num">Vence</th>
                        <th scope="col" class="meio">A&ccedil;&otilde;es</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($g['linhas'] as $c):
                        $id = (int) $c['id'];
                        $sit = (string) $c['situacao'];
                        $rascunho = ($sit === SHIELD_COB_RASCUNHO);
                        $terminal = shield_cob_terminal($sit);
                        $atrasada = (!$terminal && strtotime((string) $c['vencimento']) < strtotime('today'));
                        $nome = (string) ($c['razao'] ?? 'Cliente');
                        // A cor do selo sai da situacao, e "vencida" nao e o
                        // mesmo cinza de "rascunho": uma pede acao hoje.
                        $selo = array(
                            SHIELD_COB_PAGA => array('ok', 'fa-check-circle'),
                            SHIELD_COB_ABERTA => array($atrasada ? 'erro' : 'atencao', 'fa-hourglass-half'),
                            SHIELD_COB_VENCIDA => array('erro', 'fa-exclamation-triangle'),
                            SHIELD_COB_RASCUNHO => array('neutro', 'fa-file-signature'),
                        );
                        list($selCor, $selIcone) = $selo[$sit] ?? array('neutro', 'fa-info-circle');
                    ?>
                        <tr>
                            <td class="meio sem-rotulo">
                                <span class="selo <?= $selCor; ?>" title="<?= shield_h($sit); ?>">
                                    <i class="fas <?= $selIcone; ?>"></i>
                                </span>
                            </td>
                            <td class="identidade" data-r="<?= $agrupar ? 'Cobran&ccedil;a' : 'Cliente'; ?>">
                                <div>
                                    <?php
                                    // QUANTO TEMPO A FATURA VALE (10/09/2026, noite): sem isto o membro
                                    // pagava um "anual" e via a validade andar um mes sem saber por que.
                                    $mesesVale = (int) ($c['meses'] ?? 0);
                                    $valeTexto = $mesesVale > 0
                                        ? 'vale ' . $mesesVale . ($mesesVale == 1 ? ' m&ecirc;s' : ' meses')
                                        : (empty($c['fk_assinatura']) ? 'n&atilde;o move a validade' : '');
                                    ?>
                                    <?php if ($agrupar): ?>
                                        <?php /* DENTRO DO GRUPO A LINHA E A FATURA (14/09/2026): o nome do cliente ja
                                                 esta no cabecalho do bloco, e repeti-lo em cada linha empurrava para
                                                 baixo o que distingue uma fatura da outra. */ ?>
                                        <span class="nome"><?= shield_h((string) $c['descricao']); ?></span>
                                        <?php if ($valeTexto !== ''): ?><span class="apoio"><?= $valeTexto; ?></span><?php endif; ?>
                                    <?php else: ?>
                                        <?php /* O NOME ABRE AS COBRANCAS DESTE CLIENTE (10/09/2026, tarde): na tela de
                                                 cobrancas, o nome leva as cobrancas; a ficha fica um clique adiante. */ ?>
                                        <a class="nome" href="/cobrancas.php?empresa=<?= (int) $c['fk_empresa']; ?>&situacao=todas"><?= shield_h($nome); ?></a>
                                        <span class="apoio"><?= shield_h((string) $c['descricao']); ?><?= $valeTexto !== '' ? ' &middot; ' . $valeTexto : ''; ?></span>
                                    <?php endif; ?>
                                    <?php
                                    // A SITUACAO ESCRITA (10/09/2026, tarde): o selo colorido sozinho
                                    // pedia decorar a cor. O texto diz o que esta acontecendo com a fatura.
                                    if ($rascunho) {
                                        $situTexto = array('neutro', 'aguardando a fatura ser gerada');
                                    } elseif ($sit === SHIELD_COB_PAGA) {
                                        $situTexto = array('ok', 'paga' . (!empty($c['pago_em']) ? ' em ' . date('d/m', strtotime((string) $c['pago_em'])) : ''));
                                    } elseif ($sit === SHIELD_COB_VENCIDA || $atrasada) {
                                        $situTexto = array('erro', 'vencida h&aacute; ' . (int) ((strtotime('today') - strtotime((string) $c['vencimento'])) / 86400) . ' dia(s)');
                                    } elseif ($sit === SHIELD_COB_ABERTA && (string) ($c['provedor'] ?? '') === 'dinheiro') {
                                        // Sem codigo na rua: "aguardando pagamento" sem nada para copiar parecia
                                        // defeito. Quem da a baixa e a pessoa, no Confirmar da linha.
                                        $situTexto = array('atencao', 'a receber em dinheiro');
                                    } elseif ($sit === SHIELD_COB_ABERTA) {
                                        $situTexto = array('atencao', 'aguardando pagamento');
                                    } else {
                                        $situTexto = array('neutro', $sit);
                                    }
                                    ?>
                                    <span class="d-block mt-1"><span class="pilula pilula-<?= $situTexto[0]; ?>"><?= $situTexto[1]; ?></span></span>
                                    <?php
                                    // O pedido e do cliente, nao da fatura: aparece uma vez, na primeira fatura em aberto dele.
                                    $promRow = (!$terminal && in_array($sit, array(SHIELD_COB_ABERTA, SHIELD_COB_VENCIDA), true)) ? ($promessasPendentes[(int) $c['fk_empresa']] ?? null) : null;
                                    if ($promRow !== null) { unset($promessasPendentes[(int) $c['fk_empresa']]); }
                                    ?>
                                    <?php $promOk = (!$terminal && in_array($sit, array(SHIELD_COB_ABERTA, SHIELD_COB_VENCIDA), true)) ? ($promessasAceitas[(int) $c['fk_empresa']] ?? null) : null;
                                    if ($promOk !== null) { unset($promessasAceitas[(int) $c['fk_empresa']]); } ?>
                                    <?php if ($promOk !== null): ?>
                                        <span class="d-block mt-1"><span class="pilula pilula-ok" title="Prazo aceito: a loja trabalha at&eacute; esta data mesmo com a fatura em aberto">prazo aceito at&eacute; <?= shield_h(date('d/m', strtotime((string) $promOk['ate']))); ?> (+<?= max(0, (int) round((strtotime((string) $promOk['ate']) - strtotime('today')) / 86400)); ?> dias)</span></span>
                                    <?php endif; ?>
                                    <?php if ($promRow !== null): ?>
                                        <span class="apoio d-block mt-1" style="color: var(--atencao)">
                                            <i class="fas fa-calendar-day"></i> cliente pede prazo at&eacute; <strong><?= shield_h(date('d/m', strtotime((string) $promRow['ate']))); ?></strong><?= trim((string) ($promRow['motivo'] ?? '')) !== '' ? ': &ldquo;' . shield_h((string) $promRow['motivo']) . '&rdquo;' : ''; ?>
                                        </span>
                                        <form method="post" action="<?= shield_h($urlCobrancas); ?>" class="d-inline-flex gap-1 mt-1">
                                            <input type="hidden" name="acao" value="promessa">
                                            <?php /* A empresa vai junto so para a tela reabrir o grupo dela depois do POST. */ ?>
                                            <input type="hidden" name="empresa" value="<?= (int) $c['fk_empresa']; ?>">
                                            <input type="hidden" name="promessa" value="<?= (int) $promRow['id']; ?>">
                                            <button class="btn btn-sm btn-primary py-0" name="decisao" value="aceitar" title="A loja segue trabalhando at&eacute; a data prometida">Aceitar</button>
                                            <button class="btn btn-sm btn-outline-secondary py-0" name="decisao" value="recusar" title="Vencida, a licen&ccedil;a bloqueia; o cliente s&oacute; pede de novo em 5 horas">Recusar</button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if (!$terminal && !empty($c['informado_em'])): ?>
                                        <?php
                                        // O CLIENTE AVISOU PELO ERP que pagou (aba
                                        // Mensalidade da Licenca do Sistema). E aviso,
                                        // nao prova: quem confirma continua sendo o
                                        // membro, olhando o extrato -- pelo Confirmar
                                        // de sempre, que ja vem com a forma preenchida.
                                        ?>
                                        <span class="apoio d-block" style="color: var(--atencao)">
                                            <i class="fas fa-info-circle"></i> cliente avisou que pagou em
                                            <?= shield_h(date('d/m H:i', strtotime((string) $c['informado_em']))); ?><?= !empty($c['informado_forma']) ? ' por ' . shield_h((string) $c['informado_forma']) : ''; ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td data-r="Emitida por">
                                <?php if ($rascunho): ?>
                                    <span class="pilula pilula-neutro">ainda n&atilde;o emitida</span>
                                <?php else: ?>
                                    <?php
                                    // COM CINCO GATEWAYS, "esta paga" sem dizer
                                    // ONDE nao concilia nada: o membro precisa
                                    // saber em qual extrato procurar.
                                    $catalogo = shield_cobranca_provedores();
                                    $prov = (string) ($c['provedor'] ?? '');
                                    $rotulo = $catalogo[$prov]['nome'] ?? ($prov !== '' ? $prov : 'sem registro');
                                    ?>
                                    <?php
                                    // NAO REPETIR O NOME: o apelido que o
                                    // membro deu quase sempre ja contem o do
                                    // provedor, e "Efi Efi (PIX)" e o que sai
                                    // de mostrar os dois sem olhar.
                                    $apelido = trim((string) ($c['conta_apelido'] ?? ''));
                                    $repete = ($apelido !== '' && stripos($apelido, (string) $rotulo) !== false);
                                    // A situacao CRUA do gateway (OVERDUE,
                                    // RECEIVED) e vocabulario dele, e serve
                                    // para diagnostico -- nao para a leitura
                                    // diaria. Vai para o title.
                                    $tituloProv = trim($rotulo . ($apelido !== '' ? ' -- ' . $apelido : '')
                                        . (!empty($c['situacao_provedor'])
                                            ? ' -- o provedor diz: ' . $c['situacao_provedor'] : '')
                                        . (!empty($c['id_externo']) ? ' -- ' . $c['id_externo'] : ''));
                                    ?>
                                    <?php /* A cor e a do provedor (painel.css, .pilula-prov-*): cinco
                                             gateways todos cinza obrigavam a LER para saber em qual
                                             extrato procurar. Sem provedor gravado, fica neutra. */ ?>
                                    <span class="pilula <?= $prov !== '' ? 'pilula-prov pilula-prov-' . shield_h($prov) : 'pilula-neutro'; ?>" title="<?= shield_h($tituloProv); ?>">
                                        <?= shield_h($repete ? $apelido : $rotulo); ?>
                                    </span>
                                    <?php if (!$repete && $apelido !== ''): ?>
                                        <span class="apoio d-block"><?= shield_h($apelido); ?></span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="num" data-r="Valor">
                                <strong>R$ <?= shield_h(shield_dinheiro((int) $c['valor_centavos'])); ?></strong>
                                <?php if ($c['valor_pago_centavos'] !== null
                                          && (int) $c['valor_pago_centavos'] !== (int) $c['valor_centavos']): ?>
                                    <?php
                                    // Pagou DIFERENTE do combinado -- a mais ou
                                    // a menos. Some no total e so aparece aqui.
                                    ?>
                                    <span class="apoio d-block" style="color: var(--atencao)">
                                        recebido R$ <?= shield_h(shield_dinheiro((int) $c['valor_pago_centavos'])); ?>
                                    </span>
                                <?php endif; ?>
                                <?php
                                // O PIX EMITIDO PEDE O VALOR DE ONTEM. Multa e
                                // juros so entram quando alguem troca o codigo
                                // (reemitir); ate la o painel mostra a
                                // diferenca e nao sobe o valor por baixo do
                                // cliente. Ver shield_encargos_pendentes.
                                //
                                // So para quem TEM codigo emitido (fk_conta da
                                // ultima tentativa): cobranca vencida sem
                                // tentativa nenhuma nao tem o que trocar.
                                $pendente = (!$terminal && !$rascunho && $atrasada && !empty($c['fk_conta']))
                                    ? shield_encargos_pendentes($pdo, $c) : 0;
                                ?>
                                <?php if ($pendente > 0): ?>
                                    <span class="apoio d-block" style="color: var(--atencao)"
                                          title="Multa e juros de hoje que o codigo emitido ainda nao pede">
                                        + R$ <?= shield_h(shield_dinheiro($pendente)); ?> de encargos hoje
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="num" data-r="Vence">
                                <?= shield_h(date('d/m/Y', strtotime((string) $c['vencimento']))); ?>
                                <?php if ($atrasada): ?>
                                    <span class="apoio d-block" style="color: var(--erro)">
                                        h&aacute; <?= (int) ((strtotime('today') - strtotime((string) $c['vencimento'])) / 86400); ?> dias
                                    </span>
                                <?php elseif ($sit === SHIELD_COB_PAGA && !empty($c['pago_em'])): ?>
                                    <span class="apoio d-block">
                                        pago <?= shield_h(date('d/m', strtotime((string) $c['pago_em']))); ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="meio" data-r="A&ccedil;&otilde;es">
                                <?php /* A ORDEM E A DO DONO (14/09/2026): copiar o codigo, abrir no provedor, editar,
                                         a ficha do cliente e, por ultimo, o que mexe no dinheiro -- confirmar a mao ou
                                         lancar estorno, que nunca aparecem juntos. O que so existe em certas situacoes
                                         (emitir o rascunho, reemitir com encargos, conferir no provedor) entra entre a
                                         ficha e o ultimo: os cinco nao saem do lugar relativo e o botao perigoso fica
                                         sempre na ponta. */ ?>
                                <span class="acoes">
                                    <?php
                                    // O COPIA-E-COLA E O QUE SE MANDA AO CLIENTE, e ate agora ele vinha na
                                    // consulta e morria na tela. Sem um botao aqui, o membro abre o painel do
                                    // gateway para pegar o codigo -- ou seja, o painel deixa de servir para a
                                    // coisa mais frequente do dia.
                                    //
                                    // O TITULO SAI DO CONTEUDO, E NAO DA FORMA (17/09/2026): o boleto hibrido
                                    // (Cora, Inter, C6, Asaas com chave) leva o PIX, e o boleto sem PIX leva a
                                    // linha. Um botao so, com o primeiro codigo -- o PIX quando ha, que paga na
                                    // hora; a linha do hibrido o cliente acha ao lado dele na area do cliente.
                                    $codigos = CodigoDePagamento::paraCopiar((string) ($c['copia'] ?? ''), (string) ($c['linha'] ?? ''));
                                    $oQueCopia = array(
                                        'pix' => 'o c&oacute;digo PIX (copia e cola)',
                                        'linha' => 'a linha digit&aacute;vel do boleto',
                                        'codigo' => 'o c&oacute;digo para pagar',
                                    );
                                    ?>
                                    <?php if ($codigos !== array()): ?>
                                        <button type="button" class="acao js-copiar"
                                                data-codigo="<?= shield_h($codigos[0]['valor']); ?>"
                                                title="Copiar <?= $oQueCopia[$codigos[0]['tipo']]; ?> para mandar ao cliente"
                                                aria-label="Copiar <?= $oQueCopia[$codigos[0]['tipo']]; ?> de <?= shield_h($nome); ?>">
                                            <i class="fas fa-copy"></i></button>
                                    <?php endif; ?>
                                    <?php if (!empty($c['link'])): ?>
                                        <a class="acao" href="<?= shield_h((string) $c['link']); ?>"
                                           target="_blank" rel="noopener"
                                           title="Abrir a cobran&ccedil;a no site do provedor, em outra aba"
                                           aria-label="Abrir no provedor a cobran&ccedil;a de <?= shield_h($nome); ?>">
                                            <i class="fas fa-external-link-alt"></i></a>
                                    <?php elseif (shield_cobranca_tem_pdf_do_painel($c)): ?>
                                        <?php /* IMPRIMIR O BOLETO (19/10/2026): o Inter nao da link do boleto, e o
                                                 membro ia ao banco para imprimir. No lugar do "abrir no provedor",
                                                 que essa linha nunca teria. */ ?>
                                        <a class="acao" href="/boleto_pdf.php?cobranca=<?= $id; ?>"
                                           target="_blank" rel="noopener"
                                           title="Abrir o boleto em PDF para imprimir ou mandar ao cliente"
                                           aria-label="Abrir o boleto em PDF de <?= shield_h($nome); ?>">
                                            <i class="fas fa-file-download"></i></a>
                                    <?php endif; ?>
                                    <?php /* EDITAR COBRANCA = mudar o plano do cliente (assinatura, pre-pago,
                                             valor, ciclo, conta): mora em Mudar o contrato, "Como paga".
                                             O DESENHO NAO E O LAPIS (14/09/2026): o lapis e o abrir no provedor sao
                                             os dois um quadrado com um traco saindo do canto, e no tamanho da coluna
                                             o dono nao distinguia um do outro. O deslizante e o do botao "Mudar o
                                             contrato" do cadastro (editar_empresa.php), que e para onde este leva; o
                                             lapis no painel continua sendo editar o CADASTRO. */ ?>
                                    <a class="acao" href="/mudanca_contrato.php?id=<?= (int) $c['fk_empresa']; ?>#como-paga"
                                       title="Editar como este cliente paga (assinatura, pr&eacute;-pago, valor, conta), em Mudar o contrato"
                                       aria-label="Editar como <?= shield_h($nome); ?> paga"><i class="fas fa-sliders-h"></i></a>
                                    <?php /* A FICHA DO CLIENTE (14/09/2026, pedido do dono): dentro do grupo o nome nao e link
                                             e a linha das cobrancas do cliente saiu, entao a fatura precisava de um caminho ate
                                             ele. Logo depois de editar porque os dois levam ao cliente e nao mexem na fatura:
                                             copiar e abrir no provedor seguem na frente, o dinheiro na ponta. O olho e o da
                                             lista de clientes, que tambem abre a ficha. */ ?>
                                    <a class="acao" href="/ver_empresa.php?id=<?= (int) $c['fk_empresa']; ?>"
                                       title="Ir para a ficha do cliente"
                                       aria-label="Ir para a ficha de <?= shield_h($nome); ?>"><i class="fas fa-eye"></i></a>

                                    <?php if ($rascunho && $contas): ?>
                                        <button type="button" class="acao" data-bs-toggle="modal"
                                                data-bs-target="#emi<?= $id; ?>"
                                                title="Emitir em um provedor"
                                                aria-label="Emitir a cobran&ccedil;a de <?= shield_h($nome); ?>">
                                            <i class="fas fa-bolt"></i></button>
                                    <?php elseif (!$terminal): ?>
                                        <?php if ($pendente > 0): ?>
                                            <form method="post" action="<?= shield_h($urlCobrancas); ?>" class="d-inline"
                                                  onsubmit="return confirm('Cancela o codigo atual no provedor e emite outro de R$ <?= shield_h(shield_dinheiro((int) $c['valor_centavos'] + $pendente)); ?>. O cliente precisa receber o novo. Continuar?');">
                                                <input type="hidden" name="acao" value="reemitir">
                                                <input type="hidden" name="cobranca" value="<?= $id; ?>">
                                                <button class="acao" style="color: var(--atencao)"
                                                        title="Reemitir com multa e juros de hoje (cancela o c&oacute;digo antigo no provedor)"
                                                        aria-label="Reemitir a cobran&ccedil;a de <?= shield_h($nome); ?> com os encargos de hoje">
                                                    <i class="fas fa-sync-alt"></i></button>
                                            </form>
                                        <?php endif; ?>
                                        <?php /* CONFERIR NAO GIRA (14/09/2026, pedido do dono): era a mesma seta do reemitir, e
                                                 com encargos os dois ficavam lado a lado iguais -- um so pergunta ao provedor, o
                                                 outro cancela o codigo que o cliente tem na mao. */ ?>
                                        <form method="post" action="<?= shield_h($urlCobrancas); ?>" class="d-inline">
                                            <input type="hidden" name="acao" value="consultar">
                                            <input type="hidden" name="cobranca" value="<?= $id; ?>">
                                            <button class="acao" title="Conferir: perguntar ao provedor qual &eacute; a situa&ccedil;&atilde;o desta cobran&ccedil;a"
                                                    aria-label="Conferir no provedor a cobran&ccedil;a de <?= shield_h($nome); ?>">
                                                <i class="fas fa-clipboard-check"></i></button>
                                        </form>
                                    <?php endif; ?>

                                    <?php if (!$terminal && $podeConfirmar): ?>
                                        <button type="button" class="acao" data-bs-toggle="modal"
                                                data-bs-target="#conf<?= $id; ?>"
                                                title="Confirmar que o dinheiro entrou"
                                                aria-label="Confirmar recebimento de <?= shield_h($nome); ?>">
                                            <i class="fas fa-check"></i></button>
                                    <?php elseif ($sit === SHIELD_COB_PAGA && $podeConfirmar): ?>
                                        <button type="button" class="acao perigo" data-bs-toggle="modal"
                                                data-bs-target="#est<?= $id; ?>"
                                                title="Lan&ccedil;ar estorno: desfaz o que o pagamento fez, com motivo"
                                                aria-label="Estornar a cobran&ccedil;a de <?= shield_h($nome); ?>">
                                            <i class="fas fa-times-circle"></i></button>
                                    <?php endif; ?>
                                    <?php /* CANCELAR (21/09/2026, pedido de membro): a cobranca aberta no valor
                                             errado nao tinha saida pela tela -- o POST e o motor existiam, o botao
                                             nunca. Fica na ponta, depois do confirmar, porque e o que some com a
                                             divida. Nao pede $podeConfirmar: cancelar nao da licenca a ninguem. */ ?>
                                    <?php if (!$terminal): ?>
                                        <button type="button" class="acao perigo" data-bs-toggle="modal"
                                                data-bs-target="#can<?= $id; ?>"
                                                title="Cancelar esta cobran&ccedil;a (tamb&eacute;m no provedor), com motivo"
                                                aria-label="Cancelar a cobran&ccedil;a de <?= shield_h($nome); ?>">
                                            <i class="fas fa-times"></i></button>
                                    <?php endif; ?>
                                    <?php /* GERAR DE NOVO (14/10/2026, achado de membro): a mensalidade cancelada
                                             ocupa a competencia, e o ciclo nao a gerava mais. Aqui ela nasce de
                                             novo como o ciclo faria -- mesmo mes, mesmo vencimento, estende a
                                             licenca --, e nao como avulsa. So para assinatura. */ ?>
                                    <?php if ($sit === SHIELD_COB_CANCELADA && !empty($c['fk_assinatura']) && !empty($c['competencia'])): ?>
                                        <form method="post" action="<?= shield_h($urlCobrancas); ?>" class="d-inline"
                                              onsubmit="return confirm('Gera de novo a mensalidade deste mes, com o mesmo vencimento, pela conta da assinatura. Continuar?');">
                                            <input type="hidden" name="acao" value="regerar">
                                            <input type="hidden" name="cobranca" value="<?= $id; ?>">
                                            <button class="acao" title="Gerar de novo esta mensalidade (mesmo m&ecirc;s e vencimento)"
                                                    aria-label="Gerar de novo a mensalidade de <?= shield_h($nome); ?>">
                                                <i class="fas fa-plus-circle"></i></button>
                                        </form>
                                    <?php endif; ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
                <?php if ($agrupar): ?></details><?php endif; ?>
                <?php endforeach; ?>
                <?php if ($agrupar): ?></div><?php endif; ?>

                <?php
                // OS DIALOGOS FICAM FORA DA TABELA -- collapse dentro da celula
                // empurra todas as linhas abaixo a cada clique, e com duzias de
                // cobrancas a tabela inteira dancava.
                foreach ($lista as $c):
                    $id = (int) $c['id'];
                    $sit = (string) $c['situacao'];
                    $nome = (string) ($c['razao'] ?? 'Cliente');
                ?>
                    <?php if ($sit === SHIELD_COB_RASCUNHO && $contas): ?>
                    <div class="modal fade" id="emi<?= $id; ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content"><div class="modal-header">
                                <h3 class="h6 modal-title">Emitir &mdash; <?= shield_h($nome); ?></h3>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                            </div><div class="modal-body">
                                <form method="post" action="<?= shield_h($urlCobrancas); ?>">
                                    <input type="hidden" name="acao" value="emitir">
                                    <input type="hidden" name="cobranca" value="<?= $id; ?>">
                                    <label class="form-label small mb-1" for="ct<?= $id; ?>">Por qual conta</label>
                                    <select id="ct<?= $id; ?>" name="conta" class="form-select form-select-sm mb-2">
                                        <?php foreach ($contas as $co): ?>
                                            <?php /* Conta que nao cobra pela forma desta cobranca vem apagada (14/09/2026):
                                                     escolher so para ler o erro e o clique que a tela pode poupar. ATENCAO:
                                                     o motor NAO recusa por aqui -- a emissao olha shield_cobranca_forma_recusa,
                                                     que so conhece o provedor, e o POST de emitir desta tela nao confere o
                                                     "Cobra por". Quem segura e so o disabled. A conta que nao esta pronta (o
                                                     PIX na chave sem chave) tambem vem apagada; essa o motor recusa. */ ?>
                                            <option value="<?= (int) $co['id']; ?>" <?= (shield_conta_forma_recusa($co, (string) ($c['forma'] ?? '')) !== null || $contaNaoPronta[(int) $co['id']] !== null) ? 'disabled' : ''; ?>>
                                                <?= shield_h((string) $co['apelido']); ?>
                                                <?php
                                                // O QUE A CONTA SUPORTA sai no
                                                // proprio rotulo: a Efi so faz
                                                // PIX neste painel, e escolher
                                                // uma conta que nao faz boleto
                                                // para uma cobranca de boleto e
                                                // um erro que so aparece la na
                                                // frente.
                                                $cap = array();
                                                foreach (shield_conta_formas($co) as $fz) {
                                                    $cap[] = array('pix' => 'PIX', 'boleto' => 'boleto', 'cartao' => 'cartao', 'dinheiro' => 'dinheiro')[$fz];
                                                }
                                                echo $cap ? '(' . implode(', ', $cap) . ')' : '';
                                                ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <p class="small text-secondary">
                                        Emitir cria a cobran&ccedil;a NO PROVEDOR e gera o c&oacute;digo que
                                        voc&ecirc; manda ao cliente. Falhando, a cobran&ccedil;a continua em
                                        rascunho e o motivo aparece aqui em cima.
                                    </p>
                                    <button class="btn btn-sm btn-primary">
                                        <i class="fas fa-bolt"></i> Emitir agora
                                    </button>
                                </form>
                            </div></div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (!shield_cob_terminal($sit) && $podeConfirmar): ?>
                    <div class="modal fade" id="conf<?= $id; ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content"><div class="modal-header">
                                <h3 class="h6 modal-title">Confirmar recebimento &mdash; <?= shield_h($nome); ?></h3>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                            </div><div class="modal-body">
                                <form method="post" action="<?= shield_h($urlCobrancas); ?>">
                                    <input type="hidden" name="acao" value="confirmar">
                                    <input type="hidden" name="cobranca" value="<?= $id; ?>">
                                    <label class="form-label small mb-1" for="vp<?= $id; ?>">Valor recebido</label>
                                    <input id="vp<?= $id; ?>" type="text" name="valor_pago"
                                           class="form-control form-control-sm num mb-2"
                                           value="<?= shield_h(shield_dinheiro((int) $c['valor_centavos'])); ?>">
                                    <label class="form-label small mb-1" for="fp<?= $id; ?>">Como entrou</label>
                                    <?php
                                    // O que o cliente disse pelo ERP ja vem escolhido:
                                    // o membro confere no extrato e so confirma.
                                    $formaInformada = (string) ($c['informado_forma'] ?? '');
                                    $obsInformada = !empty($c['informado_em'])
                                        ? 'cliente avisou pelo ERP em ' . date('d/m/Y H:i', strtotime((string) $c['informado_em']))
                                            . (!empty($c['informado_obs']) ? ' -- ' . (string) $c['informado_obs'] : '')
                                        : '';
                                    ?>
                                    <select id="fp<?= $id; ?>" name="forma_pago" class="form-select form-select-sm mb-2">
                                        <?php foreach (array('pix' => 'PIX', 'dinheiro' => 'Dinheiro', 'transferencia' => 'Transfer&ecirc;ncia', 'boleto' => 'Boleto', 'cartao' => 'Cart&atilde;o') as $fv => $fr): ?>
                                            <option value="<?= $fv; ?>" <?= $fv === $formaInformada ? 'selected' : ''; ?>><?= $fr; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <label class="form-label small mb-1" for="ob<?= $id; ?>">Observa&ccedil;&atilde;o</label>
                                    <input id="ob<?= $id; ?>" type="text" name="observacao"
                                           class="form-control form-control-sm mb-2" maxlength="120"
                                           value="<?= shield_h(substr($obsInformada, 0, 120)); ?>"
                                           placeholder="Onde voc&ecirc; viu o dinheiro">
                                    <p class="small text-secondary">
                                        Isto estende a licen&ccedil;a <strong>sem prova do banco</strong>, e fica
                                        registrado com o seu nome no livro de auditoria. Se a cobran&ccedil;a
                                        foi emitida num gateway, prefira <strong>Conferir</strong>: quem
                                        responde ali e o provedor. Se o cliente pagou por fora, o painel
                                        d&aacute; baixa tamb&eacute;m no Asaas; nos outros provedores, d&ecirc;
                                        baixa por l&aacute;.
                                    </p>
                                    <button class="btn btn-sm btn-primary">Confirmar recebimento</button>
                                </form>
                            </div></div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if ($sit === SHIELD_COB_PAGA && $podeConfirmar): ?>
                    <div class="modal fade" id="est<?= $id; ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content"><div class="modal-header">
                                <h3 class="h6 modal-title">Estornar &mdash; <?= shield_h($nome); ?></h3>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                            </div><div class="modal-body">
                                <form method="post" action="<?= shield_h($urlCobrancas); ?>">
                                    <input type="hidden" name="acao" value="estornar">
                                    <input type="hidden" name="cobranca" value="<?= $id; ?>">
                                    <label class="form-label small mb-1" for="mt<?= $id; ?>">Motivo do estorno</label>
                                    <input id="mt<?= $id; ?>" type="text" name="motivo"
                                           class="form-control form-control-sm mb-2" required maxlength="150">
                                    <p class="small text-secondary">
                                        O registro anterior <strong>n&atilde;o</strong> some: lan&ccedil;a-se o
                                        inverso, com motivo. O painel desfaz o que o pagamento fez &mdash;
                                        <strong>recolhe os meses de licen&ccedil;a</strong> que esta cobran&ccedil;a deu e
                                        devolve o cr&eacute;dito ao estado anterior. O estorno NO PROVEDOR,
                                        quando houver, &eacute; feito l&aacute;.
                                    </p>
                                    <button class="btn btn-sm btn-outline-danger">Lan&ccedil;ar estorno</button>
                                </form>
                            </div></div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (!shield_cob_terminal($sit)): ?>
                    <div class="modal fade" id="can<?= $id; ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content"><div class="modal-header">
                                <h3 class="h6 modal-title">Cancelar cobran&ccedil;a &mdash; <?= shield_h($nome); ?></h3>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                            </div><div class="modal-body">
                                <form method="post" action="<?= shield_h($urlCobrancas); ?>">
                                    <input type="hidden" name="acao" value="cancelar">
                                    <input type="hidden" name="cobranca" value="<?= $id; ?>">
                                    <p class="small mb-2">
                                        <?= shield_h((string) ($c['descricao'] ?? '')); ?> &middot;
                                        R$ <?= shield_h(shield_dinheiro((int) $c['valor_centavos'])); ?> &middot;
                                        vence <?= shield_h(date('d/m/Y', strtotime((string) $c['vencimento']))); ?>
                                    </p>
                                    <label class="form-label small mb-1" for="mc<?= $id; ?>">Motivo do cancelamento</label>
                                    <input id="mc<?= $id; ?>" type="text" name="motivo"
                                           class="form-control form-control-sm mb-2" required maxlength="150"
                                           placeholder="Ex.: valor errado, vou gerar outra">
                                    <p class="small text-secondary">
                                        O painel cancela <strong>primeiro no provedor</strong>: o c&oacute;digo que o
                                        cliente tem na m&atilde;o deixa de valer. Se o provedor recusar, nada muda
                                        aqui. O cr&eacute;dito que esta cobran&ccedil;a usou volta para o cliente, e o
                                        cancelamento fica no livro de auditoria com o motivo. Valor errado? Cancele e
                                        abra outra com o valor certo.
                                    </p>
                                    <button class="btn btn-sm btn-outline-danger">Cancelar cobran&ccedil;a</button>
                                </form>
                            </div></div>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>



<?php include __DIR__ . '/../../templates/fecha.php'; ?>
