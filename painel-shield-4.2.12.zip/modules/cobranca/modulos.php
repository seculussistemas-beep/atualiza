<?php
/**
 * Catalogo de modulos -- 09/09/2026.
 *
 * Nove das quarenta e tres softwarehouses do levantamento de 08/09/2026 vendem
 * por modulo, e cada uma tem a lista dela: Fiscal, NFS-e, TEF, Forca de Vendas,
 * Mesas e Comandas, Farmacia, Restaurante, O.S. Por isso a lista e uma TABELA e
 * nao um ENUM, e por isso o painel nasce vazio: adivinhar a lista de outra
 * pessoa seria pior do que a tela em branco.
 *
 * ESTA TELA E SO O CATALOGO -- o preco de tabela e o nome. Quem tem o que se
 * decide no cadastro do cliente, junto da cota e da validade, porque e la que
 * mora o contrato dele.
 *
 * O PRECO AQUI NAO REAJUSTA NINGUEM. Ao contratar, o valor e COPIADO para o
 * cliente; mexer no catalogo depois nao mexe em quem ja fechou. E o mesmo
 * motivo de cobranca.valor_centavos ser copiado do plano.
 *
 * MODULO NAO SE APAGA, se desativa. A linha do cliente aponta para ele, e o
 * historico de "o que ele pagava em marco" some junto se a linha sumir.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca.php';
require_once __DIR__ . '/../../funcoes/licenca/modulos_licenca.php'; // a chave que vai no token

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

$erro = '';
$aviso = '';
// Consequencia fica dez segundos no canto, e nao cinco (funcoes/ui/aviso.php):
// "fora do catalogo" sem o "quem ja tem continua com ele" assusta quem desligou.
$avisoDemorado = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $acao = (string) ($_POST['acao'] ?? '');

        if ($acao === 'gravar') {
            $nome = trim((string) ($_POST['nome'] ?? ''));
            if ($nome === '') {
                throw new RuntimeException('O modulo precisa de um nome.');
            }

            $id = (int) ($_POST['id'] ?? 0);
            $valor = max(0, shield_centavos((string) ($_POST['valor'] ?? '0')));
            // NOME E VALOR SAO OBRIGATORIOS (10/09/2026, tarde); chave e
            // observacao, nao. Modulo de R$ 0,00 e item de fatura sem valor,
            // e nao ha por que existir.
            if ($valor <= 0) {
                throw new RuntimeException('Digite o valor de tabela do modulo.');
            }
            $descricao = substr(trim((string) ($_POST['descricao'] ?? '')), 0, 150);
            // A CHAVE DO ERP -- 10/09/2026. E o que vai dentro da licenca
            // assinada e desliga a funcao na loja; vazia, o modulo e so item
            // de fatura. Ver funcoes/licenca/modulos_licenca.php.
            $chave = shield_modulo_chave_normalizar((string) ($_POST['chave'] ?? ''));

            if ($id > 0) {
                $pdo->prepare(
                    'UPDATE modulo SET nome = :n, chave = :c, descricao = :d, valor_centavos = :v WHERE id = :id'
                )->execute(array(':n' => substr($nome, 0, 60), ':c' => $chave !== '' ? $chave : null, ':d' => $descricao, ':v' => $valor, ':id' => $id));
                // REAJUSTE GERAL (10/09/2026, tarde): mexer no valor do catalogo
                // reajusta quem tem o modulo, a partir da PROXIMA fatura -- a que
                // ja esta na rua nao muda. Antes o valor era copiado e o catalogo
                // nao alcancava ninguem; o dono do produto quis o contrario.
                $st = $pdo->prepare('UPDATE empresa_modulo SET valor_centavos = :v WHERE fk_modulo = :m AND ate IS NULL');
                $st->execute(array(':v' => $valor, ':m' => $id));
                $reajustados = (int) $st->rowCount();
                // So quando alguem passa a pagar outro valor: "Modulo atualizado"
                // sozinho e resposta curta.
                $avisoDemorado = $reajustados > 0;
                $aviso = 'Modulo atualizado.' . ($reajustados > 0
                    ? ' ' . $reajustados . ' cliente(s) passam a pagar R$ ' . shield_dinheiro($valor) . ' a partir da proxima fatura.'
                    : '');
            } else {
                $pdo->prepare(
                    'INSERT INTO modulo (nome, chave, descricao, valor_centavos) VALUES (:n, :c, :d, :v)'
                )->execute(array(':n' => substr($nome, 0, 60), ':c' => $chave !== '' ? $chave : null, ':d' => $descricao, ':v' => $valor));
                $aviso = 'Modulo criado.';
            }

            shield_auditar($pdo, 'modulo_' . ($id > 0 ? 'alterado' : 'criado'), array(
                'alvo_tipo' => 'modulo',
                'alvo_id' => $id > 0 ? $id : (int) $pdo->lastInsertId(),
                'detalhe' => $nome . ' por R$ ' . shield_dinheiro($valor),
            ));
        } elseif ($acao === 'sem_contrato') {
            // O QUE O CLIENTE SEM MODULO RECEBE (10/09/2026, tarde): tudo, pela
            // regra do ERP, ou so o basico. Ver shield_modulos_sem_contrato.
            shield_modulos_definir_sem_contrato($pdo, (string) ($_POST['modo'] ?? 'tudo'));
            $avisoDemorado = true;
            $aviso = (string) ($_POST['modo'] ?? 'tudo') === 'basico'
                ? 'Cliente sem modulo contratado passa a receber so o basico. Vale na proxima abertura de cada ERP.'
                : 'Cliente sem modulo contratado volta a receber tudo, que e a regra do ERP.';
        } elseif ($acao === 'ativo') {
            $id = (int) ($_POST['id'] ?? 0);
            $ativo = !empty($_POST['ligar']) ? 1 : 0;
            $pdo->prepare('UPDATE modulo SET ativo = :a WHERE id = :id')
                ->execute(array(':a' => $ativo, ':id' => $id));

            // Voltar ao catalogo e resposta curta; sair dele tem consequencia.
            $avisoDemorado = !$ativo;
            $aviso = $ativo
                ? 'Modulo de volta ao catalogo.'
                : 'Modulo fora do catalogo. Quem ja tem continua com ele ate voce tirar no cadastro do cliente.';

            shield_auditar($pdo, 'modulo_' . ($ativo ? 'reativado' : 'desativado'), array(
                'alvo_tipo' => 'modulo', 'alvo_id' => $id,
            ));
        }
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
}

// Quantos clientes tem cada um: e o numero que impede alguem de desativar um
// modulo achando que nao esta em uso.
$modulos = $pdo->query(
    'SELECT m.*,
            (SELECT COUNT(*) FROM empresa_modulo em
              WHERE em.fk_modulo = m.id AND em.ate IS NULL) AS clientes
       FROM modulo m ORDER BY m.ativo DESC, m.nome'
)->fetchAll(PDO::FETCH_ASSOC) ?: array();

$semContrato = shield_modulos_sem_contrato($pdo);
$edicao = null;
if (isset($_GET['editar'])) {
    $stmt = $pdo->prepare('SELECT * FROM modulo WHERE id = :id');
    $stmt->execute(array(':id' => (int) $_GET['editar']));
    $edicao = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<?php
/* ICONES DESTA TELA SAO SVG EM LINHA (10/09/2026, tarde): o dono do produto
   achou os do subconjunto "muito antigos". Tracos finos, do mesmo desenho da
   seta dos grupos da lateral. So aqui por enquanto. */
function mod_icone($qual)
{
    $d = array(
        'mais' => '<path d="M12 5v14M5 12h14"/>',
        'lapis' => '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
        'olho' => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
        'olho_fechado' => '<path d="M9.9 4.2A10.9 10.9 0 0 1 12 4c6.5 0 10 8 10 8a18 18 0 0 1-2.2 3.2"/><path d="M6.6 6.6A18 18 0 0 0 2 12s3.5 8 10 8a10.6 10.6 0 0 0 5.4-1.4"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/><path d="m2 2 20 20"/>',
    );
    return '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $d[$qual] . '</svg>';
}
?>
<style>
    .ico { width: 1.05rem; height: 1.05rem; vertical-align: -.2rem; }
    .catalogo td:first-child { overflow-wrap: anywhere; word-break: break-word; }
    .catalogo th.num, .catalogo td.num, .catalogo td:last-child { white-space: nowrap; }
    /* TABELA, CLIENTES E ACOES NO CENTRO (14/09/2026), como as outras listas. A
       coluna de acoes nao tinha cabecalho e os botoes encostavam na borda direita,
       longe do numero de clientes. */
    .catalogo th, .catalogo td { vertical-align: middle; }
    .catalogo .btn svg { width: .95rem; height: .95rem; vertical-align: -.15rem; }
</style>

<div class="topo-tela">
    <div>
        <h1 class="h4 mb-1">M&oacute;dulos</h1>
        <p class="text-secondary small mb-0">
            O que o cliente contrata al&eacute;m do b&aacute;sico. O valor entra na mensalidade dele,
            somado ao plano.
        </p>
    </div>
    <button type="button" class="btn btn-primary btn-sm" onclick="modAbrir(null)"><?= mod_icone('mais'); ?> Novo m&oacute;dulo</button>
</div>

<?php shield_aviso_flutuante($aviso, '', $avisoDemorado); ?>
<?php if ($erro !== ''): ?>
    <div class="alert alert-danger"><?= shield_h($erro); ?></div>
<?php endif; ?>

<?php /* A REGRA DE QUEM NAO TEM MODULO: o ERP libera tudo quando a licenca nao
         diz nada. Quem vende por modulo quer o contrario -- so o basico ate
         contratar. Dois lados, como na regua. */ ?>
<div class="card mb-3" data-tour="mod-regra">
    <div class="card-body py-3">
        <form method="post" action="/modulos.php" class="d-flex align-items-start flex-wrap gap-3">
            <input type="hidden" name="acao" value="sem_contrato">
            <div>
                <div class="small text-secondary mb-1">Cliente <strong>sem</strong> m&oacute;dulo contratado recebe</div>
                <div class="dois-lados" role="radiogroup" aria-label="O que o cliente sem modulo recebe">
                    <input type="radio" name="modo" id="sc_tudo" value="tudo" <?= $semContrato === 'tudo' ? 'checked' : ''; ?> onchange="this.form.submit()">
                    <label for="sc_tudo" class="desliga">Tudo</label>
                    <input type="radio" name="modo" id="sc_basico" value="basico" <?= $semContrato === 'basico' ? 'checked' : ''; ?> onchange="this.form.submit()">
                    <label for="sc_basico">S&oacute; o b&aacute;sico</label>
                </div>
            </div>
            <span class="small text-secondary flex-grow-1 align-self-end" style="min-width: 14rem">
                <?php /* Em portugues de balcao: o que muda na loja de quem nao contratou modulo. */ ?>
                <?php if ($semContrato === 'basico'): ?>
                    <strong>S&oacute; o b&aacute;sico.</strong> Um cliente que n&atilde;o contratou nenhum m&oacute;dulo abre o ERP com
                    venda, caixa e cadastros funcionando, mas as telas que s&atilde;o m&oacute;dulo (fiscal, NFS-e, O.S., restaurante&hellip;)
                    ficam desligadas at&eacute; voc&ecirc; marcar o m&oacute;dulo no contrato dele. &Eacute; o modo de quem <strong>vende por m&oacute;dulo</strong>.
                    Quem j&aacute; tem m&oacute;dulo contratado n&atilde;o sente diferen&ccedil;a.
                <?php else: ?>
                    <strong>Tudo.</strong> Um cliente que n&atilde;o contratou nenhum m&oacute;dulo abre o ERP com <strong>todas</strong> as telas
                    liberadas &mdash; &eacute; como o ERP sempre funcionou. Os m&oacute;dulos do cat&aacute;logo s&oacute; entram na fatura
                    de quem os marcou. Troque para "s&oacute; o b&aacute;sico" se voc&ecirc; vende por m&oacute;dulo e quer que a tela
                    fique fechada at&eacute; o cliente contratar.
                <?php endif; ?>
            </span>
        </form>
    </div>
</div>

<div class="card" data-tour="mod-catalogo">
    <div class="card-header">No cat&aacute;logo</div>
    <div class="card-body p-0">
        <?php if ($modulos === array()): ?>
            <p class="text-secondary small p-3 mb-0">
                Nenhum m&oacute;dulo ainda. Crie os que voc&ecirc; vende &mdash; Fiscal, NFS-e, TEF,
                For&ccedil;a de Vendas &mdash; e depois marque no cadastro de cada cliente.
            </p>
        <?php else: ?>
            <div class="table-responsive">
            <table class="table table-sm mb-0 align-middle catalogo">
                <thead>
                    <tr>
                        <th>M&oacute;dulo</th>
                        <th class="text-center num">Tabela</th>
                        <th class="text-center num">Clientes</th>
                        <th class="text-center" style="width: 1%">A&ccedil;&otilde;es</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($modulos as $m): ?>
                    <tr<?= (int) $m['ativo'] === 0 ? ' class="text-secondary"' : ''; ?>>
                        <td>
                            <?= shield_h((string) $m['nome']); ?>
                            <?php if ((int) $m['ativo'] === 0): ?>
                                <span class="pilula pilula-neutro">fora do cat&aacute;logo</span>
                            <?php endif; ?>
                            <?php if (trim((string) ($m['chave'] ?? '')) !== ''): ?>
                                <span class="pilula pilula-ok" title="Vai na licenca assinada: liga esta funcao no ERP"><code><?= shield_h((string) $m['chave']); ?></code></span>
                            <?php else: ?>
                                <span class="pilula pilula-neutro" title="Sem chave: so entra na fatura, nao desliga nada na loja">s&oacute; fatura</span>
                            <?php endif; ?>
                            <?php if (trim((string) $m['descricao']) !== ''): ?>
                                <div class="small text-secondary"><?= shield_h((string) $m['descricao']); ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="text-center num">R$ <?= shield_dinheiro((int) $m['valor_centavos']); ?></td>
                        <td class="text-center num"><?= (int) $m['clientes']; ?></td>
                        <td class="text-center">
                            <?php /* O MODAL VEM PREENCHIDO com o que a linha tem: sem recarregar a tela. */ ?>
                            <button type="button" class="btn btn-sm btn-outline-secondary" title="Editar" aria-label="Editar <?= shield_h((string) $m['nome']); ?>"
                                    onclick='modAbrir(<?= json_encode(array(
                                        'id' => (int) $m['id'], 'nome' => (string) $m['nome'], 'chave' => (string) ($m['chave'] ?? ''),
                                        'valor' => shield_dinheiro((int) $m['valor_centavos']), 'descricao' => (string) $m['descricao'],
                                    ), JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE); ?>)'><?= mod_icone('lapis'); ?> Editar</button>
                            <form method="post" action="/modulos.php" class="d-inline">
                                <input type="hidden" name="acao" value="ativo">
                                <input type="hidden" name="id" value="<?= (int) $m['id']; ?>">
                                <?php if ((int) $m['ativo'] === 1): ?>
                                    <button class="btn btn-sm btn-outline-secondary" title="Tirar do cat&aacute;logo" aria-label="Tirar do catalogo"><?= mod_icone('olho_fechado'); ?> Ocultar</button>
                                <?php else: ?>
                                    <input type="hidden" name="ligar" value="1">
                                    <button class="btn btn-sm btn-outline-secondary" title="Voltar ao cat&aacute;logo" aria-label="Voltar ao catalogo"><?= mod_icone('olho'); ?> Mostrar</button>
                                <?php endif; ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php /* O FORMULARIO E UM MODAL (10/09/2026, tarde): novo e editar no mesmo
         lugar, preenchido pelo JS com o que a linha ja tem. */ ?>
<div class="modal fade" id="modalModulo" tabindex="-1" aria-labelledby="modalModuloTitulo" aria-hidden="true">
    <div class="modal-dialog">
        <form method="post" action="/modulos.php" class="modal-content" id="formModulo">
            <div class="modal-header">
                <h2 class="modal-title h6" id="modalModuloTitulo">Novo m&oacute;dulo</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="acao" value="gravar">
                <input type="hidden" name="id" id="mod_id" value="0">

                <div class="mb-3">
                    <label for="nome" class="form-label">Nome <span class="text-danger">*</span></label>
                    <input type="text" id="nome" name="nome" class="form-control" maxlength="60" required placeholder="Fiscal NF-e">
                </div>

                <div class="mb-3">
                    <label for="chave_lista" class="form-label">O que ele liga no ERP</label>
                    <?php
                    // A lista das nove chaves que o build do ERP conhece, mais
                    // "nada" (item de fatura) e uma chave livre para o que o
                    // proximo build vier a conhecer -- o ERP ignora chave
                    // desconhecida, entao emitir antes nao quebra ninguem.
                    $conhecidas = shield_modulos_conhecidos();
                    ?>
                    <select id="chave_lista" class="form-select mb-1"
                            onchange="var l=document.getElementById('chave'); l.hidden=this.value!=='__outra'; if(this.value!=='__outra'){l.value=this.value;}">
                        <option value="">Nada &mdash; s&oacute; entra na fatura</option>
                        <?php
                        // Chave ja usada por outro modulo some da lista (o JS esconde
                        // conforme o modulo aberto): um modulo por chave, senao o
                        // token sairia com a mesma chave duas vezes.
                        $chaveDoModulo = array();
                        foreach ($modulos as $mm) {
                            if (trim((string) ($mm['chave'] ?? '')) !== '') {
                                $chaveDoModulo[(string) $mm['chave']] = (int) $mm['id'];
                            }
                        }
                        ?>
                        <?php foreach ($conhecidas as $k => $oque): ?>
                            <option value="<?= shield_h($k); ?>" data-usada-por="<?= (int) ($chaveDoModulo[$k] ?? 0); ?>"><?= shield_h($k); ?> &middot; <?= shield_h($oque); ?></option>
                        <?php endforeach; ?>
                        <option value="__outra">Outra chave (build futuro do ERP)</option>
                    </select>
                    <input type="text" id="chave" name="chave" class="form-control" maxlength="20" placeholder="chave, ex. farmacia" hidden>
                    <small class="form-text text-muted">
                        Vai <strong>dentro da licen&ccedil;a assinada</strong>: cliente sem este m&oacute;dulo
                        perde a fun&ccedil;&atilde;o na loja. Cliente sem m&oacute;dulo nenhum com chave
                        continua com tudo liberado &mdash; &eacute; a regra do ERP.
                    </small>
                </div>

                <div class="mb-3">
                    <label for="valor" class="form-label">Valor de tabela (R$/m&ecirc;s) <span class="text-danger">*</span></label>
                    <?php /* SO O PLACEHOLDER: pre-preenchido com 0,00, digitar virava "0,00123". */ ?>
                    <input type="text" inputmode="decimal" id="valor" name="valor" class="form-control dinheiro" data-teto="999999"
                           placeholder="0,00" required onfocus="this.select()" maxlength="15">
                    <small class="form-text text-muted">
                        Mexer aqui <strong>reajusta todo mundo</strong> que tem o m&oacute;dulo, a partir da pr&oacute;xima fatura.
                        A fatura que j&aacute; est&aacute; na rua n&atilde;o muda.
                    </small>
                </div>

                <div class="mb-1">
                    <label for="descricao" class="form-label">Observa&ccedil;&atilde;o</label>
                    <input type="text" id="descricao" name="descricao" class="form-control" maxlength="150">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary btn-sm">Gravar</button>
            </div>
        </form>
    </div>
</div>

<script>
// Abre o modal vazio (novo) ou com os dados da linha (editar).
function modAbrir(m) {
    var f = document.getElementById('formModulo');
    var conhecidas = <?= json_encode(array_keys($conhecidas)); ?>;
    m = m || { id: 0, nome: '', chave: '', valor: '', descricao: '' };
    document.getElementById('modalModuloTitulo').innerText = m.id > 0 ? 'Editar módulo' : 'Novo módulo';
    document.getElementById('mod_id').value = m.id;
    f.nome.value = m.nome;
    f.valor.value = m.valor;
    f.descricao.value = m.descricao;
    var lista = document.getElementById('chave_lista'), livre = document.getElementById('chave');
    // Esconde as chaves que outro modulo ja usa; a deste modulo continua.
    Array.prototype.forEach.call(lista.options, function (o) {
        var dono = parseInt(o.getAttribute('data-usada-por') || '0', 10);
        o.hidden = dono > 0 && dono !== m.id;
    });
    var conhecida = m.chave === '' || conhecidas.indexOf(m.chave) !== -1;
    lista.value = conhecida ? m.chave : '__outra';
    livre.value = m.chave;
    livre.hidden = conhecida;
    var modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('modalModulo'));
    modal.show();
    setTimeout(function () { f.nome.focus(); }, 300);
}
<?php if ($edicao): ?>
// Link antigo ?editar=: abre o modal ja preenchido.
document.addEventListener('DOMContentLoaded', function () {
    modAbrir(<?= json_encode(array(
        'id' => (int) $edicao['id'], 'nome' => (string) $edicao['nome'], 'chave' => (string) ($edicao['chave'] ?? ''),
        'valor' => shield_dinheiro((int) $edicao['valor_centavos']), 'descricao' => (string) $edicao['descricao'],
    ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE); ?>);
});
<?php endif; ?>
</script>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
