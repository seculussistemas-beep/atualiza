<?php
/**
 * Formas de recebimento - 25/08/2026.
 *
 * Onde o dinheiro cai. Gateway, PIX na chave do membro e dinheiro em especie
 * aparecem lado a lado, de proposito: para o membro, sao tres jeitos de
 * receber, e nao "a integracao" contra "o manual".
 *
 * A TELA OFERECE O QUE A CONTA SUPORTA, e nao um formulario igual para todos.
 * Capacidade declarada pelo adaptador em vez de presumida e o que impede o
 * membro de montar uma cobranca de cartao numa conta que so faz PIX e
 * descobrir no erro, depois de ja ter dito ao cliente que mandou.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca_motor.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca_credenciais.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca_teste.php';
require_once __DIR__ . '/../../funcoes/cobranca/certificado_cliente.php';

use Shield\Cobranca\Provedores\ContaAzul;
use Shield\Cobranca\Registro;

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

$erro = '';
$aviso = '';

// A credencial que cada provedor pede sai do CATALOGO
// (includes/cobranca_credenciais.php), e nao de uma lista local -- esta aqui
// so conhecia tres provedores, e por isso a tela nunca pedia a chave dos
// outros quatro.
$campos = array();
foreach (shield_cred_catalogo() as $prov => $meta) {
    $campos[$prov] = array();
    foreach ($meta as $campo => $m) {
        $campos[$prov][$campo] = $m['rotulo'];
    }
}

$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);

/* O GRUPO DE ONDE O CLIQUE VEIO (14/09/2026). Configurar, testar, gravar e
   fechar o modal recarregam a pagina, e o <details> voltava FECHADO -- atras
   do modal e na volta dele: o membro abria "Pelo provedor", clicava na
   engrenagem e perdia o lugar a cada passo. O grupo viaja na URL (e no POST)
   e o PHP escreve o `open` ja no HTML; abrir por JS depois de pintar seria o
   grupo fechado aparecendo e abrindo, a piscada que saiu do fecha.php.

   Vem do clique, e nao do provedor da conta: o PIX na sua chave e o dinheiro
   aparecem nos Metodos configurados E no grupo deles. Clique nos Metodos
   configurados nao manda grupo, e sem grupo tudo vem fechado como sempre.

   Lista fechada porque o valor volta para o Location, para dentro de um
   script e para o HTML: qualquer outra coisa vira ''. Sem (string) de
   proposito: ?grupo[]=x viraria "Array to string conversion" impresso antes
   do header, e o in_array estrito ja recusa array sozinho. */
$grupoAberto = $_POST['grupo'] ?? $_GET['grupo'] ?? '';
if (!in_array($grupoAberto, array('provedor', 'chave', 'especie'), true)) {
    $grupoAberto = '';
}
$voltaGrupo = $grupoAberto !== '' ? '&grupo=' . $grupoAberto : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $id > 0 && ($_POST['acao'] ?? '') === 'alternar') {
    // LIGAR / DESLIGAR PELA LINHA (10/09/2026, noite): o dinheiro em especie nao
    // tem o que configurar, entao o botao da linha e o unico interruptor dele.
    try {
        $conta = shield_cobranca_conta($pdo, $id);
        if ($conta === null) {
            throw new RuntimeException('Forma nao encontrada.');
        }
        $ligar = (int) $conta['ativo'] === 1 ? 0 : 1;
        // LIGAR PERGUNTA SE A CONTA COBRA (15/09/2026): o PIX na sua chave sem a
        // chave ficava ligado e so era recusado na hora de cobrar. Desligar passa sempre.
        $naoLiga = $ligar ? shield_conta_ligar_recusa($conta, shield_cobranca_credenciais($conta)) : null;
        if ($naoLiga !== null) {
            throw new RuntimeException($naoLiga);
        }
        $pdo->prepare('UPDATE conta_recebimento SET ativo = :a WHERE id = :id')->execute(array(':a' => $ligar, ':id' => $id));
        shield_auditar($pdo, $ligar ? 'conta_ligada' : 'conta_desligada', array('alvo_tipo' => 'conta_recebimento', 'alvo_id' => $id,
            'detalhe' => (string) $conta['apelido']));
        $aviso = $ligar ? 'Forma ligada: passa a aparecer na hora de emitir.' : 'Forma desligada: fica guardada, mas nao e oferecida.';
        $id = 0;
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && $id > 0 && ($_POST['acao'] ?? '') === 'remover') {
    // REMOVER (10/09/2026, tarde): apaga a credencial e desliga; a forma volta
    // para a lista do provedor, como se nunca tivesse sido configurada.
    // Dinheiro nao se remove: nao tem o que apagar. O PIX na sua chave sim
    // (10/09/2026, noite): a chave e apagada e ele volta para a lista.
    try {
        $conta = shield_cobranca_conta($pdo, $id);
        if ($conta === null || (string) $conta['provedor'] === 'dinheiro') {
            throw new RuntimeException('Esta forma nao se remove.');
        }
        $pdo->prepare('UPDATE conta_recebimento SET credenciais = NULL, webhook_segredo = NULL, ativo = 0 WHERE id = :id')->execute(array(':id' => $id));
        shield_auditar($pdo, 'conta_removida', array('alvo_tipo' => 'conta_recebimento', 'alvo_id' => $id,
            'detalhe' => (string) $conta['apelido'] . ': credencial apagada, forma desligada'));
        $aviso = 'Forma removida. Ela voltou para a lista do provedor; configure de novo quando quiser.';
        $id = 0;
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && $id > 0) {
    try {
        $conta = shield_cobranca_conta($pdo, $id);
        if ($conta === null) {
            throw new RuntimeException('Conta nao encontrada.');
        }

        // Credencial em branco no formulario NAO apaga a que esta guardada: o
        // campo vem sempre vazio (nao se exibe segredo), e gravar o vazio
        // desconfiguraria a conta a cada vez que o membro so troca o apelido.
        $atuais = shield_cobranca_credenciais($conta);
        foreach (array_keys($campos[$conta['provedor']] ?? array()) as $campo) {
            $novo = trim((string) ($_POST['cred_' . $campo] ?? ''));
            if ($novo !== '') {
                $atuais[$campo] = $novo;
            }
        }

        // O CERTIFICADO DO INTER E DO C6 CHEGA POR ARQUIVO (16/09/2026): o .crt
        // e o .key que o banco entregou, conferidos como par e gravados no
        // formato que o adaptador le. Sem arquivo nenhum, fica o que estava.
        // O par enviado passa por cima do que foi colado no campo de texto, e
        // apaga a senha antiga: o .p12 montado aqui nasce sem senha.
        if (in_array((string) $conta['provedor'], shield_certificado_provedores_com_par(), true)) {
            $par = shield_certificado_par_do_upload((string) $conta['provedor'], $_FILES);
            if ($par !== null) {
                $atuais = array_merge($atuais, $par);
                unset($atuais['inter_certificado_senha']);
            }
        }

        // Marcar "ligada" pergunta se a conta cobra com a chave que vai ficar
        // gravada (15/09/2026). Recusado, nada e gravado e a frase diz o que falta.
        if (!empty($_POST['ativo'])) {
            $naoLiga = shield_conta_ligar_recusa($conta, $atuais);
            if ($naoLiga !== null) {
                throw new RuntimeException($naoLiga);
            }
        }

        $capacidades = Registro::para((string) $conta['provedor']);
        $limite = $capacidades ? $capacidades->capacidades($conta) : array();

        $stmt = $pdo->prepare(
            'UPDATE conta_recebimento
                SET apelido = :apelido, ambiente = :amb, ativo = :ativo,
                    credenciais = :cred, webhook_segredo = :segredo,
                    aceita_pix = :pix, aceita_boleto = :bol, aceita_cartao = :car
              WHERE id = :id'
        );
        $stmt->execute(array(
            ':apelido' => substr(trim((string) ($_POST['apelido'] ?? $conta['apelido'])), 0, 80),
            ':amb' => ($_POST['ambiente'] ?? '') === 'teste' ? 'teste' : 'producao',
            ':ativo' => empty($_POST['ativo']) ? 0 : 1,
            ':cred' => shield_cobranca_guardar_credenciais($atuais),
            ':segredo' => trim((string) ($_POST['webhook_segredo'] ?? '')) ?: null,
            // A conta nunca pode declarar mais do que o provedor faz.
            ':pix' => (int) (!empty($_POST['aceita_pix']) && !empty($limite['pix'])),
            ':bol' => (int) (!empty($_POST['aceita_boleto']) && !empty($limite['boleto'])),
            ':car' => (int) (!empty($_POST['aceita_cartao']) && !empty($limite['cartao'])),
            ':id' => $id,
        ));

        shield_auditar($pdo, 'conta_recebimento_alterada', array(
            'alvo_tipo' => 'conta_recebimento', 'alvo_id' => $id,
            'detalhe' => (string) $conta['provedor'] . ' -- '
                . (empty($_POST['ativo']) ? 'desligada' : 'ligada'),
        ));

        // Quem clicou em "Gravar e testar" quer o teste da credencial que ACABOU
        // de gravar, e nao a lista: o redirecionamento leva direto ao teste.
        // O grupo vai junto: gravar nao pode fechar o grupo de onde se veio.
        if (($_POST['acao'] ?? '') === 'gravar_e_cadastrar_webhook') {
            // O webhook do Inter e cadastrado pela API, com o token que ACABOU de
            // ser gravado: o cadastro sai do GET seguinte, como o teste.
            header('Location: /formas_recebimento.php?cadastrar_webhook=' . $id . $voltaGrupo);
            exit;
        }
        header(($_POST['acao'] ?? '') === 'gravar_e_testar'
            ? 'Location: /formas_recebimento.php?testar=' . $id . $voltaGrupo
            : 'Location: /formas_recebimento.php?ok=1' . $voltaGrupo);
        exit;
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
}

if (($_GET['ok'] ?? '') === '1') {
    $aviso = 'Forma gravada.';
} elseif (($_GET['ok'] ?? '') === 'contaazul') {
    // A volta do OAuth (contaazul_retorno.php) cai aqui, com o modal aberto.
    $aviso ='Conectado ao Conta Azul. Escolha a conta de cobranca, marque Ligada e grave.';
}
// O erro da conexao com o Conta Azul chega pela sessao, e nao pela URL.
if ($erro === '' && !empty($_SESSION['contaazul_erro'])) {
    $erro = (string) $_SESSION['contaazul_erro'];
    unset($_SESSION['contaazul_erro']);
}

/* CADASTRAR O WEBHOOK NO PROVEDOR (16/09/2026). So o Inter, por enquanto: la
   nao ha tela, e o cadastro e um PUT pela API com a URL do painel ja com o
   token no fim. Sai do GET depois do gravar (o token precisa estar gravado), e
   repetir a pagina repete o PUT, que e idempotente no Inter. */
if (($_GET['cadastrar_webhook'] ?? '') !== '') {
    $alvo = shield_cobranca_conta($pdo, (int) $_GET['cadastrar_webhook']);
    $adaptadorWebhook = $alvo !== null ? Registro::para((string) $alvo['provedor']) : null;
    if ($alvo === null || $adaptadorWebhook === null || !method_exists($adaptadorWebhook, 'cadastrarWebhook')) {
        $erro = 'Esta forma nao cadastra o webhook pelo painel.';
    } elseif (trim((string) $alvo['webhook_segredo']) === '') {
        $erro = 'Grave um token da URL do webhook antes: sem ele o aviso do provedor seria recusado.';
    } else {
        $alvo['_credenciais'] = shield_cobranca_credenciais($alvo);
        $urlCadastro = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
            . '://' . (string) ($_SERVER['HTTP_HOST'] ?? '') . '/webhooks/cobranca.php?p=' . (string) $alvo['provedor']
            . '&t=' . rawurlencode(trim((string) $alvo['webhook_segredo']));
        try {
            $feito = $adaptadorWebhook->cadastrarWebhook($alvo, $urlCadastro);
            $partes = array();
            foreach ($feito as $qual => $ok) {
                $partes[] = ($ok ? 'cadastrado' : 'NAO cadastrado') . ' para ' . $qual;
            }
            shield_auditar($pdo, 'conta_recebimento_webhook', array(
                'alvo_tipo' => 'conta_recebimento', 'alvo_id' => (int) $alvo['id'],
                'detalhe' => (string) $alvo['provedor'] . ' -- ' . implode(', ', $partes) . ' -- ' . $urlCadastro,
            ));
            $aviso = shield_webhook_cadastro_frase($feito, (string) $alvo['apelido']);
        } catch (Throwable $e) {
            $erro = 'O provedor nao aceitou o webhook: ' . $e->getMessage();
        }
    }
}

/* TESTAR uma conta. Sai por GET de proposito: e leitura, nao muda nada, e
   assim o membro pode recarregar a pagina sem reenviar formulario. */
$testeFeito = null;
$qrTeste = '';
if (($_GET['testar'] ?? '') !== '') {
    $alvo = shield_cobranca_conta($pdo, (int) $_GET['testar']);
    if ($alvo !== null && (string) $alvo['provedor'] === 'pix_estatico') {
        /* O PIX estatico nao tem provedor para perguntar. O teste aqui e o
           unico que faz sentido: montar o QR de R$ 1,00 com a chave gravada e
           deixar o membro ler no aplicativo do banco -- se o app mostrar o
           nome dele e o valor, a chave aponta para o lugar certo. Ninguem
           paga; e so leitura. */
        $cred = shield_cobranca_credenciais($alvo);
        $faltam = shield_cred_faltando('pix_estatico', $cred);
        if ($faltam) {
            $testeFeito = array('ok' => false, 'titulo' => 'Falta preencher',
                                'detalhe' => implode(', ', $faltam));
        } else {
            try {
                $qrTeste = \Shield\Cobranca\Brcode::montar(
                    (string) $cred['chave_pix'],
                    (string) ($cred['nome_recebedor'] ?? $alvo['apelido']),
                    (string) ($cred['cidade'] ?? 'BRASIL'),
                    100,
                    'SHTESTE'
                );
                $testeFeito = array('ok' => true, 'titulo' => 'QR gerado',
                                    // O banco mostra o TITULAR DA CHAVE no DICT, e nao o nome do
                                    // codigo (17/09/2026): e ele que confere para onde a chave aponta.
                                    'detalhe' => 'Leia com o aplicativo do banco: ele deve mostrar R$ 1,00 e o titular da chave'
                                        . ' (o nome que o seu banco tem cadastrado, que pode ser diferente de '
                                        . (string) ($cred['nome_recebedor'] ?? $alvo['apelido'])
                                        . '). Nao pague -- e so para conferir para onde a chave aponta.');
            } catch (Throwable $e) {
                $testeFeito = array('ok' => false, 'titulo' => 'A chave nao montou um QR valido',
                                    'detalhe' => $e->getMessage());
            }
        }
        $testeFeito += array('conta' => (int) $alvo['id'], 'apelido' => (string) $alvo['apelido']);
    } elseif ($alvo !== null) {
        // O teste do Conta Azul pode renovar o token; o par novo tem de ser gravado.
        shield_cobranca_ligar_renovacao($pdo);
        $testeFeito = shield_conta_testar($alvo) + array('conta' => (int) $alvo['id'],
                                                          'apelido' => (string) $alvo['apelido']);
    }
}

/* AS FORMAS VEM DE FABRICA. Nao ha "acrescentar": o painel oferece cada
   provedor que sabe operar, ja na lista e aguardando configuracao, e o membro
   so preenche o que vai usar. Uma linha por provedor; se ela nao existe ainda
   (base antiga, provedor novo como a Stone), nasce aqui, desligada. O cadastro
   antigo do PagBank e o provedor de teste ficam de fora: um e legado, o outro
   e da suite. */
$semeados = array();
foreach (shield_cobranca_provedores() as $prov => $m) {
    if ($prov === 'pagseguro' || $prov === 'falso' || Registro::para($prov) === null) {
        continue;
    }
    $semeados[] = $prov;
}
$existentes = array();
foreach (shield_cobranca_contas($pdo) as $c) {
    $existentes[(string) $c['provedor']] = true;
}
foreach ($semeados as $prov) {
    if (isset($existentes[$prov])) {
        continue;
    }
    $m = shield_cobranca_provedores()[$prov];
    // WHERE NOT EXISTS no proprio INSERT (10/09/2026, noite): a lista lida um
    // instante antes nao basta -- duas abas, ou a lista vazia por um erro
    // engolido, semeavam um segundo dinheiro em especie.
    $pdo->prepare(
        'INSERT INTO conta_recebimento (provedor, apelido, ambiente, ativo,
                aceita_pix, aceita_boleto, aceita_cartao, aceita_assinatura, criado_em, atualizado_em)
         SELECT :p, :a, :amb, :ativo, :pix, :bol, :car, :ass, NOW(), NOW()
          WHERE NOT EXISTS (SELECT 1 FROM conta_recebimento WHERE provedor = :p2)'
    )->execute(array(
        ':p2' => $prov,
        ':p' => $prov, ':a' => substr((string) $m['nome'], 0, 80), ':amb' => 'producao',
        // TUDO NASCE DESLIGADO, o dinheiro tambem (10/09/2026, noite): o membro
        // liga pelo botao da linha quando quiser oferecer.
        ':ativo' => 0,
        ':pix' => (int) !empty($m['pix']), ':bol' => (int) !empty($m['boleto']),
        ':car' => (int) !empty($m['cartao']), ':ass' => (int) !empty($m['assinatura']),
    ));
}

$contas = shield_cobranca_contas($pdo);
$editando = $id > 0 ? shield_cobranca_conta($pdo, $id) : null;
$credEditando = $editando ? shield_cobranca_credenciais($editando) : array();

$urlWebhook = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
    . '://' . (string) ($_SERVER['HTTP_HOST'] ?? 'seusite.com.br') . '/webhooks/cobranca.php?p=';
?>
<?php
/* --------------------------------------------------------------- grupos --
 *
 * Tres jeitos de receber, e sao tres NEGOCIOS diferentes -- por isso tres
 * blocos, e nao uma lista so com uma coluna dizendo o tipo:
 *
 *   PELO PROVEDOR  a conta deles gera o QR, o boleto ou o link, e eles
 *                  avisam quando cai. Precisa de credencial e de teste.
 *   NA SUA CHAVE   o painel monta o QR do PIX com a SUA chave; quem confere
 *                  o extrato e voce. Precisa so da chave e do nome.
 *   EM ESPECIE     nada a configurar: o cliente pagou na mao, voce marca.
 */
$grupos = array(
    'provedor' => array(
        'titulo' => 'Pelo provedor',
        'nota' => 'A conta deles gera o QR, o boleto ou o link de cart&atilde;o, e avisa o painel quando o dinheiro cai. Cada uma precisa da credencial e de um teste antes de ligar.',
        'linhas' => array(),
    ),
    'chave' => array(
        'titulo' => 'PIX na sua chave',
        'nota' => 'O painel monta o QR com a sua chave PIX. N&atilde;o h&aacute; retorno autom&aacute;tico: voc&ecirc; v&ecirc; o dinheiro no extrato e confirma na tela de cobran&ccedil;as.',
        'linhas' => array(),
    ),
    'especie' => array(
        'titulo' => 'Em esp&eacute;cie',
        'nota' => 'O cliente pagou na m&atilde;o. Nada a configurar &mdash; s&oacute; marcar como paga.',
        'linhas' => array(),
    ),
);
/* A ORDEM DOS PROVEDORES E FIXA, e nao alfabetica: e a ordem em que o
   membro tende a ter conta -- os grandes primeiro. O cadastro antigo do
   PagBank so aparece se alguem ja gravou credencial nele. */
// O PIX na sua chave vem antes do dinheiro em especie (10/09/2026, noite).
// A ordem e a que o dono pediu em 16/09/2026.
$ordemProvedores = array('asaas', 'mercadopago', 'pagbank', 'pagarme', 'inter', 'infinitepay', 'c6bank', 'contaazul', 'cora', 'efi', 'pix_estatico', 'dinheiro');
usort($contas, static function ($a, $b) use ($ordemProvedores) {
    $pa = array_search((string) $a['provedor'], $ordemProvedores, true);
    $pb = array_search((string) $b['provedor'], $ordemProvedores, true);
    $pa = $pa === false ? 99 : $pa;
    $pb = $pb === false ? 99 : $pb;
    return $pa === $pb ? strcasecmp((string) $a['apelido'], (string) $b['apelido']) : $pa - $pb;
});
$contas = array_values(array_filter($contas, static function ($c) {
    return (string) $c['provedor'] !== 'pagseguro' || trim((string) ($c['credenciais'] ?? '')) !== '';
}));

$configuradas = array();
foreach ($contas as $c) {
    $prov = (string) $c['provedor'];
    $chave = $prov === 'dinheiro' ? 'especie' : ($prov === 'pix_estatico' ? 'chave' : 'provedor');
    $grupos[$chave]['linhas'][] = $c;
    // Configurada = nada faltando E com adaptador. Ligada ou nao: o membro
    // quer ver o que JA ESTA PRONTO para usar, e desligar e decisao dele.
    $adap = Registro::para($prov);
    $temCatalogo = (bool) shield_cred_campos($prov);
    $faltando = shield_cred_faltando($prov, shield_cobranca_credenciais($c));
    // Provedor que fala com API mas cujo catalogo de credenciais o painel nao
    // conhece (o cadastro antigo do PagBank) nao pode contar como configurado
    // -- ninguem preencheu nada nele, so nao ha o que pedir.
    $conhecido = $temCatalogo || ($adap !== null && empty($adap->capacidades($c)['automatico']));
    if ($adap !== null && $conhecido && !$faltando) {
        $configuradas[] = $c;
        // CONFIGURADA SOBE e sai da lista do provedor (10/09/2026, tarde);
        // removida, volta. PIX na chave e dinheiro ficam nos dois lugares.
        if ($chave === 'provedor') {
            array_pop($grupos[$chave]['linhas']);
        }
    }
}
$catalogoProv = shield_cobranca_provedores();

/**
 * Uma linha da lista. O ESTADO em uma cor so, e a cor grita o que o membro
 * provavelmente nao sabe: "aguardando configuracao" e um problema; "desligada"
 * e uma escolha dele.
 */
function shield_forma_linha(array $c, array $catalogo, string $grupo = '')
{
    // $grupo e a chave do <details> onde a linha esta desenhada, e vazio nos
    // Metodos configurados. Vai em cada link e formulario da linha para a
    // pagina seguinte abrir o mesmo grupo (ver $grupoAberto no topo).
    $grupoQs = $grupo !== '' ? '&amp;grupo=' . $grupo : '';
    // Configurada = credencial completa e adaptador; e o que decide se ha
    // "Remover". Mesma conta de cima, refeita aqui porque a linha e uma funcao.
    $configurada = Registro::para((string) $c['provedor']) !== null
        && !shield_cred_faltando((string) $c['provedor'], shield_cobranca_credenciais($c))
        && (bool) shield_cred_campos((string) $c['provedor']);

    $cid = (int) $c['id'];
    $prov = (string) $c['provedor'];
    $adaptador = Registro::para($prov);
    $cap = $adaptador ? $adaptador->capacidades($c) : array();
    $automatico = !empty($cap['automatico']);
    $ligada = ((int) $c['ativo'] === 1);
    $faltam = shield_cred_faltando($prov, shield_cobranca_credenciais($c));
    $nomeProv = $catalogo[$prov]['nome'] ?? $prov;

    if ($adaptador === null) {
        $sel = array('erro', 'fa-exclamation-triangle', 'sem adaptador');
    } elseif ($faltam) {
        $sel = array('atencao', 'fa-hourglass-half', 'aguardando configura&ccedil;&atilde;o');
    } elseif (!$ligada) {
        $sel = array('neutro', 'fa-times-circle', 'desligada');
    } else {
        $sel = array('ok', 'fa-check-circle', 'pronta');
    }

    $formas = array();
    foreach (array('aceita_pix' => 'PIX', 'aceita_boleto' => 'Boleto', 'aceita_cartao' => 'Cart&atilde;o') as $col => $rot) {
        if (!empty($c[$col])) {
            $formas[] = $rot;
        }
    }
    ?>
    <tr<?= $ligada && !$faltam ? '' : ' class="text-secondary"'; ?>>
        <td class="meio sem-rotulo">
            <span class="selo <?= $sel[0]; ?>" title="<?= $sel[2]; ?>"><i class="fas <?= $sel[1]; ?>"></i></span>
        </td>
        <td class="identidade" data-r="Forma">
            <div>
                <a class="nome" href="/formas_recebimento.php?id=<?= $cid; ?><?= $grupoQs; ?>"><?= shield_h(shield_conta_rotulo($c)); ?></a>
                <span class="apoio">
                    <span class="tom-prov tom-prov-<?= shield_h($prov); ?>"><?= shield_h($nomeProv); ?></span>
                    <?php if ((string) $c['ambiente'] !== 'producao'): ?>
                        <?php /* O nome que o provedor usa (Sandbox, Stage, Teste), e nao um
                                 generico: e assim que ele aparece no portal do outro lado. */ ?>
                        &middot; <span style="color: var(--atencao)"><?= shield_cred_ambiente($prov)['rotulos']['teste']; ?></span>
                    <?php endif; ?>
                </span>
            </div>
        </td>
        <td class="meio" data-r="Estado">
            <span class="pilula pilula-<?= $sel[0]; ?>"><?= $sel[2]; ?></span>
            <?php if ($faltam && $adaptador !== null): ?>
                <span class="apoio d-block mt-1">falta: <?= shield_h(implode(', ', $faltam)); ?></span>
            <?php elseif ($ligada && !empty(shield_cred_webhook($prov)['recusa_sem_segredo']) && trim((string) ($c['webhook_segredo'] ?? '')) === ''): ?>
                <?php /* A conta cobra, mas o aviso dela e recusado (17/09/2026): a baixa so chega
                         pela conciliacao. Sem esta linha a lista diria "pronta" e nada mais. */ ?>
                <span class="apoio d-block mt-1" style="color: var(--atencao)">aviso recusado: sem <?= shield_h(strtolower(html_entity_decode(shield_cred_webhook($prov)['rotulo'], ENT_QUOTES, 'UTF-8'))); ?></span>
            <?php elseif ($ligada && shield_cobranca_aviso_na_emissao_recusa($prov) !== null): ?>
                <?php /* O ENDERECO DO AVISO NAO VAI (01/10/2026): sem SHIELD_APP_URL a conta
                         cobra, mas o provedor nao avisa. A frase inteira esta no formulario. */ ?>
                <span class="apoio d-block mt-1" style="color: var(--atencao)"
                      title="<?= shield_h((string) shield_cobranca_aviso_na_emissao_recusa($prov)); ?>">sem aviso: falta SHIELD_APP_URL</span>
            <?php endif; ?>
        </td>
        <td class="meio" data-r="Cobra por">
            <?= $formas ? implode(', ', $formas) : '<span class="text-secondary">&mdash;</span>'; ?>
        </td>
        <td class="meio" data-r="A&ccedil;&otilde;es">
            <span class="acoes">
                <?php if ($automatico || $prov === 'pix_estatico'): ?>
                    <a class="acao" href="/formas_recebimento.php?testar=<?= $cid; ?><?= $grupoQs; ?>"
                       title="<?= $prov === 'pix_estatico'
                           ? 'Testar: gera um QR de R$ 1,00 com a sua chave para voc&ecirc; ler no banco'
                           : 'Testar: pergunta ao provedor se a credencial funciona, sem criar cobran&ccedil;a nenhuma'; ?>"
                       aria-label="Testar <?= shield_h((string) $c['apelido']); ?>">
                        <i class="fas fa-bolt"></i></a>
                <?php endif; ?>
                <?php if ($prov === 'dinheiro'): ?>
                    <form method="post" action="/formas_recebimento.php" class="d-inline">
                        <input type="hidden" name="id" value="<?= $cid; ?>">
                        <input type="hidden" name="acao" value="alternar">
                        <?php if ($grupo !== ''): ?><input type="hidden" name="grupo" value="<?= $grupo; ?>"><?php endif; ?>
                        <button class="btn btn-sm <?= (int) $c['ativo'] === 1 ? 'btn-outline-secondary' : 'btn-outline-primary'; ?> py-0"
                                title="<?= (int) $c['ativo'] === 1 ? 'Desligar: deixa de ser oferecida' : 'Ligar: passa a aparecer na hora de emitir'; ?>"><?= (int) $c['ativo'] === 1 ? 'desligar' : 'ligar'; ?></button>
                    </form>
                <?php endif; ?>
                <?php if ($prov !== 'dinheiro'): ?>
                    <a class="acao" href="/formas_recebimento.php?id=<?= $cid; ?><?= $grupoQs; ?>"
                       title="Configurar esta forma"
                       aria-label="Configurar <?= shield_h((string) $c['apelido']); ?>">
                        <i class="fas fa-cog"></i></a>
                <?php endif; ?>
                <?php /* REMOVER SO O QUE ESTA CONFIGURADO (11/09/2026): sem credencial nao ha o que apagar. */ ?>
                <?php if ($configurada && ($automatico || $prov === 'pix_estatico')): ?>
                    <form method="post" action="/formas_recebimento.php" class="d-inline"
                          onsubmit="return confirm('Remover esta forma? A credencial é apagada e ela volta para a lista do provedor. Cobranças já emitidas por ela continuam onde estão.');">
                        <input type="hidden" name="id" value="<?= $cid; ?>">
                        <input type="hidden" name="acao" value="remover">
                        <?php if ($grupo !== ''): ?><input type="hidden" name="grupo" value="<?= $grupo; ?>"><?php endif; ?>
                        <button class="acao perigo" title="Remover: apaga a credencial e desliga"
                                aria-label="Remover <?= shield_h((string) $c['apelido']); ?>"><i class="fas fa-trash-alt"></i></button>
                    </form>
                <?php endif; ?>
            </span>
        </td>
    </tr>
    <?php
}
?>
<?php $GLOBALS['shield_sem_transicao'] = $editando !== null || $testeFeito !== null; ?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <h1 class="h4 mb-1">Formas de recebimento</h1>
        <p class="text-secondary small mb-0">Por onde o dinheiro do seu cliente chega at&eacute; voc&ecirc;.</p>
    </div>
</div>

<?php shield_aviso_flutuante($aviso, 'ok'); ?>
<?php if ($erro !== ''): ?>
    <div class="alert alert-danger"><?= shield_h($erro); ?></div>
<?php endif; ?>

<?php if ($testeFeito !== null): ?>
    <?php /* O resultado no modal, e nao numa faixa no topo: e resposta a um
             clique, e o membro quer ler, entender e fechar -- nao carregar a
             faixa ate a proxima carga. O QR do PIX estatico entra no mesmo. */ ?>
    <?php /* NASCE ESCONDIDO E APARECE INTEIRO (11/09/2026). O modal e desenhado
             pelo PHP no meio da pagina, e o navegador PINTA O QUE JA CHEGOU: em
             produccao, com a resposta vindo em pedacos pela rede, dava para ver o
             modal pela metade -- sem o rodape, sem os ultimos campos -- e depois
             completo. Na bancada nunca aparecia, porque em localhost a pagina
             inteira chega num pedaco so. O `hidden` sai no script logo depois do
             fechamento do modal: quando ele roda, todo o conteudo ja foi lido.

         E `display:none` no atributo, e nao `hidden`: o modal ja traz
         `style="display:block"` por dentro, e estilo em linha ganha do
         `[hidden]` da folha do navegador -- esconder por `hidden` nao
         esconderia nada. */ ?>
    <div class="modal-backdrop show" id="fundoProvisorioTeste" style="display:none"></div>
    <div class="modal show" id="modalTeste" tabindex="-1" aria-labelledby="modalTesteTitulo" style="display:none">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title h6 mb-0" id="modalTesteTitulo">
                        Teste &mdash; <?= shield_h($testeFeito['apelido']); ?>
                    </h2>
                    <button type="button" class="btn-close" data-fecha="1" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <div class="teste-resultado mb-3">
                        <span class="selo <?= $testeFeito['ok'] ? 'ok' : 'erro'; ?>">
                            <i class="fas <?= $testeFeito['ok'] ? 'fa-check' : 'fa-exclamation-triangle'; ?>"></i>
                        </span>
                        <div>
                            <strong><?= shield_h($testeFeito['titulo']); ?></strong>
                            <span class="text-secondary small"><?= shield_h($testeFeito['detalhe']); ?></span>
                        </div>
                    </div>
                    <?php if ($qrTeste !== ''): ?>
                        <div class="text-center">
                            <canvas id="qrTeste" width="240" height="240" style="width:240px;height:240px;border:1px solid var(--borda);border-radius:.5rem;background:#fff"></canvas>
                        </div>
                        <p class="small text-secondary mt-3 mb-2">
                            Aponte a c&acirc;mera do aplicativo do banco. O nome e o valor que aparecerem l&aacute;
                            s&atilde;o o que o seu cliente vai ver &mdash; se o nome for outro, a chave aponta para
                            a conta errada. <strong>N&atilde;o pague.</strong>
                        </p>
                        <div class="input-group input-group-sm">
                            <input type="text" id="copiaTeste" class="form-control num" readonly value="<?= shield_h($qrTeste); ?>">
                            <button type="button" class="btn btn-outline-secondary js-copiar" data-codigo="<?= shield_h($qrTeste); ?>">
                                <i class="fas fa-copy"></i> Copiar
                            </button>
                        </div>
                    <?php else: ?>
                        <p class="small text-secondary mb-0">
                            O teste pergunta ao provedor por uma cobran&ccedil;a que n&atilde;o existe. Ele n&atilde;o cria,
                            n&atilde;o cobra e n&atilde;o deixa rastro &mdash; s&oacute; diz se a credencial abre a porta.
                        </p>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <?php if ($testeFeito['conta'] > 0 && $qrTeste === '' && !$testeFeito['ok']): ?>
                        <a class="btn btn-outline-secondary btn-sm me-auto" href="/formas_recebimento.php?id=<?= (int) $testeFeito['conta']; ?><?= shield_h($voltaGrupo); ?>">
                            <i class="fas fa-cog"></i> Configurar
                        </a>
                    <?php endif; ?>
                    <button type="button" class="btn btn-primary btn-sm" data-fecha="1">Fechar</button>
                </div>
            </div>
        </div>
    </div>
    <script>
      // Aqui o modal ja esta inteiro no documento: mostrar agora e mostrar pronto.
      (function () {
        var fundo = document.getElementById('fundoProvisorioTeste');
        var el = document.getElementById('modalTeste');

        // A BARRA DE ROLAGEM SOME AGORA, e nao quando o bootstrap chegar.
        // Quem punha `modal-open` no body era ele, no fim do carregamento: a
        // pagina inteira pulava a largura da barra com o modal ja pintado na
        // tela, e era isso que se via como piscada ao ABRIR. Aqui o pulo
        // acontece antes de haver o que ver.
        var barra = window.innerWidth - document.documentElement.clientWidth;
        document.body.classList.add('modal-open');
        if (barra > 0) { document.body.style.paddingRight = barra + 'px'; }

        fundo.style.display = 'block';
        el.style.display = 'block';

        // FECHAR E IR EMBORA NO MESMO GESTO. Antes o bootstrap fechava o modal
        // primeiro -- desfazendo o modal-open, com a pagina de tras pulando de
        // volta e reaparecendo -- e SO ENTAO a navegacao comecava. Eram tres
        // quadros diferentes para um clique. Agora o modal fica pintado ate a
        // pagina nova chegar.
        var indo = false;
        function sair() {
          if (indo) { return; }
          indo = true;
          // Volta com o grupo de onde o teste saiu; quem o abre e o PHP.
          window.location.replace('/formas_recebimento.php<?= $grupoAberto !== '' ? '?grupo=' . $grupoAberto : ''; ?>');
        }
        el.addEventListener('click', function (ev) { if (ev.target === el) { sair(); } });
        var botoes = el.querySelectorAll('[data-fecha]');
        for (var i = 0; i < botoes.length; i++) { botoes[i].addEventListener('click', sair); }
        document.addEventListener('keydown', function (ev) {
          if (ev.key === 'Escape' || ev.keyCode === 27) { sair(); }
        });
      }());
    </script>
    <?php if ($qrTeste !== ''): ?>
        <script src="/js/qr.js?v=<?= (int) @filemtime(__DIR__ . '/../../public/js/qr.js'); ?>"></script>
    <?php endif; ?>
    <script>
    (function () {
      var c = document.getElementById('qrTeste');
      if (c && window.shieldQr) {
        try { shieldQr.desenhar(c, <?= json_encode($qrTeste, JSON_UNESCAPED_SLASHES); ?>, 240); }
        catch (e) { c.replaceWith(document.createTextNode('Nao consegui desenhar o QR: ' + e.message)); }
      }
    }());
    </script>
<?php endif; ?>

<div class="card mb-3" data-tour="formas-prontas">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span>M&eacute;todos configurados</span>
        <span class="text-secondary small fw-normal"><?= count($configuradas); ?> pronta<?= count($configuradas) == 1 ? '' : 's'; ?> para usar</span>
    </div>
    <div class="table-responsive">
        <table class="lista">
            <thead><tr>
                <th scope="col" style="width:1%"><span class="visually-hidden">Estado</span></th>
                <th scope="col">Forma</th>
                <th scope="col" class="meio">Estado</th>
                <th scope="col" class="meio">Cobra por</th>
                <th scope="col" class="meio" style="width:1%">A&ccedil;&otilde;es</th>
            </tr></thead>
            <tbody>
            <?php if (empty($configuradas)): ?>
                <tr><td colspan="5" class="sem-rotulo"><div class="vazio">Nenhuma forma configurada ainda. Abra um dos grupos abaixo e configure a primeira.</div></td></tr>
            <?php endif; ?>
            <?php foreach ($configuradas as $c) { shield_forma_linha($c, $catalogoProv); } ?>
            </tbody>
        </table>
    </div>
</div>

<?php /* Os grupos vem FECHADOS: o que se usa no dia a dia esta no cartao de
         cima; aqui e onde se vem para configurar mais uma. A excecao e o grupo
         de onde o clique veio ($grupoAberto): o `open` sai daqui, no HTML, e
         nao de um script depois -- o grupo ja nasce aberto no primeiro quadro. */ ?>
<div class="grupos-terminais mb-3">
<?php foreach ($grupos as $chaveGrupo => $g): ?>
    <details class="card grupo-terminais grupo-formas"<?= $chaveGrupo === $grupoAberto ? ' open' : ''; ?>>
        <summary>
            <span class="grupo-nome"><i class="fas fa-credit-card"></i> <?= $g['titulo']; ?></span>
            <span class="grupo-resumo">
                <span class="grupo-total num"><?= count($g['linhas']); ?> forma<?= count($g['linhas']) == 1 ? '' : 's'; ?></span>
                <i class="fas fa-sort-down grupo-seta"></i>
            </span>
            <span class="grupo-nota"><?= $g['nota']; ?></span>
        </summary>
        <div class="table-responsive">
            <table class="lista">
                <thead><tr>
                    <th scope="col" style="width:1%"><span class="visually-hidden">Estado</span></th>
                    <th scope="col">Forma</th>
                    <th scope="col" class="meio">Estado</th>
                    <th scope="col" class="meio">Cobra por</th>
                    <th scope="col" class="meio" style="width:1%">A&ccedil;&otilde;es</th>
                </tr></thead>
                <tbody>
                <?php if (empty($g['linhas'])): ?>
                    <tr><td colspan="5" class="sem-rotulo"><div class="vazio">Nenhuma forma aqui ainda.</div></td></tr>
                <?php endif; ?>
                <?php foreach ($g['linhas'] as $c) { shield_forma_linha($c, $catalogoProv, $chaveGrupo); } ?>
                </tbody>
            </table>
        </div>
    </details>
<?php endforeach; ?>
</div>

<?php if ($editando !== null):
    $prov = (string) $editando['provedor'];
    $adaptador = Registro::para($prov);
    $capacidades = $adaptador ? $adaptador->capacidades($editando) : array();
    $nomeProv = $catalogoProv[$prov]['nome'] ?? $prov;
    $meta = shield_cred_campos($prov);
?>
<?php /* A configuracao abre num modal por cima da lista, e nao num cartao no
         pe da pagina: o membro configura olhando a lista, e fechar volta para
         ela sem rolar. O formulario e o mesmo de sempre -- so o embrulho mudou. */ ?>
<?php /* JA NASCE ABERTO, e nao passa pelo bootstrap. Ele so chega no rodape,
         entao abrir por ele depois de a pagina pintar custava dois quadros: o
         modal aparecendo e, mais tarde, a pagina inteira pulando a largura da
         barra de rolagem quando o `modal-open` finalmente entrava. O script
         logo depois do fechamento deste modal faz as duas coisas de uma vez,
         antes de a tela pintar. */ ?>
<?php /* NASCE ESCONDIDO E APARECE INTEIRO (11/09/2026). O modal e desenhado
         pelo PHP no meio da pagina, e o navegador PINTA O QUE JA CHEGOU: em
         produccao, com a resposta vindo em pedacos pela rede, dava para ver o
         modal pela metade -- sem o rodape, sem os ultimos campos -- e depois
         completo. Na bancada nunca aparecia, porque em localhost a pagina
         inteira chega num pedaco so. O `hidden` sai no script logo depois do
         fechamento do modal: quando ele roda, todo o conteudo ja foi lido. */ ?>
<div class="modal-backdrop show" id="fundoProvisorio" style="display:none"></div>
<div class="modal show" id="modalConfigurar" tabindex="-1" aria-labelledby="modalConfigurarTitulo" style="display:none">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <?php /* multipart por causa dos arquivos de certificado (Inter, C6):
                 sem ele o navegador manda so o nome do arquivo. Nao muda nada
                 para os campos de texto. */ ?>
        <form method="post" action="/formas_recebimento.php" class="modal-content" autocomplete="off" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= (int) $editando['id']; ?>">
            <?php if ($grupoAberto !== ''): ?><input type="hidden" name="grupo" value="<?= $grupoAberto; ?>"><?php endif; ?>
            <div class="modal-header">
                <h2 class="modal-title h6 mb-0" id="modalConfigurarTitulo">
                    Configurar &mdash; <?= shield_h((string) $editando['apelido']); ?>
                    <span class="text-secondary fw-normal">&middot; <span class="tom-prov tom-prov-<?= shield_h($prov); ?>"><?= shield_h($nomeProv); ?></span></span>
                </h2>
                <button type="button" class="btn-close" data-fecha="1" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <?php if ($adaptador === null): ?>
                    <div class="alert alert-warning">
                        O provedor <strong><span class="tom-prov tom-prov-<?= shield_h($prov); ?>"><?= shield_h($nomeProv); ?></span></strong> ainda n&atilde;o tem
                        adaptador neste painel. A forma fica guardada com as credenciais dela e
                        passa a emitir quando o adaptador chegar.
                    </div>
                <?php elseif (empty($capacidades['automatico'])): ?>
                    <div class="alert alert-secondary">
                        <strong>Confirma&ccedil;&atilde;o manual.</strong> N&atilde;o h&aacute; retorno
                        autom&aacute;tico: voc&ecirc; v&ecirc; o dinheiro no seu banco e confirma na tela de
                        cobran&ccedil;as.
                    </div>
                <?php endif; ?>

                <div class="row g-3 mb-3">
                    <div class="col-12">
                        <label class="form-label small mb-1" for="apelido">Como voc&ecirc; chama esta forma</label>
                        <input id="apelido" type="text" name="apelido" class="form-control form-control-sm"
                               value="<?= shield_h((string) $editando['apelido']); ?>" maxlength="80">
                    </div>
                    <?php /* O QUE O BOTAO FAZ MUDA DE PROVEDOR PARA PROVEDOR (11/09/2026):
                             em quatro deles ele troca o endereco; no Mercado Pago e no
                             Pagar.me quem decide e a credencial. Ver shield_cred_ambiente. */ ?>
                    <?php $amb = shield_cred_ambiente($prov); ?>
                    <div class="col-12 col-sm-6">
                        <span class="form-label small mb-1 d-block">Ambiente</span>
                        <div class="dois-lados" role="radiogroup" aria-label="Ambiente">
                            <input type="radio" name="ambiente" id="amb_p" value="producao" <?= $editando['ambiente'] === 'producao' ? 'checked' : ''; ?>>
                            <label for="amb_p"><?= $amb['rotulos']['producao']; ?></label>
                            <input type="radio" name="ambiente" id="amb_t" value="teste" <?= $editando['ambiente'] === 'teste' ? 'checked' : ''; ?>>
                            <label for="amb_t"><?= $amb['rotulos']['teste']; ?></label>
                        </div>
                        <div class="form-text small"><?= $amb['ajuda']; ?></div>
                    </div>
                    <div class="col-12 col-sm-6">
                        <span class="form-label small mb-1 d-block">Esta forma est&aacute;</span>
                        <div class="dois-lados perigo" role="radiogroup" aria-label="Ligada ou desligada">
                            <input type="radio" name="ativo" id="ativo_0" value="0" <?= (int) $editando['ativo'] === 1 ? '' : 'checked'; ?>>
                            <label for="ativo_0" class="desliga">Desligada</label>
                            <input type="radio" name="ativo" id="ativo_1" value="1" <?= (int) $editando['ativo'] === 1 ? 'checked' : ''; ?>>
                            <label for="ativo_1">Ligada</label>
                        </div>
                        <div class="form-text small">Ligada aparece na hora de emitir uma cobran&ccedil;a. Desligada fica guardada, mas n&atilde;o &eacute; oferecida.</div>
                    </div>
                </div>

                <?php if ($meta): ?>
                    <h3 class="h6 mb-1">Credenciais</h3>
                    <p class="small text-secondary mb-2">
                        O nome de cada campo &eacute; o mesmo do portal do provedor. Campo em branco
                        <strong>n&atilde;o apaga</strong> o que j&aacute; est&aacute; guardado.
                    </p>
                    <div class="row g-2 mb-3">
                        <?php foreach ($meta as $campo => $m):
                            $guardado = trim((string) ($credEditando[$campo] ?? ''));
                        ?>
                            <div class="col-12 col-lg-6">
                                <label class="form-label small mb-1" for="c_<?= shield_h($campo); ?>"><?= $m['rotulo']; ?></label>
                                <?php if ($campo === 'tipo_chave'): ?>
                                    <?php /* Sempre em "Escolha": trocar o tipo limpa a chave ao lado,
                                             entao pre-selecionar o gravado e convidar a apagar sem
                                             querer. O que esta gravado vai na ajuda. */ ?>
                                    <select id="c_tipo_chave" name="cred_tipo_chave" class="form-select form-select-sm"
                                            data-gravado="<?= shield_h($guardado); ?>">
                                        <?php foreach (array('' => 'Escolha', 'cpf' => 'CPF', 'cnpj' => 'CNPJ', 'celular' => 'Celular',
                                                             'email' => 'E-mail', 'aleatoria' => 'Chave aleat&oacute;ria') as $v => $r): ?>
                                            <option value="<?= $v; ?>"><?= $r; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                <?php elseif ($campo === 'contaazul_conta_financeira'): ?>
                                    <?php /* A CONTA DE COBRANCA E ESCOLHIDA, NAO DIGITADA (16/09/2026): a
                                             lista vem do Conta Azul na volta do OAuth e fica gravada em
                                             contaazul_contas. Antes de conectar nao ha o que escolher. */ ?>
                                    <?php $contasCa = json_decode((string) ($credEditando['contaazul_contas'] ?? '[]'), true) ?: array(); ?>
                                    <select id="c_contaazul_conta_financeira" name="cred_contaazul_conta_financeira"
                                            class="form-select form-select-sm"<?= $contasCa ? '' : ' disabled'; ?>>
                                        <option value=""><?= $contasCa ? 'Escolha' : 'conecte ao Conta Azul primeiro'; ?></option>
                                        <?php foreach ($contasCa as $ca): ?>
                                            <option value="<?= shield_h((string) ($ca['id'] ?? '')); ?>"<?= (string) ($ca['id'] ?? '') === $guardado ? ' selected' : ''; ?>>
                                                <?= shield_h((string) ($ca['nome'] ?? '')); ?> (<?= (string) ($ca['tipo'] ?? '') === 'CONTA_CORRENTE' ? 'conta corrente' : 'cobran&ccedil;as'; ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                <?php else: ?>
                                    <input id="c_<?= shield_h($campo); ?>" type="text"
                                           class="form-control form-control-sm"
                                           name="cred_<?= shield_h($campo); ?>"
                                           autocomplete="off" spellcheck="false"
                                           placeholder="<?= $guardado !== ''
                                               ? shield_h(!empty($m['segredo']) ? shield_cred_mascara($guardado) : $guardado)
                                               : 'ainda n&atilde;o preenchido'; ?>">
                                <?php endif; ?>
                                <div class="form-text small">
                                    <?= $m['ajuda']; ?>
                                    <?php if ($campo === 'tipo_chave' && $guardado !== ''): ?>
                                        <span class="d-block">Gravado: <strong><?= shield_h($guardado); ?></strong>.</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if ($prov === 'contaazul'): ?>
                        <?php /* A CONEXAO E NO NAVEGADOR (16/09/2026): OAuth2 authorization code.
                                 O botao so aparece com o Client ID e o Client Secret ja GRAVADOS,
                                 porque a ida le a credencial do banco, nao do formulario. A URL
                                 de redirecionamento mostrada e a que o membro cadastra no portal,
                                 byte a byte -- e por isso sai da mesma funcao que a ida usa. */ ?>
                        <?php
                        $caConectada = trim((string) ($credEditando['contaazul_refresh_token'] ?? '')) !== '';
                        $caPronta = trim((string) ($credEditando['contaazul_client_id'] ?? '')) !== ''
                            && trim((string) ($credEditando['contaazul_client_secret'] ?? '')) !== '';
                        $caRedirect = ContaAzul::redirectUri($_SERVER);
                        ?>
                        <h3 class="h6 mb-1">Conex&atilde;o com o Conta Azul</h3>
                        <p class="small text-secondary mb-2">
                            No Portal do Desenvolvedor, cadastre na aplica&ccedil;&atilde;o esta <strong>URL de redirecionamento</strong>,
                            exatamente assim. Depois grave o Client ID e o Client Secret e clique em Conectar: o Conta Azul
                            pede o login da <em>empresa</em> (n&atilde;o o do portal) e volta para c&aacute;.
                        </p>
                        <div class="input-group input-group-sm mb-2">
                            <input type="text" class="form-control" readonly value="<?= shield_h($caRedirect); ?>">
                            <button type="button" class="btn btn-outline-secondary js-copiar"
                                    data-codigo="<?= shield_h($caRedirect); ?>" title="Copiar a URL de redirecionamento">
                                <i class="fas fa-copy"></i> Copiar
                            </button>
                        </div>
                        <p class="small mb-3">
                            <?php if ($caPronta): ?>
                                <a class="btn btn-sm <?= $caConectada ? 'btn-outline-secondary' : 'btn-primary'; ?>"
                                   href="/contaazul_retorno.php?iniciar=<?= (int) $editando['id']; ?>">
                                    <i class="fas fa-link"></i> <?= $caConectada ? 'Conectar de novo ao Conta Azul' : 'Conectar ao Conta Azul'; ?>
                                </a>
                                <span class="text-secondary ms-2"><?= $caConectada ? 'Conectado: o token &eacute; renovado sozinho.' : 'Ainda n&atilde;o conectado.'; ?></span>
                            <?php else: ?>
                                <span class="text-secondary">Grave o Client ID e o Client Secret para o bot&atilde;o Conectar aparecer.</span>
                            <?php endif; ?>
                        </p>
                    <?php endif; ?>
                    <?php if (in_array($prov, shield_certificado_provedores_com_par(), true)): ?>
                        <?php /* O PAR DE ARQUIVOS DO BANCO (16/09/2026). Os conversores publicos do
                                 pacote do membro recebiam a chave privada numa URL sem login; aqui
                                 ela entra atras da sessao, e conferida como par e nunca toca o disco.
                                 Sem arquivo, gravar mantem o certificado que ja esta guardado. */ ?>
                        <h3 class="h6 mb-1">Certificado do banco</h3>
                        <p class="small text-secondary mb-2">
                            Mande os <strong>dois</strong> arquivos que o banco entregou ao criar a aplica&ccedil;&atilde;o.
                            O painel confere se s&atilde;o o mesmo par e guarda cifrado. Sem arquivo, fica o que j&aacute; est&aacute; guardado
                            <?php $temCert = trim((string) ($credEditando[shield_certificado_campo_guardado($prov)] ?? '')) !== ''; ?>
                            (<?= $temCert ? 'h&aacute; um certificado guardado' : 'ainda n&atilde;o h&aacute; certificado'; ?>).
                        </p>
                        <div class="row g-2 mb-3">
                            <div class="col-12 col-lg-6">
                                <label class="form-label small mb-1" for="arquivo_crt">Certificado (.crt)</label>
                                <input id="arquivo_crt" type="file" name="arquivo_crt" class="form-control form-control-sm" accept=".crt,.pem,.cer">
                            </div>
                            <div class="col-12 col-lg-6">
                                <label class="form-label small mb-1" for="arquivo_key">Chave privada (.key)</label>
                                <input id="arquivo_key" type="file" name="arquivo_key" class="form-control form-control-sm" accept=".key,.pem">
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if (!empty($capacidades['automatico'])): ?>
                    <?php /* O TOKEN NA URL (16/09/2026): quem nao assina o aviso (Inter, C6,
                             InfinitePay) confere pelo `t=` no fim da URL. A URL mostrada ja
                             vai com o segredo gravado, para o membro copiar a que funciona. */ ?>
                    <?php
                    $rotWebhook = shield_cred_webhook($prov);
                    $urlWebhookConta = $urlWebhook . $prov;
                    if (!empty($rotWebhook['token_na_url']) && trim((string) ($editando['webhook_segredo'] ?? '')) !== '') {
                        $urlWebhookConta .= '&t=' . rawurlencode(trim((string) $editando['webhook_segredo']));
                    }
                    ?>
                    <h3 class="h6 mb-1">Aviso de pagamento (webhook)</h3>
                    <?php $faltaEndereco = shield_cobranca_aviso_na_emissao_recusa($prov); ?>
                    <?php if ($faltaEndereco !== null): ?>
                        <?php /* Antes do resto do bloco, porque sem ele o resto nao adianta: o
                                 token e a URL abaixo so servem se o endereco for na cobranca. */ ?>
                        <div class="alert alert-warning small mb-3">
                            <?= shield_h($faltaEndereco); ?>
                            Crie (ou edite) o arquivo <code>.env</code> na raiz do painel, ao lado do <code>banco.php</code>,
                            com a linha <code>SHIELD_APP_URL=https://<?= shield_h((string) ($_SERVER['HTTP_HOST'] ?? 'painel.seudominio.com.br')); ?></code>
                            &mdash; o endere&ccedil;o do seu painel, sempre com <code>https://</code>.
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($rotWebhook['sem_webhook'])): ?>
                    <?php /* Quem nao tem webhook (Conta Azul) nao ganha URL nem segredo. E AVISO,
                             nao nota de rodape (pedido do dono, 16/09/2026): quem configura
                             precisa saber que a baixa nao e na hora. */ ?>
                    <div class="alert alert-warning small mb-3"><?= $rotWebhook['ajuda']; ?></div>
                    <?php else: ?>
                    <?php /* QUEM CADASTRA PELA API NAO TEM PORTAL (17/09/2026): o Inter e a Cora
                             nao tem tela de webhook, e a frase mandava colar a URL num lugar que
                             nao existe. */ ?>
                    <?php $adaptadorDoAviso = Registro::para($prov); ?>
                    <?php $cadastraPelaApi = $adaptadorDoAviso !== null && method_exists($adaptadorDoAviso, 'cadastrarWebhook'); ?>
                    <p class="small text-secondary mb-2">
                        <?php if ($cadastraPelaApi): ?>
                        Esta URL n&atilde;o se cola em portal nenhum: grave um token abaixo e clique em
                        <strong>Gravar e cadastrar o webhook</strong>, que o painel a cadastra no
                        <span class="tom-prov tom-prov-<?= shield_h($prov); ?>"><?= shield_h($nomeProv); ?></span> pela API.
                        <?php else: ?>
                        Cole esta URL no portal do <span class="tom-prov tom-prov-<?= shield_h($prov); ?>"><?= shield_h($nomeProv); ?></span>.
                        <?php endif; ?>
                        Sem ela o cliente paga e o painel <em>n&atilde;o fica sabendo</em> at&eacute; algu&eacute;m clicar em Conferir.
                    </p>
                    <div class="input-group input-group-sm mb-2">
                        <input type="text" class="form-control" readonly value="<?= shield_h($urlWebhookConta); ?>">
                        <button type="button" class="btn btn-outline-secondary js-copiar"
                                data-codigo="<?= shield_h($urlWebhookConta); ?>" title="Copiar a URL">
                            <i class="fas fa-copy"></i> Copiar
                        </button>
                    </div>
                    <?php /* O NOME E O DO PORTAL (11/09/2026): "Segredo do webhook" nao e
                             como nenhum provedor chama isso, e o membro ficava com um nome
                             no painel e outro do outro lado. Ver shield_cred_webhook. */ ?>
                    <div class="row g-2 mb-3">
                        <div class="col-12 col-lg-6">
                            <label class="form-label small mb-1" for="webhook_segredo">
                                <?= $rotWebhook['rotulo']; ?><?= (empty($rotWebhook['token_na_url']) && empty($rotWebhook['recusa_sem_segredo'])) ? ' (opcional)' : ''; ?>
                            </label>
                            <input id="webhook_segredo" type="text" name="webhook_segredo"
                                   class="form-control form-control-sm"
                                   value="<?= shield_h((string) ($editando['webhook_segredo'] ?? '')); ?>"
                                   maxlength="120" autocomplete="off">
                            <div class="form-text small">
                                <?= $rotWebhook['ajuda']; ?>
                                <?php /* SEM SEGREDO, RECUSA (17/09/2026): Asaas e Mercado Pago deixaram de
                                         aceitar o aviso da conta sem segredo, e a frase de baixo passou a
                                         valer so para quem ainda aceita. */ ?>
                                <?php if (!empty($rotWebhook['recusa_sem_segredo'])): ?>
                                <strong>Em branco, o aviso &eacute; recusado</strong>: a baixa s&oacute; chega pela concilia&ccedil;&atilde;o
                                (quando algu&eacute;m abre o painel ou o agendador passa) ou pelo bot&atilde;o Conferir.
                                <?php elseif (empty($rotWebhook['token_na_url'])): ?>
                                Em branco, o painel aceita o aviso e continua conferindo com o provedor
                                antes de dar qualquer coisa por paga.
                                <?php else: ?>
                                Depois de gravar, a URL acima aparece j&aacute; com o token no fim.
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if ($adaptador !== null): ?>
                    <h3 class="h6 mb-1">O que esta forma cobra</h3>
                    <p class="small text-secondary mb-2">
                        S&oacute; aparece o que o provedor faz.
                    </p>
                    <div class="d-flex flex-wrap gap-3">
                        <?php foreach (array('pix' => array('aceita_pix', 'PIX'),
                                             'boleto' => array('aceita_boleto', 'Boleto'),
                                             'cartao' => array('aceita_cartao', 'Cart&atilde;o')) as $k => $par):
                            if (empty($capacidades[$k])) { continue; }
                            list($col, $rot) = $par;
                        ?>
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="<?= $col; ?>"
                                       name="<?= $col; ?>" value="1" <?= !empty($editando[$col]) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="<?= $col; ?>"><?= $rot; ?></label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer justify-content-between">
                <span>
                    <?php /* GRAVA E ENTAO TESTA -- 11/09/2026. Era um link: quem colava a
                             credencial e clicava testava a ANTERIOR (ou nenhuma), levava
                             erro e achava que a chave estava errada. Agora e um submit do
                             proprio formulario, e o POST redireciona para o teste. */ ?>
                    <?php if (!empty($capacidades['automatico'])): ?>
                        <button type="submit" name="acao" value="gravar_e_testar" class="btn btn-outline-secondary btn-sm"
                                title="Grava o que est&aacute; na tela e pergunta ao provedor por uma cobran&ccedil;a que n&atilde;o existe. N&atilde;o cria nada.">
                            <i class="fas fa-bolt"></i> Gravar e testar a conex&atilde;o
                        </button>
                        <?php /* So quem cadastra o webhook pela API (o Inter nao tem tela para isso). */ ?>
                        <?php if (method_exists(Registro::para($prov), 'cadastrarWebhook')): ?>
                        <button type="submit" name="acao" value="gravar_e_cadastrar_webhook" class="btn btn-outline-secondary btn-sm"
                                title="Grava o que est&aacute; na tela e cadastra no provedor a URL do webhook com o token no fim, para PIX e boleto.">
                            <i class="fas fa-link"></i> Gravar e cadastrar o webhook no <?= shield_h($nomeProv); ?>
                        </button>
                        <?php endif; ?>
                    <?php elseif ($prov === 'pix_estatico'): ?>
                        <button type="submit" name="acao" value="gravar_e_testar" class="btn btn-outline-secondary btn-sm"
                                title="Grava a chave e gera um QR de R$ 1,00 com ela.">
                            <i class="fas fa-bolt"></i> Gravar e gerar QR de teste
                        </button>
                    <?php endif; ?>
                </span>
                <span class="d-flex gap-2">
                    <button type="button" class="btn btn-outline-secondary btn-sm" data-fecha="1">Cancelar</button>
                    <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Gravar</button>
                </span>
            </div>
        </form>
    </div>
</div>
<script>
  // Aqui o modal ja esta inteiro no documento: mostrar agora e mostrar pronto.
      (function () {
        var fundo = document.getElementById('fundoProvisorio');
        var el = document.getElementById('modalConfigurar');

        // A BARRA DE ROLAGEM SOME AGORA, e nao quando o bootstrap chegar.
        // Quem punha `modal-open` no body era ele, no fim do carregamento: a
        // pagina inteira pulava a largura da barra com o modal ja pintado na
        // tela, e era isso que se via como piscada ao ABRIR. Aqui o pulo
        // acontece antes de haver o que ver.
        var barra = window.innerWidth - document.documentElement.clientWidth;
        document.body.classList.add('modal-open');
        if (barra > 0) { document.body.style.paddingRight = barra + 'px'; }

        fundo.style.display = 'block';
        el.style.display = 'block';

        // FECHAR E IR EMBORA NO MESMO GESTO. Antes o bootstrap fechava o modal
        // primeiro -- desfazendo o modal-open, com a pagina de tras pulando de
        // volta e reaparecendo -- e SO ENTAO a navegacao comecava. Eram tres
        // quadros diferentes para um clique. Agora o modal fica pintado ate a
        // pagina nova chegar.
        var indo = false;
        function sair() {
          if (indo) { return; }
          indo = true;
          window.location.replace('/formas_recebimento.php<?= $grupoAberto !== '' ? '?grupo=' . $grupoAberto : ''; ?>');
        }
        // SO O BOTAO FECHA (11/09/2026). Clique fora e ESC saiam daqui de
        // proposito: este modal e um formulario com credencial colada dentro, e
        // fechar joga fora o que foi digitado sem perguntar. Roçar o mouse na
        // beirada da tela nao pode custar a chave de API de novo. Sair e o X ou
        // o Cancelar -- os dois dizem o que fazem antes de serem clicados.
        var botoes = el.querySelectorAll('[data-fecha]');
        for (var i = 0; i < botoes.length; i++) { botoes[i].addEventListener('click', sair); }
      }());
</script>

<script>
// O MODAL NAO PASSA PELO BOOTSTRAP (11/09/2026). Ele ja vem aberto do PHP, e
// fechar sempre significa trocar de pagina: o unico efeito de entregar o
// elemento ao bootstrap era o `modal-open` chegar atrasado (a pagina pulando a
// largura da barra de rolagem) e a animacao de fechar rodar antes da
// navegacao. O que precisa de JS -- fundo, trava de rolagem, ESC, clique fora
// -- esta no bloco logo acima, e roda antes de a tela pintar.
//
// Aqui fica so a mascara da chave PIX, que depende dos campos e nao do modal.
window.addEventListener('DOMContentLoaded', function () {
  var el = document.getElementById('modalConfigurar');
  if (!el) { return; }

  // ---- a chave PIX escrita do jeito que o tipo pede ----------------------
  // A mascara nao e enfeite: o Brcode vai com o texto cru, e "+55" faltando
  // no celular ou ponto no CPF da um QR que o banco recusa sem dizer por que.
  var tipo = document.getElementById('c_tipo_chave');
  var chave = document.getElementById('c_chave_pix');
  if (tipo && chave) {
    // `max` e a trava: CPF nao passa de 11 digitos, CNPJ de 14, celular de 11
    // (DDD + 9). O que vier a mais e cortado na hora, nao no envio.
    var regras = {
      cpf:       { dica: '000.000.000-00', max: 11, normal: function (v) { return v.replace(/\D/g, '').slice(0, 11); },
                   valido: function (v) { return /^\d{11}$/.test(v); },
                   mostra: function (v) { return v.replace(/(\d{3})(\d{3})(\d{3})(\d{0,2})/, '$1.$2.$3-$4').replace(/-$/, ''); } },
      cnpj:      { dica: '00.000.000/0000-00', max: 14, normal: function (v) { return v.replace(/\D/g, '').slice(0, 14); },
                   valido: function (v) { return /^\d{14}$/.test(v); },
                   mostra: function (v) { return v.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{0,2})/, '$1.$2.$3/$4-$5').replace(/-$/, ''); } },
      celular:   { dica: '(11) 99999-9999', max: 11, normal: function (v) { var d = v.replace(/\D/g, '').replace(/^55(?=\d{11}$)/, '').slice(0, 11); return '+55' + d; },
                   valido: function (v) { return /^\+55\d{10,11}$/.test(v); },
                   mostra: function (v) { var d = v.replace(/\D/g, '').replace(/^55/, ''); return d.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3').replace(/-$/, ''); } },
      email:     { dica: 'voce@empresa.com.br', normal: function (v) { return v.trim().toLowerCase(); },
                   valido: function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); },
                   mostra: function (v) { return v; } },
      aleatoria: { dica: '123e4567-e89b-12d3-a456-426614174000', normal: function (v) { return v.trim().toLowerCase(); },
                   valido: function (v) { return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(v); },
                   mostra: function (v) { return v; } }
    };
    function regra() { return regras[tipo.value] || null; }
    function aplicarDica() {
      var r = regra();
      chave.placeholder = r ? r.dica : chave.getAttribute('data-placeholder-original') || 'ainda nao preenchido';
      chave.classList.remove('is-invalid', 'is-valid');
      // A trava de tamanho vale so para os tipos numericos; a mascara
      // ocupa 14, 18 e 15 caracteres na tela.
      if (r && r.max) { chave.maxLength = { cpf: 14, cnpj: 18, celular: 15 }[tipo.value]; }
      else { chave.removeAttribute('maxlength'); }
      chave.inputMode = r && r.max ? 'numeric' : 'text';
    }
    chave.setAttribute('data-placeholder-original', chave.placeholder);
    tipo.addEventListener('change', function () {
      // Trocar o tipo e comecar de novo: a chave de um tipo nunca serve ao outro.
      chave.value = '';
      aplicarDica();
      chave.focus();
    });
    chave.addEventListener('input', function () {
      var r = regra();
      if (!r) { return; }
      var n = r.normal(chave.value);
      if (tipo.value === 'cpf' || tipo.value === 'cnpj' || tipo.value === 'celular') { chave.value = r.mostra(n.replace(/^\+/, '')); }
      chave.classList.toggle('is-valid', chave.value !== '' && r.valido(n));
      chave.classList.toggle('is-invalid', chave.value !== '' && !r.valido(n));
    });
    // No envio vai o valor NORMALIZADO -- o que o Brcode precisa --, nao a
    // mascara bonita da tela.
    el.querySelector('form').addEventListener('submit', function (ev) {
      var r = regra();
      if (!r || chave.value.trim() === '') { return; }
      var n = r.normal(chave.value);
      if (!r.valido(n)) {
        ev.preventDefault();
        chave.classList.add('is-invalid');
        chave.focus();
        return;
      }
      chave.value = n;
    });
    aplicarDica();
  }
});
</script>
<?php endif; ?>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
