<?php
/**
 * Assinaturas - 25/08/2026.
 *
 * Quem e recorrente, em qual MODO, e quando vem a proxima.
 *
 * O modo aparece na tela como coluna, e nao escondido no cadastro, porque e
 * ele que responde a pergunta que o membro faz quando o telefone toca: "esse
 * cliente esta sendo cobrado por quem?". Na nativa quem cobra e o provedor e o
 * painel acompanha; na manual quem cobra e o painel.
 *
 * O RISCO DE CADA MODO E DIFERENTE, e por isso os dois aparecem nomeados: na
 * nativa, o provedor cobra e o painel pode nao ficar sabendo; na manual, o
 * painel pode esquecer de gerar. Chamar os dois de "assinatura" e nao dizer
 * qual e qual esconde as duas falhas.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/cobranca/assinatura.php';
require_once __DIR__ . '/../../funcoes/licenca/situacao.php';   // shield_cnpj
require_once __DIR__ . '/../../funcoes/ui/lista_ui.php';
require_once __DIR__ . '/../../funcoes/cobranca/busca_cliente.php'; // a mesma busca nos dois cartoes

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

$erro = '';
$aviso = '';

// Esta tela nao grava nada desde 10/09/2026 (tarde): e so de olhar. Editar,
// cancelar e retomar moram em Mudar o contrato, na ficha do cliente.

/* O PIX DO PROXIMO CICLO NASCE SOZINHO. Nao ha cron na hospedagem do membro,
   entao quem dispara e quem abre esta tela -- no maximo uma vez por dia, como
   a compactacao do parque. Gera so o que vence nos proximos 7 dias e pula o
   que ja existe, entao rodar de novo nao duplica nada. */
$geradasHoje = null;
try {
    $ultimaPassada = (string) shield_get_system_meta($pdo, 'assinatura_ciclo_gerado_em', '');
    if (substr($ultimaPassada, 0, 10) !== date('Y-m-d')) {
        $geradasHoje = shield_assinatura_gerar_ciclo($pdo, 7);
        shield_set_system_meta($pdo, 'assinatura_ciclo_gerado_em', date('Y-m-d H:i:s'));
    }
} catch (Throwable $ignorado) {
    // Provedor fora do ar nao pode derrubar a tela de assinaturas.
}

$lista = $pdo->query(
    'SELECT a.*, e.razao, e.cnpj, c.apelido AS conta_apelido, c.provedor AS conta_provedor, p.descricao AS plano_nome
       FROM assinatura a
       LEFT JOIN empresa e ON e.codigo = a.fk_empresa
       LEFT JOIN conta_recebimento c ON c.id = a.fk_conta
       LEFT JOIN planos p ON p.id = a.fk_plano
      ORDER BY a.situacao, a.proxima_competencia'
)->fetchAll(PDO::FETCH_ASSOC) ?: array();

$clientes = $pdo->query('SELECT codigo, razao, cnpj FROM empresa ORDER BY razao')
                ->fetchAll(PDO::FETCH_ASSOC) ?: array();
$contas = shield_cobranca_contas($pdo, true);
$planosAssinatura = array();
try {
    $planosAssinatura = $pdo->query(
        "SELECT id, descricao, recorrencia, valor FROM planos
          WHERE tipo = 'assinatura' AND (status IS NULL OR TRIM(status) IN ('', 'ativo'))
          ORDER BY CAST(recorrencia AS UNSIGNED), descricao"
    )->fetchAll(PDO::FETCH_ASSOC) ?: array();
} catch (Throwable $semPlanos) {
}

/* A RECEITA RECORRENTE, normalizada por mes. E o unico numero que responde
   "de quanto e o meu negocio", e ele exige normalizar o ciclo -- somar a
   coluna de valor com mensal, semestral e anual juntos nao significa nada. */
$mrr = 0;
$ativas = 0;
$pausadas = 0;
$peloProvedor = 0;
foreach ($lista as $a) {
    if ((string) $a['situacao'] === 'ativa') {
        $ativas++;
        $mrr += shield_assinatura_por_mes($a);
        if ((string) $a['modo'] === 'nativa') {
            $peloProvedor++;
        }
    } elseif ((string) $a['situacao'] !== 'cancelada') {
        $pausadas++;
    }
}

/* O TOTAL, guardado ANTES da busca. Os indicadores falam do negocio, e o
   negocio nao encolhe porque alguem digitou um nome no campo de procurar --
   sem isto, buscar algo que nao existe apagava a receita recorrente da tela. */
$temAssinaturas = (count($lista) > 0);

/* BUSCA por nome ou CNPJ. Com trinta linhas, procurar um cliente na tela e
   rolar a pagina inteira duas vezes -- e a lista de clientes ja tem filtro.

   A MESMA BUSCA FILTRA OS PRE-PAGOS (14/09/2026). O campo mora no cartao de
   cima e so filtrava ele: quem procurava um pre-pago lia "nenhuma assinatura"
   com o cliente la embaixo, fora da busca. A regra saiu para
   funcoes/cobranca/busca_cliente.php, e com ela o CNPJ passa a entrar so
   quando a busca tem cara de documento, como em Cobrancas. */
$busca = isset($_GET['q']) ? trim((string) $_GET['q']) : '';
$lista = shield_busca_cliente($lista, $busca);

/* ORDENACAO. O padrao continua sendo por peso -- numa tela de trinta linhas o
   que se procura primeiro e quem pesa --, mas "o que vem primeiro" e a outra
   pergunta que esta tela responde, e antes ela nao tinha resposta: com a ordem
   fixa por valor, as datas apareciam embaralhadas.

   ATIVAS SEMPRE ANTES DAS PAUSADAS, em qualquer ordem escolhida: pausada nao
   compete com ativa por atencao, ela e o rodape da lista. */
$ordens = array('valor' => 1, 'nome' => 1, 'proxima' => 1);
list($ord, $dir) = shield_ordem_escolhida($ordens, 'valor');
$sinal = ($dir === 'ASC') ? 1 : -1;
usort($lista, function ($x, $y) use ($ord, $sinal) {
    $ax = (string) $x['situacao'] === 'ativa' ? 0 : 1;
    $ay = (string) $y['situacao'] === 'ativa' ? 0 : 1;
    if ($ax !== $ay) {
        return $ax - $ay;
    }
    if ($ord === 'nome') {
        return $sinal * strcasecmp((string) ($x['razao'] ?? ''), (string) ($y['razao'] ?? ''));
    }
    if ($ord === 'proxima') {
        // Pelo VENCIMENTO de verdade, e nao pela competencia: duas
        // assinaturas do mesmo mes vencem em dias diferentes, e e o dia que
        // decide qual sai primeiro.
        $vx = $x['proxima_competencia']
            ? shield_assinatura_vencimento($x['proxima_competencia'], $x['dia_vencimento']) : '9999-12-31';
        $vy = $y['proxima_competencia']
            ? shield_assinatura_vencimento($y['proxima_competencia'], $y['dia_vencimento']) : '9999-12-31';

        return $sinal * strcmp($vx, $vy);
    }

    return $sinal * (shield_assinatura_por_mes($y) - shield_assinatura_por_mes($x));
});

/* Quantas o botao "Gerar" vai criar de fato. Sem este numero o membro clica
   sem saber se aquilo produz UMA cobranca ou trinta -- e cobranca criada
   chega no cliente. So conta as que o PAINEL gera: as do provedor saem la. */
$prontasParaGerar = 0;
foreach ($lista as $a) {
    if ((string) $a['situacao'] === 'ativa' && (string) $a['modo'] !== 'nativa') {
        $prontasParaGerar++;
    }
}
?>
<?php
// So as contas que fazem PIX: a assinatura do painel sai como um PIX por
// ciclo, entao oferecer boleto ou cartao aqui e oferecer o que nao vai sair.
$contasPix = array_values(array_filter($contas, static function ($c) {
    return !empty($c['aceita_pix']);
}));

// Quantas vencem nos proximos 7 dias -- e o numero que diz "o que vem ai".
$vencemLogo = 0;
foreach ($lista as $a) {
    if ((string) $a['situacao'] !== 'ativa' || !$a['proxima_competencia']) {
        continue;
    }
    $venc = strtotime(shield_assinatura_vencimento($a['proxima_competencia'], $a['dia_vencimento']));
    if ($venc >= strtotime('today') && $venc <= strtotime('+7 days')) {
        $vencemLogo++;
    }
}
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<?php
// SO PARA OLHAR (10/09/2026, tarde): quem paga como, quanto entra por mes e
// quanto ja entrou. Mexer e em Mudar o contrato do cliente.
$prepagosTodos = shield_prepagos_lista($pdo);
$prepagos = shield_busca_cliente($prepagosTodos, $busca);
$receita = shield_receita_resumo($pdo);
?>
<div class="topo-tela">
    <div>
        <h1 class="h4 mb-1">Assinaturas e pr&eacute;-pagos</h1>
        <p class="text-secondary small mb-0">
            S&oacute; para olhar: quem paga todo ciclo, quem paga de uma vez, quanto entra por m&ecirc;s e quanto j&aacute; entrou.
            Para mudar como um cliente paga, abra a ficha dele e "Mudar o contrato".
        </p>
    </div>
    <?php /* O VOLTAR NA DIREITA DA FAIXA (14/09/2026). Solto como filho da faixa, ele
             descia para baixo do texto quando a descricao ocupava a linha e ficava a
             esquerda. .acoes-pagina tem margin-left: auto, como nas outras telas. */ ?>
    <div class="acoes-pagina">
        <a href="/cobrancas.php" class="btn btn-sm btn-outline-secondary"><i class="fas fa-arrow-left me-1"></i>Voltar</a>
    </div>
</div>

<?php shield_aviso_flutuante($aviso); ?>
<?php if ($erro !== ''): ?>
    <div class="alert alert-danger"><?= shield_h($erro); ?></div>
<?php endif; ?>
<?php if ($geradasHoje !== null && (int) $geradasHoje['criadas'] > 0): ?>
    <div class="alert alert-success">
        Passada de hoje: <?= (int) $geradasHoje['criadas']; ?> cobran&ccedil;a(s) do pr&oacute;ximo ciclo
        criada(s) sozinha(s). Veja em <a href="/cobrancas.php" class="alert-link">Cobran&ccedil;as</a>.
    </div>
<?php endif; ?>

<div class="row g-3 mb-3" data-tour="assinaturas-numeros">
    <div class="col-6 col-xl-3">
        <div class="indicador ok">
            <i class="fas fa-sync-alt fundo"></i>
            <div class="rotulo">Receita recorrente</div>
            <div class="valor">R$ <?= shield_h(shield_dinheiro($mrr)); ?><span class="parte">/m&ecirc;s</span></div>
            <div class="nota">ciclos longos entram divididos pelos meses</div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="indicador marca">
            <i class="fas fa-users fundo"></i>
            <div class="rotulo">Ativas</div>
            <div class="valor"><?= $ativas; ?></div>
            <div class="nota"><?= $pausadas > 0 ? $pausadas . ' pausada' . ($pausadas == 1 ? '' : 's') : 'nenhuma pausada'; ?></div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="indicador <?= $vencemLogo > 0 ? 'atencao' : ''; ?>">
            <i class="fas fa-calendar-day fundo"></i>
            <div class="rotulo">Vencem em 7 dias</div>
            <div class="valor"><?= $vencemLogo; ?></div>
            <div class="nota"><?= $vencemLogo > 0 ? 'o PIX precisa sair antes' : 'nada vence esta semana'; ?></div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="indicador">
            <i class="fas fa-calendar-alt fundo"></i>
            <div class="rotulo">M&eacute;dia por cliente</div>
            <div class="valor">R$ <?= shield_h(shield_dinheiro($ativas > 0 ? (int) round($mrr / $ativas) : 0)); ?></div>
            <div class="nota">por m&ecirc;s, entre as ativas</div>
        </div>
    </div>
</div>

<div class="row g-3 mb-3" data-tour="assinaturas-dinheiro">
    <div class="col-6 col-xl-4">
        <div class="indicador ok">
            <i class="fas fa-money-bill-wave fundo"></i>
            <div class="rotulo">Entrou nos &uacute;ltimos 12 meses</div>
            <div class="valor">R$ <?= shield_h(shield_dinheiro($receita['recebido_12m'])); ?></div>
            <div class="nota">assinaturas e pr&eacute;-pagos, pelo que foi pago</div>
        </div>
    </div>
    <div class="col-6 col-xl-4">
        <div class="indicador <?= $receita['a_receber'] > 0 ? 'atencao' : ''; ?>">
            <i class="fas fa-hourglass-half fundo"></i>
            <div class="rotulo">Na rua</div>
            <div class="valor">R$ <?= shield_h(shield_dinheiro($receita['a_receber'])); ?></div>
            <div class="nota">faturas em aberto e vencidas</div>
        </div>
    </div>
    <div class="col-6 col-xl-4">
        <div class="indicador <?= $receita['vencido'] > 0 ? 'erro' : ''; ?>">
            <i class="fas fa-exclamation-triangle fundo"></i>
            <div class="rotulo">Vencido</div>
            <div class="valor">R$ <?= shield_h(shield_dinheiro($receita['vencido'])); ?></div>
            <div class="nota">o que j&aacute; passou da data</div>
        </div>
    </div>
</div>

<div class="card" data-tour="assinaturas-lista">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <span>Quem &eacute; recorrente</span>
        <form method="get" action="/assinaturas.php" class="d-flex gap-2 align-items-center">
            <?php if ($ord !== 'valor'): ?>
                <input type="hidden" name="ord" value="<?= shield_h($ord); ?>">
                <input type="hidden" name="dir" value="<?= $dir === 'ASC' ? 'asc' : 'desc'; ?>">
            <?php endif; ?>
            <?php /* A CONTAGEM A ESQUERDA DO CAMPO, NUMA LINHA SO (14/09/2026). No fim do
                     formulario ela ficava depois do Limpar, longe do que foi digitado, e o
                     texto quebrava em duas linhas no canto do cartao. */ ?>
            <?php if ($busca !== ''): ?><span class="text-secondary small fw-normal text-nowrap"><?= count($lista); ?> encontrada(s)</span><?php endif; ?>
            <label class="visually-hidden" for="q">Procurar cliente</label>
            <input id="q" type="search" name="q" class="form-control form-control-sm"
                   style="max-width: 15rem" placeholder="Nome ou CNPJ" value="<?= shield_h($busca); ?>">
            <button class="btn btn-sm btn-outline-secondary" type="submit">
                <i class="fas fa-search"></i><span class="visually-hidden">Procurar</span>
            </button>
            <?php if ($busca !== ''): ?>
                <a href="/assinaturas.php" class="btn btn-sm btn-outline-secondary">Limpar</a>
            <?php endif; ?>
        </form>
    </div>
    <div class="table-responsive">
        <table class="lista">
            <thead>
                <tr>
                    <th scope="col" style="width:1%"><span class="visually-hidden">Situa&ccedil;&atilde;o</span></th>
                    <?php shield_th_ordem('assinaturas.php', 'nome', 'Cliente', $ord, $dir); ?>
                    <th scope="col">Plano</th>
                    <?php shield_th_ordem('assinaturas.php', 'proxima', 'Vencimento', $ord, $dir, 'meio'); ?>
                    <?php shield_th_ordem('assinaturas.php', 'valor', 'Por m&ecirc;s', $ord, $dir, 'num'); ?>
                    <th scope="col" class="meio">Conta do PIX</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$lista): ?>
                <tr>
                    <td colspan="6" class="sem-rotulo">
                        <div class="vazio">
                            <i class="fas fa-sync-alt"></i>
                            <?php if ($busca !== ''): ?>
                                Nenhuma assinatura com &ldquo;<?= shield_h($busca); ?>&rdquo;.
                                <a href="/assinaturas.php">Ver todas</a>.
                            <?php else: ?>
                                Nenhuma assinatura ainda. Sem ela, cada m&ecirc;s &eacute; um lan&ccedil;amento &agrave; m&atilde;o.
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endif; ?>
            <?php foreach ($lista as $a):
                $id = (int) $a['id'];
                $ativa = ((string) $a['situacao'] === 'ativa');
                $ciclo = (int) $a['ciclo_meses'];
                $porMes = shield_assinatura_por_mes($a);
                $nome = (string) ($a['razao'] ?? 'Cliente');
                $proxima = $a['proxima_competencia']
                    ? shield_assinatura_vencimento($a['proxima_competencia'], $a['dia_vencimento']) : '';
                $diasProx = $proxima !== '' ? (int) ((strtotime($proxima) - strtotime('today')) / 86400) : null;
            ?>
                <tr<?= $ativa ? '' : ' class="text-secondary"'; ?>>
                    <td class="meio sem-rotulo">
                        <span class="selo <?= $ativa ? 'ok' : 'neutro'; ?>" title="<?= shield_h((string) $a['situacao']); ?>">
                            <i class="fas <?= $ativa ? 'fa-sync-alt' : 'fa-hourglass-half'; ?>"></i>
                        </span>
                    </td>
                    <td class="identidade" data-r="Cliente">
                        <div>
                            <a class="nome" href="/ver_empresa.php?id=<?= (int) $a['fk_empresa']; ?>"><?= shield_h($nome); ?></a>
                            <span class="apoio">
                                <?= shield_h(shield_cnpj($a['cnpj'] ?? '')); ?>
                                <?php if (!$ativa): ?> &middot; <?= shield_h((string) $a['situacao']); ?><?php endif; ?>
                            </span>
                        </div>
                    </td>
                    <td class="identidade" data-r="Plano">
                        <div>
                            <span class="nome"><?= !empty($a['plano_nome']) ? shield_h((string) $a['plano_nome']) : 'sem plano'; ?></span>
                            <span class="apoio"><?= shield_h(shield_assinatura_ciclo_nome($ciclo)); ?>, todo dia <?= (int) $a['dia_vencimento']; ?></span>
                        </div>
                    </td>
                    <td class="meio" data-r="Vencimento">
                        <?php if ($proxima !== ''): ?>
                            <strong class="num"><?= shield_h(date('d/m/Y', strtotime($proxima))); ?></strong>
                            <?php if ($ativa && $diasProx !== null): ?>
                                <span class="apoio d-block" <?= $diasProx < 0 ? 'style="color: var(--erro)"' : ''; ?>>
                                    <?= $diasProx < 0 ? 'atrasado ' . abs($diasProx) . ' dia' . (abs($diasProx) == 1 ? '' : 's')
                                        : ($diasProx == 0 ? 'hoje' : 'em ' . $diasProx . ' dia' . ($diasProx == 1 ? '' : 's')); ?>
                                </span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="text-secondary">&mdash;</span>
                        <?php endif; ?>
                    </td>
                    <td class="num" data-r="Por m&ecirc;s">
                        <strong>R$ <?= shield_h(shield_dinheiro($porMes)); ?></strong>
                        <?php if ($ciclo > 1): ?>
                            <span class="apoio d-block">R$ <?= shield_h(shield_dinheiro((int) $a['valor_centavos'])); ?> por <?= $ciclo; ?> meses</span>
                        <?php endif; ?>
                    </td>
                    <td class="meio" data-r="Conta do PIX">
                        <?php if ($a['conta_apelido']): ?>
                            <span class="pilula pilula-prov pilula-prov-<?= shield_h((string) ($a['conta_provedor'] ?? '')); ?>"><?= shield_h((string) $a['conta_apelido']); ?></span>
                        <?php else: ?>
                            <span class="pilula pilula-neutro" title="A cobran&ccedil;a abre em rascunho e voc&ecirc; emite na tela de cobran&ccedil;as">rascunho</span>
                        <?php endif; ?>
                    </td>
                    <?php /* SEM A COLUNA VER (14/09/2026): a tela serve para entender o fluxo
                             -- quem e recorrente, quem e pre-pago, quanto entra. Os atalhos para
                             cobrancas e Mudar o contrato ja moram na ficha e na lista de
                             clientes; aqui eles faziam a tela parecer um lugar de mexer. */ ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>


<div class="card mt-3" data-tour="assinaturas-prepagos">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <span>Quem paga de uma vez (pr&eacute;-pago)</span>
        <?php /* COM BUSCA, A CONTAGEM E DO QUE CASOU E DIZ DE QUANTOS (14/09/2026): o total
                 cru ao lado de uma lista filtrada parece gente faltando. */ ?>
        <?php if ($busca !== ''): ?>
            <span class="text-secondary small fw-normal text-nowrap"><?= count($prepagos); ?> encontrado(s) de <?= count($prepagosTodos); ?></span>
        <?php else: ?>
            <span class="text-secondary small fw-normal"><?= count($prepagos); ?> cliente<?= count($prepagos) == 1 ? '' : 's'; ?></span>
        <?php endif; ?>
    </div>
    <div class="card-body p-0">
        <?php if (empty($prepagos)): ?>
            <div class="vazio">
                <i class="fas fa-calendar-alt"></i>
                <?php if ($busca !== ''): ?>
                    Nenhum pr&eacute;-pago com &ldquo;<?= shield_h($busca); ?>&rdquo;.
                    <a href="/assinaturas.php">Ver todos</a>.
                <?php else: ?>
                    Nenhum cliente pr&eacute;-pago no momento.
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="table-responsive">
            <table class="lista">
                <thead><tr>
                    <th scope="col">Cliente</th>
                    <th scope="col" class="meio">Sistema liberado at&eacute;</th>
                    <th scope="col" class="meio">&Uacute;ltimo pagamento</th>
                    <th scope="col" class="num">Entrou em 12 meses</th>
                </tr></thead>
                <tbody>
                <?php foreach ($prepagos as $pp): ?>
                    <?php $vencidoPp = substr((string) $pp['validade_licenca'], 0, 10) < date('Y-m-d'); ?>
                    <tr>
                        <td class="identidade" data-r="Cliente"><div>
                            <span class="nome"><?= shield_h((string) $pp['razao']); ?></span>
                            <span class="apoio"><span class="dado"><?= shield_h(shield_cnpj((string) $pp['cnpj'])); ?></span></span>
                        </div></td>
                        <td class="meio" data-r="Sistema liberado at&eacute;">
                            <span class="pilula pilula-<?= $vencidoPp ? 'erro' : 'ok'; ?>"><?= shield_h(date('d/m/Y', strtotime((string) $pp['validade_licenca']))); ?></span>
                        </td>
                        <td class="meio" data-r="&Uacute;ltimo pagamento">
                            <?php if (!empty($pp['ultimo_pago'])): ?>
                                R$ <?= shield_h(shield_dinheiro((int) $pp['ultimo_valor'])); ?>
                                <span class="apoio d-block"><?= shield_h(date('d/m/Y', strtotime((string) $pp['ultimo_pago']))); ?><?= (int) $pp['ultimo_meses'] > 0 ? ' &middot; ' . (int) $pp['ultimo_meses'] . ' meses' : ''; ?></span>
                            <?php else: ?>
                                <span class="text-secondary">&mdash;</span>
                            <?php endif; ?>
                        </td>
                        <td class="num" data-r="Entrou em 12 meses"><strong>R$ <?= shield_h(shield_dinheiro((int) $pp['pago_12m'])); ?></strong></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
