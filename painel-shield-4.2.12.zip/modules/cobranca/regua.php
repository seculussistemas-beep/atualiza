<?php
/**
 * Regua de cobranca - 25/08/2026.
 *
 * Quando avisar, quando insistir, quando suspender. Ela existe desde o primeiro
 * dia porque COBRANCA AUTOMATICA SEM REGUA E CORTE AUTOMATICO -- e corte
 * automatico sem carencia transforma atraso de pagamento em loja parada.
 *
 * A SUSPENSAO NAO E AUTOMATICA POR PADRAO. A regua chega ate o ultimo passo e
 * PROPOE; quem aperta o botao e o membro. Suspender desliga o caixa de uma
 * loja, e a assimetria vale inteira: estender exige prova, suspender exige
 * deliberacao. Quem quiser automatico liga aqui -- e a decisao fica dele,
 * registrada no livro.
 *
 * E toda tela que diz "suspenso" precisa dizer A PARTIR DE QUANDO isso chega na
 * loja: o ERP guarda o token por sete dias e decide sozinho, sem rede, ate ele
 * vencer. Suspender hoje nao para ninguem hoje.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/cobranca/regua.php';
require_once __DIR__ . '/../../funcoes/cobranca/encargos.php';
require_once __DIR__ . '/../../funcoes/licenca/confianca.php'; // liberacao em confianca

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

$erro = '';
$aviso = '';
// Frase de consequencia ou de instrucao fica dez segundos no canto, e nao cinco
// (funcoes/ui/aviso.php): "Cliente suspenso" sem a data de quando vale na loja
// e pior que aviso nenhum.
$avisoDemorado = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $acao = (string) ($_POST['acao'] ?? '');

        if ($acao === 'gravar_passo') {
            $stmt = $pdo->prepare(
                'INSERT INTO regua_passo (dias, acao, ativo, texto)
                 VALUES (:dias, :acao, 1, :texto)
                 ON DUPLICATE KEY UPDATE ativo = 1, texto = VALUES(texto)'
            );
            $stmt->execute(array(
                ':dias' => (int) ($_POST['dias'] ?? 0),
                ':acao' => (string) ($_POST['passo'] ?? 'aviso'),
                ':texto' => substr(trim((string) ($_POST['texto'] ?? '')), 0, 255),
            ));
            $aviso = 'Passo gravado.';
        } elseif ($acao === 'remover_passo') {
            // "Nao encontrado" e recusa, e nao sucesso: com o aviso verde sumindo
            // sozinho no canto, ele passaria por "removido" (14/09/2026).
            if (shield_regua_remover_passo($pdo, (int) ($_POST['passo_id'] ?? 0))) {
                $aviso = 'Passo removido.';
            } else {
                $erro = 'Passo nao encontrado.';
            }
        } elseif ($acao === 'desligar_passo') {
            $stmt = $pdo->prepare('UPDATE regua_passo SET ativo = 0 WHERE id = :id');
            $stmt->execute(array(':id' => (int) ($_POST['passo_id'] ?? 0)));
            $aviso = 'Passo desligado.';
        } elseif ($acao === 'ligar_passo') {
            $stmt = $pdo->prepare('UPDATE regua_passo SET ativo = 1 WHERE id = :id');
            $stmt->execute(array(':id' => (int) ($_POST['passo_id'] ?? 0)));
            $aviso = 'Passo ligado.';
        } elseif ($acao === 'automatica') {
            shield_regua_definir_automatica($pdo, !empty($_POST['ligada']));
            $avisoDemorado = true;
            $aviso = !empty($_POST['ligada'])
                ? 'A regua passa a suspender sozinha ao fim do prazo.'
                : 'A regua volta a apenas propor a suspensao.';
        } elseif ($acao === 'confianca') {
            // LIBERACAO EM CONFIANCA -- 10/09/2026. O "mais uns dias" que cinco
            // membros dao por telefone, agora pelo botao na tela do ERP. Fica
            // na regua porque e a outra metade da mesma conversa: o que
            // acontece quando o cliente atrasa.
            shield_confianca_definir(
                $pdo,
                (int) ($_POST['dias'] ?? 0),
                (int) ($_POST['por_ano'] ?? 1)
            );
            $avisoDemorado = true;
            $aviso = (int) ($_POST['dias'] ?? 0) > 0
                ? 'Liberacao em confianca ligada. O botao aparece na tela de licenca do ERP de quem estiver vencendo.'
                : 'Liberacao em confianca desligada. O botao some do ERP.';
        } elseif ($acao === 'encargos') {
            // MULTA E JUROS -- 09/09/2026. Ficam aqui, e nao numa tela
            // propria, porque foi aqui que os membros os pediram: "que ele
            // calcule multa + juros diario, cadastrados via painel na regua de
            // cobranca". Atraso e assunto da regua.
            // EM DINHEIRO OU EM PERCENTUAL (01/10/2026). O campo e um so e o modo diz
            // como le-lo; o numero do outro modo fica como estava gravado, para
            // quem trocar de ideia voltar a ele.
            $antes = shield_encargos_config($pdo);
            $modoMulta = (string) ($_POST['multa_modo'] ?? '') === SHIELD_ENCARGOS_MULTA_VALOR
                ? SHIELD_ENCARGOS_MULTA_VALOR : SHIELD_ENCARGOS_MULTA_PERCENTUAL;
            $digitado = (string) ($_POST['multa'] ?? '0');
            shield_encargos_definir(
                $pdo,
                $modoMulta === SHIELD_ENCARGOS_MULTA_PERCENTUAL
                    ? (float) str_replace(',', '.', $digitado) : (float) $antes['multa'],
                (float) str_replace(',', '.', (string) ($_POST['juros'] ?? '0')),
                $modoMulta,
                $modoMulta === SHIELD_ENCARGOS_MULTA_VALOR
                    ? (int) shield_centavos($digitado) : (int) $antes['multa_valor_centavos']
            );
            $avisoDemorado = true;
            $aviso = 'Multa e juros gravados. Eles entram quando a cobranca vencida for emitida.';
        } elseif ($acao === 'reemissao') {
            shield_regua_definir_reemissao($pdo, !empty($_POST['ligada']));
            $avisoDemorado = true;
            $aviso = !empty($_POST['ligada'])
                ? 'Ligado. Uma vez por dia a rotina troca o codigo das vencidas pelo de hoje, com multa e juros. O ERP mostra sempre o codigo atual.'
                : 'Desligado. Multa e juros voltam a entrar so quando alguem clicar em reemitir.';
        } elseif ($acao === 'suspender') {
            $empresa = (int) ($_POST['empresa'] ?? 0);
            // Suspender nao escreve por cima do bloqueio manual nem suspende duas
            // vezes (14/09/2026): sem mudanca, a frase nao pode dizer que suspendeu.
            if (!shield_validade_suspender($pdo, $empresa, (string) ($_POST['motivo'] ?? 'suspenso pelo membro'))) {
                throw new RuntimeException('Nada mudou: este cliente ja estava bloqueado ou suspenso.');
            }
            $avisoDemorado = true;
            $aviso = 'Cliente suspenso. Na loja isso passa a valer a partir de '
                . date('d/m/Y', strtotime(shield_validade_quando_vale())) . '.';
        } elseif ($acao === 'liberar') {
            shield_validade_liberar($pdo, (int) ($_POST['empresa'] ?? 0),
                                    (string) ($_POST['motivo'] ?? ''));
            $aviso = 'Suspensao retirada.';
        }
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
}

$passos = shield_regua_passos($pdo, false);
$automatica = shield_regua_suspensao_automatica($pdo);
$reemissao = shield_regua_reemissao_automatica($pdo);
$encargos = shield_encargos_config($pdo);
$confianca = shield_confianca_config($pdo);

// A passada de agora, so para MOSTRAR -- e o `true` e o que garante isso
// (11/09/2026). Sem ele, com o automatico ligado, clicar em "Liberar"
// suspendia o cliente de novo na mesma requisicao: o POST liberava e a
// passada logo abaixo o pegava vencido outra vez.
$situacao = shield_regua_passar($pdo, true);

$suspensos = $pdo->query(
    'SELECT codigo, razao, cnpj, suspenso_em, suspenso_motivo
       FROM empresa WHERE suspenso_em IS NOT NULL ORDER BY suspenso_em DESC'
)->fetchAll(PDO::FETCH_ASSOC) ?: array();

$rotulos = array(
    'lembrete' => 'Lembrar antes do vencimento',
    'aviso' => 'Avisar que venceu',
    'insistir' => 'Insistir',
    'suspender' => 'Propor a suspensao',
);
// O selo na tabela e curto para nao quebrar linha; o nome inteiro fica no
// <select> de cadastro e no title.
$rotulosCurtos = array(
    'lembrete' => 'Lembrar',
    'aviso' => 'Avisar',
    'insistir' => 'Insistir',
    'suspender' => 'Propor suspens&atilde;o',
);
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <h1 class="h4 mb-1">R&eacute;gua de cobran&ccedil;a</h1>
        <p class="text-secondary small mb-0">
            Quando lembrar, quando insistir e quando propor a suspens&atilde;o &mdash; contado a partir do vencimento.
        </p>
    </div>
</div>

<?php shield_aviso_flutuante($aviso, '', $avisoDemorado); ?>
<?php if ($erro !== ''): ?>
    <div class="alert alert-danger"><?= shield_h($erro); ?></div>
<?php endif; ?>

<div class="row g-3 bloco-cheio">
    <?php /* OS SUSPENSOS MORAM EMBAIXO DOS PASSOS (14/09/2026). A coluna da direita
             tem quatro cartoes e a da esquerda um so, esticado ate a mesma altura:
             sobrava meia tela em branco debaixo do formulario de gravar. Os
             suspensos sao o fim da regua, e ficam ao lado de quem os pos la. */ ?>
    <div class="col-xl-7 coluna-empilhada">
        <div class="card" data-tour="regua-passos">
            <div class="card-header">Os passos</div>
            <?php /* A LISTA ROLA SO QUANDO PASSA DOS PASSOS DE FABRICA (14/09/2026). Com a
                     altura fixa de 24rem os cinco passos que a instalacao traz (V3_0_3) ja
                     nasciam com barra de rolagem. Ate sete passos a tabela mostra tudo e os
                     Suspensos embaixo encolhem; dali para cima volta a rolar, para o
                     formulario de gravar continuar a vista. */ ?>
            <div class="table-responsive"<?= count($passos) > 7 ? ' style="max-height: 34rem; overflow-y: auto"' : ''; ?>>
                <table class="lista">
                    <thead><tr>
                        <th scope="col">Quando</th>
                        <th scope="col">O que faz</th>
                        <th scope="col">Texto do aviso</th>
                        <th scope="col" class="meio" style="width:1%">Ligado</th>
                    </tr></thead>
                    <tbody>
                    <?php if (empty($passos)): ?>
                        <tr><td colspan="4" class="sem-rotulo"><div class="vazio"><i class="fas fa-sliders-h"></i>Nenhum passo. Grave o primeiro abaixo.</div></td></tr>
                    <?php endif; ?>
                    <?php foreach ($passos as $p):
                        $ligado = (int) $p['ativo'] === 1;
                        $d = (int) $p['dias'];
                    ?>
                        <tr<?= $ligado ? '' : ' class="text-secondary"'; ?>>
                            <td class="identidade" data-r="Quando">
                                <div>
                                    <span class="nome">
                                        <?php if ($d < 0): ?><?= abs($d); ?> dia<?= abs($d) == 1 ? '' : 's'; ?> antes
                                        <?php elseif ($d === 0): ?>no dia
                                        <?php else: ?><?= $d; ?> dia<?= $d == 1 ? '' : 's'; ?> depois<?php endif; ?>
                                    </span>
                                    <span class="apoio">do vencimento</span>
                                </div>
                            </td>
                            <td data-r="O que faz">
                                <span class="pilula pilula-<?= $p['acao'] === 'suspender' ? 'erro' : ($p['acao'] === 'insistir' ? 'atencao' : 'neutro'); ?>"
                                      style="white-space: nowrap" title="<?= shield_h($rotulos[$p['acao']] ?? (string) $p['acao']); ?>">
                                    <?= $rotulosCurtos[$p['acao']] ?? shield_h((string) $p['acao']); ?>
                                </span>
                            </td>
                            <td data-r="Texto"><?= shield_h((string) ($p['texto'] ?? '')); ?></td>
                            <td class="meio" data-r="Ligado">
                                <span class="acoes d-inline-flex gap-1 align-items-center">
                                <form method="post" action="/regua.php" class="m-0">
                                    <input type="hidden" name="acao" value="<?= $ligado ? 'desligar_passo' : 'ligar_passo'; ?>">
                                    <input type="hidden" name="passo_id" value="<?= (int) $p['id']; ?>">
                                    <button class="btn btn-sm <?= $ligado ? 'btn-outline-secondary' : 'btn-outline-primary'; ?> acao-log"
                                            title="<?= $ligado ? 'Desligar este passo' : 'Ligar este passo'; ?>">
                                        <?= $ligado ? 'desligar' : 'ligar'; ?>
                                    </button>
                                </form>
                                <form method="post" action="/regua.php" class="m-0" onsubmit="return confirm('Remover este passo da r\u00e9gua?');">
                                    <input type="hidden" name="acao" value="remover_passo">
                                    <input type="hidden" name="passo_id" value="<?= (int) $p['id']; ?>">
                                    <button class="acao perigo" title="Remover este passo" aria-label="Remover o passo"><i class="fas fa-trash-alt"></i></button>
                                </form>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="card-body border-top py-3">
                <?php /* DUAS LINHAS, E NAO QUATRO COLUNAS (11/09/2026). Este cartao mora
                         na coluna estreita da tela (uns 520px), entao `col-lg-2` dava 86px
                         a coluna do botao e o "Gravar" quebrava embaixo do icone, com o
                         dobro da altura. As proporcoes aqui sao do CARTAO, nao da janela.

                         E `align-items-start`: o AdminLTE insere a mensagem de campo
                         obrigatorio DENTRO da coluna, e com os campos alinhados pelo pe
                         o "O que faz" subia 46px sozinho quando o erro aparecia. */ ?>
                <form method="post" action="/regua.php" class="row g-2 align-items-start" autocomplete="off">
                    <input type="hidden" name="acao" value="gravar_passo">
                    <div class="col-4">
                        <label class="form-label small mb-1" for="dias">Dias</label>
                        <input id="dias" type="number" name="dias" class="form-control form-control-sm num" value="0" min="-60" max="180">
                    </div>
                    <div class="col-8">
                        <label class="form-label small mb-1" for="passo">O que faz</label>
                        <select id="passo" name="passo" class="form-select form-select-sm" required>
                            <option value="" selected disabled>Selecione&hellip;</option>
                            <?php foreach ($rotulos as $k => $r): ?>
                                <option value="<?= $k; ?>"><?= shield_h($r); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-8">
                        <label class="form-label small mb-1" for="texto">Texto do aviso</label>
                        <input id="texto" type="text" name="texto" class="form-control form-control-sm" maxlength="255" placeholder="O que o cliente l&ecirc;">
                    </div>
                    <div class="col-4">
                        <span class="form-label small mb-1 d-block">&nbsp;</span>
                        <button class="btn btn-sm btn-primary w-100 text-nowrap"><i class="fas fa-plus-circle"></i> Gravar</button>
                    </div>
                    <div class="col-12"><span class="form-text">Dias negativos s&atilde;o antes do vencimento; zero &eacute; no dia; positivos, depois. Mesmo dia e a&ccedil;&atilde;o sobrescreve o texto.</span></div>
                </form>
            </div>
        </div>

        <div class="card rola rola-lista" data-tour="regua-suspensos">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Suspensos</span>
                <?php if ($suspensos): ?><span class="pilula pilula-neutro"><?= count($suspensos); ?></span><?php endif; ?>
            </div>
            <div class="card-body p-0">
            <?php if (empty($suspensos)): ?>
                <div class="vazio"><i class="fas fa-users"></i>Nenhum cliente suspenso.</div>
            <?php else: ?>
                <ul class="list-unstyled mb-0 px-3 py-2">
                <?php foreach ($suspensos as $sus): ?>
                    <li class="pedido-log">
                        <div>
                            <strong class="small d-block"><?= shield_h((string) $sus['razao']); ?></strong>
                            <span class="text-secondary small num d-block">
                                desde <?= shield_h(date('d/m/Y', strtotime((string) $sus['suspenso_em']))); ?>
                                &middot; vale na loja desde <?= shield_h(date('d/m/Y', strtotime(shield_validade_quando_vale($sus['suspenso_em'])))); ?>
                            </span>
                            <span class="small"><?= shield_h((string) ($sus['suspenso_motivo'] ?? '')); ?></span>
                        </div>
                        <form method="post" action="/regua.php">
                            <input type="hidden" name="acao" value="liberar">
                            <input type="hidden" name="empresa" value="<?= (int) $sus['codigo']; ?>">
                            <button class="btn btn-sm btn-outline-secondary">Liberar</button>
                        </form>
                    </li>
                <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-xl-5 coluna-empilhada">
        <?php /* A decisao que mais pesa vem primeiro: suspender desliga o caixa
                 de uma loja. Dois lados, como nas outras telas. */ ?>
        <div class="card <?= $automatica ? 'borda-erro' : ''; ?>" data-tour="regua-fim">
            <div class="card-header">Ao chegar no &uacute;ltimo passo</div>
            <div class="card-body py-3">
                <form method="post" action="/regua.php" class="d-flex align-items-start flex-wrap gap-3">
                    <input type="hidden" name="acao" value="automatica">
                    <div class="dois-lados perigo" role="radiogroup" aria-label="Suspensao automatica">
                        <input type="radio" name="ligada" id="auto_0" value="" <?= $automatica ? '' : 'checked'; ?> onchange="this.form.submit()">
                        <label for="auto_0" class="desliga">S&oacute; propor</label>
                        <input type="radio" name="ligada" id="auto_1" value="1" <?= $automatica ? 'checked' : ''; ?> onchange="this.form.submit()">
                        <label for="auto_1">Suspender sozinha</label>
                    </div>
                    <span class="small text-secondary flex-grow-1" style="min-width: 12rem">
                        <?php if ($automatica): ?>
                            <strong style="color: var(--erro)">Ligada.</strong> No &uacute;ltimo passo o cliente &eacute; suspenso sem
                            ningu&eacute;m confirmar. Isso <strong>para o caixa da loja</strong> em at&eacute;
                            <?= (int) (defined('SHIELD_LICENCA_CARENCIA_DIAS') ? SHIELD_LICENCA_CARENCIA_DIAS : 7); ?> dias.
                        <?php else: ?>
                            Padr&atilde;o. A r&eacute;gua vai at&eacute; o &uacute;ltimo passo e <strong>prop&otilde;e</strong>;
                            quem suspende &eacute; voc&ecirc;, logo abaixo.
                        <?php endif; ?>
                    </span>
                </form>
            </div>
        </div>

        <?php /* Multa e juros ficam ao lado da suspensao porque sao a mesma
                 conversa: o que acontece quando o cliente atrasa. Tres membros
                 pediram no levantamento de 08/09/2026, e um deles pediu aqui
                 mesmo, "na regua de cobranca". */ ?>
        <div class="card" data-tour="regua-atraso">
            <div class="card-header">Quando atrasa</div>
            <div class="card-body py-3">
                <form method="post" action="/regua.php" class="d-flex align-items-end flex-wrap gap-3">
                    <input type="hidden" name="acao" value="encargos">
                    <?php $multaEmValor = $encargos['multa_modo'] === SHIELD_ENCARGOS_MULTA_VALOR; ?>
                    <div>
                        <label for="multa" class="small text-secondary d-block">Multa</label>
                        <div class="input-group input-group-sm" style="width: 11rem">
                            <?php /* O seletor fica colado ao numero porque e ele que diz o que o numero e:
                                     "2" em percentual sao 2%, em dinheiro sao R$ 2,00. */ ?>
                            <select name="multa_modo" class="form-select form-select-sm" style="max-width: 4.5rem"
                                    aria-label="A multa e em percentual ou em dinheiro">
                                <option value="<?= SHIELD_ENCARGOS_MULTA_PERCENTUAL; ?>" <?= $multaEmValor ? '' : 'selected'; ?>>%</option>
                                <option value="<?= SHIELD_ENCARGOS_MULTA_VALOR; ?>" <?= $multaEmValor ? 'selected' : ''; ?>>R$</option>
                            </select>
                            <input type="text" inputmode="decimal" id="multa" name="multa" class="form-control form-control-sm"
                                   value="<?= shield_h($multaEmValor ? shield_dinheiro((int) $encargos['multa_valor_centavos']) : (string) $encargos['multa']); ?>" maxlength="12">
                        </div>
                    </div>
                    <div>
                        <label for="juros" class="small text-secondary d-block">Juros ao dia (%)</label>
                        <input type="text" inputmode="decimal" id="juros" name="juros" class="form-control form-control-sm"
                               style="width: 6rem" value="<?= shield_h((string) $encargos['juros_dia']); ?>" maxlength="8">
                    </div>
                    <button type="submit" class="btn btn-sm btn-outline-secondary">Gravar</button>
                    <span class="small text-secondary flex-grow-1" style="min-width: 12rem">
                        <?php if (!shield_encargos_ligados($encargos)): ?>
                            Desligado, que &eacute; o padr&atilde;o. Nada &eacute; acrescentado a cobran&ccedil;a nenhuma.
                        <?php else: ?>
                            A multa entra <strong>uma vez</strong><?= $multaEmValor ? ', e nunca passa do valor da cobran&ccedil;a' : ''; ?>; os juros correm por dia.
                            Os dois s&atilde;o somados quando a cobran&ccedil;a vencida for emitida,
                            e o recibo mostra o valor j&aacute; com eles.
                        <?php endif; ?>
                    </span>
                </form>
                <?php /* QUEM FAZ O CLIQUE DE REEMITIR (10/09/2026, tarde): o membro, ou a
                         rotina diaria. O valor nunca anda por baixo do PIX na mao do
                         cliente; o que anda e o codigo, trocado pelo de hoje. */ ?>
                <form method="post" action="/regua.php" class="d-flex align-items-start flex-wrap gap-3 mt-3 pt-3 border-top">
                    <input type="hidden" name="acao" value="reemissao">
                    <div class="dois-lados" role="radiogroup" aria-label="Reemissao automatica das vencidas">
                        <input type="radio" name="ligada" id="reem_0" value="" <?= $reemissao ? '' : 'checked'; ?> onchange="this.form.submit()">
                        <label for="reem_0" class="desliga">No clique</label>
                        <input type="radio" name="ligada" id="reem_1" value="1" <?= $reemissao ? 'checked' : ''; ?> onchange="this.form.submit()">
                        <label for="reem_1">Todo dia, sozinha</label>
                    </div>
                    <span class="small text-secondary flex-grow-1" style="min-width: 12rem">
                        <?php if ($reemissao): ?>
                            <strong>Ligada.</strong> Uma vez por dia a rotina cancela o c&oacute;digo da vencida no provedor
                            e emite o de hoje, com multa e juros. S&oacute; mexe se o provedor cancelar o antigo;
                            o ERP mostra sempre o c&oacute;digo atual.
                        <?php else: ?>
                            Multa e juros entram quando <strong>voc&ecirc;</strong> clica em reemitir na cobran&ccedil;a vencida.
                            Ligue para a rotina di&aacute;ria fazer esse clique.
                        <?php endif; ?>
                    </span>
                </form>
            </div>
        </div>

        <?php /* A outra metade de "quando atrasa": em vez de cortar, dar uns dias.
                 O ERP mostra o botao so quando o painel manda o bloco `confianca`,
                 e o painel so manda com dias > 0. */ ?>
        <div class="card" data-tour="regua-confianca">
            <div class="card-header">Libera&ccedil;&atilde;o em confian&ccedil;a</div>
            <div class="card-body py-3">
                <form method="post" action="/regua.php" class="d-flex align-items-end flex-wrap gap-3">
                    <input type="hidden" name="acao" value="confianca">
                    <div>
                        <label for="conf_dias" class="small text-secondary d-block">Dias (0 desliga)</label>
                        <input type="number" min="0" max="30" id="conf_dias" name="dias" class="form-control form-control-sm"
                               style="width: 6rem" value="<?= (int) $confianca['dias']; ?>">
                    </div>
                    <div>
                        <label for="conf_ano" class="small text-secondary d-block">Vezes por 12 meses</label>
                        <input type="number" min="1" max="12" id="conf_ano" name="por_ano" class="form-control form-control-sm"
                               style="width: 6rem" value="<?= (int) $confianca['por_ano']; ?>">
                    </div>
                    <button type="submit" class="btn btn-sm btn-outline-secondary">Gravar</button>
                    <span class="small text-secondary flex-grow-1" style="min-width: 12rem">
                        <?php if ($confianca['dias'] <= 0): ?>
                            Desligado. O cliente n&atilde;o v&ecirc; bot&atilde;o nenhum.
                        <?php else: ?>
                            Cliente vencido ou vencendo em at&eacute; <?= SHIELD_CONFIANCA_JANELA_DIAS; ?> dias ganha, pelo bot&atilde;o na
                            tela de licen&ccedil;a do ERP ou na &aacute;rea do cliente, <strong><?= (int) $confianca['dias']; ?> dias</strong>
                            a partir do vencimento (ou de hoje, para quem j&aacute; venceu) &mdash;
                            sem mexer na validade, no bloqueio nem na cobran&ccedil;a. Uma por vez, no m&aacute;ximo
                            <?= (int) $confianca['por_ano']; ?> por ano, e cada uma fica no livro de auditoria.
                            Bloqueio feito &agrave; m&atilde;o e cadastro encerrado n&atilde;o entram.
                        <?php endif; ?>
                    </span>
                </form>
            </div>
        </div>

        <div class="card rola rola-lista" data-tour="regua-propostas">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Propostas de suspens&atilde;o</span>
                <?php if ($situacao['propostas']): ?><span class="pilula pilula-erro"><?= count($situacao['propostas']); ?></span><?php endif; ?>
            </div>
            <div class="card-body p-0">
            <?php if (empty($situacao['propostas'])): ?>
                <div class="vazio"><i class="fas fa-check-circle"></i>Ningu&eacute;m chegou no fim da r&eacute;gua hoje.</div>
            <?php else: ?>
                <ul class="list-unstyled mb-0 px-3 py-2">
                <?php foreach ($situacao['propostas'] as $p): ?>
                    <li class="pedido-log">
                        <div>
                            <strong class="small d-block"><?= shield_h((string) $p['razao']); ?></strong>
                            <span class="text-secondary small num">
                                R$ <?= shield_h(shield_dinheiro((int) $p['valor_centavos'])); ?>
                                vencida em <?= shield_h(date('d/m/Y', strtotime((string) $p['vencimento']))); ?>
                            </span>
                        </div>
                        <form method="post" action="/regua.php">
                            <input type="hidden" name="acao" value="suspender">
                            <input type="hidden" name="empresa" value="<?= (int) $p['fk_empresa']; ?>">
                            <input type="hidden" name="motivo" value="cobranca <?= (int) $p['id']; ?> vencida">
                            <button class="btn btn-sm btn-outline-danger"
                                    title="Para o caixa da loja em at&eacute; <?= (int) (defined('SHIELD_LICENCA_CARENCIA_DIAS') ? SHIELD_LICENCA_CARENCIA_DIAS : 7); ?> dias">
                                Suspender
                            </button>
                        </form>
                    </li>
                <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
