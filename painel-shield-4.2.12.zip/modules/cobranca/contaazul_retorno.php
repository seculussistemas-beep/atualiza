<?php
/**
 * A ida e a volta do OAuth do Conta Azul - 16/09/2026.
 *
 * O Conta Azul nao tem chave de API para colar: o membro cria a aplicacao no
 * Portal do Desenvolvedor, grava aqui o Client ID e o Client Secret, e o
 * TOKEN nasce de uma autorizacao no login.contaazul.com que volta para esta
 * rota com um `code`. Esta tela faz as duas pontas:
 *
 *   ?iniciar=<conta>   guarda um state aleatorio na sessao e manda o membro
 *                      para a URL de autorizacao;
 *   ?code=..&state=..  confere o state, troca o code pelos tokens, grava,
 *                      lista as contas financeiras e volta para o modal da
 *                      conta em Formas de recebimento.
 *
 * E ROTA DE ADMINISTRADOR LOGADO, apesar de ser um redirect_uri: sem a
 * sessao, qualquer um com o link gravaria um token na conta do membro. E o
 * STATE E OBRIGATORIO: sem ele um link forjado trocaria a conexao pela de
 * outra empresa (o CSRF classico do OAuth).
 *
 * O NOME DESTA ROTA E O redirect_uri CADASTRADO NO PORTAL DO CONTA AZUL. Ele
 * tem de ser igual byte a byte (developers.contaazul.com/requestingcode);
 * renomear a rota desconecta todo membro que ja cadastrou.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca_motor.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca_credenciais.php';

use Shield\Cobranca\Provedores\ContaAzul;

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

/** Volta para o modal da conta, com o grupo "Pelo provedor" aberto. */
function shield_contaazul_voltar($contaId, $ok = false)
{
    header('Location: /formas_recebimento.php?id=' . (int) $contaId . ($ok ? '&ok=contaazul' : '') . '&grupo=provedor');
    exit;
}

/** O erro vai pela sessao, e nao pela URL: a tela o le uma vez e apaga. */
function shield_contaazul_falhar($contaId, $mensagem)
{
    $_SESSION['contaazul_erro'] = (string) $mensagem;
    if ((int) $contaId > 0) {
        shield_contaazul_voltar($contaId);
    }
    header('Location: /formas_recebimento.php?grupo=provedor');
    exit;
}

$redirectUri = ContaAzul::redirectUri($_SERVER);

// ------------------------------------------------------------------- ida ---

if (($_GET['iniciar'] ?? '') !== '') {
    $contaId = (int) $_GET['iniciar'];
    $conta = shield_cobranca_conta($pdo, $contaId);
    if ($conta === null || (string) $conta['provedor'] !== 'contaazul') {
        shield_contaazul_falhar(0, 'Esta forma nao e do Conta Azul.');
    }
    $cred = shield_cobranca_credenciais($conta);
    if (trim((string) ($cred['contaazul_client_id'] ?? '')) === '' || trim((string) ($cred['contaazul_client_secret'] ?? '')) === '') {
        shield_contaazul_falhar($contaId, 'Grave o Client ID e o Client Secret antes de conectar ao Conta Azul.');
    }

    // Um state por ida, aleatorio, guardado na sessao: e o que a volta confere.
    $state = bin2hex(random_bytes(16));
    $_SESSION['contaazul_oauth'] = array('state' => $state, 'conta' => $contaId, 'em' => time());

    header('Location: ' . ContaAzul::urlAutorizacao((string) $cred['contaazul_client_id'], $redirectUri, $state));
    exit;
}

// ----------------------------------------------------------------- volta ---

$pendente = isset($_SESSION['contaazul_oauth']) && is_array($_SESSION['contaazul_oauth']) ? $_SESSION['contaazul_oauth'] : array();
unset($_SESSION['contaazul_oauth']);   // vale UMA volta: repetir a URL nao troca o code de novo
$contaId = (int) ($pendente['conta'] ?? 0);

if (($_GET['error'] ?? '') !== '') {
    shield_contaazul_falhar($contaId, 'O Conta Azul nao autorizou: ' . (string) $_GET['error']
        . (($_GET['error_description'] ?? '') !== '' ? ' -- ' . (string) $_GET['error_description'] : ''));
}

$code = trim((string) ($_GET['code'] ?? ''));
$state = trim((string) ($_GET['state'] ?? ''));
if ($code === '' || $state === '') {
    shield_contaazul_falhar($contaId, 'A volta do Conta Azul veio sem o codigo de autorizacao. Clique em Conectar ao Conta Azul de novo.');
}
// Sem ida guardada (sessao nova, ou ida de 30 min atras) o state nunca confere.
if ($contaId <= 0 || (time() - (int) ($pendente['em'] ?? 0)) > 1800
    || !ContaAzul::stateConfere((string) ($pendente['state'] ?? ''), $state)) {
    shield_contaazul_falhar($contaId, 'A volta do Conta Azul nao confere com a ida (state). Clique em Conectar ao Conta Azul de novo, na mesma aba.');
}

$conta = shield_cobranca_conta($pdo, $contaId);
if ($conta === null || (string) $conta['provedor'] !== 'contaazul') {
    shield_contaazul_falhar(0, 'A conta do Conta Azul nao existe mais.');
}

try {
    // ORDEM: troca o code, GRAVA os tokens, e so entao lista as contas. Se a
    // listagem falhar, a conexao ja esta guardada e o membro so recarrega.
    $cred = shield_cobranca_credenciais($conta);
    $tokens = ContaAzul::trocarCodigo($cred, $code, $redirectUri);
    shield_cobranca_credenciais_mesclar($pdo, $contaId, $tokens);

    $conta = shield_cob_conta($pdo, $contaId);
    $lista = (new ContaAzul())->contasFinanceiras($conta);
    $delta = array('contaazul_contas' => json_encode($lista, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    // Uma conta so: ja fica escolhida, e o membro so grava.
    if (count($lista) === 1) {
        $delta['contaazul_conta_financeira'] = (string) $lista[0]['id'];
    }
    shield_cobranca_credenciais_mesclar($pdo, $contaId, $delta);

    shield_auditar($pdo, 'conta_recebimento_conectada', array(
        'alvo_tipo' => 'conta_recebimento', 'alvo_id' => $contaId,
        'detalhe' => 'contaazul -- autorizado; ' . count($lista) . ' conta(s) de cobranca; redirect_uri ' . $redirectUri,
    ));
} catch (Throwable $e) {
    shield_contaazul_falhar($contaId, 'Nao consegui concluir a conexao com o Conta Azul: ' . $e->getMessage());
}

shield_contaazul_voltar($contaId, true);
