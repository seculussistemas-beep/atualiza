<?php
/**
 * O PDF do boleto, para o membro -- 19/10/2026.
 *
 * Pedido de membro depois de integrar o Inter: "tem que ir no banco para imprimir
 * o boleto". O Inter nao da link publico do boleto; o PDF sai de uma chamada com
 * o certificado da conta, que so o painel tem. Ver shield_cobranca_boleto_pdf.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/cobranca/cobranca_motor.php';

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

try {
    shield_cobranca_enviar_pdf(shield_cobranca_boleto_pdf($pdo, (int) ($_GET['cobranca'] ?? 0)));
} catch (Throwable $e) {
    // Texto simples: quem chega aqui abriu uma aba so para o PDF, e uma pagina
    // do painel inteira por um erro de provedor seria mais confusa que a frase.
    http_response_code(502);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Nao foi possivel buscar o boleto: ' . $e->getMessage();
}
