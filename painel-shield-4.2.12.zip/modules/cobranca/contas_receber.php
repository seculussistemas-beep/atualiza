<?php
/**
 * Contas a receber -- 06/10/2026. Quem deve, quanto, quanto ja venceu e ate
 * quando, um cliente por linha. A regra mora em funcoes/cobranca/relatorio.php
 * (shield_contas_receber), ao lado do relatorio do periodo; aqui so se desenha.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/cobranca/relatorio.php';
require_once __DIR__ . '/../../funcoes/licenca/situacao.php'; // shield_cnpj, shield_telefone

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

$quem = (string) ($_GET['quem'] ?? 'todos');
if (!in_array($quem, array('todos', 'atrasados', 'ate'), true)) {
    $quem = 'todos';
}
$ate = trim((string) ($_GET['ate'] ?? ''));
$ateValida = DateTimeImmutable::createFromFormat('!Y-m-d', $ate);
if (!$ateValida || $ateValida->format('Y-m-d') !== $ate) {
    // Sem data que preste, "vence ate" vira o fim do mes: e a pergunta mais comum.
    $ate = date('Y-m-t');
}

$cr = shield_contas_receber($pdo, $quem, $quem === 'ate' ? $ate : null);

$data = static function ($valor): string {
    $valor = trim((string) $valor);

    return $valor === '' ? '&mdash;' : date('d/m/Y', strtotime($valor));
};
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <h1 class="h4 mb-1">Contas a receber</h1>
        <p class="text-secondary small mb-0">
            Quem est&aacute; devendo, quanto, quanto disso j&aacute; venceu e at&eacute; quando. Conta as faturas
            emitidas em aberto; quem est&aacute; h&aacute; mais tempo sem pagar vem primeiro.
        </p>
    </div>
    <div class="acoes-pagina">
        <a href="/relatorio_financeiro.php" class="btn btn-sm btn-outline-secondary"><i class="fas fa-calendar-day me-1"></i>Relat&oacute;rio do per&iacute;odo</a>
        <a href="/cobrancas.php" class="btn btn-sm btn-outline-secondary"><i class="fas fa-money-bill-wave me-1"></i>Cobran&ccedil;as</a>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-6 col-xl-3">
        <div class="indicador <?= $cr['total'] > 0 ? 'atencao' : 'ok'; ?>">
            <i class="fas fa-money-bill-wave fundo"></i>
            <div class="rotulo">A receber</div>
            <div class="valor">R$ <?= shield_h(shield_dinheiro($cr['total'])); ?></div>
            <div class="nota"><?= (int) $cr['clientes']; ?> cliente(s) com fatura em aberto</div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="indicador <?= $cr['vencido'] > 0 ? 'erro' : ''; ?>">
            <i class="fas fa-exclamation-triangle fundo"></i>
            <div class="rotulo">J&aacute; venceu</div>
            <div class="valor">R$ <?= shield_h(shield_dinheiro($cr['vencido'])); ?></div>
            <div class="nota"><?= (int) $cr['clientes_atrasados']; ?> cliente(s) em atraso</div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="indicador">
            <i class="fas fa-hourglass-half fundo"></i>
            <div class="rotulo">Vence em 7 dias</div>
            <div class="valor">R$ <?= shield_h(shield_dinheiro($cr['sete_dias'])); ?></div>
            <div class="nota">de hoje at&eacute; <?= $data(date('Y-m-d', strtotime('+7 days'))); ?></div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <a class="indicador" href="/cobrancas.php?situacao=rascunho">
            <i class="fas fa-file-signature fundo"></i>
            <div class="rotulo">Em rascunho</div>
            <div class="valor">R$ <?= shield_h(shield_dinheiro($cr['rascunho'])); ?></div>
            <div class="nota"><?= (int) $cr['qtd_rascunho']; ?> fatura(s) que ainda n&atilde;o foram ao cliente</div>
        </a>
    </div>
</div>

<div class="card mb-3" data-tour="contas-receber">
    <div class="card-body py-3">
        <form method="get" action="/contas_receber.php" class="d-flex align-items-end flex-wrap gap-3">
            <div class="btn-group btn-group-sm" role="group" aria-label="Quem mostrar">
                <a class="btn btn-outline-secondary <?= $quem === 'todos' ? 'active' : ''; ?>" href="/contas_receber.php">Todos</a>
                <a class="btn btn-outline-secondary <?= $quem === 'atrasados' ? 'active' : ''; ?>" href="/contas_receber.php?quem=atrasados">S&oacute; quem est&aacute; atrasado</a>
            </div>
            <input type="hidden" name="quem" value="ate">
            <div>
                <label for="ate" class="small text-secondary d-block">Vence at&eacute;</label>
                <input type="date" id="ate" name="ate" class="form-control form-control-sm" value="<?= shield_h($ate); ?>" required>
            </div>
            <button class="btn btn-sm <?= $quem === 'ate' ? 'btn-primary' : 'btn-outline-primary'; ?>"><i class="fas fa-search me-1"></i>Ver at&eacute; esta data</button>
            <?php if ($quem === 'ate'): ?>
                <span class="small text-secondary">Faturas com vencimento at&eacute; <?= $data($ate); ?>, inclusive as que j&aacute; venceram.</span>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="lista">
            <thead>
                <tr>
                    <th scope="col">Cliente</th>
                    <th scope="col" class="num">Faturas</th>
                    <th scope="col" class="num">Deve</th>
                    <th scope="col" class="num">J&aacute; venceu</th>
                    <th scope="col" class="meio">Mais atrasada</th>
                    <th scope="col" class="meio">Pr&oacute;ximo vencimento</th>
                    <th scope="col" class="num">A&ccedil;&otilde;es</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$cr['linhas']): ?>
                <tr><td colspan="7" class="text-secondary small">
                    <?= $quem === 'atrasados' ? 'Ningu&eacute;m em atraso.' : 'Ningu&eacute;m devendo neste recorte.'; ?>
                </td></tr>
            <?php endif; ?>
            <?php foreach ($cr['linhas'] as $l): ?>
                <?php
                $cnpj = (string) ($l['cnpj'] ?? '');
                $fone = trim((string) ($l['fone'] ?? ''));
                ?>
                <tr>
                    <td class="identidade" data-r="Cliente">
                        <div>
                            <a class="nome" href="/ver_empresa.php?id=<?= (int) $l['fk_empresa']; ?>"><?= shield_h((string) ($l['razao'] ?? 'Cliente')); ?></a>
                            <span class="apoio">
                                <?= shield_h($cnpj !== '' ? shield_cnpj($cnpj) : ''); ?>
                                <?php if ($fone !== ''): ?> &middot; <?php $zap = shield_whatsapp_url($fone); ?><?php if ($zap !== null): ?><a href="<?= shield_h($zap); ?>" target="_blank" rel="noopener" title="Abrir no WhatsApp"><?= shield_h(shield_telefone($fone)); ?></a><?php else: ?><?= shield_h(shield_telefone($fone)); ?><?php endif; ?><?php endif; ?>
                                <?php if (!empty($l['encerrado_em'])): ?> &middot; <span class="pilula pilula-neutro">encerrado</span><?php endif; ?>
                            </span>
                        </div>
                    </td>
                    <td class="num" data-r="Faturas"><?= (int) $l['qtd']; ?></td>
                    <td class="num" data-r="Deve">R$ <?= shield_h(shield_dinheiro($l['total'])); ?></td>
                    <td class="num" data-r="J&aacute; venceu">
                        <?php if ($l['vencido'] > 0): ?>
                            <span class="text-danger">R$ <?= shield_h(shield_dinheiro($l['vencido'])); ?></span>
                        <?php else: ?>&mdash;<?php endif; ?>
                    </td>
                    <td class="meio" data-r="Mais atrasada">
                        <?php if ($l['vencido'] > 0): ?>
                            <?= $data($l['mais_antigo']); ?>
                            <span class="pilula pilula-erro ms-1">h&aacute; <?= (int) $l['dias_atraso']; ?> dia<?= $l['dias_atraso'] === 1 ? '' : 's'; ?></span>
                        <?php else: ?><span class="pilula pilula-ok">em dia</span><?php endif; ?>
                    </td>
                    <td class="meio" data-r="Pr&oacute;ximo vencimento"><?= $data($l['proximo']); ?></td>
                    <td class="num" data-r="A&ccedil;&otilde;es">
                        <a class="btn btn-sm btn-outline-secondary" href="/cobrancas.php?empresa=<?= (int) $l['fk_empresa']; ?>"
                           title="As faturas deste cliente em Cobran&ccedil;as"><i class="fas fa-money-bill-wave me-1"></i>Faturas</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
