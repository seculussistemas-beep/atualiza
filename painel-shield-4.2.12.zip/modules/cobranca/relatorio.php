<?php
/**
 * Relatorio do periodo -- 01/10/2026. O que entrou e o que esta para entrar,
 * entre duas datas. A regra (que data conta de que lado, o que fica de fora)
 * mora em funcoes/cobranca/relatorio.php; aqui so se desenha.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/cobranca/relatorio.php';

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

$periodo = shield_relatorio_periodo($_GET);
$de = $periodo['de'];
$ate = $periodo['ate'];
$rel = shield_relatorio_financeiro($pdo, $de, $ate);
$recebido = $rel['recebido'];
$aReceber = $rel['a_receber'];

// Os atalhos de periodo. Sao os dois que se pede de verdade no fechamento do mes;
// qualquer outro sai pelas duas datas.
$hoje = new DateTimeImmutable('today');
$mesPassado = $hoje->modify('first day of last month');
$atalhos = array(
    'Este m&ecirc;s' => array($hoje->format('Y-m-01'), $hoje->format('Y-m-t')),
    'M&ecirc;s passado' => array($mesPassado->format('Y-m-01'), $mesPassado->format('Y-m-t')),
);

$data = static function ($valor): string {
    $valor = trim((string) $valor);

    return $valor === '' ? '&mdash;' : date('d/m/Y', strtotime($valor));
};
$rotuloBalde = array(
    'vencido' => array('erro', 'vencida'),
    'a_vencer' => array('atencao', 'a vencer'),
    'rascunho' => array('neutro', 'rascunho'),
);
?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>

<div class="topo-tela">
    <div>
        <h1 class="h4 mb-1">Relat&oacute;rio do per&iacute;odo</h1>
        <p class="text-secondary small mb-0">
            O que entrou e o que est&aacute; para entrar. <strong>Recebido</strong> conta pela data do pagamento;
            <strong>a receber</strong>, pela data do vencimento. Cancelada e estornada n&atilde;o entram.
        </p>
    </div>
    <div class="acoes-pagina">
        <a href="/cobrancas.php" class="btn btn-sm btn-outline-secondary"><i class="fas fa-money-bill-wave me-1"></i>Cobran&ccedil;as</a>
    </div>
</div>

<?php if ($periodo['erro'] !== null): ?>
    <div class="alert alert-warning py-2 small"><?= shield_h($periodo['erro']); ?></div>
<?php endif; ?>

<div class="card mb-3" data-tour="relatorio-periodo">
    <div class="card-body py-3">
        <form method="get" action="/relatorio_financeiro.php" class="d-flex align-items-end flex-wrap gap-3">
            <div>
                <label for="de" class="small text-secondary d-block">De</label>
                <input type="date" id="de" name="de" class="form-control form-control-sm" value="<?= shield_h($de); ?>" required>
            </div>
            <div>
                <label for="ate" class="small text-secondary d-block">At&eacute;</label>
                <input type="date" id="ate" name="ate" class="form-control form-control-sm" value="<?= shield_h($ate); ?>" required>
            </div>
            <button class="btn btn-sm btn-primary"><i class="fas fa-search me-1"></i>Ver o per&iacute;odo</button>
            <div class="btn-group btn-group-sm" role="group" aria-label="Atalhos de per&iacute;odo">
                <?php foreach ($atalhos as $rotulo => $par): ?>
                    <a class="btn btn-outline-secondary <?= ($par[0] === $de && $par[1] === $ate) ? 'active' : ''; ?>"
                       href="/relatorio_financeiro.php?de=<?= shield_h($par[0]); ?>&amp;ate=<?= shield_h($par[1]); ?>"><?= $rotulo; ?></a>
                <?php endforeach; ?>
            </div>
        </form>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-6 col-xl-3">
        <div class="indicador ok">
            <i class="fas fa-money-bill-wave fundo"></i>
            <div class="rotulo">Recebido</div>
            <div class="valor">R$ <?= shield_h(shield_dinheiro($recebido['total'])); ?></div>
            <div class="nota"><?= (int) $recebido['qtd']; ?> fatura(s) paga(s) no per&iacute;odo</div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="indicador <?= $aReceber['a_vencer'] > 0 ? 'atencao' : ''; ?>">
            <i class="fas fa-hourglass-half fundo"></i>
            <div class="rotulo">A vencer</div>
            <div class="valor">R$ <?= shield_h(shield_dinheiro($aReceber['a_vencer'])); ?></div>
            <div class="nota"><?= (int) $aReceber['qtd_a_vencer']; ?> fatura(s) com vencimento ainda por vir</div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="indicador <?= $aReceber['vencido'] > 0 ? 'erro' : ''; ?>">
            <i class="fas fa-exclamation-triangle fundo"></i>
            <div class="rotulo">Vencido</div>
            <div class="valor">R$ <?= shield_h(shield_dinheiro($aReceber['vencido'])); ?></div>
            <div class="nota"><?= (int) $aReceber['qtd_vencido']; ?> fatura(s) que j&aacute; passaram da data</div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="indicador">
            <i class="fas fa-file-signature fundo"></i>
            <div class="rotulo">Em rascunho</div>
            <div class="valor">R$ <?= shield_h(shield_dinheiro($aReceber['rascunho'])); ?></div>
            <div class="nota"><?= (int) $aReceber['qtd_rascunho']; ?> fatura(s) ainda n&atilde;o emitida(s)</div>
        </div>
    </div>
</div>

<?php if ($rel['cortado']): ?>
    <?php /* O CORTE DIZ QUE CORTOU, como em Cobrancas: os numeros de cima vem do banco
             inteiro, as listas mostram as primeiras SHIELD_RELATORIO_LIMITE. */ ?>
    <div class="alert alert-warning py-2 small">
        Per&iacute;odo grande: as listas mostram as <?= SHIELD_RELATORIO_LIMITE; ?> primeiras linhas de cada lado.
        Os totais acima contam tudo.
    </div>
<?php endif; ?>

<div class="card mb-3">
    <div class="card-header">Recebido de <?= $data($de); ?> a <?= $data($ate); ?></div>
    <div class="table-responsive">
        <table class="lista">
            <thead>
                <tr>
                    <th scope="col">Cliente</th>
                    <th scope="col">Descri&ccedil;&atilde;o</th>
                    <th scope="col" class="meio">Venceu em</th>
                    <th scope="col" class="meio">Pago em</th>
                    <th scope="col" class="num">Valor</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$recebido['linhas']): ?>
                <tr><td colspan="5" class="text-secondary small">Nenhum pagamento neste per&iacute;odo.</td></tr>
            <?php endif; ?>
            <?php foreach ($recebido['linhas'] as $l): ?>
                <tr>
                    <td><a href="/ver_empresa.php?id=<?= (int) $l['fk_empresa']; ?>"><?= shield_h((string) ($l['razao'] ?? 'Cliente')); ?></a></td>
                    <td><?= shield_h((string) $l['descricao']); ?></td>
                    <td class="meio"><?= $data($l['vencimento']); ?></td>
                    <td class="meio"><?= $data($l['pago_em']); ?></td>
                    <td class="num">R$ <?= shield_h(shield_dinheiro((int) $l['valor'])); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-header">A receber com vencimento de <?= $data($de); ?> a <?= $data($ate); ?></div>
    <div class="table-responsive">
        <table class="lista">
            <thead>
                <tr>
                    <th scope="col">Cliente</th>
                    <th scope="col">Descri&ccedil;&atilde;o</th>
                    <th scope="col" class="meio">Vence em</th>
                    <th scope="col" class="meio">Situa&ccedil;&atilde;o</th>
                    <th scope="col" class="num">Valor</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$aReceber['linhas']): ?>
                <tr><td colspan="5" class="text-secondary small">Nada a receber com vencimento neste per&iacute;odo.</td></tr>
            <?php endif; ?>
            <?php foreach ($aReceber['linhas'] as $l): ?>
                <?php list($corBalde, $textoBalde) = $rotuloBalde[(string) $l['balde']] ?? array('neutro', (string) $l['situacao']); ?>
                <tr>
                    <td><a href="/cobrancas.php?empresa=<?= (int) $l['fk_empresa']; ?>"><?= shield_h((string) ($l['razao'] ?? 'Cliente')); ?></a></td>
                    <td><?= shield_h((string) $l['descricao']); ?></td>
                    <td class="meio"><?= $data($l['vencimento']); ?></td>
                    <td class="meio"><span class="pilula pilula-<?= $corBalde; ?>"><?= $textoBalde; ?></span></td>
                    <td class="num">R$ <?= shield_h(shield_dinheiro((int) $l['valor'])); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
