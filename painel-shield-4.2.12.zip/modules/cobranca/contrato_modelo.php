<?php
/**
 * O modelo do contrato -- 01/10/2026. O membro escreve o texto uma vez, com os
 * campos que o painel preenche, e liga o aceite na area do cliente. A regra
 * mora em funcoes/contrato/contrato.php; aqui so se desenha e se grava.
 */

require_once __DIR__ . '/../../verificar_sesao.php';
require_once __DIR__ . '/../../banco.php';
require_once __DIR__ . '/../../funcoes/contrato/contrato.php';

if (trim((string) ($_SESSION['usuario']['acesso'] ?? '')) !== '1') {
    header('Location: /acesso_negado.php');
    exit;
}

$erro = '';
$aviso = '';
$avisoDemorado = false;

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && (string) ($_POST['acao'] ?? '') === 'gravar') {
    try {
        $ligar = !empty($_POST['ativo']);
        shield_contrato_definir($pdo, (string) ($_POST['modelo'] ?? ''), $ligar);
        $avisoDemorado = true;
        $aviso = $ligar
            ? 'Modelo gravado e aceite ligado. Quem ja tem contrato iniciado passa a ver o contrato na area do cliente.'
            : 'Modelo gravado. O aceite esta desligado: a area do cliente nao mostra o contrato.';
    } catch (Throwable $e) {
        $erro = $e->getMessage();
    }
}

$cfg = shield_contrato_config($pdo);
$modeloNaTela = $erro !== '' ? (string) ($_POST['modelo'] ?? $cfg['modelo']) : $cfg['modelo'];
$campos = shield_contrato_campos();

// Os clientes com contrato iniciado, para ver o modelo preenchido. Lista curta de
// proposito: e so para conferir o texto, nao uma lista de trabalho.
$clientes = array();
try {
    $clientes = $pdo->query('SELECT codigo, razao FROM empresa WHERE fechado_em IS NOT NULL ORDER BY razao LIMIT 300')
        ->fetchAll(PDO::FETCH_ASSOC) ?: array();
} catch (Throwable $semColuna) {
}

?>
<?php include __DIR__ . '/../../templates/estrutura.php'; ?>
<?php if ($aviso !== ''): ?><?php shield_aviso_flutuante($aviso, '', $avisoDemorado); ?><?php endif; ?>

<div class="topo-tela">
    <div>
        <h1 class="h4 mb-1">Modelo de contrato</h1>
        <p class="text-secondary small mb-0">
            O texto do contrato que o cliente l&ecirc; e aceita na &aacute;rea do cliente. Os campos entre
            <code>{{ }}</code> o painel preenche com os dados de cada um; o aceite fica registrado com data, IP e o
            e-mail de quem entrou, e vira um PDF.
        </p>
    </div>
</div>

<?php if ($erro !== ''): ?>
    <div class="alert alert-danger"><?= shield_h($erro); ?></div>
<?php endif; ?>

<?php if (!$cfg['gravado']): ?>
    <?php /* NASCE DESLIGADO (4.1): o texto abaixo e uma sugestao, e nada vale ate o membro
             gravar. Revisar com advogado e dele: o painel nao sabe as condicoes do negocio. */ ?>
    <div class="alert alert-warning small">
        Este &eacute; um modelo de partida, ainda n&atilde;o gravado. Revise as cl&aacute;usulas para o seu neg&oacute;cio
        &mdash; de prefer&ecirc;ncia com o seu advogado &mdash; antes de ligar o aceite.
    </div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="card" data-tour="contrato-modelo">
            <div class="card-body">
                <form method="post" action="/contrato_modelo.php">
                    <input type="hidden" name="acao" value="gravar">
                    <label for="modelo" class="form-label small text-secondary">
                        Texto do contrato. A primeira linha vira o t&iacute;tulo; linha que come&ccedil;a com
                        <code># </code> vira o t&iacute;tulo de uma cl&aacute;usula.
                    </label>
                    <textarea id="modelo" name="modelo" class="form-control font-monospace" rows="26"
                              maxlength="<?= SHIELD_CONTRATO_MAX_CARACTERES; ?>" spellcheck="true"><?= shield_h($modeloNaTela); ?></textarea>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" id="ativo" name="ativo" value="1" <?= $cfg['ativo'] ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="ativo">
                            Pedir o aceite na &aacute;rea do cliente
                        </label>
                        <div class="form-text">
                            S&oacute; para quem j&aacute; tem contrato iniciado. Se voc&ecirc; mudar o texto depois, ou se o
                            valor do cliente mudar, a &aacute;rea do cliente pede o aceite de novo; o anterior fica
                            guardado.
                        </div>
                    </div>
                    <button class="btn btn-primary btn-sm mt-3"><i class="fas fa-save me-1"></i>Gravar o modelo</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card mb-3">
            <div class="card-header">Campos que o painel preenche</div>
            <div class="card-body small">
                <?php foreach ($campos as $campo => $explicacao): ?>
                    <div class="mb-1"><code>{{<?= shield_h($campo); ?>}}</code> <span class="text-secondary"><?= shield_h($explicacao); ?></span></div>
                <?php endforeach; ?>
                <p class="text-secondary mt-2 mb-0">
                    N&atilde;o h&aacute; campo com a data de hoje de prop&oacute;sito: o texto mudaria todo dia, e o
                    cliente teria de aceitar de novo a cada manh&atilde;.
                </p>
            </div>
        </div>
        <div class="card">
            <div class="card-header">Ver preenchido</div>
            <div class="card-body small">
                <?php if ($clientes === array()): ?>
                    <p class="text-secondary mb-0">Nenhum cliente com contrato iniciado ainda.</p>
                <?php else: ?>
                    <form method="get" action="/contrato_pdf.php" target="_blank" class="d-flex gap-2">
                        <select name="empresa" class="form-select form-select-sm" aria-label="Cliente">
                            <?php foreach ($clientes as $c): ?>
                                <option value="<?= (int) $c['codigo']; ?>"><?= shield_h((string) $c['razao']); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button class="btn btn-sm btn-outline-secondary" title="Abrir o PDF">PDF</button>
                    </form>
                    <p class="text-secondary mt-2 mb-0">
                        Com o modelo <strong>gravado</strong>. Sem aceite, o PDF sai marcado como minuta.
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../templates/fecha.php'; ?>
