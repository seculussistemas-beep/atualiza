<?php

require_once __DIR__ . '/../../funcoes/nucleo/system_bootstrap.php';
shield_enforce_installation_guard();

$file = dirname(__DIR__, 2) . '/instalador.exe';

if (file_exists($file)) {
    header('Content-Description: File Transfer');
    // O instalador pode ter dezenas de MB: sem isto o filtro do CSRF o
    // seguraria inteiro na memoria antes de mandar o primeiro byte.
    shield_csrf_sem_filtro();
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($file) . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    header('Transfer-Encoding: chunked');

    $handle = fopen($file, 'rb');
    while ($handle !== false && !feof($handle)) {
        echo fread($handle, 1024);
        flush();
    }

    if ($handle !== false) {
        fclose($handle);
    }
    exit;
}
