<?php

return [
    'index' => ['type' => 'include', 'target' => 'modules/sistema/dashboard.php'],
    'dashboard' => ['type' => 'redirect', 'target' => 'index.php'],
    'login' => ['type' => 'include', 'target' => 'modules/sistema/login.php'],
    'logout' => ['type' => 'include', 'target' => 'modules/sistema/logout.php'],
    'sair' => ['type' => 'redirect', 'target' => 'logout.php'],
    'acesso_negado' => ['type' => 'include', 'target' => 'modules/sistema/acesso_negado.php'],
    'atualizacao' => ['type' => 'include', 'target' => 'modules/sistema/atualizacao.php'],
    'softhouse' => ['type' => 'include', 'target' => 'modules/softhouse/ver.php'],
    'editar_softhouse' => ['type' => 'include', 'target' => 'modules/softhouse/editar.php'],
    // CNPJ e CEP consultados pelo servidor, com varias fontes em cascata.
    'ajax_consulta' => ['type' => 'include', 'target' => 'modules/softhouse/ajax_consulta.php'],
    'emissor_licenca' => ['type' => 'include', 'target' => 'modules/licencas/emissor.php'],
    'licenca_arquivo' => ['type' => 'include', 'target' => 'modules/licencas/arquivo.php'],
    // config_whatsapp e excluir_empresa (com o alias processa_excluir_empresa)
    // sairam em 17/09/2026: nenhuma tela chegava nelas. A do WhatsApp dependia
    // de um app Node que nunca esteve no projeto; apagar cliente e na Limpeza.
    // `instalador` FICA de proposito: entrega o instalador.exe que o membro poe
    // na raiz, e ele pode estar mandando esse link para as lojas.
    'instalador' => ['type' => 'include', 'target' => 'modules/install/download_instalador.php'],
    'listar_empresa' => ['type' => 'redirect', 'target' => 'clientes.php'],
    'listar_terminais' => ['type' => 'redirect', 'target' => 'terminais.php'],
    'uf' => ['type' => 'redirect', 'target' => 'clientes.php?status=legacy_uf_redirect'],

    'avaliacao' => ['type' => 'include', 'target' => 'modules/clientes/avaliacao.php'],
    // Cadastrar cliente a mao (16/09/2026): ate aqui so a rota de licenca criava
    // empresa, e quem fechava o negocio antes de instalar abria o ERP numa base
    // limpa so para a loja aparecer -- deixando a propria maquina na cota dela.
    'novo_cliente' => ['type' => 'include', 'target' => 'modules/clientes/novo_cliente.php'],
    'fechamento' => ['type' => 'include', 'target' => 'modules/clientes/fechamento.php'],
    'mudanca_contrato' => ['type' => 'include', 'target' => 'modules/clientes/mudanca.php'],
    'clientes' => ['type' => 'include', 'target' => 'modules/clientes/clientes.php'],
    'ver_empresa' => ['type' => 'include', 'target' => 'modules/clientes/ver_empresa.php'],
    'editar_empresa' => ['type' => 'include', 'target' => 'modules/clientes/editar_empresa.php'],
    'terminais' => ['type' => 'include', 'target' => 'modules/clientes/terminais.php'],
    'parque' => ['type' => 'include', 'target' => 'modules/clientes/parque.php'],
    'logs_cliente' => ['type' => 'include', 'target' => 'modules/clientes/logs.php'],
    'limpeza_cadastros' => ['type' => 'include', 'target' => 'modules/clientes/limpeza.php'],
    'excluir_terminal' => ['type' => 'include', 'target' => 'modules/clientes/excluir_terminal.php'],
    'excluir_terminais_empresa' => ['type' => 'include', 'target' => 'modules/clientes/excluir_terminais_empresa.php'],

    'listar_planos' => ['type' => 'include', 'target' => 'modules/planos/listar_planos.php'],
    'adicionar_plano' => ['type' => 'include', 'target' => 'modules/planos/adicionar_plano.php'],
    'editar_plano' => ['type' => 'include', 'target' => 'modules/planos/editar_plano.php'],
    'excluir_plano' => ['type' => 'include', 'target' => 'modules/planos/excluir_plano.php'],
    // `plano` saiu em 17/09/2026: gravava na tabela `pedido`, que e so
    // historico, e mandava para um pedido_cliente.php que nao existe.
    // `grupos_precos` saiu no mesmo dia: o preco por grupo so entrava no
    // pedido do plano.php, e nenhuma cobranca o lia (V4_2_9).

    'ajax_buscar_clientes' => ['type' => 'include', 'target' => 'modules/clientes/ajax_buscar_clientes.php'],

    'cobrancas' => ['type' => 'include', 'target' => 'modules/cobranca/cobrancas.php'],
    // O que entrou e o que esta para entrar, por periodo (01/10/2026).
    'relatorio_financeiro' => ['type' => 'include', 'target' => 'modules/cobranca/relatorio.php'],
    'contas_receber' => ['type' => 'include', 'target' => 'modules/cobranca/contas_receber.php'],
    'assinaturas' => ['type' => 'include', 'target' => 'modules/cobranca/assinaturas.php'],
    'regua' => ['type' => 'include', 'target' => 'modules/cobranca/regua.php'],
    // O contrato que o cliente aceita na area do cliente (01/10/2026): o modelo,
    // e o PDF de um cliente (o do aceite, ou a minuta).
    'contrato_modelo' => ['type' => 'include', 'target' => 'modules/cobranca/contrato_modelo.php'],
    'contrato_pdf' => ['type' => 'include', 'target' => 'modules/clientes/contrato_pdf.php'],
    'boleto_pdf' => ['type' => 'include', 'target' => 'modules/cobranca/boleto_pdf.php'],
    'certificados' => ['type' => 'include', 'target' => 'modules/clientes/certificados.php'],
    'modulos' => ['type' => 'include', 'target' => 'modules/cobranca/modulos.php'],
    // A TELA SE CHAMA "Formas de recebimento" no menu, e a URL passa a dizer o
    // mesmo. O endereco antigo vira REDIRECT em vez de sumir: ele esta em
    // favorito de membro e em link de tela antiga, e rota que some vira 404
    // sem explicacao nenhuma.
    'formas_recebimento' => ['type' => 'include', 'target' => 'modules/cobranca/contas.php'],
    'contas_recebimento' => ['type' => 'redirect', 'target' => 'formas_recebimento.php'],
    // A volta do OAuth do Conta Azul (16/09/2026): e o redirect_uri cadastrado
    // no portal deles, entao o nome NAO muda -- mudar e desconectar todo membro.
    'contaazul_retorno' => ['type' => 'include', 'target' => 'modules/cobranca/contaazul_retorno.php'],

    // gateway, edit_gateway, gateway_asas, gateways_pagseguro e pagar_gateway
    // sairam em 10/09/2026 com o motor antigo de cobranca. Contas e formas de
    // recebimento moram em `formas_recebimento`; o cliente paga pela area dele.
    'pagseguro_webhook' => ['type' => 'include', 'target' => 'public/webhooks/pagseguro_webhook.php'],
    'efi_webhook' => ['type' => 'include', 'target' => 'public/webhooks/efi_webhook.php'],
    'cora_webhook' => ['type' => 'include', 'target' => 'public/webhooks/cora_webhook.php'],

    'perfil' => ['type' => 'include', 'target' => 'modules/usuarios/perfil.php'],
    'editar_perfil' => ['type' => 'include', 'target' => 'modules/usuarios/editar_perfil.php'],
    'area_cliente' => ['type' => 'include', 'target' => 'modules/usuarios/area_cliente.php'],
    // O CADASTRO DE CLIENTE PELO LOGIN SAIU em 14/09/2026 (as duas telas estao no
    // _remover.txt). A conta que ele criava (acesso '3') caia na area do cliente,
    // que desde 10/09/2026 so abre com o e-mail e a senha da LOJA: nao abria nada.
    // `register` vira redirect para essa porta, pelo mesmo motivo de
    // contas_recebimento: endereco em favorito nao pode virar 404 mudo.
    // `vincular_cnpj` some: exigia login e nenhuma tela linkava para ela.
    'register' => ['type' => 'redirect', 'target' => 'area_cliente.php'],
    // Publicas, como o login: quem chega aqui esta do lado de fora.
    'esqueci_senha' => ['type' => 'include', 'target' => 'modules/usuarios/esqueci_senha.php'],
    'redefinir_senha' => ['type' => 'include', 'target' => 'modules/usuarios/redefinir_senha.php'],

];
