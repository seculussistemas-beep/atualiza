<?php

function shield_resolve_route_name()
{
    $route = trim((string) ($_GET['r'] ?? ''));
    if ($route !== '') {
        return preg_replace('/[^a-zA-Z0-9_-]/', '', $route);
    }

    $requestUri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
    $path = trim((string) parse_url($requestUri, PHP_URL_PATH), '/');
    if ($path === '') {
        return 'index';
    }

    $basename = basename($path);
    if (str_ends_with($basename, '.php')) {
        $basename = substr($basename, 0, -4);
    }

    $basename = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $basename);
    return $basename !== '' ? $basename : 'index';
}

function shield_dispatch_request()
{
    $routes = require __DIR__ . '/routes.php';
    $routeName = shield_resolve_route_name();
    if ($routeName === '') {
        $routeName = 'index';
    }

    if (!isset($routes[$routeName])) {
        http_response_code(404);
        header('Content-Type: text/html; charset=utf-8');
        echo '<h1>404 - Rota nao encontrada</h1>';
        exit;
    }

    $route = $routes[$routeName];
    if (!is_array($route) || !isset($route['type'], $route['target'])) {
        http_response_code(500);
        echo 'Rota invalida.';
        exit;
    }

    if ($route['type'] === 'redirect') {
        header('Location: ' . (string) $route['target']);
        exit;
    }

    if ($route['type'] !== 'include') {
        http_response_code(500);
        echo 'Tipo de rota nao suportado.';
        exit;
    }

    $baseDir = dirname(__DIR__);
    $target = $baseDir . '/' . ltrim((string) $route['target'], '/');
    if (!is_file($target)) {
        http_response_code(500);
        echo 'Arquivo da rota nao encontrado.';
        exit;
    }

    $virtualScript = '/' . $routeName . '.php';
    $_SERVER['SHIELD_ROUTE'] = $routeName;
    $_SERVER['SCRIPT_NAME'] = $virtualScript;
    $_SERVER['PHP_SELF'] = $virtualScript;
    $_GET['r'] = $routeName;

    shield_csrf_guardar_rota($routeName);
    shield_faxina_de_restos($routeName);

    require $target;
    exit;
}

/**
 * O CSRF entra AQUI, e nao em cada tela -- 04/09/2026.
 *
 * O router e o unico ponto por onde toda rota passa. Poe a validacao aqui e
 * ela nao pode ser esquecida numa tela nova; poe em 26 arquivos e a proxima
 * tela nasce sem ela. Ver ALTO-3 em docs/auditoria-seguranca.md.
 *
 * ROTAS DE MAQUINA FICAM DE FORA, e nao por comodidade: os webhooks sao
 * chamados pelo gateway de pagamento, que nao tem sessao no painel e nao tem
 * como mandar token nenhum. Exigir CSRF ali nao aumentaria seguranca -- ela ja
 * vem da reconsulta autenticada a API do gateway (CRIT-1/ALTO-1) -- e pararia
 * de confirmar pagamento de verdade.
 */
function shield_csrf_guardar_rota(string $routeName): void
{
    if (in_array($routeName, shield_rotas_de_maquina(), true)) {
        return;
    }

    require_once dirname(__DIR__) . '/funcoes/nucleo/csrf.php';

    // A recusa e o filtro de saida moram em shield_csrf_proteger(), porque as
    // telas de install/ e update/ precisam do mesmo comportamento e NAO passam
    // por aqui -- sao pasta servida pelo .htaccess. Duas copias da mesma regra
    // divergiriam na primeira vez que alguem ajustasse uma delas.
    shield_csrf_proteger();
}

/**
 * As rotas que um PROGRAMA chama, e nao uma pessoa.
 *
 * Sao os webhooks: o gateway de pagamento nao tem sessao no painel, nao manda
 * token de CSRF e nao espera. A lista mora aqui, e nao repetida em cada guarda,
 * porque duas copias divergem na primeira vez que alguem acrescentar um
 * provedor -- e a que ficar para tras vira, no melhor caso, pagamento que para
 * de confirmar.
 *
 * @return string[]
 */
function shield_rotas_de_maquina(): array
{
    return ['pagseguro_webhook', 'efi_webhook', 'cora_webhook'];
}

/**
 * A faxina dos restos da troca, no unico ponto por onde toda TELA passa.
 *
 * Ate 08/09/2026 ela dependia de alguem recarregar a tela de atualizacao, e
 * quem nao voltasse la ficava com os `.old` no disco por tempo indeterminado --
 * codigo-fonte que o Apache entrega como texto se o .htaccess se perder num
 * refactor, que ja aconteceu uma vez.
 *
 * CUSTA UM is_file() quando nao ha nada a fazer: a varredura da arvore so
 * roda na primeira requisicao depois de uma troca, e a marca sai em seguida.
 * Ver funcoes/atualizacao/restos.php.
 *
 * FORA DO CAMINHO DE QUEM E PROGRAMA, e isso e a parte que importa: os
 * webhooks ficam de fora pela mesma razao do CSRF, e a API de licenca nem
 * passa por aqui -- e arquivo em public/api/. Uma varredura recursiva dentro da
 * requisicao do ERP atrasaria a batida de licenca da loja, e o preco de uma
 * faxina nao pode ser cobrado de quem so quer saber se pode abrir o caixa.
 */
function shield_faxina_de_restos(string $routeName): void
{
    if (in_array($routeName, shield_rotas_de_maquina(), true)) {
        return;
    }

    require_once dirname(__DIR__) . '/funcoes/atualizacao/restos.php';
    shield_atu_limpar_pendentes();
}
