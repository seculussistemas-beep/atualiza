<?php

/**
 * O PAINEL NAO DEPENDE DE vendor/ PARA SUBIR, e isso e uma escolha -- 03/09/2026.
 *
 * Chegou a depender por um dia: o carregador do Composer entrava aqui, e os
 * dois require abaixo tinham saido. Foi revertido depois de olhar o que o
 * Composer de fato entrega a este painel em tempo de execucao, que e NADA --
 * nao ha um unico `use` de pacote externo em 28 mil linhas, e o SMTP e escrito
 * a mao. O unico produto dele aqui seria o autoloader, e o painel ja tem um,
 * em funcoes/nucleo/autoload.php: quinze linhas, escritas assim de proposito porque
 * o membro sobe por FTP e nao roda `composer dump-autoload` do outro lado.
 *
 * A troca teria custado uma dependencia nova em toda instalacao em campo --
 * sem script de release que garanta o vendor/ no pacote, e com um atualizador
 * que nao remove arquivo que saiu -- para ganhar um carregador equivalente ao
 * que ja existia.
 *
 * QUANDO ISSO MUDA: no dia em que entrar uma dependencia que o painel USE de
 * verdade. Ai o vendor/ e obrigatorio de qualquer jeito, e a ordem correta e
 * escrever o script de release primeiro.
 */
require_once __DIR__ . '/funcoes/nucleo/carregar.php';
require_once __DIR__ . '/funcoes/nucleo/system_bootstrap.php';

shield_enforce_installation_guard();

$dbConfig = shield_load_database_config();
if (!shield_is_database_configured($dbConfig)) {
    shield_redirect('/install/?error=db_config');
}

try {
    $pdo = shield_create_pdo_connection($dbConfig);
} catch (Throwable $exception) {
    // O DETALHE NAO VAI NO CORPO (16/09/2026). O public/api/licenca.php abre
    // ob_start() ANTES deste require, e os webhooks passam pelo mesmo caminho:
    // o texto do die cai dentro do buffer, o exit acontece antes de a rota
    // limpar qualquer coisa e o PHP o descarrega no fim. O ERP da loja, que
    // espera JSON, receberia "Access denied for user 'fulano'@'host'" -- o
    // usuario e o host do banco do membro entregues a quem so pediu licenca.
    error_log('[banco] ' . $exception->getMessage());
    if (shield_guard_servico_json(shield_current_request_path())) {
        // A mesma resposta do porteiro: 503 com JSON, que o gateway e o ERP
        // entendem como "tente de novo depois".
        shield_guard_parar(true, '', 'banco_fora');
    }

    // Na tela quem le e o membro, e ele precisa do motivo para consertar a
    // conexao; a dica diz onde se mexe quando o caso e TLS.
    $dica = shield_banco_dica_conexao($exception, $dbConfig);
    die('Erro ao conectar ao banco de dados (PDO): ' . $exception->getMessage() . ($dica !== '' ? ' -- ' . $dica : ''));
}

// O $conexao (mysqli) SAIU EM 17/09/2026. Era compatibilidade com paginas antigas
// e nada no codigo o usava: so abria uma segunda conexao por requisicao --
// inclusive em cada consulta de licenca do ERP -- e em 15/09 derrubou a API no
// MySQL 8.4 com TLS ligado. Pagina propria de membro que ainda o use precisa
// passar para o $pdo.
