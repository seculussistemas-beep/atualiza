<?php
/**
 * O casco do painel - 25/08/2026.
 *
 * Substituiu o tema SB Admin 2 inteiro. Bootstrap 5 e nada de jQuery: o menu
 * que se abre, o tema escuro e a gaveta do celular sao vinte linhas de
 * JavaScript comum, e o painel deixou de carregar 3 MB para desenhar uma barra
 * lateral.
 *
 * A COR E A DO MEMBRO, lida do cadastro dele e escrita em duas variaveis de
 * CSS. Ele revende com a identidade dele e o cliente final ve o nome dele --
 * nao o nosso. Nenhuma cor da LojaDev aparece aqui.
 *
 * O ITEM DA PAGINA ATUAL GANHA UMA BARRA, e nao so um fundo diferente: fundo
 * some em monitor mal calibrado e em impressao, barra nao.
 *
 * Cada tela inclui este arquivo no comeco e o templates/fecha.php no fim.
 */

if (session_status() === PHP_SESSION_NONE) {
    require_once __DIR__ . '/../funcoes/nucleo/sessao.php'; shield_sessao_abrir();
}

$nomeUsuario = (string) ($_SESSION['usuario']['nome'] ?? 'Usuario');
$emailUsuario = trim((string) ($_SESSION['usuario']['email'] ?? ''));
$acessoUsuario = (string) ($_SESSION['usuario']['acesso'] ?? '');
$isAdmin = $acessoUsuario === '1';

// O relogio oportunista: a cada abertura de tela do administrador, no maximo
// uma vez a cada cinco minutos, um lote pequeno do que o cron.php faz
// (verificar webhooks, conciliar, marcar vencidas, gerar o ciclo). E o que
// faz o pagamento aparecer sozinho em quem nunca configurou o agendador.
if ($isAdmin && isset($pdo) && $pdo instanceof PDO) {
    try {
        require_once __DIR__ . '/../funcoes/cobranca/relogio.php';
        shield_relogio_oportunista($pdo);
    } catch (Throwable $ignorado) {
        // Tela abre de qualquer jeito.
    }
}

// A marca do membro. Falhando a leitura, fica o azul de fabrica -- o casco nao
// pode deixar de desenhar por causa de um cadastro incompleto.
$marca = array('nome' => 'Painel', 'cor' => SHIELD_MARCA_COR_PADRAO);
try {
    if (isset($pdo) && $pdo instanceof PDO) {
        $s = $pdo->query('SELECT fantasia, razao FROM softhouse LIMIT 1')->fetch(PDO::FETCH_ASSOC);
        $nome = trim((string) ($s['fantasia'] ?? ''));
        if ($nome === '') {
            $nome = trim((string) ($s['razao'] ?? ''));
        }
        if ($nome !== '') {
            $marca['nome'] = $nome;
        }

        if (function_exists('shield_get_system_meta')) {
            $cor = trim((string) shield_get_system_meta($pdo, 'marca_cor', ''));
            if (preg_match('/^#[0-9a-fA-F]{6}$/', $cor)) {
                $marca['cor'] = $cor;
            }
        }
    }
} catch (Throwable $ignorado) {
    // fica o padrao
}

// A segunda e a terceira cor saem da primeira. Pedir tres ao membro so criaria
// tres jeitos de ele escolher um trio que nao combina.
//
// A ESCURA desce rumo ao preto e e o :hover em fundo claro.
// A CLARA sobe rumo ao branco e e quem ESCREVE no tema escuro -- link e
// .text-primary. Ate agora nao existia, e o escuro reaproveitava a cor de
// preencher: dava 3,30:1, ja reprovado, e ninguem via porque nao da erro.
//
// O fator de subida e .55, e nao .45, por causa do PIOR CASO: membro que
// escolhe #000000. Com .45 o resultado da 3,67:1 e reprova; com .55 da #8c8c8c,
// 5,18:1. Vermelho, verde e roxo passam folgado nos dois.
//
// O TRIO DE FABRICA e fixado a mao, e nao derivado, porque nao existe fator
// uniforme que leve #00697f a #02c8f0 -- o vermelho pediria .008, o verde .633
// e o azul .883. Derivar so vale para a cor que o membro escolheu.
$corEscura = '#004d5d';
$corClara = '#02c8f0';
if (strcasecmp((string) $marca['cor'], SHIELD_MARCA_COR_PADRAO) !== 0
    && preg_match('/^#([0-9a-fA-F]{6})$/', (string) $marca['cor'], $m)) {
    $rgb = array_map('hexdec', str_split($m[1], 2));
    $corEscura = sprintf('#%02x%02x%02x', (int) ($rgb[0] * .74),
                         (int) ($rgb[1] * .74), (int) ($rgb[2] * .74));
    $corClara = sprintf('#%02x%02x%02x',
                        (int) ($rgb[0] + (255 - $rgb[0]) * .55),
                        (int) ($rgb[1] + (255 - $rgb[1]) * .55),
                        (int) ($rgb[2] + (255 - $rgb[2]) * .55));
}

$rotaAtual = strtolower((string) ($_GET['r']
    ?? basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''), '.php')));
// Este arquivo e incluido de DENTRO de shield_dispatch_request(), entao
// $rotaAtual e variavel local daquela funcao -- e o `global` la em
// shield_item() enxergava null: nenhum item ficava marcado como atual.
// Guardar em $GLOBALS explicitamente resolve nos dois casos (03/09/2026).
$GLOBALS['shield_rota_atual'] = $rotaAtual;

// O contexto tambem aparece na lateral: a pessoa nao precisa decorar de que
// cliente saiu quando troca de Terminais para Cobrancas ou Logs. A ficha usa
// `id`; as telas operacionais usam `empresa` (com `fk_empresa` legado aceito).
$clienteEmFoco = null;
try {
    $empresaEmFoco = function_exists('shield_empresa_contexto_id')
        ? shield_empresa_contexto_id($_GET)
        : null;
    if ($empresaEmFoco === null && $rotaAtual === 'ver_empresa'
        && isset($_GET['id']) && filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
        $empresaEmFoco = (int) $_GET['id'];
    }
} catch (Throwable $ignorado) {
    $empresaEmFoco = null;
}

// DENTRO DE UM CLIENTE, A LATERAL MARCA "CLIENTES" E SO ELE -- 10/09/2026,
// tarde. Andando entre visao geral, terminais, monitoramento, logs, cobrancas
// e cadastro do mesmo cliente, o item marcado pulava a cada tela, e o dono do
// produto se perdia. Sem cliente em foco, cada tela marca o proprio item.
$rotasDentroDoCliente = array('ver_empresa', 'editar_empresa', 'terminais', 'parque', 'logs_cliente',
                              'mudanca_contrato', 'cobrancas', 'assinaturas');
$GLOBALS['shield_rota_marcada'] = ($empresaEmFoco !== null && in_array($rotaAtual, $rotasDentroDoCliente, true))
    ? 'clientes'
    : $rotaAtual;

/** As duas letras mantem a marca reconhecivel quando a lateral esta recolhida. */
if (!function_exists('shield_marca_iniciais')) {
    function shield_marca_iniciais($nome)
    {
        $palavras = preg_split('/\s+/', trim((string) $nome)) ?: array();
        $iniciais = '';
        foreach ($palavras as $palavra) {
            if ($palavra !== '') {
                $iniciais .= strtoupper(substr($palavra, 0, 1));
            }
            if (strlen($iniciais) >= 2) {
                break;
            }
        }

        if (count($palavras) === 1 && strlen($iniciais) === 1) {
            $iniciais = strtoupper(substr((string) $palavras[0], 0, 2));
        }

        return $iniciais !== '' ? $iniciais : 'PS';
    }
}


// O estado do parque no topo: caixas dando sinal / total. E a unica conta
// que vale olhar a toda hora, e o topo e o unico lugar visivel em toda tela.
$parqueTopo = null;
if ($isAdmin && isset($pdo) && $pdo instanceof PDO) {
    try {
        require_once __DIR__ . '/../funcoes/licenca/parque.php';
        if (function_exists('shield_parque_resumo')) {
            $parqueTopo = shield_parque_resumo($pdo);
        }
    } catch (Throwable $ignorado) {
        $parqueTopo = null;
    }
}

// OS GRUPOS, OS ITENS E OS BADGES VEM DE funcoes/ui/lateral.php -- 10/09/2026,
// fatia 0 da reorganizacao. Aqui so se desenha. O badge conta o MESMO recorte
// para onde o clique leva (shield_lateral_destino); antes o numero dizia "5
// vencidas" e o clique caia na lista inteira.
require_once __DIR__ . '/../funcoes/ui/lateral.php';
require_once __DIR__ . '/../funcoes/ui/tarefas.php'; // o que a busca do topo acha alem de cliente e terminal
// O aviso que flutua: a tela registra depois de incluir este arquivo, e o
// templates/fecha.php desenha fora do .corpo.
require_once __DIR__ . '/../funcoes/ui/aviso.php';
$alertasMenu = array('avaliacao' => 0, 'clientes' => 0, 'cobrancas' => 0);
if ($isAdmin && isset($pdo) && $pdo instanceof PDO) {
    $alertasMenu = shield_lateral_contagens($pdo);
}

// Conta de gateway em ambiente de teste. Sinalizada em TODA tela, e nao so na
// dela: descobrir depois que a cobranca do cliente foi para o sandbox e caro.
// DUAS PERGUNTAS, e nao uma (08/09/2026). "Ha conta em homologacao?" e aviso
// ambar: alguem ligou o sandbox e pode ter esquecido. "Ha cliente com cobranca
// EM ABERTO por conta de teste?" e alerta vermelho: tem dinheiro que nao vai
// cair, e o cliente acha que pagou. A segunda so se pergunta se a primeira deu
// sim -- sem conta de teste nao ha o que cruzar. O hover do chip lista as duas
// respostas, para nao ser preciso abrir tela nenhuma para saber quem.
$emTeste = '';
$contasTeste = array();
$clientesHomolog = array();
try {
    if (isset($pdo) && $pdo instanceof PDO) {
        $stmt = $pdo->query(
            "SELECT apelido FROM conta_recebimento WHERE ativo = 1 AND ambiente = 'teste' ORDER BY apelido"
        );
        $contasTeste = array_values(array_filter(array_map('strval', $stmt->fetchAll(PDO::FETCH_COLUMN) ?: array())));
        $emTeste = (string) ($contasTeste[0] ?? '');
        if ($contasTeste !== array()) {
            // A ULTIMA tentativa de cada cobranca decide por qual conta ela saiu --
            // a mesma subconsulta da lista de cobrancas, para os dois concordarem.
            $stmt = $pdo->query(
                "SELECT DISTINCT e.razao
                   FROM cobranca c
                   JOIN empresa e ON e.codigo = c.fk_empresa
                   JOIN cobranca_tentativa t
                     ON t.id = (SELECT x.id FROM cobranca_tentativa x
                                 WHERE x.fk_cobranca = c.id ORDER BY x.id DESC LIMIT 1)
                   JOIN conta_recebimento co ON co.id = t.fk_conta
                  WHERE co.ambiente = 'teste' AND c.situacao IN ('aberta', 'vencida')
                  ORDER BY e.razao LIMIT 30"
            );
            $clientesHomolog = array_values(array_filter(array_map('strval', $stmt->fetchAll(PDO::FETCH_COLUMN) ?: array())));
        }
    }
} catch (Throwable $ignorado) {
    $emTeste = '';
    $contasTeste = array();
    $clientesHomolog = array();
}

if (!function_exists('shield_grupo_abrir')) {
    /**
     * Um grupo da lateral que abre e fecha -- 03/09/2026. Abre sozinho quando
     * a tela atual esta dentro dele; os outros lembram o que a pessoa deixou
     * (localStorage, em templates/fecha.php). Recolhida, a lateral ignora o
     * fechado e mostra so os icones.
     */
    function shield_grupo_abrir($chave, $icone, $rotulo, array $rotas)
    {
        $atual = (string) ($GLOBALS['shield_rota_atual'] ?? '');
        // Todos os grupos comecam abertos. O que a pessoa fechar depois fica
        // lembrado no navegador (fecha.php).
        $contemAtual = in_array($atual, $rotas, true);
        $aberto = true;
        printf(
            '<section class="grupo-acc%s" data-grupo="%s"%s>'
            . '<button class="grupo-trigger" type="button" aria-expanded="%s" aria-controls="grupo-%s">'
            . '<span class="grupo-nome">%s</span>'
            . '<svg class="grupo-seta" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>'
            . '</button><div class="grupo-itens" id="grupo-%s"><div class="grupo-lista">',
            $aberto ? ' aberto' : '',
            htmlspecialchars((string) $chave, ENT_QUOTES, 'UTF-8'),
            $contemAtual ? ' data-atual="1"' : '',
            $aberto ? 'true' : 'false',
            htmlspecialchars((string) $chave, ENT_QUOTES, 'UTF-8'),
            $rotulo,
            htmlspecialchars((string) $chave, ENT_QUOTES, 'UTF-8')
        );
    }

    function shield_grupo_fechar()
    {
        echo '</div></div></section>';
    }
}

/* Uma LEGENDA dentro do grupo. Nao abre, nao fecha, nao guarda estado: ela
 * some e volta junto com o grupo em que mora.
 *
 * Existe porque "Cobranca" junta dois ritmos: o que se olha todo dia
 * (cobrancas, assinaturas, regua) e o que se ajusta uma vez por ano (planos,
 * formas de recebimento). Sem a divisao os cinco itens tem o mesmo peso, e a
 * pessoa varre a lista inteira toda vez para achar os dois que usa.
 *
 * Ja foi subgrupo com gatilho proprio, aninhando um `.grupo-acc` dentro de
 * outro. Dois gatilhos empilhados, cada um com a sua seta e a sua memoria, no
 * mesmo bloco -- e a lateral virou a pergunta "qual dos dois fechou o que?".
 * Recolher os ajustes junto com Cobranca e o suficiente: quem nao quer ve-los
 * fecha o grupo, que ja e o gesto que todo mundo conhece. */
if (!function_exists('shield_legenda')) {
    function shield_legenda($texto)
    {
        printf(
            '<span class="menu-legenda" aria-hidden="true">%s</span>',
            htmlspecialchars(html_entity_decode((string) $texto, ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'UTF-8')
        );
    }
}

if (!function_exists('shield_item')) {
    /** Um item de navegacao, com estado atual e badge opcional de atencao. */
    function shield_item($rota, $icone, $texto, $badge = 0, $url = null, $tipoBadge = '')
    {
        $atual = (string) ($GLOBALS['shield_rota_marcada'] ?? $GLOBALS['shield_rota_atual'] ?? '') === (string) $rota;
        $rotulo = html_entity_decode((string) $texto, ENT_QUOTES, 'UTF-8');
        $url = $url === null ? '/' . (string) $rota . '.php' : (string) $url;
        // O PEDIDO DE PRAZO DIZ O QUE E (01/10/2026): o numero no lugar do de
        // Cobrancas precisa se distinguir dele, na cor e na frase lida em voz.
        $prazo = (string) $tipoBadge === 'prazo';
        if ($prazo && (int) $badge > 0) {
            $rotulo .= ' -- ' . (int) $badge . ' pedido(s) de prazo esperando resposta';
        }
        printf(
            '<a class="menu-item%s" href="%s" title="%s"%s>'
            . '<span class="menu-icone"><i class="fas fa-fw %s"></i></span>'
            . '<span class="menu-texto">%s</span>%s</a>',
            $atual ? ' aqui' : '',
            htmlspecialchars($url, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($rotulo, ENT_QUOTES, 'UTF-8'),
            $atual ? ' aria-current="page"' : '',
            htmlspecialchars((string) $icone, ENT_QUOTES, 'UTF-8'),
            $texto,
            (int) $badge > 0
                ? ($prazo
                    ? '<span class="menu-badge prazo" aria-label="' . (int) $badge . ' pedido(s) de prazo">' . (int) $badge . '</span>'
                    : '<span class="menu-badge" aria-label="' . (int) $badge . ' pendencia(s)">' . (int) $badge . '</span>')
                : ''
        );
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars((string) $marca['nome'], ENT_QUOTES, 'UTF-8'); ?></title>

  <!-- AdminLTE 4 ja incorpora Bootstrap 5.3; vem local para o painel abrir
       tambem no servidor do membro, sem depender de CDN. -->
  <link rel="stylesheet" href="/vendor/adminlte/css/adminlte.min.css?v=4.8.4">
  <link rel="stylesheet" href="/css/icones.css?v=<?= (int) @filemtime(__DIR__ . '/../public/css/icones.css'); ?>">
  <?php /* A data do arquivo como cache-bust: CSS editado sem trocar o rotulo ficava preso no navegador. */ ?>
  <link rel="stylesheet" href="/css/painel.css?v=<?= (int) @filemtime(__DIR__ . '/../public/css/painel.css'); ?>">
  <link rel="stylesheet" href="/css/senha.css?v=<?= (int) @filemtime(__DIR__ . '/../public/css/senha.css'); ?>">
  <?php /* No head, e nao junto do aviso: e o que faz ele nascer fixo no canto no primeiro quadro. */ ?>
  <link rel="stylesheet" href="/css/aviso.css?v=<?= (int) @filemtime(__DIR__ . '/../public/css/aviso.css'); ?>">
  <link rel="icon" href="/favicon.ico?v=<?= (int) @filemtime(__DIR__ . '/../public/favicon.ico'); ?>" sizes="16x16 32x32 48x48">
  <link rel="icon" type="image/png" sizes="512x512" href="/img/favicon-512.png?v=<?= (int) @filemtime(__DIR__ . '/../public/img/favicon-512.png'); ?>">
  <link rel="apple-touch-icon" sizes="180x180" href="/img/favicon-180.png?v=<?= (int) @filemtime(__DIR__ . '/../public/img/favicon-180.png'); ?>">
  <?php if (!empty($GLOBALS['shield_sem_transicao'])): ?>
    <?php /* A tela chega com um modal ja aberto. Com a transicao entre
             documentos, a lateral e o topo (que tem nome proprio de transicao)
             ficam por cima do fundo escuro ate a animacao acabar -- e o que
             se ve e a lateral branca por um instante. Sem transicao, nao. */ ?>
    <style>@view-transition { navigation: none; }</style>
  <?php endif; ?>
  <style>
    :root {
      --marca: <?= htmlspecialchars((string) $marca['cor'], ENT_QUOTES, 'UTF-8'); ?>;
      --marca-escura: <?= htmlspecialchars($corEscura, ENT_QUOTES, 'UTF-8'); ?>;
      /* Quem USA esta no painel.css, em :root[data-bs-theme="dark"] -- e o
         seletor precisa daquele :root para vencer este bloco, que vem depois
         da folha e teria a mesma especificidade sem ele. */
      --marca-clara: <?= htmlspecialchars($corClara, ENT_QUOTES, 'UTF-8'); ?>;
    }
  </style>
  <script>
    // O tema vai ANTES de o corpo pintar: aplicar depois faz a tela piscar
    // branca a cada navegacao, e quem trabalha no escuro sente isso o dia todo.
    (function () {
      try {
        var t = localStorage.getItem('painel_tema');
        // ?tema=light|dark na URL forca e grava: serve para link de suporte e
        // para fotografar o painel num tema certo sem mexer no navegador.
        var q = new URLSearchParams(location.search).get('tema');
        if (q === 'light' || q === 'dark') { t = q; localStorage.setItem('painel_tema', q); }
        if (!t) {
          t = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        }
        document.documentElement.setAttribute('data-bs-theme', t);
        // A chave ?casco= que escolheu entre as duas regras de "onde o preto
        // mora" (08/09/2026) ja cumpriu o papel e saiu. Sobrou o que ela deixou
        // gravado: limpar, para o navegador de quem testou nao guardar lixo.
        try { localStorage.removeItem('painel_casco'); } catch (e) {}
        if (localStorage.getItem('painel_sidebar_compacta') === '1') {
          document.documentElement.setAttribute('data-sidebar', 'compacta');
        }
      } catch (e) {}
    })();
  </script>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">

<div class="app-wrapper painel">
  <aside class="app-sidebar lateral" id="lateral" aria-label="Navegacao principal">
    <div class="sidebar-cabeca">
      <a class="marca-painel" href="/index.php" aria-label="Ir para o inicio">
        <?php /* UMA imagem, nos dois temas. Eram duas, cada uma com um
                 mix-blend-mode, por causa de uma premissa que a decodificacao
                 dos arquivos derrubou: os dois PNG sao transparentes, nao ha
                 fundo branco nem preto para esconder. Ver public/css/painel.css,
                 no bloco .marca-escudo. O arquivo e o antigo logo.png inteiro
                 (o original fica no historico do git), com a palavra SHIELD,
                 so que 18x mais leve. */ ?>
        <img class="marca-escudo" src="/img/escudo-256.png?v=<?= (int) @filemtime(__DIR__ . '/../public/img/escudo-256.png'); ?>" alt="" aria-hidden="true">
        <span class="marca-texto">
          <strong><?= htmlspecialchars((string) $marca['nome'], ENT_QUOTES, 'UTF-8'); ?></strong>
          <small><?= $isAdmin ? 'Central de Opera&ccedil;&atilde;o' : 'Portal do cliente'; ?></small>
        </span>
      </a>
      <button class="sidebar-acao sidebar-fechar" type="button" id="btGaveta"
              aria-label="Fechar menu" aria-expanded="false">
        <i class="fas fa-times"></i>
      </button>
    </div>

    <?php /* "Cliente: X" saiu da lateral em 10/09/2026: a trilha da tela ja diz
             de quem se fala, e a lateral agora marca "Clientes" enquanto se
             anda dentro dele. */ ?>

    <div class="itens">
      <?php if ($isAdmin): ?>
        <?php /* Quatro grupos, na ordem do dia de quem opera (03/09/2026):
                 o que se olha sempre, quem paga, como se cobra, o que se
                 configura uma vez. "Licencas vencidas" era um item que so
                 filtrava a tela de Clientes; virou o contador dela. */ ?>
        <?php /* INICIO E ITEM SOLTO, sem grupo em volta -- 08/09/2026.
                 Ele era um grupo "Operacao" com um item so dentro, chamado
                 "Central de operacao": a mesma palavra duas vezes, uma embaixo
                 da outra, gastando duas linhas e um gatilho de abrir/fechar
                 para chegar a um unico link. Grupo de um item e cabecalho sem
                 lista. Agora e o que ele sempre foi: o painel, no topo, a um
                 clique. A "Central de Operacao" segue nomeando o painel inteiro
                 no subtitulo ao lado do escudo, que e onde ela faz sentido. */ ?>
        <?php shield_item('index', 'fa-tachometer-alt', 'Dashboard'); ?>

        <?php /* A ORDEM DOS ITENS E POR FREQUENCIA (o que se olha todo dia
                 primeiro; "Ajusta uma vez" separa o que se visita uma vez por
                 ano), e a lista inteira -- grupos, itens, rotas de cada grupo,
                 badges -- mora em funcoes/ui/lateral.php, onde tem teste contra
                 o roteador. "Minha empresa" mora no menu da conta, no topo. */ ?>
        <?php foreach (shield_lateral_grupos() as $chaveGrupo => $grupoLateral): ?>
            <?php shield_grupo_abrir($chaveGrupo, $grupoLateral['icone'], $grupoLateral['rotulo'], $grupoLateral['rotas']); ?>
            <?php foreach ($grupoLateral['itens'] as $itemLateral): ?>
                <?php if (!empty($itemLateral['legenda'])) { shield_legenda($itemLateral['legenda']); } ?>
                <?php
                list($badgeLateral, $destinoLateral, $tipoLateral) = shield_lateral_badge_do_item($itemLateral, $alertasMenu);
                shield_item(
                    $itemLateral['rota'],
                    $itemLateral['icone'],
                    $itemLateral['texto'],
                    $badgeLateral,
                    $destinoLateral,
                    $tipoLateral
                );
                ?>
            <?php endforeach; ?>
            <?php shield_grupo_fechar(); ?>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="grupo">Minha conta</div>
        <?php shield_item('area_cliente', 'fa-user', 'Minha conta'); ?>
      <?php endif; ?>
    </div>

    <?php /* UM rodape so. Este ja existia, com borda em cima; o botao do tutorial
             chegou dentro de um segundo <div class="sidebar-rodape"> aninhado, e
             as duas bordas viraram duas linhas na tela. */ ?>
    <div class="sidebar-rodape">
      <?php /* Recolher fica aqui embaixo, acima de Sair: longe do escudo e no
               mesmo lugar nos dois estados. */ ?>
      <?php /* "Sair" mora so no menu da conta, no topo. Aqui fica o recolher. */ ?>
      <?php /* Recolher primeiro, "?" por ultimo -- e nessa ordem no MARKUP, e nao
               so no CSS: ordem no documento e ordem de tabulacao, e quem chega
               pelo teclado alcanca antes o que se usa todo dia. O "?" e ajuda,
               nao destino: fica na ponta, fora do caminho. */ ?>
      <button class="sair-lateral sidebar-recolher" type="button" id="btRecolher"
              aria-label="Recolher menu" title="Recolher menu" aria-pressed="false">
        <i class="fas fa-arrow-left"></i><span>Recolher menu</span>
      </button>
      <button class="tutorial-bt" type="button" id="btTutorial"
              aria-label="Tutorial das telas" title="Tutorial das telas: um passeio guiado por cada tela do painel">?</button>
    </div>
  </aside>
  <div class="mascara-lateral" id="mascaraLateral" aria-hidden="true"></div>

  <?php /* SEM `bg-body`, de proposito (08/09/2026). A classe do Bootstrap pinta
           com `--bs-body-bg-rgb` e `!important` -- uma tripla RGB propria que
           NAO acompanha o `--fundo` do painel e que nenhuma regra da folha
           consegue vencer. Com ela, a barra ficava branca em todo tema e em
           toda variante de casco, por mais que `.topo` mandasse outra coisa.
           Quem pinta a barra e `.topo`, em painel.css. */ ?>
  <header class="app-header navbar navbar-expand topo">
    <div class="container-fluid px-3">
      <ul class="navbar-nav d-lg-none">
        <li class="nav-item">
          <button class="nav-link border-0 bg-transparent" type="button" id="btGaveta2"
                  aria-label="Abrir o menu" aria-expanded="false"><i class="fas fa-bars"></i></button>
        </li>
      </ul>
      <?php if ($isAdmin): ?>
      <div class="topo-esquerda">
        <?php /* A busca (Ctrl+K) abre a paleta que fica no fim do corpo. */ ?>
        <button class="busca-topo" type="button" id="btBusca" aria-label="Buscar cliente, terminal ou tarefa" aria-haspopup="dialog">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
          <span class="busca-topo-texto">Buscar cliente, terminal ou tarefa</span>
          <kbd>Ctrl K</kbd>
        </button>
        <?php if ($parqueTopo !== null): ?>
          <?php
            $pt = (int) $parqueTopo['terminais'];
            $pv = (int) $parqueTopo['vivos'];
            // NAO usar "vazio": a classe ja existe para o estado vazio dos
            // cartoes, com padding grande -- o chip virava uma bolha.
            $estadoParque = $pt === 0 ? 'chip-sem-parque' : ($pv < $pt ? 'alerta' : 'ok');
            $tituloParque = $pt === 0
                ? 'Nenhum terminal registrado ainda'
                : ($pv < $pt ? ($pt - $pv) . ' caixa(s) sem sinal ha mais de ' . (int) SHIELD_PARQUE_DIAS_SUMIDO . ' dias' : 'Todo o parque respondendo');
          ?>
          <a class="parque-chip <?= $estadoParque; ?>" href="/parque.php" title="<?= htmlspecialchars($tituloParque, ENT_QUOTES, 'UTF-8'); ?>">
            <span class="parque-ponto" aria-hidden="true"></span>
            <?php if ($pt === 0): ?>
              <span>Parque vazio</span>
            <?php else: ?>
              <strong><?= $pv; ?></strong><span class="parque-de">/<?= $pt; ?></span><span class="parque-rotulo">caixas no ar</span>
            <?php endif; ?>
          </a>
        <?php endif; ?>
        <?php if ($contasTeste !== array()): ?>
          <?php
            /* Ambar: ha conta em homologacao. VERMELHO: ha cliente com cobranca
               em aberto saida por uma delas -- e o chip passa a levar para as
               cobrancas, que e onde se conserta. O hover diz quem, nos dois
               casos: uma quebra de linha no title vira linha no tooltip. */
            $vermelho = $clientesHomolog !== array();
            $rotuloChip = count($contasTeste) === 1 ? $contasTeste[0] : count($contasTeste) . ' contas';
            $dicaChip = 'Em homologacao: ' . implode(', ', $contasTeste) . '.';
            $dicaChip .= $vermelho
                ? "
Cobranca em aberto por conta de teste (nao recebe dinheiro de verdade): " . implode(', ', $clientesHomolog) . '.'
                : "
Nenhum cliente com cobranca em aberto por elas.";
          ?>
          <a class="parque-chip sandbox-chip<?= $vermelho ? ' alerta' : ''; ?>" href="<?= $vermelho ? '/cobrancas.php' : '/formas_recebimento.php'; ?>"
             title="<?= htmlspecialchars($dicaChip, ENT_QUOTES, 'UTF-8'); ?>">
            <span class="parque-ponto" aria-hidden="true"></span>
            <strong><?= htmlspecialchars($rotuloChip, ENT_QUOTES, 'UTF-8'); ?></strong><span class="parque-rotulo"><?= $vermelho ? count($clientesHomolog) . ' cliente(s) em homologa&ccedil;&atilde;o' : 'em homologa&ccedil;&atilde;o'; ?></span>
          </a>
        <?php endif; ?>
      </div>
      <?php endif; ?>
      <ul class="navbar-nav ms-auto align-items-center">
        <li class="nav-item">
          <?php /* Lua no claro ("ir para o escuro"), sol no escuro. O CSS escolhe pelo data-bs-theme. */ ?>
          <button class="bt-tema" type="button" id="btTema"
                  aria-label="Alternar entre claro e escuro" title="Claro ou escuro">
            <svg class="tema-lua" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
            <svg class="tema-sol" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
          </button>
        </li>
        <li class="nav-item dropdown">
          <?php /* So a bolinha: nome e e-mail aparecem quando o menu desce. */ ?>
          <button class="conta-topo" type="button" data-bs-toggle="dropdown" aria-expanded="false"
                  aria-label="Menu da conta" title="<?= htmlspecialchars($nomeUsuario, ENT_QUOTES, 'UTF-8'); ?>">
            <span class="conta-avatar" aria-hidden="true"><?= htmlspecialchars(shield_marca_iniciais($nomeUsuario), ENT_QUOTES, 'UTF-8'); ?></span>
            <svg class="conta-seta" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>
          </button>
          <div class="dropdown-menu dropdown-menu-end menu-conta">
            <div class="menu-conta-cabeca">
              <span class="conta-avatar grande" aria-hidden="true"><?= htmlspecialchars(shield_marca_iniciais($nomeUsuario), ENT_QUOTES, 'UTF-8'); ?></span>
              <div>
                <strong><?= htmlspecialchars($nomeUsuario, ENT_QUOTES, 'UTF-8'); ?></strong>
                <small><?= htmlspecialchars($emailUsuario !== '' ? $emailUsuario : ($isAdmin ? 'Administrador' : 'Cliente'), ENT_QUOTES, 'UTF-8'); ?></small>
              </div>
            </div>
            <a class="dropdown-item" href="/perfil.php">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="8" r="4"/></svg>
              Meu perfil
            </a>
            <?php if ($isAdmin): ?>
            <a class="dropdown-item" href="/softhouse.php">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 21h18"/><path d="M5 21V7l7-4 7 4v14"/><path d="M9 21v-5h6v5"/><path d="M9 11h.01M15 11h.01M12 11h.01"/></svg>
              Minha empresa
            </a>
            <?php endif; ?>
            <a class="dropdown-item sair" href="/logout.php">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/></svg>
              Sair
            </a>
          </div>
        </li>
      </ul>
    </div>
  </header>

  <?php if ($isAdmin): ?>
  <?php /* A paleta de busca. Fica fora do fluxo (fixed) e so aparece com Ctrl+K ou o botao do topo. */ ?>
  <?php /* AS TAREFAS VAO NA PAGINA, e nao num pedido ao servidor (06/10/2026): sao
           as mesmas para todo mundo, e a resposta sai na hora em que se digita. */ ?>
  <div class="busca-paleta" id="paleta" hidden data-tarefas="<?= shield_h(json_encode(shield_tarefas_busca(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)); ?>">
    <div class="busca-fundo" data-fecha-paleta></div>
    <div class="busca-caixa" role="dialog" aria-modal="true" aria-label="Buscar cliente, terminal ou tarefa">
      <div class="busca-campo">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
        <input type="search" id="paletaInput" placeholder="Cliente, CNPJ, m&aacute;quina ou o que voc&ecirc; quer fazer" autocomplete="off" spellcheck="false" aria-controls="paletaLista">
        <kbd>Esc</kbd>
      </div>
      <div class="busca-resultados" id="paletaLista" role="listbox">
        <div class="busca-vazio">Digite pelo menos 2 letras. Vale nome, CNPJ, o nome da m&aacute;quina que aparece no ERP ou o que voc&ecirc; quer fazer: &ldquo;alterar vencimento&rdquo;, &ldquo;cancelar cobran&ccedil;a&rdquo;, &ldquo;planos&rdquo;.</div>
      </div>
      <div class="busca-rodape"><span><kbd>&uarr;</kbd><kbd>&darr;</kbd> navegar</span><span><kbd>Enter</kbd> abrir</span><span><kbd>Esc</kbd> fechar</span></div>
    </div>
  </div>
  <?php endif; ?>

  <main class="app-main conteudo">
    <?php /* O aviso de conta em ambiente de teste saiu daqui (08/09/2026). Era
             uma tira ambar de largura total entre a barra e a pagina -- a
             unica coisa na tela que nao era nem cromo nem trabalho, e por isso
             a mais feia. Virou o chip ao lado de "caixas no ar", na barra:
             e status, e status mora com status. */ ?>

    <div class="app-content corpo">
    <?php if (function_exists('shield_sql_mode_pendente') && shield_sql_mode_pendente() !== ''): ?>
      <?php /* O BANCO RECUSOU O AJUSTE DA CONEXAO (15/09/2026). Sem este aviso, as
               listas que engolem excecao aparecem vazias e os contadores em zero,
               e ninguem liga isso ao banco. Em toda tela, porque todas sofrem. */ ?>
      <div class="alert alert-danger">
        <strong>O banco desta hospedagem n&atilde;o aceitou o ajuste que o painel faz ao conectar.</strong>
        Algumas listas e contadores podem aparecer vazios e telas podem falhar. Pe&ccedil;a ao suporte da hospedagem
        para tirar <code>NO_ZERO_DATE</code>, <code>NO_ZERO_IN_DATE</code> e <code>ONLY_FULL_GROUP_BY</code>
        do <code>sql_mode</code> do banco.
        <div class="small mt-1 text-break">Modo atual, para o suporte: <?= shield_h(shield_sql_mode_pendente()); ?></div>
      </div>
    <?php endif; ?>
