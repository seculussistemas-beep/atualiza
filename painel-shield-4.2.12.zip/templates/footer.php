<?php
$anoAtual = date('Y');
$dbVersion = '';
try {
    $pdoRef = null;
    if (isset($pdo) && $pdo instanceof PDO) {
        $pdoRef = $pdo;
    } elseif (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) {
        $pdoRef = $GLOBALS['pdo'];
    }

    if (function_exists('shield_versao_do_painel')) {
        $dbVersion = shield_versao_do_painel($pdoRef);
    } elseif (function_exists('shield_load_app_config')) {
        $appCfg = shield_load_app_config();
        $dbVersion = trim((string) ($appCfg['app_version'] ?? ''));
    }
} catch (Throwable $ignored) {
    $dbVersion = '';
}

if ($dbVersion === '') {
    $dbVersion = '0.0.0';
}
?>
<span class="shield-footer-text">
    &copy; <?= htmlspecialchars((string) $anoAtual, ENT_QUOTES, 'UTF-8'); ?> Painel Shield. Todos os direitos reservados.
    <?php /* A versao que o membro ve e a do CODIGO (funcoes/nucleo/versao.php), a mesma da
             tela de login. A do banco anda em outro ritmo e fica no title.
             NUMA LINHA PROPRIA (14/09/2026): colada no fim da frase de direitos ela se
             perdia, e e o numero que o membro procura quando fala com o suporte. */ ?>
    <?php require_once __DIR__ . '/../funcoes/nucleo/versao.php'; ?>
    <span class="shield-footer-versao" title="Banco na vers&atilde;o <?= htmlspecialchars((string) $dbVersion, ENT_QUOTES, 'UTF-8'); ?>">Vers&atilde;o <?= htmlspecialchars(shield_versao_exibida(), ENT_QUOTES, 'UTF-8'); ?></span>
</span>
