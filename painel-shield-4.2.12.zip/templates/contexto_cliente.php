<?php
/**
 * Para onde o "Voltar" das telas do cliente aponta.
 *
 * O arquivo nasceu em 04/09/2026 para a barra de contexto do cliente, que as
 * telas da ficha, terminais, monitoramento, cobrancas e logs desenhavam com o
 * HTML copiado. A barra saiu das telas, e a funcao dela
 * (shield_contexto_cliente) saiu em 17/09/2026, sem chamador. O nome do
 * arquivo ficou porque sete telas o incluem.
 */

/**
 * Para onde o botao "Voltar" das telas do cliente aponta: a lista de
 * clientes, com a ultima busca. Uma funcao so porque quatro telas respondiam
 * isso e duas ja respondiam diferente.
 */
function shield_voltar_cliente($empresa)
{
    // VOLTAR E SEMPRE A LISTA DE CLIENTES, com a busca que estava la
    // (10/09/2026, tarde). Ficha, terminais, cobrancas e logs de um cliente
    // sao um clique de distancia da lista; "voltar" para a ficha fazia a pessoa
    // clicar duas vezes para chegar onde queria. $empresa fica na assinatura
    // por compatibilidade: quem chama nao precisa mudar.
    $empresa = (int) $empresa;
    // A lista volta com a ultima busca (ver clientes.php).
    $busca = (string) ($_SESSION['clientes_ultima_busca'] ?? '');

    return '/clientes.php' . ($busca !== '' ? '?' . $busca : '');
}
