<?php
/**
 * Fecha o casco que o estrutura.php abre - 25/08/2026.
 *
 * Ele abre <main class="corpo">, <div class="conteudo"> e <div class="painel">.
 * Fechar aqui, no fim, mantem a marcacao valida -- e a conferencia automatica
 * do design deixa de acusar tres tags abertas em cada pagina, que e o ruido
 * que ensina a ignorar a conferencia inteira.
 *
 * Aqui tambem vao o rodape, o Bootstrap e o punhado de JavaScript do casco. Sao
 * vinte linhas: gaveta no celular, tema claro/escuro. Nao voltar a puxar
 * jQuery por causa disto.
 */
?>
    </div>
  </main>

  <footer class="app-footer rodape">
    <?php include __DIR__ . '/footer.php'; ?>
  </footer>
</div>

<?php /* OS AVISOS QUE FLUTUAM (14/09/2026). Aqui, e nao onde a tela chamou:
         fora do .corpo, que anima com transform e roubaria o fixed (ver
         funcoes/ui/aviso.php). Sem aviso, nao sai nada. */ ?>
<?php $avisosFlutuantes = function_exists('shield_avisos_html') ? shield_avisos_html() : ''; ?>
<?php if ($avisosFlutuantes !== ''): ?>
<script>
  // Voltar ou avancar pelo historico remonta a pagina com o aviso da visita
  // passada ("gravado" sem nada ter sido gravado agora). A marca vai no <html>
  // ANTES de a pilha existir e o aviso.css a esconde. Esconder DEPOIS de a
  // pilha chegar deixaria o navegador pinta-la num quadro e tira-la no
  // seguinte, sempre que o parser parasse entre as duas coisas.
  (function () {
    try {
      var nav = performance.getEntriesByType('navigation')[0];
      if (nav && nav.type === 'back_forward') { document.documentElement.classList.add('aviso-voltou'); }
    } catch (e) {}
  })();
</script>
<?= $avisosFlutuantes; ?>
<?php endif; ?>

<?php /* O "grupo aberto continua aberto" saiu em 11/09/2026. Ele guardava o
         estado no navegador e reabria os <details> AQUI, no fim do corpo: a
         pagina pintava com tudo fechado e logo depois pulava, abrindo sozinha
         -- mais uma piscada, e ainda por cima trazendo aberto o que o membro
         queria fechado. Grupo e recorte de uma visita, nao preferencia. */ ?>
<script src="/vendor/bootstrap5/js/bootstrap.bundle.min.js?v=5.3.8"></script>
<script src="/vendor/adminlte/js/adminlte.min.js?v=4.8.4"></script>
<script src="/js/senha_forca.js?v=<?= (int) @filemtime(__DIR__ . '/../public/js/senha_forca.js'); ?>"></script>
<?php /* O tutorial das telas. Carrega em toda tela porque o passeio muda de pagina a
         cada passo: a pagina nova e que desenha o balao do passo em que esta. */ ?>
<?php /* Os prazos que o passeio conta vem das constantes, nao do texto do JS: o
         60 do rascunho mudou em 4.1.27 e o tutorial continuou dizendo o numero
         velho. Antes do tutorial.js, que le isto ao montar os passos. */
      require_once __DIR__ . '/../funcoes/licenca/encerramento.php';
      require_once __DIR__ . '/../funcoes/licenca/area_cliente.php'; ?>
<script>window.shieldTutorialDados = <?= json_encode(array(
    'encerramentoDias' => (int) SHIELD_ENCERRAMENTO_DIAS,
    'encerramentoDiasRascunho' => (int) SHIELD_ENCERRAMENTO_DIAS_RASCUNHO,
    'senhaTemporariaDias' => (int) SHIELD_AREA_SENHA_TEMPORARIA_DIAS,
)); ?>;</script>
<script src="/js/tutorial.js?v=<?= (int) @filemtime(__DIR__ . '/../public/js/tutorial.js'); ?>"></script>
<script>if (window.shieldLigarSenha) { window.shieldLigarSenha(document); }</script>
<script>
(function () {
  // A gaveta do celular. Dois botoes -- um na barra, um no topo -- porque a
  // barra some quando ela esta fechada.
  var lateral = document.getElementById('lateral');
  var mascara = document.getElementById('mascaraLateral');
  function alternarGaveta() {
    if (!lateral) { return; }
    var aberta = lateral.classList.toggle('aberta');
    document.body.classList.toggle('menu-aberto', aberta);
    document.querySelectorAll('#btGaveta,#btGaveta2').forEach(function (b) {
      b.setAttribute('aria-expanded', aberta ? 'true' : 'false');
    });
  }
  document.querySelectorAll('#btGaveta,#btGaveta2').forEach(function (b) {
    b.addEventListener('click', alternarGaveta);
  });
  if (mascara) { mascara.addEventListener('click', alternarGaveta); }
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape' && lateral && lateral.classList.contains('aberta')) {
      alternarGaveta();
    }
  });

  // No desktop, a lateral recolhida deixa a tela maior sem tirar os atalhos:
  // icones continuam acessiveis por titulo e o estado fica por navegador.
  var btRecolher = document.getElementById('btRecolher');
  function lateralCompacta() {
    return document.documentElement.getAttribute('data-sidebar') === 'compacta';
  }
  function atualizarLateral(compacta) {
    if (compacta) {
      document.documentElement.setAttribute('data-sidebar', 'compacta');
    } else {
      document.documentElement.removeAttribute('data-sidebar');
    }
    if (btRecolher) {
      btRecolher.setAttribute('aria-pressed', compacta ? 'true' : 'false');
      btRecolher.setAttribute('aria-label', compacta ? 'Expandir menu' : 'Recolher menu');
      btRecolher.setAttribute('title', compacta ? 'Expandir menu' : 'Recolher menu');
    }
    try { localStorage.setItem('painel_sidebar_compacta', compacta ? '1' : '0'); } catch (e) {}
  }
  if (btRecolher) {
    atualizarLateral(lateralCompacta());
    btRecolher.addEventListener('click', function () { atualizarLateral(!lateralCompacta()); });
  }
  window.addEventListener('resize', function () {
    if (window.innerWidth > 992 && lateral && lateral.classList.contains('aberta')) {
      lateral.classList.remove('aberta');
      document.body.classList.remove('menu-aberto');
      document.querySelectorAll('#btGaveta,#btGaveta2').forEach(function (b) {
        b.setAttribute('aria-expanded', 'false');
      });
    }
  });

  // Os grupos da lateral. O da tela atual ja vem aberto do PHP; os outros
  // lembram o que a pessoa deixou. Recolhida, o CSS ignora tudo isto e mostra
  // so icones.
  var grupos = document.querySelectorAll('.grupo-acc');
  var lembrados = {};
  try { lembrados = JSON.parse(localStorage.getItem('painel_grupos') || '{}') || {}; } catch (e) {}
  grupos.forEach(function (g) {
    var chave = g.getAttribute('data-grupo');
    var bt = g.querySelector('.grupo-trigger');
    // O grupo da tela atual nao obedece a memoria: fica aberto. Os outros
    // seguem o que a pessoa deixou (true abre, false fecha).
    if (!g.hasAttribute('data-atual') && typeof lembrados[chave] === 'boolean') {
      g.classList.toggle('aberto', lembrados[chave]);
      bt.setAttribute('aria-expanded', lembrados[chave] ? 'true' : 'false');
    }
    bt.addEventListener('click', function () {
      var aberto = g.classList.toggle('aberto');
      bt.setAttribute('aria-expanded', aberto ? 'true' : 'false');
      lembrados[chave] = aberto;
      try { localStorage.setItem('painel_grupos', JSON.stringify(lembrados)); } catch (e) {}
    });
  });

  // A busca do topo (Ctrl+K). Procura cliente e terminal enquanto digita,
  // com setas e Enter para abrir. O servidor e modules/clientes/ajax_buscar_clientes.php.
  var paleta = document.getElementById('paleta');
  var paletaInput = document.getElementById('paletaInput');
  var paletaLista = document.getElementById('paletaLista');
  if (paleta && paletaInput && paletaLista) {
    var itensPaleta = [];
    var ativoPaleta = -1;
    var temporizadorBusca = null;
    var pedidoAtual = 0;
    var h = function (t) { return String(t).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); };

    function abrirPaleta() {
      paleta.hidden = false;
      document.body.classList.add('paleta-aberta');
      requestAnimationFrame(function () { paleta.classList.add('aberta'); paletaInput.focus(); paletaInput.select(); });
    }
    function fecharPaleta() {
      paleta.classList.remove('aberta');
      document.body.classList.remove('paleta-aberta');
      setTimeout(function () { paleta.hidden = true; }, 160);
    }
    function marcarAtivo(i) {
      ativoPaleta = i;
      itensPaleta.forEach(function (el, k) { el.classList.toggle('ativo', k === i); el.setAttribute('aria-selected', k === i ? 'true' : 'false'); });
      if (itensPaleta[i]) { itensPaleta[i].scrollIntoView({ block: 'nearest' }); }
    }
    function mostrar(html) {
      paletaLista.innerHTML = html;
      itensPaleta = Array.prototype.slice.call(paletaLista.querySelectorAll('.busca-item'));
      itensPaleta.forEach(function (el, k) {
        el.addEventListener('mousemove', function () { if (ativoPaleta !== k) { marcarAtivo(k); } });
      });
      marcarAtivo(itensPaleta.length ? 0 : -1);
    }
    // AS TAREFAS (06/10/2026). A lista vem de funcoes/ui/tarefas.php, no
    // data-tarefas da paleta, e e comparada aqui mesmo, sem ir ao servidor.
    var tarefas = [];
    try { tarefas = JSON.parse(paleta.getAttribute('data-tarefas') || '[]'); } catch (e) { tarefas = []; }
    var decodificador = document.createElement('textarea');
    function semEntidade(t) { decodificador.innerHTML = t; return decodificador.value; }
    // Minusculo e sem acento. Letra a letra, e nao por expressao com faixa de
    // escape unicode: escape escrito por ferramenta de edicao ja virou caractere
    // cru neste projeto mais de uma vez.
    function normal(t) {
      var d = String(t).toLowerCase().normalize('NFD'), s = '';
      for (var i = 0; i < d.length; i++) {
        var c = d.charCodeAt(i);
        if (c < 0x300 || c > 0x36f) { s += d.charAt(i); }
      }
      return s;
    }
    tarefas.forEach(function (t) {
      t.rotulo = semEntidade(t.texto);
      t.onde = semEntidade(t.caminho);
      t.termos = normal(t.rotulo + ' ' + t.palavras).split(/[^a-z0-9]+/).filter(Boolean);
    });
    // Casa pelo comeco da palavra ("venc" acha "vencimento") e aceita o plural
    // ("planos" acha "plano").
    function casa(token, termos) {
      var raiz = token.length > 3 && token.charAt(token.length - 1) === 's' ? token.slice(0, -1) : token;
      for (var i = 0; i < termos.length; i++) {
        if (termos[i].indexOf(token) === 0 || termos[i].indexOf(raiz) === 0) { return true; }
      }
      return false;
    }
    // As tarefas que casam, a que casa mais palavras primeiro, e as palavras que
    // sobraram: em "vencimento mercado", o "mercado" e o cliente.
    var LIGACAO = ['de', 'da', 'do', 'das', 'dos', 'um', 'uma', 'no', 'na', 'em', 'para', 'pra', 'com', 'por', 'que', 'meu', 'minha'];
    function acharTarefas(q) {
      // "do", "de", "um"... casariam com qualquer texto e empatariam tudo.
      var tokens = normal(q).split(/[^a-z0-9]+/).filter(function (x) { return x.length >= 2 && LIGACAO.indexOf(x) < 0; });
      var achadas = [];
      tarefas.forEach(function (t, ordem) {
        var usados = tokens.filter(function (k) { return casa(k, t.termos); });
        if (usados.length) { achadas.push({ t: t, nota: usados.length, ordem: ordem, usados: usados }); }
      });
      achadas.sort(function (a, b) { return (b.nota - a.nota) || (a.ordem - b.ordem); });
      var sobra = achadas.length ? tokens.filter(function (k) { return achadas[0].usados.indexOf(k) < 0; }) : [];
      return { lista: achadas.slice(0, 6).map(function (a) { return a.t; }), sobra: sobra };
    }
    function itemTarefa(url, titulo, sub) {
      return '<a class="busca-item" role="option" href="' + h(url) + '">'
        + '<span class="busca-icone">🧭</span>'
        + '<span class="busca-texto"><b>' + h(titulo) + '</b><small>' + h(sub) + '</small></span></a>';
    }
    // Tarefa de cliente com cliente achado vai direto para a tela dele; sem
    // cliente, para a lista onde se escolhe.
    function htmlTarefas(r, clientesDaSobra) {
      if (!r.lista.length) { return ''; }
      var html = '<div class="busca-grupo">Tarefas</div>';
      r.lista.forEach(function (t) {
        if (t.cliente && clientesDaSobra && clientesDaSobra.length) {
          clientesDaSobra.slice(0, 3).forEach(function (c) {
            html += itemTarefa(t.cliente.replace('{id}', String(c.id)), t.rotulo + ' · ' + c.razao, t.onde);
          });
        } else {
          html += itemTarefa(t.url, t.rotulo, t.onde + (t.cliente ? ' · escolha o cliente' : ''));
        }
      });
      return html;
    }

    function situacaoTexto(s) {
      return { em_dia: 'Licença em dia', vencida: 'Licença vencida', bloqueado: 'Bloqueado', sem_licenca: 'Sem licença' }[s] || '';
    }
    // r: o que acharTarefas deu. Com tarefa achada e palavra sobrando, o
    // servidor procura so a sobra ("mercado" em "vencimento mercado").
    function buscar(q, r) {
      var meu = ++pedidoAtual;
      var daSobra = r.lista.length > 0 && r.sobra.length > 0;
      var pergunta = daSobra ? r.sobra.join(' ') : q;
      fetch('/ajax_buscar_clientes.php?q=' + encodeURIComponent(pergunta), { credentials: 'same-origin' })
        .then(function (resposta) { return resposta.json(); })
        .then(function (d) {
          if (meu !== pedidoAtual) { return; }
          if (!d || !d.ok) { mostrar(htmlTarefas(r) + '<div class="busca-vazio">A busca de clientes falhou. Tente de novo.</div>'); return; }
          var html = htmlTarefas(r, daSobra ? d.clientes : null);
          if (d.clientes.length) {
            html += '<div class="busca-grupo">Clientes</div>';
            d.clientes.forEach(function (c) {
              html += '<a class="busca-item" role="option" href="' + h(c.url) + '">'
                + '<span class="busca-icone">🏬</span>'
                + '<span class="busca-texto"><b>' + h(c.razao) + '</b><small>' + h(c.cnpj) + (c.lugar ? ' · ' + h(c.lugar) : '') + '</small></span>'
                + '<span class="busca-selo ' + h(c.situacao) + '">' + h(situacaoTexto(c.situacao)) + '</span></a>';
            });
          }
          if (d.terminais.length) {
            html += '<div class="busca-grupo">Terminais</div>';
            d.terminais.forEach(function (t) {
              html += '<a class="busca-item" role="option" href="' + h(t.url) + '">'
                + '<span class="busca-icone">🖥️</span>'
                + '<span class="busca-texto"><b>' + h(t.nome || t.mac) + '</b><small>' + h(t.razao || 'sem cliente') + (t.maquina ? ' · ' + h(t.maquina) : '') + (t.mac ? ' · ' + h(t.mac) : '') + '</small></span>'
                + '<span class="busca-selo ' + (t.vivo ? 'em_dia' : 'vencida') + '">' + (t.vivo ? 'dando sinal' : 'sem sinal') + (t.ha_quanto ? ' · ' + h(t.ha_quanto) : '') + '</span></a>';
            });
          }
          if (!html) { html = '<div class="busca-vazio">Nada com "' + h(q) + '". Clientes aparecem depois que o ERP se registra pela primeira vez.</div>'; }
          mostrar(html);
        })
        .catch(function () { if (meu === pedidoAtual) { mostrar(htmlTarefas(r) + '<div class="busca-vazio">A busca de clientes falhou. Tente de novo.</div>'); } });
    }

    paletaInput.addEventListener('input', function () {
      var q = paletaInput.value.trim();
      clearTimeout(temporizadorBusca);
      if (q.length < 2) {
        pedidoAtual++;
        mostrar('<div class="busca-vazio">Digite pelo menos 2 letras. Vale nome, CNPJ, o nome da máquina ou o que você quer fazer.</div>');
        return;
      }
      // As tarefas aparecem na hora; cliente e terminal chegam depois, do servidor.
      var r = acharTarefas(q);
      if (r.lista.length) { mostrar(htmlTarefas(r)); }
      temporizadorBusca = setTimeout(function () { buscar(q, r); }, 180);
    });
    paletaInput.addEventListener('keydown', function (ev) {
      if (ev.key === 'ArrowDown') { ev.preventDefault(); if (itensPaleta.length) { marcarAtivo((ativoPaleta + 1) % itensPaleta.length); } }
      else if (ev.key === 'ArrowUp') { ev.preventDefault(); if (itensPaleta.length) { marcarAtivo((ativoPaleta - 1 + itensPaleta.length) % itensPaleta.length); } }
      else if (ev.key === 'Enter') { ev.preventDefault(); if (itensPaleta[ativoPaleta]) { window.location.href = itensPaleta[ativoPaleta].href; } }
      else if (ev.key === 'Escape') { ev.preventDefault(); fecharPaleta(); }
    });
    document.querySelectorAll('[data-fecha-paleta]').forEach(function (el) { el.addEventListener('click', fecharPaleta); });
    var btBusca = document.getElementById('btBusca');
    if (btBusca) { btBusca.addEventListener('click', abrirPaleta); }
    document.addEventListener('keydown', function (ev) {
      if ((ev.ctrlKey || ev.metaKey) && (ev.key === 'k' || ev.key === 'K')) {
        ev.preventDefault();
        if (paleta.hidden) { abrirPaleta(); } else { fecharPaleta(); }
      } else if (ev.key === 'Escape' && !paleta.hidden) {
        fecharPaleta();
      }
    });
  }

  // OS AVISOS QUE FLUTUAM (14/09/2026). Sumir em 5 s (10 s o demorado) e pausar
  // sob o mouse sao do CSS (public/css/aviso.css); aqui fica so o que CSS nao faz.
  var pilha = document.getElementById('avisoPilha');
  if (pilha) {
    // Volta pela memoria do navegador: a pagina nao roda de novo, e o aviso
    // da visita passada nao pode reaparecer junto com ela.
    window.addEventListener('pageshow', function (ev) {
      if (ev.persisted) { document.documentElement.classList.add('aviso-voltou'); }
    });
  }
  if (pilha && !document.documentElement.classList.contains('aviso-voltou')) {
    // O X esconde NO LUGAR (.fechado usa visibility): o aviso de baixo nao
    // sobe para o buraco, e nada na tela muda de lugar.
    pilha.addEventListener('click', function (ev) {
      var x = ev.target.closest ? ev.target.closest('.aviso-fechar') : null;
      if (x) { x.closest('.aviso-flutua').classList.add('fechado'); }
    });
    // O anuncio ao leitor de tela vem um instante depois da carga: regiao viva
    // preenchida no mesmo quadro em que nasce nao e lida por todo leitor.
    var leitor = document.getElementById('avisoLeitor');
    if (leitor) {
      var frases = Array.prototype.map.call(pilha.querySelectorAll('.aviso-texto'), function (t) { return t.textContent; });
      setTimeout(function () { leitor.textContent = frases.join(' '); }, 400);
    }
    // ?ok=1, ?msg=, ?salvo= e ?status= saem do endereco: F5 nao repete "gravado".
    var tirar = (pilha.getAttribute('data-tirar') || '').split(' ').filter(Boolean);
    if (tirar.length && window.URL && history.replaceState) {
      try {
        var endereco = new URL(location.href);
        tirar.forEach(function (k) { endereco.searchParams.delete(k); });
        history.replaceState(history.state, '', endereco.pathname + endereco.search + endereco.hash);
      } catch (e) {}
    }
  }

  // Claro e escuro. A escolha fica no navegador do operador, e nao no banco:
  // e preferencia da MAQUINA dele -- o mesmo usuario num monitor claro na loja
  // e num escuro em casa quer coisas diferentes.
  var bt = document.getElementById('btTema');
  if (bt) {
    bt.addEventListener('click', function () {
      var raiz = document.documentElement;
      var novo = raiz.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
      // Desliga toda transicao durante a troca: a tela inteira muda de cor
      // de uma vez, em vez de cada peca no seu ritmo.
      raiz.classList.add('sem-transicao');
      raiz.setAttribute('data-bs-theme', novo);
      try { localStorage.setItem('painel_tema', novo); } catch (e) {}
      void raiz.offsetWidth;
      // Dois quadros: o primeiro aplica as cores novas ainda sem transicao,
      // o segundo devolve as transicoes para o resto da pagina.
      requestAnimationFrame(function () { requestAnimationFrame(function () { raiz.classList.remove('sem-transicao'); }); });
    });
  }
})();

  /* COPIAR UM CODIGO -- o copia-e-cola do PIX, a linha digitavel do boleto.
     Fica aqui e nao na tela de cobrancas porque a proxima tela que mostrar um
     codigo vai precisar do mesmo, e duas copias divergem.

     `navigator.clipboard` exige contexto seguro (https ou localhost). O painel
     do membro pode rodar em http numa rede interna, e ali ele simplesmente
     nao existe -- por isso o caminho antigo continua como reserva, em vez de
     o botao nao fazer nada e ninguem entender por que. */
  function shieldCopiar(texto, botao) {
    var feito = function () {
      var antes = botao.innerHTML;
      botao.innerHTML = '<i class="fas fa-check"></i>';
      botao.classList.add('copiado');
      setTimeout(function () {
        botao.innerHTML = antes;
        botao.classList.remove('copiado');
      }, 1400);
    };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(texto).then(feito, function () { shieldCopiarVelho(texto, feito); });
    } else {
      shieldCopiarVelho(texto, feito);
    }
  }
  function shieldCopiarVelho(texto, feito) {
    var a = document.createElement('textarea');
    a.value = texto;
    a.setAttribute('readonly', '');
    a.style.position = 'fixed';
    a.style.left = '-9999px';
    document.body.appendChild(a);
    a.select();
    try { document.execCommand('copy'); feito(); } catch (e) { window.prompt('Copie o codigo:', texto); }
    document.body.removeChild(a);
  }
  // Campo de dinheiro: ao sair dele, "249" vira "249,00" e "1000" vira
  // "1000,00". So a mascara -- quem converte para centavos e o servidor.
  function formatarDinheiro(ev) {
    var i = ev.target;
    if (!i || !i.classList || !i.classList.contains('dinheiro') || i.readOnly) { return; }
    var t = (i.value || '').trim();
    if (t === '') { return; }
    var neg = t.charAt(0) === '-';
    var so = t.replace(/[^0-9,.]/g, '');
    var ultimaV = so.lastIndexOf(','), ultimoP = so.lastIndexOf('.');
    var n;
    if (ultimaV !== -1 && ultimoP !== -1) { n = ultimaV > ultimoP ? so.replace(/\./g, '').replace(',', '.') : so.replace(/,/g, ''); }
    else if (ultimaV !== -1) { n = so.replace(',', '.'); }
    else { n = so; }
    var v = parseFloat(n);
    if (isNaN(v)) { return; }
    var teto = parseFloat(i.getAttribute('data-teto') || '');
    if (!isNaN(teto) && v > teto) { v = teto; }
    i.value = (neg ? '-' : '') + v.toFixed(2).replace('.', ',');
  }
  // blur nao borbulha (por isso a captura); change borbulha e cobre o
  // autopreenchimento do navegador, que nao passa por blur.
  document.addEventListener('blur', formatarDinheiro, true);
  document.addEventListener('change', formatarDinheiro);

  // MASCARA DE TELEFONE (10/09/2026): (00)00000-0000 enquanto digita, so digitos
  // ate 11. Vale para todo input com a classe `fone`; o servidor guarda os
  // digitos, entao a mascara e so de tela.
  document.addEventListener('input', function (ev) {
    var i = ev.target;
    if (!i || !i.classList || !i.classList.contains('fone')) { return; }
    var d = (i.value || '').replace(/\D/g, '').slice(0, 11);
    var r = d;
    if (d.length > 2) { r = '(' + d.slice(0, 2) + ')' + d.slice(2); }
    if (d.length > 6) { var meio = d.length === 11 ? 7 : 6; r = '(' + d.slice(0, 2) + ')' + d.slice(2, meio) + '-' + d.slice(meio); }
    i.value = r;
  });

  document.addEventListener('click', function (ev) {
    var b = ev.target.closest ? ev.target.closest('.js-copiar') : null;
    if (b && b.dataset.codigo) {
      ev.preventDefault();
      shieldCopiar(b.dataset.codigo, b);
    }
  });

  /* RESPOSTA IMEDIATA AO CLIQUE -- 08/09/2026.
   *
   * O painel leva ~300ms para responder no servidor e a transicao entre
   * documentos segura a tela ANTIGA enquanto espera: por cerca de meio segundo
   * a pessoa clica e nao acontece nada visivel, entao ela clica de novo. Nao e
   * clique perdido -- e falta de resposta.
   *
   * O conserto nao e ficar mais rapido (o custo e o arranque do PHP, e em
   * producao ele nem existe do mesmo jeito): e AVISAR que o clique pegou. Uma
   * barra fina no topo, que comeca no instante do clique e cresce enquanto a
   * proxima tela nao chega. Ela nao mede nada -- nao da para saber quanto falta
   * --, ela so diz "estou indo".
   *
   * O elemento clicado tambem apaga um pouco, para a mao saber onde encostou.
   */
  var barra = null;
  function comecarEspera(alvo) {
    if (barra) { return; }
    barra = document.createElement('div');
    barra.className = 'indo';
    document.body.appendChild(barra);
    // Le uma medida para forcar o calculo do estado inicial (largura 0). Sem
    // isso o navegador junta o nascimento e a mudanca no mesmo quadro, e a
    // barra salta pronta em vez de crescer.
    void barra.offsetWidth;
    requestAnimationFrame(function () {
      requestAnimationFrame(function () { if (barra) { barra.classList.add('andando'); } });
    });
    if (alvo && alvo.classList) { alvo.classList.add('indo-daqui'); }
  }
  // Volta da memoria do navegador (botao Voltar): a barra da vez passada nao
  // pode continuar na tela como se a pagina ainda estivesse carregando.
  window.addEventListener('pageshow', function (ev) {
    if (ev.persisted && barra) { barra.remove(); barra = null; }
  });

  document.addEventListener('click', function (ev) {
    // Clique com modificador abre em outra aba: a tela AQUI nao vai a lugar
    // nenhum, e a barra ficaria mentindo.
    if (ev.defaultPrevented || ev.button !== 0 || ev.metaKey || ev.ctrlKey || ev.shiftKey || ev.altKey) { return; }
    var a = ev.target.closest ? ev.target.closest('a[href]') : null;
    if (!a) { return; }
    var href = a.getAttribute('href') || '';
    if (a.target === '_blank' || a.hasAttribute('download')) { return; }
    if (href === '' || href.charAt(0) === '#' || /^(javascript|mailto|tel):/i.test(href)) { return; }
    if (a.origin && a.origin !== location.origin) { return; }
    // Mesma pagina, so a ancora: nao ha navegacao para esperar.
    if (a.pathname === location.pathname && a.search === location.search) { return; }
    comecarEspera(a);
  });

  document.addEventListener('submit', function (ev) {
    if (ev.defaultPrevented) { return; }
    comecarEspera(ev.target);
  });

</script>
</body>
</html>
