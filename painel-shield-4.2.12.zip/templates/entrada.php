<?php

// As telas de ENTRADA: login, esqueci a senha, redefinir senha -- 03/09/2026.
//
// A folha e uma so (css/entrada.css): a metade escura com o logo a esquerda e o
// formulario a direita. Cada tela escreve so a metade direita, entre
// shield_entrada_abrir() e shield_entrada_fechar(). Assim o logo, o texto da
// marca e o rodape mudam num lugar e valem para as tres.

require_once __DIR__ . '/../funcoes/nucleo/versao.php';

/* As tres cores da marca, lidas do cadastro -- 08/09/2026.
 *
 * Ate aqui a tela de entrada tinha paleta PROPRIA e ignorava o cadastro: o
 * membro que escolhia a cor dele via a cor dele no painel e um azul-marinho no
 * login. Agora a primeira tela ja e a dele.
 *
 * E a mesma conta de templates/estrutura.php, e de proposito -- as duas telas
 * tem de derivar igual, senao o :hover do botao muda de uma para a outra.
 *
 * FALHAR AQUI NAO PODE APAGAR A TELA. Esta e a unica tela que roda ANTES do
 * login, entao um erro aqui tranca inclusive o administrador que iria
 * consertar. Por isso o try/catch devolve o trio de fabrica, e a regex e o que
 * impede uma string qualquer do banco de entrar no <style>.
 */
function shield_entrada_marca_cores()
{
    $cor = '';
    try {
        if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO
            && function_exists('shield_get_system_meta')) {
            $cor = trim((string) shield_get_system_meta($GLOBALS['pdo'], 'marca_cor', ''));
        }
    } catch (Throwable $ignorado) {
        $cor = '';
    }

    $padrao = defined('SHIELD_MARCA_COR_PADRAO') ? SHIELD_MARCA_COR_PADRAO : '#00697f';
    if (!preg_match('/^#([0-9a-fA-F]{6})$/', $cor, $m) || strcasecmp($cor, $padrao) === 0) {
        return array('marca' => $padrao, 'escura' => '#004d5d', 'clara' => '#02c8f0');
    }

    $rgb = array_map('hexdec', str_split($m[1], 2));

    return array(
        'marca' => strtolower($cor),
        'escura' => sprintf('#%02x%02x%02x', (int) ($rgb[0] * .74),
                            (int) ($rgb[1] * .74), (int) ($rgb[2] * .74)),
        'clara' => sprintf('#%02x%02x%02x',
                           (int) ($rgb[0] + (255 - $rgb[0]) * .55),
                           (int) ($rgb[1] + (255 - $rgb[1]) * .55),
                           (int) ($rgb[2] + (255 - $rgb[2]) * .55)),
    );
}

/** So o documento e o fundo. O cadastro usa isto com uma folha propria. */
function shield_entrada_html_abrir($titulo)
{
    $e = static function ($t) {
        return htmlspecialchars((string) $t, ENT_QUOTES, 'UTF-8');
    };
    $versao = shield_versao_exibida();
    $cores = shield_entrada_marca_cores();
    ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $e($titulo); ?> - Shield</title>
    <?php /* O DM Sans do Google Fonts saiu daqui em 08/09/2026. Era o unico
             recurso externo do produto, numa tela que precisa abrir na rede da
             loja -- atras do proxy que ela tiver -- e a propria CSP do painel
             nao o admite (public/.htaccess: font-src 'self' data:). As letras
             agora vem de css/fonts/, declaradas em css/entrada.css. */ ?>
    <link rel="stylesheet" href="/vendor/bootstrap5/css/bootstrap.min.css">
    <?php /* A data do arquivo, e nao a versao: CSS editado sem subir versao ficava preso no cache. */ ?>
    <link rel="stylesheet" href="/css/entrada.css?v=<?= (int) @filemtime(__DIR__ . '/../public/css/entrada.css'); ?>">
    <link rel="stylesheet" href="/css/senha.css?v=<?= (int) @filemtime(__DIR__ . '/../public/css/senha.css'); ?>">
    <link rel="icon" href="/favicon.ico?v=<?= (int) @filemtime(__DIR__ . '/../public/favicon.ico'); ?>" sizes="16x16 32x32 48x48">
    <link rel="icon" type="image/png" sizes="512x512" href="/img/favicon-512.png?v=<?= (int) @filemtime(__DIR__ . '/../public/img/favicon-512.png'); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="/img/favicon-180.png?v=<?= (int) @filemtime(__DIR__ . '/../public/img/favicon-180.png'); ?>">
    <?php /* DEPOIS das folhas, de proposito: e isto que faz a cor do cadastro
             vencer o padrao de fabrica declarado no :root do entrada.css. */ ?>
    <style>
        :root {
            --marca: <?= $e($cores['marca']); ?>;
            --marca-escura: <?= $e($cores['escura']); ?>;
            --marca-clara: <?= $e($cores['clara']); ?>;
        }
    </style>
</head>
<body>
    <div class="fundo" aria-hidden="true">
        <?php /* A constelacao (js/constelacao.js) desenha aqui; a grade de pontos de CSS saiu. */ ?>
        <canvas class="constelacao"></canvas>
        <div class="grad"><div class="feixe f1"></div><div class="feixe f2"></div><div class="feixe f3"></div></div>
        <div class="pontos"></div>
    </div>
    <?php
}

/** A folha dividida: marca a esquerda, e a tela escreve a metade direita. */
function shield_entrada_abrir($titulo)
{
    shield_entrada_html_abrir($titulo);
    $e = static function ($t) {
        return htmlspecialchars((string) $t, ENT_QUOTES, 'UTF-8');
    };
    $versao = shield_versao_exibida();
    ?>
    <main class="palco">
        <div class="folha">
            <section class="marca" aria-label="Painel Shield">
                <div class="grad"></div><div class="feixe f1"></div><div class="pontos"></div><div class="raios"></div>
                <img class="logo" src="/img/escudo-256.png?v=<?= (int) @filemtime(__DIR__ . "/../public/img/escudo-256.png"); ?>" alt="Shield">
                <h1>Licenças no controle, cobrança no automático.</h1>
                <p>O painel da softhouse para o parque de ERPs: quem está rodando, quem venceu, quem pagou.</p>
                <ul>
                    <li><i>✓</i>Caixa pergunta, painel responde em segundos</li>
                    <li><i>✓</i>Régua de cobrança cuida do lembrete</li>
                    <li><i>✓</i>Você só decide o que exige decisão</li>
                </ul>
                <div class="versao">Painel Shield · versão <?= $e($versao); ?></div>
            </section>

            <section class="form">
    <?php
}

function shield_entrada_fechar()
{
    $versao = htmlspecialchars(shield_versao_exibida(), ENT_QUOTES, 'UTF-8');
    ?>
            </section>
        </div>
    </main>
    <?php
    shield_entrada_html_fechar();
}

/** O script comum (olho da senha, validacao no envio) e o fim do documento. */
function shield_entrada_html_fechar()
{
    ?>
    <script src="/js/senha_forca.js?v=<?= (int) @filemtime(__DIR__ . '/../public/js/senha_forca.js'); ?>"></script>
    <script src="/js/constelacao.js?v=<?= (int) @filemtime(__DIR__ . '/../public/js/constelacao.js'); ?>"></script>
    <script>
        (function () {
            // Olho, medidor de forca e conferencia: /js/senha_forca.js.
            if (window.shieldLigarSenha) { window.shieldLigarSenha(document); }
            // Validacao so no envio, e o botao trava para nao mandar duas vezes.
            document.querySelectorAll('form[data-valida]').forEach(function (form) {
                // Campo que ficou certo vai ficando verde enquanto a pessoa preenche o resto.
                form.querySelectorAll('input:not([type="hidden"]):not([type="checkbox"])').forEach(function (campo) {
                    var marca = function () {
                        campo.classList.toggle('valido', campo.value !== '' && campo.validity.valid);
                    };
                    campo.addEventListener('input', marca);
                    campo.addEventListener('blur', marca);
                    // Os medidores de senha mudam a validade sem evento de input no outro campo.
                    campo.addEventListener('change', marca);
                });
                form.addEventListener('submit', function (e) {
                    form.classList.add('was-validated');
                    if (!form.checkValidity()) {
                        e.preventDefault();
                        var primeiro = form.querySelector(':invalid');
                        if (primeiro) primeiro.focus();
                        return;
                    }
                    var botao = form.querySelector('button[type="submit"]');
                    if (botao) {
                        botao.disabled = true;
                        // "Entrar" vira "Entrando…", "Criar o acesso" vira "Criando acesso…".
                        var texto = botao.getAttribute('data-enviando');
                        var rotulo = botao.querySelector('span:last-child');
                        if (texto && rotulo) rotulo.textContent = texto;
                    }
                });
            });
            // Transicao entre as telas de entrada: a folha sai antes de a proxima chegar.
            var quieto = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            document.querySelectorAll('a[href$=".php"], a.entrar').forEach(function (a) {
                a.addEventListener('click', function (e) {
                    if (quieto || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
                    if (a.origin !== location.origin) return;
                    e.preventDefault();
                    document.body.classList.add('saindo');
                    setTimeout(function () { location.href = a.href; }, 220);
                });
            });
            // Ao voltar pelo historico a pagina vem do cache com a classe 'saindo' ainda posta.
            window.addEventListener('pageshow', function () { document.body.classList.remove('saindo'); });
        })();
    </script>
</body>
</html>
    <?php
}

/** O medidor de forca. $id e o que o input aponta em data-forca. */
function shield_entrada_forca($id)
{
    return '<div class="forca" id="' . htmlspecialchars((string) $id, ENT_QUOTES, 'UTF-8') . '" data-nivel="0" aria-live="polite">'
        . '<div class="forca-barra"><i></i><i></i><i></i><i></i></div>'
        . '<div class="forca-texto"><b></b><span>Use 8 ou mais caracteres misturando letras, números e símbolos.</span></div>'
        . '</div>';
}

/** O botao de mostrar/ocultar senha, para nao repetir os dois SVGs em cada tela. */
function shield_entrada_olho()
{
    return '<button type="button" class="olho" aria-label="Mostrar senha" aria-pressed="false">'
        . '<svg class="aberto" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>'
        . '<svg class="fechado" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.9 17.9A10.5 10.5 0 0 1 12 19c-6.5 0-10-7-10-7a17.6 17.6 0 0 1 4.1-4.9M9.9 5.2A9.6 9.6 0 0 1 12 5c6.5 0 10 7 10 7a17.6 17.6 0 0 1-2.2 3.1"/><path d="M14.1 14.1a3 3 0 0 1-4.2-4.2"/><path d="M2 2l20 20"/></svg>'
        . '</button>';
}
