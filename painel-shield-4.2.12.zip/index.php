<?php

/**
 * LAPIDE DA RAIZ -- 04/09/2026.
 *
 * O painel passa a ser servido de public/. Este arquivo so e alcancado por quem
 * ainda tem o DocumentRoot apontando para a raiz -- e, por causa do .htaccess
 * antigo, ele recebe TODAS as telas (a regra reescreve qualquer /x.php para
 * index.php?r=x).
 *
 * DESDE 10/09/2026 A RAIZ TEM UM .htaccess QUE ENCAMINHA PARA public/ por
 * dentro do servidor (pedido do dono do produto: "descompacta e funciona").
 * Este arquivo, portanto, so e alcancado quando o Apache NAO le o .htaccess
 * -- AllowOverride None -- e ai a mensagem certa e essa, e nao a de reapontar.
 *
 * ELE NAO ENCAMINHA DE PROPOSITO, e essa e a diferenca para as lapides de
 * webhooks/ e api/.
 *
 * Aquelas encaminham porque sao chamadas por PROGRAMA -- gateway e ERP, que tem
 * a URL cadastrada e nao tem como saber que algo mudou. Deixa-las quebradas
 * seria perder pagamento e travar caixa de cliente.
 *
 * Esta aqui e lida por GENTE, e encaminhar seria pior do que a tela de erro:
 * faria a configuracao errada FUNCIONAR. E servindo da raiz, o Apache alcanca
 * src/, includes/ e vendor/ -- o painel voltaria a expor o proprio codigo, que
 * e exatamente o que a mudanca para public/ veio fechar. Uma tela que explica
 * custa cinco minutos ao membro; um painel que funciona errado custa o resto.
 *
 * Some junto com as outras lapides, quando o atualizador aprender a remover
 * caminho que saiu do pacote. Ver docs/orfaos-do-move.md.
 */

http_response_code(503);
header('Content-Type: text/html; charset=utf-8');
header('Retry-After: 3600');

?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Painel Shield — falta um ajuste no servidor</title>
<style>
  body { font: 16px/1.6 system-ui, -apple-system, "Segoe UI", Arial, sans-serif;
         color: #1b2027; background: #f5f6f8; margin: 0; padding: 40px 20px; }
  main { max-width: 620px; margin: 0 auto; background: #fff; border: 1px solid #dde2e8;
         border-radius: 6px; padding: 32px 36px; }
  h1 { font-size: 22px; margin: 0 0 4px; }
  p.sub { color: #5b6675; margin: 0 0 24px; }
  code { background: #eef1f4; padding: 2px 6px; border-radius: 3px;
         font-family: ui-monospace, Consolas, monospace; font-size: 14px; }
  ol { padding-left: 20px; } li { margin-bottom: 10px; }
  .nota { margin-top: 26px; padding-top: 18px; border-top: 1px solid #e6eaee;
          color: #5b6675; font-size: 14px; }
</style>
</head>
<body>
<main>
  <h1>Falta um ajuste no servidor</h1>
  <p class="sub">Os arquivos estão no lugar, mas o servidor não está lendo o <code>.htaccess</code>.</p>

  <p>O painel se encaminha sozinho para a pasta <code>public/</code> por uma regra
  do <code>.htaccess</code> da raiz. Esta página só aparece quando o Apache está
  ignorando esse arquivo. Dois caminhos resolvem, e qualquer um serve:</p>

  <ol>
    <li><strong>Ligar o <code>.htaccess</code>:</strong> na configuração do domínio
        (ou pedindo à hospedagem), <code>AllowOverride All</code> para a pasta do
        painel. Em cPanel e Plesk isso já vem ligado.</li>
    <li><strong>Ou apontar o domínio para <code>public/</code>:</strong> em
        <strong>Domínios</strong> &rarr; <strong>Document Root</strong>, acrescente
        <code>/public</code> ao caminho atual. Exemplo: <code>/home/usuario/painel</code>
        passa a <code>/home/usuario/painel/public</code>.</li>
  </ol>
  <p>Depois, recarregue esta página.</p>

  <p class="nota">
    Enquanto isso, o recebimento de pagamentos e a validação de licença dos seus
    clientes <strong>continuam funcionando</strong> — os endereços que os
    gateways e o ERP usam foram preservados. O que está parado é só o acesso a
    estas telas.
  </p>
</main>
</body>
</html>
