<?php

namespace Shield\Email;

/**
 * Cliente SMTP minimo - 25/08/2026.
 *
 * Escrito a mao, e nao com biblioteca, por dois motivos concretos: o membro
 * sobe o painel por FTP com a pasta pronta e nao roda composer do outro lado; e
 * a alternativa sem biblioteca -- a funcao mail() do PHP -- entrega direto pelo
 * servidor da hospedagem, que e exatamente o remetente que cai em spam.
 *
 * COM AUTENTICACAO NO SERVIDOR DO PROPRIO MEMBRO, o e-mail sai do dominio dele,
 * assinado pelo provedor dele. E a diferenca entre a cobranca chegar e a
 * cobranca sumir.
 *
 * O QUE ELE NAO FAZ, de proposito: anexo, HTML com imagem embutida, lista de
 * destinatarios. Cobranca e aviso de licenca sao texto curto para uma pessoa.
 */
final class Smtp
{
    private const TEMPO = 20;

    /** @var string[] a conversa inteira, para o membro ver quando nao funciona */
    public array $conversa = array();

    public function __construct(
        private string $servidor,
        private int $porta = 587,
        private string $usuario = '',
        private string $senha = '',
        private string $seguranca = 'tls'
    ) {
    }

    private function linha($conexao): string
    {
        $texto = '';
        while (($pedaco = fgets($conexao, 515)) !== false) {
            $texto .= $pedaco;
            // Resposta de varias linhas usa "250-"; a ULTIMA usa "250 ". Ler so
            // a primeira faz o dialogo sair de sincronia uma resposta adiante,
            // e o erro aparece no comando seguinte, que estava certo.
            if (strlen($pedaco) < 4 || $pedaco[3] !== '-') {
                break;
            }
        }
        $this->conversa[] = '< ' . trim($texto);

        return $texto;
    }

    private function manda($conexao, string $comando, bool $segredo = false): void
    {
        $this->conversa[] = '> ' . ($segredo ? '(omitido)' : $comando);
        fwrite($conexao, $comando . "\r\n");
    }

    private function espera($conexao, string $comando, array $codigos, bool $segredo = false): void
    {
        if ($comando !== '') {
            $this->manda($conexao, $comando, $segredo);
        }
        $resposta = $this->linha($conexao);
        $codigo = substr(trim($resposta), 0, 3);

        if (!in_array($codigo, $codigos, true)) {
            throw new \RuntimeException('O servidor de e-mail respondeu: ' . trim($resposta));
        }
    }

    public function enviar(string $de, string $nomeDe, string $para, string $assunto, string $html): bool
    {
        $endereco = ($this->seguranca === 'ssl' ? 'ssl://' : '') . $this->servidor . ':' . $this->porta;

        $contexto = stream_context_create(array('ssl' => array(
            'verify_peer' => true,
            'verify_peer_name' => true,
        )));

        $conexao = @stream_socket_client($endereco, $erroN, $erroS, self::TEMPO,
                                         STREAM_CLIENT_CONNECT, $contexto);
        if ($conexao === false) {
            throw new \RuntimeException('Nao consegui conectar em ' . $endereco . ': ' . $erroS);
        }

        stream_set_timeout($conexao, self::TEMPO);

        try {
            $this->espera($conexao, '', array('220'));
            $eu = (string) ($_SERVER['HTTP_HOST'] ?? 'painel.shield');
            $this->espera($conexao, 'EHLO ' . $eu, array('250'));

            if ($this->seguranca === 'tls') {
                $this->espera($conexao, 'STARTTLS', array('220'));
                if (!stream_socket_enable_crypto($conexao, true,
                        STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                    throw new \RuntimeException('O servidor aceitou STARTTLS e a conexao segura falhou.');
                }
                // Depois do STARTTLS o dialogo recomeca: as capacidades de
                // antes nao valem mais, e servidor nenhum aceita AUTH sem isto.
                $this->espera($conexao, 'EHLO ' . $eu, array('250'));
            }

            if ($this->usuario !== '') {
                $this->espera($conexao, 'AUTH LOGIN', array('334'));
                $this->espera($conexao, base64_encode($this->usuario), array('334'), true);
                $this->espera($conexao, base64_encode($this->senha), array('235'), true);
            }

            $this->espera($conexao, 'MAIL FROM:<' . $de . '>', array('250'));
            $this->espera($conexao, 'RCPT TO:<' . $para . '>', array('250', '251'));
            $this->espera($conexao, 'DATA', array('354'));

            fwrite($conexao, $this->corpo($de, $nomeDe, $para, $assunto, $html));
            $this->espera($conexao, '.', array('250'));
            $this->espera($conexao, 'QUIT', array('221'));

            return true;
        } finally {
            @fclose($conexao);
        }
    }

    private function corpo(string $de, string $nomeDe, string $para, string $assunto, string $html): string
    {
        // Assunto com acento precisa ir codificado, senao chega embaralhado --
        // e "Sua mensalidade venceu" com acento quebrado ja parece golpe.
        $linhas = array(
            'From: =?UTF-8?B?' . base64_encode($nomeDe) . '?= <' . $de . '>',
            'To: <' . $para . '>',
            'Subject: =?UTF-8?B?' . base64_encode($assunto) . '?=',
            'Date: ' . date('r'),
            'MIME-Version: 1.0',
            'Content-Type: text/html; charset=UTF-8',
            'Content-Transfer-Encoding: base64',
            '',
            chunk_split(base64_encode($html), 76, "\r\n"),
        );

        $texto = implode("\r\n", $linhas);

        // Linha que comece com ponto seria lida como fim da mensagem. E a
        // regra mais antiga do SMTP e a que mais some em implementacao a mao.
        $texto = preg_replace('/^\./m', '..', $texto);

        // SEM o ponto final aqui: quem manda o "." e enviar(), pela espera()
        // que le a resposta dele. Ate 03/09/2026 o ponto ia nos dois lugares,
        // e o segundo chegava ao servidor como comando -- "500 Syntax error"
        // DEPOIS de a mensagem ja ter sido aceita. O painel via erro, a fila
        // marcava para tentar de novo, e o cliente recebia a cobranca em dobro.
        return $texto . "\r\n";
    }
}
