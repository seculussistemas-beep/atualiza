<?php

namespace Shield\Pdf;

/**
 * Um PDF de texto, escrito a mao -- 01/10/2026.
 *
 * O PAINEL NAO TEM BIBLIOTECA DE PDF, E NAO PODE TER. Ele nao carrega o
 * vendor/ em tempo de execucao (o membro sobe por FTP e nao roda composer;
 * ele so serve aos testes), e o que se precisa aqui e pouco: texto corrido em A4,
 * com titulo, negrito, quebra de linha, varias paginas e um rodape numerado.
 * Isso cabe em PDF 1.4 com as duas fontes que todo leitor ja traz
 * (Helvetica e Helvetica-Bold), sem embutir fonte nenhuma.
 *
 * O ACENTO VAI EM WinAnsiEncoding. O texto chega em UTF-8 e sai em
 * Windows-1252, que e o que a codificacao padrao dessas fontes entende; letra
 * fora dela vira "?" em vez de quebrar o arquivo. Por isso a largura de cada
 * caractere (para quebrar a linha no lugar certo) e a da tabela da Helvetica,
 * com a letra acentuada medida pela letra de base.
 *
 * FUNCAO PURA: nao le banco, nao le relogio a nao ser na data do arquivo, que
 * quem chama pode fixar. O mesmo texto da sempre o mesmo corpo de pagina.
 */
final class Documento
{
    private const LARGURA = 595.28;   // A4, em pontos
    private const ALTURA = 841.89;
    private const MARGEM = 56.0;
    private const RODAPE_Y = 30.0;

    /** Larguras da Helvetica, em milesimos do corpo, de 32 (espaco) a 126 (~). */
    private const LARGURAS_REGULAR = array(
        278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278,
        556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
        1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778,
        667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
        333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556,
        556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584,
    );

    /** As mesmas, da Helvetica-Bold. */
    private const LARGURAS_NEGRITO = array(
        278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278,
        556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 333, 333, 584, 584, 584, 611,
        975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778,
        667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556,
        333, 556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611,
        611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584,
    );

    /**
     * A letra acentuada do Windows-1252 medida pela letra de base. Diferenca de
     * largura entre "a" e "a" agudo e nenhuma na Helvetica.
     */
    private const BASE_ACENTUADA = array(
        192 => 'A', 193 => 'A', 194 => 'A', 195 => 'A', 196 => 'A', 197 => 'A', 199 => 'C',
        200 => 'E', 201 => 'E', 202 => 'E', 203 => 'E', 204 => 'I', 205 => 'I', 206 => 'I', 207 => 'I',
        209 => 'N', 210 => 'O', 211 => 'O', 212 => 'O', 213 => 'O', 214 => 'O',
        217 => 'U', 218 => 'U', 219 => 'U', 220 => 'U', 221 => 'Y',
        224 => 'a', 225 => 'a', 226 => 'a', 227 => 'a', 228 => 'a', 229 => 'a', 231 => 'c',
        232 => 'e', 233 => 'e', 234 => 'e', 235 => 'e', 236 => 'i', 237 => 'i', 238 => 'i', 239 => 'i',
        241 => 'n', 242 => 'o', 243 => 'o', 244 => 'o', 245 => 'o', 246 => 'o',
        249 => 'u', 250 => 'u', 251 => 'u', 252 => 'u', 253 => 'y', 255 => 'y',
    );

    /** @var list<array{fonte:string,corpo:float,texto:string,y:float}>[] as linhas de cada pagina */
    private array $paginas = array(array());
    private float $y;
    private string $titulo = '';
    private string $rodape = '';
    private ?string $quando = null;

    public function __construct()
    {
        $this->y = self::ALTURA - self::MARGEM;
    }

    /** O titulo do arquivo (aparece na aba do leitor) e a primeira linha, em negrito. */
    public function titulo(string $texto): self
    {
        $this->titulo = $texto;
        $this->escrever($texto, 'F2', 14.0, 20.0);
        $this->espaco(6.0);

        return $this;
    }

    /** Um subtitulo de clausula: negrito, com um respiro antes. */
    public function secao(string $texto): self
    {
        $this->espaco(6.0);
        $this->escrever($texto, 'F2', 11.0, 15.0);

        return $this;
    }

    /** Um paragrafo de texto corrido, quebrado na largura da pagina. */
    public function paragrafo(string $texto, bool $negrito = false, float $corpo = 10.0): self
    {
        $this->escrever($texto, $negrito ? 'F2' : 'F1', $corpo, $corpo * 1.4);

        return $this;
    }

    public function espaco(float $pontos): self
    {
        $this->y -= $pontos;

        return $this;
    }

    /** A linha que vai em toda pagina, ao lado de "Pagina X de Y". */
    public function rodape(string $texto): self
    {
        $this->rodape = $texto;

        return $this;
    }

    /** Fixa a data do arquivo (testes). Sem isto, agora. */
    public function quando(string $data): self
    {
        $this->quando = $data;

        return $this;
    }

    public function paginas(): int
    {
        return count($this->paginas);
    }

    /** O arquivo, pronto para mandar com Content-Type application/pdf. */
    public function gerar(): string
    {
        $objetos = array();
        $total = count($this->paginas);

        // 1 catalogo, 2 arvore de paginas, 3 e 4 as fontes, 5 a informacao; as
        // paginas vem depois, duas entradas cada (a pagina e o seu conteudo).
        $kids = array();
        for ($i = 0; $i < $total; $i++) {
            $kids[] = (6 + $i * 2) . ' 0 R';
        }
        $objetos[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $objetos[2] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . $total . ' >>';
        $objetos[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objetos[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        $data = 'D:' . date('YmdHis', $this->quando !== null ? strtotime($this->quando) : time());
        $objetos[5] = '<< /Title (' . self::escapar(self::winansi($this->titulo)) . ') /Producer (Painel Shield)'
            . ' /CreationDate (' . $data . ') >>';

        foreach ($this->paginas as $i => $linhas) {
            $fluxo = '';
            foreach ($linhas as $l) {
                $fluxo .= self::linhaDeTexto($l['fonte'], $l['corpo'], self::MARGEM, $l['y'], $l['texto']);
            }
            // "Pagina" com o acento pelo escape: o codigo segue sem acento (secao 5),
            // e o PDF sai com a palavra certa.
            $rotulo = "P\u{00E1}gina " . ($i + 1) . ' de ' . $total;
            if ($this->rodape !== '') {
                $fluxo .= self::linhaDeTexto('F1', 7.5, self::MARGEM, self::RODAPE_Y, self::winansi($this->rodape));
            }
            $larguraRotulo = self::largura(self::winansi($rotulo), 'F1', 7.5);
            $fluxo .= self::linhaDeTexto('F1', 7.5, self::LARGURA - self::MARGEM - $larguraRotulo, self::RODAPE_Y, self::winansi($rotulo));

            $pagina = 6 + $i * 2;
            $objetos[$pagina] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' . self::n(self::LARGURA) . ' ' . self::n(self::ALTURA) . ']'
                . ' /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ' . ($pagina + 1) . ' 0 R >>';
            $objetos[$pagina + 1] = '<< /Length ' . strlen($fluxo) . " >>\nstream\n" . $fluxo . "\nendstream";
        }

        // O comentario de bytes altos na segunda linha diz aos programas de
        // transferencia que o arquivo e binario -- o texto acentuado vai cru.
        $saida = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $deslocamentos = array();
        ksort($objetos);
        foreach ($objetos as $numero => $corpo) {
            $deslocamentos[$numero] = strlen($saida);
            $saida .= $numero . " 0 obj\n" . $corpo . "\nendobj\n";
        }

        $xref = strlen($saida);
        $tamanho = max(array_keys($objetos)) + 1;
        $saida .= "xref\n0 " . $tamanho . "\n0000000000 65535 f \n";
        for ($i = 1; $i < $tamanho; $i++) {
            $saida .= sprintf("%010d 00000 n \n", $deslocamentos[$i]);
        }
        $saida .= "trailer\n<< /Size " . $tamanho . " /Root 1 0 R /Info 5 0 R >>\nstartxref\n" . $xref . "\n%%EOF\n";

        return $saida;
    }

    // ---------------------------------------------------------------
    // Por dentro
    // ---------------------------------------------------------------

    /** Quebra o texto (UTF-8) em linhas e as poe na pagina, abrindo outra quando acaba. */
    private function escrever(string $texto, string $fonte, float $corpo, float $entrelinha): void
    {
        $util = self::LARGURA - 2 * self::MARGEM;
        foreach (self::quebrar(self::winansi($texto), $fonte, $corpo, $util) as $linha) {
            if ($this->y - $entrelinha < self::RODAPE_Y + 24) {
                $this->paginas[] = array();
                $this->y = self::ALTURA - self::MARGEM;
            }
            $this->y -= $entrelinha;
            $this->paginas[count($this->paginas) - 1][] = array(
                'fonte' => $fonte, 'corpo' => $corpo, 'texto' => $linha, 'y' => $this->y,
            );
        }
    }

    /**
     * Quebra pela palavra, e pela letra so quando uma palavra sozinha nao cabe
     * (um e-mail ou um hash comprido). Linha vazia continua sendo uma linha.
     *
     * @return list<string>
     */
    private static function quebrar(string $texto, string $fonte, float $corpo, float $util): array
    {
        $linhas = array();
        $atual = '';
        foreach (explode(' ', $texto) as $palavra) {
            $tentativa = $atual === '' ? $palavra : $atual . ' ' . $palavra;
            if (self::largura($tentativa, $fonte, $corpo) <= $util) {
                $atual = $tentativa;
                continue;
            }
            if ($atual !== '') {
                $linhas[] = $atual;
            }
            $atual = '';
            // A palavra sozinha nao cabe: corta pela letra.
            while (self::largura($palavra, $fonte, $corpo) > $util) {
                $corte = strlen($palavra) - 1;
                while ($corte > 1 && self::largura(substr($palavra, 0, $corte), $fonte, $corpo) > $util) {
                    $corte--;
                }
                $linhas[] = substr($palavra, 0, $corte);
                $palavra = substr($palavra, $corte);
            }
            $atual = $palavra;
        }
        $linhas[] = $atual;

        return $linhas;
    }

    /** A largura, em pontos, de um texto ja em Windows-1252. */
    private static function largura(string $texto, string $fonte, float $corpo): float
    {
        $tabela = $fonte === 'F2' ? self::LARGURAS_NEGRITO : self::LARGURAS_REGULAR;
        $soma = 0;
        $n = strlen($texto);
        for ($i = 0; $i < $n; $i++) {
            $c = ord($texto[$i]);
            if (isset(self::BASE_ACENTUADA[$c])) {
                $c = ord(self::BASE_ACENTUADA[$c]);
            }
            $soma += ($c >= 32 && $c <= 126) ? $tabela[$c - 32] : 556;
        }

        return $soma * $corpo / 1000;
    }

    private static function linhaDeTexto(string $fonte, float $corpo, float $x, float $y, string $texto): string
    {
        return 'BT /' . $fonte . ' ' . self::n($corpo) . ' Tf 1 0 0 1 ' . self::n($x) . ' ' . self::n($y)
            . ' Tm (' . self::escapar($texto) . ") Tj ET\n";
    }

    /** UTF-8 para Windows-1252; o que nao existe la vira "?". Quebra de linha vira espaco. */
    public static function winansi(string $texto): string
    {
        $texto = str_replace(array("\r\n", "\r", "\n", "\t"), ' ', $texto);
        $convertido = mb_convert_encoding($texto, 'Windows-1252', 'UTF-8');

        return is_string($convertido) ? $convertido : preg_replace('/[^\x20-\x7E]/', '?', $texto);
    }

    /** O que tem significado dentro de uma string PDF: a barra e os parenteses. */
    private static function escapar(string $texto): string
    {
        return strtr($texto, array(chr(92) => chr(92) . chr(92), '(' => chr(92) . '(', ')' => chr(92) . ')'));
    }

    /** Numero com ponto decimal, sem depender da localidade do servidor. */
    private static function n(float $v): string
    {
        return rtrim(rtrim(number_format($v, 2, '.', ''), '0'), '.');
    }
}
