<?php

namespace Shield\Cobranca;

/**
 * O token na URL do webhook, para quem nao assina o aviso -- 16/09/2026.
 *
 * Inter, C6, InfinitePay e Cora nao assinam o corpo nem mandam segredo em
 * cabecalho. Marcar o aviso como NAO conferido seria honesto, mas a fila
 * responde 401 ao nao conferido e NAO enfileira a verificacao: a Cora viveu
 * assim ate 17/09/2026, com a baixa dependendo so da conciliacao, e a
 * InfinitePay nem teria como, porque o payment_check exige dados que so
 * chegam no aviso.
 *
 * A saida e o segredo viajar na propria URL que o membro cola no portal
 * (`...?p=inter&t=<segredo>`). O endpoint o entrega ao adaptador como o
 * cabecalho sintetico `x-shield-token` -- sintetico porque vem da query, e
 * nunca de um cabecalho HTTP de verdade (shield_webhook_cabecalhos so o poe
 * a partir da QUERY_STRING). Confere so com segredo gravado E token presente
 * E igual; sem segredo gravado NADA confere, e nunca e true por padrao.
 */
final class TokenWebhook
{
    public const CABECALHO = 'x-shield-token';

    public static function confere(array $cabecalhos, array $conta): bool
    {
        $esperado = trim((string) ($conta['webhook_segredo'] ?? ''));
        $recebido = trim((string) ($cabecalhos[self::CABECALHO] ?? ''));

        return $esperado !== '' && $recebido !== '' && hash_equals($esperado, $recebido);
    }
}
