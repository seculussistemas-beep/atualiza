<?php

namespace Shield\Cobranca;

/**
 * Um webhook lido e normalizado - 25/08/2026.
 *
 * ELE NAO CARREGA SITUACAO DE PAGAMENTO, e isso e deliberado. O webhook diz
 * "olha esta cobranca"; quem diz se ela foi paga e o consultar() do provedor,
 * depois. Se este objeto trouxesse "paga", alguem em algum ponto usaria esse
 * campo para estender validade -- e ai bastaria um POST forjado para ganhar
 * meses de licenca.
 *
 * O `id` e a idempotencia: provedor reenvia, e reenvia fora de ordem. E ele que
 * a unicidade de webhook_evento usa.
 *
 * `idParaConsultar` (16/09/2026) existe para UM caso: o provedor cuja consulta
 * exige dados que so chegam no proprio aviso. A InfinitePay confirma pagamento
 * por `payment_check`, que pede `transaction_nsu` e `slug` -- e os dois nascem
 * no webhook. O `idExterno` continua sendo o que casa com a tentativa (o
 * order_nsu); este campo e o id COMPLETO, que a fila grava na tentativa antes
 * de enfileirar a verificacao, para o consultar() seguinte ter o que perguntar.
 * Vazio para todo provedor que consulta pelo id de sempre. Continua nao
 * movendo dinheiro: so muda COM QUE ID se pergunta ao provedor.
 */
final class EventoWebhook
{
    public function __construct(
        public readonly string $id,
        public readonly string $tipo,
        public readonly string $idExterno,
        public readonly bool $assinaturaConfere,
        public readonly string $corpo = '',
        public readonly string $idParaConsultar = ''
    ) {
    }
}
