<?php

namespace Shield\Cobranca;

/**
 * O caminho de volta da credencial que MUDA SOZINHA -- 16/09/2026.
 *
 * Ate aqui a credencial so andava num sentido: o membro digita, o painel
 * cifra e guarda, o adaptador le. O Conta Azul quebra isso: o token e OAuth2
 * e o refresh_token ROTACIONA a cada renovacao -- o antigo morre na hora
 * ("invalid_refresh_token: ja foi utilizado"). Se o adaptador renovasse e
 * ninguem gravasse o par novo, a proxima requisicao ja nasceria com um
 * refresh morto e o membro teria de autorizar de novo no navegador a cada
 * hora. O mesmo vale para o id do servico que o adaptador cria uma vez no
 * Conta Azul e nao quer procurar pelo nome em toda emissao.
 *
 * O adaptador NAO conhece PDO nem a tabela: ele entrega o delta por aqui e o
 * painel liga o gancho onde tem banco (shield_cobranca_ligar_renovacao, no
 * motor). Sem o gancho ligado -- a suite, ou um caminho que esqueceu de
 * ligar -- o adaptador continua funcionando dentro da requisicao, com o par
 * novo em memoria; o que se perde e a persistencia, nunca a chamada.
 */
final class Credenciais
{
    /** @var null|callable(int,array):void */
    private static $aoRenovar = null;

    /**
     * Liga (ou desliga, com null) quem grava o delta. Um so: o ultimo a ligar
     * vale, e e assim de proposito -- e sempre o mesmo gravador com o PDO da
     * requisicao corrente.
     *
     * @param null|callable(int,array):void $gravador
     */
    public static function aoRenovar(?callable $gravador): void
    {
        self::$aoRenovar = $gravador;
    }

    /**
     * O adaptador avisa: estas chaves das credenciais da conta $contaId mudaram.
     * So as chaves do delta; o resto fica como esta.
     *
     * @param array<string,string> $delta
     */
    public static function renovadas(int $contaId, array $delta): void
    {
        if (self::$aoRenovar === null || $delta === array()) {
            return;
        }
        (self::$aoRenovar)($contaId, $delta);
    }
}
