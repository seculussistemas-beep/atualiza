<?php

namespace Shield\Cobranca;

/**
 * Monta o copia-e-cola do PIX estatico - 25/08/2026.
 *
 * E o formato EMV(R) QRCPS do Banco Central: campos no molde
 * ID + TAMANHO(2 digitos) + VALOR, encadeados, com o CRC16 no fim.
 *
 * DUAS COISAS QUEBRAM ISTO EM SILENCIO, e as duas ja quebraram implementacao
 * de outra gente:
 *
 *   O TAMANHO E EM BYTES, com dois digitos e zero a esquerda. Nome com acento
 *   ocupa dois bytes e um digito a mais: contar caractere no lugar de byte
 *   gera um codigo que o aplicativo do banco recusa sem dizer por que. Por
 *   isso os campos de texto saem sem acento e em maiusculas -- e tambem porque
 *   e o que a especificacao pede para nome e cidade.
 *
 *   O CRC E CALCULADO SOBRE O PROPRIO "6304" ja concatenado. Calcular antes de
 *   acrescentar o cabecalho do campo 63 da um codigo que parece certo, tem o
 *   tamanho certo, e nao passa na conferencia do banco.
 */
final class Brcode
{
    /**
     * O maior tamanho de chave no DICT (o e-mail, 77). Acima dele o campo 01 teria
     * tres digitos de tamanho, e o codigo inteiro deixaria de ser lido.
     */
    public const CHAVE_MAXIMO = 77;

    /**
     * Letra acentuada para a letra sem acento, POR TABELA -- 17/09/2026. O iconv
     * //TRANSLIT depende do locale do processo: com o locale C ele devolve "?" no
     * lugar da letra, o filtro de caracteres apagava o "?", e "Sao Paulo" com til
     * saia "SO PAULO". O painel nunca chama setlocale, e hospedagem sem C.UTF-8 cai
     * no C.
     */
    private const ACENTOS = array(
        "\u{E1}" => 'a', "\u{E0}" => 'a', "\u{E2}" => 'a', "\u{E3}" => 'a', "\u{E4}" => 'a', "\u{E5}" => 'a',
        "\u{C1}" => 'A', "\u{C0}" => 'A', "\u{C2}" => 'A', "\u{C3}" => 'A', "\u{C4}" => 'A', "\u{C5}" => 'A',
        "\u{E9}" => 'e', "\u{E8}" => 'e', "\u{EA}" => 'e', "\u{EB}" => 'e',
        "\u{C9}" => 'E', "\u{C8}" => 'E', "\u{CA}" => 'E', "\u{CB}" => 'E',
        "\u{ED}" => 'i', "\u{EC}" => 'i', "\u{EE}" => 'i', "\u{EF}" => 'i',
        "\u{CD}" => 'I', "\u{CC}" => 'I', "\u{CE}" => 'I', "\u{CF}" => 'I',
        "\u{F3}" => 'o', "\u{F2}" => 'o', "\u{F4}" => 'o', "\u{F5}" => 'o', "\u{F6}" => 'o',
        "\u{D3}" => 'O', "\u{D2}" => 'O', "\u{D4}" => 'O', "\u{D5}" => 'O', "\u{D6}" => 'O',
        "\u{FA}" => 'u', "\u{F9}" => 'u', "\u{FB}" => 'u', "\u{FC}" => 'u',
        "\u{DA}" => 'U', "\u{D9}" => 'U', "\u{DB}" => 'U', "\u{DC}" => 'U',
        "\u{E7}" => 'c',
        "\u{C7}" => 'C',
        "\u{F1}" => 'n',
        "\u{D1}" => 'N',
        "\u{FD}" => 'y', "\u{FF}" => 'y',
        "\u{DD}" => 'Y',
    );

    /** Um campo: identificador, tamanho em BYTES com dois digitos, valor. */
    private static function campo(string $id, string $valor): string
    {
        return $id . str_pad((string) strlen($valor), 2, '0', STR_PAD_LEFT) . $valor;
    }

    /**
     * Tira acento, corta no limite e sobe para maiuscula.
     *
     * O corte vem DEPOIS de tirar o acento: cortar antes poderia partir um
     * caractere de dois bytes ao meio e produzir byte solto no meio do codigo.
     */
    private static function texto(string $valor, int $limite): string
    {
        $limpo = preg_replace('/[^A-Za-z0-9 .\-]/', '', strtr($valor, self::ACENTOS));
        $limpo = trim(preg_replace('/\s+/', ' ', (string) $limpo));

        return strtoupper(rtrim(substr($limpo, 0, $limite)));
    }

    /**
     * O txid do PIX estatico: so letras e numeros, ate 25 (Manual de Padroes para
     * Iniciacao do Pix, 2.6.2). O texto() deixava passar espaco, ponto e hifen.
     */
    private static function referencia(string $txid): string
    {
        $limpo = (string) preg_replace('/[^A-Za-z0-9]/', '', strtr($txid, self::ACENTOS));

        return strtoupper(substr($limpo, 0, 25));
    }

    /**
     * A chave como o DICT a guarda -- 17/09/2026. O servidor so fazia trim, e a
     * mascara da tela so roda com o tipo da chave escolhido: "123.456.789-09",
     * "(48) 99999-8888" e e-mail com maiuscula montavam um codigo com CRC certo e
     * uma chave que o banco nao acha. CPF e CNPJ so com digitos, celular com +55,
     * e-mail e aleatoria em minuscula, CNPJ alfanumerico em maiuscula. O que nao
     * se reconhece vai como veio.
     *
     * ONZE DIGITOS SOLTOS SAO CPF SO SE O DIGITO VERIFICADOR FECHA; senao, celular
     * sem o +55. Com parenteses ou com +, e telefone sempre.
     */
    public static function chave(string $chave): string
    {
        $chave = trim($chave);
        if ($chave === '' || strpos($chave, '@') !== false) {
            return strtolower($chave);
        }
        if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $chave)) {
            return strtolower($chave);
        }
        $alfanumerico = strtoupper((string) preg_replace('/[.\/-]/', '', $chave));
        if (preg_match('/[A-Za-z]/', $chave) && preg_match('/^[0-9A-Z]{12}[0-9]{2}$/', $alfanumerico)) {
            return $alfanumerico;
        }
        if (!preg_match('/^[0-9+().\/\s-]+$/', $chave)) {
            return $chave;
        }

        $digitos = (string) preg_replace('/[^0-9]/', '', $chave);
        if (strpos($chave, '+') === 0) {
            return '+' . $digitos;
        }
        $telefone = strpbrk($chave, '()') !== false;
        if (!$telefone && strlen($digitos) === 14) {
            return $digitos;
        }
        if (!$telefone && strlen($digitos) === 11 && self::cpfValido($digitos)) {
            return $digitos;
        }
        if (strlen($digitos) === 10 || strlen($digitos) === 11) {
            return '+55' . $digitos;
        }
        if ((strlen($digitos) === 12 || strlen($digitos) === 13) && strncmp($digitos, '55', 2) === 0) {
            return '+' . $digitos;
        }

        return $chave;
    }

    private static function cpfValido(string $digitos): bool
    {
        if (!preg_match('/^[0-9]{11}$/', $digitos) || count(array_unique(str_split($digitos))) === 1) {
            return false;
        }
        for ($posicao = 9; $posicao < 11; $posicao++) {
            $soma = 0;
            for ($i = 0; $i < $posicao; $i++) {
                $soma += (int) $digitos[$i] * ($posicao + 1 - $i);
            }
            if ((int) $digitos[$posicao] !== ((10 * $soma) % 11) % 10) {
                return false;
            }
        }

        return true;
    }

    /** CRC-16/CCITT-FALSE: polinomio 0x1021, inicial 0xFFFF, sem reflexao. */
    public static function crc16(string $dados): string
    {
        $crc = 0xFFFF;
        $tamanho = strlen($dados);

        for ($i = 0; $i < $tamanho; $i++) {
            $crc ^= ord($dados[$i]) << 8;
            for ($bit = 0; $bit < 8; $bit++) {
                $crc = ($crc & 0x8000) ? (($crc << 1) ^ 0x1021) : ($crc << 1);
                $crc &= 0xFFFF;
            }
        }

        return strtoupper(str_pad(dechex($crc), 4, '0', STR_PAD_LEFT));
    }

    /**
     * @param string $chave     a chave PIX do membro
     * @param int    $centavos  0 = codigo sem valor, o pagador digita
     * @param string $txid      ate 25 caracteres; vazio vira ***
     */
    public static function montar(
        string $chave,
        string $nome,
        string $cidade,
        int $centavos = 0,
        string $txid = ''
    ): string {
        $chave = self::chave($chave);
        if ($chave === '') {
            throw new \RuntimeException('Sem chave PIX nao ha copia-e-cola.');
        }
        if (strlen($chave) > self::CHAVE_MAXIMO) {
            throw new \RuntimeException('A chave PIX tem mais de ' . self::CHAVE_MAXIMO
                . ' caracteres, o maximo do DICT. Confira a chave gravada em Formas de recebimento.');
        }

        $conta = self::campo('00', 'br.gov.bcb.pix') . self::campo('01', $chave);

        $carga = self::campo('00', '01')
            . self::campo('26', $conta)
            . self::campo('52', '0000')
            . self::campo('53', '986');

        if ($centavos > 0) {
            // Valor SEMPRE com ponto e duas casas -- virgula nao existe aqui.
            $carga .= self::campo('54', number_format($centavos / 100, 2, '.', ''));
        }

        $carga .= self::campo('58', 'BR')
            . self::campo('59', self::texto($nome, 25) ?: 'RECEBEDOR')
            . self::campo('60', self::texto($cidade, 15) ?: 'BRASIL');

        $referencia = self::referencia($txid);
        $carga .= self::campo('62', self::campo('05', $referencia !== '' ? $referencia : '***'));

        // O "6304" entra na conta do CRC. Calcular sem ele produz um codigo que
        // parece certo e o banco recusa.
        $carga .= '6304';

        return $carga . self::crc16($carga);
    }
}
