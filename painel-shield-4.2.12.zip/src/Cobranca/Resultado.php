<?php

namespace Shield\Cobranca;

/**
 * O que um provedor devolve ao emitir ou consultar - 25/08/2026.
 *
 * A SITUACAO AQUI E A NOSSA, ja traduzida. Cada provedor tem o vocabulario
 * dele -- CONFIRMED, RECEIVED, paid, approved -- e deixar esse vocabulario
 * vazar para o motor faria a regra de negocio conhecer cada gateway, que e
 * exatamente o que esta interface existe para evitar.
 *
 * A palavra crua do provedor NAO se perde: vai em `situacaoProvedor`, e o
 * retorno inteiro vai em `bruto`. E o que responde "o que ele disse mesmo"
 * seis meses depois.
 */
final class Resultado
{
    /** As unicas situacoes que o motor entende. */
    public const ABERTA = 'aberta';
    public const PAGA = 'paga';
    public const VENCIDA = 'vencida';
    public const CANCELADA = 'cancelada';
    public const ESTORNADA = 'estornada';
    /** O provedor respondeu algo que nao sabemos ler. NAO e pago. */
    public const INDEFINIDA = 'indefinida';

    public function __construct(
        public readonly string $situacao,
        public readonly string $idExterno = '',
        public readonly string $situacaoProvedor = '',
        public readonly string $link = '',
        public readonly string $copiaECola = '',
        public readonly ?int $valorPagoCentavos = null,
        public readonly ?string $pagoEm = null,
        public readonly string $metodo = '',
        public readonly string $bruto = '',
        /**
         * A linha digitavel do boleto, so digitos -- 17/09/2026. Mora aqui, e nao
         * em `copiaECola`, porque o boleto hibrido tem os dois: o copia e cola e o
         * PIX (o ERP o desenha como QR) e a linha e o que se digita no banco. No
         * boleto sem PIX o copia e cola continua levando a linha, como sempre, para
         * quem so le aquele campo. Ver Shield\Cobranca\CodigoDePagamento.
         */
        public readonly string $linhaDigitavel = ''
    ) {
    }

    /**
     * Situacao que o provedor nao soube explicar NAO conta como nada.
     *
     * Na duvida entre "pago" e "nao sei", e "nao sei" -- estender validade
     * exige prova, e resposta que a gente nao sabe ler nao e prova.
     */
    public function conclusiva(): bool
    {
        return $this->situacao !== self::INDEFINIDA;
    }
}
