<?php

namespace Shield\Cobranca;

/**
 * O telefone do cliente do jeito que os gateways pedem -- 17/09/2026.
 *
 * O cadastro guarda o numero em `empresa.fone` (o que veio do ERP) e, desde o
 * fechamento, em `financeiro_fone` e `responsavel_fone`. O Asaas procurava
 * `telefone`, coluna que a empresa nunca teve, e o cliente nascia la sem celular.
 * O PIX do Pagar.me exige telefone, e o guia do PIX do PagBank o pede: a leitura
 * mora aqui para os tres nao divergirem, como o Endereco.
 *
 * A LIMPEZA E A DE shield_telefone, que formata o mesmo campo nas listas: o 55 do
 * pais so sai quando sobram digitos (DDD 55 existe), o zero da operadora sai, e
 * 0800 nao tem DDD. O que nao vira DDD e numero volta null -- gateway nenhum
 * recebe telefone inventado.
 */
final class Telefone
{
    /** Quem cuida do financeiro vem primeiro: e quem o gateway avisa do pagamento. */
    private const CAMPOS = array('financeiro_fone', 'fone', 'responsavel_fone');

    /** @return array{ddd:string,numero:string,celular:bool}|null */
    public static function de(array $cliente): ?array
    {
        foreach (self::CAMPOS as $campo) {
            $lido = self::ler((string) ($cliente[$campo] ?? ''));
            if ($lido !== null) {
                return $lido;
            }
        }

        return null;
    }

    /** @return array{ddd:string,numero:string,celular:bool}|null */
    private static function ler(string $valor): ?array
    {
        $so = (string) preg_replace('/\D/', '', $valor);
        if (preg_match('/^0[3589]00/', $so)) {
            return null;
        }
        if ((strlen($so) === 12 || strlen($so) === 13) && strpos($so, '55') === 0) {
            $so = substr($so, 2);
        } elseif ((strlen($so) === 11 || strlen($so) === 12) && $so[0] === '0') {
            $so = substr($so, 1);
        }
        if ((strlen($so) !== 10 && strlen($so) !== 11) || $so[0] === '0') {
            return null;
        }

        return array(
            'ddd' => substr($so, 0, 2),
            'numero' => substr($so, 2),
            'celular' => strlen($so) === 11 && $so[2] === '9',
        );
    }
}
