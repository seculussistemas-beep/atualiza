<?php

namespace Shield\Cobranca;

/**
 * Ate quando o codigo de pagamento vale - 11/09/2026.
 *
 * O prazo saia do vencimento da cobranca, direto, em todos os adaptadores. E a
 * cobranca VENCIDA e justamente a que se reemite: a reemissao cancela o codigo
 * antigo no provedor e pede um novo com um vencimento que ja passou.
 *
 * O sintoma mudava de provedor para provedor, e nenhum era bom. A Efi tinha um
 * piso de uma hora, entao entregava um PIX que morria antes de o membro mandar
 * pelo WhatsApp -- silencioso, ninguem percebia. Pagar.me, PagBank e Mercado
 * Pago mandavam a data passada e a API recusava a criacao: a excecao subia e
 * era engolida pelo contador de falhas da regua, e o cliente ficava sem codigo
 * nenhum, com o valor ja atualizado com multa no banco.
 *
 * O PISO E DE TRES DIAS porque ja era "o padrao da casa", escrito na Efi para a
 * cobranca sem vencimento. Ele so LEVANTA: vencimento la na frente continua
 * mandando, porque o codigo tem de morrer junto com a fatura que ele cobra.
 */
final class Prazo
{
    /** Tres dias. E o tempo de mandar o codigo e o cliente pagar. */
    public const DIAS_MINIMOS = 3;

    /**
     * O fim do prazo: o vencimento (no fim do dia), ou hoje mais o piso quando
     * ele ja passou -- ou nem existe.
     */
    public static function fim(string $vencimento, ?\DateTimeImmutable $agora = null): \DateTimeImmutable
    {
        $agora = $agora ?: new \DateTimeImmutable('now');
        $piso = $agora->modify('+' . self::DIAS_MINIMOS . ' days');

        $vencimento = trim($vencimento);
        if ($vencimento === '') {
            return $piso;
        }

        $fim = date_create_immutable($vencimento . ' 23:59:59');
        if ($fim === false) {
            return $piso;
        }

        return $fim > $piso ? $fim : $piso;
    }

    /** O mesmo prazo contado a partir de agora, em segundos (a Efi pede assim). */
    public static function segundos(string $vencimento, ?\DateTimeImmutable $agora = null): int
    {
        $agora = $agora ?: new \DateTimeImmutable('now');

        return max(1, self::fim($vencimento, $agora)->getTimestamp() - $agora->getTimestamp());
    }
}
