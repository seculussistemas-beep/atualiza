<?php

namespace Shield\Cobranca;

/**
 * A ida a rede, num lugar so - 25/08/2026.
 *
 * Todo adaptador de provedor fala com o mundo por aqui. Ter um ponto so nao e
 * arrumacao: e o que permite dar timeout curto, exigir TLS de verdade e
 * devolver o corpo CRU para ser guardado -- em todos os provedores, sem depender
 * de cada adaptador lembrar.
 *
 * O CORPO VOLTA SEMPRE, inclusive no erro. E ele que responde "o que o gateway
 * disse mesmo" seis meses depois, e e ele que vai para a coluna de retorno da
 * tentativa. Adaptador que so devolvesse a mensagem tratada perderia
 * exatamente o campo que faltava.
 *
 * NENHUM ADAPTADOR ABRE cURL PROPRIO (16/09/2026). O pacote do Inter e do C6
 * vinha com um cURL a parte para o token OAuth, porque ele vai em formulario
 * e nao em JSON; por fora deste ponto a suite nao alcancava, e foi por fora
 * dele que o "Empty reply from server" do Inter viveu ate alguem forcar
 * HTTP/1.1 a mao. O corpo em formulario passou a ser decidido aqui, pelo
 * cabecalho que o adaptador manda (ver corpo()), e o HTTP/1.1 vale para todos.
 */
final class Http
{
    /** Curto de proposito: a tela do membro espera esta chamada. */
    public const SEGUNDOS = 25;

    /**
     * O unico ponto em que a suite entra -- 03/09/2026.
     *
     * NADA NO PAINEL CHAMA ISTO. Em producao vale sempre o cURL abaixo; este
     * campo so sai de null quando um teste o troca, e o proprio teste o
     * devolve para null no fim.
     *
     * Existe porque a alternativa era pior: sem ele, os oito adaptadores de
     * provedor so poderiam ser exercitados indo na rede, e teste que depende
     * de sandbox de terceiro falha quando o terceiro cai -- ate ninguem mais
     * olhar o vermelho. Com o ponto de troca, cada adaptador e conferido
     * contra respostas gravadas, INCLUSIVE as que nao se consegue pedir a um
     * gateway sob demanda: 401, 500, corpo que nao e JSON, rede que nao
     * responde.
     *
     * @var null|callable(string,string,array,?array,?string):array
     */
    private static $transporte = null;

    /**
     * Troca a ida a rede por outra coisa. So para teste; passe null para
     * devolver o cURL.
     *
     * @param null|callable(string,string,array,?array,?string):array $transporte
     */
    public static function usarTransporte(?callable $transporte): void
    {
        self::$transporte = $transporte;
    }

    /**
     * O corpo e o content-type que vao na chamada -- 16/09/2026.
     *
     * JSON, como sempre, a nao ser que o adaptador ja tenha posto o
     * content-type de FORMULARIO nos cabecalhos: ai a carga vai como
     * query-string (RFC 3986, espaco vira %20 -- e o que o token do Inter e do
     * C6 pedem) e nenhum segundo content-type e acrescentado. A carga chega
     * como array nos dois casos, entao o transporte da suite intercepta igual.
     *
     * @return array{corpo:?string,cabecalhos:array}
     */
    public static function corpo(array $cabecalhos, ?array $carga): array
    {
        if ($carga === null) {
            return array('corpo' => null, 'cabecalhos' => $cabecalhos);
        }

        foreach ($cabecalhos as $linha) {
            if (preg_match('#^content-type:\s*application/x-www-form-urlencoded#i', trim((string) $linha))) {
                return array(
                    'corpo' => http_build_query($carga, '', '&', PHP_QUERY_RFC3986),
                    'cabecalhos' => $cabecalhos,
                );
            }
        }

        $cabecalhos[] = 'Content-Type: application/json';

        return array(
            'corpo' => json_encode($carga, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'cabecalhos' => $cabecalhos,
        );
    }

    /**
     * @param array   $cabecalhos linhas prontas, no formato "Nome: valor"
     * @param ?string $certificadoPem certificado + chave em PEM, para os
     *                provedores que exigem mTLS (Efi, Inter e C6). Nulo
     *                mantem a chamada de sempre.
     * @return array{codigo:int,corpo:string,json:?array,erro:string}
     */
    public static function json(string $metodo, string $url, array $cabecalhos = array(), ?array $carga = null, ?string $certificadoPem = null): array
    {
        if (self::$transporte !== null) {
            return (self::$transporte)($metodo, $url, $cabecalhos, $carga, $certificadoPem);
        }

        $montado = self::corpo($cabecalhos, $carga);
        $corpo = $montado['corpo'];
        $cabecalhos = $montado['cabecalhos'];

        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_CUSTOMREQUEST => strtoupper($metodo),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $cabecalhos,
            CURLOPT_TIMEOUT => self::SEGUNDOS,
            CURLOPT_CONNECTTIMEOUT => 10,
            // Nao desligar: e dinheiro atravessando a rede. Certificado que nao
            // valida e um homem no meio esperando para acontecer.
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => false,
            // HTTP/1.1 SEMPRE (16/09/2026): a API do Inter responde "Empty
            // reply from server" quando o cURL negocia h2, e o sintoma parece
            // rede caida. Nenhum dos outros provedores perde nada com 1.1.
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        ));
        if ($corpo !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $corpo);
        }

        // O CERTIFICADO PRECISA SER ARQUIVO -- o cURL nao aceita o PEM em
        // memoria. Ele nasce com permissao so do dono e e apagado no finally
        // mesmo que a chamada estoure: certificado esquecido em disco e a
        // credencial mais cara que este painel guarda.
        $arquivoCert = null;
        if ($certificadoPem !== null && trim($certificadoPem) !== '') {
            $arquivoCert = tempnam(sys_get_temp_dir(), 'shield_cert_');
            if ($arquivoCert === false) {
                curl_close($ch);

                return array('codigo' => 0, 'corpo' => '', 'json' => null,
                             'erro' => 'nao consegui preparar o certificado desta conta');
            }
            @chmod($arquivoCert, 0600);
            file_put_contents($arquivoCert, $certificadoPem);
            curl_setopt($ch, CURLOPT_SSLCERT, $arquivoCert);
            curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM');
            // A chave no MESMO arquivo, dita explicitamente: o PEM traz
            // certificado e chave colados, e o cURL acha a chave sozinho na
            // maioria das builds -- mas nao em todas (o membro do Inter viu o
            // handshake falhar sem esta linha).
            curl_setopt($ch, CURLOPT_SSLKEY, $arquivoCert);
            curl_setopt($ch, CURLOPT_SSLKEYTYPE, 'PEM');
        }

        try {
            $resposta = curl_exec($ch);
            $falha = curl_error($ch);
            $codigo = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        } finally {
            curl_close($ch);
            if ($arquivoCert !== null) {
                @unlink($arquivoCert);
            }
        }

        if ($resposta === false) {
            return array('codigo' => 0, 'corpo' => '', 'json' => null,
                         'erro' => 'nao consegui falar com o provedor: ' . $falha);
        }

        $json = json_decode((string) $resposta, true);

        return array(
            'codigo' => $codigo,
            'corpo' => (string) $resposta,
            'json' => is_array($json) ? $json : null,
            'erro' => '',
        );
    }
}
