<?php

namespace Shield\Cobranca;

/**
 * O que todo provedor de cobranca sabe fazer - 25/08/2026.
 *
 * Esta interface e o que permite acrescentar provedor SEM TOCAR EM NENHUMA
 * TABELA: a cobranca guarda valor, vencimento e situacao, e o provedor mora
 * na tentativa. Gateway, PIX estatico e dinheiro em especie entram todos por
 * aqui -- o que muda entre eles e quem confirma o pagamento, nao o formato.
 *
 * CAPACIDADES SAO DECLARADAS, NAO PRESUMIDAS. A tela oferece o que aquela
 * conta suporta, em vez de deixar o membro descobrir no erro depois de montar
 * a cobranca.
 *
 * A SITUACAO QUE MANDA E A DO consultar(). O webhook DISPARA a verificacao; ele
 * nao a substitui. Nenhuma implementacao desta interface pode estender validade
 * ou mover dinheiro so porque um webhook chegou dizendo que sim.
 */
interface Provedor
{
    /** O identificador curto, igual ao gravado em conta_recebimento.provedor. */
    public function nome(): string;

    /**
     * O que ESTA conta suporta.
     *
     * @param array $conta linha de conta_recebimento, ja com credenciais lidas
     * @return array{pix:bool,boleto:bool,cartao:bool,assinatura:bool,automatico:bool}
     */
    public function capacidades(array $conta): array;

    /**
     * Emite a cobranca no provedor.
     *
     * @param array $cobranca linha de `cobranca` (valor_centavos, vencimento, ...)
     * @param array $conta    linha de conta_recebimento
     * @param array $cliente  linha de `empresa` -- quem vai pagar
     * @return Resultado
     * @throws \RuntimeException quando o provedor recusa ou nao responde
     */
    public function criar(array $cobranca, array $conta, array $cliente): Resultado;

    /**
     * Pergunta ao provedor qual e a situacao. E A FONTE DA VERDADE.
     *
     * @throws \RuntimeException
     */
    public function consultar(string $idExterno, array $conta): Resultado;

    /** Cancela no provedor. Devolve false quando ele nao suporta cancelar. */
    public function cancelar(string $idExterno, array $conta): bool;

    /**
     * Le o corpo do webhook e diz o que ele significa -- e se a assinatura
     * confere. Devolve null quando o corpo nao e deste provedor.
     */
    public function lerWebhook(string $corpo, array $cabecalhos, array $conta): ?EventoWebhook;
}
