<?php

namespace Shield\Cobranca;

/**
 * O endereco do cliente do jeito que boleto pede -- 10/09/2026, tarde.
 *
 * O cadastro guarda "Rua das Flores, 120" num campo so, e as tres APIs que
 * emitem boleto (Mercado Pago, PagBank, Pagar.me) exigem rua e numero em
 * campos separados, com CEP so digitos e UF em duas letras. Esta classe faz
 * essa leitura num lugar so, para os tres adaptadores nao divergirem no dia
 * em que alguem ajustar um deles.
 *
 * Sem numero no cadastro vai "S/N": os provedores aceitam, e recusar a
 * emissao por isso seria pior do que um boleto com S/N.
 */
final class Endereco
{
    /** @return array{cep:string,rua:string,numero:string,bairro:string,cidade:string,uf:string} */
    public static function de(array $cliente): array
    {
        $linha = trim((string) ($cliente['endereco'] ?? ''));
        $rua = $linha;
        $numero = '';
        if (preg_match('/^(.*?)[,\s]+(?:n[º°o]?\.?\s*)?(\d+[A-Za-z]?)\s*$/u', $linha, $m)) {
            $rua = trim($m[1], " ,");
            $numero = $m[2];
        }

        return array(
            'cep' => preg_replace('/\D+/', '', (string) ($cliente['cep'] ?? '')),
            'rua' => $rua !== '' ? $rua : 'Sem endereco',
            'numero' => $numero !== '' ? $numero : 'S/N',
            'bairro' => trim((string) ($cliente['bairro'] ?? '')) ?: 'Centro',
            'cidade' => trim((string) ($cliente['cidade'] ?? '')) ?: 'Cidade',
            'uf' => strtoupper(substr(trim((string) ($cliente['uf'] ?? '')), 0, 2)) ?: 'SP',
        );
    }

    /** "Nome Sobrenome" -> [nome, sobrenome]: o Mercado Pago pede os dois. */
    public static function nomeEmDois(string $nome): array
    {
        $partes = preg_split('/\s+/', trim($nome)) ?: array();
        $primeiro = (string) array_shift($partes);

        return array($primeiro !== '' ? $primeiro : 'Cliente', $partes ? implode(' ', $partes) : 'Ltda');
    }
}
