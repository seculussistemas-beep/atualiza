<?php

namespace Shield\Cobranca\Provedores;

use Shield\Cobranca\CodigoDePagamento;
use Shield\Cobranca\EventoWebhook;
use Shield\Cobranca\Http;
use Shield\Cobranca\Prazo;
use Shield\Cobranca\Provedor;
use Shield\Cobranca\Resultado;
use Shield\Cobranca\Telefone;

/**
 * Asaas - 25/08/2026.
 *
 * O primeiro gateway completo, e o escolhido por um motivo pratico: PIX, boleto
 * e cartao recorrente numa conta so, e ja havia integracao no painel velho com
 * dinheiro de verdade rodando por ela.
 *
 * ESTE ADAPTADOR FOI ESCRITO LENDO O CODIGO VELHO, nao a documentacao. O que
 * estava naquelas 2.113 linhas nao e a API -- e o conhecimento de campo: que o
 * cliente precisa existir antes da cobranca e se procura por cpfCnpj, que o
 * erro vem em `errors[].description` e nao em `message`, que o vocabulario de
 * situacao tem oito palavras e nem todas significam o que parecem.
 *
 * A TRADUCAO DE SITUACAO E O CORACAO DISTO, e ela e conservadora: o que nao
 * esta explicitamente na lista de pago NAO E PAGO. RECEIVED_WITHOUT_INTEGRATION
 * -- dinheiro que entrou fora do Asaas -- fica de fora de proposito: e o membro
 * quem confirma esse, pela via manual, que e auditada.
 */
final class Asaas implements Provedor
{
    public function nome(): string
    {
        return 'asaas';
    }

    public function capacidades(array $conta): array
    {
        // O QUE O PROVEDOR FAZ, e nao o que a conta marcou -- 10/09/2026,
        // tarde. As tres formas saem pela mesma API de pagamentos (conferido
        // no sandbox: PIX, boleto e cartao emitidos e cancelados). Os flags da
        // conta viviam desligados por padrao e escondiam formas que funcionam.
        return array(
            'pix' => true,
            'boleto' => true,
            'cartao' => true,
            'assinatura' => (bool) ($conta['aceita_assinatura'] ?? 1),
            'automatico' => true,
        );
    }

    private function base(array $conta): string
    {
        // O HOST DE SANDBOX E O DA DOCUMENTACAO ATUAL (docs.asaas.com/docs/sandbox,
        // conferido em 17/09/2026). O sandbox.asaas.com/api/v3 de antes e o
        // endereco antigo, que so seguia respondendo por compatibilidade.
        return ((string) ($conta['ambiente'] ?? 'producao')) === 'producao'
            ? 'https://api.asaas.com/v3'
            : 'https://api-sandbox.asaas.com/v3';
    }

    private function cabecalhos(array $conta): array
    {
        $credenciais = (array) ($conta['_credenciais'] ?? array());
        $token = trim((string) ($credenciais['access_token'] ?? ''));
        if ($token === '') {
            throw new \RuntimeException('A conta do Asaas esta sem o access token.');
        }

        return array(
            'access_token: ' . $token,
            'Accept: application/json',
            'User-Agent: PainelShield',
        );
    }

    /** Levanta com a mensagem que o Asaas de fato mandou, nao com uma generica. */
    private function chamar(array $conta, string $metodo, string $rota, ?array $carga = null): array
    {
        $r = Http::json($metodo, $this->base($conta) . '/' . ltrim($rota, '/'),
                        $this->cabecalhos($conta), $carga);

        if ($r['erro'] !== '') {
            throw new \RuntimeException($r['erro']);
        }

        if ($r['codigo'] >= 400) {
            // O Asaas devolve o motivo em errors[].description; `message`
            // costuma vir vazio. Ler so o `message` da "erro HTTP 400" e manda
            // o membro adivinhar.
            $motivos = array();
            foreach ((array) ($r['json']['errors'] ?? array()) as $e) {
                if (!empty($e['description'])) {
                    $motivos[] = (string) $e['description'];
                }
            }
            $texto = $motivos ? implode(' | ', $motivos)
                : trim((string) ($r['json']['message'] ?? ''));

            if ($r['codigo'] === 401 || $r['codigo'] === 403) {
                // Credencial recusada: a mensagem crua do provedor ("authorization
                // value not present") nao diz ao membro o que fazer.
                throw new \RuntimeException('O Asaas recusou a credencial desta conta (HTTP ' . $r['codigo']
                    . '). Confira o access token em Formas de recebimento.');
            }
            throw new \RuntimeException('Asaas recusou (HTTP ' . $r['codigo'] . ')'
                . ($texto !== '' ? ': ' . $texto : '.'));
        }

        return $r;
    }

    /**
     * A cobranca do Asaas exige um cliente que ja exista la dentro. Procura-se
     * pelo CNPJ; nao achando, cria. Sem isto, a primeira cobranca de todo
     * cliente novo falha com um erro que nao fala de cliente nenhum.
     */
    private function cliente(array $conta, array $empresa): string
    {
        $documento = preg_replace('/[^0-9]/', '', (string) ($empresa['cnpj'] ?? ''));
        if ($documento === '') {
            throw new \RuntimeException('O cliente esta sem CNPJ, e o Asaas exige o documento.');
        }

        $r = $this->chamar($conta, 'GET', 'customers?cpfCnpj=' . urlencode($documento));
        foreach ((array) ($r['json']['data'] ?? array()) as $achado) {
            if (!empty($achado['id'])) {
                return (string) $achado['id'];
            }
        }

        $dados = array(
            'name' => (string) ($empresa['razao'] ?? 'Cliente'),
            'cpfCnpj' => $documento,
            'email' => (string) ($empresa['email'] ?? ''),
            'notificationDisabled' => false,
        );
        // O TELEFONE MORA EM `fone` (17/09/2026): o adaptador procurava `telefone`,
        // coluna que a empresa nunca teve, e todo cliente nascia no Asaas sem numero
        // -- e e por ele que o Asaas avisa o cliente do vencimento.
        $telefone = Telefone::de($empresa);
        if ($telefone !== null) {
            $dados[$telefone['celular'] ? 'mobilePhone' : 'phone'] = $telefone['ddd'] . $telefone['numero'];
        }

        $r = $this->chamar($conta, 'POST', 'customers', $dados);

        $id = (string) ($r['json']['id'] ?? '');
        if ($id === '') {
            throw new \RuntimeException('O Asaas aceitou o cliente e nao devolveu o id.');
        }

        return $id;
    }

    /**
     * Multa e juros da regua no formato do Asaas (14/10/2026): `fine` em
     * percentual ou valor fixo, `interest` em percentual AO MES. Sem regra, nada --
     * o pedido sai byte a byte como antes. Ver shield_encargos_para_provedor.
     */
    public static function encargos(?array $regra): array
    {
        if ($regra === null) {
            return array();
        }
        $saida = array();
        if (($regra['multa_centavos'] ?? null) !== null) {
            if ((int) $regra['multa_centavos'] > 0) {
                $saida['fine'] = array('value' => round((int) $regra['multa_centavos'] / 100, 2), 'type' => 'FIXED');
            }
        } elseif ((float) ($regra['multa_percentual'] ?? 0) > 0) {
            $saida['fine'] = array('value' => round((float) $regra['multa_percentual'], 4), 'type' => 'PERCENTAGE');
        }
        if ((float) ($regra['juros_mes_percentual'] ?? 0) > 0) {
            $saida['interest'] = array('value' => round((float) $regra['juros_mes_percentual'], 4));
        }

        return $saida;
    }

    public function criar(array $cobranca, array $conta, array $cliente): Resultado
    {
        $metodo = strtoupper((string) ($cobranca['forma'] ?? 'pix'));
        $mapa = array('PIX' => 'PIX', 'BOLETO' => 'BOLETO', 'CARTAO' => 'CREDIT_CARD');
        // VENCIMENTO QUE JA PASSOU SOBE PARA O PISO DA CASA (17/09/2026). O Asaas
        // recusa a criacao com invalid_dueDate ("A data de vencimento nao pode ser
        // inferior a hoje"), e a cobranca vencida e justamente a que a regua reemite:
        // o codigo antigo ja cancelado e o novo nunca saia. Ver Shield\Cobranca\Prazo.
        // Vencimento de hoje em diante nao se mexe: ele e a data impressa no boleto.
        $vencimento = substr((string) ($cobranca['vencimento'] ?? ''), 0, 10);
        if ($vencimento < date('Y-m-d')) {
            $vencimento = Prazo::fim($vencimento)->format('Y-m-d');
        }

        $carga = array(
            'customer' => $this->cliente($conta, $cliente),
            'billingType' => $mapa[$metodo] ?? 'UNDEFINED',
            // O Asaas fala em reais com ponto; o painel guarda centavos.
            'value' => round(((int) $cobranca['valor_centavos']) / 100, 2),
            'dueDate' => $vencimento,
            'description' => (string) $cobranca['descricao'],
            'externalReference' => 'shield-' . (int) ($cobranca['id'] ?? 0),
        );
        $encargos = self::encargos($conta['_encargos'] ?? null);

        try {
            $r = $this->chamar($conta, 'POST', 'payments', $carga + $encargos);
        } catch (\RuntimeException $e) {
            // RECUSA DA MULTA OU DOS JUROS NAO PODE DEIXAR O CLIENTE SEM CODIGO
            // (14/10/2026). A regra vem da regua do membro, e o Asaas tem limites
            // proprios; se ele recusar por causa dela, a cobranca sai sem ela, como
            // saia antes desta data. Recusa 4xx nao cria nada, entao repetir nao
            // duplica.
            if ($encargos === array() || !preg_match('/fine|interest|multa|juros/i', $e->getMessage())) {
                throw $e;
            }
            $r = $this->chamar($conta, 'POST', 'payments', $carga);
        }

        $dados = (array) ($r['json'] ?? array());
        $tipo = $mapa[$metodo] ?? '';
        $copiaECola = '';
        $linha = '';
        if (($tipo === 'PIX' || $tipo === 'BOLETO') && !empty($dados['id'])) {
            // Os codigos vem em outras chamadas. Falhar nelas NAO invalida a
            // cobranca -- ela ja existe no Asaas e tem link; o membro so nao
            // recebe o texto para colar.
            //
            // O BOLETO TAMBEM TEM PIX (17/09/2026): o /pixQrCode serve a cobranca
            // BOLETO "quando o Pix estiver disponivel", e a linha vem de
            // /identificationField. Ate aqui o boleto saia sem codigo nenhum.
            try {
                $q = $this->chamar($conta, 'GET', 'payments/' . $dados['id'] . '/pixQrCode');
                $payload = (string) ($q['json']['payload'] ?? '');
                if (self::qrServeAteOVencimento((string) ($q['json']['expirationDate'] ?? ''), $vencimento, $tipo === 'PIX')) {
                    $copiaECola = $payload;
                }
            } catch (\Throwable $ignorado) {
                $copiaECola = '';
            }
            if ($tipo === 'BOLETO') {
                try {
                    $l = $this->chamar($conta, 'GET', 'payments/' . $dados['id'] . '/identificationField');
                    $linha = CodigoDePagamento::linha((string) ($l['json']['identificationField'] ?? ''));
                } catch (\Throwable $ignorado) {
                    $linha = '';
                }
                if ($copiaECola === '') {
                    $copiaECola = $linha;
                }
            }
        }

        return new Resultado(
            situacao: self::traduzir((string) ($dados['status'] ?? '')),
            idExterno: (string) ($dados['id'] ?? ''),
            situacaoProvedor: (string) ($dados['status'] ?? ''),
            link: self::linkDe($dados, $tipo),
            copiaECola: $copiaECola,
            metodo: strtolower($metodo),
            bruto: (string) $r['corpo'],
            linhaDigitavel: $linha
        );
    }

    /**
     * SEM CHAVE PIX NA CONTA, O QR DO ASAAS VALE ATE AS 23:59 DO PROPRIO DIA (doc do
     * /pixQrCode; com chave, doze meses depois do vencimento). O painel guarda o
     * codigo e nao o renova: na cobranca que vence daqui a dez dias, esse QR morre
     * amanha na mao do cliente, no ERP e na area do cliente. No boleto entra a linha
     * no lugar dele; na cobranca PIX fica so a fatura (`invoiceUrl`), onde o Asaas
     * mostra o PIX na hora de pagar -- e o membro resolve cadastrando a chave.
     *
     * $semDataServe: resposta sem `expirationDate` (a doc sempre a manda) vale na
     * cobranca PIX, onde o QR e o unico codigo, e nao vale no boleto, que tem linha.
     */
    private static function qrServeAteOVencimento(string $expira, string $vencimento, bool $semDataServe): bool
    {
        $dia = substr(trim($expira), 0, 10);
        if ($dia === '') {
            return $semDataServe;
        }

        return $dia > date('Y-m-d') && $dia >= substr($vencimento, 0, 10);
    }

    /** O boleto abre o PDF (`bankSlipUrl`); o resto, a fatura. O Asaas manda os dois. */
    private static function linkDe(array $dados, string $tipo): string
    {
        $fatura = (string) ($dados['invoiceUrl'] ?? '');
        $pdf = (string) ($dados['bankSlipUrl'] ?? '');
        if ($tipo === 'BOLETO') {
            return $pdf !== '' ? $pdf : $fatura;
        }

        return $fatura !== '' ? $fatura : $pdf;
    }

    public function consultar(string $idExterno, array $conta): Resultado
    {
        $r = $this->chamar($conta, 'GET', 'payments/' . rawurlencode($idExterno));
        $d = (array) ($r['json'] ?? array());
        $situacao = self::traduzir((string) ($d['status'] ?? ''));
        $situacaoProvedor = (string) ($d['status'] ?? '');

        // REMOVIDA NO ASAAS NAO MUDA O STATUS -- 21/09/2026, visto num membro. Excluir
        // a cobranca pelo site do Asaas (ou pelo DELETE) deixa o `status` como estava,
        // PENDING ou OVERDUE, e liga `deleted: true`; o GET continua respondendo. Lendo
        // so o status, o Conferir e o aviso PAYMENT_DELETED davam "aberta" e a cobranca
        // ficava viva no painel. Paga vence o `deleted`: dinheiro que entrou nao some.
        if (!empty($d['deleted']) && $situacao !== Resultado::PAGA) {
            $situacao = Resultado::CANCELADA;
            $situacaoProvedor = trim($situacaoProvedor . ' (removida)');
        }

        return new Resultado(
            situacao: $situacao,
            idExterno: $idExterno,
            situacaoProvedor: $situacaoProvedor,
            link: self::linkDe($d, strtoupper((string) ($d['billingType'] ?? ''))),
            valorPagoCentavos: $situacao === Resultado::PAGA
                ? (int) round(((float) ($d['value'] ?? 0)) * 100) : null,
            pagoEm: $situacao === Resultado::PAGA
                ? (string) ($d['paymentDate'] ?? $d['confirmedDate'] ?? '') : null,
            metodo: strtolower((string) ($d['billingType'] ?? '')),
            bruto: (string) $r['corpo']
        );
    }

    /**
     * DAR BAIXA NO ASAAS QUANDO O PAINEL CONFIRMA A MAO (15/10/2026, visto num
     * membro). O "Confirmar recebimento" so mudava o painel: o Asaas seguia com a
     * cobranca pendente, mandando lembrete de atraso, e o codigo continuava pagavel
     * -- o cliente podia pagar duas vezes. `receiveInCash` e o "Confirmar
     * recebimento em dinheiro" da tela do Asaas, sem avisar o cliente.
     */
    public function receberEmDinheiro(string $idExterno, array $conta, int $valorCentavos, string $data): bool
    {
        $this->chamar($conta, 'POST', 'payments/' . rawurlencode($idExterno) . '/receiveInCash', array(
            'paymentDate' => substr($data, 0, 10),
            'value' => round($valorCentavos / 100, 2),
            'notifyCustomer' => false,
        ));

        return true;
    }

    public function cancelar(string $idExterno, array $conta): bool
    {
        $this->chamar($conta, 'DELETE', 'payments/' . rawurlencode($idExterno));

        return true;
    }

    public function lerWebhook(string $corpo, array $cabecalhos, array $conta): ?EventoWebhook
    {
        $d = json_decode($corpo, true);
        if (!is_array($d) || empty($d['event'])) {
            return null;
        }

        // O Asaas nao assina o corpo: ele manda um token combinado no cabecalho
        // asaas-access-token.
        //
        // SEM TOKEN GRAVADO, RECUSA -- 17/09/2026 (era aceitar, "o estado de quem
        // ainda nao configurou"). A URL do webhook do painel nao leva segredo,
        // entao sem o token ela ficava aberta a qualquer POST, e a tela diria que
        // o aviso funciona sobre um endpoint sem tranca. A situacao continua
        // vindo da consulta, e a baixa de quem nao gravou o token chega pela
        // conciliacao. E a regra da LojadevCentral para o Mercado Pago; aqui vale
        // tambem para o Asaas porque, ao contrario de la, a URL nao autentica.
        $esperado = trim((string) ($conta['webhook_segredo'] ?? ''));
        $recebido = (string) ($cabecalhos['asaas-access-token'] ?? '');
        $confere = $esperado !== '' && hash_equals($esperado, $recebido);

        return new EventoWebhook(
            id: (string) ($d['id'] ?? ($d['event'] . '-' . ($d['payment']['id'] ?? ''))),
            tipo: (string) $d['event'],
            idExterno: (string) ($d['payment']['id'] ?? ''),
            assinaturaConfere: $confere,
            corpo: $corpo
        );
    }

    /**
     * O vocabulario do Asaas para o nosso. CONSERVADOR de proposito: o que nao
     * esta explicitamente na lista de pago nao e pago.
     *
     * RECEIVED_WITHOUT_INTEGRATION fica de fora porque e dinheiro que entrou
     * FORA do Asaas -- quem confirma esse e o membro, pela via manual, que e
     * auditada e tem permissao propria.
     */
    public static function traduzir(string $status): string
    {
        $s = strtoupper(trim($status));

        if (in_array($s, array('CONFIRMED', 'RECEIVED', 'RECEIVED_IN_CASH'), true)) {
            return Resultado::PAGA;
        }
        if (in_array($s, array('PENDING', 'AWAITING_RISK_ANALYSIS', 'AWAITING_PAYMENT'), true)) {
            return Resultado::ABERTA;
        }
        if ($s === 'OVERDUE') {
            return Resultado::VENCIDA;
        }
        if (in_array($s, array('REFUNDED', 'REFUND_REQUESTED', 'CHARGEBACK_REQUESTED',
                               'CHARGEBACK_DISPUTE', 'AWAITING_CHARGEBACK_REVERSAL'), true)) {
            return Resultado::ESTORNADA;
        }
        if (in_array($s, array('DELETED', 'CANCELLED'), true)) {
            return Resultado::CANCELADA;
        }

        return Resultado::INDEFINIDA;
    }
}
