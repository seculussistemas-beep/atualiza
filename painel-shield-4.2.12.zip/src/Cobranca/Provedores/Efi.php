<?php

namespace Shield\Cobranca\Provedores;

use Shield\Cobranca\EventoWebhook;
use Shield\Cobranca\Http;
use Shield\Cobranca\Prazo;
use Shield\Cobranca\Provedor;
use Shield\Cobranca\Resultado;
use Shield\Cobranca\TokenWebhook;

/**
 * Efi (a antiga Gerencianet) - 25/08/2026.
 *
 * E O UNICO PROVEDOR DESTA CASA QUE EXIGE CERTIFICADO. O PIX da Efi segue a
 * norma do Banco Central: mTLS obrigatorio, com o .p12 que a propria Efi
 * emite. Sem ele nao ha caminho -- nao e uma opcao de seguranca a mais, e a
 * porta. Por isso o `Http` ganhou suporte a certificado de cliente em vez de
 * este adaptador abrir o proprio cURL.
 *
 * SAO DOIS PASSOS ONDE OS OUTROS TEM UM: primeiro OAuth (client_id +
 * client_secret, sobre o mesmo mTLS) para pegar um token de uma hora, depois a
 * cobranca. O token e guardado em memoria pelo tempo da requisicao; guardar em
 * disco exigiria um cofre proprio e economizaria uma chamada por tela.
 *
 * O COPIA E COLA JA VEM NA CRIACAO: `PUT /v2/cob/{txid}` devolve `pixCopiaECola`
 * junto com o `loc.id` (17/09/2026). O `GET /v2/loc/{id}/qrcode` ficou so para a
 * resposta que vier sem ele -- antes era o unico caminho, e se aquela segunda
 * chamada falhasse o codigo se perdia, embora ja estivesse na mao.
 *
 * O TXID E NOSSO, e nao da Efi: 26 a 35 caracteres alfanumericos, definidos por
 * quem cria. Ele carrega o id da cobranca e termina com sorteio, porque a Efi
 * responde 409 `txid_duplicado` a txid ja usado (17/09/2026) -- com o txid fixo,
 * a REEMISSAO, que cancela o PIX antigo e pede outro para a mesma cobranca, nunca
 * saia. Quem protege do clique duplo hoje e o motor: a guarda de codigo vivo e a
 * chave de idempotencia.
 */
final class Efi implements Provedor
{
    public function nome(): string
    {
        return 'efi';
    }

    public function capacidades(array $conta): array
    {
        return array(
            // Boleto e cartao da Efi sao outra API (a de "charges", sem mTLS).
            // Declarar so o que este adaptador faz e o que impede a tela de
            // oferecer o que ela nao entrega.
            'pix' => true,
            'boleto' => false,
            'cartao' => false,
            'assinatura' => false,
            'automatico' => true,
        );
    }

    private function base(array $conta): string
    {
        return ((string) ($conta['ambiente'] ?? 'producao')) === 'producao'
            ? 'https://pix.api.efipay.com.br'
            : 'https://pix-h.api.efipay.com.br';
    }

    /**
     * O .p12 guardado em base64 vira o PEM que o cURL consome.
     *
     * A senha e vazia de proposito: a Efi emite o certificado sem senha, e
     * pedir uma que nao existe so cria um campo a mais para o membro errar.
     */
    private function pem(array $conta): string
    {
        $c = (array) ($conta['_credenciais'] ?? array());
        $b64 = trim((string) ($c['efi_certificado'] ?? ''));
        if ($b64 === '') {
            throw new \RuntimeException(
                'A conta da Efi esta sem o certificado. O PIX da Efi nao funciona sem ele.'
            );
        }
        $p12 = base64_decode($b64, true);
        if ($p12 === false || $p12 === '') {
            throw new \RuntimeException('O certificado da Efi nao esta em base64 valido.');
        }

        $partes = array();
        if (!openssl_pkcs12_read($p12, $partes, '')) {
            throw new \RuntimeException(
                'Nao consegui ler o certificado da Efi. Confira se colou o .p12 inteiro, em base64.'
            );
        }

        return (string) ($partes['cert'] ?? '') . (string) ($partes['pkey'] ?? '');
    }

    /** O token do OAuth, valido por uma hora. Guardado pelo tempo da chamada. */
    private function token(array $conta): string
    {
        static $cache = array();
        $chave = (string) ($conta['id'] ?? '0');
        if (isset($cache[$chave]) && $cache[$chave]['ate'] > time()) {
            return $cache[$chave]['token'];
        }

        $c = (array) ($conta['_credenciais'] ?? array());
        $id = trim((string) ($c['efi_client_id'] ?? ''));
        $segredo = trim((string) ($c['efi_client_secret'] ?? ''));
        if ($id === '' || $segredo === '') {
            throw new \RuntimeException('A conta da Efi esta sem o Client_Id ou o Client_Secret.');
        }

        $r = Http::json('POST', $this->base($conta) . '/oauth/token',
            array(
                'Authorization: Basic ' . base64_encode($id . ':' . $segredo),
                'Accept: application/json',
                'User-Agent: PainelShield',
            ),
            array('grant_type' => 'client_credentials'),
            $this->pem($conta)
        );

        if ($r['erro'] !== '') {
            throw new \RuntimeException($r['erro']);
        }
        if ($r['codigo'] >= 400) {
            throw new \RuntimeException('A Efi recusou as credenciais (HTTP ' . $r['codigo'] . '). '
                . 'Confira Client_Id, Client_Secret e se o certificado e do MESMO ambiente.');
        }

        $token = trim((string) ($r['json']['access_token'] ?? ''));
        if ($token === '') {
            throw new \RuntimeException('A Efi respondeu sem token de acesso.');
        }

        // Um minuto de folga: token que vence entre a autenticacao e o uso
        // produz um 401 que ninguem consegue explicar.
        $cache[$chave] = array('token' => $token, 'ate' => time() + 3000);

        return $token;
    }

    private function chamar(array $conta, string $metodo, string $rota, ?array $carga = null, array $extras = array()): array
    {
        $r = Http::json($metodo, $this->base($conta) . '/' . ltrim($rota, '/'),
            array_merge(array(
                'Authorization: Bearer ' . $this->token($conta),
                'Accept: application/json',
                'User-Agent: PainelShield',
            ), $extras),
            $carga,
            $this->pem($conta)
        );

        if ($r['erro'] !== '') {
            throw new \RuntimeException($r['erro']);
        }
        if ($r['codigo'] >= 400) {
            // A Efi segue o padrao de erro do BC: `violacoes[]` com `razao`.
            $motivos = array();
            foreach ((array) ($r['json']['violacoes'] ?? array()) as $v) {
                if (!empty($v['razao'])) {
                    $motivos[] = (string) $v['razao'];
                }
            }
            $texto = $motivos ? implode(' | ', $motivos)
                : trim((string) ($r['json']['mensagem'] ?? ($r['json']['detail'] ?? '')));

            if ($r['codigo'] === 401 || $r['codigo'] === 403) {
                // Credencial recusada: a mensagem crua do provedor ("authorization
                // value not present") nao diz ao membro o que fazer.
                throw new \RuntimeException('O Efi recusou a credencial desta conta (HTTP ' . $r['codigo']
                    . '). Confira as credenciais e o certificado em Formas de recebimento.');
            }
            throw new \RuntimeException('Efi recusou (HTTP ' . $r['codigo'] . ')'
                . ($texto !== '' ? ': ' . $texto : '.'));
        }

        return $r;
    }

    /**
     * O txid: `shield`, o id da cobranca e doze caracteres sorteados -- 30 no total,
     * dentro dos 26 a 35 que a Efi aceita. O id continua legivel para quem for
     * procurar no extrato; o sorteio e o que deixa a reemissao pedir outro PIX para
     * a mesma cobranca sem tomar o 409 `txid_duplicado`.
     */
    private function txid(array $cobranca): string
    {
        return 'shield' . str_pad((string) ((int) $cobranca['id']), 12, '0', STR_PAD_LEFT)
            . bin2hex(random_bytes(6));
    }

    public function criar(array $cobranca, array $conta, array $cliente): Resultado
    {
        $c = (array) ($conta['_credenciais'] ?? array());
        $chave = trim((string) ($c['efi_chave_pix'] ?? ''));
        if ($chave === '') {
            throw new \RuntimeException('A conta da Efi esta sem a chave PIX que recebe.');
        }

        $documento = preg_replace('/[^0-9]/', '', (string) ($cliente['cnpj'] ?? ''));
        // O piso de uma hora que morava aqui entregava, na reemissao de uma
        // cobranca vencida, um PIX que morria antes de o membro manda-lo. Ver
        // Shield\Cobranca\Prazo (11/09/2026).
        $segundos = Prazo::segundos((string) ($cobranca['vencimento'] ?? ''));

        $carga = array(
            'calendario' => array('expiracao' => $segundos),
            'valor' => array('original' => number_format((int) $cobranca['valor_centavos'] / 100, 2, '.', '')),
            'chave' => $chave,
            'solicitacaoPagador' => substr((string) ($cobranca['descricao'] ?? 'Licenca de uso'), 0, 140),
        );
        // Devedor identificado so quando o documento e valido: a Efi recusa a
        // cobranca inteira se o CPF/CNPJ vier torto, e cobranca sem devedor
        // funciona.
        if (strlen($documento) === 14) {
            $carga['devedor'] = array('cnpj' => $documento, 'nome' => (string) ($cliente['razao'] ?? 'Cliente'));
        } elseif (strlen($documento) === 11) {
            $carga['devedor'] = array('cpf' => $documento, 'nome' => (string) ($cliente['razao'] ?? 'Cliente'));
        }

        $txid = $this->txid($cobranca);
        $j = (array) $this->chamar($conta, 'PUT', '/v2/cob/' . $txid, $carga)['json'];

        return new Resultado(
            situacao: $this->traduzir((string) ($j['status'] ?? '')),
            idExterno: (string) ($j['txid'] ?? $txid),
            situacaoProvedor: (string) ($j['status'] ?? ''),
            copiaECola: trim((string) ($j['pixCopiaECola'] ?? '')) !== ''
                ? trim((string) $j['pixCopiaECola'])
                : $this->copiaECola($conta, (string) ($j['loc']['id'] ?? '')),
            bruto: (string) json_encode($j)
        );
    }

    /**
     * O copia-e-cola vem de OUTRA chamada, com o `loc.id` que a criacao
     * devolveu. Quem pular esta etapa entrega ao cliente uma cobranca sem nada
     * para pagar -- e o erro so aparece do lado dele.
     *
     * Falhar aqui NAO derruba a cobranca, que ja existe na Efi: devolve vazio,
     * e o painel mostra o link em vez do codigo.
     */
    private function copiaECola(array $conta, string $locId): string
    {
        if ($locId === '') {
            return '';
        }
        try {
            $j = (array) $this->chamar($conta, 'GET', '/v2/loc/' . rawurlencode($locId) . '/qrcode')['json'];

            return (string) ($j['qrcode'] ?? '');
        } catch (\RuntimeException $e) {
            return '';
        }
    }

    public function consultar(string $idExterno, array $conta): Resultado
    {
        $j = (array) $this->chamar($conta, 'GET', '/v2/cob/' . rawurlencode($idExterno))['json'];

        // A Efi devolve os pagamentos em `pix[]`. Somar todos, e nao ler so o
        // primeiro: cobranca pode ser quitada em mais de um lancamento.
        $pagoCentavos = null;
        $pagoEm = null;
        foreach ((array) ($j['pix'] ?? array()) as $p) {
            $pagoCentavos = (int) $pagoCentavos + (int) round(((float) ($p['valor'] ?? 0)) * 100);
            $quando = trim((string) ($p['horario'] ?? ''));
            if ($quando !== '') {
                $pagoEm = date('Y-m-d H:i:s', strtotime($quando));
            }
        }

        return new Resultado(
            situacao: $this->traduzir((string) ($j['status'] ?? '')),
            idExterno: (string) ($j['txid'] ?? $idExterno),
            situacaoProvedor: (string) ($j['status'] ?? ''),
            copiaECola: (string) ($j['pixCopiaECola'] ?? ''),
            valorPagoCentavos: $pagoCentavos,
            pagoEm: $pagoEm,
            bruto: (string) json_encode($j)
        );
    }

    public function cancelar(string $idExterno, array $conta): bool
    {
        try {
            $this->chamar($conta, 'PATCH', '/v2/cob/' . rawurlencode($idExterno),
                          array('status' => 'REMOVIDA_PELO_USUARIO_RECEBEDOR'));

            return true;
        } catch (\RuntimeException $e) {
            return false;
        }
    }

    /**
     * O AVISO CONFERE PELO TOKEN DA URL -- 17/09/2026.
     *
     * Ate aqui todo aviso voltava conferido, "porque chega pelo mesmo mTLS da API".
     * So que o cadastro do webhook vai com `x-skip-mtls-checking` (a hospedagem
     * compartilhada do membro nao confere certificado de cliente), e ai qualquer POST
     * entrava como autentico. O segredo viaja na propria URL cadastrada, que e o que
     * a Efi recomenda no lugar do mTLS -- junto com o IP dela, que nao da para
     * conferir de dentro do painel.
     */
    public function lerWebhook(string $corpo, array $cabecalhos, array $conta): ?EventoWebhook
    {
        $confere = TokenWebhook::confere($cabecalhos, $conta);
        $j = json_decode($corpo, true);
        $txid = is_array($j) && is_array($j['pix'] ?? null)
            ? (string) ($j['pix'][0]['txid'] ?? '')
            : '';

        if ($txid === '') {
            // A NOTIFICACAO DE TESTE DO CADASTRO precisa de 200, senao a Efi nao
            // grava o webhook. Ela vem sem `pix`, entao nao acha cobranca nenhuma e
            // nao enfileira nada -- e so com o token, para POST de estranho seguir
            // caindo em "corpo nao reconhecido".
            if (!$confere) {
                return null;
            }

            return new EventoWebhook(
                id: 'efi-teste-' . substr(hash('sha256', $corpo), 0, 32),
                tipo: 'teste',
                idExterno: '',
                assinaturaConfere: true,
                corpo: $corpo
            );
        }

        return new EventoWebhook(
            id: 'efi-' . $txid . '-' . (string) ($j['pix'][0]['endToEndId'] ?? ''),
            tipo: 'pix',
            idExterno: $txid,
            assinaturaConfere: $confere,
            corpo: $corpo
        );
    }

    /**
     * Cadastra o aviso de PIX na Efi -- chamado por Formas de recebimento (17/09/2026).
     *
     * `PUT /v2/webhook/{chave}` com `x-skip-mtls-checking: true`, que e o que permite
     * receber o aviso em hospedagem que nao confere certificado de cliente; o segredo
     * fica na URL. O `ignorar=` no fim existe porque a Efi acrescenta `/pix` a URL
     * cadastrada na hora de avisar -- com ele, o `/pix` cai no parametro e a rota
     * continua sendo a do painel.
     *
     * @return array{pix: bool}
     */
    public function cadastrarWebhook(array $conta, string $url): array
    {
        $chave = trim((string) (($conta['_credenciais'] ?? array())['efi_chave_pix'] ?? ''));
        if ($chave === '') {
            return array('pix' => false);
        }
        if (!preg_match('#^https://#', $url)) {
            throw new \RuntimeException('A Efi so aceita webhook em https://. A URL do painel e ' . $url);
        }
        if (strpos($url, 'ignorar=') === false) {
            $url .= (strpos($url, '?') === false ? '?' : '&') . 'ignorar=';
        }

        $this->chamar($conta, 'PUT', '/v2/webhook/' . rawurlencode($chave),
                      array('webhookUrl' => $url), array('x-skip-mtls-checking: true'));

        return array('pix' => true);
    }

    private function traduzir(string $status): string
    {
        switch (strtoupper(trim($status))) {
            case 'CONCLUIDA':
                return Resultado::PAGA;
            case 'ATIVA':
                return Resultado::ABERTA;
            case 'REMOVIDA_PELO_USUARIO_RECEBEDOR':
            case 'REMOVIDA_PELO_PSP':
                return Resultado::CANCELADA;
            default:
                return Resultado::INDEFINIDA;
        }
    }
}
