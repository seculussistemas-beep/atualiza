<?php

namespace Shield\Cobranca\Provedores;

use Shield\Cobranca\CodigoDePagamento;
use Shield\Cobranca\Endereco;
use Shield\Cobranca\EventoWebhook;
use Shield\Cobranca\Http;
use Shield\Cobranca\Prazo;
use Shield\Cobranca\Provedor;
use Shield\Cobranca\Resultado;
use Shield\Cobranca\Telefone;

/**
 * PagBank (o antigo PagSeguro) - 25/08/2026.
 *
 * API de Pedidos (`/orders`), autenticada por Bearer com o token de API.
 *
 * O NOME MUDOU E O CODIGO ANTIGO NAO. O identificador de provedor no banco era
 * `pagseguro`, e continua sendo aceito na leitura -- renomear a coluna de uma
 * base em producao para acompanhar marketing custa uma migracao e nao entrega
 * nada. O que o membro LE e "PagBank"; o que o banco guarda pode ser qualquer
 * um dos dois.
 *
 * VALORES EM CENTAVOS, como no Pagar.me e ao contrario do Mercado Pago.
 *
 * O PIX E UM CHARGE DO PEDIDO desde 17/09/2026 (`payment_method.type = PIX`,
 * o guia "Criar pedido com QR Code Pix v2"). Ate ali ele saia pelo `qr_codes`
 * do topo do pedido, que a referencia marca como depreciado e descreve como o
 * QR Code exclusivo da carteira PagBank. O codigo vem em `charges[].qr_code.text`;
 * o pedido antigo, com o QR no topo, continua legivel na consulta.
 */
final class PagBank implements Provedor
{
    public function nome(): string
    {
        return 'pagbank';
    }

    public function capacidades(array $conta): array
    {
        return array(
            'pix' => true,
            // BOLETO E CARTAO DESDE 10/09/2026 (tarde). Boleto e um charge do
            // pedido (API de Pedidos); cartao e um LINK da API de Checkout,
            // so com cartao -- o painel nunca ve o numero.
            'boleto' => true,
            'cartao' => true,
            'assinatura' => false,
            'automatico' => true,
        );
    }

    private function base(array $conta): string
    {
        return ((string) ($conta['ambiente'] ?? 'producao')) === 'producao'
            ? 'https://api.pagseguro.com'
            : 'https://sandbox.api.pagseguro.com';
    }

    private function cabecalhos(array $conta): array
    {
        $c = (array) ($conta['_credenciais'] ?? array());
        $token = trim((string) ($c['pagbank_token'] ?? ''));
        if ($token === '') {
            throw new \RuntimeException('A conta do PagBank esta sem o token de API.');
        }

        return array(
            'Authorization: Bearer ' . $token,
            'Accept: application/json',
            'User-Agent: PainelShield',
        );
    }

    private function chamar(array $conta, string $metodo, string $rota, ?array $carga = null): array
    {
        $r = Http::json($metodo, $this->base($conta) . '/' . ltrim($rota, '/'),
                        $this->cabecalhos($conta), $carga);

        if ($r['erro'] !== '') {
            throw new \RuntimeException($r['erro']);
        }
        if ($r['codigo'] >= 400) {
            // O PagBank devolve `error_messages[]` com `description` e o campo
            // que falhou -- e o campo importa, porque quase todo erro dele e
            // de dado obrigatorio ausente.
            $motivos = array();
            foreach ((array) ($r['json']['error_messages'] ?? array()) as $e) {
                $motivos[] = trim((string) ($e['parameter_name'] ?? '') . ' '
                    . (string) ($e['description'] ?? ''));
            }
            $texto = $motivos ? implode(' | ', $motivos) : '';

            if ($r['codigo'] === 401 || $r['codigo'] === 403) {
                // Credencial recusada: a mensagem crua do provedor ("authorization
                // value not present") nao diz ao membro o que fazer.
                throw new \RuntimeException('O PagBank recusou a credencial desta conta (HTTP ' . $r['codigo']
                    . '). Confira o token de API em Formas de recebimento.');
            }
            throw new \RuntimeException('PagBank recusou (HTTP ' . $r['codigo'] . ')'
                . ($texto !== '' ? ': ' . $texto : '.'));
        }

        return $r;
    }

    public function criar(array $cobranca, array $conta, array $cliente): Resultado
    {
        $forma = strtolower(trim((string) ($cobranca['forma'] ?? 'pix')));
        if ($forma === 'cartao') {
            return $this->criarCartao($cobranca, $conta, $cliente);
        }

        $documento = preg_replace('/[^0-9]/', '', (string) ($cliente['cnpj'] ?? ''));
        $centavos = (int) $cobranca['valor_centavos'];
        // Vencimento no passado ia direto para expiration_date. Ver
        // Shield\Cobranca\Prazo (11/09/2026).
        $expira = Prazo::fim((string) ($cobranca['vencimento'] ?? ''))->format('c');
        $email = trim((string) ($cliente['email'] ?? '')) !== ''
            ? (string) $cliente['email']
            : 'sem-email+' . $documento . '@painelshield.local';

        $carga = array(
            'reference_id' => 'shield-' . (int) $cobranca['id'],
            'customer' => array(
                'name' => (string) ($cliente['razao'] ?? 'Cliente'),
                'email' => $email,
                'tax_id' => $documento,
            ),
            'items' => array(array(
                'name' => (string) ($cobranca['descricao'] ?? 'Licenca de uso'),
                'quantity' => 1,
                'unit_amount' => $centavos,
            )),
        );
        $telefones = self::telefones($cliente);
        if ($telefones !== array()) {
            $carga['customer']['phones'] = $telefones;
        }
        $aviso = self::urlAviso($conta);
        if ($aviso !== '') {
            $carga['notification_urls'] = array($aviso);
        }

        if ($forma === 'boleto') {
            // BOLETO E UM CHARGE DO PEDIDO, e o titular precisa de endereco
            // completo: e o que sai impresso.
            $e = Endereco::de($cliente);
            $carga['charges'] = array(array(
                'reference_id' => 'shield-' . (int) $cobranca['id'],
                'description' => (string) ($cobranca['descricao'] ?? 'Licenca de uso'),
                'amount' => array('value' => $centavos, 'currency' => 'BRL'),
                'payment_method' => array(
                    'type' => 'BOLETO',
                    'boleto' => array(
                        // O vencimento IMPRESSO no boleto sai do mesmo prazo: boleto
                        // reemitido com data passada e recusado na hora (11/09/2026).
                        'due_date' => Prazo::fim((string) ($cobranca['vencimento'] ?? ''))->format('Y-m-d'),
                        'instruction_lines' => array('line_1' => 'Licenca de uso do sistema', 'line_2' => 'Nao receber apos o vencimento'),
                        'holder' => array(
                            'name' => (string) ($cliente['razao'] ?? 'Cliente'),
                            'tax_id' => $documento,
                            'email' => $email,
                            'address' => array(
                                'street' => $e['rua'], 'number' => $e['numero'], 'locality' => $e['bairro'],
                                'city' => $e['cidade'], 'region_code' => $e['uf'], 'country' => 'BRA',
                                'postal_code' => $e['cep'],
                            ),
                        ),
                    ),
                ),
            ));
        } else {
            // O charge que faz o pedido ter o que pagar. Sem ele o PagBank cria
            // um pedido vazio, que o cliente abre e nao consegue pagar.
            $carga['charges'] = array(array(
                'reference_id' => 'shield-' . (int) $cobranca['id'],
                'description' => (string) ($cobranca['descricao'] ?? 'Licenca de uso'),
                'amount' => array('value' => $centavos, 'currency' => 'BRL'),
                'payment_method' => array(
                    'type' => 'PIX',
                    'pix' => array('expiration_date' => $expira),
                ),
            ));
        }

        $j = (array) $this->chamar($conta, 'POST', '/orders', $carga)['json'];

        $charge = (array) ($j['charges'][0] ?? array());

        if ($forma === 'boleto') {
            $linha = self::linhaDoBoleto($charge);

            return new Resultado(
                situacao: $charge ? $this->traduzir((string) ($charge['status'] ?? '')) : Resultado::ABERTA,
                idExterno: (string) ($j['id'] ?? ''),
                situacaoProvedor: (string) ($charge['status'] ?? 'CREATED'),
                link: $this->linkDoBoleto($charge),
                copiaECola: $linha,
                metodo: 'boleto',
                bruto: (string) json_encode($j),
                linhaDigitavel: $linha
            );
        }

        $texto = self::textoDoPix($j, $charge);
        if ($texto === '') {
            // Charge recusado na hora nao traz QR. Guardar o pedido sem codigo faria
            // a guarda de codigo vivo recusar o Emitir seguinte, e o PagBank nao
            // cancela pedido: fica valendo so o que ele disse.
            throw new \RuntimeException('O PagBank criou o pedido ' . (string) ($j['id'] ?? '')
                . ' sem o QR do PIX (situacao ' . ((string) ($charge['status'] ?? '') ?: 'nenhuma') . ').'
                . ' Confira a conta no PagBank e emita de novo.');
        }

        return new Resultado(
            situacao: $charge ? $this->traduzir((string) ($charge['status'] ?? '')) : Resultado::ABERTA,
            idExterno: (string) ($j['id'] ?? ''),
            situacaoProvedor: (string) ($charge['status'] ?? 'CREATED'),
            link: $this->linkDoPix($j, $charge),
            copiaECola: $texto,
            metodo: 'pix',
            bruto: (string) json_encode($j)
        );
    }

    /** O copia e cola: o do charge (v2) e, no pedido antigo, o do `qr_codes` do topo. */
    private static function textoDoPix(array $j, array $charge): string
    {
        $texto = trim((string) ($charge['qr_code']['text'] ?? ''));

        return $texto !== '' ? $texto : trim((string) ($j['qr_codes'][0]['text'] ?? ''));
    }

    /** A imagem do QR (rel QRCODE.PNG no charge v2; `image/png` no pedido antigo). */
    private function linkDoPix(array $j, array $charge): string
    {
        foreach ((array) ($charge['links'] ?? array()) as $l) {
            if (strtoupper((string) ($l['rel'] ?? '')) === 'QRCODE.PNG') {
                return (string) ($l['href'] ?? '');
            }
        }

        return $this->linkDe((array) ($j['qr_codes'][0] ?? array()));
    }

    /**
     * A linha do boleto, so digitos. A referencia poe as duas sob "Linha Digitavel":
     * `barcode` numerico e `formatted_barcode` com pontuacao (54 caracteres).
     */
    private static function linhaDoBoleto(array $charge): string
    {
        $boleto = (array) ($charge['payment_method']['boleto'] ?? array());
        $linha = CodigoDePagamento::linha((string) ($boleto['barcode'] ?? ''));

        return $linha !== '' ? $linha : CodigoDePagamento::linha((string) ($boleto['formatted_barcode'] ?? ''));
    }

    /**
     * O telefone do cadastro no formato do PagBank, ou nada. O guia do PIX v2 manda
     * `customer.phones`; cadastro sem um numero com DDD nao inventa telefone.
     */
    private static function telefones(array $cliente): array
    {
        $telefone = Telefone::de($cliente);
        if ($telefone === null) {
            return array();
        }

        return array(array(
            'country' => '55',
            'area' => $telefone['ddd'],
            'number' => $telefone['numero'],
            'type' => $telefone['celular'] ? 'MOBILE' : 'BUSINESS',
        ));
    }

    /**
     * O endereco do aviso, que o PagBank so usa se vier NO PEDIDO (`notification_urls`).
     * Quem monta e o motor, so a partir do endereco declarado do painel (ver
     * shield_cobranca_url_aviso); o PagBank exige HTTPS e recusaria o pedido
     * inteiro por um endereco http.
     */
    private static function urlAviso(array $conta): string
    {
        $url = trim((string) ($conta['_url_webhook'] ?? ''));

        return strpos($url, 'https://') === 0 ? $url : '';
    }

    /**
     * Cartao e um LINK da API de Checkout (CHEC_...), so com cartao. O
     * checkout gera um pedido quando o cliente paga; a consulta le esse
     * pedido de dentro do proprio checkout.
     */
    private function criarCartao(array $cobranca, array $conta, array $cliente): Resultado
    {
        $documento = preg_replace('/[^0-9]/', '', (string) ($cliente['cnpj'] ?? ''));
        $carga = array(
            'reference_id' => 'shield-' . (int) $cobranca['id'],
            'expiration_date' => Prazo::fim((string) ($cobranca['vencimento'] ?? ''))->format('c'),
            'customer' => array(
                'name' => (string) ($cliente['razao'] ?? 'Cliente'),
                'email' => trim((string) ($cliente['email'] ?? '')) !== '' ? (string) $cliente['email'] : 'sem-email+' . $documento . '@painelshield.local',
                'tax_id' => $documento,
            ),
            'items' => array(array(
                'reference_id' => 'shield-' . (int) $cobranca['id'],
                'name' => (string) ($cobranca['descricao'] ?? 'Licenca de uso'),
                'quantity' => 1,
                'unit_amount' => (int) $cobranca['valor_centavos'],
            )),
            'payment_methods' => array(array('type' => 'CREDIT_CARD')),
            'soft_descriptor' => 'LICENCA',
        );

        $j = (array) $this->chamar($conta, 'POST', '/checkouts', $carga)['json'];

        return new Resultado(
            situacao: Resultado::ABERTA,
            idExterno: (string) ($j['id'] ?? ''),
            situacaoProvedor: (string) ($j['status'] ?? 'ACTIVE'),
            link: $this->linkPagar($j),
            metodo: 'cartao',
            bruto: (string) json_encode($j)
        );
    }

    private function ehCheckout(string $idExterno): bool
    {
        return strpos($idExterno, 'CHEC') === 0;
    }

    private function consultarCheckout(string $idExterno, array $conta): Resultado
    {
        $j = (array) $this->chamar($conta, 'GET', '/checkouts/' . rawurlencode($idExterno))['json'];
        $charge = (array) ($j['orders'][0]['charges'][0] ?? array());
        if ($charge) {
            $pago = trim((string) ($charge['paid_at'] ?? ''));

            return new Resultado(
                situacao: $this->traduzir((string) ($charge['status'] ?? '')),
                idExterno: $idExterno,
                situacaoProvedor: (string) ($charge['status'] ?? ''),
                valorPagoCentavos: isset($charge['amount']['summary']['paid']) ? (int) $charge['amount']['summary']['paid'] : null,
                pagoEm: $pago !== '' ? date('Y-m-d H:i:s', strtotime($pago)) : null,
                metodo: 'cartao',
                bruto: (string) json_encode($j)
            );
        }
        $status = strtoupper((string) ($j['status'] ?? ''));

        return new Resultado(
            // Checkout sem pedido: ninguem pagou. Expirado ou inativado, o
            // link morreu -- e cancelado, nao "desconhecido".
            situacao: in_array($status, array('EXPIRED', 'INACTIVE'), true) ? Resultado::CANCELADA : Resultado::ABERTA,
            idExterno: $idExterno,
            situacaoProvedor: $status !== '' ? $status : 'ACTIVE',
            link: $this->linkPagar($j),
            metodo: 'cartao',
            bruto: (string) json_encode($j)
        );
    }

    /** O link "PAY" do checkout. */
    private function linkPagar(array $j): string
    {
        foreach ((array) ($j['links'] ?? array()) as $l) {
            if (strtoupper((string) ($l['rel'] ?? '')) === 'PAY') {
                return (string) ($l['href'] ?? '');
            }
        }

        return (string) ($j['links'][0]['href'] ?? '');
    }

    /** O PDF do boleto, que e o que se manda ao cliente. */
    private function linkDoBoleto(array $charge): string
    {
        foreach ((array) ($charge['links'] ?? array()) as $l) {
            if (($l['media'] ?? '') === 'application/pdf') {
                return (string) ($l['href'] ?? '');
            }
        }

        return (string) ($charge['links'][0]['href'] ?? '');
    }

    public function consultar(string $idExterno, array $conta): Resultado
    {
        if ($this->ehCheckout($idExterno)) {
            return $this->consultarCheckout($idExterno, $conta);
        }
        $j = (array) $this->chamar($conta, 'GET', '/orders/' . rawurlencode($idExterno))['json'];
        $charge = (array) ($j['charges'][0] ?? array());
        $pago = trim((string) ($charge['paid_at'] ?? ''));

        // Pedido SEM charge nenhum e pedido que ninguem pagou ainda -- e nao
        // um pedido em estado desconhecido.
        $status = (string) ($charge['status'] ?? '');

        $boleto = strtoupper((string) ($charge['payment_method']['type'] ?? '')) === 'BOLETO';
        $linha = $boleto ? self::linhaDoBoleto($charge) : '';

        return new Resultado(
            situacao: $charge ? $this->traduzir($status) : Resultado::ABERTA,
            idExterno: (string) ($j['id'] ?? $idExterno),
            situacaoProvedor: $status !== '' ? $status : 'CREATED',
            link: $boleto ? $this->linkDoBoleto($charge) : $this->linkDoPix($j, $charge),
            copiaECola: $boleto ? $linha : self::textoDoPix($j, $charge),
            linhaDigitavel: $linha,
            metodo: $boleto ? 'boleto' : 'pix',
            valorPagoCentavos: isset($charge['amount']['summary']['paid'])
                ? (int) $charge['amount']['summary']['paid'] : null,
            pagoEm: $pago !== '' ? date('Y-m-d H:i:s', strtotime($pago)) : null,
            bruto: (string) json_encode($j)
        );
    }

    public function cancelar(string $idExterno, array $conta): bool
    {
        if ($this->ehCheckout($idExterno)) {
            // Checkout de cartao se inativa: o link morre na hora.
            try {
                $this->chamar($conta, 'POST', '/checkouts/' . rawurlencode($idExterno) . '/inactivate');

                return true;
            } catch (\RuntimeException $e) {
                return false;
            }
        }

        // O PagBank nao cancela PEDIDO: ele cancela CHARGE, e so depois de
        // existir um. Pedido nao pago simplesmente expira na data marcada --
        // devolver false aqui e a resposta honesta, e nao uma falha.
        return false;
    }

    public function lerWebhook(string $corpo, array $cabecalhos, array $conta): ?EventoWebhook
    {
        $j = json_decode($corpo, true);
        if (!is_array($j)) {
            return null;
        }
        $id = (string) ($j['id'] ?? '');
        if ($id === '' || strpos($id, 'ORDE') !== 0) {
            return null;      // so aviso de pedido interessa aqui
        }

        // O PagBank assina o corpo em SHA-256 com o token da conta, no cabecalho
        // x-authenticity-token: sha256("{token}-{corpo}"), em hexadecimal minusculo
        // (developer.pagbank.com.br, "Confirmar autenticidade da notificacao").
        //
        // SEM SEGREDO, NADA CONFERE (17/09/2026). A conta sem segredo gravado
        // aceitava qualquer POST, e o hash de "-" mais o corpo qualquer um calcula.
        // O token que assina e o proprio token de API, que toda conta que emite
        // tem: sem segredo gravado, vale ele.
        $esperado = trim((string) ($conta['webhook_segredo'] ?? ''));
        if ($esperado === '') {
            $esperado = trim((string) (($conta['_credenciais'] ?? array())['pagbank_token'] ?? ''));
        }
        $recebido = strtolower(trim((string) ($cabecalhos['x-authenticity-token'] ?? '')));
        $confere = $esperado !== '' && $recebido !== ''
            && hash_equals(hash('sha256', $esperado . '-' . $corpo), $recebido);

        return new EventoWebhook(
            id: $id,
            tipo: (string) ($j['charges'][0]['status'] ?? 'ORDER'),
            idExterno: $id,
            assinaturaConfere: $confere,
            corpo: $corpo
        );
    }

    /** O link que se manda ao cliente: o PagBank publica varios formatos. */
    private function linkDe(array $qr): string
    {
        foreach ((array) ($qr['links'] ?? array()) as $l) {
            if (($l['media'] ?? '') === 'image/png') {
                return (string) ($l['href'] ?? '');
            }
        }

        return (string) ($qr['links'][0]['href'] ?? '');
    }

    private function traduzir(string $status): string
    {
        switch (strtoupper(trim($status))) {
            case 'PAID':
                return Resultado::PAGA;
            case 'AUTHORIZED':
            case 'WAITING':
            case 'IN_ANALYSIS':
                return Resultado::ABERTA;
            case 'DECLINED':
            case 'CANCELED':
                return Resultado::CANCELADA;
            case 'REFUNDED':
                return Resultado::ESTORNADA;
            default:
                return Resultado::INDEFINIDA;
        }
    }
}
