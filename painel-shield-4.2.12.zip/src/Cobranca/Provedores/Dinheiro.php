<?php

namespace Shield\Cobranca\Provedores;

use Shield\Cobranca\EventoWebhook;
use Shield\Cobranca\Provedor;
use Shield\Cobranca\Resultado;

/**
 * Dinheiro em especie - 25/08/2026.
 *
 * O cliente paga no balcao e o membro confirma na tela. Nao ha nada a emitir e
 * nao ha a quem perguntar.
 *
 * Existe como provedor pelo mesmo motivo do PIX estatico: para a tela, a regua
 * e o historico nao precisarem saber a diferenca. O que muda entre ele e um
 * gateway e SO quem confirma o pagamento.
 */
final class Dinheiro implements Provedor
{
    public function nome(): string
    {
        return 'dinheiro';
    }

    public function capacidades(array $conta): array
    {
        return array(
            'pix' => false,
            'boleto' => false,
            'cartao' => false,
            'assinatura' => false,
            'automatico' => false,
        );
    }

    public function criar(array $cobranca, array $conta, array $cliente): Resultado
    {
        return new Resultado(
            situacao: Resultado::ABERTA,
            idExterno: 'DIN' . (int) ($cobranca['id'] ?? 0),
            situacaoProvedor: 'a receber no balcao',
            metodo: 'dinheiro'
        );
    }

    public function consultar(string $idExterno, array $conta): Resultado
    {
        return new Resultado(
            situacao: Resultado::ABERTA,
            idExterno: $idExterno,
            situacaoProvedor: 'a receber no balcao',
            metodo: 'dinheiro'
        );
    }

    public function cancelar(string $idExterno, array $conta): bool
    {
        return true;
    }

    public function lerWebhook(string $corpo, array $cabecalhos, array $conta): ?EventoWebhook
    {
        return null;
    }
}
