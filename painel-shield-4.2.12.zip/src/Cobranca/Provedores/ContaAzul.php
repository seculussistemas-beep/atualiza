<?php

namespace Shield\Cobranca\Provedores;

use Shield\Cobranca\Credenciais;
use Shield\Cobranca\Endereco;
use Shield\Cobranca\EventoWebhook;
use Shield\Cobranca\Http;
use Shield\Cobranca\Prazo;
use Shield\Cobranca\Provedor;
use Shield\Cobranca\Resultado;

/**
 * Conta Azul -- boleto, PIX cobranca e link de cartao pelo ERP - 16/09/2026.
 *
 * NAO E UM GATEWAY, E UM ERP. A cobranca do Conta Azul nasce presa a uma
 * PARCELA de uma venda; nao ha "crie um PIX de R$ 150". Emitir aqui e uma
 * cadeia de sete chamadas, e cada elo veio do OpenAPI de
 * developers.contaazul.com (lido em 16/09/2026; os bundles JSON do portal):
 *
 *   1. GET  /v1/pessoas?documentos=<cnpj>        acha o cliente (ou POST /v1/pessoas)
 *   2. GET  /v1/servicos?busca_textual=...       acha o servico (ou POST /v1/servicos),
 *                                                porque o item da venda EXIGE o id de um
 *                                                produto/servico; o id fica guardado na
 *                                                credencial contaazul_servico
 *   3. GET  /v1/venda/proximo-numero             o numero e obrigatorio na venda
 *   4. POST /v1/venda                            APROVADO, um item, uma parcela no vencimento
 *   5. GET  /v1/venda/{id}                       so para achar evento_financeiro.id
 *   6. GET  /v1/financeiro/eventos-financeiros/{id}/parcelas   a parcela da venda
 *   7. POST /v1/financeiro/eventos-financeiros/contas-a-receber/gerar-cobranca
 *
 * O ID EXTERNO LEVA OS DOIS: `<id_cobranca>|<id_parcela>`. A situacao vem da
 * cobranca (GET .../cobranca/{id}: id, url, status) e o VALOR PAGO e a data
 * vem da parcela (GET .../parcelas/{id}: status, valor_pago, baixas[]), que a
 * rota da cobranca nao traz. Cancelar e DELETE na cobranca.
 *
 * NAO HA WEBHOOK, e nao e falta deste adaptador: "a API nao suporta webhooks,
 * sera preciso implementar polling" (developers.contaazul.com/aboutapis). A
 * conciliacao do painel ja pergunta por consultar(); lerWebhook() devolve
 * null para tudo. TAMBEM NAO HA SANDBOX: a conta de desenvolvimento do portal
 * (30 dias) e o unico ambiente de teste, no mesmo endereco.
 *
 * O TOKEN E OAUTH2 AUTHORIZATION CODE: quem autoriza e o membro no navegador
 * (ver urlAutorizacao/trocarCodigo e modules/cobranca/contaazul_retorno.php).
 * O access_token dura 1 h e o refresh_token ROTACIONA a cada renovacao -- o
 * anterior morre na hora. Por isso token() entrega o par novo por
 * Credenciais::renovadas, e quem tem banco grava.
 *
 * NINGUEM RODOU ISTO CONTRA O CONTA AZUL. E o contrato da documentacao.
 */
final class ContaAzul implements Provedor
{
    public const BASE = 'https://api-v2.contaazul.com';
    public const AUTORIZAR = 'https://login.contaazul.com/#/oauth/authorize';
    /** Fixo, pelo guia: "seu aplicativo tera a permissao de administrador". */
    public const ESCOPO = 'openid+profile+aws.cognito.signin.user.admin';
    public const ROTA_RETORNO = '/contaazul_retorno.php';
    /** O nome do servico que o painel cria no Conta Azul para vender a licenca. */
    public const SERVICO = 'Licenca de uso';

    private const COBRANCA = '/v1/financeiro/eventos-financeiros/contas-a-receber';
    private const SENTINELA = 'shield-teste-inexistente-0';

    /** O token renovado nesta requisicao, por conta: o gancho pode nao estar ligado. */
    private static array $renovados = array();

    public function nome(): string
    {
        return 'contaazul';
    }

    public function capacidades(array $conta): array
    {
        return array(
            'pix' => true,
            'boleto' => true,
            'cartao' => true,
            'assinatura' => false,
            'automatico' => true,
        );
    }

    // ---------------------------------------------------------------
    // OAuth: as pecas que a tela usa
    // ---------------------------------------------------------------

    /** A URL do guia (requestingcode), com o scope fixo e o state do painel. */
    public static function urlAutorizacao(string $clientId, string $redirectUri, string $state): string
    {
        return self::AUTORIZAR . '?response_type=code&client_id=' . rawurlencode($clientId)
            . '&redirect_uri=' . rawurlencode($redirectUri) . '&state=' . rawurlencode($state)
            . '&scope=' . self::ESCOPO;
    }

    /**
     * O redirect_uri e montado de UM jeito so, do host da requisicao, porque
     * ele tem de ser byte a byte igual ao cadastrado no portal -- a tela mostra
     * este mesmo texto para o membro cadastrar la.
     */
    public static function redirectUri(array $servidor): string
    {
        $https = isset($servidor['HTTPS']) && strtolower((string) $servidor['HTTPS']) !== 'off' && (string) $servidor['HTTPS'] !== '';

        return ($https ? 'https' : 'http') . '://' . (string) ($servidor['HTTP_HOST'] ?? '') . self::ROTA_RETORNO;
    }

    /** O state da volta e o da ida, e vazio nunca confere (nem com vazio). */
    public static function stateConfere(string $esperado, string $recebido): bool
    {
        return $esperado !== '' && hash_equals($esperado, $recebido);
    }

    /**
     * Troca o `code` da volta pelos tokens (changecode). Devolve o delta de
     * credenciais para gravar; recusa estoura com o erro do Conta Azul.
     *
     * @return array{contaazul_access_token:string,contaazul_refresh_token:string,contaazul_expira_em:string}
     */
    public static function trocarCodigo(array $credenciais, string $code, string $redirectUri): array
    {
        return self::pedirToken($credenciais, array(
            'grant_type' => 'authorization_code',
            'code' => $code,
            'redirect_uri' => $redirectUri,
        ));
    }

    /** POST /oauth/token com Basic client_id:client_secret e corpo em formulario. */
    private static function pedirToken(array $credenciais, array $carga): array
    {
        $id = trim((string) ($credenciais['contaazul_client_id'] ?? ''));
        $segredo = trim((string) ($credenciais['contaazul_client_secret'] ?? ''));
        if ($id === '' || $segredo === '') {
            throw new \RuntimeException('A conta do Conta Azul esta sem o Client ID ou o Client Secret.');
        }

        $r = Http::json('POST', self::BASE . '/oauth/token',
            array(
                'Authorization: Basic ' . base64_encode($id . ':' . $segredo),
                'Content-Type: application/x-www-form-urlencoded',
                'Accept: application/json',
                'User-Agent: PainelShield',
            ),
            $carga
        );
        if ($r['erro'] !== '') {
            throw new \RuntimeException($r['erro']);
        }
        if ($r['codigo'] >= 400) {
            $j = (array) ($r['json'] ?? array());
            $motivo = trim((string) ($j['error'] ?? '') . ' ' . (string) ($j['error_subtype'] ?? ''));
            throw new \RuntimeException('O Conta Azul recusou o token (HTTP ' . $r['codigo'] . ')'
                . ($motivo !== '' ? ': ' . $motivo : '') . '. Clique em Conectar ao Conta Azul em Formas de recebimento e autorize de novo.');
        }

        $token = trim((string) ($r['json']['access_token'] ?? ''));
        if ($token === '') {
            throw new \RuntimeException('O Conta Azul respondeu sem access_token.');
        }

        // Um minuto de folga: token que vence entre a autenticacao e o uso
        // produz um 401 que ninguem consegue explicar.
        $ttl = max(120, (int) ($r['json']['expires_in'] ?? 3600)) - 60;

        return array(
            'contaazul_access_token' => $token,
            // Sem refresh novo na resposta, o antigo continua valendo.
            'contaazul_refresh_token' => trim((string) ($r['json']['refresh_token'] ?? ($carga['refresh_token'] ?? ''))),
            'contaazul_expira_em' => (string) (time() + $ttl),
        );
    }

    /**
     * O access_token valido, renovando pelo refresh quando venceu. O PAR NOVO
     * E ENTREGUE AO GANCHO na hora: o refresh antigo ja morreu.
     */
    private function token(array $conta): string
    {
        $c = (array) ($conta['_credenciais'] ?? array());
        $id = (int) ($conta['id'] ?? 0);
        if (isset(self::$renovados[$id])) {
            $c = array_merge($c, self::$renovados[$id]);
        }

        $access = trim((string) ($c['contaazul_access_token'] ?? ''));
        $expira = (int) ($c['contaazul_expira_em'] ?? 0);
        if ($access !== '' && $expira > time() + 60) {
            return $access;
        }

        $refresh = trim((string) ($c['contaazul_refresh_token'] ?? ''));
        if ($refresh === '') {
            throw new \RuntimeException('Esta conta ainda nao foi autorizada no Conta Azul. '
                . 'Em Formas de recebimento, grave o Client ID e o Client Secret e clique em Conectar ao Conta Azul.');
        }

        $novo = self::pedirToken($c, array('grant_type' => 'refresh_token', 'refresh_token' => $refresh));
        self::$renovados[$id] = $novo;
        Credenciais::renovadas($id, $novo);

        return $novo['contaazul_access_token'];
    }

    // ---------------------------------------------------------------
    // HTTP
    // ---------------------------------------------------------------

    /** A chamada crua, sem levantar: o teste de conexao precisa ler o codigo. */
    private function pedir(array $conta, string $metodo, string $rota, ?array $carga = null): array
    {
        $r = Http::json($metodo, self::BASE . $rota,
            array(
                'Authorization: Bearer ' . $this->token($conta),
                'Accept: application/json',
                'User-Agent: PainelShield',
            ),
            $carga
        );
        if ($r['erro'] !== '') {
            throw new \RuntimeException($r['erro']);
        }

        return $r;
    }

    private function chamar(array $conta, string $metodo, string $rota, ?array $carga = null): array
    {
        $r = $this->pedir($conta, $metodo, $rota, $carga);
        if ($r['codigo'] >= 400) {
            throw new \RuntimeException($this->motivo($r));
        }

        return $r;
    }

    private function motivo(array $r): string
    {
        $j = (array) ($r['json'] ?? array());
        $texto = trim((string) ($j['message'] ?? ($j['mensagem'] ?? ($j['error_description'] ?? ($j['error'] ?? '')))));
        if ($texto === '' && !empty($j['errors']) && is_array($j['errors'])) {
            $partes = array();
            foreach ($j['errors'] as $e) {
                $partes[] = is_array($e) ? (string) ($e['message'] ?? ($e['mensagem'] ?? json_encode($e))) : (string) $e;
            }
            $texto = implode(' | ', $partes);
        }

        if ($r['codigo'] === 401 || $r['codigo'] === 403) {
            return 'O Conta Azul recusou o token desta conta (HTTP ' . $r['codigo'] . '). '
                . 'Clique em Conectar ao Conta Azul em Formas de recebimento e autorize de novo.';
        }

        return 'Conta Azul recusou (HTTP ' . $r['codigo'] . ')' . ($texto !== '' ? ': ' . $texto : '.');
    }

    // ---------------------------------------------------------------
    // Emissao
    // ---------------------------------------------------------------

    /** A forma do painel -> o tipo_pagamento da venda e o tipo da cobranca. */
    private static function tipos(string $forma): array
    {
        switch ($forma) {
            case 'pix':
                return array('venda' => 'COBRANCA_PIX', 'cobranca' => 'PIX_COBRANCA');
            case 'boleto':
                return array('venda' => 'BOLETO_BANCARIO', 'cobranca' => 'BOLETO');
            case 'cartao':
                return array('venda' => 'LINK_PAGAMENTO', 'cobranca' => 'LINK_PAGAMENTO');
        }
        throw new \RuntimeException('O Conta Azul emite PIX, boleto e link de cartao; pedido veio como "' . $forma . '".');
    }

    public function criar(array $cobranca, array $conta, array $cliente): Resultado
    {
        $forma = strtolower((string) ($cobranca['forma'] ?? 'pix'));
        $tipos = self::tipos($forma);

        $c = (array) ($conta['_credenciais'] ?? array());
        $contaFinanceira = trim((string) ($c['contaazul_conta_financeira'] ?? ''));
        if ($contaFinanceira === '') {
            throw new \RuntimeException('A conta do Conta Azul esta sem a conta de cobranca. '
                . 'Em Formas de recebimento, conecte ao Conta Azul e escolha a conta que recebe.');
        }

        $valor = (float) number_format((int) $cobranca['valor_centavos'] / 100, 2, '.', '');
        $vencimento = trim((string) ($cobranca['vencimento'] ?? ''));
        if ($vencimento === '') {
            $vencimento = Prazo::fim('')->format('Y-m-d');
        }
        $descricao = mb_substr(trim((string) ($cobranca['descricao'] ?? '')) ?: self::SERVICO, 0, 200);

        $idCliente = $this->cliente($conta, $cliente);
        $idServico = $this->servico($conta);

        $numero = (int) trim((string) $this->chamar($conta, 'GET', '/v1/venda/proximo-numero')['corpo']);
        if ($numero <= 0) {
            throw new \RuntimeException('O Conta Azul nao devolveu o proximo numero de venda.');
        }

        // A VENDA APROVADA COM UMA PARCELA SO, no vencimento da cobranca: e a
        // parcela que vira a cobranca. "À vista" com acento e o formato que a
        // documentacao de opcao_condicao_pagamento exige.
        $venda = $this->chamar($conta, 'POST', '/v1/venda', array(
            'id_cliente' => $idCliente,
            'numero' => $numero,
            'situacao' => 'APROVADO',
            'data_venda' => date('Y-m-d'),
            'itens' => array(array(
                'id' => $idServico,
                'descricao' => $descricao,
                'quantidade' => 1,
                'valor' => $valor,
            )),
            'condicao_pagamento' => array(
                'tipo_pagamento' => $tipos['venda'],
                'id_conta_financeira' => $contaFinanceira,
                'opcao_condicao_pagamento' => 'À vista',
                'parcelas' => array(array(
                    'data_vencimento' => $vencimento,
                    'valor' => $valor,
                    'descricao' => $descricao,
                )),
            ),
        ));
        $idVenda = trim((string) ($venda['json']['id'] ?? ''));
        if ($idVenda === '') {
            throw new \RuntimeException('O Conta Azul aceitou a venda e nao devolveu o id dela.');
        }

        // O POST da venda nao traz o evento financeiro; o GET traz.
        $detalhe = (array) ($this->chamar($conta, 'GET', '/v1/venda/' . rawurlencode($idVenda))['json'] ?? array());
        $idEvento = trim((string) ($detalhe['evento_financeiro']['id'] ?? ''));
        if ($idEvento === '') {
            throw new \RuntimeException('A venda ' . $numero . ' foi criada no Conta Azul sem evento financeiro; nao ha parcela para cobrar.');
        }

        $parcelas = (array) ($this->chamar($conta, 'GET', '/v1/financeiro/eventos-financeiros/' . rawurlencode($idEvento) . '/parcelas')['json'] ?? array());
        $idParcela = trim((string) ($parcelas[0]['id'] ?? ''));
        if ($idParcela === '') {
            throw new \RuntimeException('A venda ' . $numero . ' foi criada no Conta Azul e o evento financeiro veio sem parcela.');
        }

        $r = $this->chamar($conta, 'POST', self::COBRANCA . '/gerar-cobranca', array(
            'conta_bancaria' => $contaFinanceira,
            'descricao_fatura' => $descricao,
            'id_parcela' => $idParcela,
            // O codigo nao pode nascer morto: vencimento passado vira hoje + 3.
            'data_vencimento' => Prazo::fim($vencimento)->format('Y-m-d'),
            'tipo' => $tipos['cobranca'],
        ));
        $j = (array) ($r['json'] ?? array());
        $idCobranca = trim((string) ($j['id'] ?? ''));
        if ($idCobranca === '') {
            throw new \RuntimeException('O Conta Azul aceitou a cobranca e nao devolveu o id dela.');
        }

        return new Resultado(
            situacao: self::traduzir((string) ($j['status'] ?? '')) === Resultado::INDEFINIDA
                ? Resultado::ABERTA   // a cobranca acabou de nascer: existe, e esta na rua
                : self::traduzir((string) ($j['status'] ?? '')),
            idExterno: $idCobranca . '|' . $idParcela,
            situacaoProvedor: (string) ($j['status'] ?? ''),
            link: (string) ($j['url'] ?? ''),
            metodo: $forma,
            bruto: (string) $r['corpo']
        );
    }

    /** O uuid da pessoa no Conta Azul: acha pelo documento, senao cria. */
    private function cliente(array $conta, array $cliente): string
    {
        $documento = preg_replace('/\D+/', '', (string) ($cliente['cnpj'] ?? ''));
        if (!in_array(strlen($documento), array(11, 14), true)) {
            throw new \RuntimeException('O cliente esta sem CPF/CNPJ valido, e o Conta Azul cadastra a pessoa pelo documento.');
        }

        // `documentos` e busca por documento, mas confere o retorno: so a
        // pessoa com o MESMO documento serve, senao a venda vai para outro.
        $busca = (array) ($this->chamar($conta, 'GET', '/v1/pessoas?' . http_build_query(array(
            'documentos' => $documento, 'tamanho_pagina' => 10, 'pagina' => 1,
        )))['json'] ?? array());
        foreach ((array) ($busca['items'] ?? ($busca['itens'] ?? array())) as $p) {
            $doc = preg_replace('/\D+/', '', (string) ($p['documento'] ?? ''));
            $id = trim((string) ($p['id'] ?? ''));
            if ($id !== '' && $doc === $documento) {
                return $id;
            }
        }

        $endereco = Endereco::de($cliente);
        $carga = array(
            'nome' => mb_substr(trim((string) ($cliente['razao'] ?? '')) ?: 'Cliente', 0, 200),
            // Com acento: e o enum da API (Física | Jurídica | Estrangeira).
            'tipo_pessoa' => strlen($documento) === 14 ? 'Jurídica' : 'Física',
            'perfis' => array(array('tipo_perfil' => 'Cliente')),
            'enderecos' => array(array(
                'logradouro' => $endereco['rua'],
                'numero' => $endereco['numero'],
                'bairro' => $endereco['bairro'],
                'cidade' => $endereco['cidade'],
                'estado' => $endereco['uf'],
                'cep' => $endereco['cep'],
                'pais' => 'Brasil',
            )),
        );
        $carga[strlen($documento) === 14 ? 'cnpj' : 'cpf'] = $documento;
        $email = trim((string) ($cliente['email'] ?? ''));
        if ($email !== '') {
            $carga['email'] = $email;
        }

        $r = $this->chamar($conta, 'POST', '/v1/pessoas', $carga);
        $id = trim((string) ($r['json']['id'] ?? ''));
        if ($id === '') {
            throw new \RuntimeException('O Conta Azul aceitou o cliente e nao devolveu o id dele.');
        }

        return $id;
    }

    /**
     * O uuid do servico "Licenca de uso": o guardado na credencial; senao acha
     * pelo nome; senao cria, e GUARDA para nao procurar de novo.
     */
    private function servico(array $conta): string
    {
        $c = (array) ($conta['_credenciais'] ?? array());
        $id = (int) ($conta['id'] ?? 0);
        $guardado = trim((string) ($c['contaazul_servico'] ?? (self::$renovados[$id]['contaazul_servico'] ?? '')));
        if ($guardado !== '') {
            return $guardado;
        }

        $busca = (array) ($this->chamar($conta, 'GET', '/v1/servicos?' . http_build_query(array(
            'busca_textual' => self::SERVICO, 'tamanho_pagina' => 50, 'pagina' => 1,
        )))['json'] ?? array());
        // O OpenAPI descreve a resposta como lista de {itens, paginacao}; um
        // objeto solto tambem entra, porque e o que a maioria das rotas faz.
        $itens = (array) ($busca['itens'] ?? ($busca[0]['itens'] ?? array()));
        $achado = '';
        foreach ($itens as $s) {
            if (strcasecmp(trim((string) ($s['descricao'] ?? '')), self::SERVICO) === 0 && trim((string) ($s['id'] ?? '')) !== '') {
                $achado = trim((string) $s['id']);
                break;
            }
        }

        if ($achado === '') {
            $r = $this->chamar($conta, 'POST', '/v1/servicos', array(
                'descricao' => self::SERVICO,
                'tipo_servico' => 'PRESTADO',
                'status' => 'ATIVO',
            ));
            $achado = trim((string) ($r['json']['id'] ?? ''));
            if ($achado === '') {
                throw new \RuntimeException('O Conta Azul aceitou o servico e nao devolveu o id dele.');
            }
        }

        self::$renovados[$id] = array_merge(self::$renovados[$id] ?? array(), array('contaazul_servico' => $achado));
        Credenciais::renovadas($id, array('contaazul_servico' => $achado));

        return $achado;
    }

    // ---------------------------------------------------------------
    // Consulta
    // ---------------------------------------------------------------

    public function consultar(string $idExterno, array $conta): Resultado
    {
        if ($idExterno === self::SENTINELA) {
            return $this->testarConexao($conta);
        }

        $partes = explode('|', $idExterno, 2);
        $idCobranca = trim($partes[0]);
        $idParcela = trim((string) ($partes[1] ?? ''));

        $r = $this->chamar($conta, 'GET', self::COBRANCA . '/cobranca/' . rawurlencode($idCobranca));
        $j = (array) ($r['json'] ?? array());
        $situacaoProvedor = trim((string) ($j['status'] ?? ''));
        $situacao = self::traduzir($situacaoProvedor);

        // "PAGO" esta no enum e nao na documentacao: so vale com a parcela QUITADA.
        $pedirParcela = $idParcela !== '' && ($situacao === Resultado::PAGA || strtoupper($situacaoProvedor) === 'PAGO');
        $valorPago = null;
        $pagoEm = null;
        if ($pedirParcela) {
            $parcela = (array) ($this->chamar($conta, 'GET', '/v1/financeiro/eventos-financeiros/parcelas/' . rawurlencode($idParcela))['json'] ?? array());
            $parcelaQuitada = strtoupper(trim((string) ($parcela['status'] ?? ''))) === 'QUITADO';
            if ($situacao !== Resultado::PAGA) {
                $situacao = $parcelaQuitada ? Resultado::PAGA : Resultado::INDEFINIDA;
            }
            if ($situacao === Resultado::PAGA) {
                $recebido = (float) ($parcela['valor_pago'] ?? 0);
                $valorPago = $recebido > 0 ? (int) round($recebido * 100) : null;
                foreach ((array) ($parcela['baixas'] ?? array()) as $b) {
                    $quando = trim((string) ($b['data_pagamento'] ?? ''));
                    if ($quando !== '' && ($ts = strtotime($quando)) !== false) {
                        $pagoEm = date('Y-m-d H:i:s', $ts);
                    }
                }
            }
        }

        return new Resultado(
            situacao: $situacao,
            idExterno: $idExterno,
            situacaoProvedor: $situacaoProvedor,
            link: (string) ($j['url'] ?? ''),
            valorPagoCentavos: $situacao === Resultado::PAGA ? $valorPago : null,
            pagoEm: $situacao === Resultado::PAGA ? $pagoEm : null,
            bruto: (string) $r['corpo']
        );
    }

    /**
     * O TESTE DE CONEXAO LISTA AS CONTAS FINANCEIRAS: exige o token, nao cria
     * nada, e nao manda um uuid falso para a rota de cobranca. 200 e conectou;
     * 401 sobe com o codigo, que o teste da tela le como credencial recusada.
     */
    private function testarConexao(array $conta): Resultado
    {
        $r = $this->pedir($conta, 'GET', '/v1/conta-financeira?' . http_build_query(array('tamanho_pagina' => 10, 'pagina' => 1)));
        if ($r['codigo'] >= 400) {
            throw new \RuntimeException($this->motivo($r));
        }

        return new Resultado(situacao: Resultado::INDEFINIDA, idExterno: self::SENTINELA, bruto: (string) $r['corpo']);
    }

    /**
     * As contas que podem receber a cobranca: COBRANCAS_CONTA_AZUL, ou a
     * conta corrente (a Conta PJ do proprio Conta Azul). E o que o select de
     * Formas de recebimento oferece depois de conectar.
     *
     * @return array<int,array{id:string,nome:string,tipo:string}>
     */
    public function contasFinanceiras(array $conta): array
    {
        $rota = '/v1/conta-financeira?tipos=COBRANCAS_CONTA_AZUL&tipos=CONTA_CORRENTE&apenas_ativo=true&pagina=1&tamanho_pagina=100';
        $j = (array) ($this->chamar($conta, 'GET', $rota)['json'] ?? array());
        $lista = array();
        foreach ((array) ($j['itens'] ?? array()) as $i) {
            $tipo = strtoupper(trim((string) ($i['tipo'] ?? '')));
            $id = trim((string) ($i['id'] ?? ''));
            if ($id === '' || !in_array($tipo, array('COBRANCAS_CONTA_AZUL', 'CONTA_CORRENTE'), true)) {
                continue;
            }
            $lista[] = array('id' => $id, 'nome' => trim((string) ($i['nome'] ?? $id)), 'tipo' => $tipo);
        }

        return $lista;
    }

    public function cancelar(string $idExterno, array $conta): bool
    {
        $idCobranca = trim((string) explode('|', $idExterno, 2)[0]);
        try {
            $this->chamar($conta, 'DELETE', self::COBRANCA . '/cobranca/' . rawurlencode($idCobranca));

            return true;
        } catch (\RuntimeException $e) {
            return false;
        }
    }

    // ---------------------------------------------------------------
    // Webhook: nao existe
    // ---------------------------------------------------------------

    /** O Conta Azul nao manda aviso nenhum; quem descobre o pagamento e a conciliacao. */
    public function lerWebhook(string $corpo, array $cabecalhos, array $conta): ?EventoWebhook
    {
        return null;
    }

    // ---------------------------------------------------------------
    // Traducao -- conservadora: o que nao esta na lista NAO e pago
    // ---------------------------------------------------------------

    public static function traduzir(string $status): string
    {
        switch (strtoupper(trim($status))) {
            case 'QUITADO':
                return Resultado::PAGA;
            case 'AGUARDANDO_CONFIRMACAO':
            case 'REGISTRADO':
            case 'REMESSA_GERADO':
            case 'REMESSA_PENDENTE':
            case 'FALHA_CANCELAR':      // o cancelamento falhou: o codigo continua vivo
                return Resultado::ABERTA;
            case 'CANCELADO':
            case 'EXPIRADO':
            case 'INVALIDO':
            case 'FALHA_EMISSAO':
                return Resultado::CANCELADA;
            case 'EXTORNADO':           // e assim que a API escreve
                return Resultado::ESTORNADA;
            default:
                // PAGO (depende da parcela) e EM_CANCELAMENTO caem aqui.
                return Resultado::INDEFINIDA;
        }
    }
}
