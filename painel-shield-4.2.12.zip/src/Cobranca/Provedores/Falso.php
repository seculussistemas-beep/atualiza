<?php

namespace Shield\Cobranca\Provedores;

use Shield\Cobranca\EventoWebhook;
use Shield\Cobranca\Provedor;
use Shield\Cobranca\Resultado;

/**
 * Provedor de mentira, para a bancada - 25/08/2026.
 *
 * Ele nao fala com ninguem: o estado das cobrancas dele mora num arquivo JSON
 * na pasta de estagio. Serve para exercitar o motor inteiro -- emitir,
 * consultar, cancelar, webhook, conciliacao -- sem conta de sandbox, sem
 * internet e sem depender de o provedor de verdade estar no ar.
 *
 * ELE E O QUE PROVA A INTERFACE. Um adaptador que so existe em teste obriga o
 * motor a nao saber nada sobre gateway nenhum: qualquer coisa especifica de
 * Asaas que vazasse para o motor faria este aqui parar de funcionar.
 *
 * TAMBEM SERVE AOS CASOS QUE NINGUEM CONSEGUE PRODUZIR SOB DEMANDA num gateway
 * real: pagamento que nunca chega, resposta que a gente nao sabe ler, webhook
 * repetido e fora de ordem. Regra que so e exercitada quando da errado no
 * cliente nao esta testada.
 *
 * NAO E DISTRIBUIDO COMO OPCAO AO MEMBRO: ele so aparece se alguem cadastrar
 * uma conta com o provedor "falso" a mao, e a tela de contas nao o oferece.
 */
final class Falso implements Provedor
{
    public const ARQUIVO = 'falso.json';

    public function nome(): string
    {
        return 'falso';
    }

    public function capacidades(array $conta): array
    {
        return array(
            'pix' => true,
            'boleto' => true,
            'cartao' => true,
            'assinatura' => true,
            'automatico' => true,
        );
    }

    private static function caminho(): string
    {
        $pasta = dirname(__DIR__, 3) . '/estagio/pacotes';
        if (!is_dir($pasta)) {
            @mkdir($pasta, 0775, true);
        }

        return $pasta . '/' . self::ARQUIVO;
    }

    private static function ler(): array
    {
        $p = self::caminho();
        if (!is_file($p)) {
            return array();
        }
        $d = json_decode((string) @file_get_contents($p), true);

        return is_array($d) ? $d : array();
    }

    private static function gravar(array $estado): void
    {
        @file_put_contents(self::caminho(), json_encode($estado, JSON_UNESCAPED_SLASHES));
    }

    /** Usado pela bancada para dizer o que o "provedor" vai responder. */
    public static function definir(string $idExterno, array $dados): void
    {
        $estado = self::ler();
        $estado[$idExterno] = array_merge($estado[$idExterno] ?? array(), $dados);
        self::gravar($estado);
    }

    public static function limpar(): void
    {
        @unlink(self::caminho());
    }

    /**
     * A bancada derruba a EMISSAO. E o caso que nenhum gateway produz sob
     * demanda e que deixa a reemissao no meio do caminho: o codigo antigo ja
     * cancelado e o novo que nunca nasceu.
     */
    public static function recusarCriar(bool $recusa = true): void
    {
        $estado = self::ler();
        $estado['__recusa_criar'] = $recusa;
        self::gravar($estado);
    }

    /**
     * O que a PROXIMA emissao devolve no lugar do PIX de sempre -- 'copia_e_cola',
     * 'link' e 'linha_digitavel' --, para exercitar o boleto hibrido sem gateway.
     * Vale uma vez.
     */
    public static function proximaEmissao(array $campos): void
    {
        $estado = self::ler();
        $estado['__proxima_emissao'] = $campos;
        self::gravar($estado);
    }

    public function criar(array $cobranca, array $conta, array $cliente): Resultado
    {
        if (!empty(self::ler()['__recusa_criar'])) {
            throw new \RuntimeException('o provedor de bancada esta fora do ar');
        }
        $estado = self::ler();
        $campos = (array) ($estado['__proxima_emissao'] ?? array());
        if ($campos !== array()) {
            unset($estado['__proxima_emissao']);
            self::gravar($estado);
        }

        // ID NOVO A CADA EMISSAO, como gateway de verdade. A primeira versao
        // usava so o id da cobranca, e reemitir SOBRESCREVIA o estado do PIX
        // antigo -- o teste via "aberta" onde devia ver o cancelamento.
        $id = 'FALSO-' . (int) ($cobranca['id'] ?? 0);
        $estado = self::ler();
        for ($n = 2; isset($estado[$id]); $n++) {
            $id = 'FALSO-' . (int) ($cobranca['id'] ?? 0) . '-' . $n;
        }
        self::definir($id, array(
            'situacao' => Resultado::ABERTA,
            'valor' => (int) $cobranca['valor_centavos'],
            'situacao_provedor' => 'PENDING',
            // O endereco do aviso que o motor entregou, para o teste conferir.
            'url_webhook' => (string) ($conta['_url_webhook'] ?? ''),
            // A regra de multa e juros que o motor entregou (14/10/2026).
            'encargos' => $conta['_encargos'] ?? null,
        ));

        return new Resultado(
            situacao: Resultado::ABERTA,
            idExterno: $id,
            situacaoProvedor: 'PENDING',
            link: (string) ($campos['link'] ?? 'https://exemplo.invalido/cobranca/' . $id),
            copiaECola: (string) ($campos['copia_e_cola'] ?? '00020126FALSO' . $id),
            metodo: 'pix',
            bruto: json_encode(array('id' => $id, 'status' => 'PENDING')),
            linhaDigitavel: (string) ($campos['linha_digitavel'] ?? '')
        );
    }

    public function consultar(string $idExterno, array $conta): Resultado
    {
        $estado = self::ler();
        if (!isset($estado[$idExterno])) {
            // Cobranca que o provedor nao conhece nao e "cancelada" nem "paga".
            return new Resultado(
                situacao: Resultado::INDEFINIDA,
                idExterno: $idExterno,
                situacaoProvedor: 'desconhecida'
            );
        }

        $linha = $estado[$idExterno];
        $situacao = (string) ($linha['situacao'] ?? Resultado::ABERTA);

        return new Resultado(
            situacao: $situacao,
            idExterno: $idExterno,
            situacaoProvedor: (string) ($linha['situacao_provedor'] ?? ''),
            // O codigo que so aparece na consulta (boleto assincrono, como o do
            // Inter): a bancada o define com 'copia_e_cola' e 'link'.
            link: (string) ($linha['link'] ?? ''),
            copiaECola: (string) ($linha['copia_e_cola'] ?? ''),
            valorPagoCentavos: $situacao === Resultado::PAGA
                ? (int) ($linha['valor_pago'] ?? $linha['valor'] ?? 0) : null,
            pagoEm: $situacao === Resultado::PAGA ? (string) ($linha['pago_em'] ?? date('Y-m-d H:i:s')) : null,
            metodo: 'pix',
            bruto: json_encode($linha),
            linhaDigitavel: (string) ($linha['linha_digitavel'] ?? '')
        );
    }

    /** O que a bancada gravou para um id -- para o teste conferir o que o "provedor" viu. */
    public static function consultarEstado(string $idExterno): array
    {
        return self::ler()[$idExterno] ?? array();
    }

    /** O PDF do boleto do Inter, para o motor ter onde testar a rota (19/10/2026). */
    public function pdfBoleto(string $idExterno, array $conta): string
    {
        return "%PDF-1.4
% boleto falso de " . $idExterno . "
";
    }

    /** O "recebido em dinheiro" do Asaas, para o motor ter onde testar a baixa. */
    public function receberEmDinheiro(string $idExterno, array $conta, int $valorCentavos, string $data): bool
    {
        if (!empty(self::ler()[$idExterno]['recusa_baixa'])) {
            throw new \RuntimeException('Falso recusou a baixa.');
        }
        self::definir($idExterno, array('situacao' => Resultado::PAGA, 'situacao_provedor' => 'RECEIVED_IN_CASH',
                                        'valor_pago' => $valorCentavos, 'pago_em' => $data));

        return true;
    }

    public function cancelar(string $idExterno, array $conta): bool
    {
        // Gateway de verdade recusa cancelar o que ja foi pago, ou quando a
        // credencial caiu. A bancada liga essa recusa com 'recusa_cancelar'.
        if (!empty(self::ler()[$idExterno]['recusa_cancelar'])) {
            return false;
        }
        self::definir($idExterno, array('situacao' => Resultado::CANCELADA,
                                        'situacao_provedor' => 'CANCELLED'));

        return true;
    }

    public function lerWebhook(string $corpo, array $cabecalhos, array $conta): ?EventoWebhook
    {
        $dados = json_decode($corpo, true);
        if (!is_array($dados) || empty($dados['evento'])) {
            return null;
        }

        // O segredo confere igual ao de um gateway de verdade: e o que faz o
        // teste do webhook forjado medir alguma coisa.
        $segredo = trim((string) ($conta['webhook_segredo'] ?? ''));
        $enviado = (string) ($cabecalhos['x-shield-assinatura'] ?? '');
        $confere = $segredo === '' || hash_equals(hash_hmac('sha256', $corpo, $segredo), $enviado);

        return new EventoWebhook(
            id: (string) $dados['evento'],
            tipo: (string) ($dados['tipo'] ?? 'cobranca'),
            idExterno: (string) ($dados['id_externo'] ?? ''),
            assinaturaConfere: $confere,
            corpo: $corpo,
            // O id completo que a fila grava na tentativa (ver
            // EventoWebhook::idParaConsultar): a bancada exercita o caminho
            // da InfinitePay sem a InfinitePay.
            idParaConsultar: (string) ($dados['id_para_consultar'] ?? '')
        );
    }
}
