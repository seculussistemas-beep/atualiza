<?php

namespace Shield\Cobranca\Provedores;

use Shield\Cobranca\CodigoDePagamento;
use Shield\Cobranca\Endereco;
use Shield\Cobranca\EventoWebhook;
use Shield\Cobranca\Http;
use Shield\Cobranca\Prazo;
use Shield\Cobranca\Provedor;
use Shield\Cobranca\Resultado;

/**
 * Mercado Pago - 25/08/2026.
 *
 * Usa a API de PAGAMENTOS (`/v1/payments`), e nao a de preferencias: aqui a
 * cobranca precisa ter um identificador consultavel do lado de ca desde o
 * primeiro instante, e preferencia so vira pagamento depois que alguem abre o
 * link -- ate la nao ha o que consultar, e a fonte da verdade desta casa e o
 * `consultar()`.
 *
 * O PIX SAI PRONTO NA CRIACAO: o copia-e-cola vem em
 * point_of_interaction.transaction_data.qr_code, na MESMA resposta. Boleto
 * idem, em transaction_details.external_resource_url. Nao ha segunda chamada.
 *
 * O WEBHOOK DO MERCADO PAGO NAO TRAZ A SITUACAO -- ele manda so o id e o tipo,
 * e espera que voce va perguntar. Isso casa exatamente com a regra da casa: o
 * webhook DISPARA a verificacao, nunca a substitui.
 */
final class MercadoPago implements Provedor
{
    private const BASE = 'https://api.mercadopago.com';

    /**
     * O data.id da URL do aviso, que a fila entrega como cabecalho sintetico
     * (shield_webhook_cabecalhos): a assinatura e calculada sobre ele, e o
     * adaptador so recebe cabecalhos e corpo.
     */
    public const CABECALHO_DATA_ID = 'x-shield-data-id';

    /**
     * A janela do ts assinado: 48 horas, o mesmo corte da LojadevCentral. O
     * Mercado Pago reapresenta o mesmo aviso por horas sem garantia de reassinar,
     * e janela curta recusaria entrega legitima ate ele desistir.
     */
    public const JANELA_ASSINATURA_SEGUNDOS = 172800;

    public function nome(): string
    {
        return 'mercadopago';
    }

    public function capacidades(array $conta): array
    {
        return array(
            'pix' => true,
            // BOLETO E CARTAO DESDE 10/09/2026 (tarde). Boleto sai pela mesma
            // API de pagamentos (bolbradesco); cartao e um LINK de Checkout
            // Pro que so aceita cartao -- o painel nunca ve o numero. Ver
            // criarBoleto() e criarCartao().
            'boleto' => true,
            'cartao' => true,
            // Assinatura recorrente do MP e outra API (preapproval), com outro
            // fluxo de autorizacao. Declarar `false` e honesto: quem precisa de
            // recorrencia usa o modo em que o PAINEL gera a cobranca do ciclo.
            'assinatura' => false,
            'automatico' => true,
        );
    }

    private function token(array $conta): string
    {
        $c = (array) ($conta['_credenciais'] ?? array());
        $token = trim((string) ($c['access_token'] ?? ''));
        if ($token === '') {
            throw new \RuntimeException('A conta do Mercado Pago esta sem o Access Token.');
        }

        return $token;
    }

    private function cabecalhos(array $conta, string $chaveIdempotencia = ''): array
    {
        $h = array(
            'Authorization: Bearer ' . $this->token($conta),
            'Accept: application/json',
            'User-Agent: PainelShield',
        );

        if ($chaveIdempotencia !== '') {
            // A CHAVE SAI DA OPERACAO, e nao de random_bytes -- 03/09/2026.
            //
            // Ela vinha sendo sorteada a cada chamada, e assim nao protegia de
            // nada: dois cliques no botao geravam duas chaves diferentes, o
            // Mercado Pago via duas operacoes distintas e criava DUAS cobrancas
            // para o mesmo cliente, que entao recebia dois avisos de PIX.
            //
            // Derivada da cobranca, a repeticao da MESMA operacao manda a MESMA
            // chave, e o MP devolve a cobranca que ja existe em vez de criar
            // outra. Isso cobre tambem o caso pior que o clique duplo: o POST
            // estourar o tempo com a cobranca ja criada do outro lado, e o
            // painel reenviar sem saber.
            $h[] = 'X-Idempotency-Key: ' . $chaveIdempotencia;
        }

        return $h;
    }

    private function chamar(
        array $conta,
        string $metodo,
        string $rota,
        ?array $carga = null,
        string $chaveIdempotencia = ''
    ): array {
        $r = Http::json($metodo, self::BASE . '/' . ltrim($rota, '/'),
                        $this->cabecalhos($conta, $chaveIdempotencia), $carga);

        if ($r['erro'] !== '') {
            throw new \RuntimeException($r['erro']);
        }
        if ($r['codigo'] >= 400) {
            // O MP devolve o motivo util em `cause[].description`; o `message`
            // sozinho costuma ser um codigo interno que nao ajuda ninguem.
            $motivos = array();
            foreach ((array) ($r['json']['cause'] ?? array()) as $c) {
                if (!empty($c['description'])) {
                    $motivos[] = (string) $c['description'];
                }
            }
            $texto = $motivos ? implode(' | ', $motivos)
                : trim((string) ($r['json']['message'] ?? ''));

            if ($r['codigo'] === 401 || $r['codigo'] === 403) {
                // Credencial recusada: a mensagem crua do provedor ("authorization
                // value not present") nao diz ao membro o que fazer.
                throw new \RuntimeException('O Mercado Pago recusou a credencial desta conta (HTTP ' . $r['codigo']
                    . '). Confira o access token em Formas de recebimento.');
            }
            $daConta = self::recusaDaContaQueRecebe($texto);
            if ($daConta !== '') {
                throw new \RuntimeException($daConta . ' (o Mercado Pago respondeu: ' . $texto . ')');
            }

            throw new \RuntimeException('Mercado Pago recusou (HTTP ' . $r['codigo'] . ')'
                . ($texto !== '' ? ': ' . $texto : '.'));
        }

        return $r;
    }

    /**
     * A RECUSA QUE E DA CONTA DO MEMBRO, E NAO DA COBRANCA -- 23/09/2026, membro
     * na 4.2.10 com "Error in Financial Identity Use Case" na tela.
     *
     * O PIX do Mercado Pago so sai de conta com chave PIX cadastrada e
     * identidade conferida; sem isso a criacao volta 400 com uma frase que fala
     * do USE CASE interno deles e nao diz ao membro que o problema esta na conta
     * que recebe -- e ele fica conferindo o access token e o cadastro do
     * cliente, que estao certos. Devolve '' quando a recusa nao e dessa familia.
     *
     * A frase crua vai junto na mensagem: e ela que o suporte do Mercado Pago
     * pede, e sem ela o membro fica sem o que mostrar la.
     *
     * CONFIRMADO NO MEMBRO no mesmo dia: ele tinha PEDIDO A PORTABILIDADE da
     * chave para o Mercado Pago e ela ainda nao tinha migrado -- para o painel e
     * para a API, conta sem chave. Cadastrar uma chave ALEATORIA resolveu na
     * hora, e e por isso que a frase manda nela: nao depende de portabilidade,
     * de telefone nem de e-mail, e quem recebe o PIX e o QR, nao a chave.
     */
    private static function recusaDaContaQueRecebe(string $texto): string
    {
        $t = mb_strtolower($texto);
        $daConta = strpos($t, 'financial identity') !== false
            || strpos($t, 'collector user without key') !== false
            || strpos($t, 'without key enabled for qr render') !== false;

        if (!$daConta) {
            return '';
        }

        return 'A conta do Mercado Pago que recebe ainda nao esta pronta para gerar PIX: cadastre nela uma chave'
            . ' PIX ALEATORIA (no aplicativo, em Seu negocio / Identidade financeira) e emita de novo. Chave pedida'
            . ' por portabilidade so vale depois que o outro banco libera, e ate la a conta conta como sem chave.'
            . ' Se ja houver chave, confira se a identidade da conta foi conferida e se o access token e o de'
            . ' producao DESSA conta.';
    }

    public function criar(array $cobranca, array $conta, array $cliente): Resultado
    {
        $forma = strtolower(trim((string) ($cobranca['forma'] ?? 'pix')));
        if ($forma === 'cartao') {
            return $this->criarCartao($cobranca, $conta, $cliente);
        }

        $centavos = (int) $cobranca['valor_centavos'];
        $documento = preg_replace('/[^0-9]/', '', (string) ($cliente['cnpj'] ?? ''));
        $email = trim((string) ($cliente['email'] ?? ''));
        list($nome, $sobrenome) = Endereco::nomeEmDois((string) ($cliente['razao'] ?? ''));

        $carga = array(
            'transaction_amount' => round($centavos / 100, 2),
            'description' => (string) ($cobranca['descricao'] ?? 'Licenca de uso'),
            'payment_method_id' => $forma === 'boleto' ? 'bolbradesco' : 'pix',
            'external_reference' => 'shield-' . (int) $cobranca['id'],
            'payer' => array(
                // O MP EXIGE e-mail. Sem um valido ele recusa a cobranca
                // inteira, entao o painel usa um endereco tecnico da propria
                // instalacao em vez de deixar a cobranca morrer no cadastro.
                'email' => $email !== '' ? $email : 'sem-email+' . $documento . '@painelshield.local',
                'first_name' => $nome,
                'last_name' => $sobrenome,
                'identification' => array(
                    'type' => strlen($documento) === 14 ? 'CNPJ' : 'CPF',
                    'number' => $documento,
                ),
            ),
        );

        if ($forma === 'boleto') {
            // O BOLETO PEDE ENDERECO COMPLETO do pagador; sem ele o MP recusa
            // com "payer.address" e nao diz qual campo.
            $e = Endereco::de($cliente);
            $carga['payer']['address'] = array(
                'zip_code' => $e['cep'], 'street_name' => $e['rua'], 'street_number' => $e['numero'],
                'neighborhood' => $e['bairro'], 'city' => $e['cidade'], 'federal_unit' => $e['uf'],
            );
        }

        // O PIX do MP expira; sem data ele usa um padrao curto demais para
        // cobranca com vencimento la na frente. No boleto a mesma data e o
        // vencimento impresso.
        // O piso de tres dias e o que impede a reemissao de uma cobranca
        // vencida de nascer com data passada, que o MP recusa. Ver
        // Shield\Cobranca\Prazo (11/09/2026).
        $venc = trim((string) ($cobranca['vencimento'] ?? ''));
        if ($venc !== '') {
            $carga['date_of_expiration'] = Prazo::fim($venc)->format('Y-m-d\TH:i:s.vP');
        }

        // A chave e a propria cobranca: reenvio da mesma cobranca faz o MP
        // devolver a que ja existe, em vez de criar outra.
        $r = $this->chamar($conta, 'POST', '/v1/payments', $carga,
                           'shield-cob-' . (int) $cobranca['id']);
        $j = (array) $r['json'];
        $ponto = (array) ($j['point_of_interaction']['transaction_data'] ?? array());
        $linha = $forma === 'boleto' ? self::linhaDoBoleto($j) : '';

        return new Resultado(
            situacao: $this->traduzir((string) ($j['status'] ?? '')),
            idExterno: (string) ($j['id'] ?? ''),
            situacaoProvedor: (string) ($j['status'] ?? ''),
            link: $forma === 'boleto'
                ? (string) ($j['transaction_details']['external_resource_url'] ?? '')
                : (string) ($ponto['ticket_url'] ?? ''),
            copiaECola: $forma === 'boleto' ? $linha : (string) ($ponto['qr_code'] ?? ''),
            metodo: $forma === 'boleto' ? 'boleto' : 'pix',
            bruto: (string) json_encode($j),
            linhaDigitavel: $linha
        );
    }

    /**
     * A linha digitavel do boleto -- 17/09/2026. O copia e cola levava o
     * `barcode.content` do topo da resposta: o codigo de barras de 44 posicoes,
     * feito para a leitora, que ninguem digita no banco e que o ERP desenhava
     * como QR de PIX. Os SDKs oficiais do MP poem os dois em
     * `transaction_details`: `digitable_line` e `barcode.content`. Sem a linha,
     * ela sai do codigo de barras (o do topo fica como ultima tentativa).
     */
    private static function linhaDoBoleto(array $j): string
    {
        $detalhes = (array) ($j['transaction_details'] ?? array());
        $linha = CodigoDePagamento::linha((string) ($detalhes['digitable_line'] ?? ''));
        if ($linha !== '') {
            return $linha;
        }
        foreach (array($detalhes['barcode'] ?? null, $j['barcode'] ?? null) as $bloco) {
            if (is_array($bloco) && trim((string) ($bloco['content'] ?? '')) !== '') {
                return CodigoDePagamento::linhaDoCodigoDeBarras((string) $bloco['content']);
            }
        }

        return '';
    }

    /**
     * Cartao e um LINK do Checkout Pro que so aceita cartao. O painel nao
     * tokeniza cartao nem guarda numero: o cliente digita no site do MP.
     *
     * O id externo guarda a preferencia E a cobranca ("pref:<id>:<cob>"),
     * porque preferencia nao tem situacao -- quem tem e o pagamento que ela
     * gera, e ele so se acha pelo external_reference. Ver consultar().
     */
    private function criarCartao(array $cobranca, array $conta, array $cliente): Resultado
    {
        $documento = preg_replace('/[^0-9]/', '', (string) ($cliente['cnpj'] ?? ''));
        $email = trim((string) ($cliente['email'] ?? ''));
        $venc = trim((string) ($cobranca['vencimento'] ?? ''));

        $carga = array(
            'items' => array(array(
                'id' => 'shield-' . (int) $cobranca['id'],
                'title' => (string) ($cobranca['descricao'] ?? 'Licenca de uso'),
                'quantity' => 1,
                'currency_id' => 'BRL',
                'unit_price' => round(((int) $cobranca['valor_centavos']) / 100, 2),
            )),
            'payer' => array(
                'email' => $email !== '' ? $email : 'sem-email+' . $documento . '@painelshield.local',
                'identification' => array('type' => strlen($documento) === 14 ? 'CNPJ' : 'CPF', 'number' => $documento),
            ),
            'external_reference' => 'shield-' . (int) $cobranca['id'],
            // SO CARTAO: boleto (ticket), pix (bank_transfer) e caixa
            // eletronico (atm) ficam fora, senao o cliente pagaria por outra
            // forma um link que a cobranca registrou como cartao.
            'payment_methods' => array(
                'excluded_payment_types' => array(array('id' => 'ticket'), array('id' => 'bank_transfer'), array('id' => 'atm')),
                'installments' => 1,
            ),
            'statement_descriptor' => 'LICENCA',
        );
        if ($venc !== '') {
            $carga['expires'] = true;
            $carga['expiration_date_to'] = (new \DateTimeImmutable($venc . ' 23:59:59'))->format('Y-m-d\TH:i:s.vP');
        }

        $j = (array) $this->chamar($conta, 'POST', '/checkout/preferences', $carga,
                                   'shield-pref-' . (int) $cobranca['id'])['json'];

        return new Resultado(
            situacao: Resultado::ABERTA,
            idExterno: 'pref:' . (string) ($j['id'] ?? '') . ':' . (int) $cobranca['id'],
            situacaoProvedor: 'checkout aberto',
            link: (string) ($j['init_point'] ?? ''),
            metodo: 'cartao',
            bruto: (string) json_encode($j)
        );
    }

    /** "pref:<id>:<cobranca>" -> [id, cobranca], ou null quando nao e checkout. */
    private function preferencia(string $idExterno): ?array
    {
        if (strpos($idExterno, 'pref:') !== 0) {
            return null;
        }
        $partes = explode(':', $idExterno, 3);

        return count($partes) === 3 ? array($partes[1], (int) $partes[2]) : null;
    }

    /** O pagamento que a preferencia gerou: o aprovado, se houver; senao o mais recente; senao null. */
    private function pagamentoDaPreferencia(array $conta, int $cobranca): ?array
    {
        $r = $this->chamar($conta, 'GET', '/v1/payments/search?external_reference='
            . rawurlencode('shield-' . $cobranca) . '&sort=date_created&criteria=desc');
        $lista = (array) ($r['json']['results'] ?? array());
        foreach ($lista as $pg) {
            if (in_array((string) ($pg['status'] ?? ''), array('approved', 'authorized'), true)) {
                return (array) $pg;
            }
        }

        return $lista ? (array) $lista[0] : null;
    }

    public function consultar(string $idExterno, array $conta): Resultado
    {
        $pref = $this->preferencia($idExterno);
        if ($pref !== null) {
            // Checkout de cartao: a situacao e do pagamento que ele gerou.
            $pg = $this->pagamentoDaPreferencia($conta, $pref[1]);
            if ($pg === null) {
                $p = (array) $this->chamar($conta, 'GET', '/checkout/preferences/' . rawurlencode($pref[0]))['json'];

                return new Resultado(
                    situacao: Resultado::ABERTA,
                    idExterno: $idExterno,
                    situacaoProvedor: 'checkout aberto',
                    link: (string) ($p['init_point'] ?? ''),
                    metodo: 'cartao',
                    bruto: (string) json_encode($p)
                );
            }
            $j = $pg;
            $pago = trim((string) ($j['date_approved'] ?? ''));

            return new Resultado(
                situacao: $this->traduzir((string) ($j['status'] ?? '')),
                idExterno: $idExterno,
                situacaoProvedor: (string) ($j['status'] ?? ''),
                valorPagoCentavos: isset($j['transaction_amount'])
                    ? (int) round(((float) $j['transaction_amount'] - (float) ($j['transaction_amount_refunded'] ?? 0)) * 100)
                    : null,
                pagoEm: $pago !== '' ? date('Y-m-d H:i:s', strtotime($pago)) : null,
                metodo: 'cartao',
                bruto: (string) json_encode($j)
            );
        }

        $r = $this->chamar($conta, 'GET', '/v1/payments/' . rawurlencode($idExterno));
        $j = (array) $r['json'];
        $ponto = (array) ($j['point_of_interaction']['transaction_data'] ?? array());
        $pago = trim((string) ($j['date_approved'] ?? ''));
        // O boleto e `ticket`; perguntado pelos campos do PIX, voltava sem codigo.
        $boleto = (string) ($j['payment_type_id'] ?? '') === 'ticket';
        $linha = $boleto ? self::linhaDoBoleto($j) : '';

        return new Resultado(
            situacao: $this->traduzir((string) ($j['status'] ?? '')),
            idExterno: (string) ($j['id'] ?? $idExterno),
            situacaoProvedor: (string) ($j['status'] ?? ''),
            link: $boleto
                ? (string) ($j['transaction_details']['external_resource_url'] ?? '')
                : (string) ($ponto['ticket_url'] ?? ''),
            copiaECola: $boleto ? $linha : (string) ($ponto['qr_code'] ?? ''),
            linhaDigitavel: $linha,
            // `transaction_amount_refunded` desconta estorno parcial: sem isso
            // uma devolucao de metade apareceria como pagamento cheio.
            valorPagoCentavos: isset($j['transaction_amount'])
                ? (int) round(((float) $j['transaction_amount']
                    - (float) ($j['transaction_amount_refunded'] ?? 0)) * 100)
                : null,
            pagoEm: $pago !== '' ? date('Y-m-d H:i:s', strtotime($pago)) : null,
            bruto: (string) json_encode($j)
        );
    }

    public function cancelar(string $idExterno, array $conta): bool
    {
        $pref = $this->preferencia($idExterno);
        if ($pref !== null) {
            // Checkout ja pago nao se cancela; sem pagamento, a preferencia
            // expira agora e o link morre.
            try {
                $pg = $this->pagamentoDaPreferencia($conta, $pref[1]);
                if ($pg !== null && $this->traduzir((string) ($pg['status'] ?? '')) === Resultado::PAGA) {
                    return false;
                }
                $this->chamar($conta, 'PUT', '/checkout/preferences/' . rawurlencode($pref[0]),
                              array('expires' => true, 'expiration_date_to' => (new \DateTimeImmutable('-1 minute'))->format('Y-m-d\TH:i:s.vP')));

                return true;
            } catch (\RuntimeException $e) {
                return false;
            }
        }

        try {
            $this->chamar($conta, 'PUT', '/v1/payments/' . rawurlencode($idExterno),
                          array('status' => 'cancelled'),
                          'shield-cancel-' . $idExterno);

            return true;
        } catch (\RuntimeException $e) {
            // Pagamento ja aprovado nao cancela -- estorna, que e outra coisa
            // e nao pode acontecer sem alguem mandar.
            return false;
        }
    }

    public function lerWebhook(string $corpo, array $cabecalhos, array $conta): ?EventoWebhook
    {
        $j = json_decode($corpo, true);
        if (!is_array($j)) {
            return null;
        }
        $tipo = (string) ($j['type'] ?? $j['topic'] ?? '');
        if (strpos($tipo, 'payment') === false) {
            return null;      // merchant_order e afins nao interessam aqui
        }
        $id = (string) ($j['data']['id'] ?? $j['resource'] ?? '');
        if ($id === '') {
            return null;
        }
        // O ID pode vir como URL em avisos antigos do MP.
        if (strpos($id, '/') !== false) {
            $id = (string) substr($id, (int) strrpos($id, '/') + 1);
        }

        // O CORPO NAO TRAZ A SITUACAO, so o id -- e assim que o Mercado Pago
        // funciona, e casa exatamente com a regra da casa: o webhook DISPARA a
        // verificacao, nunca a substitui.
        $confere = self::assinaturaConfere(
            $cabecalhos,
            (string) ($j['data']['id'] ?? ''),
            trim((string) ($conta['webhook_segredo'] ?? ''))
        );

        return new EventoWebhook(
            id: (string) ($j['id'] ?? ($tipo . '-' . $id)),
            tipo: $tipo,
            idExterno: $id,
            assinaturaConfere: $confere,
            corpo: $corpo
        );
    }

    /**
     * A ASSINATURA SECRETA DO AVISO -- 17/09/2026.
     *
     * Ate aqui a conferencia procurava o texto do segredo DENTRO do x-signature,
     * que nunca o traz: com a assinatura gravada, todo aviso de verdade era
     * recusado e a baixa ficava so com a conciliacao; sem ela, qualquer POST
     * passava. O que a documentacao manda:
     *
     *   x-signature: ts=<ts>,v1=<hex>
     *   manifesto:   id:<data.id>;request-id:<x-request-id>;ts:<ts>;
     *   v1 = HMAC-SHA256(manifesto, assinatura secreta), em hexadecimal
     *
     * O data.id e o da URL, em minusculas quando alfanumerico; o do corpo entra
     * como segundo candidato (e o mesmo id, e a comparacao continua
     * criptografica, entao tentar os dois nao afrouxa nada). Valor que nao veio
     * sai do manifesto. O ts vem em segundos ou em milissegundos, e so e olhado
     * DEPOIS da assinatura: antes dela, ele nao prova nada.
     *
     * SEM A ASSINATURA SECRETA GRAVADA, RECUSA. Aceitar sem conferir diria que o
     * aviso funciona sobre um endpoint aberto a qualquer POST; a baixa de quem
     * nao a gravou chega pela conciliacao. A mesma regra da LojadevCentral
     * (RecebimentoWebhookController).
     */
    public static function assinaturaConfere(array $cabecalhos, string $idDoCorpo, string $segredo, ?int $agora = null): bool
    {
        if ($segredo === '') {
            return false;
        }

        $partes = array();
        foreach (explode(',', (string) ($cabecalhos['x-signature'] ?? '')) as $pedaco) {
            $par = explode('=', trim($pedaco), 2);
            $partes[strtolower(trim($par[0]))] = trim((string) ($par[1] ?? ''));
        }
        $ts = (string) ($partes['ts'] ?? '');
        $v1 = strtolower((string) ($partes['v1'] ?? ''));
        if (!ctype_digit($ts) || $v1 === '') {
            return false;
        }

        $pedido = trim((string) ($cabecalhos['x-request-id'] ?? ''));
        $candidatos = array_values(array_unique(array_filter(
            array(trim((string) ($cabecalhos[self::CABECALHO_DATA_ID] ?? '')), trim($idDoCorpo)),
            'strlen'
        )));
        if ($candidatos === array()) {
            $candidatos = array('');
        }

        foreach ($candidatos as $dataId) {
            $manifesto = ($dataId !== '' ? 'id:' . strtolower($dataId) . ';' : '')
                . ($pedido !== '' ? 'request-id:' . $pedido . ';' : '')
                . 'ts:' . $ts . ';';
            if (hash_equals(hash_hmac('sha256', $manifesto, $segredo), $v1)) {
                $segundos = (float) $ts > 20000000000 ? intdiv((int) $ts, 1000) : (int) $ts;

                return abs(($agora ?? time()) - $segundos) <= self::JANELA_ASSINATURA_SEGUNDOS;
            }
        }

        return false;
    }

    /** O vocabulario do MP para o desta casa. */
    private function traduzir(string $status): string
    {
        switch ($status) {
            case 'approved':
                return Resultado::PAGA;
            case 'refunded':
            case 'charged_back':
                return Resultado::ESTORNADA;
            case 'cancelled':
            case 'rejected':
                return Resultado::CANCELADA;
            case 'pending':
            case 'in_process':
            case 'in_mediation':
            // AUTORIZADO NAO E PAGO -- 17/09/2026. No cartao, "authorized" e
            // dinheiro reservado e ainda nao capturado: pode nao virar pagamento
            // nenhum, e como PAGA estenderia a licenca por uma reserva. O PagBank
            // ja tratava assim.
            case 'authorized':
                return Resultado::ABERTA;
            default:
                return Resultado::INDEFINIDA;
        }
    }
}
