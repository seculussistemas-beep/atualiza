<?php

namespace Shield\Cobranca\Provedores;

use Shield\Cobranca\CodigoDePagamento;
use Shield\Cobranca\Endereco;
use Shield\Cobranca\EventoWebhook;
use Shield\Cobranca\Http;
use Shield\Cobranca\Prazo;
use Shield\Cobranca\Provedor;
use Shield\Cobranca\Resultado;
use Shield\Cobranca\TokenWebhook;

/**
 * C6 Bank -- BolePix (boleto com PIX) pela API BaaS - 16/09/2026.
 *
 * NINGUEM RODOU ISTO CONTRA O C6, NEM EM SANDBOX. O membro que o escreveu nao
 * conseguiu ativar o servico de cobranca na conta dele, e este painel nao tem
 * conta no C6. Tudo aqui -- endpoints, campos, vocabulario de situacao, o
 * formato do aviso -- saiu da documentacao OpenAPI 1.1.x do banco, lida por
 * ele. A primeira emissao real precisa ser acompanhada de perto, e a primeira
 * consulta tambem: e provavel que algum nome de campo esteja errado.
 *
 * O que foi TIRADO do que o membro mandou: o "PIX Automatico" (exige um
 * idRec autorizado pelo pagador, que o painel nao tem como obter) e o link
 * para um `/c6_bolepix_pdf.php` que nao existia no pacote -- o `link` fica
 * vazio e o `copiaECola` leva o QR do PIX (ou a linha digitavel).
 *
 * mTLS em tudo, com o .crt e o .key em base64 (a tela os recebe por upload);
 * o PEM do Http e um colado no outro. O token e formulario, como no Inter.
 * A API pede dois cabecalhos de identificacao do parceiro em toda chamada
 * (partner-software-name/version).
 */
final class C6Bank implements Provedor
{
    private const SENTINELA = 'shield-teste-inexistente-0';

    public function nome(): string
    {
        return 'c6bank';
    }

    public function capacidades(array $conta): array
    {
        return array(
            'pix' => true,
            'boleto' => true,
            'cartao' => false,
            'assinatura' => false,
            'automatico' => true,
        );
    }

    private function base(array $conta): string
    {
        return ((string) ($conta['ambiente'] ?? 'producao')) === 'producao'
            ? 'https://baas-api.c6bank.info'
            : 'https://baas-api-sandbox.c6bank.info';
    }

    private function credenciais(array $conta): array
    {
        $c = (array) ($conta['_credenciais'] ?? array());
        $obrigatorios = array(
            'c6_client_id' => 'o Client ID',
            'c6_client_secret' => 'o Client Secret',
            'c6_certificado_crt' => 'o certificado (.crt)',
            'c6_certificado_key' => 'a chave privada (.key)',
        );
        foreach ($obrigatorios as $campo => $nome) {
            if (trim((string) ($c[$campo] ?? '')) === '') {
                throw new \RuntimeException('A conta do C6 Bank esta sem ' . $nome . '.');
            }
        }

        return $c;
    }

    /** O .crt colado ao .key, os dois decodificados do base64. */
    private function pem(array $conta): string
    {
        $c = $this->credenciais($conta);
        $partes = array();
        foreach (array('c6_certificado_crt' => 'certificado', 'c6_certificado_key' => 'chave privada') as $campo => $nome) {
            $bin = base64_decode(preg_replace('/\s+/', '', (string) $c[$campo]), true);
            if ($bin === false || $bin === '') {
                throw new \RuntimeException('O ' . $nome . ' do C6 Bank nao esta em base64 valido.');
            }
            $partes[] = rtrim($bin) . "\n";
        }

        return implode('', $partes);
    }

    private function cabecalhosDeParceiro(): array
    {
        return array(
            'User-Agent: PainelShield',
            'partner-software-name: Painel Shield',
            'partner-software-version: ' . (defined('SHIELD_VERSAO') ? SHIELD_VERSAO : 'dev'),
        );
    }

    private function token(array $conta): string
    {
        static $cache = array();
        $chave = (string) ($conta['id'] ?? '0') . '|' . (string) ($conta['ambiente'] ?? '');
        if (isset($cache[$chave]) && $cache[$chave]['ate'] > time()) {
            return $cache[$chave]['token'];
        }

        $c = $this->credenciais($conta);
        $r = Http::json('POST', $this->base($conta) . '/v1/auth/',
            array_merge(array('Content-Type: application/x-www-form-urlencoded', 'Accept: application/json'),
                        $this->cabecalhosDeParceiro()),
            array(
                'client_id' => (string) $c['c6_client_id'],
                'client_secret' => (string) $c['c6_client_secret'],
                'grant_type' => 'client_credentials',
            ),
            $this->pem($conta)
        );

        if ($r['erro'] !== '') {
            throw new \RuntimeException($r['erro']);
        }
        if ($r['codigo'] >= 400) {
            throw new \RuntimeException('O C6 Bank recusou as credenciais (HTTP ' . $r['codigo'] . '). '
                . 'Confira o Client ID, o Client Secret e se o certificado e do MESMO ambiente.');
        }
        $token = trim((string) ($r['json']['access_token'] ?? ''));
        if ($token === '') {
            throw new \RuntimeException('O C6 Bank respondeu sem token de acesso.');
        }

        // O token do C6 e curto (documentado em minutos): dez segundos de folga.
        $ttl = max(30, (int) ($r['json']['expires_in'] ?? 300)) - 10;
        $cache[$chave] = array('token' => $token, 'ate' => time() + $ttl);

        return $token;
    }

    private function chamar(array $conta, string $metodo, string $rota, ?array $carga = null): array
    {
        $r = Http::json($metodo, $this->base($conta) . '/' . ltrim($rota, '/'),
            array_merge(array('Authorization: Bearer ' . $this->token($conta), 'Accept: application/json'),
                        $this->cabecalhosDeParceiro()),
            $carga,
            $this->pem($conta)
        );

        if ($r['erro'] !== '') {
            throw new \RuntimeException($r['erro']);
        }
        if ($r['codigo'] >= 400) {
            $j = (array) ($r['json'] ?? array());
            $texto = '';
            foreach (array('detail', 'message', 'title', 'error_description', 'error') as $campo) {
                if (isset($j[$campo]) && is_scalar($j[$campo]) && trim((string) $j[$campo]) !== '') {
                    $texto = trim((string) $j[$campo]);
                    break;
                }
            }
            if ($r['codigo'] === 401) {
                throw new \RuntimeException('O C6 Bank recusou a credencial desta conta (HTTP 401). '
                    . 'Confira as credenciais e o certificado em Formas de recebimento.');
            }
            if ($r['codigo'] === 403) {
                // Autenticou e nao pode: e o servico de cobranca desligado na
                // conta -- foi exatamente onde o membro parou.
                throw new \RuntimeException('O C6 Bank autenticou mas negou o acesso (HTTP 403)'
                    . ($texto !== '' ? ': ' . $texto : '.')
                    . ' Confira se o BolePix esta habilitado para estas credenciais no ambiente escolhido.');
            }
            throw new \RuntimeException('C6 Bank recusou (HTTP ' . $r['codigo'] . ')' . ($texto !== '' ? ': ' . $texto : '.'));
        }

        return $r;
    }

    // ---------------------------------------------------------------
    // Emissao
    // ---------------------------------------------------------------

    public function criar(array $cobranca, array $conta, array $cliente): Resultado
    {
        $metodo = strtolower((string) ($cobranca['forma'] ?? 'boleto'));
        if (!in_array($metodo, array('pix', 'boleto'), true)) {
            throw new \RuntimeException('O C6 Bank so emite BolePix (boleto com PIX); pedido veio como "' . $metodo . '".');
        }

        $c = $this->credenciais($conta);
        $chave = trim((string) ($c['c6_chave_pix'] ?? ''));
        if ($chave === '') {
            throw new \RuntimeException('A conta do C6 Bank esta sem a chave PIX aleatoria (EVP) que recebe.');
        }

        $documento = preg_replace('/\D+/', '', (string) ($cliente['cnpj'] ?? ''));
        if (!in_array(strlen($documento), array(11, 14), true)) {
            throw new \RuntimeException('O cliente esta sem CPF/CNPJ valido, e o BolePix exige o documento do pagador.');
        }
        $endereco = Endereco::de($cliente);
        if (strlen($endereco['cep']) !== 8) {
            throw new \RuntimeException('O cliente esta sem CEP valido, e o BolePix exige o endereco do pagador.');
        }

        // Ate 26 caracteres, so do que a doc chama de external_reference_id.
        $referencia = substr('SH' . str_pad((string) ((int) ($cobranca['id'] ?? 0)), 24, '0', STR_PAD_LEFT), -26);
        // VENCIMENTO QUE JA PASSOU SOBE PARA O PISO DA CASA (17/09/2026): o BolePix
        // nasce com a data impressa, e vencido o banco recusa registrar -- vencida e
        // justamente a cobranca que a regua reemite. Data de hoje em diante fica.
        $vencimento = substr(trim((string) ($cobranca['vencimento'] ?? '')), 0, 10);
        if (!preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/', $vencimento) || $vencimento < date('Y-m-d')) {
            $vencimento = Prazo::fim('')->format('Y-m-d');
        }
        $carga = array(
            'external_reference_id' => $referencia,
            'amount' => round((int) $cobranca['valor_centavos'] / 100, 2),
            'due_date' => $vencimento,
            'description' => mb_substr((string) ($cobranca['descricao'] ?? 'Licenca de uso'), 0, 100),
            'payer' => array(
                'name' => mb_substr((string) ($cliente['razao'] ?? 'Cliente'), 0, 40),
                'tax_id' => $documento,
                'address' => array(
                    'address' => mb_substr($endereco['rua'] . ', ' . $endereco['numero'], 0, 40),
                    'neighborhood' => mb_substr($endereco['bairro'], 0, 40),
                    'city' => mb_substr($endereco['cidade'], 0, 40),
                    'state' => $endereco['uf'],
                    'zip_code' => $endereco['cep'],
                ),
            ),
            'payment_method' => array(
                // O codigo da carteira difere entre producao e sandbox, pela doc.
                'bank_slip' => array('billing_scheme' => ((string) ($conta['ambiente'] ?? 'producao')) === 'producao' ? '15' : '21'),
                'pix' => array('type' => 'EVP', 'key' => $chave),
            ),
            'origin' => 'Shield',
        );

        $r = $this->chamar($conta, 'POST', '/v2/bank_slips', $carga);
        $j = (array) ($r['json'] ?? array());
        $id = (string) ($j['external_reference_id'] ?? $referencia);

        // COBRANCA PIX SEM O QR -- 17/09/2026. Com a chave invalida o C6 cria o
        // BolePix SEM os dados de PIX (doc da API Bolepix). A linha digitavel iria
        // para onde o ERP desenha o QR do PIX, e o cliente nao conseguiria pagar
        // lendo: cancela e explica, como a Cora faz.
        if ($metodo === 'pix' && trim((string) ($j['payment_method']['pix']['qr_code'] ?? '')) === '') {
            $desfecho = $this->cancelar($id, $conta)
                ? 'O boleto foi cancelado; confira a chave e emita de novo.'
                : 'Cancele o boleto ' . $id . ' no C6, confira a chave e emita de novo.';
            throw new \RuntimeException('O C6 Bank criou a cobranca sem o QR do PIX: confira a chave PIX aleatoria (EVP)'
                . ' da conta. ' . $desfecho);
        }

        return $this->resultado($j, $id, (string) $r['corpo'], $metodo);
    }

    /**
     * @param array{centavos:int,quando:string}|null $pagamentos o que a listagem disse
     */
    private function resultado(array $j, string $idExterno, string $bruto, string $metodo = 'boleto', ?array $pagamentos = null): Resultado
    {
        $situacaoProvedor = strtoupper(trim((string) ($j['status'] ?? 'CREATED')));
        $situacao = self::traduzir($situacaoProvedor);
        $pm = (array) ($j['payment_method'] ?? array());
        $pixBloco = (array) ($pm['pix'] ?? array());
        $boletoBloco = (array) ($pm['bank_slip'] ?? array());
        $pix = (string) ($pixBloco['qr_code'] ?? '');
        // So os digitos: os exemplos do C6 trazem a linha com pontos e espacos, e
        // a do Inter e a da Cora chegam com os 47 digitos puros.
        $linha = CodigoDePagamento::linha((string) ($boletoBloco['digitable_line'] ?? ''));

        // O VALOR PAGO E A DATA VEM DA LISTAGEM (17/09/2026): a consulta por id nao
        // tem `paid_amount` nem `paid_at` -- o adaptador lia campos que o spec do
        // BolePix nao descreve, e todo pagamento entrava pelo valor nominal e sem
        // data. Sem a listagem (fora do ar), fica o nominal, que e o que se sabe.
        $pago = null;
        $quando = '';
        if ($situacao === Resultado::PAGA) {
            if ($pagamentos !== null) {
                $pago = $pagamentos['centavos'];
                $quando = $pagamentos['quando'];
            } else {
                $valor = (float) ($j['amount'] ?? 0);
                $pago = $valor > 0 ? (int) round($valor * 100) : null;
            }
        }

        return new Resultado(
            situacao: $situacao,
            idExterno: $idExterno,
            situacaoProvedor: $situacaoProvedor,
            copiaECola: $pix !== '' ? $pix : $linha,
            valorPagoCentavos: $pago,
            pagoEm: $situacao === Resultado::PAGA && $quando !== '' && strtotime($quando) !== false
                ? date('Y-m-d H:i:s', strtotime($quando)) : null,
            metodo: $metodo,
            bruto: $bruto,
            // A cobranca PIX paga pelo QR do BolePix: o boleto que vem junto nao
            // e o que o cliente pediu, e nao vai para a tela.
            linhaDigitavel: $metodo === 'boleto' ? $linha : ''
        );
    }

    public function consultar(string $idExterno, array $conta): Resultado
    {
        // O sentinela do teste de conexao segue a rota de sempre: um 404 e
        // "conectou", um 403 e o BolePix desligado -- as duas respostas dizem
        // ao membro o que fazer.
        $r = $this->chamar($conta, 'GET', '/v2/bank_slips/' . rawurlencode($idExterno));
        $j = (array) ($r['json'] ?? array());
        if ($idExterno === self::SENTINELA) {
            return new Resultado(situacao: Resultado::INDEFINIDA, idExterno: $idExterno, bruto: (string) $r['corpo']);
        }

        $id = (string) ($j['external_reference_id'] ?? $idExterno);
        $pagamentos = self::traduzir((string) ($j['status'] ?? '')) === Resultado::PAGA
            ? $this->pagamentos($conta, $id, (string) ($j['due_date'] ?? ''))
            : null;

        return $this->resultado($j, $id, (string) $r['corpo'], 'boleto', $pagamentos);
    }

    /**
     * O que entrou e quando, da listagem -- 17/09/2026. So ela tem `payments[]`, e
     * exige um intervalo de datas (no maximo 60 dias): o vencimento da propria
     * cobranca serve de janela. Listagem fora do ar devolve null, e a consulta segue
     * com o valor nominal: perder a baixa por causa dela seria pior.
     *
     * @return array{centavos:int,quando:string}|null
     */
    private function pagamentos(array $conta, string $idExterno, string $vencimento): ?array
    {
        $venc = substr(trim($vencimento), 0, 10);
        $filtro = array('external_reference_id' => $idExterno);
        if (preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/', $venc)) {
            $filtro['due_date_from'] = $venc;
            $filtro['due_date_to'] = $venc;
        } else {
            $filtro['payment_date_from'] = date('Y-m-d', strtotime('-59 days'));
            $filtro['payment_date_to'] = date('Y-m-d');
        }

        try {
            $r = $this->chamar($conta, 'GET', '/v2/bank_slips/list?' . http_build_query($filtro));
        } catch (\RuntimeException $listagemFora) {
            return null;
        }

        $centavos = 0;
        $quando = '';
        foreach ((array) ($r['json']['content'] ?? array()) as $item) {
            if (!is_array($item) || (string) ($item['external_reference_id'] ?? '') !== $idExterno) {
                continue;
            }
            foreach ((array) ($item['payments'] ?? array()) as $pagamento) {
                if (!is_array($pagamento) || !is_numeric($pagamento['amount'] ?? null)) {
                    continue;
                }
                $centavos += (int) round(((float) $pagamento['amount']) * 100);
                $data = substr((string) ($pagamento['payment_date'] ?? ''), 0, 10);
                if ($data > $quando) {
                    $quando = $data;
                }
            }
        }

        return $centavos > 0 ? array('centavos' => $centavos, 'quando' => $quando) : null;
    }

    public function cancelar(string $idExterno, array $conta): bool
    {
        try {
            $this->chamar($conta, 'PUT', '/v2/bank_slips/' . rawurlencode($idExterno) . '/cancel');

            return true;
        } catch (\RuntimeException $e) {
            return false;
        }
    }

    /**
     * O formato do aviso do C6 NAO foi visto por ninguem. Aceita um corpo com
     * `external_reference_id` (ou `id`) e deixa o consultar() dizer o resto;
     * confere so pelo token da URL, porque nao ha assinatura documentada.
     */
    public function lerWebhook(string $corpo, array $cabecalhos, array $conta): ?EventoWebhook
    {
        $j = json_decode($corpo, true);
        if (!is_array($j)) {
            return null;
        }
        $dados = isset($j['external_reference_id']) || isset($j['id']) ? $j : (array) ($j['data'] ?? array());
        $id = trim((string) ($dados['external_reference_id'] ?? ($dados['id'] ?? '')));
        if ($id === '') {
            return null;
        }

        return new EventoWebhook(
            id: 'c6bank-' . $id . '-' . (string) ($dados['status'] ?? ($j['event'] ?? '')),
            tipo: (string) ($j['event'] ?? 'bank_slip'),
            idExterno: $id,
            assinaturaConfere: TokenWebhook::confere($cabecalhos, $conta),
            corpo: $corpo
        );
    }

    /** Conservadora: o que nao esta na lista de pago NAO e pago. */
    public static function traduzir(string $status): string
    {
        switch (strtoupper(trim($status))) {
            case 'PAID':
            case 'SETTLED':
            // WAITING_CONFIRMATION e "o pagamento foi confirmado, mas os recursos
            // ainda nao foram creditados" (spec do BolePix). Ficava INDEFINIDA, e a
            // licenca esperava o credito -- um ou dois dias depois de o cliente
            // pagar. E o CONFIRMED do Asaas, que esta casa ja conta como pago.
            case 'WAITING_CONFIRMATION':
                return Resultado::PAGA;
            case 'CREATED':
            case 'REGISTERED':
            case 'PENDING':
            case 'ISSUED':
            case 'PROCESSING':
                return Resultado::ABERTA;
            case 'EXPIRED':
            case 'OVERDUE':
                return Resultado::VENCIDA;
            case 'CANCELED':
            case 'CANCELLED':
                return Resultado::CANCELADA;
            default:
                return Resultado::INDEFINIDA;
        }
    }
}
