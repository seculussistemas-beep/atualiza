<?php

namespace Shield\Cobranca\Provedores;

use Shield\Cobranca\Brcode;
use Shield\Cobranca\EventoWebhook;
use Shield\Cobranca\Provedor;
use Shield\Cobranca\Resultado;

/**
 * PIX na chave do membro, confirmado a mao - 25/08/2026.
 *
 * O membro cadastra a chave dele; o painel monta o copia-e-cola com o valor da
 * cobranca. O cliente paga, o membro ve no extrato do banco e confirma na tela.
 * NAO HA RETORNO AUTOMATICO -- e o preco de nao ter conta de gateway, e e o
 * caminho da maioria dos membros, nao a excecao.
 *
 * ELE ENTRA COMO PROVEDOR DE VERDADE, atras da mesma interface dos gateways.
 * Assim a tela, a regua e o historico tratam os tres iguais; a alternativa
 * seria um caminho paralelo de "cobranca manual" com regras proprias, e regra
 * que existe em dois lugares diverge.
 *
 * O consultar() devolve SEMPRE a situacao que esta no banco -- ele nao tem a
 * quem perguntar. Quem move essa cobranca e a confirmacao manual, que e
 * auditada e tem permissao propria justamente porque estende validade sem
 * prova externa nenhuma.
 */
final class PixEstatico implements Provedor
{
    public function nome(): string
    {
        return 'pix_estatico';
    }

    public function capacidades(array $conta): array
    {
        return array(
            'pix' => true,
            'boleto' => false,
            'cartao' => false,
            'assinatura' => false,
            'automatico' => false,
        );
    }

    public function criar(array $cobranca, array $conta, array $cliente): Resultado
    {
        $credenciais = (array) ($conta['_credenciais'] ?? array());
        $chave = trim((string) ($credenciais['chave_pix'] ?? ''));
        if ($chave === '') {
            // "Tela de contas" era o nome de antes: desde 10/09/2026 ela se chama Formas
            // de recebimento, e a frase so ajuda se o membro achar onde ir. O motor
            // pergunta antes (shield_conta_pronta_recusa); esta fica para quem chama o
            // adaptador direto.
            throw new \RuntimeException(
                'A conta de PIX na sua chave esta sem a chave PIX. Cadastre a chave em Formas de recebimento.'
            );
        }

        $codigo = Brcode::montar(
            $chave,
            (string) ($credenciais['nome_recebedor'] ?? ($conta['apelido'] ?? 'RECEBEDOR')),
            (string) ($credenciais['cidade'] ?? 'BRASIL'),
            (int) $cobranca['valor_centavos'],
            'SH' . (int) ($cobranca['id'] ?? 0)
        );

        // O id externo e nosso mesmo: nao ha ninguem do outro lado para dar um.
        return new Resultado(
            situacao: Resultado::ABERTA,
            idExterno: 'SH' . (int) ($cobranca['id'] ?? 0),
            situacaoProvedor: 'aguardando confirmacao manual',
            copiaECola: $codigo,
            metodo: 'pix',
            bruto: json_encode(array('copia_e_cola' => $codigo), JSON_UNESCAPED_SLASHES)
        );
    }

    public function consultar(string $idExterno, array $conta): Resultado
    {
        // Nao ha a quem perguntar. Devolver "paga" aqui seria mentir; devolver
        // "aberta" e a verdade -- o painel so sabe pela mao do membro.
        return new Resultado(
            situacao: Resultado::ABERTA,
            idExterno: $idExterno,
            situacaoProvedor: 'aguardando confirmacao manual',
            metodo: 'pix'
        );
    }

    public function cancelar(string $idExterno, array $conta): bool
    {
        // Nada foi emitido em lugar nenhum; cancelar e so nao cobrar mais.
        return true;
    }

    public function lerWebhook(string $corpo, array $cabecalhos, array $conta): ?EventoWebhook
    {
        return null;
    }
}
