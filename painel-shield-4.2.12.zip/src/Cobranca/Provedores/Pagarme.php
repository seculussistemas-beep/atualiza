<?php

namespace Shield\Cobranca\Provedores;

use Shield\Cobranca\CodigoDePagamento;
use Shield\Cobranca\Endereco;
use Shield\Cobranca\EventoWebhook;
use Shield\Cobranca\Http;
use Shield\Cobranca\Prazo;
use Shield\Cobranca\Provedor;
use Shield\Cobranca\Resultado;
use Shield\Cobranca\Telefone;

/**
 * Pagar.me (Stone) - 25/08/2026.
 *
 * API v5, autenticada por Basic com a secret key no usuario e senha vazia --
 * e nao por Bearer, que e o que se supoe olhando os outros gateways.
 *
 * AQUI TUDO E "ORDER" COM UM "CHARGE" DENTRO. A cobranca que este painel
 * conhece vira uma order de um item so, e o que se guarda e o id do CHARGE:
 * e ele que tem situacao, valor pago e estorno. Guardar o id da order
 * obrigaria a navegar por dentro dela a cada consulta.
 *
 * OS VALORES SAO EM CENTAVOS dos dois lados, entao nao ha conversao -- e e
 * justamente onde o adaptador do Mercado Pago precisa dividir por cem. Nao
 * uniformizar isso e o tipo de descuido que gera cobranca de R$ 14.900.
 */
final class Pagarme implements Provedor
{
    private const BASE = 'https://api.pagar.me/core/v5';

    /** As chaves publicas que assinam o aviso, escolhidas pelo `kid`. */
    public const JWKS = 'https://hubapi.pagar.me/.well-known/jwks.json';

    /** kid => PEM, por processo: o aviso seguinte nao busca de novo. */
    private static $chavesDoAviso = array();

    public function nome(): string
    {
        return 'pagarme';
    }

    public function capacidades(array $conta): array
    {
        return array(
            'pix' => true,
            // BOLETO E CARTAO DESDE 10/09/2026 (tarde). Boleto e a order com
            // payment_method boleto; cartao e a order com payment_method
            // "checkout", que devolve um LINK hospedado so de cartao.
            'boleto' => true,
            'cartao' => true,
            // Recorrencia no Pagar.me e a API de subscriptions, com cartao
            // tokenizado. Declarar false e honesto: quem quer recorrencia usa
            // o modo em que o PAINEL gera a cobranca de cada ciclo.
            'assinatura' => false,
            'automatico' => true,
        );
    }

    private function cabecalhos(array $conta): array
    {
        $c = (array) ($conta['_credenciais'] ?? array());
        $chave = trim((string) ($c['pagarme_secret_key'] ?? ''));
        if ($chave === '') {
            throw new \RuntimeException('A conta do Pagar.me esta sem a Secret Key.');
        }

        return array(
            // Basic com a chave no usuario e senha VAZIA -- o dois-pontos no
            // fim nao e engano, e o que a documentacao pede.
            'Authorization: Basic ' . base64_encode($chave . ':'),
            'Accept: application/json',
            'User-Agent: PainelShield',
        );
    }

    private function chamar(array $conta, string $metodo, string $rota, ?array $carga = null): array
    {
        $r = Http::json($metodo, self::BASE . '/' . ltrim($rota, '/'),
                        $this->cabecalhos($conta), $carga);

        if ($r['erro'] !== '') {
            throw new \RuntimeException($r['erro']);
        }
        if ($r['codigo'] >= 400) {
            // O Pagar.me devolve `errors` como mapa campo => [mensagens]. Ler
            // so a `message` da "The request is invalid", que nao diz nada.
            $motivos = array();
            foreach ((array) ($r['json']['errors'] ?? array()) as $campo => $lista) {
                foreach ((array) $lista as $m) {
                    $motivos[] = (is_string($campo) ? $campo . ': ' : '') . (string) $m;
                }
            }
            $texto = $motivos ? implode(' | ', $motivos)
                : trim((string) ($r['json']['message'] ?? ''));

            if ($r['codigo'] === 401 || $r['codigo'] === 403) {
                // Credencial recusada: a mensagem crua do provedor ("authorization
                // value not present") nao diz ao membro o que fazer.
                throw new \RuntimeException('O Pagar.me recusou a credencial desta conta (HTTP ' . $r['codigo']
                    . '). Confira a secret key em Formas de recebimento.');
            }
            throw new \RuntimeException('Pagar.me recusou (HTTP ' . $r['codigo'] . ')'
                . ($texto !== '' ? ': ' . $texto : '.'));
        }

        return $r;
    }

    public function criar(array $cobranca, array $conta, array $cliente): Resultado
    {
        $documento = preg_replace('/[^0-9]/', '', (string) ($cliente['cnpj'] ?? ''));
        // Vencimento no passado ia direto para expires_at e a Pagar.me
        // recusava a order inteira -- e a cobranca vencida e justamente a que
        // se reemite. Ver Shield\Cobranca\Prazo (11/09/2026).
        $expira = Prazo::fim((string) ($cobranca['vencimento'] ?? ''))->format('c');

        $carga = array(
            'items' => array(array(
                'amount' => (int) $cobranca['valor_centavos'],   // JA em centavos
                'description' => (string) ($cobranca['descricao'] ?? 'Licenca de uso'),
                'quantity' => 1,
            )),
            'customer' => array(
                'name' => (string) ($cliente['razao'] ?? 'Cliente'),
                'type' => strlen($documento) === 14 ? 'company' : 'individual',
                'document' => $documento,
                'email' => trim((string) ($cliente['email'] ?? '')) !== ''
                    ? (string) $cliente['email']
                    : 'sem-email+' . $documento . '@painelshield.local',
            ),
            'payments' => array(array(
                'payment_method' => 'pix',
                'pix' => array('expires_at' => $expira),
            )),
            'code' => 'shield-' . (int) $cobranca['id'],
        );

        // O PIX EXIGE O TELEFONE (17/09/2026): a pagina de PIX da v5 manda o
        // `customer` com name, email, document E phones. Sem ele o charge nasce
        // `failed` sem QR, e uma tentativa com id e sem codigo faz a guarda de codigo
        // vivo recusar o Emitir seguinte -- so a reemissao sairia dali.
        $telefone = Telefone::de($cliente);
        if ($telefone !== null) {
            $carga['customer']['phones'] = array(
                ($telefone['celular'] ? 'mobile_phone' : 'home_phone') => array(
                    'country_code' => '55',
                    'area_code' => $telefone['ddd'],
                    'number' => $telefone['numero'],
                ),
            );
        }

        // BOLETO E CARTAO -- 10/09/2026, tarde. A mesma order, com outro
        // payments[0]. Boleto exige o endereco do pagador; cartao vira um
        // checkout hospedado que so aceita cartao.
        $forma = strtolower(trim((string) ($cobranca['forma'] ?? 'pix')));
        if ($forma !== 'boleto' && $forma !== 'cartao' && $telefone === null) {
            throw new \RuntimeException(
                'O Pagar.me exige o telefone do cliente para emitir PIX, e este cadastro esta sem um'
                . ' numero com DDD. Preencha o telefone no Contrato do cliente e emita de novo.'
            );
        }
        if ($forma === 'boleto') {
            $e = Endereco::de($cliente);
            $carga['customer']['address'] = array(
                'line_1' => $e['numero'] . ', ' . $e['rua'] . ', ' . $e['bairro'],
                'zip_code' => $e['cep'], 'city' => $e['cidade'], 'state' => $e['uf'], 'country' => 'BR',
            );
            $carga['payments'] = array(array(
                'payment_method' => 'boleto',
                'boleto' => array('due_at' => $expira, 'instructions' => 'Licenca de uso do sistema. Nao receber apos o vencimento.'),
            ));
        } elseif ($forma === 'cartao') {
            $minutos = max(60, (int) ceil(((new \DateTimeImmutable($expira))->getTimestamp() - time()) / 60));
            $carga['payments'] = array(array(
                'payment_method' => 'checkout',
                'checkout' => array(
                    'expires_in' => $minutos,
                    'accepted_payment_methods' => array('credit_card'),
                    'customer_editable' => false,
                    'billing_address_editable' => false,
                    'skip_checkout_success_page' => true,
                    'credit_card' => array('installments' => array(array('number' => 1, 'total' => (int) $cobranca['valor_centavos']))),
                ),
            ));
        }

        $j = (array) $this->chamar($conta, 'POST', '/orders', $carga)['json'];
        $charge = (array) ($j['charges'][0] ?? array());
        $tx = (array) ($charge['last_transaction'] ?? array());

        if ($forma === 'cartao') {
            // Checkout ainda nao tem charge: o que se guarda e a ORDER, e a
            // consulta le o charge quando ele nascer. Ver consultar().
            return new Resultado(
                situacao: Resultado::ABERTA,
                idExterno: (string) ($j['id'] ?? ''),
                situacaoProvedor: (string) ($j['status'] ?? 'pending'),
                link: (string) ($j['checkouts'][0]['payment_url'] ?? ''),
                metodo: 'cartao',
                bruto: (string) json_encode($j)
            );
        }

        // A linha do boleto so com os digitos: o `line` vem com pontos e espacos.
        $linha = $forma === 'boleto' ? CodigoDePagamento::linha((string) ($tx['line'] ?? '')) : '';

        if ($forma !== 'boleto' && trim((string) ($tx['qr_code'] ?? '')) === '') {
            // Charge que nasceu `failed` nao tem QR e nao se paga. Guardar a tentativa
            // deixaria a cobranca com id externo e sem codigo; o motivo do Pagar.me e
            // o que diz ao membro o que corrigir no cadastro.
            $motivos = array();
            foreach ((array) ($tx['gateway_response']['errors'] ?? array()) as $erro) {
                if (is_array($erro) && trim((string) ($erro['message'] ?? '')) !== '') {
                    $motivos[] = trim((string) $erro['message']);
                }
            }

            throw new \RuntimeException('O Pagar.me criou o pedido ' . (string) ($j['id'] ?? '')
                . ' sem o QR do PIX (situacao ' . ((string) ($charge['status'] ?? '') ?: 'nenhuma') . ')'
                . ($motivos ? ': ' . implode(' | ', $motivos) : '.')
                . ' Nada foi cobrado: confira o cadastro do cliente e emita de novo.');
        }

        return new Resultado(
            situacao: $this->traduzir((string) ($charge['status'] ?? '')),
            // O ID GUARDADO E O DO CHARGE, nao o da order: e ele que tem
            // situacao, valor pago e estorno.
            idExterno: (string) ($charge['id'] ?? ''),
            situacaoProvedor: (string) ($charge['status'] ?? ''),
            link: $forma === 'boleto'
                ? (string) ($tx['pdf'] ?? ($tx['url'] ?? ''))
                : (string) ($tx['qr_code_url'] ?? ($tx['pdf'] ?? '')),
            copiaECola: $forma === 'boleto' ? $linha : (string) ($tx['qr_code'] ?? ''),
            metodo: $forma === 'boleto' ? 'boleto' : 'pix',
            bruto: (string) json_encode($j),
            linhaDigitavel: $linha
        );
    }

    public function consultar(string $idExterno, array $conta): Resultado
    {
        if (strpos($idExterno, 'or_') === 0) {
            // Order de checkout (cartao): o charge nasce quando o cliente paga.
            $o = (array) $this->chamar($conta, 'GET', '/orders/' . rawurlencode($idExterno))['json'];
            $charge = (array) ($o['charges'][0] ?? array());
            if (!$charge) {
                $fechada = in_array(strtolower((string) ($o['status'] ?? '')), array('canceled', 'failed'), true);

                return new Resultado(
                    situacao: $fechada ? Resultado::CANCELADA : Resultado::ABERTA,
                    idExterno: $idExterno,
                    situacaoProvedor: (string) ($o['status'] ?? 'pending'),
                    link: (string) ($o['checkouts'][0]['payment_url'] ?? ''),
                    metodo: 'cartao',
                    bruto: (string) json_encode($o)
                );
            }
            $pago = trim((string) ($charge['paid_at'] ?? ''));

            return new Resultado(
                situacao: $this->traduzir((string) ($charge['status'] ?? '')),
                idExterno: $idExterno,
                situacaoProvedor: (string) ($charge['status'] ?? ''),
                valorPagoCentavos: isset($charge['paid_amount']) ? (int) $charge['paid_amount'] : null,
                pagoEm: $pago !== '' ? date('Y-m-d H:i:s', strtotime($pago)) : null,
                metodo: 'cartao',
                bruto: (string) json_encode($o)
            );
        }

        $j = (array) $this->chamar($conta, 'GET', '/charges/' . rawurlencode($idExterno))['json'];
        $tx = (array) ($j['last_transaction'] ?? array());
        $pago = trim((string) ($j['paid_at'] ?? ''));

        // `paid_amount` e o que entrou de fato; `amount` e o que se pediu.
        // Usar o segundo faria pagamento parcial parecer pagamento cheio.
        $pagoCentavos = isset($j['paid_amount']) ? (int) $j['paid_amount'] : null;
        // NO BOLETO, `qr_code` E A URL DE UMA IMAGEM (17/09/2026): ia para o copia e
        // cola da consulta, que agora preenche o codigo que faltou na emissao.
        $boleto = (string) ($j['payment_method'] ?? '') === 'boleto' || (string) ($tx['transaction_type'] ?? '') === 'boleto';
        $linha = $boleto ? CodigoDePagamento::linha((string) ($tx['line'] ?? '')) : '';

        return new Resultado(
            situacao: $this->traduzir((string) ($j['status'] ?? '')),
            idExterno: (string) ($j['id'] ?? $idExterno),
            situacaoProvedor: (string) ($j['status'] ?? ''),
            link: $boleto
                ? (string) ($tx['pdf'] ?? ($tx['url'] ?? ''))
                : (string) ($tx['qr_code_url'] ?? ($tx['pdf'] ?? '')),
            copiaECola: $boleto ? $linha : (string) ($tx['qr_code'] ?? ''),
            linhaDigitavel: $linha,
            valorPagoCentavos: $pagoCentavos,
            pagoEm: $pago !== '' ? date('Y-m-d H:i:s', strtotime($pago)) : null,
            bruto: (string) json_encode($j)
        );
    }

    public function cancelar(string $idExterno, array $conta): bool
    {
        try {
            if (strpos($idExterno, 'or_') === 0) {
                // Order de checkout: fechar como cancelada mata o link.
                $this->chamar($conta, 'PATCH', '/orders/' . rawurlencode($idExterno) . '/closed', array('status' => 'canceled'));

                return true;
            }
            $this->chamar($conta, 'DELETE', '/charges/' . rawurlencode($idExterno));

            return true;
        } catch (\RuntimeException $e) {
            return false;
        }
    }

    public function lerWebhook(string $corpo, array $cabecalhos, array $conta): ?EventoWebhook
    {
        $j = json_decode($corpo, true);
        if (!is_array($j) || empty($j['type'])) {
            return null;
        }
        $tipo = (string) $j['type'];
        if (strpos($tipo, 'charge.') !== 0 && strpos($tipo, 'order.') !== 0) {
            return null;
        }

        $dados = (array) ($j['data'] ?? array());
        // Em evento de order o charge vem aninhado; em evento de charge o
        // proprio `data` ja e o charge.
        $id = (string) ($dados['id'] ?? '');
        if (strpos($tipo, 'order.') === 0) {
            $id = (string) ($dados['charges'][0]['id'] ?? $id);
        }
        if ($id === '') {
            return null;
        }

        // A CONFERENCIA DO AVISO -- 17/09/2026. A de antes procurava o segredo
        // DENTRO do cabecalho (`strpos`): o Basic chega em base64 e o
        // X-Hub-Signature e da API v3, entao com segredo gravado nenhum aviso de
        // verdade conferia -- e sem segredo, qualquer POST conferia. Vale o que vier:
        // a assinatura do Pagar.me (a dos plugins oficiais) ou o Basic da Dashboard.
        // Sem nenhum dos dois, nada confere.
        $confere = $this->assinaturaConfere($corpo, (string) ($cabecalhos['x-webhook-asymmetric-signature'] ?? ''))
            || self::basicConfere((string) ($cabecalhos['authorization'] ?? ''), (string) ($conta['webhook_segredo'] ?? ''));

        return new EventoWebhook(
            id: (string) ($j['id'] ?? ($tipo . '-' . $id)),
            tipo: $tipo,
            idExterno: $id,
            assinaturaConfere: $confere,
            corpo: $corpo
        );
    }

    /**
     * `X-Webhook-Asymmetric-Signature: alg=RS256; kid=<kid>; signature=<base64url>`:
     * RSA-SHA256 sobre o corpo CRU, com a chave publica do JWKS do Pagar.me que tem
     * aquele `kid` -- como pagarme/ecommerce-module-core (WebhookValidatorService)
     * confere. Nao usa segredo nenhum do membro.
     */
    private function assinaturaConfere(string $corpo, string $cabecalho): bool
    {
        $partes = array();
        foreach (explode(';', $cabecalho) as $pedaco) {
            $par = explode('=', trim($pedaco), 2);
            if (count($par) === 2) {
                $partes[strtolower(trim($par[0]))] = trim($par[1]);
            }
        }
        $kid = (string) ($partes['kid'] ?? '');
        $assinatura = self::base64url((string) ($partes['signature'] ?? ''));
        if (strtoupper((string) ($partes['alg'] ?? '')) !== 'RS256' || $kid === '' || $assinatura === '') {
            return false;
        }

        $pem = $this->chaveDoAviso($kid);

        return $pem !== '' && openssl_verify($corpo, $assinatura, $pem, OPENSSL_ALGO_SHA256) === 1;
    }

    /** A chave publica daquele `kid`; kid que o painel nao conhece busca o JWKS de novo. */
    private function chaveDoAviso(string $kid): string
    {
        if (!isset(self::$chavesDoAviso[$kid])) {
            $r = Http::json('GET', self::JWKS, array('Accept: application/json', 'User-Agent: PainelShield'));
            if ($r['erro'] === '' && $r['codigo'] === 200) {
                foreach ((array) ($r['json']['keys'] ?? array()) as $jwk) {
                    if (is_array($jwk) && strtoupper((string) ($jwk['kty'] ?? '')) === 'RSA' && (string) ($jwk['kid'] ?? '') !== '') {
                        $pem = self::pemDaJwk(self::base64url((string) ($jwk['n'] ?? '')), self::base64url((string) ($jwk['e'] ?? '')));
                        if ($pem !== '') {
                            self::$chavesDoAviso[(string) $jwk['kid']] = $pem;
                        }
                    }
                }
            }
        }

        return (string) (self::$chavesDoAviso[$kid] ?? '');
    }

    /**
     * O Basic da autenticacao do webhook na Dashboard: `webhook_segredo` gravado como
     * "usuario:senha", comparado em tempo constante com o que veio no cabecalho.
     */
    private static function basicConfere(string $autorizacao, string $segredo): bool
    {
        $segredo = trim($segredo);
        $autorizacao = trim($autorizacao);
        if ($segredo === '' || strpos($segredo, ':') === false || stripos($autorizacao, 'basic ') !== 0) {
            return false;
        }
        $enviado = base64_decode(trim(substr($autorizacao, 6)), true);

        return is_string($enviado) && hash_equals($segredo, $enviado);
    }

    private static function base64url(string $texto): string
    {
        $bytes = base64_decode(strtr($texto, '-_', '+/'), true);

        return is_string($bytes) ? $bytes : '';
    }

    /**
     * A chave publica RSA (modulo e expoente do JWK) em PEM, para o openssl_verify.
     * O DER montado a mao: SubjectPublicKeyInfo com rsaEncryption e o RSAPublicKey.
     */
    private static function pemDaJwk(string $modulo, string $expoente): string
    {
        if ($modulo === '' || $expoente === '') {
            return '';
        }
        $inteiro = static function (string $bytes): string {
            if (ord($bytes[0]) > 0x7F) {
                $bytes = chr(0) . $bytes;
            }

            return chr(0x02) . self::tamanhoDer(strlen($bytes)) . $bytes;
        };
        $rsa = $inteiro($modulo) . $inteiro($expoente);
        $rsa = chr(0x30) . self::tamanhoDer(strlen($rsa)) . $rsa;
        $bits = chr(0x03) . self::tamanhoDer(strlen($rsa) + 1) . chr(0) . $rsa;
        $algoritmo = (string) hex2bin('300d06092a864886f70d0101010500');
        $info = chr(0x30) . self::tamanhoDer(strlen($algoritmo . $bits)) . $algoritmo . $bits;

        return "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($info), 64, "\n") . "-----END PUBLIC KEY-----\n";
    }

    private static function tamanhoDer(int $tamanho): string
    {
        if ($tamanho < 0x80) {
            return chr($tamanho);
        }
        $bytes = ltrim(pack('N', $tamanho), chr(0));

        return chr(0x80 | strlen($bytes)) . $bytes;
    }

    /**
     * O vocabulario do Pagar.me para o desta casa. CONSERVADOR: o que nao
     * esta explicitamente na lista de pago nao e pago.
     */
    private function traduzir(string $status): string
    {
        switch (strtolower(trim($status))) {
            case 'paid':
            case 'overpaid':
                return Resultado::PAGA;
            case 'pending':
            case 'processing':
            case 'waiting_payment':
            case 'underpaid':       // pagou menos: continua em aberto, nao paga
                return Resultado::ABERTA;
            case 'canceled':
            case 'failed':
            case 'not_authorized':
                return Resultado::CANCELADA;
            case 'refunded':
            case 'chargedback':
            case 'partial_refunded':
                return Resultado::ESTORNADA;
            default:
                return Resultado::INDEFINIDA;
        }
    }
}
