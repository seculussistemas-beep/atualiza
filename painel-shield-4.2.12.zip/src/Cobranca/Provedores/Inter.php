<?php

namespace Shield\Cobranca\Provedores;

use Shield\Cobranca\CodigoDePagamento;
use Shield\Cobranca\Endereco;
use Shield\Cobranca\EventoWebhook;
use Shield\Cobranca\Http;
use Shield\Cobranca\Prazo;
use Shield\Cobranca\Provedor;
use Shield\Cobranca\Resultado;
use Shield\Cobranca\TokenWebhook;

/**
 * Banco Inter -- PIX (API Pix v2) e boleto (Cobranca v3) - 16/09/2026.
 *
 * Veio de um membro que o roda em producao com dinheiro de verdade: boleto
 * (com PIX dentro) e PIX dinamico. O que esta aqui e a reescrita dele no
 * molde da casa; os endpoints, os campos e as duas armadilhas abaixo sao
 * conhecimento de campo dele.
 *
 * mTLS EM TUDO, INCLUSIVE NO TOKEN. O Inter exige o certificado que o proprio
 * portal emite em toda chamada; sem ele nao ha token. O certificado chega
 * como .p12 em base64 (montado pela tela a partir do .crt e do .key) e vira
 * o PEM que o Http consome.
 *
 * O TOKEN VAI EM FORMULARIO, nao em JSON, e com os escopos no corpo. O cURL
 * proprio que o membro abriu para isso saiu: o Http monta o corpo de
 * formulario quando o adaptador manda o content-type dele.
 *
 * DUAS ARMADILHAS QUE MORDERAM EM PRODUCAO: `seuNumero` do boleto tem NO
 * MAXIMO 15 caracteres (a mais e HTTP 400), e a API responde "Empty reply from
 * server" em HTTP/2 -- o Http forca 1.1 para todos por causa disso.
 *
 * O BOLETO E ASSINCRONO: o POST devolve so o `codigoSolicitacao`, e a linha
 * digitavel e o PIX do boleto aparecem no GET seguinte, as vezes segundos
 * depois. Insiste tres vezes; nao vindo, a cobranca fica ABERTA sem codigo e a
 * consulta seguinte (a conciliacao) traz.
 *
 * O ID EXTERNO DIZ QUAL API: uuid e boleto (codigoSolicitacao); o resto e o
 * txid do PIX, que e NOSSO (26 a 35 alfanumericos, deterministico do id da
 * cobranca -- repetir a criacao atualiza a mesma cobranca no Inter).
 *
 * O WEBHOOK NAO E ASSINADO pelo Inter. Confere so pelo token na URL
 * (TokenWebhook); a situacao continua vindo do consultar().
 */
final class Inter implements Provedor
{
    /** Os escopos do token: a lista que o membro provou em producao. */
    public const ESCOPOS = 'cob.read cob.write webhook.read webhook.write pix.read boleto-cobranca.read boleto-cobranca.write';

    /** O id sentinela do teste de conexao (funcoes/cobranca/cobranca_teste.php). */
    private const SENTINELA = 'shield-teste-inexistente-0';

    /** Espera entre as tentativas de ler o boleto recem-criado. A suite zera. */
    public static int $esperaEntreTentativas = 1;

    public function nome(): string
    {
        return 'inter';
    }

    public function capacidades(array $conta): array
    {
        return array(
            'pix' => true,
            'boleto' => true,
            'cartao' => false,
            'assinatura' => false,
            'automatico' => true,
        );
    }

    private function base(array $conta): string
    {
        // Producao e o UAT (o "sandbox" do Inter), hosts diferentes.
        return ((string) ($conta['ambiente'] ?? 'producao')) === 'producao'
            ? 'https://cdpj.partners.bancointer.com.br'
            // cdpj-SANDBOX (developers.inter.co, 16/09/2026): o pacote do membro
            // apontava para cdpj.partners.uatinter.co, que nao e o sandbox.
            : 'https://cdpj-sandbox.partners.uatinter.co';
    }

    /**
     * O .p12 em base64 vira o PEM do cURL. A senha e a gravada, e vazia como
     * segunda tentativa: o p12 montado pela tela nasce sem senha, e uma senha
     * antiga esquecida na credencial nao pode trancar o certificado novo.
     */
    private function pem(array $conta): string
    {
        $c = (array) ($conta['_credenciais'] ?? array());
        $b64 = trim((string) ($c['inter_certificado'] ?? ''));
        if ($b64 === '') {
            throw new \RuntimeException(
                'A conta do Inter esta sem o certificado. O Inter exige o certificado em toda chamada, inclusive no token.'
            );
        }
        $p12 = base64_decode(preg_replace('/\s+/', '', $b64), true);
        if ($p12 === false || $p12 === '') {
            throw new \RuntimeException('O certificado do Inter nao esta em base64 valido.');
        }

        $senha = (string) ($c['inter_certificado_senha'] ?? '');
        foreach (array_unique(array($senha, '')) as $tentativa) {
            $partes = array();
            if (openssl_pkcs12_read($p12, $partes, $tentativa)) {
                return (string) ($partes['cert'] ?? '') . (string) ($partes['pkey'] ?? '');
            }
        }

        throw new \RuntimeException(
            'Nao consegui abrir o certificado do Inter. Mande o .crt e o .key de novo em Formas de recebimento, ou confira a senha.'
        );
    }

    private function token(array $conta): string
    {
        static $cache = array();
        $chave = (string) ($conta['id'] ?? '0') . '|' . (string) ($conta['ambiente'] ?? '');
        if (isset($cache[$chave]) && $cache[$chave]['ate'] > time()) {
            return $cache[$chave]['token'];
        }

        $c = (array) ($conta['_credenciais'] ?? array());
        $id = trim((string) ($c['inter_client_id'] ?? ''));
        $segredo = trim((string) ($c['inter_client_secret'] ?? ''));
        // O certificado antes das credenciais: e a falta mais comum e a mais
        // cara, e sem ele nem o token sai.
        $pem = $this->pem($conta);
        if ($id === '' || $segredo === '') {
            throw new \RuntimeException('A conta do Inter esta sem o Client ID ou o Client Secret.');
        }

        $r = Http::json('POST', $this->base($conta) . '/oauth/v2/token',
            array(
                'Content-Type: application/x-www-form-urlencoded',
                'Accept: application/json',
                'User-Agent: PainelShield',
            ),
            array(
                'client_id' => $id,
                'client_secret' => $segredo,
                'grant_type' => 'client_credentials',
                'scope' => self::ESCOPOS,
            ),
            $pem
        );

        if ($r['erro'] !== '') {
            throw new \RuntimeException($r['erro']);
        }
        if ($r['codigo'] >= 400) {
            throw new \RuntimeException('O Inter recusou as credenciais (HTTP ' . $r['codigo'] . '). '
                . 'Confira o Client ID, o Client Secret, os escopos da aplicacao e se o certificado e do MESMO ambiente.');
        }

        $token = trim((string) ($r['json']['access_token'] ?? ''));
        if ($token === '') {
            throw new \RuntimeException('O Inter respondeu sem token de acesso.');
        }

        // Um minuto de folga: token que vence entre a autenticacao e o uso
        // produz um 401 que ninguem consegue explicar.
        $ttl = max(120, (int) ($r['json']['expires_in'] ?? 3600)) - 60;
        $cache[$chave] = array('token' => $token, 'ate' => time() + $ttl);

        return $token;
    }

    /** A chamada crua, sem levantar: o teste de conexao precisa ler o codigo. */
    private function pedir(array $conta, string $metodo, string $rota, ?array $carga = null): array
    {
        $r = Http::json($metodo, $this->base($conta) . '/' . ltrim($rota, '/'),
            array(
                'Authorization: Bearer ' . $this->token($conta),
                'Accept: application/json',
                'User-Agent: PainelShield',
            ),
            $carga,
            $this->pem($conta)
        );

        if ($r['erro'] !== '') {
            throw new \RuntimeException($r['erro']);
        }

        return $r;
    }

    private function chamar(array $conta, string $metodo, string $rota, ?array $carga = null): array
    {
        $r = $this->pedir($conta, $metodo, $rota, $carga);
        if ($r['codigo'] >= 400) {
            throw new \RuntimeException($this->motivo($r));
        }

        return $r;
    }

    private function motivo(array $r): string
    {
        $j = (array) ($r['json'] ?? array());
        // O Inter segue o padrao do BC no PIX (`violacoes[].razao`) e manda
        // `title`/`detail` no boleto.
        $motivos = array();
        foreach ((array) ($j['violacoes'] ?? array()) as $v) {
            if (!empty($v['razao'])) {
                // O campo recusado vai junto (15/10/2026): e por ele que o boleto
                // sabe que foi a multa, e o membro sabe o que corrigir.
                $campo = trim((string) ($v['propriedade'] ?? ''));
                $motivos[] = ($campo !== '' ? $campo . ': ' : '') . (string) $v['razao'];
            }
        }
        $texto = $motivos ? implode(' | ', $motivos)
            : trim((string) ($j['detail'] ?? ($j['title'] ?? ($j['message'] ?? ''))));

        if ($r['codigo'] === 401 || $r['codigo'] === 403) {
            return 'O Inter recusou a credencial desta conta (HTTP ' . $r['codigo'] . '). '
                . 'Confira as credenciais, os escopos da aplicacao e o certificado em Formas de recebimento.';
        }

        return 'Inter recusou (HTTP ' . $r['codigo'] . ')' . ($texto !== '' ? ': ' . $texto : '.');
    }

    private function txid(array $cobranca): string
    {
        return 'shield' . str_pad((string) ((int) $cobranca['id']), 20, '0', STR_PAD_LEFT);
    }

    private function ehBoleto(string $idExterno): bool
    {
        return (bool) preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-/i', $idExterno);
    }

    // ---------------------------------------------------------------
    // Emissao
    // ---------------------------------------------------------------

    public function criar(array $cobranca, array $conta, array $cliente): Resultado
    {
        $metodo = strtolower((string) ($cobranca['forma'] ?? 'pix'));
        if (!in_array($metodo, array('pix', 'boleto'), true)) {
            throw new \RuntimeException('O Inter so emite PIX e boleto; pedido veio como "' . $metodo . '".');
        }

        return $metodo === 'pix'
            ? $this->criarPix($cobranca, $conta, $cliente)
            : $this->criarBoleto($cobranca, $conta, $cliente);
    }

    /**
     * O PDF DO BOLETO (19/10/2026, pedido de membro: "tem que ir no banco para
     * imprimir"). O Inter nao da endereco publico do boleto: o PDF vem em base64
     * de uma chamada com o certificado e o token da conta, e por isso o painel o
     * busca e entrega por uma rota propria, em vez de por um link. So o boleto tem:
     * o id externo dele e o codigoSolicitacao (UUID); o do PIX e o txid.
     */
    public function pdfBoleto(string $idExterno, array $conta): string
    {
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $idExterno)) {
            throw new \RuntimeException('Esta cobranca do Inter e PIX, e nao tem boleto para imprimir.');
        }
        $r = $this->chamar($conta, 'GET', '/cobranca/v3/cobrancas/' . rawurlencode($idExterno) . '/pdf');
        $pdf = base64_decode((string) (((array) ($r['json'] ?? array()))['pdf'] ?? ''), true);
        if (!is_string($pdf) || strncmp($pdf, '%PDF', 4) !== 0) {
            throw new \RuntimeException('O Inter respondeu sem o PDF do boleto. Se ele acabou de ser emitido, tente de novo em alguns segundos.');
        }

        return $pdf;
    }

    /** O padrao quando o membro nao escolheu: um mes para pagar atrasado. */
    public const DIAS_APOS_VENCIMENTO_PADRAO = 30;
    /** O teto do Inter para o numDiasAgenda. */
    public const DIAS_APOS_VENCIMENTO_MAX = 60;

    /**
     * Quantos dias o codigo aceita pagamento depois do vencimento (15/10/2026).
     * Vazio e o padrao; 0 e escolha (expira no vencimento, como era); acima do
     * teto do Inter, o teto.
     */
    public static function diasAposVencimento(array $conta): int
    {
        $c = (array) ($conta['_credenciais'] ?? array());
        $v = trim((string) ($c['inter_dias_apos_vencimento'] ?? ''));
        if ($v === '' || !preg_match('/^[0-9]+$/', $v)) {
            return self::DIAS_APOS_VENCIMENTO_PADRAO;
        }

        return min(self::DIAS_APOS_VENCIMENTO_MAX, (int) $v);
    }

    /** A expiracao do PIX em segundos: o prazo da casa mais os dias depois do vencimento. */
    public static function expiracaoPix(string $vencimento, array $conta, ?\DateTimeImmutable $agora = null): int
    {
        $agora = $agora ?: new \DateTimeImmutable('now');
        $fim = Prazo::fim($vencimento, $agora)->modify('+' . self::diasAposVencimento($conta) . ' days');

        return max(1, $fim->getTimestamp() - $agora->getTimestamp());
    }

    /**
     * Multa e juros da regua no formato do boleto v3 do Inter (15/10/2026): multa
     * PERCENTUAL (taxa) ou VALORFIXO (valor em reais), mora TAXAMENSAL (taxa ao
     * mes). Sem regra, nada. Ver shield_encargos_para_provedor. So vai quando o
     * boleto aceita pagamento depois do vencimento -- sem isso nao ha atraso a cobrar.
     */
    public static function encargos(?array $regra): array
    {
        if ($regra === null) {
            return array();
        }
        $saida = array();
        if (($regra['multa_centavos'] ?? null) !== null) {
            if ((int) $regra['multa_centavos'] > 0) {
                $saida['multa'] = array('codigo' => 'VALORFIXO', 'valor' => round((int) $regra['multa_centavos'] / 100, 2));
            }
        } elseif ((float) ($regra['multa_percentual'] ?? 0) > 0) {
            $saida['multa'] = array('codigo' => 'PERCENTUAL', 'taxa' => round((float) $regra['multa_percentual'], 4));
        }
        if ((float) ($regra['juros_mes_percentual'] ?? 0) > 0) {
            $saida['mora'] = array('codigo' => 'TAXAMENSAL', 'taxa' => round((float) $regra['juros_mes_percentual'], 4));
        }

        return $saida;
    }

    private function criarPix(array $cobranca, array $conta, array $cliente): Resultado
    {
        $c = (array) ($conta['_credenciais'] ?? array());
        $chave = trim((string) ($c['inter_chave_pix'] ?? ''));
        if ($chave === '') {
            throw new \RuntimeException('A conta do Inter esta sem a chave PIX que recebe.');
        }

        $documento = preg_replace('/\D+/', '', (string) ($cliente['cnpj'] ?? ''));
        $carga = array(
            // O PIX VIVE O MESMO PRAZO DO BOLETO (15/10/2026): ate aqui morria no
            // vencimento, e quem atrasava um dia ficava sem como pagar.
            'calendario' => array('expiracao' => self::expiracaoPix((string) ($cobranca['vencimento'] ?? ''), $conta)),
            'valor' => array('original' => number_format((int) $cobranca['valor_centavos'] / 100, 2, '.', '')),
            'chave' => $chave,
            'solicitacaoPagador' => substr((string) ($cobranca['descricao'] ?? 'Licenca de uso'), 0, 140),
        );
        // Devedor so com documento valido: o BC recusa a cobranca inteira com
        // documento torto, e cobranca sem devedor funciona.
        if (strlen($documento) === 14) {
            $carga['devedor'] = array('cnpj' => $documento, 'nome' => (string) ($cliente['razao'] ?? 'Cliente'));
        } elseif (strlen($documento) === 11) {
            $carga['devedor'] = array('cpf' => $documento, 'nome' => (string) ($cliente['razao'] ?? 'Cliente'));
        }

        $txid = $this->txid($cobranca);
        $r = $this->chamar($conta, 'PUT', '/pix/v2/cob/' . $txid, $carga);
        $j = (array) ($r['json'] ?? array());

        return new Resultado(
            situacao: self::traduzirPix((string) ($j['status'] ?? '')),
            idExterno: (string) ($j['txid'] ?? $txid),
            situacaoProvedor: (string) ($j['status'] ?? ''),
            copiaECola: (string) ($j['pixCopiaECola'] ?? ''),
            metodo: 'pix',
            bruto: (string) $r['corpo']
        );
    }

    private function criarBoleto(array $cobranca, array $conta, array $cliente): Resultado
    {
        $documento = preg_replace('/\D+/', '', (string) ($cliente['cnpj'] ?? ''));
        if (!in_array(strlen($documento), array(11, 14), true)) {
            throw new \RuntimeException('O cliente esta sem CPF/CNPJ valido, e o boleto do Inter exige o documento do pagador.');
        }

        $endereco = Endereco::de($cliente);
        // VENCIMENTO QUE JA PASSOU SOBE PARA O PISO DA CASA (17/09/2026): boleto que
        // nasce vencido o banco recusa registrar, e vencida e justamente a cobranca
        // que a regua reemite -- com o codigo antigo ja cancelado. Vencimento de hoje
        // em diante nao se mexe: e a data impressa no boleto.
        $vencimento = substr(trim((string) ($cobranca['vencimento'] ?? '')), 0, 10);
        if (!preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/', $vencimento) || $vencimento < date('Y-m-d')) {
            $vencimento = Prazo::fim('')->format('Y-m-d');
        }
        $carga = array(
            // ATE 15 CARACTERES, senao HTTP 400 (visto em producao).
            'seuNumero' => substr('shield' . (int) ($cobranca['id'] ?? 0), 0, 15),
            'valorNominal' => (float) number_format((int) $cobranca['valor_centavos'] / 100, 2, '.', ''),
            'dataVencimento' => $vencimento,
            // DIAS QUE O BOLETO AINDA ACEITA PAGAMENTO DEPOIS DO VENCIMENTO
            // (15/10/2026, visto num membro). Era 0, e o Inter da baixa no proprio
            // vencimento: o cliente que atrasava um dia nao conseguia pagar.
            'numDiasAgenda' => self::diasAposVencimento($conta),
            'pagador' => array(
                'cpfCnpj' => $documento,
                'tipoPessoa' => strlen($documento) === 14 ? 'JURIDICA' : 'FISICA',
                'nome' => mb_substr((string) ($cliente['razao'] ?? 'Cliente'), 0, 100),
                'endereco' => mb_substr($endereco['rua'], 0, 90),
                'numero' => mb_substr($endereco['numero'], 0, 10),
                'bairro' => mb_substr($endereco['bairro'], 0, 60),
                'cidade' => mb_substr($endereco['cidade'], 0, 60),
                'uf' => $endereco['uf'],
                'cep' => $endereco['cep'],
            ),
            // Boleto com PIX dentro: o cliente que le o QR paga na hora, sem
            // esperar o registro da CIP.
            'formasRecebimento' => array('BOLETO', 'PIX'),
        );

        $encargos = self::diasAposVencimento($conta) > 0 ? self::encargos($conta['_encargos'] ?? null) : array();
        try {
            $r = $this->chamar($conta, 'POST', '/cobranca/v3/cobrancas', $carga + $encargos);
        } catch (\RuntimeException $e) {
            // RECUSA DA MULTA OU DA MORA NAO DEIXA O CLIENTE SEM BOLETO: sai sem
            // elas, como saia antes desta data. 4xx nao registra nada.
            if ($encargos === array() || !preg_match('/multa|mora|juros/i', $e->getMessage())) {
                throw $e;
            }
            $r = $this->chamar($conta, 'POST', '/cobranca/v3/cobrancas', $carga);
        }
        $j = (array) ($r['json'] ?? array());
        $codigo = trim((string) ($j['codigoSolicitacao'] ?? ''));
        if ($codigo === '') {
            throw new \RuntimeException('O Inter aceitou o boleto e nao devolveu o codigoSolicitacao.');
        }

        // Assincrono: le ate tres vezes esperando a linha digitavel. Falhar
        // aqui NAO derruba a cobranca, que ja existe no Inter.
        $linha = '';
        $pix = '';
        for ($i = 0; $i < 3; $i++) {
            if ($i > 0 && self::$esperaEntreTentativas > 0) {
                sleep(self::$esperaEntreTentativas);
            }
            try {
                $detalhe = (array) ($this->chamar($conta, 'GET', '/cobranca/v3/cobrancas/' . rawurlencode($codigo))['json'] ?? array());
            } catch (\RuntimeException $e) {
                continue;
            }
            $situacao = strtoupper(trim((string) ($detalhe['cobranca']['situacao'] ?? '')));
            if ($situacao !== '' && $situacao !== 'EM_PROCESSAMENTO') {
                $linha = (string) ($detalhe['boleto']['linhaDigitavel'] ?? '');
                $pix = (string) ($detalhe['pix']['pixCopiaECola'] ?? '');
                break;
            }
        }

        return new Resultado(
            situacao: Resultado::ABERTA,
            idExterno: $codigo,
            situacaoProvedor: 'EM_PROCESSAMENTO',
            copiaECola: $pix !== '' ? $pix : CodigoDePagamento::linha($linha),
            metodo: 'boleto',
            bruto: (string) $r['corpo'],
            linhaDigitavel: CodigoDePagamento::linha($linha)
        );
    }

    // ---------------------------------------------------------------
    // Consulta
    // ---------------------------------------------------------------

    public function consultar(string $idExterno, array $conta): Resultado
    {
        if ($idExterno === self::SENTINELA) {
            return $this->testarConexao($conta);
        }

        return $this->ehBoleto($idExterno)
            ? $this->consultarBoleto($idExterno, $conta)
            : $this->consultarPix($idExterno, $conta);
    }

    /**
     * O TESTE DE CONEXAO NAO PODE VIRAR 400 DE FORMATO: o sentinela nao e um
     * txid valido (26-35 alfanumericos) nem um uuid. Bate no boleto com um
     * uuid zerado -- 404 e "conectou" -- e, quando a conta nao tem o escopo de
     * boleto (403), cai num txid de formato valido no PIX.
     */
    private function testarConexao(array $conta): Resultado
    {
        $r = $this->pedir($conta, 'GET', '/cobranca/v3/cobrancas/00000000-0000-0000-0000-000000000000');
        if ($r['codigo'] === 403) {
            $r = $this->pedir($conta, 'GET', '/pix/v2/cob/shield00000000000000000000');
        }
        if ($r['codigo'] >= 400) {
            throw new \RuntimeException($this->motivo($r));
        }

        return new Resultado(situacao: Resultado::INDEFINIDA, idExterno: self::SENTINELA, bruto: (string) $r['corpo']);
    }

    private function consultarPix(string $txid, array $conta): Resultado
    {
        $r = $this->chamar($conta, 'GET', '/pix/v2/cob/' . rawurlencode($txid));
        $j = (array) ($r['json'] ?? array());

        // Os pagamentos vem em pix[], e a cobranca pode ser quitada em mais de
        // um lancamento: soma todos.
        $pagoCentavos = null;
        $pagoEm = null;
        foreach ((array) ($j['pix'] ?? array()) as $p) {
            $pagoCentavos = (int) $pagoCentavos + (int) round(((float) ($p['valor'] ?? 0)) * 100);
            $quando = trim((string) ($p['horario'] ?? ''));
            if ($quando !== '') {
                $pagoEm = date('Y-m-d H:i:s', strtotime($quando));
            }
        }

        return new Resultado(
            situacao: self::traduzirPix((string) ($j['status'] ?? '')),
            idExterno: (string) ($j['txid'] ?? $txid),
            situacaoProvedor: (string) ($j['status'] ?? ''),
            copiaECola: (string) ($j['pixCopiaECola'] ?? ''),
            valorPagoCentavos: $pagoCentavos,
            pagoEm: $pagoEm,
            metodo: 'pix',
            bruto: (string) $r['corpo']
        );
    }

    private function consultarBoleto(string $codigo, array $conta): Resultado
    {
        $r = $this->chamar($conta, 'GET', '/cobranca/v3/cobrancas/' . rawurlencode($codigo));
        $j = (array) ($r['json'] ?? array());
        $cobranca = (array) ($j['cobranca'] ?? array());
        $situacaoProvedor = trim((string) ($cobranca['situacao'] ?? ''));
        $situacao = self::traduzirBoleto($situacaoProvedor);

        $pagoEm = null;
        // A CONSULTA TRAZ `dataSituacao`, SO A DATA -- 17/09/2026. O
        // `dataHoraSituacao` que o adaptador lia existe no CALLBACK (o spec da API de
        // cobranca), e nunca na resposta do GET: o boleto pago descoberto pela
        // conciliacao entrava sem data de pagamento.
        $quando = trim((string) ($cobranca['dataHoraSituacao'] ?? ''));
        if ($quando === '') {
            $quando = trim((string) ($cobranca['dataSituacao'] ?? ''));
        }
        if ($situacao === Resultado::PAGA && $quando !== '') {
            $ts = strtotime($quando);
            $pagoEm = $ts !== false ? date('Y-m-d H:i:s', $ts) : null;
        }

        // `valorTotalRecebido` e o que entrou; `valorNominal` e o que se pediu.
        $recebido = (float) ($cobranca['valorTotalRecebido'] ?? 0);
        $pix = (string) ($j['pix']['pixCopiaECola'] ?? '');
        $linha = (string) ($j['boleto']['linhaDigitavel'] ?? '');

        return new Resultado(
            situacao: $situacao,
            idExterno: $codigo,
            situacaoProvedor: $situacaoProvedor,
            copiaECola: $pix !== '' ? $pix : CodigoDePagamento::linha($linha),
            valorPagoCentavos: $situacao === Resultado::PAGA && $recebido > 0 ? (int) round($recebido * 100) : null,
            pagoEm: $pagoEm,
            metodo: 'boleto',
            bruto: (string) $r['corpo'],
            linhaDigitavel: CodigoDePagamento::linha($linha)
        );
    }

    public function cancelar(string $idExterno, array $conta): bool
    {
        try {
            if ($this->ehBoleto($idExterno)) {
                $this->chamar($conta, 'POST', '/cobranca/v3/cobrancas/' . rawurlencode($idExterno) . '/cancelar',
                              array('motivoCancelamento' => 'APEDIDODOCLIENTE'));
            } else {
                $this->chamar($conta, 'PATCH', '/pix/v2/cob/' . rawurlencode($idExterno),
                              array('status' => 'REMOVIDA_PELO_USUARIO_RECEBEDOR'));
            }

            return true;
        } catch (\RuntimeException $e) {
            return false;
        }
    }

    // ---------------------------------------------------------------
    // Webhook
    // ---------------------------------------------------------------

    /**
     * CADASTRA A URL DO WEBHOOK NO INTER -- 16/09/2026. No Inter isso so se faz
     * pela API (developers.inter.co nao tem tela): PUT /pix/v2/webhook/{chave}
     * (escopo webhook.write) para o PIX e PUT /cobranca/v3/cobrancas/webhook
     * (boleto-cobranca.write) para o boleto, os dois com {"webhookUrl"}. A URL
     * ja vai com o token no fim; o Inter exige https e aceita query string
     * (^https://[^\s]*$). Sem chave PIX gravada so o de boleto e cadastrado.
     * Devolve ['pix' => bool, 'boleto' => bool]; recusa do Inter estoura.
     */
    public function cadastrarWebhook(array $conta, string $url): array
    {
        if (!preg_match('#^https://\S+$#', $url)) {
            throw new \RuntimeException('O Inter so aceita webhook em https://. A URL do painel e ' . $url);
        }
        $c = (array) ($conta['_credenciais'] ?? array());
        $chave = trim((string) ($c['inter_chave_pix'] ?? ''));
        $feito = array('pix' => false, 'boleto' => false);

        if ($chave !== '') {
            $this->chamar($conta, 'PUT', '/pix/v2/webhook/' . rawurlencode($chave), array('webhookUrl' => $url));
            $feito['pix'] = true;
        }
        $this->chamar($conta, 'PUT', '/cobranca/v3/cobrancas/webhook', array('webhookUrl' => $url));
        $feito['boleto'] = true;

        return $feito;
    }

    /**
     * Dois formatos: o do PIX (padrao do BC, `{"pix":[...]}`) e o do boleto v3,
     * que chega como lista de cobrancas ou como uma so, com
     * `codigoSolicitacao` e `situacao`. NAO ASSINADO: confere pelo token da URL.
     */
    public function lerWebhook(string $corpo, array $cabecalhos, array $conta): ?EventoWebhook
    {
        $j = json_decode($corpo, true);
        if (!is_array($j) || $j === array()) {
            return null;
        }
        $confere = TokenWebhook::confere($cabecalhos, $conta);

        // O AVISO DE PIX DO INTER E UMA LISTA SOLTA de lancamentos
        // (`[{"endToEndId","txid","valor","horario"}]`, developers.inter.co,
        // 16/09/2026), e nao o `{"pix":[...]}` do padrao do BC. Os dois entram.
        $lancamentos = null;
        if (!empty($j['pix']) && is_array($j['pix'])) {
            $lancamentos = $j['pix'];
        } elseif (isset($j[0]) && is_array($j[0]) && isset($j[0]['txid']) && !isset($j[0]['codigoSolicitacao'])) {
            $lancamentos = $j;
        }
        if ($lancamentos !== null) {
            $primeiro = (array) ($lancamentos[0] ?? array());
            $txid = trim((string) ($primeiro['txid'] ?? ''));
            if ($txid === '') {
                return null;
            }

            return new EventoWebhook(
                id: 'inter-' . $txid . '-' . (string) ($primeiro['endToEndId'] ?? ''),
                tipo: 'pix',
                idExterno: $txid,
                assinaturaConfere: $confere,
                corpo: $corpo
            );
        }

        $boleto = isset($j['codigoSolicitacao']) ? $j : (array) ($j[0] ?? array());
        $codigo = trim((string) ($boleto['codigoSolicitacao'] ?? ''));
        if ($codigo === '') {
            return null;
        }

        return new EventoWebhook(
            id: 'inter-' . $codigo . '-' . (string) ($boleto['situacao'] ?? '') . '-' . (string) ($boleto['dataHoraSituacao'] ?? ''),
            tipo: 'boleto',
            idExterno: $codigo,
            assinaturaConfere: $confere,
            corpo: $corpo
        );
    }

    // ---------------------------------------------------------------
    // Traducao -- conservadora: o que nao esta na lista NAO e pago
    // ---------------------------------------------------------------

    public static function traduzirPix(string $status): string
    {
        switch (strtoupper(trim($status))) {
            case 'CONCLUIDA':
                return Resultado::PAGA;
            case 'ATIVA':
                return Resultado::ABERTA;
            case 'REMOVIDA_PELO_USUARIO_RECEBEDOR':
            case 'REMOVIDA_PELO_PSP':
                return Resultado::CANCELADA;
            default:
                return Resultado::INDEFINIDA;
        }
    }

    public static function traduzirBoleto(string $status): string
    {
        switch (strtoupper(trim($status))) {
            case 'RECEBIDO':
            case 'MARCADO_RECEBIDO':   // baixa manual no portal do Inter
                return Resultado::PAGA;
            case 'A_RECEBER':
            case 'EM_PROCESSAMENTO':
                return Resultado::ABERTA;
            case 'ATRASADO':
            case 'VENCIDO':
                return Resultado::VENCIDA;
            case 'CANCELADO':
            case 'EXPIRADO':
            case 'FALHA_EMISSAO':
                return Resultado::CANCELADA;
            default:
                return Resultado::INDEFINIDA;
        }
    }
}
