<?php

namespace Shield\Cobranca\Provedores;

use Shield\Cobranca\EventoWebhook;
use Shield\Cobranca\Http;
use Shield\Cobranca\Provedor;
use Shield\Cobranca\Resultado;
use Shield\Cobranca\TokenWebhook;

/**
 * InfinitePay -- link de checkout (PIX e cartao) - 16/09/2026.
 *
 * Nao ha credencial: o link nasce de um POST publico com a InfiniteTag
 * (handle) da conta. Veio de um membro que o usa em producao para GERAR o
 * link; a confirmacao do pagamento e o que faltava, e e o que muda aqui.
 *
 * O QUE O MEMBRO MANDOU DEVOLVIA INDEFINIDA EM TODA CONSULTA. Como quem
 * confirma pagamento neste painel e o consultar() -- o webhook so dispara a
 * pergunta --, o painel NUNCA daria a cobranca por paga. A confirmacao aqui e
 * o `POST /payment_check` da documentacao do checkout
 * (https://www.infinitepay.io/checkout-documentacao), que pede handle,
 * order_nsu, transaction_nsu e slug e responde `paid: true|false`.
 *
 * transaction_nsu E slug SO EXISTEM DEPOIS DO PAGAMENTO, e chegam pelo
 * webhook (e pela redirect_url, que o painel nao usa). Por isso a tentativa
 * nasce com o id = order_nsu (`shield-<id>`, a referencia da casa), o aviso
 * entrega o id completo em EventoWebhook::idParaConsultar
 * (`shield-<id>|<transaction_nsu>|<slug>`), a fila grava esse id na
 * tentativa e a consulta seguinte pergunta de verdade. Sem aviso a consulta
 * continua INDEFINIDA -- honesta: nao ha a quem perguntar.
 *
 * O QUE NAO FOI PROVADO: o payment_check foi escrito pela documentacao, nao
 * contra a API. Nao esta claro se `amount`/`paid_amount` vem em centavos
 * (como o `price` dos itens) ou em reais; aqui vao como centavos quando
 * inteiros. O webhook tambem nao foi visto: os nomes dos campos sao os da
 * documentacao. A InfinitePay nao assina o aviso; confere pelo token da URL.
 */
final class InfinitePay implements Provedor
{
    public const LINKS = 'https://api.checkout.infinitepay.io/links';
    public const PAYMENT_CHECK = 'https://api.checkout.infinitepay.io/payment_check';
    private const SENTINELA = 'shield-teste-inexistente-0';

    public function nome(): string
    {
        return 'infinitepay';
    }

    public function capacidades(array $conta): array
    {
        return array(
            'pix' => true,
            'boleto' => false,
            'cartao' => true,
            'assinatura' => false,
            'automatico' => true,
        );
    }

    private function handle(array $conta): string
    {
        $c = (array) ($conta['_credenciais'] ?? array());
        $handle = ltrim(trim((string) ($c['infinitepay_handle'] ?? '')), '@$');
        if ($handle === '') {
            throw new \RuntimeException('A conta da InfinitePay esta sem a InfiniteTag (o handle da conta).');
        }

        return $handle;
    }

    private function chamar(string $url, array $carga): array
    {
        $r = Http::json('POST', $url, array('Accept: application/json', 'User-Agent: PainelShield'), $carga);
        if ($r['erro'] !== '') {
            throw new \RuntimeException($r['erro']);
        }
        if ($r['codigo'] >= 400) {
            $j = (array) ($r['json'] ?? array());
            $texto = trim((string) ($j['message'] ?? ($j['error'] ?? '')));
            throw new \RuntimeException('InfinitePay recusou (HTTP ' . $r['codigo'] . ')' . ($texto !== '' ? ': ' . $texto : '.'));
        }

        return $r;
    }

    public function criar(array $cobranca, array $conta, array $cliente): Resultado
    {
        $forma = strtolower((string) ($cobranca['forma'] ?? 'pix'));
        if (!in_array($forma, array('pix', 'cartao'), true)) {
            throw new \RuntimeException('A InfinitePay so emite link de PIX e cartao; pedido veio como "' . $forma . '".');
        }
        $handle = $this->handle($conta);
        $orderNsu = 'shield-' . (int) ($cobranca['id'] ?? 0);

        $carga = array(
            'handle' => $handle,
            'order_nsu' => $orderNsu,
            'items' => array(array(
                'quantity' => 1,
                // Em CENTAVOS, pela documentacao (R$ 10,00 = 1000).
                'price' => (int) $cobranca['valor_centavos'],
                'description' => mb_substr((string) ($cobranca['descricao'] ?? 'Licenca de uso'), 0, 140),
            )),
        );
        $nome = trim((string) ($cliente['razao'] ?? ''));
        $email = trim((string) ($cliente['email'] ?? ''));
        if ($nome !== '' || $email !== '') {
            $carga['customer'] = array_filter(array('name' => mb_substr($nome, 0, 100), 'email' => $email));
        }
        // O checkout nao trava a forma: o cliente escolhe PIX ou cartao na
        // pagina. A forma pedida fica registrada no metodo da tentativa.

        // O AVISO E PEDIDO LINK A LINK (17/09/2026): a doc do checkout so preve o
        // `webhook_url` do POST /links, e sem aviso o pagamento nunca e confirmado.
        // O endereco vem do motor, com o token da URL; em http o token viajaria
        // aberto, e o link sai sem aviso como antes.
        $aviso = trim((string) ($conta['_url_webhook'] ?? ''));
        if (strpos($aviso, 'https://') === 0) {
            $carga['webhook_url'] = $aviso;
        }

        $r = $this->chamar(self::LINKS, $carga);
        $j = (array) ($r['json'] ?? array());
        $url = trim((string) ($j['url'] ?? ''));
        if ($url === '') {
            throw new \RuntimeException('A InfinitePay nao devolveu a URL do link de pagamento.');
        }

        return new Resultado(
            situacao: Resultado::ABERTA,
            idExterno: $orderNsu,
            situacaoProvedor: 'created',
            link: $url,
            metodo: $forma,
            bruto: (string) $r['corpo']
        );
    }

    public function consultar(string $idExterno, array $conta): Resultado
    {
        $handle = $this->handle($conta);

        if ($idExterno === self::SENTINELA) {
            // Nao ha credencial a validar: o teste so prova que a API responde.
            $this->chamar(self::PAYMENT_CHECK, array('handle' => $handle, 'order_nsu' => $idExterno,
                                                     'transaction_nsu' => $idExterno, 'slug' => $idExterno));
            throw new \RuntimeException('A InfinitePay respondeu e nao encontrou a cobranca de teste (esperado). '
                . 'A InfiniteTag em si so e conferida no primeiro link emitido.');
        }

        $partes = explode('|', $idExterno, 3);
        if (count($partes) < 3 || trim($partes[1]) === '' || trim($partes[2]) === '') {
            // Antes do aviso nao ha transaction_nsu nem slug: nao ha a quem perguntar.
            return new Resultado(
                situacao: Resultado::INDEFINIDA,
                idExterno: $idExterno,
                situacaoProvedor: 'aguardando_aviso',
                metodo: ''
            );
        }

        $r = $this->chamar(self::PAYMENT_CHECK, array(
            'handle' => $handle,
            'order_nsu' => $partes[0],
            'transaction_nsu' => $partes[1],
            'slug' => $partes[2],
        ));
        $j = (array) ($r['json'] ?? array());

        // SO O BOOLEANO true E PAGO. `success` diz que a consulta deu certo,
        // nao que alguem pagou; "true" em texto nao conta.
        $sucesso = ($j['success'] ?? null) === true;
        $pago = ($j['paid'] ?? null);
        if (!$sucesso || !is_bool($pago)) {
            $situacao = Resultado::INDEFINIDA;
        } else {
            $situacao = $pago ? Resultado::PAGA : Resultado::ABERTA;
        }

        // O QUE ENTRA NA COBRANCA NAO PASSA DO `amount` (17/09/2026). Nos exemplos da
        // doc o `paid_amount` vem MAIOR (1510 para 1500): e o que o comprador pagou,
        // com os juros do parcelamento, que nao sao da loja. Lido como valor pago, a
        // diferenca virava credito do cliente no painel. Pagou menos continua menos.
        $cobrado = self::centavos($j['amount'] ?? null);
        $pagoPeloComprador = self::centavos($j['paid_amount'] ?? null);
        $centavos = $cobrado !== null && $pagoPeloComprador !== null
            ? min($cobrado, $pagoPeloComprador)
            : ($pagoPeloComprador ?? $cobrado);

        return new Resultado(
            situacao: $situacao,
            idExterno: $idExterno,
            situacaoProvedor: $situacao === Resultado::INDEFINIDA ? '' : ($pago ? 'paid' : 'unpaid'),
            valorPagoCentavos: $situacao === Resultado::PAGA ? $centavos : null,
            pagoEm: $situacao === Resultado::PAGA ? date('Y-m-d H:i:s') : null,
            metodo: self::metodoDe((string) ($j['capture_method'] ?? '')),
            bruto: (string) $r['corpo']
        );
    }

    /** Centavos inteiros e positivos, ou null. A InfinitePay fala em centavos. */
    private static function centavos($valor): ?int
    {
        if (is_int($valor)) {
            return $valor > 0 ? $valor : null;
        }

        return is_numeric($valor) && (float) $valor > 0 ? (int) round((float) $valor) : null;
    }

    /** O checkout nao tem cancelamento por API: o link vence sozinho. */
    public function cancelar(string $idExterno, array $conta): bool
    {
        return false;
    }

    public function lerWebhook(string $corpo, array $cabecalhos, array $conta): ?EventoWebhook
    {
        $j = json_decode($corpo, true);
        if (!is_array($j)) {
            return null;
        }
        $orderNsu = trim((string) ($j['order_nsu'] ?? ''));
        if ($orderNsu === '') {
            return null;
        }
        $transacao = trim((string) ($j['transaction_nsu'] ?? ''));
        $slug = trim((string) ($j['invoice_slug'] ?? ($j['slug'] ?? '')));

        return new EventoWebhook(
            id: 'infinitepay-' . $orderNsu . '-' . ($transacao !== '' ? $transacao : md5($corpo)),
            tipo: (string) ($j['capture_method'] ?? 'checkout'),
            idExterno: $orderNsu,
            assinaturaConfere: TokenWebhook::confere($cabecalhos, $conta),
            corpo: $corpo,
            idParaConsultar: $transacao !== '' && $slug !== '' ? $orderNsu . '|' . $transacao . '|' . $slug : ''
        );
    }

    private static function metodoDe(string $captura): string
    {
        $c = strtolower(trim($captura));
        if ($c === 'pix') {
            return 'pix';
        }
        if ($c === 'credit_card' || $c === 'debit_card' || $c === 'card') {
            return 'cartao';
        }

        return '';
    }
}
