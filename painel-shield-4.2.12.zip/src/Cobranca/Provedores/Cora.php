<?php

namespace Shield\Cobranca\Provedores;

use Shield\Cobranca\CodigoDePagamento;
use Shield\Cobranca\Endereco;
use Shield\Cobranca\EventoWebhook;
use Shield\Cobranca\Http;
use Shield\Cobranca\Prazo;
use Shield\Cobranca\Provedor;
use Shield\Cobranca\Resultado;
use Shield\Cobranca\TokenWebhook;

/**
 * Cora -- Integracao Direta. Reescrito em 17/09/2026.
 *
 * O ADAPTADOR DE 04/09 NUNCA CONVERSOU COM A CORA. Foi escrito lendo o codigo
 * velho (funcoes/financeiro/cora.php), e nao a documentacao: falava com o host
 * de PARCEIROS usando um "token de acesso" que a Cora nao entrega a quem integra
 * a propria conta, montava a fatura num formato que a API nao conhece e lia
 * `total_paid` como reais -- ele vem em CENTAVOS, e um pagamento de R$ 150
 * viraria R$ 15.000, com a sobra como credito no saldo do cliente.
 *
 * Esta versao parte do adaptador que um membro escreveu pela documentacao e
 * rodou em producao, conferido linha a linha contra developers.cora.com.br (as
 * paginas .md da referencia v2, lidas em 17/09/2026):
 *
 *   - mTLS em TODA chamada, com o par que a Cora entrega em Conta > Integracoes
 *     via APIs (um por ambiente), no host matls-clients.api[.stage].cora.com.br;
 *   - token: POST /token em formulario, so grant_type=client_credentials e
 *     client_id, sem secret; vale 24 h e nao tem refresh;
 *   - fatura: POST /v2/invoices/ com Idempotency-Key UUID (sem ele, 400), valores
 *     em centavos, ["PIX"] ou ["BANK_SLIP","PIX"]; a linha digitavel e o pix.emv
 *     JA vem na resposta, mesmo com o boleto ainda sem registro;
 *   - aviso: POST SEM CORPO, com tudo nos cabecalhos webhook-event-*, e sem
 *     assinatura, segredo ou IP documentado. O segredo vai na URL (TokenWebhook),
 *     e o aviso so dispara a consulta, como em todo provedor da casa.
 *
 * O que mudou do pacote do membro, e por que:
 *   - o certificado entra por upload (.crt e .key), como no Inter e no C6, e nao
 *     colado numa caixa de texto;
 *   - /endpoints/ COM a barra, como a doc escreve, e 3xx e erro: o Http nao segue
 *     redirecionamento, e um 301 passava por cadastro feito;
 *   - o endereco vai so quando o cadastro o tem inteiro, e com `complement`, que
 *     a doc exige ("N/A", como nos exemplos dela) -- o Endereco::de completa o
 *     que falta com "Centro", "Cidade" e "SP", que serve a quem EXIGE endereco e
 *     aqui registraria boleto com cidade inventada;
 *   - PIX sem QR (conta sem chave PIX, documentado) cancela a fatura e diz o que
 *     fazer, em vez de deixar uma cobranca sem nada para pagar;
 *   - `code` leva o instante da emissao: a doc nao diz se ele e unico, e a
 *     reemissao cria outra fatura para a mesma cobranca;
 *   - uma segunda olhada so, e so quando a resposta vier sem codigo: isto roda
 *     tambem no ciclo do cron, com muitas faturas numa passada.
 */
final class Cora implements Provedor
{
    /** A Cora recusa fatura abaixo disto (R$ 5,00, no boleto e no PIX). */
    public const MINIMO_CENTAVOS = 500;

    /** O complemento que os exemplos da propria Cora mandam quando nao ha. */
    private const SEM_COMPLEMENTO = 'N/A';

    public function nome(): string
    {
        return 'cora';
    }

    public function capacidades(array $conta): array
    {
        return array(
            'pix' => true,
            'boleto' => true,
            // Cartao a Cora nao faz, e recorrencia pela API de faturas tambem nao.
            'cartao' => false,
            'assinatura' => false,
            'automatico' => true,
        );
    }

    // ---------------------------------------------------------------
    // Enderecos e credenciais
    // ---------------------------------------------------------------

    private function base(array $conta): string
    {
        return ((string) ($conta['ambiente'] ?? 'producao')) === 'producao'
            ? 'https://matls-clients.api.cora.com.br'
            : 'https://matls-clients.api.stage.cora.com.br';
    }

    private function credenciais(array $conta): array
    {
        $c = (array) ($conta['_credenciais'] ?? array());
        $obrigatorios = array(
            'cora_client_id' => 'o Client ID',
            'cora_certificado_crt' => 'o certificado',
            'cora_certificado_key' => 'a chave privada',
        );
        foreach ($obrigatorios as $campo => $nome) {
            if (trim((string) ($c[$campo] ?? '')) === '') {
                throw new \RuntimeException('A conta da Cora esta sem ' . $nome . '. Confira em Formas de recebimento.');
            }
        }

        return $c;
    }

    /** O certificado colado a chave, os dois decodificados do base64. */
    private function pem(array $conta): string
    {
        $c = $this->credenciais($conta);
        $partes = array();
        foreach (array('cora_certificado_crt' => 'O certificado', 'cora_certificado_key' => 'A chave privada') as $campo => $nome) {
            $bin = base64_decode((string) preg_replace('/\s+/', '', (string) $c[$campo]), true);
            if ($bin === false || $bin === '') {
                throw new \RuntimeException($nome . ' da Cora nao esta legivel. Mande os dois arquivos de novo em Formas de recebimento.');
            }
            $partes[] = rtrim($bin) . "\n";
        }

        return implode('', $partes);
    }

    /** O token vale 24 h e nao tem refresh: guardado pelo tempo da requisicao, como na Efi. */
    private function token(array $conta): string
    {
        static $cache = array();

        $c = $this->credenciais($conta);
        $clientId = trim((string) $c['cora_client_id']);
        $chave = (string) ($conta['id'] ?? '0') . '|' . (string) ($conta['ambiente'] ?? '') . '|' . sha1($clientId);
        if (isset($cache[$chave]) && $cache[$chave]['ate'] > time()) {
            return $cache[$chave]['token'];
        }

        $r = Http::json('POST', $this->base($conta) . '/token',
            array('Content-Type: application/x-www-form-urlencoded', 'Accept: application/json', 'User-Agent: PainelShield'),
            array('grant_type' => 'client_credentials', 'client_id' => $clientId),
            $this->pem($conta)
        );

        if ($r['erro'] !== '') {
            // Handshake recusado chega aqui como erro de rede. Na Cora quase
            // sempre e o par de outro ambiente, e dizer "rede" mandaria o membro
            // procurar o defeito no lugar errado.
            if (preg_match('/ssl|certificate|private key|handshake/i', $r['erro'])) {
                throw new \RuntimeException('A Cora recusou a conexao segura (certificado). Confira se o certificado e a chave'
                    . ' sao do ambiente escolhido, Producao ou Stage. Detalhe: ' . $r['erro']);
            }
            throw new \RuntimeException($r['erro']);
        }
        if ($r['codigo'] >= 300) {
            $j = (array) ($r['json'] ?? array());
            $motivo = self::texto($j['error_description'] ?? null);
            if ($motivo === '') {
                $motivo = self::texto($j['message'] ?? ($j['error'] ?? null));
            }
            throw new \RuntimeException('A Cora recusou a credencial desta conta (HTTP ' . $r['codigo'] . ')'
                . ($motivo !== '' ? ': ' . $motivo : '')
                . '. Confira o Client ID e se o certificado e do mesmo ambiente (Producao ou Stage).');
        }

        $token = self::texto($r['json']['access_token'] ?? null);
        if ($token === '') {
            throw new \RuntimeException('A Cora respondeu sem token de acesso.');
        }

        // Dois minutos de folga, pelo mesmo motivo da Efi.
        $vida = (int) ($r['json']['expires_in'] ?? 86400);
        $cache[$chave] = array('token' => $token, 'ate' => time() + max(60, $vida - 120));

        return $token;
    }

    /** UUID v4 para o Idempotency-Key, que a Cora exige em todo POST. */
    private static function uuid(): string
    {
        $b = random_bytes(16);
        $b[6] = chr((ord($b[6]) & 0x0f) | 0x40);
        $b[8] = chr((ord($b[8]) & 0x3f) | 0x80);
        $h = bin2hex($b);

        return substr($h, 0, 8) . '-' . substr($h, 8, 4) . '-' . substr($h, 12, 4) . '-'
            . substr($h, 16, 4) . '-' . substr($h, 20, 12);
    }

    private static function texto($valor): string
    {
        return is_scalar($valor) ? trim((string) $valor) : '';
    }

    /** Levanta com a mensagem que a Cora de fato mandou, e nao com uma generica. */
    private function chamar(array $conta, string $metodo, string $rota, ?array $carga = null): array
    {
        $cabecalhos = array(
            'Authorization: Bearer ' . $this->token($conta),
            'Accept: application/json',
            'User-Agent: PainelShield',
        );
        if (strtoupper($metodo) === 'POST') {
            // Um por chamada: a reemissao precisa de fatura NOVA, e repetir a
            // chave devolveria a antiga, ja cancelada.
            $cabecalhos[] = 'Idempotency-Key: ' . self::uuid();
        }

        $r = Http::json($metodo, $this->base($conta) . $rota, $cabecalhos, $carga, $this->pem($conta));

        if ($r['erro'] !== '') {
            throw new \RuntimeException($r['erro']);
        }
        if ($r['codigo'] >= 300 && $r['codigo'] < 400) {
            throw new \RuntimeException('A Cora respondeu com redirecionamento (HTTP ' . $r['codigo'] . ') em ' . $rota
                . ': o endereco da API mudou, e nada foi feito.');
        }
        if ($r['codigo'] >= 400) {
            if ($r['codigo'] === 401 || $r['codigo'] === 403) {
                throw new \RuntimeException('A Cora recusou a credencial desta conta (HTTP ' . $r['codigo'] . ').'
                    . ' Confira o Client ID e o certificado em Formas de recebimento.');
            }

            // 400 traz {code, message, errors[{code, message}]}; 422 traz
            // {code: "REC-XXXX", message} -- e o REC diz o motivo (REC-0006: ja pago).
            $j = (array) ($r['json'] ?? array());
            $motivos = array();
            foreach ((array) ($j['errors'] ?? array()) as $e) {
                if (is_array($e) && self::texto($e['message'] ?? null) !== '') {
                    $motivos[] = self::texto($e['message']);
                }
            }
            $texto = $motivos ? implode(' | ', $motivos) : self::texto($j['message'] ?? null);
            $codigo = self::texto($j['code'] ?? null);
            if (!$motivos && $texto !== '' && $codigo !== '') {
                $texto .= ' (' . $codigo . ')';
            }

            throw new \RuntimeException('A Cora recusou (HTTP ' . $r['codigo'] . ')' . ($texto !== '' ? ': ' . $texto : '.'));
        }

        return $r;
    }

    // ---------------------------------------------------------------
    // Cobranca
    // ---------------------------------------------------------------

    public function criar(array $cobranca, array $conta, array $cliente): Resultado
    {
        $metodo = strtolower(trim((string) ($cobranca['forma'] ?? '')));
        if ($metodo === '') {
            $metodo = 'pix';
        }
        if (!in_array($metodo, array('pix', 'boleto'), true)) {
            throw new \RuntimeException('A Cora so emite PIX e boleto; o pedido veio como "' . $metodo . '".');
        }

        $documento = (string) preg_replace('/\D+/', '', (string) ($cliente['cnpj'] ?? ''));
        $tipo = strlen($documento) === 14 ? 'CNPJ' : (strlen($documento) === 11 ? 'CPF' : '');
        if ($tipo === '') {
            throw new \RuntimeException('O cliente esta sem CPF/CNPJ valido, e a Cora exige o documento do pagador.');
        }

        $centavos = (int) ($cobranca['valor_centavos'] ?? 0);
        if ($centavos < self::MINIMO_CENTAVOS) {
            throw new \RuntimeException('A Cora so emite cobrancas a partir de R$ 5,00.');
        }

        // Vencimento no passado a Cora recusa (paymentTerms.dueDate); hoje ela
        // aceita. A vencida que se reemite ganha o piso da casa, e o vencimento
        // futuro vai como esta, porque e a data impressa no boleto.
        $vencimento = substr(trim((string) ($cobranca['vencimento'] ?? '')), 0, 10);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $vencimento) || $vencimento < date('Y-m-d')) {
            $vencimento = Prazo::fim('')->format('Y-m-d');
        }

        $descricao = trim((string) ($cobranca['descricao'] ?? ''));
        if ($descricao === '') {
            $descricao = 'Licenca de uso';
        }

        $carga = array(
            // A doc nao diz se `code` e unico, e a reemissao cria OUTRA fatura
            // para a mesma cobranca: com o instante, a segunda nunca esbarra na
            // primeira. O comeco continua sendo a referencia `shield-<id>`.
            'code' => 'shield-' . (int) ($cobranca['id'] ?? 0) . '-' . date('ymdHis'),
            'customer' => $this->pagador($cliente, $documento, $tipo),
            'services' => array(array(
                'name' => mb_substr($descricao, 0, 60),
                'description' => mb_substr($descricao, 0, 100),
                // CENTAVOS, inteiro: R$ 10,01 = 1001.
                'amount' => $centavos,
            )),
            // Multa e juros NAO vao: o motor ja os somou ao valor antes de emitir
            // (encargos.php), e mandar aqui cobraria duas vezes.
            'payment_terms' => array('due_date' => $vencimento),
            'payment_forms' => $metodo === 'pix' ? array('PIX') : array('BANK_SLIP', 'PIX'),
        );

        $r = $this->chamar($conta, 'POST', '/v2/invoices/', $carga);
        $j = (array) ($r['json'] ?? array());
        if (self::texto($j['id'] ?? null) === '') {
            throw new \RuntimeException('A Cora aceitou a cobranca e nao devolveu o id.');
        }
        $bruto = (string) $r['corpo'];

        // A doc mostra a linha e o pix.emv JA na resposta. Se vierem vazios -- ou,
        // no boleto, sem o PIX, que e o que o QR do ERP precisa --, uma segunda
        // olhada, e so uma: o painel guarda o codigo apenas na emissao, mas isto
        // tambem roda no ciclo do cron, com muitas faturas numa passada.
        $semPix = !is_array($j['pix'] ?? null) || self::texto($j['pix']['emv'] ?? null) === '';
        if ($this->codigoDe($j, $metodo) === '' || ($metodo === 'boleto' && $semPix)) {
            usleep(1000000);
            try {
                $r2 = $this->chamar($conta, 'GET', '/v2/invoices/' . rawurlencode((string) $j['id']));
                if (is_array($r2['json']) && self::texto($r2['json']['id'] ?? null) !== '') {
                    $j = $r2['json'];
                    $bruto = (string) $r2['corpo'];
                }
            } catch (\RuntimeException $ignorado) {
                // Fica valendo a resposta da emissao.
            }
        }

        if ($metodo === 'pix' && $this->codigoDe($j, 'pix') === '') {
            // DOCUMENTADO: sem chave PIX cadastrada na conta Cora o QR nao e
            // gerado. Fatura sem codigo nao cobra ninguem, e com o id guardado a
            // guarda de codigo vivo recusaria emitir por cima: cancela e explica.
            $id = (string) $j['id'];
            try {
                $this->cancelar($id, $conta);
                $desfecho = 'A fatura foi cancelada; cadastre a chave e emita de novo.';
            } catch (\RuntimeException $naoCancelou) {
                $desfecho = 'Cancele a fatura ' . $id . ' no app da Cora, cadastre a chave e emita de novo.';
            }
            throw new \RuntimeException('A Cora criou a fatura sem o QR do PIX: a conta Cora precisa de uma chave PIX'
                . ' cadastrada. ' . $desfecho);
        }

        return new Resultado(
            situacao: self::traduzir(self::texto($j['status'] ?? null)),
            idExterno: (string) $j['id'],
            situacaoProvedor: self::texto($j['status'] ?? null),
            link: $this->linkDe($j),
            copiaECola: $this->codigoDe($j, $metodo),
            metodo: $metodo,
            bruto: $bruto,
            linhaDigitavel: $metodo === 'boleto' ? $this->linhaDe($j) : ''
        );
    }

    private function pagador(array $cliente, string $documento, string $tipo): array
    {
        $nome = trim((string) ($cliente['razao'] ?? ''));
        $pagador = array(
            'name' => mb_substr($nome !== '' ? $nome : 'Cliente', 0, 60),
            'document' => array('identity' => $documento, 'type' => $tipo),
        );

        // Ate 60 pela doc. Cortar um e-mail faria dele outro endereco: o longo nao vai.
        $email = trim((string) ($cliente['email'] ?? ''));
        if ($email !== '' && strlen($email) <= 60 && filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $pagador['email'] = $email;
        }

        // Endereco e opcional na Cora, e so vai quando o cadastro o tem INTEIRO:
        // o Endereco::de completa o que falta ("Centro", "Cidade", "SP") porque
        // outros gateways exigem endereco, e aqui isso registraria boleto com
        // cidade inventada.
        $inteiro = strlen((string) preg_replace('/\D+/', '', (string) ($cliente['cep'] ?? ''))) === 8
            && strlen(trim((string) ($cliente['uf'] ?? ''))) === 2;
        foreach (array('endereco', 'bairro', 'cidade') as $campo) {
            $inteiro = $inteiro && trim((string) ($cliente[$campo] ?? '')) !== '';
        }
        if ($inteiro) {
            $e = Endereco::de($cliente);
            $pagador['address'] = array(
                'street' => mb_substr($e['rua'], 0, 60),
                'number' => mb_substr($e['numero'], 0, 10),
                'district' => mb_substr($e['bairro'], 0, 60),
                'city' => mb_substr($e['cidade'], 0, 60),
                'state' => $e['uf'],
                // Obrigatorio quando ha endereco (doc da emissao v2).
                'complement' => self::SEM_COMPLEMENTO,
                'zip_code' => $e['cep'],
            );
        }

        return $pagador;
    }

    public function consultar(string $idExterno, array $conta): Resultado
    {
        $r = $this->chamar($conta, 'GET', '/v2/invoices/' . rawurlencode($idExterno));
        $j = (array) ($r['json'] ?? array());
        $situacao = self::traduzir(self::texto($j['status'] ?? null));

        // Os pagamentos que deram certo. A doc mostra SUCCESS e nao lista os
        // outros; sem rotulo tambem vale, para o pagamento nao se perder por falta
        // de palavra.
        $pagamentos = array();
        foreach ((array) ($j['payments'] ?? array()) as $p) {
            if (is_array($p) && in_array(strtoupper(self::texto($p['status'] ?? null)), array('SUCCESS', ''), true)) {
                $pagamentos[] = $p;
            }
        }
        $ultimo = $pagamentos ? $pagamentos[count($pagamentos) - 1] : array();

        // `total_paid` JA VEM EM CENTAVOS. Nao multiplicar.
        $pago = is_numeric($j['total_paid'] ?? null) ? (int) $j['total_paid'] : 0;
        if ($pago <= 0) {
            foreach ($pagamentos as $p) {
                $pago += is_numeric($p['total_paid'] ?? null) ? (int) $p['total_paid'] : 0;
            }
        }

        // finalized_at traz data e hora; occurrence_date, so a data.
        $quando = self::texto($ultimo['finalized_at'] ?? null);
        if ($quando === '') {
            $quando = self::texto($j['occurrence_date'] ?? null);
        }

        $forma = strtoupper(self::texto($ultimo['method'] ?? null));
        if ($forma === '') {
            $forma = self::texto($this->boletoDe($j)['digitable'] ?? null) !== '' ? 'BANK_SLIP' : 'PIX';
        }
        $metodo = $forma === 'BANK_SLIP' ? 'boleto' : ($forma === 'PIX' ? 'pix' : strtolower($forma));

        return new Resultado(
            situacao: $situacao,
            idExterno: self::texto($j['id'] ?? null) !== '' ? self::texto($j['id']) : $idExterno,
            situacaoProvedor: self::texto($j['status'] ?? null),
            link: $this->linkDe($j),
            copiaECola: $this->codigoDe($j, $metodo === 'boleto' ? 'boleto' : 'pix'),
            valorPagoCentavos: $situacao === Resultado::PAGA && $pago > 0 ? $pago : null,
            pagoEm: $situacao === Resultado::PAGA && $quando !== '' && strtotime($quando) !== false
                ? date('Y-m-d H:i:s', strtotime($quando)) : null,
            metodo: $metodo,
            bruto: (string) $r['corpo'],
            linhaDigitavel: $metodo === 'boleto' ? $this->linhaDe($j) : ''
        );
    }

    public function cancelar(string $idExterno, array $conta): bool
    {
        // 204 (ou 200 com {}) quando cancela. Fatura paga volta 422 REC-0006 com
        // a frase da Cora, e ela sobe para o membro ler.
        $this->chamar($conta, 'DELETE', '/v2/invoices/' . rawurlencode($idExterno));

        return true;
    }

    // ---------------------------------------------------------------
    // Aviso de pagamento
    // ---------------------------------------------------------------

    /**
     * O aviso da Cora e um POST SEM CORPO: o evento, o tipo (invoice.paid) e a
     * fatura vem nos cabecalhos. Corpo nao e lido, e nao ha assinatura
     * documentada: confere so pelo token da URL.
     */
    public function lerWebhook(string $corpo, array $cabecalhos, array $conta): ?EventoWebhook
    {
        $tipo = strtolower(self::texto($cabecalhos['webhook-event-type'] ?? null));
        $fatura = self::texto($cabecalhos['webhook-resource-id'] ?? null);
        $evento = self::texto($cabecalhos['webhook-event-id'] ?? null);

        if ($fatura === '') {
            return null;
        }
        // So faturas sao deste painel (o cadastro pede resource=invoice).
        if ($tipo !== '' && strpos($tipo, 'invoice') !== 0) {
            return null;
        }

        return new EventoWebhook(
            id: $evento !== '' ? $evento : 'cora-' . ($tipo !== '' ? $tipo : 'invoice') . '-' . $fatura,
            tipo: $tipo !== '' ? $tipo : 'invoice',
            idExterno: $fatura,
            assinaturaConfere: TokenWebhook::confere($cabecalhos, $conta),
            corpo: $corpo
        );
    }

    /**
     * Os avisos cadastrados nesta conta da Cora (GET /endpoints/).
     *
     * @return array<int,array{id:string,url:string,resource:string,trigger:string}>
     */
    public function listarWebhooks(array $conta): array
    {
        $r = $this->chamar($conta, 'GET', '/endpoints/');
        $j = (array) ($r['json'] ?? array());
        $itens = $j;
        foreach (array('items', 'endpoints', 'data') as $chave) {
            if (isset($j[$chave]) && is_array($j[$chave])) {
                $itens = $j[$chave];
                break;
            }
        }

        $saida = array();
        foreach ($itens as $e) {
            if (!is_array($e) || self::texto($e['url'] ?? null) === '') {
                continue;
            }
            $saida[] = array(
                'id' => self::texto($e['id'] ?? null),
                'url' => self::texto($e['url']),
                'resource' => self::texto($e['resource'] ?? null),
                'trigger' => self::texto($e['trigger'] ?? null),
            );
        }

        return $saida;
    }

    /**
     * Cadastra o aviso de faturas na Cora -- chamado por Formas de recebimento.
     *
     * Na Integracao Direta nao ha tela para isso: e pela API. O aviso que aponta
     * para ESTE painel com outro token e apagado, senao a Cora continuaria
     * batendo com um token que ja nao vale; o de outro sistema na mesma conta
     * fica.
     *
     * @return array{faturas: bool}
     */
    public function cadastrarWebhook(array $conta, string $url): array
    {
        $destaTela = explode('?', $url, 2)[0];
        $jaExiste = false;

        foreach ($this->listarWebhooks($conta) as $e) {
            if ($e['resource'] !== 'invoice' && $e['resource'] !== '*') {
                continue;
            }
            if ($e['url'] === $url) {
                $jaExiste = true;
                continue;
            }
            if (explode('?', $e['url'], 2)[0] === $destaTela && $e['id'] !== '') {
                try {
                    $this->chamar($conta, 'DELETE', '/endpoints/' . rawurlencode($e['id']));
                } catch (\RuntimeException $ignorado) {
                    // Nao impede o cadastro novo: o antigo so gera avisos recusados.
                }
            }
        }

        if (!$jaExiste) {
            $this->chamar($conta, 'POST', '/endpoints/', array('url' => $url, 'resource' => 'invoice', 'trigger' => '*'));
        }

        return array('faturas' => true);
    }

    /**
     * O teste de conexao da tela. O de sempre pergunta por uma cobranca inventada
     * e le o 404 como "conectou"; a Cora responde 400 a id fora do padrao inv_...,
     * entao a credencial certa apareceria como recusada. O token prova o Client ID
     * e o par, e a lista de avisos diz se falta cadastrar o webhook.
     */
    public function testarConexao(array $conta): string
    {
        $faturas = 0;
        foreach ($this->listarWebhooks($conta) as $e) {
            if ($e['resource'] === 'invoice' || $e['resource'] === '*') {
                $faturas++;
            }
        }

        return 'A Cora aceitou o certificado e o Client ID. '
            . ($faturas > 0
                ? 'Ha ' . $faturas . ' aviso(s) de fatura cadastrado(s) nela.'
                : 'Ainda nao ha aviso de pagamento cadastrado nela: grave o token da URL e use o botao de cadastrar o webhook.');
    }

    // ---------------------------------------------------------------
    // Leitura da resposta
    // ---------------------------------------------------------------

    private function boletoDe(array $j): array
    {
        return (array) ($j['payment_options']['bank_slip'] ?? array());
    }

    /** O PDF do boleto; no so-PIX, o PNG do QR -- e o que a doc diz que vem em `url`. */
    private function linkDe(array $j): string
    {
        return self::texto($this->boletoDe($j)['url'] ?? null);
    }

    /**
     * O codigo que vai para o cliente -- O PIX PRIMEIRO, tambem no boleto.
     *
     * O BOLETO DA CORA E HIBRIDO: vem com um PIX junto. O ERP desenha um QR com
     * este campo sob "Copiar codigo PIX"; com a linha digitavel aqui, o QR saia
     * com o numero do boleto e o cliente nao conseguia pagar lendo pelo celular
     * (achado por um membro em 17/09/2026; o Inter e o C6 ja faziam assim). A
     * linha digitavel vai no campo dela (linhaDe), e o PDF no `link`. So sem PIX
     * a linha entra aqui tambem.
     */
    private function codigoDe(array $j, string $metodo): string
    {
        $emv = is_array($j['pix'] ?? null) ? self::texto($j['pix']['emv'] ?? null) : '';
        if ($metodo !== 'boleto' || $emv !== '') {
            return $emv;
        }

        return $this->linhaDe($j);
    }

    /**
     * A linha digitavel, so digitos. A doc traz `digitable` e `barcode` juntos; sem
     * a linha, ela sai do codigo de barras: ninguem digita no banco os 44 numeros
     * feitos para a leitora, e era isso que ia para o cliente ate 17/09/2026.
     */
    private function linhaDe(array $j): string
    {
        $boleto = $this->boletoDe($j);
        $linha = CodigoDePagamento::linha(self::texto($boleto['digitable'] ?? null));

        return $linha !== ''
            ? $linha
            : CodigoDePagamento::linhaDoCodigoDeBarras(self::texto($boleto['barcode'] ?? null));
    }

    /**
     * O vocabulario da Cora para o nosso. CONSERVADOR: o que nao esta na lista
     * de pago NAO e pago.
     *
     * Os oito da pagina "consultar detalhes" (developers.cora.com.br). IN_PAYMENT
     * e "em processo de pagamento": ainda nao e dinheiro, fica aberta ate PAID.
     * CANCELLED e a grafia do status; CANCELED, com um L, e a do gatilho do aviso.
     * Estorno a doc nao lista, e palavra que ela nao lista e INDEFINIDA.
     */
    public static function traduzir(string $status): string
    {
        switch (strtoupper(trim($status))) {
            case 'PAID':
                return Resultado::PAGA;
            case 'DRAFT':
            case 'OPEN':
            case 'IN_PAYMENT':
            case 'INITIATED':
            case 'RECURRENCE_DRAFT':
                return Resultado::ABERTA;
            case 'LATE':
                return Resultado::VENCIDA;
            case 'CANCELLED':
            case 'CANCELED':
                return Resultado::CANCELADA;
            default:
                return Resultado::INDEFINIDA;
        }
    }
}
