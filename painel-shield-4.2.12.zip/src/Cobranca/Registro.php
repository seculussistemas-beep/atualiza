<?php

namespace Shield\Cobranca;

use Shield\Cobranca\Provedores\Asaas;
use Shield\Cobranca\Provedores\C6Bank;
use Shield\Cobranca\Provedores\ContaAzul;
use Shield\Cobranca\Provedores\Cora;
use Shield\Cobranca\Provedores\Dinheiro;
use Shield\Cobranca\Provedores\Efi;
use Shield\Cobranca\Provedores\Falso;
use Shield\Cobranca\Provedores\InfinitePay;
use Shield\Cobranca\Provedores\Inter;
use Shield\Cobranca\Provedores\MercadoPago;
use Shield\Cobranca\Provedores\PagBank;
use Shield\Cobranca\Provedores\Pagarme;
use Shield\Cobranca\Provedores\PixEstatico;

/**
 * De um nome de provedor para o adaptador dele - 25/08/2026.
 *
 * E o unico lugar que precisa mudar para acrescentar provedor -- nenhuma
 * tabela, nenhuma tela, nenhuma linha do motor.
 *
 * `pagseguro` APONTA PARA O MESMO ADAPTADOR DE `pagbank`, e nao e descuido: a
 * empresa trocou de nome e as contas ja cadastradas guardam o codigo antigo.
 * Renomear a coluna de uma base em producao para acompanhar marketing custa
 * uma migracao e nao entrega nada; o que o membro LE e "PagBank", e o que o
 * banco guarda pode ser qualquer um dos dois.
 *
 * Provedor sem adaptador continua devolvendo null em vez de estourar. Hoje nao
 * ha nenhum nessa situacao -- a `cora` foi a ultima, e ganhou adaptador em
 * 04/09/2026. O comportamento fica porque e a rede que segura provedor
 * cadastrado a mao numa base antiga: melhor a tela dizer "sem adaptador" do que
 * o painel cair.
 *
 * Inter, C6 Bank e InfinitePay entraram em 16/09/2026, vindos de membros. So
 * o Inter e a InfinitePay tem uso real em campo; o C6 ninguem rodou. O Conta
 * Azul (mesmo dia) foi escrito pela documentacao e tambem ninguem rodou.
 */
final class Registro
{
    /** @var array<string,Provedor> */
    private static array $criados = array();

    public static function para(string $provedor): ?Provedor
    {
        $provedor = strtolower(trim($provedor));

        if (isset(self::$criados[$provedor])) {
            return self::$criados[$provedor];
        }

        $classes = array(
            'asaas' => Asaas::class,
            'efi' => Efi::class,
            'pagarme' => Pagarme::class,
            'mercadopago' => MercadoPago::class,
            'pagbank' => PagBank::class,
            'pagseguro' => PagBank::class,      // o nome antigo, mesma casa
            'pix_estatico' => PixEstatico::class,
            'dinheiro' => Dinheiro::class,
            'cora' => Cora::class,
            'inter' => Inter::class,
            'c6bank' => C6Bank::class,
            'infinitepay' => InfinitePay::class,
            'contaazul' => ContaAzul::class,
            'falso' => Falso::class,
        );

        if (!isset($classes[$provedor])) {
            return null;
        }

        return self::$criados[$provedor] = new $classes[$provedor]();
    }

    /** Os que ja emitem. O resto da conta_recebimento ainda espera adaptador. */
    public static function implementados(): array
    {
        return array('asaas', 'efi', 'pagarme', 'mercadopago', 'pagbank', 'pagseguro',
                     'pix_estatico', 'dinheiro', 'cora', 'inter', 'c6bank', 'infinitepay', 'contaazul');
    }
}
