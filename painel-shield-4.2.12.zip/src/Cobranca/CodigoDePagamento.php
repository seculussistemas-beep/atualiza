<?php

namespace Shield\Cobranca;

/**
 * O codigo que o cliente usa para pagar -- 17/09/2026.
 *
 * `cobranca_tentativa.copia_e_cola` guardava ora o PIX, ora a linha digitavel do
 * boleto, e cada tela adivinhava qual dos dois pela forma da cobranca. O boleto
 * hibrido (Cora, Inter, C6, Asaas com chave PIX) leva o PIX nesse campo com a
 * forma "boleto": a area do cliente o rotulava "Linha digitavel", e o ERP
 * desenhava como QR de PIX a linha de um boleto sem PIX.
 *
 * O QUE DECIDE E O CONTEUDO, nunca a forma: todo BR Code do PIX comeca pelo
 * campo 00 com a versao 01 ("000201", Manual do BR Code do BCB), e linha
 * digitavel e so digito. Desde a V4_2_10 a linha tem coluna propria
 * (`linha_digitavel`), e o copia e cola fica sendo o PIX sempre que houver um.
 */
final class CodigoDePagamento
{
    public static function ehPix(string $codigo): bool
    {
        return strncmp(trim($codigo), '000201', 6) === 0;
    }

    /**
     * A linha so com os digitos. C6, Pagar.me e o `formatted_barcode` do PagBank a
     * mandam com ponto e espaco; o aplicativo do banco aceita os digitos, e o ERP
     * compara tamanho. O que nao tem o tamanho de uma linha (47 no boleto
     * bancario, 48 na arrecadacao) nao e linha e volta vazio: uma URL com numeros
     * ou um codigo de barras de 44 no campo errado viraria "linha" para copiar.
     */
    public static function linha(string $texto): string
    {
        $digitos = (string) preg_replace('/\D+/', '', $texto);
        $tamanho = strlen($digitos);

        return ($tamanho === 47 || $tamanho === 48) ? $digitos : '';
    }

    /**
     * O que a tela oferece para copiar, na ordem: o PIX e a linha do boleto, cada
     * um uma vez. O boleto sem PIX grava a linha nos dois campos (quem so le o copia
     * e cola continua achando), e a tentativa de antes da V4_2_10 so tem o copia e
     * cola. O que nao e PIX nem linha -- o codigo de barras de 44 que o Mercado Pago
     * gravava ate 17/09/2026 -- vai como 'codigo', sem um nome que engane.
     *
     * @return list<array{tipo: string, valor: string}>
     */
    public static function paraCopiar(string $copiaECola, string $linhaDigitavel): array
    {
        $copia = trim($copiaECola);
        $linha = self::linha($linhaDigitavel);
        $codigos = array();

        if (self::ehPix($copia)) {
            $codigos[] = array('tipo' => 'pix', 'valor' => $copia);
        } elseif ($copia !== '') {
            $linhaDaCopia = self::linha($copia);
            if ($linhaDaCopia === '') {
                $codigos[] = array('tipo' => 'codigo', 'valor' => $copia);
            } elseif ($linha === '') {
                $linha = $linhaDaCopia;
            }
        }
        if ($linha !== '') {
            $codigos[] = array('tipo' => 'linha', 'valor' => $linha);
        }

        return $codigos;
    }

    /**
     * Do codigo de barras (44 posicoes) para a linha digitavel (47), pela regra da
     * FEBRABAN. Serve ao provedor que so devolve o codigo de barras: ninguem digita
     * 44 numeros de um codigo que foi feito para leitora.
     *
     * SO BOLETO BANCARIO, E SO COM O DIGITO GERAL CONFERIDO. A arrecadacao (comeca
     * com 8) tem outra montagem, e um numero de 44 digitos qualquer viraria uma
     * linha com cara de certa que o banco recusa.
     */
    public static function linhaDoCodigoDeBarras(string $codigo): string
    {
        $c = (string) preg_replace('/\D+/', '', $codigo);
        if (strlen($c) !== 44 || $c[0] === '8') {
            return '';
        }
        if (self::digitoGeral(substr($c, 0, 4) . substr($c, 5)) !== (int) $c[4]) {
            return '';
        }

        // Banco e moeda (1-4), digito geral (5), vencimento e valor (6-19) e o
        // campo livre (20-44), que a linha reparte em tres pedacos com digito cada.
        $livre = substr($c, 19, 25);
        $campo1 = substr($c, 0, 4) . substr($livre, 0, 5);
        $campo2 = substr($livre, 5, 10);
        $campo3 = substr($livre, 15, 10);

        return $campo1 . self::modulo10($campo1)
            . $campo2 . self::modulo10($campo2)
            . $campo3 . self::modulo10($campo3)
            . $c[4]
            . substr($c, 5, 14);
    }

    /** Pesos 2 e 1 da direita para a esquerda; produto de dois digitos soma os digitos. */
    private static function modulo10(string $numero): int
    {
        $soma = 0;
        $peso = 2;
        for ($i = strlen($numero) - 1; $i >= 0; $i--) {
            $produto = (int) $numero[$i] * $peso;
            $soma += intdiv($produto, 10) + $produto % 10;
            $peso = $peso === 2 ? 1 : 2;
        }

        return (10 - $soma % 10) % 10;
    }

    /** Modulo 11 com pesos de 2 a 9; resto que daria 0, 10 ou 11 vira 1. */
    private static function digitoGeral(string $semODigito): int
    {
        $soma = 0;
        $peso = 2;
        for ($i = strlen($semODigito) - 1; $i >= 0; $i--) {
            $soma += (int) $semODigito[$i] * $peso;
            $peso = $peso === 9 ? 2 : $peso + 1;
        }
        $digito = 11 - $soma % 11;

        return $digito >= 10 ? 1 : $digito;
    }
}
