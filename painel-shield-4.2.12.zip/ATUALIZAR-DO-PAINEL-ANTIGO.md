# Vindo do painel antigo

Para quem já tinha o Shield **anterior à versão 4** rodando na hospedagem e vai
passar para a 4.2. Quem já está na 4 não precisa disto: atualiza pela tela
*Atualização*, como diz o `README.md`.

A passagem é uma só, à mão. Depois dela, as próximas versões chegam pela tela.

## Antes de começar

São dez minutos que evitam o pior caso, que é perder a chave da licença.

1. **Faça backup do banco** (no phpMyAdmin: *Exportar*).
2. **Copie a pasta `config/` inteira para fora do servidor.** O que mais importa
   lá dentro é o `config/app.php`, se o seu painel antigo tiver um: ele guarda a
   `crypto_key`, e sem ela a chave da licença, a senha do certificado A1 e as
   credenciais dos provedores não abrem mais.
3. **Confira a versão do banco** da hospedagem. MariaDB 10.x e MySQL 8.0 ou 8.4
   são os recomendados. MySQL 5.6 instala a partir da versão seguinte à 4.2.10 (até ela, a instalação
   parava em "Falha ao aplicar migrações"), mas ele está sem suporte desde 2021:
   se a hospedagem oferecer outra versão, troque.

## Passo a passo

### 1. Extraia o zip por cima, substituindo tudo

Extraia o pacote **na mesma pasta do painel antigo**, e **substitua todos os
arquivos**. Se o seu programa de FTP perguntar, escolha *substituir* e nunca
*pular os existentes*.

Arquivo velho que não foi trocado derruba o painel. O sintoma mais comum é:

```
Failed opening required '.../funcoes/bootstrap.php'
```

Isso quer dizer que o `banco.php` da versão antiga continuou lá. A saída é
extrair de novo, substituindo tudo.

**Não apague as pastas `config/` e `uploads/`.** É ali que mora a sua instalação:
a configuração do banco, a `crypto_key`, o certificado A1 e os logs do ERP. O
zip traz as duas vazias e não mexe no que já está dentro delas.

### 2. Aponte o domínio para a pasta `public/`

No painel da hospedagem (no cPanel: *Domínios*, a *raiz do documento*), o
domínio do painel deve apontar para a pasta **`public/`**, e não para a pasta
de cima.

Funciona sem isso, porque o `.htaccess` da raiz encaminha tudo para `public/`.
Mas é só um encaminhamento, não uma proteção: enquanto o domínio apontar para
fora de `public/`, a tela de atualização vai avisar, com razão.

### 3. Abra o painel e aplique a atualização do banco

Abra o endereço do painel no navegador. Ele leva você à tela **Atualização do
banco** (ou ao instalador, se não encontrar a configuração). Entre como
administrador e aplique.

- **Se o instalador pedir a `crypto_key` antiga**, cole a do `config/app.php`
  que você guardou. A outra opção, *começar as chaves do zero*, desliga a chave
  da licença: você vai precisar gerar um par novo e recompilar o ERP de todos os
  clientes.

### 4. Leia o log do jeito certo

No fim da tela fica o **Log da Atualização**. Muita linha amarela ali é normal
para quem vem de uma base antiga:

| O que aparece | O que quer dizer |
|---|---|
| `[WARNING] Aviso de idempotência ...` (coluna, índice ou chave "já existe") | a sua base já tinha aquilo; o painel pula e segue |
| `Migração já aplicada com checksum diferente` | o arquivo daquela migração mudou depois que ela rodou na sua base; ela não roda de novo, e não há nada a fazer |
| `[ERROR] ...` | **isto sim** é problema: a migração não entrou |

Se houver linha `[ERROR]`, a partir da versão seguinte à 4.2.10 ela também aparece na faixa
vermelha do topo da tela. Mande o print dela no grupo: é a frase do banco que
diz o que aconteceu.

Ao final, o quadro **Versão DB** mostra a versão nova, e aparece o botão
*Entrar no painel*.

## Depois de entrar

### O ERP

- **O ERP antigo continua funcionando** pelo caminho de sempre, que é a cópia
  dos dados do painel para a base da loja.
- **O que é novo exige o ERP novo**, o compatível com o Shield 4: a licença
  assinada, a cota de terminais respeitada na loja, a área do cliente dentro do
  ERP, o pedido de prazo e a **licença em arquivo** para quem não tem internet.
- Para ligar a licença assinada: em **Chaves**, gere o par (se ainda não tiver),
  cole o `LICENCA_KID` e a chave pública no ERP (`Service/uLicencaEmissor.pas`) e
  recompile.
- **O gerador de serial (contra-senha) saiu.** Serial já gerado continua valendo
  até a data dele. Para liberar cliente sem internet, o caminho agora é a
  *Licença em arquivo*, que só o ERP novo lê.

### O agendador

Entre como administrador e abra `/cron.php`: a tela mostra a chave. Confira se a
tarefa agendada na hospedagem chama esse endereço com essa chave, a cada 5
minutos. Os avisos, os e-mails e a suspensão da régua **só rodam por ele**.

### As formas de recebimento

Revise cada conta em **Formas de recebimento**:

- **Asaas e Mercado Pago:** o segredo do webhook passou a ser obrigatório. Sem
  ele, o aviso de pagamento é recusado, e a baixa só chega pela conferência
  periódica, mais devagar.
- **Cora:** cadastre de novo o Client ID e o par de arquivos do certificado
  (`.crt` e `.key`). O token antigo não é mais lido.
- **InfinitePay e PagBank:** só avisam o pagamento se o painel souber o próprio
  endereço, que vem do `.env` (abaixo). Sem ele, a InfinitePay não confirma
  pagamento nenhum.

### O arquivo `.env`

O pacote não traz esse arquivo. Crie um `.env` na **raiz** do painel (ao lado do
`banco.php`), com uma linha:

```
SHIELD_APP_URL=https://painel.seudominio.com.br
```

Com o endereço do **seu** painel, sempre com `https://`. Ele é usado no link de
recuperação de senha e no aviso de pagamento da InfinitePay e do PagBank.

## As próximas atualizações

Depois desta passagem, as versões novas chegam pela tela **Atualização**, sem FTP:
você cola o endereço do `versao.json` (ou envia o `versao.json` e o zip pela
própria tela), confere a soma e clica em *Instalar agora*.

É a tela, e não a extração à mão, que **remove os arquivos que saíram do
projeto** (a lista `_remover.txt` do pacote) e guarda uma cópia do que trocou
para você poder desfazer. Por isso, depois da primeira vez, prefira sempre ela.
