# Painel Shield

Painel web de licenças do ERP Delphi do projeto Dev PDV Delphi. O ERP instalado
na loja pede ao painel uma licença assinada; o painel decide quem trabalha,
quantas máquinas cabem no contrato, cobra e mostra ao cliente final o que ele
deve.

## O que ele faz

- **Clientes e avaliação.** A loja que instala o ERP se cadastra sozinha na
  primeira abertura e ganha 7 dias de avaliação. Também dá para cadastrar a loja
  à mão, antes de instalar, em *Cadastrar cliente*. Quem está avaliando fica em
  *Em avaliação*; o contrato começa em *Dar início ao contrato*.
- **Licença.** Token assinado (RSA-SHA256) que o ERP confere: validade, cota de
  terminais, módulos, bloqueio, encerramento, liberação em confiança e pedido de
  prazo. Para loja sem internet há a *Licença em arquivo*.
- **Máquinas.** Cada caixa que consulta a licença aparece em *Terminais* e em
  *Monitoramento*: trabalhando, calada, vaga livre ou desativada. O suporte pede
  e lê os logs do ERP pelo painel.
- **Cobrança.** Assinatura (a fatura de cada ciclo nasce sozinha), pré-pago
  (planos ou período personalizado) e cobrança avulsa. A *Régua de cobrança*
  avisa, aplica multa e juros e suspende quem não paga. O pagamento confirmado
  estende a validade da licença; o estorno a recolhe.
- **Formas de recebimento.** Asaas, Mercado Pago, PagBank, Pagar.me, Efí, Inter,
  C6 Bank, Cora, InfinitePay e Conta Azul, além de PIX na sua chave e dinheiro em
  espécie (confirmação manual). Acompanhe a primeira emissão de cada provedor
  novo que ligar.
- **Área do cliente.** O cliente final entra com o e-mail da loja e a senha que
  você definiu: vê as faturas, copia o PIX, avisa que pagou e pede prazo.
- **Contrato.** Em *Modelo de contrato* você escreve o seu texto uma vez, com
  campos que o painel preenche para cada cliente. Ligado o aceite, o cliente lê e
  aceita na área do cliente, e o aceite (data, hora, IP) vira um PDF.
- **Atualização pela tela.** Versões novas chegam em *Atualização*, sem FTP.

## Requisitos

- **PHP 8.2 ou maior** (recomendado 8.4), com as extensões `pdo_mysql`, `curl`,
  `json`, `mbstring`, `openssl`, `fileinfo` e `simplexml`, que o instalador
  confere, e `zip`, que a tela de atualização usa para abrir o pacote.
- **MariaDB** 10.x ou **MySQL** 8.0 / 8.4, com charset `utf8`. Banco que exige
  TLS também funciona: marque a opção no instalador.
- **Apache** com `mod_rewrite` e `AllowOverride All` (cPanel e Plesk já vêm
  assim). **HTTPS** em produção: os provedores de pagamento só avisam em
  endereço HTTPS.
- Não precisa de Composer nem de Node: o pacote já vem com tudo.

## Instalar

1. Extraia o zip na hospedagem.
2. Aponte o domínio (o `DocumentRoot`) para a pasta **`public/`**. Se a sua
   hospedagem não deixa, extraia na raiz do domínio mesmo: o `.htaccess` da raiz
   encaminha tudo para `public/`.
3. Abra o endereço no navegador. O painel cai no **instalador**: informe o banco,
   e ele grava `config/database.php` e `config/app.php`, cria as tabelas e aplica
   as migrações.
   - Instalando sobre um banco que já tinha o painel, o instalador pede a
     `crypto_key` antiga (do `config/app.php` de antes). Sem ela, a chave da
     licença e as credenciais dos provedores ficam ilegíveis, e a saída é
     começar as chaves do zero.
4. No **primeiro acesso**, crie o administrador. Os dados da sua empresa podem
   ficar para depois, em *Minha empresa*.
5. Em **Chaves**, gere o par. A tela mostra o `LICENCA_KID` e a chave pública
   para colar no ERP (`Service/uLicencaEmissor.pas`); depois, recompile o ERP.
6. Configure o **agendador** (abaixo).
7. Em **Formas de recebimento**, ligue as contas que vão cobrar.

## O agendador (`cron.php`)

A hospedagem deve chamar, a cada 5 minutos:

```
https://seu-dominio/cron.php?chave=SUA_CHAVE
```

Para ver a chave, entre no painel como administrador e abra `/cron.php`: na
primeira vez ela é criada, e depois a mesma é mostrada sempre. Sem login, o
endereço responde 403 e não cria chave nenhuma.

Parte do trabalho acontece mesmo sem o agendador, quando alguém abre o painel
ou um caixa consulta a licença: marcar vencidas, conferir pagamentos e gerar a
fatura do ciclo. A **régua** (avisos, e-mails e suspensão) e a compactação do
histórico das máquinas **só rodam pelo agendador**.

## Atualizar

**Vindo do painel antigo, anterior à versão 4?** Siga o
`ATUALIZAR-DO-PAINEL-ANTIGO.md`, que vem neste pacote: a primeira passagem é à
mão, e tem cuidados que não valem para as próximas.

Em **Atualização**, cole o endereço do `versao.json` da versão nova, ou envie o
`versao.json` e o zip pela própria tela. Confira a soma e clique em *Instalar
agora*. O atualizador guarda uma cópia do que troca, aplica as migrações do
banco e permite desfazer. Arquivos que saíram do projeto são removidos pela
lista `_remover.txt` que vem no pacote.

## Estrutura

- `public/`: a única pasta servida pelo Apache. Telas, `api/licenca.php` (o que o
  ERP consulta), `webhooks/` (os avisos dos provedores), `install/`, `update/` e
  `cron.php`.
- `config/`: a configuração desta instalação, escrita pelo instalador.
- `uploads/`: o certificado A1 e os logs que o ERP envia.
- `estagio/`: área de trabalho do atualizador.
- `banco/`: `BancoCompleto.sql` e as migrações (`banco/migrations/`).
- `funcoes/`, `modules/`, `src/`, `templates/`, `router/`: o código.

## Segurança e cópia de segurança

- **Guarde uma cópia do `config/app.php` fora do servidor.** Ele tem a
  `crypto_key`: sem ela, a chave privada da licença, a senha do certificado A1 e
  as credenciais dos provedores não abrem mais.
- Só `public/` é servido. Os `.htaccess` das pastas internas são uma segunda
  tranca, para o caso de o domínio apontar para a raiz: não os apague.
- Faça backup do banco antes de atualizar.

## Autor

- Projeto desenvolvido por: **Dhones Meneses (Equipe LojaDev)**
- Website: https://lojadodesenvolvedor.com.br

## Licenciamento

Este software é licenciado exclusivamente para usuários do projeto Dev PDV Delphi.
É proibida a distribuição, modificação ou uso não autorizado deste sistema.

## Observação

Este arquivo faz parte do Sistema de Licença Shield.
Certifique-se de manter os créditos do desenvolvedor ao utilizar este sistema.
