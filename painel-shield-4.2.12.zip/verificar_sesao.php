<?php

require_once __DIR__ . '/funcoes/nucleo/carregar.php';
require_once __DIR__ . '/funcoes/nucleo/system_bootstrap.php';
shield_enforce_installation_guard();

// O router ja pode ter aberto a sessao (funcoes/nucleo/csrf.php); abrir de
// novo imprime um Notice no topo da tela.
require_once __DIR__ . '/funcoes/nucleo/sessao.php';
shield_sessao_abrir();

/*
 * Atalho estritamente da bancada local.
 *
 * O PHP embutido e usado apenas pelo `C:\LocalDev\subir.bat`, que serve esta
 * arvore em 127.0.0.1:8088. Nesse unico cenario, abrir uma rota diretamente
 * cria a mesma sessao de administrador que `bancada_sessao.php` criaria. Isso
 * deixa /clientes.php, /parque.php e as demais telas testaveis sem uma etapa
 * de login, mas NAO abre um bypass no Apache, Nginx, PHP-FPM ou em outra porta.
 */
if (!isset($_SESSION['usuario']['login'])
    && PHP_SAPI === 'cli-server'
    && in_array((string) ($_SERVER['REMOTE_ADDR'] ?? ''), array('127.0.0.1', '::1'), true)
    && (int) ($_SERVER['SERVER_PORT'] ?? 0) === 8088
    && realpath((string) ($_SERVER['DOCUMENT_ROOT'] ?? '')) === realpath(__DIR__)) {
    try {
        require_once __DIR__ . '/banco.php';
        $stmtBancada = $pdo->query("SELECT * FROM usuario WHERE TRIM(acesso) = '1' ORDER BY id LIMIT 1");
        $usuarioBancada = $stmtBancada->fetch(PDO::FETCH_ASSOC);
        if (is_array($usuarioBancada)) {
            $_SESSION['usuario'] = $usuarioBancada;
            $_SESSION['bancada_sem_login'] = true;
        }
    } catch (Throwable $ignorado) {
        // Sem base pronta, o fluxo normal continua levando para o login.
    }
}

// "Manter conectado": a sessao do PHP acabou, mas o cookie de 30 dias esta
// ai. Recria a sessao a partir dele e gira o validador (03/09/2026).
require_once __DIR__ . '/funcoes/acesso/sessao_lembrada.php';
if (!isset($_SESSION['usuario']['login']) && !empty($_COOKIE[SHIELD_LEMBRAR_COOKIE])) {
    try {
        require_once __DIR__ . '/banco.php';
        $lembrado = shield_lembrar_restaurar($pdo, (string) $_COOKIE[SHIELD_LEMBRAR_COOKIE]);
        if ($lembrado !== null) {
            session_regenerate_id(true);
            $_SESSION['usuario'] = $lembrado['usuario'];
            shield_lembrar_gravar_cookie($lembrado['cookie']);
        } else {
            shield_lembrar_apagar_cookie();
        }
    } catch (Throwable $ignorado) {
        // Sem tabela ainda (migracao pendente) ou banco fora: segue para o login.
    }
}

if (!isset($_SESSION['usuario']['login'])) {
    header('Location: login.php');
    exit;
}

$acesso = trim((string) ($_SESSION['usuario']['acesso'] ?? ''));
$currentPage = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));

$allowedForClient = [
    'area_cliente.php',
    'perfil.php',
    'editar_perfil.php',
    'logout.php',
];

if ($acesso === '1') {
    // Admin: acesso liberado, validacoes adicionais ficam em cada tela.
} elseif ($acesso === '3') {
    if (!in_array($currentPage, $allowedForClient, true)) {
        header('Location: area_cliente.php');
        exit;
    }
} else {
    // O acesso '2' era o do REPRESENTANTE, que saiu na Fase 1 junto com o
    // modulo. Sem este else ele continuaria sendo mandado para area_vendedor,
    // que nao existe mais -- redirecionamento em circulo para um 404. Conta
    // antiga com acesso '2' cai aqui e ve a tela de acesso negado, que e a
    // verdade: o papel dela nao existe mais neste painel.
    header('Location: acesso_negado.php');
    exit;
}
