<?php

/**
 * LAPIDE -- encaminha para o arquivo que mudou de lugar. 04/09/2026.
 *
 * O painel passou a ser servido de public/ (fase 3). Quem atualiza NAO ganha a
 * remocao do caminho antigo: o atualizador copia por cima do que vem no pacote e
 * nunca apaga o que saiu dele. Entao, numa instalacao que ainda nao reapontou o
 * DocumentRoot para public/, esta URL continua sendo servida -- e servia o
 * arquivo velho. *
 * ESTE CAMINHO SERVIA A VERSAO ANTERIOR A ALTO-1. O gateway tem esta
 * URL cadastrada e continua batendo nela; o encaminhador faz a chamada cair no
 * codigo corrigido em vez do vulneravel.
 *
 * Numa instalacao correta este arquivo e INERTE: esta fora de public/, ninguem o
 * inclui e o Apache nao tem caminho ate ele.
 *
 * Sai do pacote quando o atualizador aprender a remover caminho que saiu, ou
 * quando nao houver mais instalacao servindo da raiz. Ver docs/orfaos-do-move.md.
 */

$destino = __DIR__ . '/../public/webhooks/pagseguro_webhook.php';

if (!is_file($destino)) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    exit('Instalacao incompleta: falta ' . basename($destino) . ' em public/.');
}

// require, e nao require_once: este arquivo EXECUTA o destino. O corpo da
// requisicao (php://input) e os cabecalhos seguem disponiveis, entao o destino
// se comporta como se tivesse sido chamado direto.
require $destino;
