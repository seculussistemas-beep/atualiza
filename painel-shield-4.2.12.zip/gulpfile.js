"use strict";

// Load plugins
const del = require("del");
const gulp = require("gulp");
const merge = require("merge-stream");

// Limpa so os ativos de front-end. `vendor/` tambem contem dependencias do
// Composer (Mercado Pago, PSR, Doctrine); apagar a pasta inteira quebrava o
// painel depois de um simples `gulp vendor`.
function clean() {
  return del(["./public/vendor/bootstrap5/", "./public/vendor/adminlte/"]);
}

// Traz os dois ativos que formam o casco real do painel: AdminLTE 4 (que
// incorpora o CSS do Bootstrap 5.3) e o bundle Bootstrap para dropdowns,
// modais e demais componentes nativos.
//
// O FontAwesome saiu na fase 1: 16 MB em 1.701 arquivos para ~60 icones. Quem
// os desenha e css/icones.css, gerado uma vez. NAO devolver nenhum dos que
// sairam: `gulp vendor` apaga ./vendor inteiro e recopia, entao a linha que
// voltar traz o pacote junto, e sem nada acusar.
function modules() {
  var bootstrapCSS = gulp.src('./node_modules/bootstrap/dist/css/bootstrap.min.css')
    .pipe(gulp.dest('./public/vendor/bootstrap5/css'));
  var bootstrapJS = gulp.src('./node_modules/bootstrap/dist/js/bootstrap.bundle.min.js')
    .pipe(gulp.dest('./public/vendor/bootstrap5/js'));
  var adminLTECSS = gulp.src('./node_modules/admin-lte/dist/css/adminlte.min.css')
    .pipe(gulp.dest('./public/vendor/adminlte/css'));
  var adminLTEJS = gulp.src('./node_modules/admin-lte/dist/js/adminlte.min.js')
    .pipe(gulp.dest('./public/vendor/adminlte/js'));
  return merge(bootstrapCSS, bootstrapJS, adminLTECSS, adminLTEJS);
}

// O CSS do produto continua em css/painel.css: ele aplica marca e semantica
// de licencas por cima do AdminLTE, sem recriar componentes do Bootstrap.

// A TAREFA js E O browser-sync SAIRAM EM 17/09/2026. A js gerava um .min.js ao
// lado de cada arquivo de public/js/, e nenhuma tela carrega .min.js nosso: as
// telas pedem o arquivo legivel. O browser-sync servia a pasta como site
// estatico, sem PHP, e so existia para o `watch` recarregar essa tarefa.

// Define complex tasks
const vendor = gulp.series(clean, modules);
const build = vendor;

// Export tasks
// A tarefa `css` saiu junto com o scss do tema antigo. Deixar o export
// apontando para uma funcao que nao existe mais faria `gulp` quebrar na
// LEITURA do arquivo, antes de rodar tarefa nenhuma.
exports.clean = clean;
exports.vendor = vendor;
exports.build = build;
exports.default = build;
