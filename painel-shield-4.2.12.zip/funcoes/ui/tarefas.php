<?php

/**
 * As tarefas que a busca do topo (Ctrl+K) acha -- 06/10/2026.
 *
 * Pedido no feedback: "esta muito confuso, dificil de encontrar as informacoes:
 * colocar planos, alterar vencimento, excluir terminal, excluir cobranca". As
 * quatro existiam; o problema era o membro nao adivinhar ONDE. A busca ja achava
 * cliente e terminal; agora acha tambem a tarefa, pelo jeito que se pergunta.
 *
 * E DADO, como a lateral (funcoes/ui/lateral.php): a tela so desenha, e o
 * TarefasBuscaTest confere que toda rota daqui existe em router/routes.php.
 *
 * Cada tarefa:
 *   - texto:   o que aparece em negrito ("Alterar o dia do vencimento");
 *   - caminho: onde mora, como o menu escreve ("Configuracoes > Planos");
 *   - url:     para onde vai quando nao depende de cliente;
 *   - cliente: a url com {id} quando a tarefa e DE UM CLIENTE. Sem cliente na
 *              busca, o clique cai em `url` (a lista onde se escolhe o cliente);
 *              com "vencimento mercado", a tela oferece a tarefa ja com o
 *              cliente que a busca achou;
 *   - palavras: o vocabulario de quem procura, sem acento, alem do proprio texto.
 *              Sinonimo de verdade ("apagar", "excluir"), e nao enfeite: palavra
 *              daqui que aparece em muitas tarefas so faz a lista ficar comprida.
 *
 * Texto em entidade HTML como o resto da lateral; a busca compara sem acento.
 */
function shield_tarefas_busca()
{
    return array(
        // ------------------------------------------------- do cliente
        array('texto' => 'Alterar o dia do vencimento', 'caminho' => 'Cliente &rsaquo; Mudar o contrato',
              'url' => '/clientes.php', 'cliente' => '/mudanca_contrato.php?id={id}',
              'palavras' => 'vencimento vence dia data mudar trocar alterar mensalidade'),
        array('texto' => 'Mudar terminais, m&oacute;dulos, valor ou ciclo', 'caminho' => 'Cliente &rsaquo; Mudar o contrato',
              'url' => '/clientes.php', 'cliente' => '/mudanca_contrato.php?id={id}',
              'palavras' => 'aumentar diminuir terminais cota modulo valor reajuste preco ciclo mensal trimestral semestral anual assinatura prepago trocar conta'),
        array('texto' => 'Dar in&iacute;cio ao contrato', 'caminho' => 'Em avalia&ccedil;&atilde;o &rsaquo; Dar in&iacute;cio ao contrato',
              'url' => '/avaliacao.php', 'cliente' => '/fechamento.php?id={id}',
              'palavras' => 'fechar fechamento contrato iniciar comecar vender venda'),
        array('texto' => 'Editar o cadastro do cliente', 'caminho' => 'Cliente &rsaquo; Editar',
              'url' => '/clientes.php', 'cliente' => '/editar_empresa.php?id={id}',
              'palavras' => 'editar cadastro endereco telefone email responsavel cep alterar dados'),
        array('texto' => 'Link e senha da &aacute;rea do cliente', 'caminho' => 'Ficha do cliente',
              'url' => '/clientes.php', 'cliente' => '/ver_empresa.php?id={id}',
              'palavras' => 'area cliente link senha resetar whatsapp acesso portal'),
        array('texto' => 'Faturas de um cliente', 'caminho' => 'Cobran&ccedil;as, filtrado pelo cliente',
              'url' => '/cobrancas.php', 'cliente' => '/cobrancas.php?empresa={id}',
              'palavras' => 'faturas cobrancas boletos historico'),

        // ------------------------------------------------- cobranca
        array('texto' => 'Cancelar ou excluir uma cobran&ccedil;a', 'caminho' => 'Cobran&ccedil;as &rsaquo; bot&atilde;o Cancelar na linha',
              'url' => '/cobrancas.php',
              'palavras' => 'cancelar excluir apagar remover cobranca fatura boleto errada errado desfazer estornar'),
        array('texto' => 'Nova cobran&ccedil;a avulsa', 'caminho' => 'Cobran&ccedil;as &rsaquo; Nova cobran&ccedil;a',
              'url' => '/cobrancas.php',
              'palavras' => 'nova gerar criar emitir avulsa cobrar fatura boleto pix'),
        array('texto' => 'Confirmar pagamento recebido', 'caminho' => 'Cobran&ccedil;as &rsaquo; Confirmar na linha',
              'url' => '/cobrancas.php',
              'palavras' => 'confirmar baixa baixar pagou pago recebido dinheiro manual'),
        array('texto' => 'Pedidos de prazo (car&ecirc;ncia)', 'caminho' => 'Cobran&ccedil;as &rsaquo; Pedem prazo',
              'url' => '/cobrancas.php?situacao=prazo',
              'palavras' => 'prazo carencia promessa pedido liberar dias aceitar recusar'),
        array('texto' => 'Contas a receber: quem deve', 'caminho' => 'Clientes &rsaquo; Contas a receber',
              'url' => '/contas_receber.php',
              'palavras' => 'deve devendo devedor inadimplente inadimplencia atrasado atraso receber aberto'),
        array('texto' => 'Relat&oacute;rio do per&iacute;odo', 'caminho' => 'Clientes &rsaquo; Relat&oacute;rio do per&iacute;odo',
              'url' => '/relatorio_financeiro.php',
              'palavras' => 'relatorio recebido pago pagos periodo mes faturamento financeiro entrou'),
        array('texto' => 'Assinaturas e pr&eacute;-pagos', 'caminho' => 'Cobran&ccedil;as &rsaquo; Assinaturas',
              'url' => '/assinaturas.php',
              'palavras' => 'assinatura assinaturas recorrente recorrencia prepago receita'),

        // ------------------------------------------------- maquinas
        array('texto' => 'Excluir ou liberar um terminal', 'caminho' => 'Clientes &rsaquo; Terminais',
              'url' => '/terminais.php',
              'palavras' => 'terminal terminais maquina computador caixa excluir apagar liberar vaga trocar cota'),
        array('texto' => 'M&aacute;quinas sem sinal', 'caminho' => 'Clientes &rsaquo; Monitoramento',
              'url' => '/parque.php',
              'palavras' => 'monitoramento sinal parou offline versao parque'),
        array('texto' => 'Logs do ERP de um cliente', 'caminho' => 'Clientes &rsaquo; Logs do cliente',
              'url' => '/logs_cliente.php',
              'palavras' => 'log logs erro suporte arquivo'),
        array('texto' => 'Certificados digitais vencendo', 'caminho' => 'Clientes > Certificados digitais',
              'url' => '/certificados.php',
              'palavras' => 'certificado digital a1 vencendo vencido'),
        array('texto' => 'Licen&ccedil;as vencidas', 'caminho' => 'Clientes, filtro de vencidas',
              'url' => '/clientes.php?filter_tipo_validade=vencido',
              'palavras' => 'licenca vencida vencidas bloqueado bloqueio'),

        // ------------------------------------------------- quem ainda nao e cliente
        array('texto' => 'Cadastrar cliente', 'caminho' => 'Ainda n&atilde;o &eacute; cliente &rsaquo; Cadastrar cliente',
              'url' => '/novo_cliente.php',
              'palavras' => 'cadastrar novo cliente incluir adicionar criar empresa'),
        array('texto' => 'Quem est&aacute; em avalia&ccedil;&atilde;o', 'caminho' => 'Ainda n&atilde;o &eacute; cliente &rsaquo; Em avalia&ccedil;&atilde;o',
              'url' => '/avaliacao.php',
              'palavras' => 'avaliacao teste demonstracao lead gratis'),

        // ------------------------------------------------- configuracoes
        array('texto' => 'Planos e pre&ccedil;os do pr&eacute;-pago', 'caminho' => 'Configura&ccedil;&otilde;es &rsaquo; Planos',
              'url' => '/listar_planos.php',
              'palavras' => 'plano planos preco precos valor valores prepago tabela colocar criar'),
        array('texto' => 'M&oacute;dulos', 'caminho' => 'Configura&ccedil;&otilde;es &rsaquo; M&oacute;dulos',
              'url' => '/modulos.php',
              'palavras' => 'modulo modulos fiscal nfe nfse adicional liberar'),
        array('texto' => 'Formas de recebimento (bancos e PIX)', 'caminho' => 'Configura&ccedil;&otilde;es &rsaquo; Formas de recebimento',
              'url' => '/formas_recebimento.php',
              'palavras' => 'gateway banco asaas mercadopago cora inter c6 pagbank pagarme efi infinitepay contaazul pix chave webhook conta recebimento'),
        array('texto' => 'Multa, juros e avisos de cobran&ccedil;a', 'caminho' => 'Configura&ccedil;&otilde;es &rsaquo; R&eacute;gua de cobran&ccedil;a',
              'url' => '/regua.php',
              'palavras' => 'multa juros aviso avisos lembrete email suspender suspensao regua confianca'),
        array('texto' => 'Modelo de contrato', 'caminho' => 'Configura&ccedil;&otilde;es &rsaquo; Modelo de contrato',
              'url' => '/contrato_modelo.php',
              'palavras' => 'contrato modelo aceite termo pdf assinado'),
        array('texto' => 'Chaves da licen&ccedil;a (para o ERP)', 'caminho' => 'Configura&ccedil;&otilde;es &rsaquo; Chaves',
              'url' => '/emissor_licenca.php',
              'palavras' => 'chave chaves kid publica compilar ulicencaemissor par'),
        array('texto' => 'Licen&ccedil;a em arquivo (sem internet)', 'caminho' => 'Configura&ccedil;&otilde;es &rsaquo; Licen&ccedil;a em arquivo',
              'url' => '/licenca_arquivo.php',
              'palavras' => 'offline arquivo lic internet liberar ativar'),
        array('texto' => 'Atualizar o painel', 'caminho' => 'Configura&ccedil;&otilde;es &rsaquo; Atualiza&ccedil;&atilde;o',
              'url' => '/atualizacao.php',
              'palavras' => 'atualizar atualizacao versao pacote update'),
        array('texto' => 'Limpeza de cadastros', 'caminho' => 'Configura&ccedil;&otilde;es &rsaquo; Limpeza de cadastros',
              'url' => '/limpeza_cadastros.php',
              'palavras' => 'limpar limpeza apagar excluir encerrado encerrados cliente'),
        array('texto' => 'Minha empresa (marca, logo, contato)', 'caminho' => 'Menu da conta &rsaquo; Minha empresa',
              'url' => '/editar_softhouse.php',
              'palavras' => 'minha empresa softhouse logo marca cor certificado email contato'),
        array('texto' => 'Trocar a minha senha', 'caminho' => 'Menu da conta &rsaquo; Perfil',
              'url' => '/editar_perfil.php',
              'palavras' => 'senha perfil usuario trocar'),
    );
}
