<?php
/**
 * As pecas de interacao que TODA lista usa. 25/08/2026.
 *
 * Nasceram dentro do clientes.php e sairam de la quando a tela de Assinaturas
 * precisou das mesmas: ordenar por coluna e manter o filtro na URL sao coisas
 * que nao mudam de tela para tela, e uma segunda copia significaria dois
 * comportamentos divergindo com o tempo -- o mesmo motivo que tirou `.lista` e
 * `.selo` de dentro das telas e os levou para o painel.css.
 */

if (!function_exists('shield_url_com')) {
    /**
     * A rota ATUAL com um parametro trocado, preservando o resto.
     *
     * E o que permite ordenar e paginar sem perder o filtro que o membro
     * digitou -- e o inverso disso (perder o filtro ao ordenar) e o defeito
     * classico de lista, porque quem ordena sempre acabou de filtrar.
     */
    function shield_url_com($rota, array $troca = array())
    {
        $base = array_merge($_GET, $troca);
        unset($base['page']);
        if (isset($troca['page'])) {
            $base['page'] = $troca['page'];
        }
        $base = array_filter($base, function ($v) {
            return $v !== '' && $v !== null;
        });

        return '/' . ltrim((string) $rota, '/') . ($base ? '?' . http_build_query($base) : '');
    }
}

if (!function_exists('shield_th_ordem')) {
    /**
     * Cabecalho de coluna que ordena, com a seta no estado certo.
     *
     * Clicar na coluna ATIVA inverte; clicar noutra comeca por ASC, que e o
     * que se espera de "ordenar por nome". A seta so fica cheia na coluna
     * ativa: mostra-la em todas polui, esconder de todas nao conta que da
     * para ordenar.
     */
    function shield_th_ordem($rota, $chave, $rotulo, $ordAtual, $dirAtual, $classe = '')
    {
        $ativa = ($chave === $ordAtual);
        $prox = ($ativa && $dirAtual === 'ASC') ? 'desc' : 'asc';
        $icone = $ativa ? ($dirAtual === 'ASC' ? 'fa-sort-up' : 'fa-sort-down') : 'fa-sort';
        printf('<th scope="col" class="%s%s"><a href="%s">%s <i class="fas %s"></i></a></th>',
            $classe, $ativa ? ' ordenada' : '',
            shield_h(shield_url_com($rota, array('ord' => $chave, 'dir' => $prox))),
            $rotulo, $icone);
    }
}

if (!function_exists('shield_ordem_escolhida')) {
    /**
     * Le `ord` e `dir` da URL contra uma lista branca.
     *
     * A lista branca nao e formalidade: nome de coluna entra direto no
     * `ORDER BY` e nao ha como parametriza-lo.
     *
     * @return array chave, direcao ('ASC'|'DESC')
     */
    function shield_ordem_escolhida(array $permitidas, $padrao)
    {
        $ord = (isset($_GET['ord']) && isset($permitidas[$_GET['ord']])) ? $_GET['ord'] : $padrao;
        $dir = (isset($_GET['dir']) && strtolower($_GET['dir']) === 'asc') ? 'ASC' : 'DESC';

        return array($ord, $dir);
    }
}
