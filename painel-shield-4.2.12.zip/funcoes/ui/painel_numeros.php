<?php
/**
 * Os numeros do Inicio. 25/08/2026.
 *
 * Ficam FORA da tela porque a tela nao pode ser o lugar onde uma conta nasce:
 * "clientes ativos" tem de significar a mesma coisa aqui, na lista de clientes
 * e no aviso que o membro recebe. Cada funcao daqui devolve dado cru; quem
 * desenha e a tela.
 *
 * A CARTEIRA E CLASSIFICADA EM PHP, PELO MESMO FUNIL DA LISTA, e nao por um
 * CASE em SQL que repetiria a regra. Sao quatro colunas de uma tabela que tem
 * centenas de linhas, nao milhoes -- e o preco de ler isso e menor que o de
 * ter duas definicoes de "vencido" no mesmo painel, que e o defeito que a
 * Central de Notificacoes do ERP ja pagou.
 *
 * TODA FUNCAO AQUI SOBREVIVE A TABELA QUE NAO EXISTE. O membro pode nunca ter
 * ligado o modulo de cobranca; o Inicio dele tem de abrir do mesmo jeito, com
 * o bloco de dinheiro dizendo que nao ha o que mostrar em vez de estourar.
 */

require_once __DIR__ . '/../licenca/situacao.php';
// SHIELD_PARQUE_BATIDA_ACEITA: a palavra de "aceita" e a que o endpoint grava, e
// mora com a telemetria, nao aqui.
require_once __DIR__ . '/../licenca/parque.php';

if (!function_exists('shield_painel_carteira')) {
    /**
     * Quantos clientes em cada situacao de licenca.
     *
     * @return array faixas (chave => quantos, na ordem de leitura), total
     */
    function shield_painel_carteira(PDO $pdo)
    {
        // A MESMA consulta que a lista de clientes usa para as faixas dela
        // (fatia 4, 10/09/2026): antes o Inicio classificava cliente a cliente
        // em PHP e a lista contava por SQL proprio, e os dois discordavam.
        //
        // E o MESMO recorte, tambem (11/09/2026): sem a regra de cliente, a
        // carteira somava o lead em avaliacao e o Inicio anunciava "1 sem
        // licenca valida" de quem nem cliente e.
        $contagem = shield_situacao_contar($pdo, ' WHERE ' . shield_situacao_onde_cliente());
        $total = (int) $contagem['todas'];
        unset($contagem['todas']);

        return array('faixas' => $contagem, 'total' => $total);
    }
}

if (!function_exists('shield_painel_sem_licenca')) {
    /**
     * Os leads mais novos, para o bloco "Chegaram e ainda nao tem licenca".
     *
     * SAIU DA TELA -- 14/09/2026. Foi esta consulta que derrubou a Central do
     * membro em MySQL 8 (1525 na comparacao com a data zerada), e escrita dentro
     * de modules/ ela nao cabia num teste com a sessao em modo estrito. O
     * conserto e na conexao (shield_pdo_ajustar_sql_mode); aqui a pergunta so
     * ganhou nome, com o SQL de antes, sem mudar uma letra.
     *
     * A MESMA pergunta da fila Em avaliacao (shield_situacao_onde_avaliacao). Sem
     * o encerrado_em, quem a rotina encerrou aos 30 dias voltava a aparecer aqui
     * como oportunidade de venda (11/09/2026); sem o fechado_em, quem deu inicio
     * ao contrato e ainda nao pagou aparecia como lead (17/09/2026).
     *
     * LEVANTA EXCECAO, ao contrario das vizinhas: `empresa` sempre existe, e
     * engolir a falha aqui mostraria o proximo 1525 como bloco vazio -- que e
     * como a carteira, que engole, fica zerada calada no mesmo servidor.
     */
    function shield_painel_sem_licenca(PDO $pdo, $limite = 6)
    {
        $stmt = $pdo->query(
            'SELECT codigo, razao, cnpj
               FROM empresa
              WHERE ' . shield_situacao_onde_avaliacao() . '
              ORDER BY codigo DESC LIMIT ' . max(1, (int) $limite)
        );

        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
    }
}

if (!function_exists('shield_painel_rotulo_faixa')) {
    /** O nome de cada faixa da carteira, e o filtro da lista que a abre.
     *  O filtro tem de casar com o `switch` do clientes.php: faixa que leva a
     *  uma lista com OUTRA contagem e pior que faixa sem link. */
    function shield_painel_rotulo_faixa($chave)
    {
        $mapa = array(
            'valido'      => array('Em dia',       'ok',      'em_dia'),
            'vence'       => array('Vencendo',     'atencao', 'proximos'),
            'vencido'     => array('Vencidas',     'erro',    'vencido'),
            'sem_licenca' => array('Sem licen&ccedil;a', 'venda', 'sem_licenca'),
            'suspenso'    => array('Suspensas',    'erro',    'suspenso'),
            'bloqueado'   => array('Bloqueadas',   'erro',    'bloqueado'),
        );
        $l = isset($mapa[$chave]) ? $mapa[$chave] : array($chave, 'neutro', '');

        return array('rotulo' => $l[0], 'cor' => $l[1], 'filtro' => $l[2]);
    }
}

if (!function_exists('shield_painel_dinheiro')) {
    /**
     * Recebido no mes, a receber e ja vencido -- tudo em centavos.
     *
     * `disponivel` diz se o modulo de cobranca esta em uso. Sem ele os numeros
     * sao todos zero, e ZERO E AMBIGUO: pode ser "nao devem nada" ou "nao ha
     * cobranca cadastrada". A tela precisa saber a diferenca para nao anunciar
     * receita zero a quem cobra por fora.
     */
    function shield_painel_dinheiro(PDO $pdo)
    {
        $r = array('disponivel' => false, 'recebido_mes' => 0, 'recebimentos' => 0,
                   'a_receber' => 0, 'titulos' => 0, 'vencido' => 0, 'titulos_vencidos' => 0);
        if (!function_exists('shield_cobranca_tabelas_existem')
            || !shield_cobranca_tabelas_existem($pdo)) {
            return $r;
        }
        try {
            $stmt = $pdo->prepare(
                'SELECT COALESCE(SUM(COALESCE(valor_pago_centavos, valor_centavos)), 0) v,
                        COUNT(*) n
                   FROM cobranca
                  WHERE situacao = :paga AND pago_em >= :inicio'
            );
            $stmt->execute(array(':paga' => SHIELD_COB_PAGA, ':inicio' => date('Y-m-01 00:00:00')));
            $l = $stmt->fetch(PDO::FETCH_ASSOC) ?: array();
            $r['recebido_mes'] = (int) ($l['v'] ?? 0);
            $r['recebimentos'] = (int) ($l['n'] ?? 0);

            $stmt = $pdo->prepare(
                'SELECT COALESCE(SUM(valor_centavos), 0) v, COUNT(*) n,
                        COALESCE(SUM(CASE WHEN vencimento < CURDATE() THEN valor_centavos ELSE 0 END), 0) atrasado,
                        SUM(CASE WHEN vencimento < CURDATE() THEN 1 ELSE 0 END) natrasado
                   FROM cobranca WHERE situacao IN (:aberta, :vencida)'
            );
            $stmt->execute(array(':aberta' => SHIELD_COB_ABERTA, ':vencida' => SHIELD_COB_VENCIDA));
            $l = $stmt->fetch(PDO::FETCH_ASSOC) ?: array();
            $r['a_receber'] = (int) ($l['v'] ?? 0);
            $r['titulos'] = (int) ($l['n'] ?? 0);
            $r['vencido'] = (int) ($l['atrasado'] ?? 0);
            $r['titulos_vencidos'] = (int) ($l['natrasado'] ?? 0);
            $r['disponivel'] = true;
        } catch (Throwable $ignorado) {
            // Coluna que falta numa base antiga: fica indisponivel, nao quebra.
        }

        return $r;
    }
}

if (!function_exists('shield_painel_meses')) {
    /**
     * Os ultimos N meses com renovacoes e recebimento.
     *
     * A SERIE E MONTADA COMPLETA, com os meses vazios inclusos: buscar so o
     * que o banco devolve produz um grafico que PULA o mes sem movimento, e
     * mes sem movimento e justamente a informacao que interessa.
     *
     * @return array uma entrada por mes: ym, rotulo, renovacoes, recebido
     */
    function shield_painel_meses(PDO $pdo, $quantos = 12)
    {
        $meses = array();
        $agora = new DateTimeImmutable('first day of this month');
        for ($i = $quantos - 1; $i >= 0; $i--) {
            $m = $agora->sub(new DateInterval('P' . $i . 'M'));
            $meses[$m->format('Y-m')] = array(
                'ym' => $m->format('Y-m'),
                'rotulo' => $m->format('m/y'),
                'mes' => (int) $m->format('n'),
                'renovacoes' => 0,
                'recebido' => 0,
            );
        }
        $desde = $agora->sub(new DateInterval('P' . ($quantos - 1) . 'M'))->format('Y-m-01');

        try {
            $stmt = $pdo->prepare(
                "SELECT DATE_FORMAT(quando, '%Y-%m') ym, COUNT(*) n
                   FROM validade_movimento WHERE quando >= :desde GROUP BY ym"
            );
            $stmt->execute(array(':desde' => $desde));
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $l) {
                if (isset($meses[$l['ym']])) {
                    $meses[$l['ym']]['renovacoes'] = (int) $l['n'];
                }
            }
        } catch (Throwable $ignorado) { /* base sem o historico de validade */ }

        try {
            $stmt = $pdo->prepare(
                "SELECT DATE_FORMAT(pago_em, '%Y-%m') ym,
                        COALESCE(SUM(COALESCE(valor_pago_centavos, valor_centavos)), 0) v
                   FROM cobranca
                  WHERE situacao = :paga AND pago_em >= :desde GROUP BY ym"
            );
            $stmt->execute(array(':paga' => SHIELD_COB_PAGA, ':desde' => $desde . ' 00:00:00'));
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $l) {
                if (isset($meses[$l['ym']])) {
                    $meses[$l['ym']]['recebido'] = (int) $l['v'];
                }
            }
        } catch (Throwable $ignorado) { /* base sem o modulo de cobranca */ }

        return array_values($meses);
    }
}

if (!function_exists('shield_painel_atividade')) {
    /**
     * Batidas por dia nos ultimos N dias -- aceitas e recusadas.
     *
     * E o sinal de vida do parque inteiro: uma queda no total diz que os
     * caixas pararam de perguntar, e uma subida das recusas diz que eles estao
     * perguntando e levando nao. Sao problemas OPOSTOS, e por isso as duas
     * series viajam separadas em vez de um total unico.
     */
    function shield_painel_atividade(PDO $pdo, $dias = 30)
    {
        $serie = array();
        $hoje = new DateTimeImmutable('today');
        for ($i = $dias - 1; $i >= 0; $i--) {
            $d = $hoje->sub(new DateInterval('P' . $i . 'D'));
            $serie[$d->format('Y-m-d')] = array(
                'dia' => $d->format('Y-m-d'),
                'rotulo' => $d->format('d/m'),
                'ok' => 0,
                'recusa' => 0,
            );
        }
        try {
            // ACEITA E A PALAVRA QUE O ENDPOINT GRAVA (14/09/2026). Isto contava
            // por 'ok', que nunca foi gravado: toda batida saia recusada, e a
            // Central disse "0 aceitas, 1 recusadas" com um caixa trabalhando.
            // Dois marcadores com o mesmo valor, e nao um repetido: marcador
            // nomeado usado duas vezes estoura no PDO sem emulacao.
            $stmt = $pdo->prepare(
                "SELECT dia,
                        SUM(CASE WHEN resultado = :aceita THEN quantas ELSE 0 END) ok,
                        SUM(CASE WHEN resultado <> :aceita2 THEN quantas ELSE 0 END) recusa
                   FROM terminal_batida WHERE dia >= :desde GROUP BY dia"
            );
            $stmt->execute(array(
                ':aceita' => SHIELD_PARQUE_BATIDA_ACEITA,
                ':aceita2' => SHIELD_PARQUE_BATIDA_ACEITA,
                ':desde' => $hoje->sub(new DateInterval('P' . ($dias - 1) . 'D'))->format('Y-m-d'),
            ));
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $l) {
                if (isset($serie[$l['dia']])) {
                    $serie[$l['dia']]['ok'] = (int) $l['ok'];
                    $serie[$l['dia']]['recusa'] = (int) $l['recusa'];
                }
            }
        } catch (Throwable $ignorado) { /* base sem o historico de batidas */ }

        return array_values($serie);
    }
}

if (!function_exists('shield_painel_tem_serie')) {
    /** A serie tem algum valor diferente de zero?
     *  Grafico de linha reta no zero nao informa nada e ainda ocupa o lugar de
     *  uma frase que explicaria por que nao ha dado. */
    function shield_painel_tem_serie(array $serie, array $chaves)
    {
        foreach ($serie as $ponto) {
            foreach ($chaves as $c) {
                if (!empty($ponto[$c])) {
                    return true;
                }
            }
        }

        return false;
    }
}

if (!function_exists('shield_painel_vencimentos')) {
    /**
     * A regua do mes: quem ja venceu, quem vence hoje, e o resto do mes dia a dia.
     *
     * A PRIMEIRA VERSAO PERGUNTAVA "QUANTAS VENCEM EM CADA UM DOS PROXIMOS 6
     * MESES", e era a pergunta errada. A licenca aqui e MENSAL na maioria
     * esmagadora, com um dia combinado por cliente -- entao todo cliente
     * vence todo mes, e a resposta seria "trinta, trinta, trinta, trinta".
     * O que muda de um dia para o outro nao e o MES: e o DIA, e se a cobranca
     * daquele dia foi paga.
     *
     * Sao tres janelas de acao e uma distribuicao:
     * AS QUATRO JANELAS SAO FATIAS, e nao circulos concentricos. Na primeira
     * versao "resto do mes" comecava amanha e portanto CONTINHA os proximos 7
     * dias: as fichas mostravam 4 e 3, os 3 estavam dentro dos 4, e quem
     * somasse chegaria a 7 clientes que nao existem. Agora cada cliente cai
     * em exatamente um balde, e a soma e verdadeira.
     *
     *   atrasadas  -- venceu e continua rodando. Trabalho de agora.
     *   hoje       -- vence hoje. Confira se a cobranca saiu.
     *   proximos7  -- de amanha ate o setimo dia. Da para adiantar.
     *   ate_fim    -- do OITAVO dia ao fim do mes. O que ainda espera.
     *   dias       -- em que dia do mes cada cliente cai, para o membro ver
     *                 onde estao os picos (5, 10, 15 e 20 sao os que o
     *                 comercio escolhe) e quanto trabalho cada um representa.
     */
    function shield_painel_vencimentos(PDO $pdo)
    {
        $r = array(
            'atrasadas' => 0, 'hoje' => 0, 'proximos7' => 0,
            'ate_fim_do_mes' => 0, 'dias' => array(), 'maior_dia' => 0,
            'mensais' => 0, 'com_recorrencia' => 0, 'total' => 0,
        );
        try {
            $stmt = $pdo->query(
                "SELECT COUNT(*) total,
                        SUM(validade_licenca < CURDATE()) atrasadas,
                        SUM(validade_licenca = CURDATE()) hoje,
                        SUM(validade_licenca > CURDATE()
                            AND validade_licenca <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)) proximos7,
                        SUM(validade_licenca > DATE_ADD(CURDATE(), INTERVAL 7 DAY)
                            AND validade_licenca <= LAST_DAY(CURDATE())) ate_fim
                   FROM empresa
                  WHERE validade_licenca IS NOT NULL"
            );
            $l = $stmt->fetch(PDO::FETCH_ASSOC) ?: array();
            $r['total'] = (int) ($l['total'] ?? 0);
            $r['atrasadas'] = (int) ($l['atrasadas'] ?? 0);
            $r['hoje'] = (int) ($l['hoje'] ?? 0);
            $r['proximos7'] = (int) ($l['proximos7'] ?? 0);
            $r['ate_fim_do_mes'] = (int) ($l['ate_fim'] ?? 0);

            // O DIA e o do vencimento combinado -- que e o dia da propria
            // validade. Nao sai da assinatura de proposito: cliente sem
            // assinatura cadastrada tambem tem um dia, e ele esta ali.
            $stmt = $pdo->query(
                "SELECT DAY(validade_licenca) dia, COUNT(*) n
                   FROM empresa
                  WHERE validade_licenca IS NOT NULL
                  GROUP BY dia ORDER BY dia"
            );
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $l) {
                $r['dias'][(int) $l['dia']] = (int) $l['n'];
                $r['maior_dia'] = max($r['maior_dia'], (int) $l['n']);
            }
        } catch (Throwable $ignorado) { /* base antiga: devolve zerado */ }

        // Quanto da carteira e mesmo recorrente -- e o que justifica ler esta
        // tela por dia e nao por mes. Sem a tabela, fica zero e o card omite
        // a frase em vez de afirmar o que nao sabe.
        try {
            $stmt = $pdo->query(
                "SELECT COUNT(*) n, SUM(ciclo_meses = 1) mensais
                   FROM assinatura WHERE situacao <> 'cancelada'"
            );
            $l = $stmt->fetch(PDO::FETCH_ASSOC) ?: array();
            $r['com_recorrencia'] = (int) ($l['n'] ?? 0);
            $r['mensais'] = (int) ($l['mensais'] ?? 0);
        } catch (Throwable $ignorado) { /* sem o modulo de assinatura */ }

        return $r;
    }
}

if (!function_exists('shield_painel_clientes_com_recusa')) {
    /**
     * De quantos CLIENTES vem a recusa.
     *
     * O total sozinho nao decide nada: duas mil recusas espalhadas por trinta
     * clientes seriam um problema sistemico (o painel fora do ar, a chave
     * errada); as mesmas duas mil vindas de oito sao a lista de quem esta
     * vencido ou bloqueado -- e isso o membro resolve com oito telefonemas.
     */
    function shield_painel_clientes_com_recusa(PDO $pdo, $dias = 30)
    {
        try {
            $stmt = $pdo->prepare(
                "SELECT COUNT(DISTINCT fk_empresa) FROM terminal_batida
                  WHERE resultado <> :aceita AND dia >= :desde"
            );
            // A MESMA janela do grafico ao lado (shield_painel_atividade): hoje e
            // os `$dias - 1` anteriores. Com '-30 days' eram 31 dias, e a recusa
            // de um dia que o grafico nao mostra entrava no "de N clientes".
            $stmt->execute(array(
                ':aceita' => SHIELD_PARQUE_BATIDA_ACEITA,
                ':desde' => (new DateTimeImmutable('today'))
                    ->sub(new DateInterval('P' . max(0, (int) $dias - 1) . 'D'))->format('Y-m-d'),
            ));

            return (int) $stmt->fetchColumn();
        } catch (Throwable $ignorado) {
            return 0;
        }
    }
}
