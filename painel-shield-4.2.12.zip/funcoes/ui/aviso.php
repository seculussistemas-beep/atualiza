<?php

/**
 * O AVISO QUE FLUTUA -- 14/09/2026.
 *
 * A resposta a um clique que deu certo ("Apelido gravado", "Forma removida")
 * era uma faixa verde no topo do conteudo: empurrava a tela para baixo e, no
 * clique seguinte, a tela subia de volta. Agora e um aviso fixo no canto, que
 * some sozinho em cinco segundos e tem um X. A frase que traz consequencia ou
 * instrucao passa o terceiro argumento e fica dez (ver shield_aviso_flutuante).
 *
 * A TELA SO REGISTRA; QUEM DESENHA E O templates/fecha.php, FORA DO .corpo.
 * La dentro o `position: fixed` nao e do canto da tela: o .corpo anima com
 * transform na entrada (navegador sem transicao entre documentos, painel.css)
 * e na troca de passo do tutorial, e elemento com transform vira a referencia
 * do fixed. O aviso nasceria no meio do conteudo e pularia para o canto.
 *
 * NAO PASSA POR AQUI o que precisa ficar na tela: senha sorteada, link, codigo
 * de pagamento, instrucao com passos, recusa. Some sozinho -- em cinco segundos,
 * ou dez no demorado -- e o membro perde o que nao volta. A lista das faixas
 * que ficam, com o motivo de cada uma, e tests/Unidade/AvisoFlutuanteTest.php.
 */

if (!function_exists('shield_aviso_flutuante')) {
    /**
     * Guarda um aviso de sucesso para o casco desenhar. Aceita texto cru e texto
     * com entidade, porque as telas tem os dois: decodifica aqui e o desenho
     * escapa de novo (o mesmo caminho de shield_legenda). O mesmo texto duas
     * vezes na mesma requisicao vira um aviso so. Texto vazio nao faz nada, entao
     * a tela chama sem `if`.
     *
     * $parametroDaUrl e o parametro que trouxe o aviso (?ok=1, ?salvo=senha). Ele
     * sai do endereco depois de desenhar: sem isso, F5 repetia "gravado" sem nada
     * ter sido gravado.
     *
     * $demorado = true deixa o aviso dez segundos em vez de cinco. E para a frase
     * que diz uma CONSEQUENCIA ou uma INSTRUCAO curta ("na loja passa a valer a
     * partir de 15/09", "mande o novo codigo ao cliente"): em cinco segundos o
     * membro le "Cliente suspenso" e perde a data. "Passo gravado" continua em
     * cinco -- se toda frase demorasse, a pilha cobriria o trabalho com aviso
     * velho e o tempo curto deixaria de existir.
     */
    function shield_aviso_flutuante($texto, $parametroDaUrl = '', $demorado = false)
    {
        $texto = trim(html_entity_decode((string) $texto, ENT_QUOTES, 'UTF-8'));
        if ($texto === '') {
            return;
        }
        // A chave e o proprio texto: e ela que tira a repeticao, e a ordem de
        // chegada continua. O valor e o "demorado": a mesma frase pedida curta e
        // demorada na mesma requisicao fica demorada -- quem pediu mais tempo
        // tinha motivo, e perder o fim da frase e o erro que isto evita.
        $GLOBALS['shield_avisos'][$texto] = !empty($GLOBALS['shield_avisos'][$texto]) || (bool) $demorado;

        // O nome vai para um atributo e para o JavaScript: so letra e sublinhado.
        $param = (string) $parametroDaUrl;
        if (preg_match('/^[a-z_]{1,30}$/', $param) === 1) {
            $GLOBALS['shield_avisos_tirar'][$param] = true;
        }
    }
}

if (!function_exists('shield_avisos_html')) {
    /**
     * A pilha de avisos, ou '' quando nao ha nenhum. Desenhar esvazia: a mesma
     * pilha nao sai duas vezes.
     */
    function shield_avisos_html()
    {
        // Texto => demorado. A chave continua sendo o texto, na ordem de chegada.
        $avisos = (array) ($GLOBALS['shield_avisos'] ?? array());
        $tirar = array_keys($GLOBALS['shield_avisos_tirar'] ?? array());
        $GLOBALS['shield_avisos'] = array();
        $GLOBALS['shield_avisos_tirar'] = array();
        if ($avisos === array()) {
            return '';
        }

        $html = '<div class="aviso-pilha" id="avisoPilha"'
            . ($tirar !== array() ? ' data-tirar="' . htmlspecialchars(implode(' ', $tirar), ENT_QUOTES, 'UTF-8') . '"' : '')
            . '>';
        foreach ($avisos as $texto => $demorado) {
            // Uma classe, e nao um tempo no atributo: o relogio mora inteiro no
            // aviso.css, e a pausa sob o mouse, o X e o menos-movimento valem
            // para os dois sem uma linha de JavaScript.
            $html .= '<div class="aviso-flutua' . ($demorado ? ' aviso-demorado' : '') . '">'
                . '<i class="fas fa-check-circle aviso-icone" aria-hidden="true"></i>'
                . '<span class="aviso-texto">' . htmlspecialchars((string) $texto, ENT_QUOTES, 'UTF-8') . '</span>'
                . '<button type="button" class="aviso-fechar" aria-label="Fechar aviso" title="Fechar">'
                . '<i class="fas fa-times" aria-hidden="true"></i></button>'
                . '</div>';
        }
        // O LEITOR DE TELA ouve uma regiao viva que nasce VAZIA e o fecha.php
        // preenche um instante depois. Texto que ja vem dentro da regiao nao e
        // anunciado, e reescrever o aviso visivel para forcar o anuncio faria
        // ele sumir e voltar num quadro -- a piscada que esta peca existe para
        // nao ter.
        $html .= '<div class="visually-hidden" role="status" aria-live="polite" id="avisoLeitor"></div>';

        return $html . '</div>';
    }
}
