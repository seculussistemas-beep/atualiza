<?php

/**
 * A barra lateral, como dado -- 10/09/2026, fatia 0 da reorganizacao
 * (docs/reorganizacao-do-painel.md, secao 7).
 *
 * Saiu do template por um motivo so: template nao se testa, e as tres coisas
 * que esta fatia corrige eram invisiveis sem teste -- contador que levava a
 * lista errada, grupo que nao se marcava na tela de modulos porque a rota
 * faltava na lista, Limpeza sem grupo que a marcasse. tests/Unidade/
 * LateralTest.php cobra as tres contra router/routes.php.
 *
 * 10/09/2026, tarde: Configuracoes ganhou dois subtitulos ("Configuracao
 * ERP" e "Configuracao Pagamento") e o que se ajusta uma vez foi para la --
 * Cobranca ficou so com o dia a dia. O subtitulo e a 'legenda' do primeiro
 * item de cada bloco.
 *
 * O template (templates/estrutura.php) so DESENHA o que esta aqui.
 */

require_once __DIR__ . '/../cobranca/cobranca_motor.php'; // shield_cobranca_situacoes_em_aberto
require_once __DIR__ . '/../licenca/situacao.php';        // shield_situacao_onde_avaliacao
require_once __DIR__ . '/../licenca/certificado.php';     // shield_certificado_onde_vencendo

/**
 * Os grupos, com os itens que aparecem e TODAS as rotas que pertencem ao
 * grupo -- inclusive as sem item (excluir_*, editar_plano),
 * para a lateral marcar o grupo certo em toda tela.
 *
 * Um item pode ter 'legenda' antes dele ("Ajusta uma vez") e 'badge', que e
 * a chave da contagem (shield_lateral_contagens).
 */
function shield_lateral_grupos()
{
    return array(
        // A pergunta que o menu responde primeiro e DE QUEM estamos falando:
        // quem ainda nao e cliente mora num grupo proprio (fatia 6).
        'avaliacao' => array(
            'rotulo' => 'Ainda n&atilde;o &eacute; cliente',
            'icone' => 'fa-hourglass-half',
            'rotas' => array('avaliacao', 'novo_cliente', 'fechamento'),
            'itens' => array(
                array('rota' => 'avaliacao', 'icone' => 'fa-hourglass-half', 'texto' => 'Em avalia&ccedil;&atilde;o', 'badge' => 'avaliacao'),
                // Cadastrar cliente e o passo ANTES da avaliacao: quem fechou o
                // negocio e ainda nao instalou (16/09/2026).
                array('rota' => 'novo_cliente', 'icone' => 'fa-plus-circle', 'texto' => 'Cadastrar cliente'),
            ),
        ),
        'clientes' => array(
            'rotulo' => 'Clientes',
            'icone' => 'fa-building',
            'rotas' => array(
                'clientes', 'ver_empresa', 'editar_empresa', 'parque', 'terminais', 'logs_cliente',
                'excluir_terminal', 'excluir_terminais_empresa', 'mudanca_contrato',
                // COBRANCA E ASSUNTO DO CLIENTE (10/09/2026, tarde): o grupo
                // proprio saiu; Cobrancas mora aqui, depois de Logs, e a
                // assinatura se ve dentro de Cobrancas e da ficha.
                'cobrancas', 'boleto_pdf', 'assinaturas', 'relatorio_financeiro', 'contas_receber',
                // O PDF do contrato de um cliente: abre da ficha, e e assunto dele.
                'contrato_pdf',
                'certificados',
            ),
            'itens' => array(
                // A ordem e a do dia de quem opera: lista, maquinas, sinal, logs, dinheiro.
                array('rota' => 'clientes', 'icone' => 'fa-building', 'texto' => 'Clientes', 'badge' => 'clientes'),
                array('rota' => 'terminais', 'icone' => 'fa-desktop', 'texto' => 'Terminais'),
                array('rota' => 'parque', 'icone' => 'fa-broadcast-tower', 'texto' => 'Monitoramento'),
                array('rota' => 'logs_cliente', 'icone' => 'fa-headset', 'texto' => 'Logs do cliente'),
                // OS CERTIFICADOS TEM ITEM PROPRIO (19/10/2026, pedido de membro): so
                // estavam no bloco da Central e num filtro de Clientes que ninguem
                // achava. O badge conta vencidos e os que vencem em 30 dias, que e o
                // recorte em que a tela abre.
                array('rota' => 'certificados', 'icone' => 'fa-key', 'texto' => 'Certificados digitais', 'badge' => 'certificados'),
                array('rota' => 'cobrancas', 'icone' => 'fa-money-bill-wave', 'texto' => 'Cobran&ccedil;as', 'badge' => 'cobrancas'),
                // O RELATORIO VEM DEPOIS DE COBRANCAS (01/10/2026): continua sendo o
                // dinheiro no fim da ordem do dia; olhar o periodo e o passo seguinte
                // a cobrar.
                array('rota' => 'relatorio_financeiro', 'icone' => 'fa-calendar-day', 'texto' => 'Relat&oacute;rio do per&iacute;odo'),
                // QUEM DEVE, POR CLIENTE (06/10/2026): a pergunta de quem vai pegar o
                // telefone, sem periodo. O relatorio e fatura por fatura, com datas.
                array('rota' => 'contas_receber', 'icone' => 'fa-calendar', 'texto' => 'Contas a receber'),
            ),
        ),
        // CONFIGURACOES TEM DOIS SUBTITULOS: o que fala com o ERP e o que
        // fala com o dinheiro. A legenda mora no primeiro item de cada bloco.
        'config' => array(
            'rotulo' => 'Configura&ccedil;&otilde;es',
            'icone' => 'fa-cogs',
            'rotas' => array(
                'emissor_licenca', 'licenca_arquivo', 'atualizacao',
                // Limpeza de cadastros e tela de cliente (modules/clientes/
                // limpeza.php), mas e ajuste de uma vez: mora aqui, no bloco ERP.
                'limpeza_cadastros',
                'modulos',
                // PLANOS VOLTARAM AO MENU (17/09/2026), logo abaixo de Modulos. Tinham
                // saido em 10/09 "porque ha link vivo", e os links sairam no mesmo dia:
                // a tela ficou sendo o unico jeito de criar o pre-pago de "Cobrar por",
                // e so abria digitando o endereco.
                'listar_planos', 'adicionar_plano', 'editar_plano', 'excluir_plano',
                'formas_recebimento', 'regua', 'contrato_modelo',
                // A volta do OAuth do Conta Azul so redireciona para Formas de
                // recebimento; mora no mesmo grupo para a lateral nao se perder.
                'contaazul_retorno',
            ),
            'itens' => array(
                array('rota' => 'licenca_arquivo', 'icone' => 'fa-file-signature', 'texto' => 'Licen&ccedil;a em arquivo', 'legenda' => 'Configura&ccedil;&atilde;o ERP'),                array('rota' => 'emissor_licenca', 'icone' => 'fa-shield-alt', 'texto' => 'Chaves'),
                array('rota' => 'atualizacao', 'icone' => 'fa-file-download', 'texto' => 'Atualiza&ccedil;&atilde;o'),
                array('rota' => 'limpeza_cadastros', 'icone' => 'fa-broom', 'texto' => 'Limpeza de cadastros'),
                // fa-layer-group: o subconjunto de icones (public/css/icones.css)
                // nao tem fa-puzzle-piece, e classe sem icone desenha nada.
                array('rota' => 'modulos', 'icone' => 'fa-layer-group', 'texto' => 'M&oacute;dulos', 'legenda' => 'Configura&ccedil;&atilde;o Pagamento'),
                array('rota' => 'listar_planos', 'icone' => 'fa-calendar-alt', 'texto' => 'Planos'),
                array('rota' => 'formas_recebimento', 'icone' => 'fa-credit-card', 'texto' => 'Formas de recebimento'),
                array('rota' => 'regua', 'icone' => 'fa-sliders-h', 'texto' => 'R&eacute;gua de cobran&ccedil;a'),
                // Por ultimo no bloco de pagamento: o que se combina com o cliente,
                // escrito uma vez (01/10/2026).
                array('rota' => 'contrato_modelo', 'icone' => 'fa-edit', 'texto' => 'Modelo de contrato'),
            ),
        ),
    );
}

/**
 * Para onde o item leva. COM numero no badge, ao recorte que o numero conta;
 * sem, a lista inteira. "Voce clica num numero e cai numa lista com outro"
 * era a primeira frase do estudo.
 */
function shield_lateral_destino($qual, $n)
{
    $n = (int) $n;
    // CLIENTES ABRE TUDO (10/09/2026, tarde): o dono do produto quer a lista
    // inteira com a situacao em cada linha, e nao o recorte "vencidas". O
    // numero no badge continua sendo o das vencidas; a faixa na tela leva la.
    if ($qual === 'clientes') {
        return '/clientes.php';
    }
    if ($qual === 'cobrancas') {
        return $n > 0 ? '/cobrancas.php?situacao=abertas' : '/cobrancas.php';
    }

    // Em avaliacao: a tela JA E o recorte que o numero conta.
    return '/' . (string) $qual . '.php';
}

/**
 * O SQL de cada contagem. O MESMO recorte que o destino mostra: clientes com
 * validade_licenca < hoje (o filtro "vencido" de clientes.php) e cobrancas em
 * aberto no sentido da tela (aberta, vencida E rascunho -- o badge contava
 * so duas).
 */
function shield_lateral_sql_contagem($qual)
{
    if ($qual === 'clientes') {
        return "SELECT COUNT(*) FROM empresa WHERE validade_licenca IS NOT NULL AND validade_licenca < CURDATE()";
    }
    if ($qual === 'cobrancas') {
        $lista = implode("', '", array_map('addslashes', shield_cobranca_situacoes_em_aberto()));

        return "SELECT COUNT(*) FROM cobranca WHERE situacao IN ('" . $lista . "')";
    }
    if ($qual === 'avaliacao') {
        // A regra da fila, e nao uma copia dela (17/09/2026).
        return 'SELECT COUNT(*) FROM empresa WHERE ' . shield_situacao_onde_avaliacao();
    }
    if ($qual === 'certificados') {
        return 'SELECT COUNT(*) FROM empresa WHERE ' . shield_certificado_onde_vencendo(30);
    }
    if ($qual === 'prazo') {
        // CLIENTES, e nao cobrancas: a tela agrupa por cliente e o pedido e um por
        // cliente -- tres faturas abertas do mesmo cliente sao um pedido so. A
        // mesma conta de shield_cobranca_pedem_prazo_contar, que a tela usa.
        return 'SELECT COUNT(DISTINCT c.fk_empresa) FROM cobranca c WHERE ' . shield_cobranca_onde_pede_prazo('c');
    }

    return 'SELECT 0';
}

/**
 * O numero e o destino que um item mostra -- 01/10/2026.
 *
 * O PEDIDO DE PRAZO TOMA O LUGAR DO NUMERO DE COBRANCAS enquanto houver um
 * esperando resposta, em vez de um segundo badge no mesmo item: o item e um link
 * so, e dois numeros nele levariam a um destino que conta so um deles -- a
 * primeira frase do estudo de reorganizacao. Sem pedido, tudo como antes.
 * Devolve array(numero, destino, tipo); tipo 'prazo' muda a cor e a frase.
 */
function shield_lateral_badge_do_item(array $item, array $contagens)
{
    $chave = (string) ($item['badge'] ?? '');
    if ($chave === '') {
        return array(0, null, '');
    }

    if ($chave === 'cobrancas' && (int) ($contagens['prazo'] ?? 0) > 0) {
        return array((int) $contagens['prazo'], '/cobrancas.php?situacao=prazo', 'prazo');
    }

    $n = (int) ($contagens[$chave] ?? 0);

    return array($n, shield_lateral_destino($chave, $n), '');
}

/** As contagens dos badges. Badge e aviso, nunca condicao para desenhar: base antiga sem tabela mostra zero. */
function shield_lateral_contagens(PDO $pdo)
{
    $c = array();
    foreach (array('avaliacao', 'clientes', 'cobrancas', 'prazo', 'certificados') as $qual) {
        try {
            $c[$qual] = max(0, (int) $pdo->query(shield_lateral_sql_contagem($qual))->fetchColumn());
        } catch (Throwable $ignorado) {
            $c[$qual] = 0;
        }
    }

    return $c;
}
