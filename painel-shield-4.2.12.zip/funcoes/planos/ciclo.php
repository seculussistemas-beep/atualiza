<?php

/**
 * Os ciclos que um plano pode ter -- 09/09/2026.
 *
 * Quatro dos 43 do levantamento pediram anual, semestral e trimestral. O
 * motor ja sabia (assinatura.ciclo_meses, cobranca.meses); o que travava era
 * a TELA: a assinatura vinha pregada em "1" por JavaScript e por PHP, e o
 * pre-pago parava em 24 meses -- plano de tres anos nao existia pela
 * interface.
 *
 * A LISTA MORA AQUI E SO AQUI. O select da tela, a validacao do POST e o
 * rotulo da cobranca leem a mesma funcao; ter tres copias e como a tela
 * oferece o que o POST recusa.
 *
 * ASSINATURA SO NOS QUATRO CICLOS COM NOME. "Assinatura a cada 5 meses" nao
 * e produto que alguem vende; e o pre-pago que aceita qualquer prazo, porque
 * la o cliente paga uma vez e pronto.
 */

/** Teto do pre-pago, em meses. Tres anos foi o maior prazo que apareceu no levantamento. */
const SHIELD_PLANO_PREPAGO_MAX_MESES = 36;

/** [meses => rotulo], na ordem em que a tela mostra. */
function shield_plano_ciclos($tipo)
{
    if ((string) $tipo === 'assinatura') {
        return array(1 => 'mensal', 3 => 'trimestral', 6 => 'semestral', 12 => 'anual');
    }

    $ciclos = array();
    for ($m = 1; $m <= SHIELD_PLANO_PREPAGO_MAX_MESES; $m++) {
        $ciclos[$m] = shield_plano_ciclo_rotulo($m);
    }

    return $ciclos;
}

/** O motivo da recusa, ou null quando a recorrencia cabe no tipo. */
function shield_plano_recorrencia_recusa($tipo, $recorrencia)
{
    $texto = trim((string) $recorrencia);
    if ($texto === '' || !ctype_digit($texto) || (int) $texto <= 0) {
        return 'Informe a recorrencia em meses.';
    }

    $meses = (int) $texto;
    $ciclos = shield_plano_ciclos($tipo);
    if (isset($ciclos[$meses])) {
        return null;
    }

    if ((string) $tipo === 'assinatura') {
        return 'Assinatura e mensal, trimestral, semestral ou anual. Para outro prazo, crie um plano pre-pago.';
    }

    return 'Pre-pago vai de 1 a ' . SHIELD_PLANO_PREPAGO_MAX_MESES . ' meses.';
}

/** "mensal", "anual"... e, fora dos nomes, "a cada N meses". */
function shield_plano_ciclo_rotulo($meses)
{
    $meses = max(1, (int) $meses);
    $nomes = array(1 => 'mensal', 3 => 'trimestral', 6 => 'semestral', 12 => 'anual');

    return $nomes[$meses] ?? ('a cada ' . $meses . ' meses');
}
