<?php

/**
 * Criar um plano -- 08/10/2026.
 *
 * PLANO NOVO E SEMPRE UM PLANO NOVO. Ate esta data o formulario tratava o mesmo
 * tipo com a mesma duracao como "o mesmo plano" e ATUALIZAVA o que existia: o
 * membro que vende dois mensais (Basico e Completo) criava o segundo e via o
 * primeiro sumir, com "Plano gravado" na tela. Nada no painel depende de um
 * plano por duracao -- toda escolha de plano e pelo id, e as listas de escolha
 * mostram o nome. Mudar um plano que existe e o Editar da linha.
 *
 * O NOME E OBRIGATORIO E NAO SE REPETE NO MESMO TIPO: e ele que separa dois
 * planos de mesma duracao em "Cobrar por" e na assinatura. Comparado sem caixa e
 * sem espaco nas pontas, como a pessoa le.
 *
 * Devolve 'ok', 'sem_nome' ou 'nome_repetido'. Valor e recorrencia chegam ja
 * conferidos pela tela (teto, ciclo do tipo, numero).
 */
function shield_plano_criar(PDO $pdo, string $tipo, string $descricao, string $recorrencia, string $valor): string
{
    $descricao = trim($descricao);
    if ($descricao === '') {
        return 'sem_nome';
    }
    if (shield_plano_nome_repetido($pdo, $tipo, $descricao)) {
        return 'nome_repetido';
    }

    $pdo->prepare("INSERT INTO planos (tipo, descricao, recorrencia, valor, status) VALUES (?, ?, ?, ?, '')")
        ->execute(array($tipo, $descricao, $recorrencia, $valor));

    return 'ok';
}

/** Outro plano do mesmo tipo ja usa este nome? $exceto e o proprio plano, no Editar. */
function shield_plano_nome_repetido(PDO $pdo, string $tipo, string $descricao, int $exceto = 0): bool
{
    $st = $pdo->prepare('SELECT id FROM planos WHERE tipo = ? AND LOWER(TRIM(descricao)) = LOWER(?) AND id <> ? LIMIT 1');
    $st->execute(array($tipo, trim($descricao), $exceto));

    return $st->fetchColumn() !== false;
}

/**
 * Editar um plano -- 08/10/2026. Mesma regra do criar: a duracao pode repetir a
 * de outro plano (o Editar recusava, por uma lista de "duracoes ocupadas" que
 * nunca chegava a ser montada no POST e so imprimia avisos antes do
 * redirecionamento); o nome nao se repete no mesmo tipo. O TIPO NAO MUDA: e o que
 * esta gravado, nao o que veio no formulario. O ciclo que o plano ja tem passa
 * mesmo fora da lista de hoje (assinatura antiga "a cada 4 meses" continua
 * editavel no nome e no valor).
 *
 * Devolve 'ok', 'nao_existe', 'sem_nome', 'nome_repetido' ou 'ciclo'.
 */
function shield_plano_editar(PDO $pdo, int $id, string $descricao, string $recorrencia, string $valor): string
{
    require_once __DIR__ . '/ciclo.php';

    $st = $pdo->prepare('SELECT tipo, recorrencia FROM planos WHERE id = ?');
    $st->execute(array($id));
    $atual = $st->fetch(PDO::FETCH_ASSOC);
    if (!$atual) {
        return 'nao_existe';
    }
    $tipo = (string) $atual['tipo'] === 'assinatura' ? 'assinatura' : 'avulso';

    $descricao = trim($descricao);
    if ($descricao === '') {
        return 'sem_nome';
    }
    if ((string) $atual['recorrencia'] !== $recorrencia && shield_plano_recorrencia_recusa($tipo, $recorrencia) !== null) {
        return 'ciclo';
    }
    if (shield_plano_nome_repetido($pdo, $tipo, $descricao, $id)) {
        return 'nome_repetido';
    }

    $pdo->prepare('UPDATE planos SET descricao = ?, recorrencia = ?, valor = ? WHERE id = ?')
        ->execute(array(substr($descricao, 0, 80), $recorrencia, $valor, $id));

    return 'ok';
}
