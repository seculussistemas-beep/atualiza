<?php

// Telemetria do parque - 25/08/2026.
//
// Quem grava e o endpoint de licenca, uma linha por batida. Quem le e a tela
// Parque e os avisos do painel.
//
// REGRA DURA: NADA AQUI PODE LEVANTAR EXCECAO PARA O ENDPOINT DE LICENCA.
// Telemetria e informacao; licenca e o caixa da loja do cliente do membro
// abrindo. Falhando a gravacao -- tabela ainda nao migrada, disco cheio,
// coluna diferente --, a batida se perde e a licenca sai assim mesmo. O
// inverso seria trocar o caixa parado por um numero bonito na tela.

// Sem sinal por mais que isto e terminal SUMIDO. Duas batidas de 18 h cabem em
// um dia e meio; tres dias perdoa fim de semana, feriado e maquina desligada
// por manutencao, e ainda acusa a loja que parou na segunda.
const SHIELD_PARQUE_DIAS_SUMIDO = 3;

// Ate aqui guarda-se linha por batida. Depois, uma linha por terminal por dia.
const SHIELD_PARQUE_DIAS_DETALHE = 90;

// A compactacao roda no maximo uma vez por dia, disparada por quem abrir o
// painel: nao ha cron garantido na hospedagem do membro.
const SHIELD_PARQUE_CHAVE_COMPACTACAO = 'parque_compactado_em';

// A BATIDA QUE VIROU LICENCA EM DIA -- 14/09/2026. E a palavra que o endpoint
// grava quando o status sai 'ativa' (public/api/licenca.php); qualquer outra
// (excedente, bloqueada, sem_validade, identidade, erro...) conta como recusa,
// que e o que a lista de recusados do Parque ja fazia. Mora num lugar so porque
// a Central contava aceita por 'ok', palavra que nunca foi gravada: com um caixa
// trabalhando, o cartao dizia "0 aceitas, 1 recusadas".
const SHIELD_PARQUE_BATIDA_ACEITA = 'assinada';

function shield_parque_tabela_existe(PDO $pdo)
{
    try {
        if (function_exists('shield_table_exists')) {
            return shield_table_exists($pdo, 'terminal_batida');
        }
        $pdo->query('SELECT 1 FROM terminal_batida LIMIT 1');

        return true;
    } catch (Throwable $ignorado) {
        return false;
    }
}

/**
 * Grava a batida. Devolve true/false so para quem quiser saber -- ninguem no
 * caminho da licenca olha, e e assim de proposito.
 */
function shield_parque_registrar(PDO $pdo, array $dados)
{
    try {
        // O IP so entra se a coluna ja veio pelo /update -- 09/09/2026.
        // Codigo novo chega antes da migracao rodar, e nesse intervalo um
        // INSERT com a coluna nova falharia calado: o painel pararia de gravar
        // telemetria e ninguem descobriria, porque esta funcao engole a propria
        // falha de proposito. Ver o teto em funcoes/licenca/teto_api.php.
        //
        // A DESCOBERTA E POR TENTATIVA, e nao perguntando ao INFORMATION_SCHEMA:
        // esta funcao roda a cada abertura de caixa do parque inteiro, e
        // consulta de catalogo ali custa mais do que o recurso vale. Quem ja
        // atualizou acerta na primeira e nunca paga nada; quem nao atualizou
        // erra UMA vez por processo e passa a gravar como antes.
        static $temIp = true;

        $valores = array(
            ':emp' => ($dados['empresa'] ?? null) ? (int) $dados['empresa'] : null,
            ':ter' => ($dados['terminal'] ?? null) ? (int) $dados['terminal'] : null,
            ':cnpj' => substr((string) ($dados['cnpj'] ?? ''), 0, 20),
            ':fp' => substr((string) ($dados['fingerprint'] ?? ''), 0, 64),
            ':nome' => substr((string) ($dados['nome'] ?? ''), 0, 50),
            ':ver' => substr((string) ($dados['versao'] ?? ''), 0, 20),
            ':res' => substr((string) ($dados['resultado'] ?? 'desconhecido'), 0, 20),
            ':mot' => substr((string) ($dados['motivo'] ?? ''), 0, 150),
        );

        try {
            if (!$temIp) {
                throw new RuntimeException('sem coluna ip');
            }

            // O :ip entra no MESMO array, e nao por bindValue: execute() com
            // array descarta tudo o que foi ligado antes.
            $comIp = $valores;
            $comIp[':ip'] = substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);

            $pdo->prepare(
                'INSERT INTO terminal_batida
                    (fk_empresa, fk_terminal, cnpj, ip, fingerprint, nome_computador,
                     versao_exe, resultado, motivo, batido_em, dia, quantas)
                 VALUES (:emp, :ter, :cnpj, :ip, :fp, :nome, :ver, :res, :mot, NOW(), CURDATE(), 1)'
            )->execute($comIp);

            return true;
        } catch (Throwable $semColuna) {
            // Uma vez por processo, e nunca mais: instalacao com o /update
            // pendente volta a gravar como sempre gravou.
            $temIp = false;
        }

        $pdo->prepare(
            'INSERT INTO terminal_batida
                (fk_empresa, fk_terminal, cnpj, fingerprint, nome_computador,
                 versao_exe, resultado, motivo, batido_em, dia, quantas)
             VALUES (:emp, :ter, :cnpj, :fp, :nome, :ver, :res, :mot, NOW(), CURDATE(), 1)'
        )->execute($valores);

        return true;
    } catch (Throwable $e) {
        // Nem error_log com detalhe: quem chama e endpoint publico e de alto
        // volume, e log por batida enche o disco antes da tabela.
        return false;
    }
}

/**
 * Junta as batidas antigas: uma linha por terminal por dia, com QUANTAS
 * dizendo quantas foram. Entrou junto com a tabela, e nao depois, porque
 * historico sem poda cresce ate a hospedagem reclamar -- e ai ja e tarde.
 *
 * Roda no maximo uma vez por dia. Nao ha cron garantido, entao quem dispara e
 * quem abre o painel; o custo cai sobre uma requisicao por dia, nao sobre a
 * do caixa.
 */
function shield_parque_compactar(PDO $pdo, $forcar = false)
{
    if (!shield_parque_tabela_existe($pdo)) {
        return 0;
    }

    try {
        if (!$forcar) {
            $ultima = (string) shield_get_system_meta($pdo, SHIELD_PARQUE_CHAVE_COMPACTACAO, '');
            if ($ultima !== '' && substr($ultima, 0, 10) === date('Y-m-d')) {
                return 0;
            }
        }

        // O resultado entra na chave: dia em que o terminal assinou 40 vezes e
        // foi recusado 2 nao pode virar uma linha so, senao a recusa some --
        // que e exatamente o que se quer enxergar.
        $limite = date('Y-m-d', strtotime('-' . SHIELD_PARQUE_DIAS_DETALHE . ' days'));

        $pdo->beginTransaction();

        $pdo->prepare(
            'CREATE TEMPORARY TABLE tmp_batida_resumo AS
             SELECT MIN(id) AS id_fica, fk_terminal, dia, resultado,
                    COUNT(*) AS quantas, MAX(batido_em) AS ultima,
                    SUM(quantas) AS soma
               FROM terminal_batida
              WHERE dia < :limite
              GROUP BY fk_terminal, dia, resultado
             HAVING COUNT(*) > 1'
        )->execute(array(':limite' => $limite));

        $pdo->exec(
            'UPDATE terminal_batida b
               JOIN tmp_batida_resumo r ON r.id_fica = b.id
                SET b.quantas = r.soma, b.batido_em = r.ultima'
        );

        $apagadas = $pdo->exec(
            'DELETE b FROM terminal_batida b
               JOIN tmp_batida_resumo r
                 ON r.fk_terminal <=> b.fk_terminal
                AND r.dia = b.dia
                AND r.resultado = b.resultado
              WHERE b.id <> r.id_fica'
        );

        $pdo->exec('DROP TEMPORARY TABLE IF EXISTS tmp_batida_resumo');
        $pdo->commit();

        shield_set_system_meta($pdo, SHIELD_PARQUE_CHAVE_COMPACTACAO, date('Y-m-d H:i:s'));

        return (int) $apagadas;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        return 0;
    }
}

// ------------------------------------------------------------- consultas ---

/**
 * O parque inteiro, uma linha por terminal. E a consulta que a tela Parque e
 * os avisos usam -- as duas leem daqui para nao divergirem: aviso que conta
 * diferente da tela que ele abre e o defeito que a Central de Notificacoes do
 * ERP ja pagou.
 */
function shield_parque_terminais(PDO $pdo, array $filtro = array())
{
    $onde = array();
    $params = array();

    // O canal de comandos entrou depois da telemetria. Bases que ainda nao
    // receberam essa migracao continuam abrindo o parque; nas atualizadas, a
    // ficha do cliente passa a saber que o log ja foi solicitado.
    $camposComando = ', NULL AS log_pedido_de, NULL AS log_pedido_ate, NULL AS log_pedido_em';
    try {
        if (function_exists('shield_column_exists')
            && shield_column_exists($pdo, 'terminais', 'log_pedido_de')) {
            $camposComando = ', t.log_pedido_de, t.log_pedido_ate, t.log_pedido_em';
        }
    } catch (Throwable $ignorado) {
        // Telemetria nao pode tirar o painel do ar por uma base intermediaria.
    }

    if (!empty($filtro['empresa'])) {
        $onde[] = 't.FK_EMPRESA = :emp';
        $params[':emp'] = (int) $filtro['empresa'];
    }
    if (!empty($filtro['versao'])) {
        $onde[] = 'COALESCE(t.VERSAO_EXE, :vervazio) = :ver';
        $params[':ver'] = (string) $filtro['versao'];
        $params[':vervazio'] = '';
    }
    $juncaoExcedente = '';
    if (($filtro['situacao'] ?? '') === 'sumido') {
        $onde[] = '(t.ULTIMO_ACESSO IS NULL OR t.ULTIMO_ACESSO < :corte)';
        $params[':corte'] = date('Y-m-d H:i:s', strtotime('-' . SHIELD_PARQUE_DIAS_SUMIDO . ' days'));
    } elseif (($filtro['situacao'] ?? '') === 'vivo') {
        $onde[] = 't.ULTIMO_ACESSO >= :corte';
        $params[':corte'] = date('Y-m-d H:i:s', strtotime('-' . SHIELD_PARQUE_DIAS_SUMIDO . ' days'));
    } elseif (($filtro['situacao'] ?? '') === 'excedente') {
        // O RECORTE QUE A CENTRAL ABRE. O numero "caixas alem do contratado"
        // leva para ca, e ate 11/09/2026 a lista nao conhecia esta palavra: o
        // clique caia no parque inteiro, sem filtro nenhum. A contagem e a
        // MESMA subconsulta do shield_parque_resumo, de proposito -- numero que
        // abre lista com outro numero foi a primeira frase do estudo de
        // reorganizacao. Mostra todas as maquinas do cliente estourado, e nao
        // so as vivas: quem esta acima da cota e o cliente, nao o terminal.
        $juncaoExcedente =
            ' JOIN (SELECT FK_EMPRESA, COUNT(*) vivos FROM terminais
                     WHERE ULTIMO_ACESSO >= :corte
                     GROUP BY FK_EMPRESA) x ON x.FK_EMPRESA = t.FK_EMPRESA';
        $onde[] = 'COALESCE(e.nterminais, 0) > 0 AND x.vivos > e.nterminais';
        $params[':corte'] = date('Y-m-d H:i:s', strtotime('-' . SHIELD_PARQUE_DIAS_SUMIDO . ' days'));
    }

    $sql = 'SELECT t.CODIGO, t.FK_EMPRESA, t.MAC, t.NOME_COMPUTADOR, t.APELIDO, t.FINGERPRINT,
                   t.ULTIMO_ACESSO, t.VERSAO_EXE' . $camposComando . ',
                   e.razao, e.cnpj, e.nterminais, e.validade_licenca, e.bloqueado
              FROM terminais t
              LEFT JOIN empresa e ON e.codigo = t.FK_EMPRESA' . $juncaoExcedente
        . ($onde ? ' WHERE ' . implode(' AND ', $onde) : '')
        . ' ORDER BY (t.ULTIMO_ACESSO IS NULL) DESC, t.ULTIMO_ACESSO ASC';

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
}

/** Os numeros do topo da tela. Contas simples, mas o membro nao as tem hoje. */
function shield_parque_resumo(PDO $pdo, array $filtro = array())
{
    $corte = date('Y-m-d H:i:s', strtotime('-' . SHIELD_PARQUE_DIAS_SUMIDO . ' days'));
    $empresa = (int) ($filtro['empresa'] ?? 0);
    $ondeEmpresa = $empresa > 0 ? ' WHERE FK_EMPRESA = :emp' : '';

    $resumo = array(
        'terminais' => 0,
        'vivos' => 0,
        'sumidos' => 0,
        'empresas_com_terminal' => 0,
        'versoes' => 0,
        'contratados' => 0,
        'excedentes' => 0,
    );

    $stmt = $pdo->prepare(
        'SELECT COUNT(*) total,
                SUM(CASE WHEN ULTIMO_ACESSO >= :corte THEN 1 ELSE 0 END) vivos,
                COUNT(DISTINCT FK_EMPRESA) empresas,
                COUNT(DISTINCT NULLIF(VERSAO_EXE, "")) versoes
           FROM terminais' . $ondeEmpresa
    );
    $paramsResumo = array(':corte' => $corte);
    if ($empresa > 0) {
        $paramsResumo[':emp'] = $empresa;
    }
    $stmt->execute($paramsResumo);
    $linha = $stmt->fetch(PDO::FETCH_ASSOC) ?: array();

    $resumo['terminais'] = (int) ($linha['total'] ?? 0);
    $resumo['vivos'] = (int) ($linha['vivos'] ?? 0);
    $resumo['sumidos'] = $resumo['terminais'] - $resumo['vivos'];
    $resumo['empresas_com_terminal'] = (int) ($linha['empresas'] ?? 0);
    $resumo['versoes'] = (int) ($linha['versoes'] ?? 0);

    // Cliente rodando mais caixa do que contratou. E o unico numero desta tela
    // que e RECEITA e nao suporte -- por isso ele sai separado, e nao como mais
    // uma coluna perdida no meio da lista.
    //
    // SO CONTA QUEM TEM COTA NO CADASTRO (11/09/2026). A conta era
    // GREATEST(vivos - nterminais, 0) para toda empresa, e empresa
    // auto-cadastrada nasce com nterminais nulo: o primeiro ping do ERP numa
    // loja em avaliacao acendia "1 caixa rodando alem do contratado" na
    // Central, visto em producao. A cota do lead e a do TESTE, que de proposito
    // nao passa por nterminais -- e shield_situacao_parque ja dizia isso na
    // lista de clientes ("sem quantidade contratada no cadastro"). Eram duas
    // telas com duas respostas para a mesma pergunta.
    $sqlCotas =
        'SELECT COALESCE(SUM(e.nterminais), 0) contratados,
                COALESCE(SUM(CASE WHEN COALESCE(e.nterminais, 0) > 0
                                  THEN GREATEST(COALESCE(v.vivos, 0) - e.nterminais, 0)
                                  ELSE 0 END), 0) excedentes
           FROM empresa e
      LEFT JOIN (SELECT FK_EMPRESA, COUNT(*) vivos FROM terminais
                  WHERE ULTIMO_ACESSO >= DATE_SUB(NOW(), INTERVAL '
        . SHIELD_PARQUE_DIAS_SUMIDO . ' DAY)
                  GROUP BY FK_EMPRESA) v ON v.FK_EMPRESA = e.codigo'
        . ($empresa > 0 ? ' WHERE e.codigo = :emp' : '');
    $stmt = $pdo->prepare($sqlCotas);
    $stmt->execute($empresa > 0 ? array(':emp' => $empresa) : array());
    $linha = $stmt->fetch(PDO::FETCH_ASSOC) ?: array();
    $resumo['contratados'] = (int) ($linha['contratados'] ?? 0);
    $resumo['excedentes'] = (int) ($linha['excedentes'] ?? 0);

    return $resumo;
}

/** Quantos terminais em cada versao do ERP. Responde "quem nunca atualiza". */
function shield_parque_versoes(PDO $pdo, array $filtro = array())
{
    $empresa = (int) ($filtro['empresa'] ?? 0);
    $stmt = $pdo->prepare(
        'SELECT COALESCE(NULLIF(TRIM(VERSAO_EXE), ""), "(nao informada)") versao,
                COUNT(*) terminais,
                MAX(ULTIMO_ACESSO) visto
           FROM terminais
          ' . ($empresa > 0 ? 'WHERE FK_EMPRESA = :emp ' : '') . '
          GROUP BY COALESCE(NULLIF(TRIM(VERSAO_EXE), ""), "(nao informada)")
          ORDER BY terminais DESC, versao DESC'
    );
    $stmt->execute($empresa > 0 ? array(':emp' => $empresa) : array());

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
}

/**
 * Pedidos que NAO viraram licenca. Hoje isto so existe no error_log do
 * servidor, que o membro nao le e boa parte das hospedagens nem entrega.
 */
function shield_parque_recusas(PDO $pdo, $dias = 7, $limite = 50, $empresa = 0)
{
    if (!shield_parque_tabela_existe($pdo)) {
        return array();
    }

    $stmt = $pdo->prepare(
        'SELECT b.batido_em, b.cnpj, b.nome_computador, b.resultado, b.motivo,
                b.versao_exe, b.quantas, e.razao
           FROM terminal_batida b
           LEFT JOIN empresa e ON e.codigo = b.fk_empresa
          WHERE b.resultado <> :aceita
            AND b.batido_em >= :corte
            ' . ((int) $empresa > 0 ? 'AND b.fk_empresa = :empresa ' : '') . '
          ORDER BY b.batido_em DESC
          LIMIT ' . max(1, min(200, (int) $limite))
    );
    $params = array(
        ':aceita' => SHIELD_PARQUE_BATIDA_ACEITA,
        ':corte' => date('Y-m-d H:i:s', strtotime('-' . (int) $dias . ' days')),
    );
    if ((int) $empresa > 0) {
        $params[':empresa'] = (int) $empresa;
    }
    $stmt->execute($params);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
}

/**
 * Ha quanto tempo esta maquina nao da sinal, em palavra de gente.
 *
 * Nasceu dentro da tela do Parque e veio para ca quando a Abertura passou a
 * precisar dela: ajudante usado por duas telas nao mora dentro de uma delas --
 * a segunda copia diverge da primeira e ninguem percebe.
 */
function shield_parque_ha_quanto($quando)
{
    $quando = trim((string) $quando);
    if ($quando === '') {
        return 'nunca deu sinal';
    }

    // COM ACENTO, e nao "ha": isto e texto de TELA, e a regra do projeto de
    // escrever sem acento vale para codigo e comentario. O valor sai daqui e vai
    // direto para a coluna "Ultimo sinal" de tres telas.
    $seg = time() - strtotime($quando);
    if ($seg < 3600) {
        return 'há ' . max(1, (int) round($seg / 60)) . ' min';
    }
    if ($seg < 86400) {
        return 'há ' . (int) round($seg / 3600) . ' h';
    }

    return 'há ' . (int) floor($seg / 86400) . ' dia(s)';
}

/**
 * O rotulo de um terminal: o APELIDO que o membro deu, ou o nome de fabrica --
 * 09/09/2026.
 *
 * "DESKTOP-4F2K9" nao diz nada a quem esta com o telefone na mao; "Caixa 2"
 * diz. O apelido nasceu na tela de terminais e ficou so la: ficha do cliente,
 * logs, licenca por arquivo e busca seguiam com o nome de fabrica. UMA funcao
 * decide, para as telas nao divergirem.
 *
 * Aceita as duas caixas de coluna, porque cada consulta veio de uma epoca:
 * NOME_COMPUTADOR na maioria, nome_computador na tela de terminais.
 */
function shield_terminal_rotulo(array $t)
{
    $apelido = trim((string) ($t['APELIDO'] ?? $t['apelido'] ?? ''));
    if ($apelido !== '') {
        return $apelido;
    }

    return trim((string) ($t['NOME_COMPUTADOR'] ?? $t['nome_computador'] ?? ''));
}

/**
 * O nome de fabrica para mostrar ATRAS do apelido -- vazio quando o apelido
 * nao esconde nada. A identidade da maquina nao pode sumir: e por ela que o
 * suporte confere "e essa mesma?" olhando o Windows do cliente.
 */
function shield_terminal_maquina_atras(array $t)
{
    $apelido = trim((string) ($t['APELIDO'] ?? $t['apelido'] ?? ''));
    if ($apelido === '') {
        return '';
    }

    return trim((string) ($t['NOME_COMPUTADOR'] ?? $t['nome_computador'] ?? ''));
}

/**
 * A busca do topo, lado dos terminais: apelido, nome de fabrica ou MAC.
 *
 * Saiu do ajax para ca para poder ser provada (tests/Integracao/BuscaTerminalTest).
 * Vazio devolve vazio -- LIKE '%%' varreria o parque inteiro a cada tecla.
 */
function shield_parque_buscar_terminais(PDO $pdo, $q, $limite = 5)
{
    $q = trim((string) $q);
    if ($q === '') {
        return array();
    }
    $like = '%' . $q . '%';

    $stmt = $pdo->prepare(
        'SELECT t.CODIGO, t.NOME_COMPUTADOR, t.APELIDO, t.MAC, t.ULTIMO_ACESSO, t.FK_EMPRESA, e.razao
           FROM terminais t
           LEFT JOIN empresa e ON e.codigo = t.FK_EMPRESA
          WHERE t.APELIDO LIKE :a OR t.NOME_COMPUTADOR LIKE :q OR t.MAC LIKE :mac
          ORDER BY t.ULTIMO_ACESSO DESC
          LIMIT ' . max(1, (int) $limite)
    );
    $stmt->execute(array(':a' => $like, ':q' => $like, ':mac' => $like));

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
}

/**
 * Caixas VIVOS por cliente -- 10/09/2026, fatia 1 da reorganizacao.
 *
 * "Um lugar de contar": a lista de clientes tinha um SQL, a ficha tinha um
 * laco PHP, e as duas podiam discordar sobre o mesmo cliente. Uma pergunta,
 * uma resposta. Devolve codigo => vivos, so para quem tem algum; lista vazia
 * devolve vazio em vez de varrer o parque.
 *
 * O corte e o da TELA (SHIELD_PARQUE_DIAS_SUMIDO, tres dias), nao o da cota
 * (trinta): ver "os dois cortes de tempo" no estudo.
 */
function shield_parque_vivos_por_empresa(PDO $pdo, array $codigos)
{
    $limpos = array();
    foreach ($codigos as $c) {
        if ((int) $c > 0) {
            $limpos[] = (int) $c;
        }
    }
    if (!$limpos) {
        return array();
    }

    $stmt = $pdo->prepare(
        'SELECT FK_EMPRESA, COUNT(*) AS vivos FROM terminais
          WHERE FK_EMPRESA IN (' . implode(',', array_unique($limpos)) . ') AND ULTIMO_ACESSO >= :corte
          GROUP BY FK_EMPRESA'
    );
    $stmt->execute(array(':corte' => date('Y-m-d H:i:s', strtotime('-' . SHIELD_PARQUE_DIAS_SUMIDO . ' days'))));

    $mapa = array();
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $l) {
        $mapa[(int) $l['FK_EMPRESA']] = (int) $l['vivos'];
    }

    return $mapa;
}

/**
 * Quando cada cliente deu sinal pela ultima vez (o caixa mais recente) --
 * 10/09/2026, fatia 2 da reorganizacao. Devolve codigo => datetime, so
 * para quem ja deu sinal alguma vez; lista vazia devolve vazio.
 */
function shield_parque_ultimo_sinal_por_empresa(PDO $pdo, array $codigos)
{
    $limpos = array();
    foreach ($codigos as $c) {
        if ((int) $c > 0) {
            $limpos[] = (int) $c;
        }
    }
    if (!$limpos) {
        return array();
    }

    $stmt = $pdo->query(
        'SELECT FK_EMPRESA, MAX(ULTIMO_ACESSO) AS ultimo FROM terminais
          WHERE FK_EMPRESA IN (' . implode(',', array_unique($limpos)) . ') AND ULTIMO_ACESSO IS NOT NULL
          GROUP BY FK_EMPRESA'
    );

    $mapa = array();
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $l) {
        $mapa[(int) $l['FK_EMPRESA']] = (string) $l['ultimo'];
    }

    return $mapa;
}

/**
 * Quantas maquinas CADASTRADAS cada cliente tem (vivas ou nao) -- fatia 9 da
 * reorganizacao, 10/09/2026. A lista de clientes e a fila de avaliacao
 * escreviam cada uma a sua subconsulta. Devolve codigo => total, so para
 * quem tem alguma; lista vazia devolve vazio.
 */
function shield_parque_cadastradas_por_empresa(PDO $pdo, array $codigos)
{
    $limpos = array();
    foreach ($codigos as $c) {
        if ((int) $c > 0) {
            $limpos[] = (int) $c;
        }
    }
    if (!$limpos) {
        return array();
    }

    $stmt = $pdo->query(
        'SELECT FK_EMPRESA, COUNT(*) AS total FROM terminais
          WHERE FK_EMPRESA IN (' . implode(',', array_unique($limpos)) . ')
          GROUP BY FK_EMPRESA'
    );

    $mapa = array();
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $l) {
        $mapa[(int) $l['FK_EMPRESA']] = (int) $l['total'];
    }

    return $mapa;
}

// A RECUSA QUE ABRE A TROCA DE COMPUTADOR -- 14/09/2026. Por quantos dias uma
// recusa por cota cheia ainda justifica liberar a vaga de uma maquina que esta
// TRABALHANDO. Sete e o mesmo recorte da lista "Pedidos recusados" do Parque
// (modules/clientes/parque.php): a recusa que o membro ve la e a que abre o
// botao na tela de Terminais. A maquina nova que continua de fora renova a
// recusa a cada abertura e a cada hora (4.1.23), entao a semana nunca segura a
// troca de quem esta trocando; ela so apaga a recusa esquecida.
const SHIELD_PARQUE_DIAS_RECUSA_TROCA = 7;

/**
 * As maquinas de cada cliente RECUSADAS POR COTA CHEIA que ainda estao de fora
 * -- 14/09/2026. Devolve codigo da empresa => lista de batidas (a mais recente
 * de cada maquina, da mais nova para a mais velha), com id, fk_empresa,
 * fk_terminal, nome_computador, fingerprint, batido_em e motivo. So entra quem
 * tem alguma; lista vazia devolve vazio em vez de varrer o parque.
 *
 * E a pergunta que desenha o botao "Trocar de computador" na tela de Terminais
 * e que o POST dele refaz (shield_terminal_trocar_computador). Uma funcao so,
 * para o botao e o servidor nunca discordarem sobre o mesmo cliente.
 *
 * TRES CORTES, e cada um tira um "ainda esta de fora" falso:
 *
 *   `excedente` COM MOTIVO "cota cheia". A mesma palavra sai para a maquina
 *   DESATIVADA que volta a bater ("terminal desativado no painel em..."): sem o
 *   motivo, o computador velho que acabou de ser trocado abriria o botao de
 *   novo nas outras maquinas da loja.
 *
 *   DEPOIS DA ULTIMA VAGA LIBERADA A MAO no cliente. Liberada uma vaga, a
 *   recusa de antes ja nao prova falta de vaga; ela so volta a valer quando a
 *   maquina bater e for recusada de novo. Sem isso, duas trocas pela mesma
 *   recusa desligariam dois caixas por um computador novo.
 *
 *   SEM BATIDA POSTERIOR DA MESMA MAQUINA que nao seja recusa por cota. A nova
 *   que ja entrou (pela troca, ou pela vaga que voltou sozinha no 30o dia) nao
 *   abre mais nada. Mesma maquina e mesma impressao; batida sem impressao casa
 *   pelo nome do computador.
 *
 * `bloqueada` NAO CONTA: com a loja bloqueada a batida grava a palavra do
 * bloqueio mesmo com a cota cheia, e trocar computador de loja que nao opera
 * nao destrava nada.
 *
 * AS DATAS SAO DO RELOGIO DO BANCO, e nao do PHP: batido_em e DESATIVADO_EM
 * nascem de NOW(), e as tres pontas da comparacao precisam do mesmo relogio.
 *
 * LEITURA DE TELA. O endpoint de licenca carrega este arquivo e nunca chama
 * esta funcao. A falha vira lista vazia: telemetria nao tira a tela do ar, e
 * sem resposta o servidor recusa a troca -- o erro fica do lado que nao
 * desliga caixa.
 */
function shield_parque_recusas_por_cota(PDO $pdo, array $codigos)
{
    $limpos = array();
    foreach ($codigos as $c) {
        if ((int) $c > 0) {
            $limpos[(int) $c] = (int) $c;
        }
    }
    if (!$limpos || !shield_parque_tabela_existe($pdo)) {
        return array();
    }

    try {
        // A mesma palavra entra com DOIS marcadores de nomes diferentes: com o
        // prepare nativo, marcador nomeado repetido estoura "number of bound
        // variables does not match" (ver shield_terminal_estado_sql). Os
        // codigos entram no IN como inteiros ja limpos, como nas vizinhas.
        $stmt = $pdo->prepare(
            'SELECT b.id, b.fk_empresa, b.fk_terminal, b.nome_computador, b.fingerprint, b.batido_em, b.motivo
               FROM terminal_batida b
              WHERE b.fk_empresa IN (' . implode(',', $limpos) . ')
                AND b.resultado = :excedente
                AND b.motivo LIKE :cota
                AND b.batido_em >= DATE_SUB(NOW(), INTERVAL ' . (int) SHIELD_PARQUE_DIAS_RECUSA_TROCA . ' DAY)
                AND b.batido_em > COALESCE(
                        (SELECT MAX(d.DESATIVADO_EM) FROM terminais d WHERE d.FK_EMPRESA = b.fk_empresa),
                        :nunca)
                AND NOT EXISTS (
                        SELECT 1 FROM terminal_batida p
                         WHERE p.fk_empresa = b.fk_empresa
                           AND p.batido_em > b.batido_em
                           AND NOT (p.resultado = :excedente2 AND COALESCE(p.motivo, \'\') LIKE :cota2)
                           AND (CASE WHEN COALESCE(b.fingerprint, \'\') <> \'\' THEN p.fingerprint = b.fingerprint
                                     ELSE p.nome_computador = b.nome_computador END))
              ORDER BY b.batido_em DESC, b.id DESC'
        );
        $stmt->execute(array(
            ':excedente' => 'excedente',
            ':cota' => 'cota cheia%',
            ':nunca' => '1000-01-01 00:00:00',
            ':excedente2' => 'excedente',
            ':cota2' => 'cota cheia%',
        ));

        // UMA POR MAQUINA: a nova que continua de fora bate a cada hora, e a
        // tela quer saber QUEM esta de fora, nao quantas vezes bateu.
        $mapa = array();
        $vistas = array();
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: array() as $l) {
            $empresa = (int) $l['fk_empresa'];
            $impressao = trim((string) ($l['fingerprint'] ?? ''));
            $maquina = $empresa . '|' . ($impressao !== ''
                ? 'fp:' . $impressao
                : 'nome:' . strtoupper(trim((string) $l['nome_computador'])));
            if (isset($vistas[$maquina])) {
                continue;
            }
            $vistas[$maquina] = true;
            $mapa[$empresa][] = $l;
        }

        return $mapa;
    } catch (Throwable $e) {
        return array();
    }
}

/**
 * As consultas de licenca que deram ERRO nas ultimas horas -- 15/09/2026. Null
 * quando nao houve nenhuma; senao quantas, de quantas lojas, a ultima e o
 * motivo dela.
 *
 * Erro e a excecao da API (500 'interno'), e nao recusa: recusa sai assinada.
 * Com erro o ERP segue com a ultima licenca guardada por ate sete dias e nenhum
 * bloqueio do painel chega a loja -- foi assim que a chave ilegivel de um membro
 * passou dias sem ninguem ver. A Central pergunta aqui.
 */
/** A chave do "Limpar agora": os erros ate este instante ja foram vistos. */
const SHIELD_LICENCA_FALHAS_LIMPO_ATE = 'licenca_falhas_limpo_ate';

/**
 * "LIMPAR AGORA" (16/09/2026): guarda o instante do ultimo erro, e a Central
 * deixa de contar o que veio ate ali. Erro NOVO, depois disso, volta a aparecer
 * -- limpar e dar por visto, nao desligar o aviso.
 */
function shield_licenca_falhas_limpar(PDO $pdo)
{
    $ate = '';
    try {
        $ate = (string) $pdo->query("SELECT MAX(batido_em) FROM terminal_batida WHERE resultado = 'erro'")->fetchColumn();
    } catch (Throwable $semTabela) {
        return;
    }
    if ($ate !== '') {
        shield_set_system_meta($pdo, SHIELD_LICENCA_FALHAS_LIMPO_ATE, $ate);
    }
}

function shield_licenca_falhas_recentes(PDO $pdo, $horas = 24)
{
    $horas = max(1, (int) $horas);
    try {
        // O que ja foi limpo fica fora da janela: o corte e o maior entre as 24 h
        // e o instante gravado pelo "Limpar agora".
        $limpoAte = trim((string) shield_get_system_meta($pdo, SHIELD_LICENCA_FALHAS_LIMPO_ATE, ''));
        $desde = "DATE_SUB(NOW(), INTERVAL :h HOUR)";
        if ($limpoAte !== '') {
            $desde = "GREATEST(DATE_SUB(NOW(), INTERVAL :h HOUR), DATE_ADD(:limpo, INTERVAL 1 SECOND))";
        }
        $comLimpo = static function (array $p) use ($limpoAte) {
            return $limpoAte !== '' ? $p + array(':limpo' => $limpoAte) : $p;
        };

        $stmt = $pdo->prepare(
            "SELECT COUNT(*) AS quantas, COUNT(DISTINCT cnpj) AS lojas, MAX(batido_em) AS ultima_em
               FROM terminal_batida
              WHERE resultado = 'erro' AND batido_em >= $desde"
        );
        $stmt->execute($comLimpo(array(':h' => $horas)));
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($linha) || (int) $linha['quantas'] === 0) {
            return null;
        }

        $ultima = $pdo->prepare(
            "SELECT motivo FROM terminal_batida
              WHERE resultado = 'erro' AND batido_em >= $desde
              ORDER BY batido_em DESC, id DESC LIMIT 1"
        );
        $ultima->execute($comLimpo(array(':h' => $horas)));

        // QUEM AINDA ESTA COM ERRO (16/09/2026): a loja cujo ultimo erro na janela
        // nao foi seguido de consulta aceita. O membro conserta a chave, as lojas
        // voltam a assinar, e sem esta conta a Central ficava vermelha por 24 h
        // dizendo "enquanto der erro" -- a janela e por hora, a frase soava atual.
        $aindaErro = $pdo->prepare(
            "SELECT COUNT(*) FROM (
                SELECT e.cnpj, MAX(e.batido_em) AS ultimo_erro
                  FROM terminal_batida e
                 WHERE e.resultado = 'erro' AND e.batido_em >= $desde
                 GROUP BY e.cnpj) u
              WHERE NOT EXISTS (
                SELECT 1 FROM terminal_batida a
                 WHERE a.cnpj = u.cnpj AND a.resultado = :aceita AND a.batido_em >= u.ultimo_erro)"
        );
        $aindaErro->execute($comLimpo(array(':h' => $horas, ':aceita' => SHIELD_PARQUE_BATIDA_ACEITA)));

        $assinadasDepois = $pdo->prepare(
            "SELECT COUNT(*) FROM terminal_batida a
              WHERE a.resultado = :aceita
                AND a.batido_em >= (SELECT MIN(e.batido_em) FROM terminal_batida e
                                     WHERE e.resultado = 'erro' AND e.batido_em >= $desde)"
        );
        $assinadasDepois->execute($comLimpo(array(':h' => $horas, ':aceita' => SHIELD_PARQUE_BATIDA_ACEITA)));

        return array(
            'quantas' => (int) $linha['quantas'],
            'lojas' => (int) $linha['lojas'],
            'ultima_em' => (string) $linha['ultima_em'],
            'motivo' => (string) $ultima->fetchColumn(),
            'lojas_ainda_com_erro' => (int) $aindaErro->fetchColumn(),
            'assinadas_depois' => (int) $assinadasDepois->fetchColumn(),
        );
    } catch (Throwable $semTabela) {
        return null;
    }
}
