<?php

/**
 * A fila "Em avaliacao" -- 10/09/2026, fatia 6 da reorganizacao
 * (docs/reorganizacao-do-painel.md, secao 5).
 *
 * Quem esta aqui: empresa que o ERP cadastrou sozinho, sem validade, nao
 * encerrada e SEM CONTRATO INICIADO (fechado_em) -- o lead. Iniciado o contrato
 * ele vira cliente e desce para Clientes na hora (11/09/2026), mesmo sem ter
 * pago: quem fechou contrato ja nao esta avaliando nada. O RASCUNHO DO
 * FECHAMENTO NAO CONTA (14/09/2026): ele mora em fechamento_rascunho, nao grava
 * fechado_em, e o lead fica aqui com a marca rascunho_em. Nenhuma contagem
 * mudou, porque todas ja perguntavam por fechado_em. Lead continua sendo "quem nao tem validade", como
 * sempre foi; esta fila e so a tela que o mostra com o que o membro precisa
 * para vender: quantas maquinas apareceram, qual versao, quando bateu pela
 * ultima vez, quantos dias de teste faltam e quantas maquinas estao BATENDO
 * NA PORTA (alem das tres do teste) -- que ja e argumento de venda antes de
 * existir contrato.
 *
 * "Um lugar de contar": a tela desenha o que sai daqui.
 */

require_once __DIR__ . '/teste.php';
require_once __DIR__ . '/parque.php';
require_once __DIR__ . '/../cobranca/composicao.php'; // shield_composicao_batendo_na_porta
require_once __DIR__ . '/../nucleo/data_zerada.php';  // a data zerada em SQL, sem pedir conversao
require_once __DIR__ . '/situacao.php';               // shield_situacao_onde_avaliacao: a regra da fila

/** Quantos leads na fila (para o badge da lateral). Base antiga devolve zero. */
function shield_avaliacao_contar(PDO $pdo)
{
    try {
        return (int) $pdo->query(
            'SELECT COUNT(*) FROM empresa WHERE ' . shield_situacao_onde_avaliacao()
        )->fetchColumn();
    } catch (Throwable $semColuna) {
        return 0;
    }
}

/**
 * A fila, uma linha por lead, com o que a tela mostra. Ordem: quem esta
 * acabando primeiro (menos dias de teste), depois quem apareceu por ultimo.
 *
 * Cada linha: a empresa inteira mais 'maquinas', 'vivos', 'versao',
 * 'ultimo_sinal', 'batendo_na_porta', 'teste_fim' (Y-m-d|null),
 * 'dias_restantes' (int|null; null = venceu ou sem data de onde contar).
 * A empresa inteira ja traz 'rascunho_em' (datetime|null): de quando e o
 * rascunho do fechamento, que a tela marca e troca o link por "Concluir".
 */
function shield_avaliacao_lista(PDO $pdo)
{
    try {
        $stmt = $pdo->query(
            'SELECT e.*,
                    (SELECT t.VERSAO_EXE FROM terminais t WHERE t.FK_EMPRESA = e.codigo
                      ORDER BY t.ULTIMO_ACESSO DESC LIMIT 1) AS versao
               FROM empresa e
              WHERE ' . shield_situacao_onde_avaliacao('e') . '
              ORDER BY e.codigo DESC'
        );
        $leads = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
    } catch (Throwable $semColuna) {
        return array();
    }

    // Um lugar de contar (fatia 9): as mesmas funcoes da lista de clientes.
    $cfg = shield_teste_config($pdo);
    $codigos = array_map(static function ($l) { return (int) $l['codigo']; }, $leads);
    $vivos = shield_parque_vivos_por_empresa($pdo, $codigos);
    $cadastradas = shield_parque_cadastradas_por_empresa($pdo, $codigos);
    $ultimoSinal = shield_parque_ultimo_sinal_por_empresa($pdo, $codigos);

    foreach ($leads as &$l) {
        $codigo = (int) $l['codigo'];
        $l['maquinas'] = (int) ($cadastradas[$codigo] ?? 0);
        $l['ultimo_sinal'] = (string) ($ultimoSinal[$codigo] ?? '');
        $l['vivos'] = (int) ($vivos[$codigo] ?? 0);
        $l['batendo_na_porta'] = shield_composicao_batendo_na_porta($pdo, $codigo);
        $l['teste_fim'] = shield_teste_fim($l, $cfg);
        $l['dias_restantes'] = shield_teste_dias_restantes($l, $cfg);
        $l['teste_terminais'] = shield_teste_terminais_de($l, $cfg);
    }
    unset($l);

    // Quem esta acabando primeiro sobe; teste vencido (null) sobe mais ainda,
    // porque e quem a rotina vai encerrar se ninguem fechar.
    usort($leads, static function ($a, $b) {
        $da = $a['dias_restantes'] === null ? -1 : $a['dias_restantes'];
        $db = $b['dias_restantes'] === null ? -1 : $b['dias_restantes'];
        if ($da !== $db) {
            return $da <=> $db;
        }

        return (int) $b['codigo'] <=> (int) $a['codigo'];
    });

    return $leads;
}

/**
 * Move a data do teste (prorrogar ou encurtar). Devolve false com data
 * ilegivel. Prorrogar E mover a data: sem contador, sem segunda regra.
 */
function shield_avaliacao_prorrogar(PDO $pdo, $codigo, $ate, $ator)
{
    $ate = substr(trim((string) $ate), 0, 10);
    $d = DateTimeImmutable::createFromFormat('!Y-m-d', $ate);
    if (!$d instanceof DateTimeImmutable || $d->format('Y-m-d') !== $ate) {
        return false;
    }

    $stmt = $pdo->prepare('UPDATE empresa SET teste_ate = :d WHERE codigo = :c AND '
        . shield_sql_sem_validade('validade_licenca'));
    $stmt->execute(array(':d' => $ate, ':c' => (int) $codigo));
    if ($stmt->rowCount() <= 0) {
        return false;
    }

    require_once __DIR__ . '/../cobranca/cobranca.php';
    shield_auditar($pdo, 'teste_prorrogado', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => (int) $codigo, 'ator' => (string) $ator,
        'depois' => $ate,
        'detalhe' => 'teste passa a valer ate ' . $d->format('d/m/Y'),
    ));

    return true;
}

/**
 * Os caixas do teste DESTA loja -- 10/09/2026, tarde. Zero devolve a regra
 * geral (a coluna volta a NULL). Vale na hora: o ERP le a cota a cada
 * abertura, sem nada gravado na licenca.
 */
function shield_avaliacao_definir_terminais(PDO $pdo, $codigo, $terminais, $ator)
{
    $n = max(0, min(99, (int) $terminais));
    $stmt = $pdo->prepare('UPDATE empresa SET teste_terminais = :n WHERE codigo = :c AND '
        . shield_sql_sem_validade('validade_licenca'));
    $stmt->execute(array(':n' => $n > 0 ? $n : null, ':c' => (int) $codigo));
    if ($stmt->rowCount() <= 0) {
        return false;
    }

    require_once __DIR__ . '/../cobranca/cobranca.php';
    shield_auditar($pdo, 'avaliacao_terminais', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => (int) $codigo, 'ator' => (string) $ator,
        'depois' => (string) $n,
        'detalhe' => $n > 0 ? 'o teste desta loja passa a liberar ' . $n . ' caixa(s)' : 'o teste desta loja volta a regra geral',
    ));

    return true;
}

/* O "contrato preenchido / emitir a primeira cobranca" que morava aqui saiu em
   11/09/2026, com o fechamento passando a fazer o cliente na hora: quem fechou
   contrato nao esta mais nesta fila, entao o bloco nunca mais desenharia. A
   cobranca em rascunho dele e emitida em Cobrancas, como a de qualquer cliente.
   O rascunho do fechamento (14/09/2026) voltou a ficar na fila, mas sem cobranca
   nenhuma: daqui nao ha o que emitir, so concluir o contrato. */
