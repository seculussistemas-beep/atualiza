<?php

/**
 * Encerrar como marca -- 10/09/2026, fatia 5 da reorganizacao
 * (docs/reorganizacao-do-painel.md, secoes 5 e 7).
 *
 * ENCERRAR NAO E APAGAR. E uma marca reversivel em `empresa`: tira o cliente
 * da fila, para a licenca na hora (o endpoint responde 409 `encerrado`), e
 * nao some com nada -- cadastro, terminais, cobrancas e historico ficam. O
 * apagar de verdade continua na Limpeza de cadastros, onde um humano confere
 * e confirma. O motivo e concreto: apagar empresa nao e atomico neste banco,
 * e rodando sem plateia e o pior lugar para esse defeito morder.
 *
 * A VARREDURA encerra sozinha o teste que venceu e ninguem fechou: passado o
 * fim do teste mais SHIELD_ENCERRAMENTO_DIAS, a marca entra com ator
 * "rotina". So lead (sem validade e sem contrato iniciado) entra na varredura
 * -- cliente com validade vencida e inadimplente, nao teste esquecido, e disso
 * a regua cuida.
 *
 * O RASCUNHO DO CONTRATO NAO PROTEGE, MAS DA PRAZO (14/09/2026, noite): quem ja
 * guardou meia ligacao de venda espera SHIELD_ENCERRAMENTO_DIAS_RASCUNHO. Nao
 * protege para sempre porque rascunho abandonado e tao esquecido quanto teste
 * abandonado, e a fila de avaliacao encheria de loja que ninguem vai fechar.
 */

require_once __DIR__ . '/../cobranca/cobranca.php'; // shield_auditar
require_once __DIR__ . '/teste.php';                 // shield_teste_fim
require_once __DIR__ . '/../nucleo/data_zerada.php'; // a data zerada em SQL, sem pedir conversao

/** Quantos dias depois do fim do teste a rotina encerra sozinha. */
const SHIELD_ENCERRAMENTO_DIAS = 30;

/** O mesmo prazo para quem tem rascunho do contrato salvo (empresa.rascunho_em, V4_2_4). */
const SHIELD_ENCERRAMENTO_DIAS_RASCUNHO = 60;

/**
 * Marca. Devolve false quando o cliente nao existe ou ja esta encerrado (nao
 * grava nada nem audita de novo).
 */
function shield_empresa_encerrar(PDO $pdo, $codigo, $ator, $motivo = '')
{
    $codigo = (int) $codigo;
    $stmt = $pdo->prepare('SELECT codigo, razao, cnpj, encerrado_em FROM empresa WHERE codigo = :c LIMIT 1');
    $stmt->execute(array(':c' => $codigo));
    $e = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!is_array($e) || trim((string) ($e['encerrado_em'] ?? '')) !== '') {
        return false;
    }

    $ator = substr(trim((string) $ator), 0, 80) ?: 'rotina';
    $motivo = substr(trim((string) $motivo), 0, 150);
    $pdo->prepare(
        'UPDATE empresa SET encerrado_em = NOW(), encerrado_por = :ator, encerrado_motivo = :motivo
          WHERE codigo = :c AND encerrado_em IS NULL'
    )->execute(array(':ator' => $ator, ':motivo' => $motivo !== '' ? $motivo : null, ':c' => $codigo));

    shield_auditar($pdo, 'cliente_encerrado', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => $codigo, 'ator' => $ator,
        'detalhe' => 'encerrado ' . (string) $e['razao'] . ' (' . (string) $e['cnpj'] . ')'
            . ($motivo !== '' ? ' -- ' . $motivo : '') . '; nada foi apagado',
    ));

    return true;
}

/** Desfaz a marca. Devolve false quando nao estava encerrado. */
function shield_empresa_reabrir(PDO $pdo, $codigo, $ator)
{
    $codigo = (int) $codigo;
    $stmt = $pdo->prepare(
        'UPDATE empresa SET encerrado_em = NULL, encerrado_por = NULL, encerrado_motivo = NULL
          WHERE codigo = :c AND encerrado_em IS NOT NULL'
    );
    $stmt->execute(array(':c' => $codigo));
    if ($stmt->rowCount() <= 0) {
        return false;
    }

    shield_auditar($pdo, 'cliente_reaberto', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => $codigo, 'ator' => substr(trim((string) $ator), 0, 80) ?: 'rotina',
        'detalhe' => 'reaberto: volta a fila e a licenca volta a sair',
    ));

    return true;
}

/**
 * A varredura: lead (sem validade, nao encerrado, sem contrato iniciado) cujo
 * teste venceu ha mais de SHIELD_ENCERRAMENTO_DIAS dias, ou de
 * SHIELD_ENCERRAMENTO_DIAS_RASCUNHO quando ha rascunho do contrato. Devolve
 * quantos encerrou. Base sem as colunas (anterior a 4.1.1) devolve zero.
 *
 * SELECT * E DE PROPOSITO (14/09/2026, noite). A lista de colunas deixava de
 * fora fechado_em, e shield_teste_fim sem ele calculava o teste de quem ja
 * tinha contrato iniciado e ainda nao pagou a primeira fatura: a rotina o
 * encerrava como teste esquecido, e encerrado recebe licenca bloqueada (4.1.23).
 * Com a empresa inteira, shield_teste_fim decide pelas mesmas colunas da fila, e
 * base anterior a V4_2_4 so fica sem rascunho_em -- vale o prazo curto.
 */
function shield_encerramento_varrer(PDO $pdo, $hoje = null)
{
    $hoje = $hoje ?: date('Y-m-d');
    try {
        // O catch abaixo trata falha como "base sem coluna": com o literal ao
        // lado da coluna, o 1525 de um servidor estrito caia nele e a varredura
        // devolvia zero calada -- o lead nunca era encerrado (16/09/2026).
        $stmt = $pdo->query(
            'SELECT * FROM empresa
              WHERE ' . shield_sql_sem_validade('validade_licenca') . ' AND encerrado_em IS NULL'
        );
        $leads = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
    } catch (Throwable $semColuna) {
        return 0;
    }

    $cfg = shield_teste_config($pdo);
    $n = 0;
    foreach ($leads as $e) {
        $fim = shield_teste_fim($e, $cfg);
        if ($fim === null) {
            continue;
        }
        $rascunho = trim((string) ($e['rascunho_em'] ?? '')) !== '';
        $dias = $rascunho ? SHIELD_ENCERRAMENTO_DIAS_RASCUNHO : SHIELD_ENCERRAMENTO_DIAS;
        if ($fim >= date('Y-m-d', strtotime($hoje . ' -' . $dias . ' days'))) {
            continue;
        }
        if (shield_empresa_encerrar($pdo, (int) $e['codigo'], 'rotina',
            'teste venceu em ' . date('d/m/Y', strtotime($fim)) . ' e ninguem fechou em ' . $dias . ' dias'
            . ($rascunho ? ' (havia rascunho do contrato salvo)' : ''))) {
            $n++;
        }
    }

    return $n;
}
