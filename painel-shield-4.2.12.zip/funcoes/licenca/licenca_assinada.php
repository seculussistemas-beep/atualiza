<?php

/**
 * Licenca assinada — emissao e cota — 23/08/2026.
 *
 * O ERP passou a saber ler uma licenca assinada; aqui e onde ela e emitida.
 * O formato e o mesmo JWS compacto que o Service/uLicencaBlob.pas do ERP le:
 *
 *   base64url(cabecalho) . "." . base64url(conteudo) . "." . base64url(assinatura)
 *
 * A assinatura e RSA-SHA256 sobre os BYTES do texto "<parte1>.<parte2>". NAO
 * mudar a forma como as partes sao montadas depois de emitir a primeira
 * licenca: o ERP confere o texto que recebeu, entao qualquer alteracao na
 * serializacao aqui invalida o que ja esta em campo.
 *
 * A chave PRIVADA fica no cofre que ja existe (shield_encrypt_secret), o mesmo
 * que guarda a senha do A1. A publica e mostrada na tela para ser colada no
 * uLicencaEmissor.pas do ERP antes de compilar.
 *
 * Par DEDICADO, nao o A1 da softhouse: o A1 vence todo ano — e o vencimento
 * dele invalidaria todas as licencas e obrigaria a recompilar o ERP anualmente
 * — e nem todo membro compra A1.
 *
 * LIMITE CONHECIDO desta versao: o pedido se identifica por CNPJ, sem segredo
 * por cliente. Quem souber um CNPJ consegue pedir licenca para ele — e recebe
 * uma amarrada a impressao da PROPRIA maquina, e so dentro da cota. E menos
 * exposto que hoje, onde o ERP se cadastra sozinho por CNPJ e SEM cota
 * nenhuma, mas nao e o mesmo que autenticado. Segredo por cliente e o passo
 * seguinte, e o formato do pedido ja comporta um campo a mais.
 */

declare(strict_types=1);

require_once __DIR__ . '/../contrato/assinatura_a1.php'; // shield_encrypt_secret / shield_decrypt_secret

/** Dias que a licenca emitida vale. Curto de proposito: e o que faz a
 *  instalacao que parou de conversar com o painel expirar sozinha. */
const SHIELD_LICENCA_CARENCIA_DIAS = 7;

/** Terminal que nao aparece ha este tanto deixa de ocupar vaga. */
const SHIELD_LICENCA_DIAS_FANTASMA = 30;

function shield_licenca_b64url(string $bytes): string
{
    return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '=');
}

/**
 * Gera o par e guarda. Devolve o registro do emissor.
 * O kid e sequencial: trocar o par significa publicar com numero novo, e
 * licenca emitida para um numero que o build do ERP nao carrega e RECUSADA em
 * vez de aceita por engano.
 */
function shield_licenca_gerar_par(PDO $pdo): array
{
    $recurso = openssl_pkey_new([
        'private_key_bits' => 2048,
        'private_key_type' => OPENSSL_KEYTYPE_RSA,
    ]);
    if ($recurso === false) {
        throw new RuntimeException('Nao foi possivel gerar o par de chaves: ' . openssl_error_string());
    }

    $privada = '';
    if (!openssl_pkey_export($recurso, $privada)) {
        throw new RuntimeException('Nao foi possivel exportar a chave privada.');
    }

    $detalhes = openssl_pkey_get_details($recurso);
    if (!is_array($detalhes) || !isset($detalhes['key'])) {
        throw new RuntimeException('Nao foi possivel extrair a chave publica.');
    }
    $publica = (string) $detalhes['key'];

    $pdo->prepare('UPDATE licenca_emissor SET ativo = 0')->execute();

    $proximo = (int) $pdo->query('SELECT COALESCE(MAX(CAST(kid AS UNSIGNED)), 0) + 1 FROM licenca_emissor')
        ->fetchColumn();

    $stmt = $pdo->prepare(
        'INSERT INTO licenca_emissor (kid, chave_publica, chave_privada, ativo)
         VALUES (:kid, :pub, :priv, 1)'
    );
    $stmt->execute([
        ':kid'  => (string) $proximo,
        ':pub'  => $publica,
        ':priv' => shield_encrypt_secret($privada),
    ]);

    return shield_licenca_emissor_ativo($pdo) ?? [];
}

function shield_licenca_emissor_ativo(PDO $pdo): ?array
{
    $stmt = $pdo->query('SELECT * FROM licenca_emissor WHERE ativo = 1 ORDER BY id DESC LIMIT 1');
    $linha = $stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : false;

    return is_array($linha) ? $linha : null;
}

/**
 * Assina e devolve o token. $conteudo vai como veio: quem monta os campos e
 * quem chama.
 */
function shield_licenca_assinar(array $emissor, array $conteudo): string
{
    $privadaPem = shield_decrypt_secret((string) ($emissor['chave_privada'] ?? ''));
    if ($privadaPem === '') {
        throw new RuntimeException('Emissor sem chave privada utilizavel.');
    }

    $chave = openssl_pkey_get_private($privadaPem);
    if ($chave === false) {
        throw new RuntimeException('Chave privada do emissor invalida.');
    }

    $cabecalho = ['alg' => 'RS256', 'kid' => (string) ($emissor['kid'] ?? '')];

    $p1 = shield_licenca_b64url((string) json_encode($cabecalho, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $p2 = shield_licenca_b64url((string) json_encode($conteudo, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));

    $assinatura = '';
    if (!openssl_sign($p1 . '.' . $p2, $assinatura, $chave, OPENSSL_ALGO_SHA256)) {
        throw new RuntimeException('Falha ao assinar a licenca: ' . openssl_error_string());
    }

    return $p1 . '.' . $p2 . '.' . shield_licenca_b64url($assinatura);
}

/**
 * Le uma parte de impressao ('M', 'B' ou 'D'). Ausente devolve ''.
 * Espelha o ValorDaParte do uLicencaTerminal.pas.
 */
function shield_licenca_parte_impressao(string $impressao, string $prefixo): string
{
    foreach (explode(';', $impressao) as $pedaco) {
        $pedaco = trim($pedaco);
        if (stripos($pedaco, $prefixo . ':') === 0) {
            $valor = substr($pedaco, strlen($prefixo) + 1);
            return $valor === '-' ? '' : $valor;
        }
    }

    return '';
}

/**
 * Duas de tres partes iguais, contando so as que existem dos DOIS lados.
 * Esta regra tem de ser identica a do TMaquina.Compativel no ERP — se as duas
 * divergirem, o servidor e o cliente discordam sobre qual maquina e qual.
 *
 * Parte ausente nao conta como igual: sem isso, duas maquinas sem serial de
 * placa-mae casariam entre si.
 */
function shield_licenca_impressao_compativel(string $um, string $outro): bool
{
    if (trim($um) === '' || trim($outro) === '') {
        return false;
    }

    $iguais = 0;
    foreach (['M', 'B', 'D'] as $parte) {
        $a = shield_licenca_parte_impressao($um, $parte);
        $b = shield_licenca_parte_impressao($outro, $parte);
        if ($a !== '' && $a === $b) {
            $iguais++;
        }
    }

    return $iguais >= 2;
}

/**
 * Documento valido: CPF (11) ou CNPJ (14), pelo digito verificador.
 *
 * Vale so na CRIACAO. Empresa que ja existe com documento torto continua sendo
 * encontrada -- corrigir cadastro antigo e outra conversa, e recusar licenca de
 * quem ja paga por causa disso seria trocar um problema por um pior.
 */
function shield_documento_valido(string $doc): bool
{
    $d = preg_replace('/\D+/', '', $doc);

    if (strlen($d) === 11) {
        if (preg_match('/^(\d)\1{10}$/', $d)) {
            return false;
        }
        for ($t = 9; $t < 11; $t++) {
            $s = 0;
            for ($i = 0; $i < $t; $i++) {
                $s += (int) $d[$i] * (($t + 1) - $i);
            }
            $dv = ((10 * $s) % 11) % 10;
            if ((int) $d[$t] !== $dv) {
                return false;
            }
        }
        return true;
    }

    if (strlen($d) === 14) {
        if (preg_match('/^(\d)\1{13}$/', $d)) {
            return false;
        }
        $pesos = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
        for ($t = 12; $t < 14; $t++) {
            $s = 0;
            $p = array_slice($pesos, 13 - $t);
            for ($i = 0; $i < $t; $i++) {
                $s += (int) $d[$i] * $p[$i];
            }
            $r = $s % 11;
            $dv = ($r < 2) ? 0 : 11 - $r;
            if ((int) $d[$t] !== $dv) {
                return false;
            }
        }
        return true;
    }

    return false;
}

/**
 * Cria a empresa que se apresentou e ainda nao existe.
 *
 * Nasce INERTE: sem validade_licenca nao ha licenca, entao ela aparece na sua
 * lista e nao roda. Quem autoriza nao e existir no painel -- e ter validade, e
 * quem poe validade e voce. E por isso que o auto-cadastro deixou de ser risco:
 * copia que ninguem vendeu entra na lista com um nome que voce nao reconhece e
 * fica parada.
 *
 * nterminais fica VAZIO de proposito. Ele quer dizer "contratado", e nada foi
 * contratado ainda; quantas maquinas existem se le na lista de terminais, e e
 * esse numero que serve para precificar. Igualar os dois destruiria a
 * comparacao contratados x instalados, que e o que acusa cota estourada.
 *
 * As colunas de endereco sao NOT NULL sem default: o que o ERP nao mandar
 * entra como texto vazio.
 */
function shield_licenca_criar_empresa(PDO $pdo, string $cnpj, array $pedido): ?array
{
    if (!shield_documento_valido($cnpj)) {
        return null;
    }

    $texto = static function ($v, int $tam): string {
        return substr(trim((string) $v), 0, $tam);
    };

    $stmt = $pdo->prepare(
        'INSERT INTO empresa (cnpj, razao, endereco, cidade, bairro, cep, uf,
                              fone, email, data, nterminais, validade_licenca, bloqueado)
         VALUES (:cnpj, :razao, :endereco, :cidade, :bairro, :cep, :uf,
                 :fone, :email, NOW(), NULL, NULL, :bloqueado)'
    );
    $stmt->execute([
        ':cnpj'      => $cnpj,
        ':razao'     => $texto($pedido['razao'] ?? '', 50),
        ':endereco'  => $texto($pedido['endereco'] ?? '', 50),
        ':cidade'    => $texto($pedido['cidade'] ?? '', 35),
        ':bairro'    => $texto($pedido['bairro'] ?? '', 35),
        ':cep'       => preg_replace('/\D+/', '', (string) ($pedido['cep'] ?? '')),
        ':uf'        => strtoupper($texto($pedido['uf'] ?? '', 2)),
        ':fone'      => $texto($pedido['fone'] ?? '', 20),
        ':email'     => $texto($pedido['email'] ?? '', 120),
        ':bloqueado' => 'N',
    ]);

    $stmt = $pdo->prepare(
        'SELECT * FROM empresa WHERE codigo = :cod'
    );
    $stmt->execute([':cod' => (int) $pdo->lastInsertId()]);
    $linha = $stmt->fetch(PDO::FETCH_ASSOC);

    return is_array($linha) ? $linha : null;
}

/**
 * O ERP COMPLETA O QUE ESTA EM BRANCO, E SO ISSO -- 16/09/2026.
 *
 * Com a tela de cadastrar cliente (funcoes/empresa/cadastro.php) a loja passa a
 * existir no painel antes de instalar, com CNPJ e nome digitados a mao e o
 * resto vazio -- endereco, telefone, e-mail. Quando o ERP dela finalmente liga,
 * ele manda esses dados no pedido, e seria desperdicio deixar os campos vazios
 * para sempre.
 *
 * O QUE O MEMBRO DIGITOU NUNCA E SOBRESCRITO. O nome no painel costuma ser o
 * que ele combinou com o cliente ("Mercado do Ze"), e o do ERP e a razao social
 * inteira; deixar o ERP mandar por cima trocaria o cadastro que o membro
 * reconhece por outro, em silencio, a cada abertura de caixa.
 *
 * NADA VAZIO, NENHUM UPDATE. Este e o caminho mais quente do painel -- toda
 * abertura de caixa de todo cliente passa aqui --, entao o comando so e montado
 * quando ha de fato o que completar, o que na pratica acontece uma vez na vida
 * de cada loja.
 */
function shield_licenca_completar_cadastro(PDO $pdo, array $empresa, array $pedido): array
{
    $campos = array(
        'razao' => 50, 'endereco' => 50, 'cidade' => 35, 'bairro' => 35,
        'cep' => 8, 'uf' => 2, 'fone' => 20, 'email' => 120,
    );

    $set = array();
    $valores = array();
    foreach ($campos as $campo => $tamanho) {
        if (trim((string) ($empresa[$campo] ?? '')) !== '') {
            continue;
        }

        $novo = trim((string) ($pedido[$campo] ?? ''));
        if ($campo === 'cep') {
            $novo = preg_replace('/\D+/', '', $novo);
        } elseif ($campo === 'uf') {
            $novo = strtoupper($novo);
        }
        if ($novo === '') {
            continue;
        }

        $novo = substr($novo, 0, $tamanho);
        $set[] = $campo . ' = :' . $campo;
        $valores[':' . $campo] = $novo;
        $empresa[$campo] = $novo;
    }

    if ($set === array()) {
        return $empresa;
    }

    $valores[':cod'] = (int) ($empresa['codigo'] ?? 0);
    $pdo->prepare('UPDATE empresa SET ' . implode(', ', $set) . ' WHERE codigo = :cod')->execute($valores);

    return $empresa;
}

/**
 * Quem, entre os terminais VIVOS, esta dentro da cota.
 *
 * Regra: os N MAIS ANTIGOS ficam. E a leitura literal de "quem ja tem vaga
 * nunca a perde para quem chegou depois" -- que e diferente de "quem ja esta
 * na tabela nunca e recusado", que era o comportamento anterior.
 *
 * Determinista e estavel: a mesma maquina recebe a mesma resposta em toda
 * abertura, e vender mais terminais e a unica coisa que muda isso.
 *
 * Cota vazia ou zero libera todo mundo -- e a empresa em DEMONSTRACAO, que
 * ainda nao contratou terminal nenhum.
 */
function shield_licenca_tem_vaga(array $linhas, int $codigo, int $contratado): bool
{
    if ($contratado <= 0) {
        return true;
    }

    $vivos = [];
    $estaNaTabela = false;
    foreach ($linhas as $linha) {
        if ((int) $linha['CODIGO'] === $codigo) {
            $estaNaTabela = true;
        }

        // DESATIVADO NAO OCUPA VAGA -- 09/09/2026. E o atalho para a
        // troca de maquina: a regra dos 30 dias devolve a vaga sozinha, e esta
        // coluna deixa o membro devolver na hora, quando ele SABE que a maquina
        // queimou. Ver V4_0_9.
        if (trim((string) ($linha['DESATIVADO_EM'] ?? '')) !== '') {
            continue;
        }

        $visto = (string) ($linha['ULTIMO_ACESSO'] ?? '');
        $ehFantasma = ($visto === '')
            || (strtotime($visto) < strtotime('-' . SHIELD_LICENCA_DIAS_FANTASMA . ' days'));
        if (!$ehFantasma) {
            $vivos[] = (int) $linha['CODIGO'];
        }
    }

    // Maquina que ainda nao esta na tabela nao pode ser recusada por uma
    // contagem que nao a inclui. Quem cobra a cota dela e o passo seguinte, na
    // reconciliacao, que sabe se ha linha para reaproveitar.
    if (!$estaNaTabela) {
        return true;
    }

    // Fantasma nao ocupa vaga: quem sumiu ha mais de
    // SHIELD_LICENCA_DIAS_FANTASMA dias nao tira do ar quem esta trabalhando.
    //
    // E QUEM VOLTA DISPUTA COMO OS OUTROS -- 09/09/2026. Antes esta
    // linha devolvia `true` seco, e com isso a propria linha estar velha
    // pulava a cota inteira: cota de dois acordava com tres maquinas no ar.
    // Contradizia a regra do cabecalho ("os N mais antigos ficam, determinista
    // e estavel") -- a mesma maquina recebia respostas diferentes conforme
    // quanto tempo tinha ficado parada.
    //
    // Quem sumiu devolveu a vaga ao bolo, entao voltar e como chegar: entra se
    // houver espaco. Nao derruba ninguem, porque so olha quantos vivos existem.
    if (!in_array($codigo, $vivos, true)) {
        return count($vivos) < $contratado;
    }

    sort($vivos);
    $posicao = array_search($codigo, $vivos, true);

    return $posicao !== false && $posicao < $contratado;
}

/**
 * Casa o terminal e cobra a cota. Devolve
 * ['terminal' => int, 'status' => 'ativa'|'excedente', 'motivo' => string].
 *
 * REGRAS, nesta ordem:
 *   1. impressao de hardware (2 de 3) — aguenta formatacao e troca de peca;
 *   2. MAC, para as linhas gravadas antes de existir impressao;
 *   3. cota cheia de terminais vivos? excedente, sem tocar em linha nenhuma;
 *   4. ha FANTASMA (sem sinal ha 30 dias)? reaproveita a vaga dele;
 *   5. sobrou espaco na cota? insere.
 *
 * A COTA VEM ANTES DO REAPROVEITAMENTO -- 14/09/2026. Ela era o ultimo passo,
 * e a maquina nova que achava linha parada saia daqui 'ativa' com a cota
 * cheia. O estrago nao era so entrar a mais: a antiguidade no painel e o
 * CODIGO, a linha reaproveitada volta a ser viva com o CODIGO antigo, e na
 * batida seguinte um caixa que estava DENTRO da cota caia para excedente.
 * Reaproveitando so quando ha espaco, os vivos de depois cabem na cota e
 * nenhuma posicao passa do contratado: o CODIGO herdado nao empurra ninguem.
 *
 * O passo 4 vem ANTES do 5 de proposito: a linha e uma VAGA, nao um historico.
 * Inserindo enquanto ha fantasma, a tabela cresce para sempre e o painel passa
 * a mostrar mais terminais do que o contrato tem — a confusao que este
 * trabalho existe para tirar.
 *
 * O nome do computador NAO participa do casamento em momento nenhum — era o
 * que fazia maquina formatada perder o registro.
 *
 * QUEM JA TEM VAGA NUNCA A PERDE PARA QUEM CHEGOU DEPOIS: os passos 1 e 2 vem
 * antes de qualquer contagem, e o 4 so alcanca linha que parou de dar sinal,
 * e so quando cabe. Sem isso, um terminal novo poderia derrubar o caixa que
 * esta vendendo.
 */
function shield_licenca_reconciliar_terminal(
    PDO $pdo,
    int $empresaId,
    int $contratado,
    string $impressao,
    string $mac,
    string $nome,
    string $versao
): array {
    $stmt = $pdo->prepare('SELECT CODIGO, MAC, NOME_COMPUTADOR, FINGERPRINT, ULTIMO_ACESSO,
                                  DESATIVADO_EM
                             FROM terminais WHERE FK_EMPRESA = :emp ORDER BY CODIGO');
    $stmt->execute([':emp' => $empresaId]);
    $linhas = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $achado = null;
    $motivo = '';

    if (trim($impressao) !== '') {
        foreach ($linhas as $linha) {
            if (shield_licenca_impressao_compativel((string) ($linha['FINGERPRINT'] ?? ''), $impressao)) {
                $achado = $linha;
                $motivo = 'casou pela impressao de hardware';
                break;
            }
        }
    }

    if ($achado === null && trim($mac) !== '') {
        foreach ($linhas as $linha) {
            if (strcasecmp(trim((string) ($linha['MAC'] ?? '')), trim($mac)) === 0) {
                $achado = $linha;
                $motivo = 'casou pelo MAC';
                break;
            }
        }
    }

    $atualiza = $pdo->prepare(
        'UPDATE terminais
            SET MAC = :mac, NOME_COMPUTADOR = :nome, FINGERPRINT = :fp,
                ULTIMO_ACESSO = NOW(), VERSAO_EXE = :ver
          WHERE CODIGO = :cod'
    );

    if ($achado !== null) {
        $codigo = (int) $achado['CODIGO'];

        // DESATIVADO NAO VOLTA SOZINHO -- 09/09/2026. Se voltasse, a
        // maquina que o membro desativou de proposito se reativaria na primeira
        // vez que alguem a ligasse para copiar um arquivo, e derrubaria a que
        // entrou no lugar dela. A volta e decisao de gente, na tela.
        //
        // O MOTIVO SAI NA RESPOSTA: sem ele, "o sistema nao abre nessa maquina"
        // vira chamado sem diagnostico, e o proprio membro nao lembra de ter
        // desativado.
        if (trim((string) ($achado['DESATIVADO_EM'] ?? '')) !== '') {
            return [
                'terminal' => $codigo,
                'status'   => 'excedente',
                'motivo'   => 'terminal desativado no painel em '
                    . date('d/m/Y', strtotime((string) $achado['DESATIVADO_EM'])),
            ];
        }

        // A COTA VALE PARA MAQUINA CONHECIDA TAMBEM. Antes o achado voltava
        // 'ativa' aqui, sem passar por verificacao nenhuma -- a cota so era
        // conferida na insercao. Na pratica ela limitava CRESCIMENTO e nao
        // USO: cliente que testava em 5 caixas e fechava licenca de 2 ficava
        // com os 5 no ar para sempre, e reduzir a cota de alguem nao tirava
        // ninguem do ar.
        //
        // A CONFERENCIA VEM ANTES DO CARIMBO -- 09/09/2026. Ela ficava
        // depois, e entao a maquina recusada saia daqui com ULTIMO_ACESSO de
        // agora, ou seja, parecendo que tinha acabado de trabalhar. A propria
        // resposta nao mudava (a contagem le a lista de ANTES do UPDATE), mas o
        // resto do painel acreditava: o membro via "3 caixas dando sinal" com
        // dois funcionando, e a ficha do cliente marcava como cobravel um
        // terminal excedente que estava parado.
        if (!shield_licenca_tem_vaga($linhas, $codigo, $contratado)) {
            // A IDENTIDADE AINDA E ATUALIZADA, so o sinal de vida que nao. A
            // impressao de hardware muda com troca de peca, e e por ela que
            // esta maquina sera reconhecida no dia em que a cota subir --
            // deixar a linha congelar faria o cliente que comprou mais um
            // terminal gastar a vaga nova com uma segunda linha da MESMA
            // maquina.
            $soIdentidade = $pdo->prepare(
                'UPDATE terminais
                    SET MAC = :mac, NOME_COMPUTADOR = :nome, FINGERPRINT = :fp, VERSAO_EXE = :ver
                  WHERE CODIGO = :cod'
            );
            $soIdentidade->execute([
                ':mac' => $mac, ':nome' => $nome, ':fp' => $impressao,
                ':ver' => $versao, ':cod' => $codigo,
            ]);

            return [
                'terminal' => $codigo,
                'status'   => 'excedente',
                'motivo'   => sprintf(
                    'cota cheia: este terminal esta fora das %d vagas',
                    $contratado
                ),
            ];
        }

        $atualiza->execute([
            ':mac' => $mac, ':nome' => $nome, ':fp' => $impressao,
            ':ver' => $versao, ':cod' => $codigo,
        ]);

        return ['terminal' => $codigo, 'status' => 'ativa', 'motivo' => $motivo];
    }

    // Maquina nova. So agora a cota entra na conversa.
    $vivos = 0;
    $fantasmas = [];
    foreach ($linhas as $linha) {
        // Linha desativada nao conta e NAO E RECICLADA: ela foi parada a mao, e
        // reaproveita-la para outra maquina ressuscitaria o registro com outra
        // identidade -- o membro veria a maquina que ele desativou "voltando".
        // A vaga dela ja esta livre por nao contar aqui; a linha fica quieta.
        if (trim((string) ($linha['DESATIVADO_EM'] ?? '')) !== '') {
            continue;
        }

        $visto = (string) ($linha['ULTIMO_ACESSO'] ?? '');
        $ehFantasma = ($visto === '')
            || (strtotime($visto) < strtotime('-' . SHIELD_LICENCA_DIAS_FANTASMA . ' days'));
        if ($ehFantasma) {
            $fantasmas[] = $linha;
        } else {
            $vivos++;
        }
    }

    // COTA CHEIA RECUSA ANTES DE OLHAR LINHA PARADA -- 14/09/2026 (ver o
    // cabecalho). A linha parada fica como esta: nem o CODIGO dela nem o sinal
    // de vida mudam por causa de uma maquina que nao entrou.
    if ($contratado > 0 && $vivos >= $contratado) {
        return [
            'terminal' => 0,
            'status'   => 'excedente',
            'motivo'   => sprintf('cota cheia: %d de %d em uso', $vivos, $contratado),
        ];
    }

    // Havendo fantasma, a vaga dele e REAPROVEITADA -- mesmo que ainda sobrasse
    // espaco para inserir linha nova. Sem isto a tabela cresce para sempre e o
    // painel passa a mostrar mais terminais do que a licenca contratou, que e
    // exatamente a confusao que este trabalho existe para tirar. A linha e uma
    // VAGA, nao um historico.
    if ($fantasmas !== []) {
        // O mais velho primeiro: ULTIMO_ACESSO vazio vira 0 e vai na frente.
        usort($fantasmas, static function (array $a, array $b): int {
            return strtotime((string) ($a['ULTIMO_ACESSO'] ?? '')) <=> strtotime((string) ($b['ULTIMO_ACESSO'] ?? ''));
        });
        $reciclado = (int) $fantasmas[0]['CODIGO'];

        $atualiza->execute([
            ':mac' => $mac, ':nome' => $nome, ':fp' => $impressao,
            ':ver' => $versao, ':cod' => $reciclado,
        ]);

        return [
            'terminal' => $reciclado,
            'status'   => 'ativa',
            'motivo'   => 'vaga reaproveitada de terminal sem sinal ha mais de '
                . SHIELD_LICENCA_DIAS_FANTASMA . ' dias',
        ];
    }

    $insere = $pdo->prepare(
        'INSERT INTO terminais (FK_EMPRESA, MAC, NOME_COMPUTADOR, FINGERPRINT, ULTIMO_ACESSO, VERSAO_EXE)
         VALUES (:emp, :mac, :nome, :fp, NOW(), :ver)'
    );
    $insere->execute([
        ':emp' => $empresaId, ':mac' => $mac, ':nome' => $nome,
        ':fp' => $impressao, ':ver' => $versao,
    ]);

    return ['terminal' => (int) $pdo->lastInsertId(), 'status' => 'ativa', 'motivo' => 'terminal novo registrado'];
}

/**
 * Reativar cabe na cota? Devolve '' quando cabe, ou a frase da recusa -- 14/09/2026.
 *
 * REATIVAR TAMBEM DERRUBA CAIXA. Desativar so exige SHIELD_PARQUE_DIAS_SUMIDO
 * dias sem sinal, e a vaga so volta sozinha depois de
 * SHIELD_LICENCA_DIAS_FANTASMA. No meio, a linha desativada ainda e viva pela
 * data: tirada a marca, ela volta a contar na hora com o CODIGO dela -- quase
 * sempre baixo, porque e maquina antiga -- e o caixa vivo mais novo cai para
 * excedente na batida seguinte, mesmo que a reativada nunca mais ligue.
 *
 * E a conta de shield_licenca_tem_vaga feita antes: com os outros vivos abaixo
 * do contratado, depois da volta todos continuam dentro. A linha parada ha
 * SHIELD_LICENCA_DIAS_FANTASMA dias ou mais passa sempre: ela nao entra nos
 * vivos ao ser reativada, e disputa a vaga pelo caminho de sempre quando bater.
 */
function shield_licenca_reativar_recusa(array $linhas, int $codigo, int $contratado): string
{
    if ($contratado <= 0) {
        return '';
    }

    $alvoVivo = false;
    $vivosOutros = 0;
    foreach ($linhas as $linha) {
        // O mesmo corte de shield_licenca_tem_vaga, escrito do mesmo jeito:
        // contar diferente aqui faria a tela recusar o que a API aceitaria.
        $visto = (string) ($linha['ULTIMO_ACESSO'] ?? '');
        $ehFantasma = ($visto === '')
            || (strtotime($visto) < strtotime('-' . SHIELD_LICENCA_DIAS_FANTASMA . ' days'));

        if ((int) $linha['CODIGO'] === $codigo) {
            $alvoVivo = !$ehFantasma;
            continue;
        }
        if (trim((string) ($linha['DESATIVADO_EM'] ?? '')) !== '') {
            continue;
        }
        if (!$ehFantasma) {
            $vivosOutros++;
        }
    }

    if (!$alvoVivo || $vivosOutros < $contratado) {
        return '';
    }

    return sprintf(
        'Nao da para reativar: as %d vagas ja estao ocupadas por maquinas que deram sinal nos ultimos %d dias, '
        . 'e reativar agora tiraria do ar um caixa que esta trabalhando. Libere a vaga de outra maquina '
        . 'ou aumente a quantidade de terminais.',
        $contratado,
        SHIELD_LICENCA_DIAS_FANTASMA
    );
}

/**
 * Tira a marca de desativado, conferindo antes a cota -- 14/09/2026.
 *
 * A cota e a MESMA que a API aplica ao casar o terminal: nterminais do
 * cadastro, ou a do teste enquanto o lead esta em avaliacao (emprestar_teste,
 * em public/api/licenca.php). Com outra conta, a tela deixaria voltar quem a
 * batida seguinte recusaria, ou recusaria quem cabe.
 *
 * Recusa com RuntimeException, com a frase para a tela mostrar. Devolve true
 * quando tirou a marca, false quando a linha ja estava ativa.
 */
function shield_licenca_reativar_terminal(PDO $pdo, int $codigo): bool
{
    $stmt = $pdo->prepare('SELECT FK_EMPRESA FROM terminais WHERE CODIGO = :c');
    $stmt->execute([':c' => $codigo]);
    $empresaId = (int) $stmt->fetchColumn();
    if ($empresaId <= 0) {
        throw new RuntimeException('Terminal nao encontrado.');
    }

    $stmt = $pdo->prepare('SELECT * FROM empresa WHERE codigo = :e');
    $stmt->execute([':e' => $empresaId]);
    $empresa = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

    $contratado = (int) ($empresa['nterminais'] ?? 0);
    // Carregado aqui dentro, e nao no topo: este arquivo esta na cadeia de
    // require de public/api/licenca.php (documentacao do projeto, secao 3).
    require_once __DIR__ . '/teste.php';
    $cfg = shield_teste_config($pdo);
    if ($empresa !== [] && shield_teste_vigente($empresa, $cfg)) {
        $contratado = shield_teste_terminais_de($empresa, $cfg);
    }

    $stmt = $pdo->prepare('SELECT CODIGO, ULTIMO_ACESSO, DESATIVADO_EM
                             FROM terminais WHERE FK_EMPRESA = :e ORDER BY CODIGO');
    $stmt->execute([':e' => $empresaId]);
    $recusa = shield_licenca_reativar_recusa($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [], $codigo, $contratado);
    if ($recusa !== '') {
        throw new RuntimeException($recusa);
    }

    $stmt = $pdo->prepare('UPDATE terminais SET DESATIVADO_EM = NULL, DESATIVADO_POR = NULL
                            WHERE CODIGO = :c AND DESATIVADO_EM IS NOT NULL');
    $stmt->execute([':c' => $codigo]);

    return $stmt->rowCount() > 0;
}

/**
 * Monta o conteudo da licenca a partir da empresa e do desfecho do terminal.
 *
 * valido_ate = o MENOR entre (hoje + carencia) e a validade contratada. O
 * prazo curto e proposital: instalacao que parar de conversar com o painel
 * expira sozinha, sem precisar de nada do nosso lado — e nunca passa do fim
 * do contrato.
 *
 * $extras -- 10/09/2026, o contrato novo com o ERP:
 *   'modulos'      lista de chaves; SO ENTRA quando nao vazia, e entra por
 *                  ULTIMO. Campo ausente e "tudo liberado" do lado Delphi, e
 *                  por ultimo porque as nove chaves de antes entram na
 *                  assinatura na ordem em que estao -- token de cliente sem
 *                  modulo sai byte a byte igual ao de ontem;
 *   'promessa_ate' Y-m-d da liberacao em confianca / promessa de pagamento.
 *                  Levanta o FIM DO CONTRATO (max), nunca a janela rolante de
 *                  sete dias, e so dentro do ramo que exige validade -- senao
 *                  vira licenca gratis para quem nunca comprou. O token nunca
 *                  passa da data prometida: a promessa se liquida sozinha.
 *
 *   'contrato_ate' true pede o FIM DO CONTRATO como chave extra -- 11/09/2026.
 *                  E o $fim de baixo (a validade, levantada pela promessa;
 *                  para o lead em avaliacao, o fim dela, porque a API ja
 *                  a emprestou na copia em memoria). E a data que o ERP
 *                  mostra como "licenca ate" na tela de licenca e na barra
 *                  da tela principal -- INFORMATIVA: quem decide continua
 *                  sendo o valido_ate. Entra DEPOIS de modulos e so quando
 *                  pedida, para o molde congelado (LicencaConteudoTest)
 *                  continuar valendo; sem validade nao ha contrato a dizer.
 *
 * A PROMESSA RETEM a sobrescrita para 'bloqueada' quando o bloqueio e a
 * SUSPENSAO POR DIVIDA (suspenso_em preenchido) -- senao o ERP faz Exit em
 * 'bloqueada' antes de ler a data e a promessa nao serve para nada. Bloqueio
 * manual (sem suspenso_em) nao e mascarado: e a unica ferramenta do membro
 * para o que nao e divida. E ela RETEM, nao escreve 'ativa': o status do
 * terminal pode ser 'excedente', e esse continua saindo.
 */
function shield_licenca_montar_conteudo(array $empresa, array $terminal, string $impressao, string $emissorNome, array $extras = array()): array
{
    $validade = trim((string) ($empresa['validade_licenca'] ?? ''));
    $limite = (new DateTimeImmutable('today'))->modify('+' . SHIELD_LICENCA_CARENCIA_DIAS . ' days');

    $promessa = null;
    $promessaTexto = trim((string) ($extras['promessa_ate'] ?? ''));
    if ($promessaTexto !== '') {
        $p = DateTimeImmutable::createFromFormat('!Y-m-d', substr($promessaTexto, 0, 10));
        $promessa = $p instanceof DateTimeImmutable ? $p : null;
    }

    $fim = null;
    if ($validade !== '') {
        $fim = DateTimeImmutable::createFromFormat('!Y-m-d', substr($validade, 0, 10));
        if ($fim instanceof DateTimeImmutable) {
            if ($promessa instanceof DateTimeImmutable && $promessa > $fim) {
                $fim = $promessa;
            }
            if ($fim < $limite) {
                $limite = $fim;
            }
        }
    }

    $status = (string) $terminal['status'];
    if (strtoupper(trim((string) ($empresa['bloqueado'] ?? ''))) === 'S') {
        $suspensoPorDivida = trim((string) ($empresa['suspenso_em'] ?? '')) !== '';
        if (!($promessa instanceof DateTimeImmutable && $suspensoPorDivida)) {
            $status = 'bloqueada';
        }
    }

    $conteudo = [
        'cnpj'        => preg_replace('/\D+/', '', (string) ($empresa['cnpj'] ?? '')),
        'fingerprint' => $impressao,
        'terminal'    => (int) $terminal['terminal'],
        'status'      => $status,
        'nterminais'  => (int) ($empresa['nterminais'] ?? 0),
        'valido_ate'  => $limite->format('Y-m-d'),
        'servidor_em' => (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s\Z'),
        'carencia'    => SHIELD_LICENCA_CARENCIA_DIAS,
        'emissor'     => $emissorNome,
    ];

    $modulos = array();
    foreach ((array) ($extras['modulos'] ?? array()) as $m) {
        $m = trim((string) $m);
        if ($m !== '') {
            $modulos[] = $m;
        }
    }
    if ($modulos) {
        $conteudo['modulos'] = array_values($modulos);
    }

    // Ver o cabecalho: extra, opcional, depois de modulos, so com validade.
    if (!empty($extras['contrato_ate']) && $fim instanceof DateTimeImmutable) {
        $conteudo['contrato_ate'] = $fim->format('Y-m-d');
    }

    return $conteudo;
}

// ------------------------------------------------------------- identidade ---

/**
 * O token assinado como IDENTIDADE do ERP - 04/09/2026.
 *
 * As acoes que o cliente dispara pela tela de licenca (conferir e informar
 * pagamento) nao podem ficar abertas a quem souber um CNPJ. O ERP manda de
 * volta a licenca assinada que guarda, e ela e prova suficiente: foi este
 * painel que a assinou, e ela carrega o CNPJ.
 *
 * Esta e a metade PURA, exercitavel sem banco: recebe a chave publica.
 * Devolve o conteudo do token, ou null quando ele nao e nosso, esta
 * adulterado ou e de outro CNPJ. A validade NAO entra na conta: um token
 * vencido continua provando de onde veio -- e o cliente vencido e justamente
 * quem esta na tela pagando.
 */
function shield_licenca_token_confere_com_chave($token, $publicaPem, $cnpj)
{
    $partes = explode('.', trim((string) $token));
    if (count($partes) !== 3) {
        return null;
    }

    $deB64 = static function ($t) {
        $t = strtr((string) $t, '-_', '+/');

        return base64_decode(str_pad($t, (int) (ceil(strlen($t) / 4) * 4), '='), true);
    };

    $cabecalho = json_decode((string) $deB64($partes[0]), true);
    $conteudo = json_decode((string) $deB64($partes[1]), true);
    if (!is_array($cabecalho) || !is_array($conteudo)) {
        return null;
    }

    $assinatura = $deB64($partes[2]);
    if ($assinatura === false || $assinatura === '' || trim((string) $publicaPem) === '') {
        return null;
    }
    if (openssl_verify($partes[0] . '.' . $partes[1], $assinatura, (string) $publicaPem, OPENSSL_ALGO_SHA256) !== 1) {
        return null;
    }

    $doToken = preg_replace('/\D+/', '', (string) ($conteudo['cnpj'] ?? ''));
    if ($doToken === '' || $doToken !== preg_replace('/\D+/', '', (string) $cnpj)) {
        return null;
    }

    return $conteudo;
}

/**
 * A metade com banco: acha a chave publica pelo kid do cabecalho.
 *
 * Aceita QUALQUER par que este painel ja tenha emitido, nao so o ativo:
 * depois de uma rotacao os clientes seguem por ate sete dias com a licenca da
 * chave anterior, e ela continua sendo assinatura nossa.
 */
function shield_licenca_token_confere(PDO $pdo, $token, $cnpj)
{
    $partes = explode('.', trim((string) $token));
    if (count($partes) !== 3) {
        return null;
    }

    $cabecalho = json_decode((string) base64_decode(
        str_pad(strtr($partes[0], '-_', '+/'), (int) (ceil(strlen($partes[0]) / 4) * 4), '='), true
    ), true);
    if (!is_array($cabecalho)) {
        return null;
    }

    try {
        $stmt = $pdo->prepare('SELECT chave_publica FROM licenca_emissor WHERE kid = :kid LIMIT 1');
        $stmt->execute(array(':kid' => (string) ($cabecalho['kid'] ?? '')));
        $publica = $stmt->fetchColumn();
    } catch (Throwable $ignorado) {
        return null;
    }
    if (!$publica) {
        return null;
    }

    return shield_licenca_token_confere_com_chave($token, (string) $publica, $cnpj);
}
