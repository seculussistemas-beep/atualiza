<?php

/**
 * A lista da tela Certificados digitais -- 19/10/2026.
 *
 * Pedido de membro: o certificado so aparecia no bloco da Central e num filtro
 * de Clientes que ninguem achava. Fica fora de certificado.php de proposito:
 * aquele arquivo esta na cadeia de require da rota de licenca, e esta lista
 * precisa da situacao do cliente, que a rota nao carrega.
 *
 * A DATA VEM SO DO ERP (4.1.1). Por isso o recorte "sem data informada": e quem
 * o membro precisa conferir, e so entre CLIENTES -- o lead em avaliacao sem data
 * encheria a lista de quem ainda nem comprou.
 */

require_once __DIR__ . '/certificado.php';
require_once __DIR__ . '/situacao.php'; // shield_situacao_onde_cliente

/** Os recortes, na ordem da tela. O primeiro e o do badge e o da abertura. */
function shield_certificado_recortes()
{
    return array(
        'vencendo' => 'Vencidos e at&eacute; 30 dias',
        'vencidos' => 'S&oacute; vencidos',
        '60' => 'At&eacute; 60 dias',
        'todos' => 'Todos com data',
        'sem' => 'Sem data informada',
    );
}

/** O WHERE de cada recorte. Recorte desconhecido cai no primeiro. */
function shield_certificado_onde_recorte($recorte)
{
    switch ((string) $recorte) {
        case 'vencidos':
            return 'certificado_vence IS NOT NULL AND certificado_vence < CURDATE() AND encerrado_em IS NULL';
        case '60':
            return shield_certificado_onde_vencendo(60);
        case 'todos':
            return 'certificado_vence IS NOT NULL AND encerrado_em IS NULL';
        case 'sem':
            return 'certificado_vence IS NULL AND encerrado_em IS NULL AND ' . shield_situacao_onde_cliente();
        default:
            return shield_certificado_onde_vencendo(30);
    }
}

/**
 * As linhas do recorte, mais vencido primeiro (e por nome no "sem data").
 * Devolve ['linhas' => [...], 'cortada' => bool].
 */
function shield_certificado_lista(PDO $pdo, $recorte, $limite = 500)
{
    $limite = max(1, (int) $limite);
    $ordem = (string) $recorte === 'sem' ? 'razao, codigo' : 'certificado_vence, razao, codigo';
    try {
        $linhas = $pdo->query(
            'SELECT codigo, razao, cnpj, fone, certificado_vence FROM empresa WHERE '
            . shield_certificado_onde_recorte($recorte) . ' ORDER BY ' . $ordem . ' LIMIT ' . ($limite + 1)
        )->fetchAll(PDO::FETCH_ASSOC) ?: array();
    } catch (Throwable $semColuna) {
        $linhas = array();
    }
    $cortada = count($linhas) > $limite;
    if ($cortada) {
        array_pop($linhas);
    }

    return array('linhas' => $linhas, 'cortada' => $cortada);
}

/** Quantos em cada recorte, para os botoes da tela. */
function shield_certificado_contagens(PDO $pdo)
{
    $c = array();
    foreach (array_keys(shield_certificado_recortes()) as $recorte) {
        try {
            $c[$recorte] = (int) $pdo->query('SELECT COUNT(*) FROM empresa WHERE ' . shield_certificado_onde_recorte($recorte))->fetchColumn();
        } catch (Throwable $semColuna) {
            $c[$recorte] = 0;
        }
    }

    return $c;
}
