<?php

/**
 * O conteudo da licenca em ARQUIVO (.lic) -- 14/09/2026.
 *
 * Saiu de modules/licencas/arquivo.php, onde a montagem vivia entre header()
 * e exit e nao havia como testar. NAO passa por shield_licenca_montar_conteudo,
 * e isso e de proposito: aquela e a da API, com o molde congelado em
 * LicencaConteudoTest, e nao carimba `origem`. O ERP decide que a licenca veio
 * de arquivo por `origem = 'arquivo'` (uLicencaBlob.pas); sem o carimbo sobra
 * uma deducao que falha justamente no arquivo cortado pela validade.
 *
 * contrato_ate NUNCA PASSA DO FIM DO ARQUIVO. Ate 14/09/2026 ele levava a
 * validade inteira do cadastro, e o ERP mostra essa data como "vale ate" na
 * tela de licenca, na barra e na Central, e conta o aviso de vencimento por
 * ela. Com um arquivo de um mes para quem tem contrato de um ano, a loja lia
 * "vale ate" daqui a um ano, nao recebia aviso nenhum e parava no fim do
 * arquivo. No arquivo quem decide e o valido_ate, e e ele que o operador
 * offline precisa ver: quando acabar, pede outro arquivo. Os .lic ja emitidos
 * nao se revogam; para eles o conserto e do lado do ERP.
 *
 * A ORDEM DAS CHAVES e a de sempre, com contrato_ate por ultimo. O arquivo nao
 * tem molde congelado como o token da API (cada .lic confere pelos proprios
 * bytes), mas chave nova entra no fim pela mesma doutrina.
 */

declare(strict_types=1);

require_once __DIR__ . '/licenca_assinada.php'; // SHIELD_LICENCA_CARENCIA_DIAS

/**
 * Devolve ['conteudo' => array, 'ate' => DateTimeImmutable, 'limitado' => bool].
 *
 * $empresa precisa de cnpj, razao, bloqueado, nterminais e validade_licenca (a
 * tela recusa emitir sem validade antes de chegar aqui). $terminal e o desfecho
 * de shield_licenca_reconciliar_terminal, ja conferido como nao excedente.
 * $hoje existe para o teste fixar a data.
 */
function shield_licenca_arquivo_conteudo(array $empresa, array $terminal, string $impressao, int $meses, ?DateTimeImmutable $hoje = null): array
{
    $hoje = $hoje ?? new DateTimeImmutable('today');

    // Prazo escolhido, LIMITADO pela validade que o cliente comprou. Sem o
    // teto, um arquivo de 12 meses sobreviveria ao fim da licenca -- e nao
    // ha como revoga-lo depois.
    $ate = $hoje->modify('+' . $meses . ' months');
    $fim = DateTimeImmutable::createFromFormat('!Y-m-d', substr(trim((string) ($empresa['validade_licenca'] ?? '')), 0, 10));
    $limitado = false;
    if ($fim instanceof DateTimeImmutable && $fim < $ate) {
        $ate = $fim;
        $limitado = true;
    }

    $conteudo = [
        'cnpj'        => preg_replace('/\D+/', '', (string) ($empresa['cnpj'] ?? '')),
        'fingerprint' => $impressao,
        'terminal'    => (int) $terminal['terminal'],
        'status'      => strtoupper(trim((string) ($empresa['bloqueado'] ?? ''))) === 'S'
                            ? 'bloqueada' : 'ativa',
        'nterminais'  => (int) ($empresa['nterminais'] ?? 0),
        'valido_ate'  => $ate->format('Y-m-d'),
        'servidor_em' => (new DateTimeImmutable('now', new DateTimeZone('UTC')))
                            ->format('Y-m-d\TH:i:s\Z'),
        'carencia'    => SHIELD_LICENCA_CARENCIA_DIAS,
        // De onde a licenca saiu. Vai ASSINADO junto com o resto, e e o
        // que faz o ERP parar de mandar o cliente conferir a internet
        // quando o prazo encurta: quem recebe arquivo pede outro arquivo.
        'origem'      => 'arquivo',
        'emissor'     => (string) ($empresa['razao'] ?? ''),
    ];

    // Ver o cabecalho: no arquivo, o fim do contrato que o ERP mostra e o fim
    // do proprio arquivo. Chave nova entra no FIM.
    if ($fim instanceof DateTimeImmutable) {
        $conteudo['contrato_ate'] = $ate->format('Y-m-d');
    }

    return ['conteudo' => $conteudo, 'ate' => $ate, 'limitado' => $limitado];
}
