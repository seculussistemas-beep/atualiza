<?php

/**
 * O teto da API de licenca -- 09/09/2026.
 *
 * BAIXO-3 de docs/auditoria-seguranca.md. `public/api/licenca.php` nao pede
 * senha, se identifica so pelo CNPJ e AUTO-CADASTRA a empresa que nao conhece
 * (funcoes/licenca/licenca_assinada.php). Varrer CNPJs validos enche a base de
 * empresas fantasma e, de quebra, revela quais deles ja sao clientes -- a
 * resposta e diferente.
 *
 * ESTE E O CAMINHO QUE O ERP PERCORRE A CADA ABERTURA DE CAIXA. Do outro lado
 * de uma recusa injusta tem supermercado com fila na frente do PDV. Por isso o
 * desenho e assimetrico:
 *
 *   CHAMADAS -- teto absurdamente folgado. O ERP so revalida a cada 18 horas
 *   (LICENCA_INTERVALO_HORAS, no uLicencaEmissor.pas), entao ate uma loja de
 *   vinte caixas com reinicio e tentativa perdida fica uma ordem de grandeza
 *   abaixo. Este teto existe contra martelo, nao contra uso.
 *
 *   CNPJS DISTINTOS POR IP -- teto apertado, e sem risco nenhum: loja de
 *   verdade tem UM CNPJ. E ele que pega a varredura, que e o ataque real, e
 *   nao ha cliente legitimo perto dele.
 *
 * NAO GRAVA NADA. A contagem sai de `terminal_batida`, que a propria API ja
 * escreve uma linha por chamada -- tabela propria dobraria a escrita no caminho
 * mais quente do painel. A compactacao do parque so mexe em dia anterior
 * (SHIELD_PARQUE_DIAS_DETALHE), entao a janela de uma hora sempre le linha
 * crua.
 *
 * FALHA ABERTO, e isto e deliberado, nao descuido. Tabela ausente, coluna que
 * ainda nao veio pelo /update, banco engasgado: passa. A alternativa e o painel
 * parar de emitir licenca para o parque inteiro por causa de uma migracao
 * pendente -- estrago maior do que o que se esta evitando. E a mesma escolha de
 * funcoes/acesso/limite_login.php.
 *
 * E A RECUSA E BARATA PARA QUEM ESTA CERTO: o ERP trata resposta que nao e 200
 * como rede fora e segue com o token que ja tem, valido por
 * SHIELD_LICENCA_CARENCIA_DIAS dias. Um falso positivo custa uma revalidacao
 * adiada, nao um caixa parado.
 */

/** A janela que a contagem olha para tras. */
const SHIELD_TETO_API_JANELA_MIN = 60;

/**
 * Chamadas do mesmo CNPJ na janela.
 *
 * Conta larga de proposito: 20 caixas revalidando de 18 em 18 horas dao ~27
 * chamadas por DIA. Cento e vinte por HORA e mais de cem vezes isso.
 */
const SHIELD_TETO_API_POR_CNPJ = 120;

/** Chamadas do mesmo IP. Mais folgado ainda: pode ser um NAT de operadora. */
const SHIELD_TETO_API_POR_IP = 600;

/**
 * CNPJs DIFERENTES vindos do mesmo IP. Este e o teto que morde.
 *
 * Loja tem um CNPJ. Contador que atende varias empresas de um escritorio so
 * cabe com folga; quem varre lista nao cabe na primeira dezena.
 */
const SHIELD_TETO_API_CNPJS_POR_IP = 10;

/**
 * Este pedido pode seguir?
 *
 * Devolve null quando pode. Quando nao pode, devolve o motivo ja escrito para
 * ir no corpo da resposta -- e ele fala com quem opera, nao com quem ataca:
 * nao diz qual teto estourou nem quanto falta.
 */
function shield_teto_api_excedido(PDO $pdo, string $cnpj, string $ip): ?string
{
    try {
        // NAO HA CHECAGEM DE ESQUEMA AQUI, e e de proposito -- 09/09/2026. A
        // primeira versao perguntava ao INFORMATION_SCHEMA se a tabela e a
        // coluna existiam, e isso somava consultas de catalogo a CADA abertura
        // de caixa do parque inteiro: o teto, que existe para proteger o
        // painel, sairia caro justamente no uso normal.
        //
        // Tabela ausente ou coluna que ainda nao veio pelo /update fazem a
        // consulta abaixo levantar, e o catch devolve null -- que e exatamente
        // a mesma resposta, sem custo nenhum no caminho feliz.

        // A janela entra como inteiro literal, e nao como parametro: INTERVAL
        // nao aceita placeholder em prepare NATIVO. E constante do codigo,
        // nunca entrada de usuario. Mesmo motivo de limite_login.php.
        $janela = (int) SHIELD_TETO_API_JANELA_MIN;
        $desde = 'batido_em > (NOW() - INTERVAL ' . $janela . ' MINUTE)';

        $cnpj = preg_replace('/\D+/', '', $cnpj);
        if ($cnpj !== '') {
            // SUM(quantas) e nao COUNT(*): linha compactada vale pelo tanto que
            // representa. Hoje ela nunca esta compactada, mas contar errado o
            // dia em que a janela crescer seria um bug silencioso.
            $stmt = $pdo->prepare(
                'SELECT COALESCE(SUM(quantas), 0) FROM terminal_batida
                  WHERE cnpj = :cnpj AND ' . $desde
            );
            $stmt->execute(array(':cnpj' => $cnpj));

            if ((int) $stmt->fetchColumn() > SHIELD_TETO_API_POR_CNPJ) {
                return 'Muitas consultas de licenca em pouco tempo. Tente de novo em alguns minutos.';
            }
        }

        // IP vazio nao vira chave: proxy mal configurado colocaria o parque
        // inteiro num balde so, e o primeiro cliente a bater derrubaria todos
        // os outros. Sem IP, so o teto por CNPJ vale.
        $ip = trim($ip);
        if ($ip === '') {
            return null;
        }

        // Se a coluna `ip` ainda nao veio pelo /update, esta consulta levanta e
        // o catch la embaixo devolve null. A contagem por IP simplesmente nao
        // existe naquela instalacao, e a por CNPJ, que ja rodou acima, vale.
        $stmt = $pdo->prepare(
            'SELECT COALESCE(SUM(quantas), 0) AS chamadas, COUNT(DISTINCT cnpj) AS documentos
               FROM terminal_batida
              WHERE ip = :ip AND ' . $desde
        );
        $stmt->execute(array(':ip' => substr($ip, 0, 45)));
        $linha = $stmt->fetch(PDO::FETCH_ASSOC) ?: array();

        if ((int) ($linha['documentos'] ?? 0) > SHIELD_TETO_API_CNPJS_POR_IP) {
            return 'Muitas consultas de licenca em pouco tempo. Tente de novo em alguns minutos.';
        }

        if ((int) ($linha['chamadas'] ?? 0) > SHIELD_TETO_API_POR_IP) {
            return 'Muitas consultas de licenca em pouco tempo. Tente de novo em alguns minutos.';
        }

        return null;
    } catch (Throwable $ignorado) {
        // Ver "falha aberto" no topo.
        return null;
    }
}

/** O IP de quem chamou, no formato que a coluna aceita. */
function shield_teto_api_ip(): string
{
    return substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
}
