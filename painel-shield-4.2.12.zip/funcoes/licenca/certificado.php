<?php

/**
 * O certificado digital do cliente -- 10/09/2026.
 *
 * O ERP passou a mandar, na batida, `certificado_vence` (AAAA-MM-DD). E
 * informacao de GESTAO: o ERP nao condiciona a licenca ao certificado, e o
 * painel nao condiciona tambem. O que dois membros pediram no forum: coluna na
 * lista de clientes, filtro "vencido ou vencendo", e alerta em 30, 15, 7 e 3
 * dias -- para o membro ver sem ligar para o cliente.
 */

/**
 * Grava o que o ERP mandou. Devolve a data gravada, ou null quando o texto
 * nao e data (ausente = "nao ha certificado configurado", e nao apaga o que
 * ja se sabia: um ERP antigo nao manda o campo e nao pode zerar a coluna).
 *
 * Base sem a coluna (anterior a 4.1.0) engole o erro: a licenca segue.
 *
 * A RENOVACAO FICA NO LIVRO (08/10/2026). $anterior e a data que o painel ja
 * tinha -- a API passa a da linha que ela ja leu, para isto nao custar uma
 * consulta a mais no caminho mais quente do painel. Quando o UPDATE muda a data
 * e havia uma antes, entra `certificado_renovado` na auditoria com as duas: a
 * coluna so guarda a de hoje, e e o livro que conta a historia. A primeira data
 * informada nao e renovacao e nao entra. Sem $anterior (quem chama nao sabe),
 * nada e registrado, e a gravacao segue igual.
 */
function shield_certificado_gravar(PDO $pdo, $empresa, $texto, $anterior = null)
{
    $texto = substr(trim((string) $texto), 0, 10);
    $data = DateTimeImmutable::createFromFormat('!Y-m-d', $texto);
    if (!$data instanceof DateTimeImmutable || $data->format('Y-m-d') !== $texto) {
        return null;
    }

    try {
        $st = $pdo->prepare(
            'UPDATE empresa SET certificado_vence = :d
              WHERE codigo = :c AND (certificado_vence IS NULL OR certificado_vence <> :d2)'
        );
        $st->execute(array(':d' => $texto, ':c' => (int) $empresa, ':d2' => $texto));
        $mudou = $st->rowCount() > 0;
    } catch (Throwable $semColuna) {
        return null;
    }

    $antes = substr(trim((string) $anterior), 0, 10);
    if ($mudou && $antes !== '' && $antes !== '0000-00-00' && $antes !== $texto && function_exists('shield_auditar')) {
        // shield_auditar engole a propria falha: o livro nunca derruba a licenca.
        shield_auditar($pdo, 'certificado_renovado', array(
            'alvo_tipo' => 'empresa', 'alvo_id' => (int) $empresa,
            'antes' => $antes, 'depois' => $texto,
            'ator' => 'ERP', 'detalhe' => 'certificado digital informado pelo ERP',
        ));
    }

    return $texto;
}

/**
 * As renovacoes do certificado de um cliente, da mais recente para a mais
 * antiga: array de ['quando' => datetime, 'antes' => Y-m-d, 'depois' => Y-m-d].
 * Le o livro (shield_certificado_gravar acima). Base sem auditoria: vazio.
 */
function shield_certificado_renovacoes(PDO $pdo, $empresa, $limite = 5)
{
    try {
        $st = $pdo->prepare(
            "SELECT quando, antes, depois FROM auditoria
              WHERE acao = 'certificado_renovado' AND alvo_tipo = 'empresa' AND alvo_id = :e
              ORDER BY quando DESC, id DESC LIMIT " . max(1, (int) $limite)
        );
        $st->execute(array(':e' => (string) (int) $empresa));

        return $st->fetchAll(PDO::FETCH_ASSOC) ?: array();
    } catch (Throwable $semTabela) {
        return array();
    }
}

/**
 * Como mostrar a data na tela: ['dias' => int|null, 'cor' => ok|atencao|erro|neutro,
 * 'rotulo' => texto curto]. Sem data: neutro, "sem certificado".
 */
function shield_certificado_situacao($vence, $hoje = null)
{
    $vence = substr(trim((string) $vence), 0, 10);
    if ($vence === '' || $vence === '0000-00-00') {
        return array('dias' => null, 'cor' => 'neutro', 'rotulo' => 'sem certificado');
    }

    $hoje = new DateTimeImmutable($hoje ?: 'today');
    $dias = (int) $hoje->diff(new DateTimeImmutable($vence))->format('%r%a');

    if ($dias < 0) {
        return array('dias' => $dias, 'cor' => 'erro', 'rotulo' => 'vencido há ' . abs($dias) . ' dia' . (abs($dias) === 1 ? '' : 's'));
    }
    if ($dias === 0) {
        return array('dias' => 0, 'cor' => 'erro', 'rotulo' => 'vence hoje');
    }
    if ($dias <= 7) {
        return array('dias' => $dias, 'cor' => 'erro', 'rotulo' => 'vence em ' . $dias . ' dia' . ($dias === 1 ? '' : 's'));
    }
    if ($dias <= 30) {
        return array('dias' => $dias, 'cor' => 'atencao', 'rotulo' => 'vence em ' . $dias . ' dias');
    }

    return array('dias' => $dias, 'cor' => 'ok', 'rotulo' => 'vence ' . date('d/m/Y', strtotime($vence)));
}

/**
 * Quem tem o certificado vencido ou vencendo em ate $dias -- 05/10/2026.
 *
 * O bloco da Central: o filtro da lista de clientes (`cert=30`) ja existia, mas
 * so achava quem fosse procurar, e o pedido do grupo foi o aviso. A janela e a
 * MESMA do filtro, para o "ver todos" levar a lista com o mesmo recorte.
 *
 * Encerrado fica de fora: nao e mais cliente, e o certificado dele nao e
 * assunto do membro. Mais vencido primeiro, porque ja e nota que nao sai.
 * Base sem a coluna (anterior a 4.1.0) devolve vazio, e a Central segue.
 */
/**
 * O SQL de "vencido ou vence em ate N dias" -- 19/10/2026. Um lugar so, porque
 * tres lugares contam a mesma coisa: o bloco da Central, o badge da lateral e a
 * tela Certificados digitais. Encerrado fica de fora nos tres. Os dias entram
 * como literal inteiro: o badge repete a condicao num SELECT sem marcador.
 */
function shield_certificado_onde_vencendo($dias = 30)
{
    return 'certificado_vence IS NOT NULL'
        . ' AND certificado_vence <= DATE_ADD(CURDATE(), INTERVAL ' . max(0, (int) $dias) . ' DAY)'
        . ' AND encerrado_em IS NULL';
}

function shield_certificado_vencendo(PDO $pdo, $dias = 30, $limite = 6)
{
    try {
        $st = $pdo->prepare(
            'SELECT codigo, razao, cnpj, fone, certificado_vence
               FROM empresa
              WHERE ' . shield_certificado_onde_vencendo($dias) . '
              ORDER BY certificado_vence, codigo
              LIMIT ' . max(1, (int) $limite)
        );
        $st->execute();

        return $st->fetchAll(PDO::FETCH_ASSOC) ?: array();
    } catch (Throwable $semColuna) {
        return array();
    }
}
