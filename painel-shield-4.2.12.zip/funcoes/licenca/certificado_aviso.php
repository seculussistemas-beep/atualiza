<?php

/**
 * O aviso do certificado digital vencendo, por e-mail -- 08/10/2026.
 *
 * Pedido no grupo ("implementacao primordial e o controle de vencimento do
 * certificado digital"), desenhado pelo membro com alertas em 30, 15, 7 e 3
 * dias. A Central ja mostrava quem vence em 30 dias (4.1.49), mas so para quem
 * abre a Central; este e o aviso que chega.
 *
 * PARA O MEMBRO, e nao para a loja: e ele quem vende a renovacao, e o ERP ja
 * avisa a loja na tela dela. Vai para o e-mail de Minha empresa e, sem ele, para
 * os administradores.
 *
 * UM E-MAIL POR DIA NO MAXIMO, com a lista de quem ENTROU numa faixa nova desde o
 * ultimo aviso -- e nao um e-mail por cliente, que viraria spam no dia em que
 * vinte certificados vencem juntos. A faixa e a menor de 30, 15, 7, 3 e 0 (ja
 * venceu) que cabe nos dias que faltam. A memoria (`certificado_avisos` em
 * shield_system_meta, codigo => "vence|faixa") e o que impede repetir: cada
 * cliente aparece uma vez por faixa, e a data nova de uma renovacao zera a
 * contagem sozinha, porque a memoria guarda a data que avisou. Contar por faixa,
 * e nao pelo dia exato, e de proposito: o cron que nao rodou no dia 30 ainda
 * avisa no 29.
 *
 * SO COM SMTP CONFIGURADO. Sem ele nada e enfileirado e a memoria nao anda: o
 * membro que configurar o e-mail depois recebe o aviso de quem esta na faixa.
 */

require_once __DIR__ . '/certificado.php';
require_once __DIR__ . '/../cobranca/cobranca_motor.php'; // a fila de trabalho, que o email.php usa e nao carrega
require_once __DIR__ . '/../notificacao/email.php';
require_once __DIR__ . '/situacao.php'; // shield_cnpj, shield_telefone

const SHIELD_CERTIFICADO_FAIXAS = array(30, 15, 7, 3, 0);
const SHIELD_CERTIFICADO_AVISOS_META = 'certificado_avisos';
const SHIELD_CERTIFICADO_AVISO_DIA_META = 'certificado_aviso_dia';

/** A faixa dos dias que faltam (negativo = vencido), ou null fora de todas. */
function shield_certificado_faixa($dias)
{
    $dias = (int) $dias;
    $faixa = null;
    foreach (SHIELD_CERTIFICADO_FAIXAS as $f) {
        if ($dias <= $f) {
            $faixa = $f;
        }
    }

    return $faixa;
}

/** Para quem o aviso vai: o e-mail de Minha empresa, ou o dos administradores. */
function shield_certificado_aviso_destinos(PDO $pdo)
{
    try {
        $email = trim((string) $pdo->query('SELECT email FROM softhouse LIMIT 1')->fetchColumn());
        if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return array($email);
        }
    } catch (Throwable $semColuna) {
        // softhouse sem a coluna (anterior a V4_2_8): segue para os administradores.
    }

    $destinos = array();
    try {
        foreach ($pdo->query("SELECT email FROM usuario WHERE TRIM(acesso) = '1'")->fetchAll(PDO::FETCH_COLUMN) as $e) {
            $e = trim((string) $e);
            if ($e !== '' && filter_var($e, FILTER_VALIDATE_EMAIL)) {
                $destinos[$e] = true;
            }
        }
    } catch (Throwable $semTabela) {
    }

    return array_keys($destinos);
}

/**
 * Quem entrou numa faixa nova. Devolve [linhas, memoria nova]: as linhas sao
 * as de shield_certificado_vencendo com 'dias' e 'faixa'; a memoria e a que
 * deve ser gravada se o aviso sair. Nao grava nada.
 */
function shield_certificado_aviso_pendentes(PDO $pdo, array $memoria, ?string $hoje = null)
{
    $hoje = new DateTimeImmutable($hoje ?? 'today');
    $novas = array();
    $nova = array();

    foreach (shield_certificado_vencendo($pdo, 30, 1000) as $c) {
        $vence = substr((string) $c['certificado_vence'], 0, 10);
        $dias = (int) $hoje->diff(new DateTimeImmutable($vence))->format('%r%a');
        $faixa = shield_certificado_faixa($dias);
        if ($faixa === null) {
            continue;
        }
        $codigo = (string) (int) $c['codigo'];
        $nova[$codigo] = $vence . '|' . $faixa;

        list($venceAvisado, $faixaAvisada) = array_pad(explode('|', (string) ($memoria[$codigo] ?? '')), 2, '');
        if ($venceAvisado === $vence && $faixaAvisada !== '' && (int) $faixaAvisada <= $faixa) {
            continue; // ja avisado nesta faixa (ou numa mais apertada) para esta mesma data
        }
        $c['dias'] = $dias;
        $c['faixa'] = $faixa;
        $novas[] = $c;
    }

    // Quem saiu da janela (renovou para longe, ou foi encerrado) sai da memoria:
    // ela so guarda quem esta dentro dos 30 dias.
    return array($novas, $nova);
}

/** O e-mail do resumo, com a marca do membro. */
function shield_certificado_aviso_email(PDO $pdo, array $linhas)
{
    $e = static function ($t) {
        return htmlspecialchars((string) $t, ENT_QUOTES, 'UTF-8');
    };
    $n = count($linhas);
    $titulo = $n === 1 ? 'Certificado digital vencendo: 1 cliente' : 'Certificados digitais vencendo: ' . $n . ' clientes';

    $tabela = '<table style="width:100%;border-collapse:collapse;font-size:14px">';
    foreach ($linhas as $c) {
        $sit = shield_certificado_situacao($c['certificado_vence']);
        $cor = $sit['cor'] === 'erro' ? '#b42318' : '#9a6700';
        $fone = trim((string) ($c['fone'] ?? ''));
        $tabela .= '<tr><td style="padding:8px 0;border-bottom:1px solid #eee">'
            . '<strong>' . $e($c['razao']) . '</strong><br>'
            . '<span style="color:#666;font-size:12px">' . $e(function_exists('shield_cnpj') ? shield_cnpj($c['cnpj']) : $c['cnpj'])
            . ($fone !== '' ? ' &middot; ' . $e(function_exists('shield_telefone') ? shield_telefone($fone) : $fone) : '') . '</span></td>'
            . '<td style="padding:8px 0;border-bottom:1px solid #eee;text-align:right;white-space:nowrap">'
            . $e(date('d/m/Y', strtotime((string) $c['certificado_vence']))) . '<br>'
            . '<span style="color:' . $cor . ';font-size:12px">' . $e($sit['rotulo']) . '</span></td></tr>';
    }
    $tabela .= '</table>';

    $corpo = '<p>O certificado digital destes clientes vence nos pr&oacute;ximos 30 dias ou j&aacute; venceu. '
        . 'Sem ele a loja para de emitir nota.</p>' . $tabela
        . '<p style="color:#666;font-size:12px">Cada cliente aparece de novo s&oacute; quando faltar menos: 15, 7 e 3 dias, e no vencimento.</p>';

    $base = rtrim(trim((string) shield_env('SHIELD_APP_URL', '')), '/');

    return array(
        'assunto' => $titulo,
        'html' => shield_email_molde($pdo, $titulo, $corpo, $base !== '' ? 'Ver os clientes' : '', $base !== '' ? $base . '/clientes.php?cert=30' : ''),
    );
}

/**
 * A passada do relogio. Uma vez por dia; so com SMTP. Devolve uma frase para a
 * linha do cron. A memoria so anda quando o e-mail foi para a fila.
 *
 * $comSmtp e $destinos sao as duas perguntas ao ambiente, e o cron nao as passa
 * (null = pergunta). O teste passa: o SMTP da bancada vem do .env, e "sem SMTP"
 * nao se simula tirando uma variavel.
 */
function shield_certificado_aviso_passar(PDO $pdo, ?string $hoje = null, ?bool $comSmtp = null, ?array $destinos = null)
{
    $dia = (new DateTimeImmutable($hoje ?? 'today'))->format('Y-m-d');
    if ((string) shield_get_system_meta($pdo, SHIELD_CERTIFICADO_AVISO_DIA_META, '') === $dia) {
        return 'ja passou hoje';
    }
    if (!($comSmtp ?? shield_email_configurado($pdo))) {
        return 'sem e-mail configurado';
    }
    shield_set_system_meta($pdo, SHIELD_CERTIFICADO_AVISO_DIA_META, $dia);

    $memoria = json_decode((string) shield_get_system_meta($pdo, SHIELD_CERTIFICADO_AVISOS_META, '{}'), true);
    list($linhas, $nova) = shield_certificado_aviso_pendentes($pdo, is_array($memoria) ? $memoria : array(), $dia);
    if ($linhas === array()) {
        shield_set_system_meta($pdo, SHIELD_CERTIFICADO_AVISOS_META, json_encode((object) $nova));

        return 'nenhum certificado entrou em faixa nova';
    }

    $destinos = $destinos ?? shield_certificado_aviso_destinos($pdo);
    if ($destinos === array()) {
        return count($linhas) . ' para avisar, mas sem e-mail de destino (preencha o de Minha empresa)';
    }

    $m = shield_certificado_aviso_email($pdo, $linhas);
    $foram = 0;
    foreach ($destinos as $para) {
        if (shield_email_enfileirar($pdo, $para, $m['assunto'], $m['html'])) {
            $foram++;
        }
    }
    if ($foram > 0) {
        shield_set_system_meta($pdo, SHIELD_CERTIFICADO_AVISOS_META, json_encode((object) $nova));
    }

    return count($linhas) . ' cliente(s) no aviso, ' . $foram . ' e-mail(s) na fila';
}
