<?php

/**
 * Os quatro estados de uma maquina -- 10/09/2026, fatia 3 da
 * reorganizacao (docs/reorganizacao-do-painel.md, secao 3).
 *
 *   trabalhando  deu sinal nos ultimos 3 dias
 *   calada       mais de 3 dias sem sinal, AINDA OCUPA VAGA (ate o 30o dia)
 *   vaga_livre   mais de 30 dias sem sinal (ou nunca): a vaga voltou sozinha
 *   desativada   o membro liberou a vaga a mao
 *
 * A tela conhecia dois ("vivo" e "sem sinal") e a cota conhecia outros dois
 * (30 dias e desativado), e o membro nao tinha como saber por que a tela
 * dizia "sem sinal" e a cota continuava ocupada. A "calada" e o estado que
 * responde isso, e so nela aparece "ocupa vaga ate DD/MM".
 *
 * OS DOIS CORTES SAO DIFERENTES DE PROPOSITO: tres dias e convencao de tela
 * (SHIELD_PARQUE_DIAS_SUMIDO); trinta esta compilado no ERP instalado em cada
 * loja (SHIELD_LICENCA_DIAS_FANTASMA), porque ele tambem decide a cota sem
 * internet. Mudar um lado so faz a mesma maquina receber uma resposta com
 * internet e outra sem.
 *
 * UMA FUNCAO DECIDE (shield_terminal_estado) e a MESMA REGRA vira SQL
 * (shield_terminal_estado_sql), para o filtro da lista e a pilula da linha
 * nao discordarem.
 */

require_once __DIR__ . '/parque.php';           // SHIELD_PARQUE_DIAS_SUMIDO
require_once __DIR__ . '/licenca_assinada.php'; // SHIELD_LICENCA_DIAS_FANTASMA
require_once __DIR__ . '/situacao.php';         // shield_situacao_licenca (e o teste, por tabela)

/** O catalogo, na ordem em que a tela mostra. */
function shield_terminal_estados()
{
    return array(
        'trabalhando' => array('rotulo' => 'trabalhando', 'cor' => 'ok', 'icone' => 'fa-broadcast-tower'),
        // Icones do subconjunto public/css/icones.css: os tres de antes
        // (volume-mute, door-open, power-off) nao existiam la e desenhavam nada.
        'calada' => array('rotulo' => 'calada', 'cor' => 'atencao', 'icone' => 'fa-hourglass-half'),
        'vaga_livre' => array('rotulo' => 'vaga livre', 'cor' => 'neutro', 'icone' => 'fa-desktop'),
        'desativada' => array('rotulo' => 'desativada', 'cor' => 'neutro', 'icone' => 'fa-times-circle'),
    );
}

/**
 * A LOJA DESTA MAQUINA PODE ABRIR AGORA? -- 11/09/2026. Devolve null quando
 * pode, e a situacao da empresa (chave, rotulo, cor) quando nao pode.
 *
 * O estado de terminal responde outra pergunta: "esta maquina ocupa vaga?", e
 * para isso dar sinal basta. Mas quem le a tela le "trabalhando" como "o caixa
 * esta operando" -- e com a empresa bloqueada o painel responde
 * `status = bloqueada` no token e o ERP abre sem deixar fazer nada. Visto em
 * producao em 11/09/2026: a lista dizia "Trabalhando" com o operador parado.
 *
 * Nao vira um quinto estado de proposito: shield_terminal_estado_sql espelha
 * os quatro para o filtro e para os contadores, e estado que existe so no PHP
 * faria a lista e a contagem discordarem. Isto aqui e uma SEGUNDA informacao
 * na linha, nao outra resposta para a mesma pergunta.
 *
 * O LEAD DENTRO DO TESTE NAO ESTA PARADO: a avaliacao de sete dias e licenca
 * emprestada de verdade (4.1.5), e a situacao dele so diz 'sem_licenca'
 * porque nada foi gravado.
 */
function shield_terminal_loja_parada(array $empresa)
{
    if (!function_exists('shield_situacao_licenca')) {
        return null;
    }
    $s = shield_situacao_licenca($empresa);
    if (in_array($s['chave'], array('encerrado', 'suspenso', 'bloqueado', 'vencido'), true)) {
        return $s;
    }
    if ($s['chave'] === 'sem_licenca' && !shield_teste_vigente($empresa)) {
        return $s;
    }

    return null;
}

/**
 * O estado de uma linha de `terminais`. Devolve chave, rotulo, cor, detalhe
 * (texto de apoio para a linha) e ocupa_ate (Y-m-d, so na calada).
 *
 * Aceita as duas caixas de coluna (ULTIMO_ACESSO / ultimo_acesso).
 */
function shield_terminal_estado(array $t, $agora = null)
{
    $agora = $agora !== null ? strtotime((string) $agora) : time();
    $catalogo = shield_terminal_estados();

    $desativado = trim((string) ($t['DESATIVADO_EM'] ?? $t['desativado_em'] ?? '')) !== '';
    if ($desativado) {
        $quando = strtotime((string) ($t['DESATIVADO_EM'] ?? $t['desativado_em']));

        return $catalogo['desativada'] + array(
            'chave' => 'desativada',
            'detalhe' => 'vaga liberada em ' . date('d/m/Y', $quando),
            'ocupa_ate' => null,
        );
    }

    $visto = trim((string) ($t['ULTIMO_ACESSO'] ?? $t['ultimo_acesso'] ?? ''));
    $vistoEm = $visto !== '' ? strtotime($visto) : false;
    if ($vistoEm === false) {
        return $catalogo['vaga_livre'] + array(
            'chave' => 'vaga_livre',
            'detalhe' => 'nunca deu sinal',
            'ocupa_ate' => null,
        );
    }

    $dias = (int) floor(($agora - $vistoEm) / 86400);
    if ($dias < SHIELD_PARQUE_DIAS_SUMIDO) {
        return $catalogo['trabalhando'] + array('chave' => 'trabalhando', 'detalhe' => '', 'ocupa_ate' => null);
    }
    if ($dias < SHIELD_LICENCA_DIAS_FANTASMA) {
        $ocupaAte = date('Y-m-d', $vistoEm + SHIELD_LICENCA_DIAS_FANTASMA * 86400);

        return $catalogo['calada'] + array(
            'chave' => 'calada',
            'detalhe' => 'sem sinal há ' . $dias . ' dia' . ($dias === 1 ? '' : 's') . ' · ocupa vaga até ' . date('d/m', strtotime($ocupaAte)),
            'ocupa_ate' => $ocupaAte,
        );
    }

    return $catalogo['vaga_livre'] + array(
        'chave' => 'vaga_livre',
        'detalhe' => 'sem sinal há ' . $dias . ' dias · a vaga voltou sozinha',
        'ocupa_ate' => null,
    );
}

/**
 * A MESMA regra em SQL, para o filtro da lista. Os dois cortes entram como
 * LITERAL (vem de date(), nunca do usuario): a tela repete a mesma condicao
 * varias vezes na mesma consulta (um SUM por estado), e marcador nomeado
 * repetido ou sobrando estoura "number of bound variables does not match".
 * Chave desconhecida devolve '1=1' -- filtro nenhum, nunca lista vazia.
 */
function shield_terminal_estado_sql($chave, $alias = 't', $agora = null)
{
    $a = $alias !== '' ? $alias . '.' : '';
    $cortes = shield_terminal_cortes($agora);
    $c3 = "'" . $cortes[':corte3'] . "'";
    $c30 = "'" . $cortes[':corte30'] . "'";
    $ativa = $a . 'DESATIVADO_EM IS NULL';
    switch ((string) $chave) {
        case 'trabalhando':
            return '(' . $ativa . ' AND ' . $a . 'ULTIMO_ACESSO >= ' . $c3 . ')';
        case 'calada':
            return '(' . $ativa . ' AND ' . $a . 'ULTIMO_ACESSO < ' . $c3 . ' AND ' . $a . 'ULTIMO_ACESSO >= ' . $c30 . ')';
        case 'vaga_livre':
            return '(' . $ativa . ' AND (' . $a . 'ULTIMO_ACESSO IS NULL OR ' . $a . 'ULTIMO_ACESSO < ' . $c30 . '))';
        case 'desativada':
            return '(' . $a . 'DESATIVADO_EM IS NOT NULL)';
        case 'sem_vaga_livre':
            // A lista de todo dia: vaga livre fica atras do filtro.
            return 'NOT ' . shield_terminal_estado_sql('vaga_livre', $alias, $agora);
    }

    return '1=1';
}

/**
 * O QUE A LINHA DA MAQUINA OFERECE -- 14/09/2026. As acoes na ordem em que a
 * tela de Terminais desenha os botoes.
 *
 *   trabalhando  'trocar', sempre desde 01/10/2026 (abaixo). Liberar a vaga de
 *                quem deu sinal agora e desligar o caixa da loja pelo painel,
 *                e por isso so passa pelo modal que pede o nome do computador
 *                digitado. Apagar continua fora: o ERP recadastra a maquina na
 *                proxima abertura.
 *   calada       liberar a vaga (o POST confere o corte de novo)
 *   vaga_livre   apagar
 *   desativada   reativar e apagar
 *
 * A TROCA DE COMPUTADOR -- 14/09/2026, pedido do dono. Quem troca o computador
 * da loja esperava tres dias com o novo recusado por cota cheia, ate o velho
 * virar calada. Com `recusa_por_cota` na linha -- a recusa de OUTRA maquina do
 * mesmo cliente que ainda esta de fora (shield_parque_recusas_por_cota,
 * escolhida por shield_terminal_recusa_para_troca) --, e a troca, e o aviso diz
 * quem entra. SEM ela, desde 01/10/2026, e liberar a vaga agora: a maquina
 * tecnica que o suporte liga na conversao de banco ocupava vaga da cota ate
 * virar calada. A calada nao ganha nenhum dos dois: ela ja libera a vaga sem
 * pedir o nome.
 *
 * UMA FUNCAO para o botao e para a coluna. A coluna "Acoes" so existe na
 * tabela em que alguma linha tem botao. Com a trabalhando sempre oferecendo
 * 'trocar' ela passou a aparecer em quase toda tabela -- o preco de a liberacao
 * da maquina tecnica estar a um clique. Se "tem botao?" fosse escrito na tela e "qual
 * botao?" aqui, a acao nova de um estado cairia numa coluna que a outra conta
 * ja tinha tirado da tabela, e o botao sumiria sem erro.
 *
 * O apelido nao entra: tem campo proprio na celula do computador, em todo
 * estado.
 */
function shield_terminal_acoes(array $t, $agora = null)
{
    switch (shield_terminal_estado($t, $agora)['chave']) {
        case 'trabalhando':
            // Sempre, desde 01/10/2026: com recusa por cota e a troca de computador;
            // sem, e liberar a vaga agora (a maquina tecnica da conversao). Os dois
            // passam pelo modal do nome digitado e por shield_terminal_trocar_computador.
            return array('trocar');
        case 'calada':
            return array('liberar');
        case 'vaga_livre':
            return array('apagar');
        case 'desativada':
            return array('reativar', 'apagar');
    }

    return array();
}

/**
 * A recusa que justifica trocar ESTA maquina, ou null -- 14/09/2026. Recebe a
 * lista de um cliente como shield_parque_recusas_por_cota devolve (a mais nova
 * primeiro) e devolve a mais nova de OUTRA maquina.
 *
 * A MAQUINA QUE ESTA ELA MESMA DE FORA NAO GANHA A TROCA, nem com outra
 * recusada ao lado. A conhecida que ficou fora da cota (cota reduzida, ou
 * cadastrada no teste com mais caixas do que o contrato) aparece trabalhando
 * por ate tres dias, porque a recusa nao carimba sinal -- mas ela nao ocupa
 * vaga: shield_licenca_tem_vaga deixa os mais antigos, e a maquina nova conta
 * todos os vivos contra a cota. Liberar a vaga dela nao abre lugar para
 * ninguem, e o aviso prometeria a entrada de uma maquina que continua de fora.
 */
function shield_terminal_recusa_para_troca(array $recusas, $codigoTerminal)
{
    $codigoTerminal = (int) $codigoTerminal;
    $outra = null;
    foreach ($recusas as $recusa) {
        if ($codigoTerminal > 0 && (int) ($recusa['fk_terminal'] ?? 0) === $codigoTerminal) {
            return null;
        }
        if ($outra === null) {
            $outra = $recusa;
        }
    }

    return $outra;
}

/**
 * O NOME DIGITADO E O DESTA MAQUINA? -- 14/09/2026. So o NOME_COMPUTADOR, e
 * nunca o apelido.
 *
 * O apelido e o membro que escreve ("Caixa 1"), sai de memoria e se repete de
 * loja em loja; o nome do Windows e o que o suporte le na tela do cliente para
 * conferir "e essa mesma?" (shield_terminal_maquina_atras). Digitar existe para
 * obrigar a olhar a maquina certa antes de desligar um caixa, e so o nome de
 * fabrica obriga.
 *
 * Sem diferenca de caixa nem de espaco nas pontas: o Windows nao distingue
 * maiuscula no nome do computador, e o JS da tela confere igual (trim e
 * toUpperCase). Cadastro sem nome nunca confere.
 */
function shield_terminal_nome_confere(array $t, $digitado)
{
    $maiuscula = static function ($s) {
        $s = trim((string) $s);

        return function_exists('mb_strtoupper') ? mb_strtoupper($s, 'UTF-8') : strtoupper($s);
    };
    $nome = $maiuscula($t['NOME_COMPUTADOR'] ?? $t['nome_computador'] ?? '');

    return $nome !== '' && $nome === $maiuscula($digitado);
}

/**
 * LIBERA A VAGA DE UMA MAQUINA TRABALHANDO PARA A TROCA DE COMPUTADOR --
 * 14/09/2026, pedido do dono. Devolve array('terminal' => a linha de antes,
 * 'recusa' => a batida que motivou). Recusa com RuntimeException, e nada muda
 * nem entra no livro.
 *
 * O SERVIDOR CONFERE TUDO DE NOVO, e nao confia no botao: a aba pode estar
 * aberta desde antes de a maquina nova entrar, e o formulario pode ser montado
 * a mao. Na ordem: a maquina e deste cliente, esta trabalhando, o nome digitado
 * e o dela, ela mesma nao esta de fora da cota, e o cliente tem OUTRA maquina
 * recusada por cota cheia que ainda esta de fora (shield_parque_recusas_por_cota).
 *
 * O EFEITO E O DO DESATIVAR DE SEMPRE (DESATIVADO_EM/DESATIVADO_POR), e por isso
 * a maquina desligada PARA na proxima abertura do ERP: ela recebe `excedente`
 * com "terminal desativado no painel". Nao ha como ser diferente: a vaga e uma
 * so. Reativar depois so passa enquanto a nova ainda nao entrou: com ela viva
 * a cota esta cheia, e shield_licenca_reativar_terminal recusa.
 *
 * O LIVRO GUARDA O QUE PROVA A DECISAO: a linha de antes, o nome que a pessoa
 * digitou e a batida recusada que abriu o botao. O ator vem da sessao, como em
 * todo shield_auditar.
 */
function shield_terminal_trocar_computador(PDO $pdo, $codigo, $fkEmpresa, $nomeDigitado)
{
    // shield_auditar mora no motor de cobranca. O require e aqui dentro, e nao
    // no topo, porque este arquivo tambem e lido pelos testes de estado e pela
    // trava de apagar, que nao precisam daquilo para decidir nada.
    require_once __DIR__ . '/../cobranca/cobranca.php';

    $codigo = (int) $codigo;
    $fkEmpresa = (int) $fkEmpresa;
    $alvo = false;
    if ($codigo > 0 && $fkEmpresa > 0) {
        $stmt = $pdo->prepare(
            'SELECT t.CODIGO, t.FK_EMPRESA, t.NOME_COMPUTADOR, t.APELIDO, t.MAC, t.ULTIMO_ACESSO,
                    t.DESATIVADO_EM, t.DESATIVADO_POR, t.VERSAO_EXE, e.razao
               FROM terminais t LEFT JOIN empresa e ON e.codigo = t.FK_EMPRESA
              WHERE t.CODIGO = :c AND t.FK_EMPRESA = :e LIMIT 1'
        );
        $stmt->execute(array(':c' => $codigo, ':e' => $fkEmpresa));
        $alvo = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    if (!is_array($alvo)) {
        throw new RuntimeException('Terminal nao encontrado neste cliente. Nada foi mudado.');
    }

    $estado = shield_terminal_estado($alvo);
    if ($estado['chave'] === 'desativada') {
        // F5 depois do sucesso reenvia o mesmo POST: a frase diz que ja foi feito.
        throw new RuntimeException('A vaga desta maquina ja estava liberada desde '
            . date('d/m/Y H:i', strtotime((string) $alvo['DESATIVADO_EM'])) . '. Nada foi mudado.');
    }
    if ($estado['chave'] !== 'trabalhando') {
        throw new RuntimeException('Esta maquina nao esta trabalhando: a troca de computador e so para quem deu sinal nos ultimos '
            . SHIELD_PARQUE_DIAS_SUMIDO . ' dias. A calada tem a vaga liberada pelo botao da propria linha.');
    }
    if (!shield_terminal_nome_confere($alvo, $nomeDigitado)) {
        throw new RuntimeException('O nome digitado nao e o nome do computador desta maquina ('
            . (string) $alvo['NOME_COMPUTADOR'] . '). Nada foi mudado.');
    }

    $recusas = shield_parque_recusas_por_cota($pdo, array($fkEmpresa));
    $doCliente = $recusas[$fkEmpresa] ?? array();
    foreach ($doCliente as $propria) {
        // A frase propria, e nao a de "nenhuma de fora": pode haver outra
        // recusada ao lado, e quem le precisa saber que o problema e ESTA linha.
        if ((int) ($propria['fk_terminal'] ?? 0) === $codigo) {
            throw new RuntimeException('Esta maquina tambem esta sendo recusada por cota cheia (em '
                . date('d/m/Y H:i', strtotime((string) $propria['batido_em'])) . '): ela nao ocupa vaga, e liberar a dela'
                . ' nao abre lugar para ninguem. Nada foi mudado.');
        }
    }
    // SEM RECUSA, A VAGA TAMBEM SE LIBERA -- 01/10/2026, decisao do Victor.
    //
    // Ate aqui a maquina trabalhando so liberava a vaga com outra do mesmo cliente
    // de fora por cota cheia, e sem isso o POST era recusado. Um membro mostrou o
    // caso que essa regra nao cobria: na conversao de banco, o tecnico liga o ERP
    // dele com o CNPJ do cliente, a maquina dele ocupa uma vaga da cota e so podia
    // ser liberada tres dias depois, quando virasse calada. Agora a mesma
    // confirmacao -- o nome do computador digitado -- libera na hora, e o livro
    // registra com acao propria (terminal_vaga_liberada_em_uso), para nao se
    // confundir com a troca, que diz quem entra.
    //
    // O QUE CONTINUA RECUSADO: a maquina que ela mesma esta de fora (acima), e a
    // que nao esta trabalhando (a calada tem o botao da linha).
    $recusa = shield_terminal_recusa_para_troca($doCliente, $codigo);

    // O mesmo UPDATE do desativar da tela, com a guarda de DESATIVADO_EM nulo:
    // duas abas confirmando juntas liberam uma vez so, e a segunda e recusada.
    $usuario = $_SESSION['usuario'] ?? array();
    $ator = substr((string) ($usuario['nome'] ?? $usuario['login'] ?? ''), 0, 80);
    $desativar = $pdo->prepare(
        'UPDATE terminais SET DESATIVADO_EM = NOW(), DESATIVADO_POR = :q
          WHERE CODIGO = :c AND DESATIVADO_EM IS NULL'
    );
    $desativar->execute(array(':q' => $ator, ':c' => $codigo));
    if ($desativar->rowCount() <= 0) {
        throw new RuntimeException('A vaga desta maquina acabou de ser liberada em outra aba. Nada foi mudado.');
    }

    $digitado = substr(trim((string) $nomeDigitado), 0, 50);

    if ($recusa === null) {
        shield_auditar($pdo, 'terminal_vaga_liberada_em_uso', array(
            'alvo_tipo' => 'terminal',
            'alvo_id' => $codigo,
            'antes' => $alvo,
            'depois' => array('nome_digitado' => $digitado),
            'detalhe' => 'vaga de ' . (string) $alvo['NOME_COMPUTADOR'] . ' liberada com a maquina em uso, sem maquina de fora'
                . ' por cota cheia; digitado: ' . $digitado,
        ));

        return array('terminal' => $alvo, 'recusa' => null, 'entra' => '');
    }
    $recusada = trim((string) ($recusa['nome_computador'] ?? ''));
    shield_auditar($pdo, 'terminal_troca_computador', array(
        'alvo_tipo' => 'terminal',
        'alvo_id' => $codigo,
        'antes' => $alvo,
        'depois' => array(
            'nome_digitado' => $digitado,
            'recusada' => array(
                'batida' => (int) $recusa['id'],
                'nome_computador' => $recusada,
                'fingerprint' => (string) ($recusa['fingerprint'] ?? ''),
                'fk_terminal' => $recusa['fk_terminal'] !== null ? (int) $recusa['fk_terminal'] : null,
                'batido_em' => (string) $recusa['batido_em'],
                'motivo' => (string) $recusa['motivo'],
            ),
        ),
        'detalhe' => 'vaga de ' . (string) $alvo['NOME_COMPUTADOR'] . ' liberada para troca de computador; recusada por cota cheia: '
            . ($recusada !== '' ? $recusada : 'maquina sem nome') . ' em ' . date('d/m/Y H:i', strtotime((string) $recusa['batido_em']))
            . '; digitado: ' . $digitado,
    ));

    // QUEM ENTRA NA VAGA (15/09/2026). shield_licenca_tem_vaga deixa os CODIGO mais
    // antigos: havendo maquina JA CADASTRADA de fora por cota, e a mais antiga
    // delas que pega a vaga na proxima batida, e nao a nova -- o aviso prometia a
    // nova. Sem conhecida de fora, entra a nova recusada.
    $entra = trim((string) ($recusa['nome_computador'] ?? ''));
    $conhecidas = array();
    foreach ($doCliente as $deFora) {
        $fk = $deFora['fk_terminal'] ?? null;
        if ($fk !== null && $fk !== '' && (int) $fk !== $codigo) {
            $conhecidas[(int) $fk] = trim((string) ($deFora['nome_computador'] ?? ''));
        }
    }
    if ($conhecidas !== array()) {
        ksort($conhecidas);
        $entra = (string) reset($conhecidas);
    }

    return array('terminal' => $alvo, 'recusa' => $recusa, 'entra' => $entra);
}

/** Os dois cortes como datetime. */
function shield_terminal_cortes($agora = null)
{
    $agora = $agora !== null ? strtotime((string) $agora) : time();

    return array(
        ':corte3' => date('Y-m-d H:i:s', $agora - SHIELD_PARQUE_DIAS_SUMIDO * 86400),
        ':corte30' => date('Y-m-d H:i:s', $agora - SHIELD_LICENCA_DIAS_FANTASMA * 86400),
    );
}
