<?php

/**
 * Liberacao em confianca -- 10/09/2026.
 *
 * Cinco membros dao "mais uns dias" ao cliente apertado, hoje por telefone; o
 * corte automatico pega a loja num domingo e alguem tem de atender. O ERP
 * passou a ter o botao (acao `liberar_confianca`), e este arquivo e a
 * decisao do lado do painel.
 *
 * O DESENHO E O DA PROMESSA DE PAGAMENTO (docs/terminais-validade-e-promessa.md,
 * secao 4): uma linha em promessa_pagamento, nunca uma edicao de cadastro. A
 * validade continua vencida, o bloqueio continua como esta, a cobranca segue
 * na regua. O unico efeito e no token da proxima batida, que passa a valer
 * ate a data prometida -- e so ate ela, entao a promessa se liquida sozinha.
 *
 * AS TRAVAS, que o proprio Delphi pediu ("sem trava isto vira mensalidade
 * opcional"): N dias configuravel (zero desliga; o padrao e 3), um teto de
 * vezes por doze meses, uma aberta por vez (indice unico no banco), e cada
 * concessao no livro de auditoria com quem pediu.
 */

require_once __DIR__ . '/../cobranca/cobranca.php'; // shield_auditar

const SHIELD_CONFIANCA_CHAVE_DIAS = 'confianca_dias';
const SHIELD_CONFIANCA_CHAVE_POR_ANO = 'confianca_por_ano';

/** Vencendo em ate tantos dias ja conta como "apertado". */
const SHIELD_CONFIANCA_JANELA_DIAS = 3;
// NASCE LIGADA -- 11/09/2026 (nascia com 0, desligada). E o corte de todo
// mundo: a licenca para no dia seguinte ao vencimento, e os dias de
// tolerancia que os membros davam por telefone sao estes, pelo botao do
// ERP. Quem nao quer desliga na regua (0 dias); a regua continua mandando.
const SHIELD_CONFIANCA_DIAS_PADRAO = 3;

/** ['dias' => int, 'por_ano' => int]. Dias zero = desligado; o padrao e SHIELD_CONFIANCA_DIAS_PADRAO. */
function shield_confianca_config(PDO $pdo)
{
    try {
        return array(
            'dias' => max(0, (int) shield_get_system_meta($pdo, SHIELD_CONFIANCA_CHAVE_DIAS, (string) SHIELD_CONFIANCA_DIAS_PADRAO)),
            'por_ano' => max(1, (int) shield_get_system_meta($pdo, SHIELD_CONFIANCA_CHAVE_POR_ANO, '1')),
        );
    } catch (Throwable $semTabela) {
        return array('dias' => 0, 'por_ano' => 1);
    }
}

function shield_confianca_definir(PDO $pdo, $dias, $porAno)
{
    shield_set_system_meta($pdo, SHIELD_CONFIANCA_CHAVE_DIAS, (string) max(0, min(30, (int) $dias)));
    shield_set_system_meta($pdo, SHIELD_CONFIANCA_CHAVE_POR_ANO, (string) max(1, min(12, (int) $porAno)));
}

/**
 * A promessa aberta deste cliente, ou null. Promessa cuja data ja passou e
 * fechada aqui como 'vencida' -- e o unico lugar que precisa saber disso, e
 * assim nao ha cron.
 */
function shield_promessa_aberta(PDO $pdo, $empresa, $hoje = null)
{
    $hoje = $hoje ?: date('Y-m-d');
    try {
        $stmt = $pdo->prepare(
            'SELECT * FROM promessa_pagamento WHERE fk_empresa = :e AND aberta = 1 LIMIT 1'
        );
        $stmt->execute(array(':e' => (int) $empresa));
        $p = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($p)) {
            return null;
        }
        if ((string) $p['ate'] < $hoje) {
            $pdo->prepare(
                "UPDATE promessa_pagamento SET situacao = 'vencida', aberta = NULL, fechada_em = NOW()
                  WHERE id = :id AND aberta = 1"
            )->execute(array(':id' => (int) $p['id']));

            return null;
        }

        return $p;
    } catch (Throwable $semTabela) {
        return null;
    }
}

/**
 * O bloco `confianca` da resposta ao ERP, ou null quando o recurso esta
 * desligado ou o cliente nem tem validade (cliente em avaliacao pede
 * fechamento, nao prazo).
 *
 * Devolve ['disponivel' => bool, 'dias' => int, 'motivo' => string]. Sem o
 * bloco o botao nem aparece na tela do cliente. Com disponivel=false o motivo
 * vai para o ERP mostrar -- em 14/09/2026 ele ainda o le e descarta (mostrar
 * e pedido ao lado Delphi), e por isso o motivo tem de ser verdadeiro.
 */
function shield_confianca_oferta(PDO $pdo, array $empresa, $hoje = null)
{
    $cfg = shield_confianca_config($pdo);
    if ($cfg['dias'] <= 0) {
        return null;
    }

    $validade = trim((string) ($empresa['validade_licenca'] ?? ''));
    if ($validade === '' || $validade === '0000-00-00') {
        return null;
    }

    $motivo = shield_confianca_recusa($pdo, $empresa, $cfg, $hoje);

    return array(
        'disponivel' => $motivo === null,
        'dias' => (int) $cfg['dias'],
        'motivo' => (string) ($motivo ?? ''),
    );
}

/** O motivo de nao dar, em portugues para o cliente ler; null quando pode. */
function shield_confianca_recusa(PDO $pdo, array $empresa, array $cfg, $hoje = null)
{
    $hoje = $hoje ?: date('Y-m-d');
    $codigo = (int) ($empresa['codigo'] ?? 0);

    // O BLOQUEIO DE DECISAO VEM ANTES DA JANELA -- 14/09/2026. Na ordem de
    // antes, a loja bloqueada ou encerrada com validade adiante recebia "sua
    // licenca esta em dia", que e mentira para quem esta parado -- e passa a
    // ser lida no dia em que o ERP mostrar o motivo.
    //
    // Encerrado primeiro, como em toda a situacao do cliente (4.1.4). O
    // licenca.php so transforma o encerrado em bloqueio manual DEPOIS de rodar
    // a acao: o liberar_confianca do ERP chega aqui com a linha crua, como a
    // area do cliente, e so encerrado_em diz o que e. Sem este corte o
    // encerrado vencido gastava a vez do ano numa liberacao que o token
    // bloqueado nunca deixa valer.
    if (trim((string) ($empresa['encerrado_em'] ?? '')) !== '') {
        return 'Este cadastro foi encerrado. Fale com o suporte.';
    }

    // Bloqueio MANUAL nao se mascara: e a unica ferramenta do membro para o
    // que nao e divida (troca de CNPJ, fraude, litigio). So a suspensao por
    // divida, que a regua registra em suspenso_em, entra na confianca.
    $bloqueado = strtoupper(trim((string) ($empresa['bloqueado'] ?? ''))) === 'S';
    $suspensoPorDivida = trim((string) ($empresa['suspenso_em'] ?? '')) !== '';
    if ($bloqueado && !$suspensoPorDivida) {
        return 'Este cadastro foi bloqueado pelo suporte. Fale com eles.';
    }

    $validade = substr(trim((string) ($empresa['validade_licenca'] ?? '')), 0, 10);
    $janela = date('Y-m-d', strtotime($hoje . ' +' . SHIELD_CONFIANCA_JANELA_DIAS . ' days'));
    if ($validade > $janela) {
        return 'Sua licenca esta em dia ate ' . date('d/m/Y', strtotime($validade)) . '. A liberacao em confianca e para quem esta vencendo.';
    }

    $aberta = shield_promessa_aberta($pdo, $codigo, $hoje);
    if ($aberta !== null) {
        return 'Voce ja tem uma liberacao ate ' . date('d/m/Y', strtotime((string) $aberta['ate'])) . '. Pague ate la.';
    }

    try {
        // TODOS OS CANAIS CONTAM (11/09/2026): a conta filtrava canal = 'erp',
        // entao quem pedia pela area do cliente nunca gastava o teto e um
        // cliente com teto 1 se liberava sem fim, alternando de onde pedia.
        // So a liberacao em confianca conta (situacao 'aceita' com aberta): o
        // pedido de prazo que alguem do painel decidiu e outra coisa.
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM promessa_pagamento
              WHERE fk_empresa = :e AND ator IN ('automatico (confianca)', 'cliente (confianca)')
                AND criado_em >= DATE_SUB(:hoje, INTERVAL 365 DAY)"
        );
        $stmt->execute(array(':e' => $codigo, ':hoje' => $hoje));
        $usadas = (int) $stmt->fetchColumn();
    } catch (Throwable $semTabela) {
        return 'O painel ainda nao oferece liberacao em confianca.';
    }
    if ($usadas >= (int) $cfg['por_ano']) {
        return 'A liberacao em confianca ja foi usada ' . $usadas . ' vez' . ($usadas === 1 ? '' : 'es')
            . ' nos ultimos doze meses. Fale com o suporte.';
    }

    return null;
}

/**
 * Concede. Devolve ['ok' => bool, 'motivo' => string, 'ate' => 'Y-m-d'|''].
 *
 * OS DIAS CONTAM DO MAIOR ENTRE HOJE E A VALIDADE -- 14/09/2026. Quem venceu
 * ha uma semana e pede agora quer os proximos dias, nao os que ja passaram:
 * a base e hoje. Quem ainda esta vencendo (a janela deixa pedir ate
 * SHIELD_CONFIANCA_JANELA_DIAS antes) contava de hoje tambem, e com validade
 * em hoje + 3 e 3 dias a promessa caia no proprio vencimento: o token nao
 * andava nada e a unica vez do ano era gasta. Com assinatura a validade e o
 * vencimento da proxima fatura, entao isso pegava todo cliente, todo mes.
 */
function shield_confianca_conceder(PDO $pdo, array $empresa, $quemPediu, $canal = 'erp', $hoje = null)
{
    $hoje = $hoje ?: date('Y-m-d');
    $cfg = shield_confianca_config($pdo);
    if ($cfg['dias'] <= 0) {
        return array('ok' => false, 'motivo' => 'O painel nao oferece liberacao em confianca.', 'ate' => '');
    }
    $validade = trim((string) ($empresa['validade_licenca'] ?? ''));
    if ($validade === '' || $validade === '0000-00-00') {
        return array('ok' => false, 'motivo' => 'Cliente sem contrato: fale com o suporte para fechar.', 'ate' => '');
    }

    $motivo = shield_confianca_recusa($pdo, $empresa, $cfg, $hoje);
    if ($motivo !== null) {
        return array('ok' => false, 'motivo' => $motivo, 'ate' => '');
    }

    // Ver o cabecalho. Texto Y-m-d ordena igual a data, entao max() serve.
    $base = max($hoje, substr($validade, 0, 10));
    $ate = date('Y-m-d', strtotime($base . ' +' . (int) $cfg['dias'] . ' days'));
    $codigo = (int) ($empresa['codigo'] ?? 0);
    try {
        $pdo->prepare(
            'INSERT INTO promessa_pagamento (fk_empresa, ate, canal, situacao, quem_pediu, ator, aberta)
             VALUES (:e, :ate, :canal, :sit, :quem, :ator, 1)'
        )->execute(array(
            ':e' => $codigo, ':ate' => $ate, ':canal' => (string) $canal, ':sit' => 'aceita',
            ':quem' => substr((string) $quemPediu, 0, 80),
            // O ator diz QUEM concedeu, e e por ele que o teto conta: as duas
            // formas sao a mesma liberacao em confianca, uma pelo ERP e outra
            // pela area do cliente (11/09/2026).
            ':ator' => $canal === 'erp' ? 'automatico (confianca)' : 'cliente (confianca)',
        ));
    } catch (PDOException $e) {
        // 23000 = ja existe uma aberta: dois caixas pediram no mesmo segundo.
        if ($e->getCode() === '23000') {
            return array('ok' => false, 'motivo' => 'Ja existe uma liberacao aberta para este cliente.', 'ate' => '');
        }
        throw $e;
    }

    shield_auditar($pdo, 'liberacao_em_confianca', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => $codigo,
        'ator' => $canal === 'erp' ? 'ERP do cliente' : (string) $quemPediu,
        'detalhe' => 'liberado em confianca ate ' . date('d/m/Y', strtotime($ate)) . ' (' . (int) $cfg['dias']
            . ' dias) -- pedido por ' . (string) $quemPediu . ' via ' . (string) $canal
            . '; validade no cadastro continua ' . substr($validade, 0, 10),
    ));

    return array('ok' => true, 'motivo' => 'Liberado ate ' . date('d/m/Y', strtotime($ate)) . '. Pague ate la.', 'ate' => $ate);
}

// ------------------------------------------------------ o pedido de prazo ---
//
// "Vou pagar dia 22" pedido de DENTRO do ERP (docs/erp-aviso-de-fim-de-teste.md,
// secao 1) -- lado do painel, 10/09/2026, tarde. Difere da liberacao em
// confianca em uma coisa: aqui ALGUEM decide. O pedido nasce 'pendente' com
// aberta = NULL (nao levanta token nenhum); aceito vira 'aceita' com aberta =
// 1, e dai em diante e a mesma promessa de sempre.

const SHIELD_PROMESSA_CHAVE_TETO = 'promessa_teto_dias';
const SHIELD_PROMESSA_TETO_PADRAO = 7;
/** Recusada continua visivel ao ERP por tantos dias, e some. */
const SHIELD_PROMESSA_RECUSA_VISIVEL_DIAS = 3;

/** Ate quantos dias a frente o cliente pode pedir. */
function shield_promessa_teto(PDO $pdo)
{
    try {
        return max(1, min(60, (int) shield_get_system_meta($pdo, SHIELD_PROMESSA_CHAVE_TETO, (string) SHIELD_PROMESSA_TETO_PADRAO)));
    } catch (Throwable $semTabela) {
        return SHIELD_PROMESSA_TETO_PADRAO;
    }
}

/** O pedido pendente deste cliente, ou null. */
function shield_promessa_pendente(PDO $pdo, $empresa)
{
    try {
        $stmt = $pdo->prepare("SELECT * FROM promessa_pagamento WHERE fk_empresa = :e AND situacao = 'pendente' ORDER BY id DESC LIMIT 1");
        $stmt->execute(array(':e' => (int) $empresa));
        $p = $stmt->fetch(PDO::FETCH_ASSOC);

        return is_array($p) ? $p : null;
    } catch (Throwable $semTabela) {
        return null;
    }
}

/**
 * O cliente pede prazo. Devolve o `acao_resultado` do contrato: 'pedido', ou
 * 'nao_pedido: <motivo>' com os motivos exatos que o doc promete ao ERP.
 */
function shield_promessa_pedir(PDO $pdo, array $empresa, $cobrancaId, $ate, $obs, $quem, $canal = 'erp', $hoje = null)
{
    $hoje = $hoje ?: date('Y-m-d');
    $codigo = (int) ($empresa['codigo'] ?? 0);
    $validade = trim((string) ($empresa['validade_licenca'] ?? ''));
    if ($validade === '' || $validade === '0000-00-00') {
        return 'nao_pedido: cliente sem contrato';
    }
    if ((int) $cobrancaId <= 0) {
        return 'nao_pedido: cobranca nao informada';
    }
    try {
        $stmt = $pdo->prepare("SELECT id FROM cobranca WHERE id = :c AND fk_empresa = :e AND situacao IN ('aberta', 'vencida') LIMIT 1");
        $stmt->execute(array(':c' => (int) $cobrancaId, ':e' => $codigo));
        if ($stmt->fetchColumn() === false) {
            return 'nao_pedido: cobranca nao esta em aberto';
        }
    } catch (Throwable $semTabela) {
        return 'nao_pedido: cobranca nao informada';
    }
    $ate = substr(trim((string) $ate), 0, 10);
    $d = DateTimeImmutable::createFromFormat('!Y-m-d', $ate);
    if (!$d instanceof DateTimeImmutable || $d->format('Y-m-d') !== $ate || $ate < $hoje) {
        return 'nao_pedido: data invalida';
    }
    $teto = shield_promessa_teto($pdo);
    if ($ate > date('Y-m-d', strtotime($hoje . ' +' . $teto . ' days'))) {
        return 'nao_pedido: prazo acima do teto';
    }
    if (shield_promessa_pendente($pdo, $codigo) !== null || shield_promessa_aberta($pdo, $codigo, $hoje) !== null) {
        return 'nao_pedido: ja existe pedido aberto';
    }
    // RECUSADO, ESPERA CINCO HORAS (10/09/2026, noite): um pedido por vez, e
    // depois de um "nao" o botao do ERP so volta a valer cinco horas depois.
    // Sem isso a recusa vira ping-pong com quem esta no painel.
    try {
        $stmt = $pdo->prepare("SELECT 1 FROM promessa_pagamento WHERE fk_empresa = :e AND situacao = 'recusada'
                                  AND fechada_em IS NOT NULL AND fechada_em > DATE_SUB(NOW(), INTERVAL 5 HOUR) LIMIT 1");
        $stmt->execute(array(':e' => $codigo));
        if ($stmt->fetchColumn() !== false) {
            return 'nao_pedido: recusado ha menos de 5 horas';
        }
    } catch (Throwable $semColuna) {
    }

    $pdo->prepare(
        'INSERT INTO promessa_pagamento (fk_empresa, ate, canal, situacao, quem_pediu, motivo, aberta)
         VALUES (:e, :ate, :canal, :sit, :quem, :motivo, NULL)'
    )->execute(array(
        ':e' => $codigo, ':ate' => $ate, ':canal' => substr((string) $canal, 0, 12), ':sit' => 'pendente',
        ':quem' => substr((string) $quem, 0, 80), ':motivo' => substr(trim((string) $obs), 0, 150) ?: null,
    ));
    shield_auditar($pdo, 'promessa_pedida', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => $codigo, 'ator' => (string) $quem,
        'detalhe' => 'pediu prazo ate ' . $d->format('d/m/Y') . ' pela cobranca ' . (int) $cobrancaId . ' via ' . (string) $canal
            . (trim((string) $obs) !== '' ? ' -- ' . trim((string) $obs) : ''),
    ));

    return 'pedido';
}

/** Alguem decidiu. Devolve 'aceita' ou 'recusada'. */
function shield_promessa_decidir(PDO $pdo, $id, $aceitar, $ator)
{
    $stmt = $pdo->prepare("SELECT * FROM promessa_pagamento WHERE id = :id AND situacao = 'pendente' LIMIT 1");
    $stmt->execute(array(':id' => (int) $id));
    $p = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!is_array($p)) {
        throw new RuntimeException('Este pedido de prazo ja foi respondido.');
    }
    if ($aceitar) {
        try {
            $pdo->prepare("UPDATE promessa_pagamento SET situacao = 'aceita', aberta = 1, ator = :a WHERE id = :id")
                ->execute(array(':a' => substr((string) $ator, 0, 80), ':id' => (int) $p['id']));
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                throw new RuntimeException('Ja existe uma promessa aberta para este cliente; ela precisa vencer ou ser cumprida antes.');
            }
            throw $e;
        }
    } else {
        $pdo->prepare("UPDATE promessa_pagamento SET situacao = 'recusada', aberta = NULL, ator = :a, fechada_em = NOW() WHERE id = :id")
            ->execute(array(':a' => substr((string) $ator, 0, 80), ':id' => (int) $p['id']));
    }
    shield_auditar($pdo, $aceitar ? 'promessa_aceita' : 'promessa_recusada', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => (int) $p['fk_empresa'], 'ator' => (string) $ator,
        'detalhe' => ($aceitar ? 'prazo aceito' : 'prazo recusado') . ' ate ' . date('d/m/Y', strtotime((string) $p['ate'])),
    ));

    return $aceitar ? 'aceita' : 'recusada';
}

/**
 * A FRASE DA DECISAO, com o numero que importa (10/09/2026, noite): aceito,
 * quantos dias a loja ganha ate a data prometida; recusado, o que acontece.
 * Texto puro: as telas passam por shield_h.
 */
function shield_promessa_frase(PDO $pdo, $id, $decisao)
{
    $stmt = $pdo->prepare('SELECT ate FROM promessa_pagamento WHERE id = :id');
    $stmt->execute(array(':id' => (int) $id));
    $ate = substr((string) $stmt->fetchColumn(), 0, 10);
    $dias = $ate !== '' ? (int) round((strtotime($ate) - strtotime('today')) / 86400) : 0;
    $quando = $ate !== '' ? date('d/m/Y', strtotime($ate)) : 'a data prometida';
    if ($decisao === 'aceita') {
        return 'Voce aceitou a promessa: a loja ganha ' . max(0, $dias) . ' dia(s) de bonus e trabalha ate ' . $quando
            . '. A fatura continua em aberto; paga, tudo volta ao normal.';
    }

    return 'Voce recusou a promessa. Com a licenca vencida a loja bloqueia; o cliente so pode pedir de novo daqui a 5 horas.';
}

/**
 * O bloco `promessa` da resposta ao ERP: pendente, aceita, ou recusada ha
 * menos de tres dias. Null quando nao ha o que dizer -- o caso de sempre.
 */
function shield_promessa_bloco(PDO $pdo, $empresa, $hoje = null)
{
    $hoje = $hoje ?: date('Y-m-d');
    $p = shield_promessa_pendente($pdo, $empresa);
    if ($p !== null) {
        return array('situacao' => 'pendente', 'ate' => (string) $p['ate']);
    }
    $a = shield_promessa_aberta($pdo, $empresa, $hoje);
    if ($a !== null) {
        return array('situacao' => 'aceita', 'ate' => (string) $a['ate']);
    }
    try {
        $stmt = $pdo->prepare("SELECT ate FROM promessa_pagamento WHERE fk_empresa = :e AND situacao = 'recusada'
                                  AND fechada_em >= DATE_SUB(:hoje, INTERVAL " . (int) SHIELD_PROMESSA_RECUSA_VISIVEL_DIAS . " DAY) ORDER BY id DESC LIMIT 1");
        $stmt->execute(array(':e' => (int) $empresa, ':hoje' => $hoje));
        $ate = $stmt->fetchColumn();

        return $ate !== false ? array('situacao' => 'recusada', 'ate' => (string) $ate) : null;
    } catch (Throwable $semTabela) {
        return null;
    }
}

/**
 * O pagamento entrou: a promessa aberta vira 'cumprida'. Chamada por
 * shield_validade_estender, o unico ponto por onde o dinheiro passa com
 * rastro -- entao webhook, conciliacao e confirmacao manual fecham de graca.
 */
function shield_promessa_cumprir(PDO $pdo, $empresa)
{
    try {
        $pdo->prepare(
            "UPDATE promessa_pagamento SET situacao = 'cumprida', aberta = NULL, fechada_em = NOW()
              WHERE fk_empresa = :e AND aberta = 1"
        )->execute(array(':e' => (int) $empresa));
    } catch (Throwable $semTabela) {
        // Base sem a tabela: nao havia promessa para cumprir.
    }
}
