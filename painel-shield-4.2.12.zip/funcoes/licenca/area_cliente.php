<?php

/**
 * A area do cliente -- 10/09/2026, tarde. Um pedido nomeado no levantamento
 * da comunidade ("Portal do cliente"), e o dono do produto quis que ela
 * abrisse "tanto pelo Delphi quanto na web".
 *
 * POR LINK ASSINADO. O cliente final nao tem conta no painel, e nao vai criar
 * uma para ver um PIX. O que ele tem e o ERP: a resposta da licenca traz a
 * URL, o ERP abre o navegador. O membro copia o mesmo link da ficha e manda
 * pelo WhatsApp. Desde a tarde de 10/09 o link nao entra sozinho: pede o
 * e-mail e a senha da loja (a entrada por senha, logo abaixo).
 *
 * O LINK E UM PORTADOR: quem o tem ve as cobrancas, a validade e as maquinas
 * daquela loja, e pode avisar que pagou ou pedir prazo -- o mesmo que o ERP
 * ja pode. E assinado com a chave da instalacao, e nada nele libera licenca:
 * pagar continua passando pela ponte de sempre.
 *
 * O LINK E FIXO (10/09/2026, tarde): o dono do produto quis que o cliente
 * guardasse o link e nao precisasse receber outro todo mes. Validade 0 no
 * token e "nunca vence"; um link com data continua aceito ate ela.
 *
 * O token e "codigo.validade.assinatura": legivel de proposito, para o membro
 * saber de quem e o link que esta na mao dele.
 */

/** 0 = sem vencimento. */
const SHIELD_AREA_DIAS = 0;

/**
 * QUEM ATENDE O CLIENTE FINAL -- 17/09/2026. O nome e o "Duvidas:" da area do
 * cliente, com o que o membro grava em Minha empresa: array('nome', 'fone', 'email').
 *
 * A tela procurava colunas que a softhouse nunca teve (nome, razao_social, fone,
 * whatsapp, email), e o e-mail saia sempre vazio -- a coluna so nasceu na
 * V4_2_8. SELECT * de proposito: base que ainda nao rodou a migracao responde
 * sem o e-mail, em vez de derrubar uma tela publica.
 */
function shield_area_contato(PDO $pdo)
{
    $contato = array('nome' => '', 'fone' => '', 'email' => '');
    try {
        $softhouse = $pdo->query('SELECT * FROM softhouse LIMIT 1')->fetch(PDO::FETCH_ASSOC);
    } catch (Throwable $semTabela) {
        return $contato;
    }
    if (!is_array($softhouse)) {
        return $contato;
    }

    $contato['nome'] = trim((string) ($softhouse['razao'] ?? ''));
    $contato['fone'] = trim((string) ($softhouse['telefone'] ?? ''));
    $contato['email'] = trim((string) ($softhouse['email'] ?? ''));

    return $contato;
}

/**
 * A ENTRADA POR SENHA -- 10/09/2026, tarde. O cliente entra na web com o
 * e-mail da loja e a senha que o membro definiu no fechamento (ou na ficha).
 * A senha mora em empresa.area_senha, em bcrypt: cliente final nao tem conta
 * em `usuario`, que e de quem opera o painel.
 */
function shield_area_senha_definir(PDO $pdo, $codigo, $senha)
{
    $senha = (string) $senha;
    if (strlen($senha) < 6) {
        throw new RuntimeException('A senha da area do cliente precisa de pelo menos 6 caracteres.');
    }
    // Definitiva: apaga a marca de temporaria e o vencimento.
    $pdo->prepare('UPDATE empresa SET area_senha = :s, area_senha_temporaria = NULL, area_senha_vence = NULL WHERE codigo = :c')
        ->execute(array(':s' => password_hash($senha, PASSWORD_DEFAULT), ':c' => (int) $codigo));
}

/** Senhas temporarias valem tantos dias. */
const SHIELD_AREA_SENHA_TEMPORARIA_DIAS = 30;

/**
 * RESETAR: o painel sorteia uma senha, guarda em bcrypt marcada como
 * temporaria (vale 30 dias e obriga a troca no primeiro acesso) e devolve a
 * senha em claro UMA VEZ, para o membro mandar ao cliente. Nao ha como
 * reler depois: so resetar de novo.
 */
function shield_area_senha_resetar(PDO $pdo, $codigo)
{
    // Sem 0/O/1/l/I: senha ditada por telefone nao pode ter letra que parece numero.
    $alfabeto = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    $senha = '';
    for ($i = 0; $i < 8; $i++) {
        $senha .= $alfabeto[random_int(0, strlen($alfabeto) - 1)];
    }
    $pdo->prepare('UPDATE empresa SET area_senha = :s, area_senha_temporaria = 1, area_senha_vence = :v WHERE codigo = :c')
        ->execute(array(
            ':s' => password_hash($senha, PASSWORD_DEFAULT),
            ':v' => date('Y-m-d', strtotime('+' . SHIELD_AREA_SENHA_TEMPORARIA_DIAS . ' days')),
            ':c' => (int) $codigo,
        ));

    return $senha;
}

/** A senha desta loja e temporaria e ja venceu? (temporaria vencida nao entra) */
function shield_area_senha_vencida(array $empresa, $hoje = null)
{
    $hoje = $hoje ?: date('Y-m-d');

    return !empty($empresa['area_senha_temporaria']) && trim((string) ($empresa['area_senha_vence'] ?? '')) !== ''
        && substr((string) $empresa['area_senha_vence'], 0, 10) < $hoje;
}

/**
 * E-mail da loja + senha -> codigo da empresa, ou null. Um caminho so para
 * e-mail inexistente, sem senha definida e senha errada: a diferenca
 * entregaria quais e-mails tem cadastro. Encerrada nao entra. Duas lojas com
 * o mesmo e-mail: entra a que a senha abrir.
 */
function shield_area_entrar(PDO $pdo, $email, $senha)
{
    $email = trim((string) $email);
    $senha = (string) $senha;
    if ($email === '' || $senha === '') {
        return null;
    }
    $stmt = $pdo->prepare('SELECT * FROM empresa WHERE email = :e AND encerrado_em IS NULL AND area_senha IS NOT NULL ORDER BY codigo');
    $stmt->execute(array(':e' => $email));
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $e) {
        if (password_verify($senha, (string) $e['area_senha']) && !shield_area_senha_vencida($e)) {
            return (int) $e['codigo'];
        }
    }

    return null;
}

/** O segredo da instalacao, derivado da crypto_key para nao reutilizar a chave crua. */
function shield_area_segredo()
{
    if (!function_exists('shield_ensure_crypto_key')) {
        return null;
    }
    try {
        return hash('sha256', 'area-do-cliente|' . shield_ensure_crypto_key());
    } catch (Throwable $semChave) {
        return null;
    }
}

/** validade e um inteiro Ymd (20261209): o link e igual o dia inteiro. */
function shield_area_token($codigo, $validadeYmd, $segredo)
{
    $carga = (int) $codigo . '.' . (int) $validadeYmd;

    return $carga . '.' . substr(hash_hmac('sha256', $carga, (string) $segredo), 0, 32);
}

/** Devolve o codigo da empresa, ou null: vencido, adulterado ou de outra instalacao. */
function shield_area_validar($token, $segredo, $hojeYmd = null)
{
    $partes = explode('.', trim((string) $token));
    if (count($partes) !== 3 || !ctype_digit($partes[0]) || !ctype_digit($partes[1]) || strlen($partes[2]) !== 32) {
        return null;
    }
    $hoje = (int) ($hojeYmd ?: date('Ymd'));
    if ((int) $partes[1] !== 0 && (int) $partes[1] < $hoje) {
        return null;
    }
    $esperado = shield_area_token((int) $partes[0], (int) $partes[1], $segredo);
    if (!hash_equals($esperado, $partes[0] . '.' . $partes[1] . '.' . $partes[2])) {
        return null;
    }

    return (int) $partes[0];
}

/**
 * A URL completa. $base sem barra no fim (https://painel.exemplo); sem base,
 * deduz da requisicao atual. Devolve '' quando nao ha segredo -- o link some
 * da resposta em vez de sair assinado com nada.
 */
function shield_area_url($codigo, $base = null, $segredo = null, $hojeYmd = null)
{
    $segredo = $segredo ?? shield_area_segredo();
    if ($segredo === null || $segredo === '') {
        return '';
    }
    $hoje = (string) ($hojeYmd ?: date('Ymd'));
    $validade = SHIELD_AREA_DIAS > 0
        ? (int) (DateTimeImmutable::createFromFormat('!Ymd', $hoje))->modify('+' . SHIELD_AREA_DIAS . ' days')->format('Ymd')
        : 0;
    if ($base === null) {
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
        $base = ($https ? 'https' : 'http') . '://' . (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');
    }

    return rtrim((string) $base, '/') . '/area_cliente.php?t=' . shield_area_token($codigo, $validade, $segredo);
}
