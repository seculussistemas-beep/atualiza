<?php

/**
 * O periodo de teste -- 09/09/2026.
 *
 * Quando o ERP liga pela primeira vez numa loja, o painel cria a empresa
 * sozinho (funcoes/licenca/licenca_assinada.php:251), sem validade e sem cota.
 * Ela aparece no painel e NAO trabalha: a API responde 409 "sem_validade"
 * (public/api/licenca.php). Quem esta avaliando o sistema fica preso antes de
 * comecar, e o membro descobre por telefone.
 *
 * ---------------------------------------------------------------------------
 * A DECISAO QUE SEGURA O DESENHO INTEIRO: nada e gravado no nascimento.
 *
 * O caminho obvio seria o INSERT ja gravar validade = hoje+7. Seria o pior:
 * TREZE pontos do painel deduzem "cliente ainda nao vendido" por
 * validade_licenca nula -- a lista, as faixas, a ordenacao, a limpeza, o
 * dashboard, o contador da lateral, o proprio 409 --, e um deles nem e SQL, e
 * deducao em PHP dentro da busca, que nao apareceria numa varredura por texto.
 * Todos passariam a enxergar o lead como cliente, calados.
 *
 * Entao a conta e feita na hora, a partir da data em que a empresa nasceu. O
 * lead continua sendo quem nao tem validade, como sempre foi.
 * ---------------------------------------------------------------------------
 *
 * O PRAZO E POR CLIENTE. O padrao vale para quem ninguem tocou; para o caso
 * especifico o membro define a data em `teste_ate`. Prorrogar e mover essa
 * data -- a mesma acao, sem contador de prorrogacoes e sem segunda regra.
 *
 * O TESTE NAO VIRA DINHEIRO. A cota dele e constante e NAO passa por
 * empresa.nterminais, de proposito: gravar 3 na cota sem gravar 3 em
 * terminais_inclusos reabriria o buraco que a V4_0_8 fechou a mao para toda a
 * base -- todo cliente novo nasceria devendo tres terminais adicionais.
 */

/** Quantos dias vale o teste de quem ninguem tocou. */
const SHIELD_TESTE_DIAS_PADRAO = 7;

/** Quantas maquinas o teste libera. Constante: nao e contrato, e avaliacao. */
const SHIELD_TESTE_TERMINAIS = 3;

/**
 * As regras do teste, CONFIGURAVEIS pelo membro -- 10/09/2026. Dias e caixas
 * ficam em shield_system_meta (teste_dias, teste_terminais); sem nada gravado
 * valem os padroes. Quem nao quer tres caixas no teste poe um.
 */
function shield_teste_config(?PDO $pdo = null): array
{
    $cfg = array('dias' => SHIELD_TESTE_DIAS_PADRAO, 'terminais' => SHIELD_TESTE_TERMINAIS);
    if ($pdo === null || !function_exists('shield_get_system_meta')) {
        return $cfg;
    }
    try {
        $dias = (int) shield_get_system_meta($pdo, 'teste_dias', (string) SHIELD_TESTE_DIAS_PADRAO);
        $term = (int) shield_get_system_meta($pdo, 'teste_terminais', (string) SHIELD_TESTE_TERMINAIS);
        $cfg['dias'] = max(1, min(90, $dias));
        $cfg['terminais'] = max(1, min(99, $term));
    } catch (Throwable $semTabela) {
    }

    return $cfg;
}

function shield_teste_definir(PDO $pdo, int $dias, int $terminais): void
{
    shield_set_system_meta($pdo, 'teste_dias', (string) max(1, min(90, $dias)));
    shield_set_system_meta($pdo, 'teste_terminais', (string) max(1, min(99, $terminais)));
}

function shield_teste_terminais(?PDO $pdo = null): int
{
    return shield_teste_config($pdo)['terminais'];
}

/**
 * Quantos caixas o teste DESTA empresa libera -- 10/09/2026, tarde. A coluna
 * empresa.teste_terminais manda quando preenchida ("esta loja testa com um");
 * vazia, vale a regra geral. So faz sentido para lead: com validade, quem
 * manda e nterminais.
 */
function shield_teste_terminais_de(array $empresa, ?array $cfg = null): int
{
    $proprio = (int) ($empresa['teste_terminais'] ?? 0);
    if ($proprio > 0) {
        return max(1, min(99, $proprio));
    }

    return (int) ($cfg ?? shield_teste_config())['terminais'];
}

/**
 * O TESTE COMECA QUANDO A PRIMEIRA MAQUINA LIGA -- 16/09/2026.
 *
 * Para a loja que chega pelo auto-cadastro isto nao muda nada: ali a primeira
 * chamada E o nascimento, entao "nascimento + dias" e "primeira maquina + dias"
 * dao a mesma data. O que muda e o cliente cadastrado A MAO semanas antes
 * (funcoes/empresa/cadastro.php): sem este carimbo ele chegaria com o teste
 * vencido no dia da instalacao, porque o relogio contava do cadastro.
 *
 * CARIMBA UMA VEZ SO. Com `teste_ate` ja decidido -- pela tela, por uma
 * prorrogacao ou por este proprio carimbo -- nada acontece; a segunda maquina
 * da loja nao renova teste nenhum. Cliente com validade, encerrado ou com
 * contrato iniciado tambem nao entra: ali o teste ja acabou, por outra razao.
 *
 * ONDE ELE E CHAMADO IMPORTA: em public/api/licenca.php ANTES de
 * emprestar_teste(), senao a primeira chamada da loja decidiria a licenca com o
 * teste ainda nao comecado e responderia sem licenca justamente no dia em que
 * ela instalou.
 *
 * Nunca derruba a licenca: coluna que ainda nao veio pelo /update, ou banco
 * engasgado, deixam o teste contando do nascimento, que e o comportamento de
 * antes.
 */
function shield_licenca_iniciar_teste_na_primeira_maquina(PDO $pdo, array $empresa, ?array $cfg = null): array
{
    require_once __DIR__ . '/../nucleo/data_zerada.php';

    $codigo = (int) ($empresa['codigo'] ?? 0);
    if ($codigo <= 0 || trim((string) ($empresa['teste_ate'] ?? '')) !== '') {
        return $empresa;
    }

    // SO QUEM FOI CADASTRADO A MAO (V4_2_7). O lead que chega pela propria rota
    // de licenca nasce e liga na MESMA requisicao: para ele "nascimento + dias"
    // ja e "primeira maquina + dias", e gravar seria quebrar 4.1.5 -- a licenca
    // do teste e emprestada em memoria, nada e escrito na linha do lead, e
    // LicencaApiTest cobra isso com um lead nascido ha dois dias. A marca e o
    // que separa os dois casos sem adivinhar por data.
    if (empty($empresa['cadastro_manual'])) {
        return $empresa;
    }

    $validade = substr(trim((string) ($empresa['validade_licenca'] ?? '')), 0, 10);
    if (($validade !== '' && $validade !== '0000-00-00')
        || trim((string) ($empresa['encerrado_em'] ?? '')) !== ''
        || trim((string) ($empresa['fechado_em'] ?? '')) !== '') {
        return $empresa;
    }

    try {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM terminais WHERE FK_EMPRESA = :c');
        $stmt->execute(array(':c' => $codigo));
        if ((int) $stmt->fetchColumn() > 0) {
            return $empresa;   // ja instalou antes: o teste dele conta do nascimento
        }

        $dias = (int) (($cfg ?? shield_teste_config($pdo))['dias']);
        $ate = date('Y-m-d', strtotime('+' . max(1, $dias) . ' days'));

        // A condicao repetida no UPDATE segura duas maquinas ligando juntas: a
        // segunda nao reescreve o que a primeira acabou de carimbar.
        $pdo->prepare(
            'UPDATE empresa SET teste_ate = :d
              WHERE codigo = :c AND ' . shield_sql_sem_validade('teste_ate')
        )->execute(array(':d' => $ate, ':c' => $codigo));

        $empresa['teste_ate'] = $ate;
    } catch (Throwable $ignorado) {
        // ver o cabecalho: sem coluna ou sem banco, o teste volta a contar do
        // nascimento em vez de a licenca cair.
    }

    return $empresa;
}

/**
 * Ate quando o teste desta empresa vale. Devolve 'Y-m-d', ou null quando ela
 * nao esta em teste nenhum -- por ja ser cliente, por ter sido encerrada, ou
 * por nao haver data de nascimento de onde contar.
 *
 * A ORDEM DAS RECUSAS IMPORTA. Validade preenchida sai primeiro: cliente com
 * validade e cliente, ainda que ela esteja vencida ha anos. Sem essa recusa, o
 * inadimplente esquecido ganharia uma semana de graca toda vez que alguem
 * olhasse para ele.
 *
 * O CONTRATO FECHADO ENCERRA A AVALIACAO (11/09/2026). Sem esta recusa, o
 * membro que fechasse o contrato SEM marcar a liberacao antecipada veria o
 * sistema do cliente continuar aberto ate o setimo dia -- e a escolha que ele
 * acabou de fazer na tela nao valeria nada. Dali em diante quem libera e o
 * pagamento, ou a cortesia da primeira fatura, que grava validade.
 */
function shield_teste_fim(array $empresa, ?array $cfg = null): ?string
{
    $dias = (int) (($cfg ?? shield_teste_config())['dias']);

    // A DATA ZERADA NAO E VALIDADE -- 16/09/2026. O cadastro legado do ERP grava
    // '0000-00-00' onde o painel grava NULL, e o painel inteiro ja trata as duas
    // como "sem licenca" (fechamento, confianca, situacao, comando do ERP, e as
    // consultas depois de 4.1.33). So aqui a zerada passava por validade
    // PREENCHIDA, e o efeito era a loja de cadastro antigo ficar presa: entrava
    // na fila de avaliacao pela consulta, nao tinha fim de teste na tela, nao
    // ganhava os sete dias na API e nunca era encerrada pela rotina -- que
    // pergunta o fim do teste aqui. O substr corta a hora, como o CAST para
    // CHAR(10) do lado do SQL, para a coluna datetime decidir igual.
    $validade = substr(trim((string) ($empresa['validade_licenca'] ?? '')), 0, 10);
    if ($validade !== '' && $validade !== '0000-00-00') {
        return null;
    }

    if (trim((string) ($empresa['encerrado_em'] ?? '')) !== '') {
        return null;
    }

    if (trim((string) ($empresa['fechado_em'] ?? '')) !== '') {
        return null;
    }

    $proprio = trim((string) ($empresa['teste_ate'] ?? ''));
    if ($proprio !== '') {
        return substr($proprio, 0, 10);
    }

    // Sem nascimento nao ha de onde contar, e nao se inventa uma data: a
    // empresa fica fora do teste e o membro resolve na tela.
    $nasceu = trim((string) ($empresa['data'] ?? ''));
    if ($nasceu === '') {
        return null;
    }

    $dia = DateTimeImmutable::createFromFormat('!Y-m-d', substr($nasceu, 0, 10));
    if ($dia === false) {
        return null;
    }

    return $dia->modify('+' . $dias . ' days')->format('Y-m-d');
}

/**
 * Quantos dias ainda faltam. Zero e o ULTIMO dia, que ainda trabalha; null
 * quando nao ha teste. Negativo nunca sai -- teste vencido devolve null, e
 * quem quer saber se acabou pergunta a shield_teste_vigente.
 */
function shield_teste_dias_restantes(array $empresa, ?array $cfg = null): ?int
{
    $fim = shield_teste_fim($empresa, $cfg);
    if ($fim === null) {
        return null;
    }

    $ate = DateTimeImmutable::createFromFormat('!Y-m-d', $fim);
    if ($ate === false) {
        return null;
    }

    $dias = (int) (new DateTimeImmutable('today'))->diff($ate)->format('%r%a');

    return $dias < 0 ? null : $dias;
}

/**
 * A empresa pode trabalhar agora por conta do teste?
 *
 * O corte e "hoje passou do fim", maior estrito -- o proprio dia do fim ainda
 * trabalha, igual ao que o ERP faz com a validade (uLicencaBlob.pas:398). As
 * duas pontas contando diferente e o tipo de divergencia que aparece so no
 * cliente, no ultimo dia, sem ninguem conseguir reproduzir.
 */
function shield_teste_vigente(array $empresa, ?array $cfg = null): bool
{
    $fim = shield_teste_fim($empresa, $cfg);
    if ($fim === null) {
        return false;
    }

    return $fim >= (new DateTimeImmutable('today'))->format('Y-m-d');
}
