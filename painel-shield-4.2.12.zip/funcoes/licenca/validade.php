<?php

// A ponte pagamento -> licenca - 25/08/2026.
//
// E isto que o membro esta ganhando, e e aqui que um erro custa caro NOS DOIS
// SENTIDOS. Por isso as duas operacoes deste arquivo nao sao simetricas, e nao
// devem ser tratadas como se fossem:
//
//   ESTENDER mexe em dinheiro. Exige PROVA -- situacao confirmada pelo
//   provedor, nunca so o webhook. Na via manual, a prova e o operador, e por
//   isso ela e auditada e tem permissao propria.
//
//   SUSPENDER desliga o caixa de uma loja. Silencio do gateway, erro de
//   integracao, cron que nao rodou ou fila parada NUNCA podem suspender
//   ninguem. Na duvida, deixa valendo.
//
// Tratar as duas como "a mesma operacao com o sinal trocado" e o erro caro
// deste sistema.

require_once __DIR__ . '/../cobranca/cobranca.php';
require_once __DIR__ . '/../nucleo/data_zerada.php'; // a data zerada em SQL, sem pedir conversao

/**
 * Soma (ou subtrai) meses SEM TRANSBORDAR O FIM DO MES -- 11/09/2026.
 *
 * A soma ingenua do PHP escorre o dia que nao existe no mes de destino para o
 * mes seguinte: 31/01 mais um mes da 03/03, e cada transbordo era um punhado de
 * dias de licenca de graca. O projeto ja sabia disso e tinha resolvido no
 * vencimento da assinatura (shield_assinatura_vencimento grampeia no ultimo dia
 * do mes); a validade e que tinha ficado de fora.
 *
 * E o MESMO resultado do DATE_ADD(..., INTERVAL n MONTH) do banco, que e quem
 * grava de verdade -- aqui a conta serve ao livro e a previsao.
 */
function shield_validade_somar_meses(DateTimeImmutable $base, $meses)
{
    $dia = (int) $base->format('j');
    // Do dia 1 para nao transbordar durante a propria soma.
    $alvo = $base->modify('first day of this month')->modify(($meses >= 0 ? '+' : '-') . abs((int) $meses) . ' month');

    return $alvo->setDate((int) $alvo->format('Y'), (int) $alvo->format('n'), min($dia, (int) $alvo->format('t')));
}

/**
 * Estende a validade do cliente por N meses.
 *
 * A PARTIR DA VALIDADE, NAO DE HOJE. Quem paga com cinco dias de atraso nao
 * perde cinco dias, e quem paga adiantado nao ganha nada -- as duas coisas
 * viram reclamacao, e a segunda vira prejuizo. So quando nao ha validade
 * nenhuma (cliente novo) a conta parte de hoje.
 *
 * COM ANCORA (10/09/2026, noite): a mensalidade da assinatura parte do MAIOR
 * entre a validade e o vencimento da fatura (`$dados['ancora']`). Sem isso a
 * validade e a proxima fatura se descolavam -- "licenca ate 10/10" com a
 * mensalidade seguinte vencendo 17/09 -- e ninguem entendia a tela.
 *
 * IDEMPOTENTE POR COBRANCA. A unicidade de validade_movimento e o que segura:
 * o webhook chega, a conciliacao chega logo atras, e sem ela o cliente ganha um
 * mes de presente a cada verificacao.
 *
 * E A CONTA E FEITA DENTRO DO UPDATE -- 11/09/2026. A tabela `empresa` e
 * MyISAM: o `FOR UPDATE` que morava aqui era aceito pelo MariaDB sem travar
 * nada, entao dois pagamentos confirmados no mesmo instante liam a mesma
 * validade e um sobrescrevia o outro -- o cliente pagava dois meses e recebia
 * um. Somando dentro do proprio UPDATE nao ha leitura a perder: o segundo parte
 * do que o primeiro gravou, e o GREATEST/DATE_ADD do banco diz a mesma coisa
 * que a conta em PHP logo acima.
 *
 * Devolve a nova validade, ou null quando nada foi feito (ja estendida antes).
 */
function shield_validade_estender(PDO $pdo, $empresaId, $meses, array $dados = array())
{
    $empresaId = (int) $empresaId;
    $meses = max(1, (int) $meses);
    $cobranca = isset($dados['cobranca']) ? (int) $dados['cobranca'] : null;

    $proprio = !$pdo->inTransaction();
    if ($proprio) {
        $pdo->beginTransaction();
    }

    try {
        // Leitura so para o livro (o `de` do movimento e da auditoria). Quem
        // decide a validade nova e o UPDATE la embaixo -- ver o cabecalho.
        $stmt = $pdo->prepare('SELECT validade_licenca FROM empresa WHERE codigo = :id');
        $stmt->execute(array(':id' => $empresaId));
        $atual = $stmt->fetchColumn();
        if ($atual === false) {
            throw new RuntimeException('Cliente nao encontrado.');
        }

        $de = trim((string) $atual);
        $base = ($de !== '' && $de !== '0000-00-00')
            ? new DateTimeImmutable(substr($de, 0, 10))
            : new DateTimeImmutable('today');
        $ancora = substr(trim((string) ($dados['ancora'] ?? '')), 0, 10);
        if ($ancora !== '' && $ancora !== '0000-00-00' && $ancora > $base->format('Y-m-d')) {
            $base = new DateTimeImmutable($ancora);
        }

        $para = shield_validade_somar_meses($base, $meses)->format('Y-m-d');

        // A linha do movimento entra ANTES da validade nova. Sendo a segunda
        // vez para a mesma cobranca, a unicidade recusa aqui e a validade nao
        // chega a ser tocada.
        $stmt = $pdo->prepare(
            'INSERT INTO validade_movimento
                (fk_empresa, fk_cobranca, de, para, meses, motivo, ator)
             VALUES (:emp, :cob, :de, :para, :meses, :motivo, :ator)'
        );

        $movimento = 0;
        try {
            $usuario = (array) ($_SESSION['usuario'] ?? array());
            $stmt->execute(array(
                ':emp' => $empresaId,
                ':cob' => $cobranca ?: null,
                // A DATA ZERADA NAO SE GRAVA, NEM NO LIVRO (16/09/2026). `de` e
                // coluna date: mandar '0000-00-00' para ela e recusado com 1292
                // onde o ajuste de sessao foi recusado, e a excecao derrubava a
                // extensao inteira -- o pagamento entrava e a validade nao
                // andava. NULL diz exatamente o mesmo que a zerada diz aqui:
                // nao havia validade antes desta. A auditoria logo abaixo
                // continua guardando o valor cru, que e texto.
                ':de' => ($de !== '' && $de !== '0000-00-00') ? substr($de, 0, 10) : null,
                ':para' => $para,
                ':meses' => $meses,
                ':motivo' => substr((string) ($dados['motivo'] ?? 'pagamento confirmado'), 0, 150),
                ':ator' => substr((string) ($dados['ator']
                    ?? ($usuario['nome'] ?? $usuario['login'] ?? 'rotina')), 0, 80),
            ));
        } catch (PDOException $e) {
            // 23000 = violacao de unicidade. Esta cobranca ja estendeu.
            if ($e->getCode() === '23000') {
                if ($proprio) {
                    $pdo->rollBack();
                }

                return null;
            }
            throw $e;
        }
        $movimento = (int) $pdo->lastInsertId();

        // A conta no banco, num comando so. `:piso` e uma data impossivel
        // quando nao ha ancora: GREATEST com ela devolve sempre a validade, que
        // e o comportamento de quem paga atrasado e nao perde dias.
        //
        // A VALIDADE ZERADA ENTRA COMO TEXTO (16/09/2026). O literal ao lado da
        // coluna fazia o servidor converte-lo para DATE ao preparar: onde o
        // ajuste de sessao e recusado, este UPDATE caia com 1292 e a validade
        // NAO andava depois de o pagamento ter sido confirmado -- o pior
        // silencio possivel nesta funcao. GREATEST e DATE_ADD dao a mesma
        // resposta com a string 'AAAA-MM-DD', fim de mes grampeado inclusive.
        $stmt = $pdo->prepare(
            "UPDATE empresa
                SET validade_licenca = DATE_ADD(
                      GREATEST(COALESCE(" . shield_sql_validade_ou_nulo('validade_licenca') . ", :hoje), :ancora),
                      INTERVAL " . $meses . " MONTH)
              WHERE codigo = :id"
        );
        $stmt->execute(array(
            ':hoje' => (new DateTimeImmutable('today'))->format('Y-m-d'),
            ':ancora' => $ancora !== '' && $ancora !== '0000-00-00' ? $ancora : '1000-01-01',
            ':id' => $empresaId,
        ));

        // O que ficou gravado de verdade. Divergindo do que a conta em PHP
        // previu, outro pagamento entrou no meio: o livro conta o que houve.
        $stmt = $pdo->prepare('SELECT validade_licenca FROM empresa WHERE codigo = :id');
        $stmt->execute(array(':id' => $empresaId));
        $gravado = substr((string) $stmt->fetchColumn(), 0, 10);
        if ($gravado !== '' && $gravado !== $para) {
            $para = $gravado;
            $pdo->prepare('UPDATE validade_movimento SET para = :p WHERE id = :id')
                ->execute(array(':p' => $para, ':id' => $movimento));
        }

        // A COTA DO CONTRATO QUE NASCE PELO PAGAMENTO -- 11/09/2026. O lead
        // que vira cliente sem passar pelo fechamento (uma cobranca avulsa
        // paga) chegava aqui com nterminais nulo: o ERP dizia "nao informado
        // pelo painel", a lista dizia "sem quantidade contratada" e o
        // membro descobria pelo cliente. A PRIMEIRA validade herda a cota que
        // ele ja tinha no teste (a propria, se o membro fixou uma). So na
        // primeira e so sem cota gravada: cota gravada e escolha do membro, e
        // o fechamento ja grava a dele. Tropeco aqui NAO desfaz a validade --
        // o dinheiro entrou; a cota o membro acerta na ficha.
        //
        // SEM COTA E NULL, NAO ZERO -- 14/09/2026. Zero gravado tambem e
        // escolha: e o "sem limite" de shield_licenca_tem_vaga, e herdar por
        // cima dele fazia o cliente que o membro liberou geral acordar, no dia
        // do primeiro pagamento, com tres caixas. O 1 que o cadastro legado do
        // ERP grava sozinho (CadastraEmpresa) tambem fica: o dado nao separa
        // esse 1 do 1 que o membro digitou, e herdar por cima do segundo daria
        // caixa que ninguem vendeu.
        $cotaHerdada = 0;
        if ($de === '' || $de === '0000-00-00') {
            try {
                $stmt = $pdo->prepare('SELECT nterminais, teste_terminais FROM empresa WHERE codigo = :id');
                $stmt->execute(array(':id' => $empresaId));
                $linha = $stmt->fetch(PDO::FETCH_ASSOC) ?: array();
                if (array_key_exists('nterminais', $linha) && $linha['nterminais'] === null) {
                    require_once __DIR__ . '/teste.php';
                    $cotaHerdada = (int) shield_teste_terminais_de($linha, shield_teste_config($pdo));
                    $pdo->prepare('UPDATE empresa SET nterminais = :n WHERE codigo = :id')
                        ->execute(array(':n' => $cotaHerdada, ':id' => $empresaId));
                }
            } catch (Throwable $e) {
                $cotaHerdada = 0;
                error_log('[validade] cota do teste nao herdada para ' . $empresaId . ': ' . $e->getMessage());
            }
        }

        if ($proprio) {
            $pdo->commit();
        }

        if ($cotaHerdada > 0) {
            shield_auditar($pdo, 'cota_herdada_do_teste', array(
                'alvo_tipo' => 'empresa', 'alvo_id' => $empresaId,
                'antes' => '', 'depois' => (string) $cotaHerdada,
                'detalhe' => 'primeira validade sem cota gravada: herdou a do teste',
            ));
        }

        shield_auditar($pdo, 'validade_estendida', array(
            'alvo_tipo' => 'empresa', 'alvo_id' => $empresaId,
            'antes' => $de, 'depois' => $para,
            'detalhe' => $meses . ' mes(es) -- ' . (string) ($dados['motivo'] ?? 'pagamento confirmado'),
        ));

        // O dinheiro entrou: a promessa de pagamento / liberacao em confianca
        // aberta esta cumprida. AQUI porque este e o unico ponto por onde o
        // pagamento passa com rastro -- webhook, conciliacao e confirmacao
        // manual fecham a promessa de graca.
        require_once __DIR__ . '/confianca.php';
        shield_promessa_cumprir($pdo, $empresaId);

        return $para;
    } catch (Throwable $e) {
        if ($proprio && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

/**
 * RECOLHE os meses que uma cobranca deu -- 11/09/2026, so no estorno.
 *
 * Nao volta para a data de antes: tira os MESES daquele movimento da validade
 * de hoje. Entre o pagamento e o estorno pode ter entrado outro pagamento, e
 * voltar para a data antiga apagaria o dinheiro de terceiros.
 *
 * O movimento original fica onde esta (a unicidade e por cobranca, e apagar
 * seria perder o rastro); o recolhimento entra como linha nova sem cobranca.
 */
function shield_validade_recolher(PDO $pdo, array $cobranca, $motivo)
{
    $id = (int) $cobranca['id'];
    try {
        $stmt = $pdo->prepare('SELECT meses FROM validade_movimento WHERE fk_cobranca = :c');
        $stmt->execute(array(':c' => $id));
        $meses = $stmt->fetchColumn();
    } catch (Throwable $semTabela) {
        return null;
    }
    if ($meses === false || (int) $meses <= 0) {
        return null;   // esta cobranca nunca moveu a validade
    }
    $meses = (int) $meses;
    $empresa = (int) $cobranca['fk_empresa'];

    $stmt = $pdo->prepare('SELECT validade_licenca FROM empresa WHERE codigo = :e');
    $stmt->execute(array(':e' => $empresa));
    $de = trim((string) $stmt->fetchColumn());
    if ($de === '' || $de === '0000-00-00') {
        return null;
    }
    $de = substr($de, 0, 10);
    $para = shield_validade_somar_meses(new DateTimeImmutable($de), -$meses)->format('Y-m-d');

    $pdo->prepare('UPDATE empresa SET validade_licenca = :para WHERE codigo = :e')
        ->execute(array(':para' => $para, ':e' => $empresa));

    $usuario = (array) ($_SESSION['usuario'] ?? array());
    $pdo->prepare(
        'INSERT INTO validade_movimento (fk_empresa, fk_cobranca, de, para, meses, motivo, ator)
         VALUES (:emp, NULL, :de, :para, :meses, :motivo, :ator)'
    )->execute(array(
        ':emp' => $empresa, ':de' => $de, ':para' => $para, ':meses' => -$meses,
        ':motivo' => substr('recolhido da cobranca ' . $id . ' -- ' . $motivo, 0, 150),
        ':ator' => substr((string) ($usuario['nome'] ?? $usuario['login'] ?? 'rotina'), 0, 80),
    ));

    shield_auditar($pdo, 'validade_recolhida', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => $empresa,
        'antes' => $de, 'depois' => $para,
        'detalhe' => $meses . ' mes(es) recolhido(s) -- ' . $motivo,
    ));

    return $para;
}

/**
 * Suspende o cliente. NUNCA e chamada por silencio: quem a chama e a regua,
 * com uma cobranca vencida na mao, ou o membro, no botao.
 *
 * NAO mexe no `bloqueado` sozinho -- mexe, mas registrando em suspenso_em que
 * quem o pos foi a suspensao. Sem essa marca, tirar uma suspensao apagaria um
 * bloqueio que o membro tinha posto a mao por outro motivo, e ele so
 * descobriria quando o cliente voltasse a emitir nota.
 *
 * SO SUSPENDE QUEM ESTA LIBERADO -- 14/09/2026. A guarda era "suspenso_em
 * vazio", e as duas pontas escapavam dela. O bloqueio manual tem suspenso_em
 * vazio: a suspensao escrevia a marca por cima e ele virava divida -- o token
 * passava a aceitar promessa sobre ele e o "liberar" da regua o apagava, que e
 * justamente o que a marca existe para impedir. E o cliente liberado com a
 * marca esquecida (o radio do Contrato do cliente gravava bloqueado sem tocar
 * nela ate esta data) nunca mais era suspenso. Quem manda e o bloqueado: 'S'
 * ja esta parado, por um motivo ou pelo outro, e fica como esta; o resto
 * suspende e reescreve a marca. COALESCE porque bloqueado aceita NULL, e
 * NULL <> 'S' nao e verdadeiro no SQL.
 */
function shield_validade_suspender(PDO $pdo, $empresaId, $motivo)
{
    $stmt = $pdo->prepare(
        "UPDATE empresa
            SET bloqueado = :s, suspenso_em = NOW(), suspenso_motivo = :motivo
          WHERE codigo = :id AND UPPER(COALESCE(bloqueado, 'N')) <> 'S'"
    );
    $stmt->execute(array(':s' => 'S', ':motivo' => substr((string) $motivo, 0, 150),
                         ':id' => (int) $empresaId));

    if ($stmt->rowCount() === 0) {
        return false;
    }

    shield_auditar($pdo, 'cliente_suspenso', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => (int) $empresaId,
        'detalhe' => (string) $motivo,
    ));

    return true;
}

/** Tira a suspensao -- e SO a suspensao. Bloqueio manual continua de pe. */
function shield_validade_liberar(PDO $pdo, $empresaId, $motivo = '')
{
    $stmt = $pdo->prepare(
        'UPDATE empresa
            SET bloqueado = :n, suspenso_em = NULL, suspenso_motivo = NULL
          WHERE codigo = :id AND suspenso_em IS NOT NULL'
    );
    $stmt->execute(array(':n' => 'N', ':id' => (int) $empresaId));

    if ($stmt->rowCount() === 0) {
        return false;
    }

    shield_auditar($pdo, 'cliente_liberado', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => (int) $empresaId,
        'detalhe' => (string) $motivo,
    ));

    return true;
}

/**
 * Quando a suspensao passa a valer NA LOJA.
 *
 * Nao e agora: o ERP guarda o token por SHIELD_LICENCA_CARENCIA_DIAS e decide
 * sozinho, sem rede, ate ele vencer. Toda tela que disser "suspenso" precisa
 * dizer a partir de quando isso chega la -- senao o membro suspende, o cliente
 * continua vendendo, e ele acha que o painel nao funcionou.
 */
function shield_validade_quando_vale($quandoSuspendeu = null)
{
    $dias = defined('SHIELD_LICENCA_CARENCIA_DIAS') ? (int) SHIELD_LICENCA_CARENCIA_DIAS : 7;
    $base = $quandoSuspendeu ? new DateTimeImmutable((string) $quandoSuspendeu)
                             : new DateTimeImmutable('now');

    return $base->modify('+' . $dias . ' days')->format('Y-m-d');
}
