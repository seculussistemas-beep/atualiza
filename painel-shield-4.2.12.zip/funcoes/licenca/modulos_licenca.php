<?php

/**
 * Os modulos contratados, do jeito que o ERP entende -- 10/09/2026.
 *
 * O ERP so obedece ao que esta DENTRO da licenca assinada. Modulo contratado,
 * portanto, vai no conteudo do JWS como lista de CHAVES curtas -- e quem
 * traduz "plano Prata" em ["fiscal","os"] e o painel, para o membro mudar o
 * pacote sem ninguem recompilar nada.
 *
 * AS REGRAS DO LADO DELPHI, que decidem o que se manda:
 *   - campo ausente = tudo liberado (e o parque inteiro hoje);
 *   - lista vazia = tudo liberado (engano de servidor nao apaga funcao paga);
 *   - chave desconhecida e ignorada (o painel pode emitir "farmacia" antes de
 *     o build conhece-la).
 * Logo: cliente sem modulo com chave NAO recebe o campo. Nao existe "nenhum
 * modulo" -- so "todos".
 *
 * Modulo do catalogo SEM chave e item de fatura ("suporte premium"): entra na
 * mensalidade e nao desliga nada na loja.
 */

/** As nove chaves deste build do ERP, com o que o cliente perde sem cada uma. */
function shield_modulos_conhecidos()
{
    return array(
        'fiscal' => 'NF-e e NFC-e pela retaguarda, documentos emitidos, importacao de lote',
        'nfse' => 'NFS-e: emissao, consulta e configuracao',
        'transporte' => 'CT-e, CT-e OS e MDF-e',
        'sped' => 'SPED Fiscal, SPED Contribuicoes, Sintegra',
        'os' => 'Ordem de Servico inteira: ordens, agenda, contratos de recorrencia',
        'restaurante' => 'Restaurante, Mesas e Delivery',
        'forcavenda' => 'Forca de Venda: pedidos e sincronizacao',
        'boleto' => 'Cobranca bancaria: remessa, retorno, boletos emitidos',
        'painel' => 'Curva ABC e Ticket Medio',
    );
}

/**
 * Normaliza o que o membro digitou como chave: minusculo, so letras e digitos,
 * ate 20. Vazio quando nao sobra nada.
 */
function shield_modulo_chave_normalizar($texto)
{
    $chave = mb_strtolower(trim((string) $texto), 'UTF-8');
    // Acento e cedilha viram a letra crua ("força" -> "forca"), em vez de
    // sumirem ("fora"): o membro digita com acento e espera a chave do ERP.
    $chave = strtr($chave, array(
        'á' => 'a', 'à' => 'a', 'ã' => 'a', 'â' => 'a', 'é' => 'e', 'ê' => 'e', 'í' => 'i',
        'ó' => 'o', 'õ' => 'o', 'ô' => 'o', 'ú' => 'u', 'ü' => 'u', 'ç' => 'c',
    ));
    $chave = preg_replace('/[^a-z0-9_]/', '', $chave);

    return substr((string) $chave, 0, 20);
}

const SHIELD_MODULOS_CHAVE_SEM_CONTRATO = 'modulos_sem_contrato';

/**
 * O que a licenca diz ao ERP quando o cliente NAO tem modulo contratado --
 * 10/09/2026, tarde. 'tudo' (padrao) nao manda o campo e o ERP libera tudo,
 * pela regra dele. 'basico' manda ["basico"]: chave fora do catalogo do ERP,
 * que ele ignora -- mas a lista definida e nao vazia faz o portao fechar tudo
 * o que e modulo, e sobra so o que nao e modulo (venda, caixa, cadastros).
 * E a convencao combinada com o Delphi (docs/erp-aviso-de-fim-de-teste.md).
 */
function shield_modulos_sem_contrato(?PDO $pdo)
{
    if ($pdo === null || !function_exists('shield_get_system_meta')) {
        return 'tudo';
    }
    try {
        return trim((string) shield_get_system_meta($pdo, SHIELD_MODULOS_CHAVE_SEM_CONTRATO, 'tudo')) === 'basico' ? 'basico' : 'tudo';
    } catch (Throwable $semTabela) {
        return 'tudo';
    }
}

function shield_modulos_definir_sem_contrato(PDO $pdo, $modo)
{
    $modo = (string) $modo === 'basico' ? 'basico' : 'tudo';
    shield_set_system_meta($pdo, SHIELD_MODULOS_CHAVE_SEM_CONTRATO, $modo);
    if (function_exists('shield_auditar')) {
        shield_auditar($pdo, 'modulos_sem_contrato', array(
            'depois' => $modo,
            'detalhe' => $modo === 'basico'
                ? 'cliente sem modulo contratado passa a receber so o basico'
                : 'cliente sem modulo contratado volta a receber tudo (regra do ERP)',
        ));
    }
}

/**
 * A lista que VAI NO TOKEN: os modulos do cliente; sem nenhum, o que a
 * regra "sem contrato" mandar (vazio = campo ausente = tudo liberado).
 */
function shield_licenca_modulos_para_token(PDO $pdo, $empresa)
{
    $lista = shield_licenca_modulos_do_cliente($pdo, $empresa);
    if ($lista === array() && shield_modulos_sem_contrato($pdo) === 'basico') {
        return array('basico');
    }

    return $lista;
}

/**
 * As chaves dos modulos que este cliente tem contratados HOJE, em ordem
 * alfabetica e sem repeticao. Vazio quando nao ha nenhum com chave -- e vazio
 * significa "nao mande o campo".
 *
 * Base sem a coluna (anterior a 4.1.0) devolve vazio: licenca segue.
 */
function shield_licenca_modulos_do_cliente(PDO $pdo, $empresa)
{
    try {
        $stmt = $pdo->prepare(
            'SELECT DISTINCT m.chave
               FROM empresa_modulo em
               JOIN modulo m ON m.id = em.fk_modulo
              WHERE em.fk_empresa = :emp AND em.ate IS NULL
                AND m.chave IS NOT NULL AND m.chave <> \'\'
              ORDER BY m.chave'
        );
        $stmt->execute(array(':emp' => (int) $empresa));

        $chaves = array();
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $c) {
            $c = shield_modulo_chave_normalizar($c);
            if ($c !== '') {
                $chaves[] = $c;
            }
        }

        return array_values(array_unique($chaves));
    } catch (Throwable $semColuna) {
        return array();
    }
}
