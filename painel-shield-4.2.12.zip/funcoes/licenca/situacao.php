<?php
/**
 * A situacao de um cliente, dita em UM lugar so. 25/08/2026.
 *
 * Antes cada tela decidia sozinha o que era "vencido": a lista de clientes
 * pintava de vermelho por `diff()->invert`, a ficha calculava dias com sinal,
 * a Central de avisos tinha o terceiro criterio. Tres respostas para a mesma
 * pergunta, e o membro conferindo uma contra a outra.
 *
 * Aqui a resposta e uma: chave, rotulo, cor e icone. Quem mostra escolhe o
 * tamanho e o lugar; NINGUEM decide de novo o que a situacao e.
 *
 * A ORDEM DAS PERGUNTAS E A REGRA DE NEGOCIO, e nao pode ser trocada:
 * bloqueio e suspensao vem ANTES da data, porque licenca dentro da validade
 * nao abre nada se a empresa esta bloqueada -- e mostrar "Valido" a quem esta
 * com o sistema parado e o pior erro possivel nesta tela.
 */

// O lead em avaliacao e um caso da situacao, e nao de outra tela: sem isto o
// detalhe "em avaliacao ate" nunca apareceria, porque a funcao so o escreve
// quando o teste esta carregado. Nao entra no caminho da API de licenca --
// ela nao carrega situacao.php.
require_once __DIR__ . '/teste.php';
require_once __DIR__ . '/../nucleo/data_zerada.php'; // a data zerada em SQL, sem pedir conversao

if (!defined('SHIELD_VENCE_EM_BREVE')) {
    /** Dias de antecedencia em que a licenca ja pede acao. O mesmo numero que
     *  o filtro "Proximos do vencimento" usa -- se um mudar, o outro mente. */
    define('SHIELD_VENCE_EM_BREVE', 15);
}

if (!function_exists('shield_situacao_licenca')) {
    /**
     * @param  array $empresa linha da tabela `empresa`
     * @param  bool  $renovaSozinho a empresa tem assinatura ativa
     * @return array chave, rotulo, detalhe, cor (ok|atencao|erro|neutro|venda), icone, dias
     */
    function shield_situacao_licenca(array $empresa, $renovaSozinho = false)
    {
        $bloqueado = strtoupper(trim((string) ($empresa['bloqueado'] ?? 'N'))) === 'S';
        $suspenso  = trim((string) ($empresa['suspenso_em'] ?? '')) !== '';
        $validade  = trim((string) ($empresa['validade_licenca'] ?? ''));
        if ($validade === '0000-00-00') {
            $validade = '';
        }

        $dias = null;
        if ($validade !== '') {
            $dias = (int) (new DateTimeImmutable('today'))
                ->diff(new DateTimeImmutable(substr($validade, 0, 10)))
                ->format('%r%a');
        }
        $quando = $validade !== '' ? date('d/m/Y', strtotime($validade)) : '';

        // ENCERRADO NA FRENTE DE TUDO -- 10/09/2026, fatia 5. E marca, nao
        // apagamento: o cadastro fica, a licenca para. Antes de bloqueio e
        // suspensao porque encerrar e a decisao mais recente de gente.
        if (trim((string) ($empresa['encerrado_em'] ?? '')) !== '') {
            return array('chave' => 'encerrado', 'rotulo' => 'Encerrado',
                         'detalhe' => 'em ' . date('d/m/Y', strtotime((string) $empresa['encerrado_em'])),
                         'cor' => 'neutro', 'icone' => 'fa-times-circle', 'dias' => $dias);
        }

        // SUSPENSO ANTES DE BLOQUEADO -- 10/09/2026, fatia 4 da reorganizacao.
        // A regua suspende escrevendo bloqueado = 'S' E suspenso_em; com o
        // bloqueio na frente, todo suspenso saia como "Bloqueado" e a faixa
        // "bloqueadas por voce" contava como ato seu o que foi automatico. A
        // cor e a mesma do bloqueio, porque a loja esta parada dos dois
        // jeitos; o rotulo e outro, porque a saida e outra -- um voce desfaz,
        // o outro o pagamento desfaz.
        if ($suspenso) {
            // Suspensao NAO para a loja hoje: o ERP guarda o token por sete
            // dias e decide sozinho ate ele vencer. O detalhe diz a partir de
            // quando vale, senao o membro promete ao cliente o que nao ocorre.
            $vale = function_exists('shield_validade_quando_vale')
                ? shield_validade_quando_vale($empresa['suspenso_em'])
                : null;
            return array('chave' => 'suspenso', 'rotulo' => 'Suspenso',
                         'detalhe' => $vale ? 'vale ' . date('d/m/Y', strtotime($vale)) : '',
                         'cor' => 'erro', 'icone' => 'fa-hourglass-half', 'dias' => $dias);
        }
        if ($bloqueado) {
            // AMARELO, e nao vermelho (10/09/2026, tarde): bloqueio e decisao do
            // membro, nao divida -- a cor diz "fui eu", como na faixa da lista.
            return array('chave' => 'bloqueado', 'rotulo' => 'Bloqueado',
                         'detalhe' => $quando !== '' ? 'licen&ccedil;a at&eacute; ' . $quando : '',
                         'cor' => 'atencao',
                         'icone' => 'fa-lock', 'dias' => $dias);
        }
        if ($validade === '') {
            // Nao e "sem informacao": e uma empresa que chegou pelo
            // auto-cadastro e esta esperando alguem vender. Cor propria de
            // proposito -- e a fila de trabalho, nao um defeito.
            //
            // O DETALHE DIZ O TESTE (11/09/2026). "Sem licenca" sozinho mente
            // por omissao: a loja que acabou de ligar o ERP esta trabalhando
            // pelos sete dias de avaliacao, e a lista dizia que nao. A CHAVE
            // continua `sem_licenca` de proposito -- e ela que a faixa "a
            // vender" conta, e o lead em teste e exatamente quem ha para
            // vender. O function_exists e porque situacao.php e carregada em
            // caminhos que nao conhecem o teste.
            $ateQuando = function_exists('shield_teste_vigente') && shield_teste_vigente($empresa)
                ? shield_teste_fim($empresa)
                : null;

            // QUEM FECHOU CONTRATO E NAO PAGOU tem outro detalhe (11/09/2026):
            // ele nao esta a venda nem avaliando, esta esperando o dinheiro da
            // primeira fatura. E a unica linha 'sem licenca' que a lista de
            // clientes mostra, porque o lead saiu dela.
            $detalhe = '';
            if (trim((string) ($empresa['fechado_em'] ?? '')) !== '') {
                $detalhe = 'aguardando o primeiro pagamento';
            } elseif ($ateQuando !== null) {
                $detalhe = 'em avalia&ccedil;&atilde;o at&eacute; ' . date('d/m/Y', strtotime($ateQuando));
            }

            return array('chave' => 'sem_licenca', 'rotulo' => 'Sem licen&ccedil;a',
                         'detalhe' => $detalhe,
                         'cor' => 'venda',
                         'icone' => 'fa-shopping-cart', 'dias' => null);
        }
        if ($dias < 0) {
            $n = abs($dias);
            return array('chave' => 'vencido', 'rotulo' => 'Vencido',
                         'detalhe' => 'h&aacute; ' . $n . ' dia' . ($n == 1 ? '' : 's'),
                         'cor' => 'erro', 'icone' => 'fa-times-circle', 'dias' => $dias);
        }
        if ($dias <= SHIELD_VENCE_EM_BREVE) {
            // QUEM RENOVA SOZINHO NAO E ATENCAO. A licenca aqui e mensal na
            // maioria esmagadora: com uma janela de 15 dias, um terco da
            // carteira fica laranja TODO DIA -- e medido nesta bancada, os 11
            // que caiam na janela tinham assinatura ativa, ou seja, os 11
            // alarmes eram falsos. Alarme falso todo dia e o que faz o membro
            // parar de olhar a cor, e ai o alarme verdadeiro passa junto.
            //
            // Ele continua aparecendo com a data e o dia do ciclo; o que muda
            // e a COR e a promessa de que algo precisa ser feito.
            if ($renovaSozinho) {
                return array('chave' => 'valido', 'rotulo' => 'V&aacute;lido',
                             'detalhe' => 'renova dia ' . date('j', strtotime($validade)),
                             'cor' => 'ok', 'icone' => 'fa-sync-alt', 'dias' => $dias);
            }

            return array('chave' => 'vence', 'rotulo' => $dias === 0 ? 'Vence hoje' : 'Vence em ' . $dias . ' dia' . ($dias == 1 ? '' : 's'),
                         'detalhe' => $quando, 'cor' => 'atencao',
                         'icone' => 'fa-exclamation-triangle', 'dias' => $dias);
        }
        return array('chave' => 'valido', 'rotulo' => 'V&aacute;lido',
                     'detalhe' => $quando, 'cor' => 'ok',
                     'icone' => 'fa-check-circle', 'dias' => $dias);
    }
}

if (!function_exists('shield_situacao_parque')) {
    /**
     * Terminais dando sinal contra terminais contratados.
     *
     * Estourar o contratado NAO e erro do cliente e sim dinheiro na mesa: e
     * caixa a mais rodando sem estar pago. Por isso a cor e de atencao, nunca
     * de falha -- quem ve esta linha tem de querer ligar para vender, e nao
     * para cobrar um defeito.
     */
    function shield_situacao_parque($vivos, $contratados, $cotaTeste = 0)
    {
        $vivos = (int) $vivos;
        $contratados = (int) $contratados;
        $cotaTeste = (int) $cotaTeste;
        if ($contratados > 0 && $vivos > $contratados) {
            return array('cor' => 'atencao', 'nota' => 'acima do contratado');
        }
        if ($contratados > 0 && $vivos === 0) {
            return array('cor' => 'erro', 'nota' => 'nenhum caixa deu sinal');
        }
        if ($vivos === 0) {
            return array('cor' => 'neutro', 'nota' => 'sem sinal');
        }
        if ($contratados === 0 && $cotaTeste > 0) {
            // QUEM ESTA EM AVALIACAO TEM COTA -- a do teste, que de proposito
            // nao passa por empresa.nterminais (funcoes/licenca/teste.php).
            // Dizer "sem quantidade contratada" a ele e verdade inutil: a tela
            // de avaliacao ao lado mostra "1 / 3". Neutro, e nao verde, porque
            // nada foi contratado ainda -- nao ha conformidade a afirmar.
            return $vivos > $cotaTeste
                ? array('cor' => 'atencao', 'nota' => 'acima da cota do teste')
                : array('cor' => 'neutro', 'nota' => 'cota do teste');
        }
        if ($contratados === 0) {
            // Sem numero contratado no cadastro nao ha contra o que comparar.
            // Verde aqui afirmaria uma conformidade que ninguem conferiu.
            return array('cor' => 'neutro', 'nota' => 'sem quantidade contratada no cadastro');
        }
        return array('cor' => 'ok', 'nota' => '');
    }
}

if (!function_exists('shield_cnpj')) {
    /** CNPJ/CPF com pontuacao. Numero corrido de 14 digitos ninguem confere
     *  contra um papel -- e conferir contra o papel e o que se faz aqui. */
    function shield_cnpj($valor)
    {
        $so = preg_replace('/\D/', '', (string) $valor);
        if (strlen($so) === 14) {
            return substr($so, 0, 2) . '.' . substr($so, 2, 3) . '.' . substr($so, 5, 3)
                 . '/' . substr($so, 8, 4) . '-' . substr($so, 12, 2);
        }
        if (strlen($so) === 11) {
            return substr($so, 0, 3) . '.' . substr($so, 3, 3) . '.' . substr($so, 6, 3)
                 . '-' . substr($so, 9, 2);
        }
        return (string) $valor;
    }
}

if (!function_exists('shield_telefone')) {
    /**
     * Telefone para LER, no formato das telas de editar: (00)00000-0000.
     *
     * O fechamento e a edicao gravam so digitos, mas o auto-cadastro grava o
     * que o ERP mandou, que pode vir formatado, com +55 ou com o zero da
     * operadora. O que nao tiver cara de telefone com DDD volta como veio:
     * sumir com o numero da lista e pior que mostra-lo sem mascara.
     */
    function shield_telefone($valor)
    {
        $original = trim((string) $valor);
        $so = preg_replace('/\D/', '', $original);

        // 0800, 0300, 0500, 0900 nao tem DDD; tirar o zero daria "(80)0123-4567".
        if (preg_match('/^0[3589]00/', $so)) {
            return $original;
        }
        if ((strlen($so) === 12 || strlen($so) === 13) && strpos($so, '55') === 0) {
            $so = substr($so, 2);
        } elseif ((strlen($so) === 11 || strlen($so) === 12) && $so[0] === '0') {
            $so = substr($so, 1);
        }
        if (strlen($so) !== 10 && strlen($so) !== 11) {
            return $original;
        }

        return '(' . substr($so, 0, 2) . ')' . substr($so, 2, -4) . '-' . substr($so, -4);
    }
}

if (!function_exists('shield_whatsapp_url')) {
    /**
     * O link do WhatsApp para o telefone do cliente -- 06/10/2026. Null quando
     * o numero nao tem DDD e assinante (10 ou 11 digitos depois de tirar o 55 e
     * o zero da frente), que e o que o wa.me precisa: 0800 e numero curto nao
     * viram link. A limpeza e a mesma de shield_telefone, para o link discar o
     * numero que a tela mostra -- a ficha punha "55" na frente do que viesse, e o
     * numero ja gravado com 55 virava 5555.
     */
    function shield_whatsapp_url($valor, $texto = '')
    {
        $so = preg_replace('/\D/', '', (string) $valor);
        if (preg_match('/^0[3589]00/', $so)) {
            return null;
        }
        if ((strlen($so) === 12 || strlen($so) === 13) && strpos($so, '55') === 0) {
            $so = substr($so, 2);
        } elseif ((strlen($so) === 11 || strlen($so) === 12) && $so[0] === '0') {
            $so = substr($so, 1);
        }
        if (strlen($so) !== 10 && strlen($so) !== 11) {
            return null;
        }

        return 'https://wa.me/55' . $so . ((string) $texto !== '' ? '?text=' . rawurlencode((string) $texto) : '');
    }
}

if (!function_exists('shield_renovam_sozinho')) {
    /**
     * Quais empresas tem assinatura ATIVA -- ou seja, renovam sem ninguem
     * fazer nada. Devolve um mapa codigo => true, para a tela consultar sem
     * ir ao banco por linha.
     *
     * Uma consulta so, para a pagina inteira: perguntar por cliente seriam 25
     * idas ao banco por pagina, e a lentidao so apareceria na base do membro.
     * Base sem o modulo de assinatura devolve vazio, e ai NINGUEM renova
     * sozinho -- que e a leitura correta para quem cobra por fora.
     */
    function shield_renovam_sozinho(PDO $pdo, array $codigos = array())
    {
        $mapa = array();
        try {
            $sql = "SELECT DISTINCT fk_empresa FROM assinatura WHERE situacao = 'ativa'";
            if ($codigos) {
                $limpos = array();
                foreach ($codigos as $c) { $limpos[] = (int) $c; }
                $sql .= ' AND fk_empresa IN (' . implode(',', $limpos) . ')';
            }
            foreach ($pdo->query($sql)->fetchAll(PDO::FETCH_COLUMN) as $c) {
                $mapa[(int) $c] = true;
            }
        } catch (Throwable $ignorado) { /* sem o modulo: ninguem renova sozinho */ }

        return $mapa;
    }
}

if (!function_exists('shield_situacao_caso_sql')) {
    /**
     * A MESMA ordem de perguntas de shield_situacao_licenca, em SQL -- fatia 4
     * da reorganizacao, 10/09/2026. Devolve uma expressao CASE que
     * responde a chave da faixa (bloqueado, suspenso, sem_licenca, vencido,
     * vence, valido), EXCLUSIVA: cada cliente cai numa so, e as faixas somam o
     * total. Antes a lista contava por SQL proprio em que "bloqueada" era um
     * eixo a parte e "vencidas" nao sabia de suspensao: as faixas se
     * sobrepunham, e "bloqueadas por voce" contava como ato seu o que a regua
     * suspendeu.
     *
     * As datas entram como LITERAL (vem de date(), nunca do usuario): a
     * expressao e repetida em SUM por faixa e no WHERE, e marcador nomeado
     * repetido estoura no PDO.
     *
     * $comAssinatura liga o "quem renova sozinho nao e alarme" (vence -> valido
     * quando ha assinatura ativa); base sem a tabela passa false.
     */
    function shield_situacao_caso_sql($alias = '', $comAssinatura = true, $hoje = null)
    {
        $a = $alias !== '' ? $alias . '.' : '';
        $hoje = $hoje ?: date('Y-m-d');
        $prox = date('Y-m-d', strtotime($hoje . ' +' . SHIELD_VENCE_EM_BREVE . ' days'));
        $validade = $a . 'validade_licenca';
        $semValidade = shield_sql_sem_validade($validade);
        $renova = $comAssinatura
            ? " AND NOT EXISTS (SELECT 1 FROM assinatura asn WHERE asn.fk_empresa = " . $a . "codigo AND asn.situacao = 'ativa')"
            : '';

        return "CASE"
            . " WHEN " . $a . "encerrado_em IS NOT NULL THEN 'encerrado'"
            . " WHEN " . $a . "suspenso_em IS NOT NULL THEN 'suspenso'"
            . " WHEN UPPER(COALESCE(" . $a . "bloqueado, 'N')) = 'S' THEN 'bloqueado'"
            . " WHEN " . $semValidade . " THEN 'sem_licenca'"
            . " WHEN " . $validade . " < '" . $hoje . "' THEN 'vencido'"
            . " WHEN " . $validade . " <= '" . $prox . "'" . $renova . " THEN 'vence'"
            . " ELSE 'valido' END";
    }
}

if (!function_exists('shield_situacao_onde_cliente')) {
    /**
     * O SQL de "isto e cliente", para quem lista clientes -- 11/09/2026.
     *
     * Cliente e quem TEM validade, ou ja teve e foi encerrado, ou FECHOU O
     * CONTRATO (11/09/2026). O resto e lead: empresa que o ERP cadastrou
     * sozinho e que ainda esta avaliando, e o lugar dele e a tela Em avaliacao.
     *
     * O fechamento entrou na conta porque quem fechou contrato ja nao esta
     * avaliando nada -- ele so ainda nao pagou. A licenca continua presa ao
     * pagamento (ou a cortesia da primeira fatura); o que muda e onde ele
     * aparece.
     *
     * E o desenho escrito desde o comeco (docs/reorganizacao-do-painel.md,
     * secao 5, passo 7): "ele sai de Em avaliacao e aparece em Clientes sem
     * codigo de transicao nenhum -- ele passa a ter validade, e ter validade e
     * o que faz alguem ser cliente neste painel desde sempre". A lista tinha
     * ficado para tras: a faixa "sem licenca (a vender)" e mais velha que a
     * tela Em avaliacao (fatia 6, 10/09/2026) e continuou mostrando o lead do
     * outro lado. A mesma loja aparecia nas duas telas, e foi a primeira coisa
     * que o membro estranhou quando ligou o ERP em producao.
     *
     * ENCERRADO FICA, mesmo sem nunca ter tido validade: e o que a Limpeza de
     * cadastros procura, e a faixa "encerradas (a limpar)" e o caminho ate ele.
     * Sem esta metade, o lead que a rotina encerra aos 30 dias sumiria de todas
     * as telas de uma vez.
     */
    function shield_situacao_onde_cliente($alias = '')
    {
        $a = $alias !== '' ? $alias . '.' : '';

        return '(' . shield_sql_com_validade($a . 'validade_licenca')
             . ' OR ' . $a . 'encerrado_em IS NOT NULL'
             . ' OR ' . $a . 'fechado_em IS NOT NULL)';
    }
}

if (!function_exists('shield_situacao_onde_avaliacao')) {
    /**
     * O SQL de "isto esta em avaliacao" -- 17/09/2026. O complemento exato de
     * shield_situacao_onde_cliente: sem validade, nao encerrado e sem contrato
     * iniciado.
     *
     * A fila, o badge da lateral e o bloco do Inicio escreviam cada um o proprio
     * WHERE, e o do Inicio tinha ficado sem o fechado_em: quem deu inicio ao
     * contrato aparecia la como lead e na lista como cliente.
     */
    function shield_situacao_onde_avaliacao($alias = '')
    {
        $a = $alias !== '' ? $alias . '.' : '';

        return '(' . shield_sql_sem_validade($a . 'validade_licenca')
             . ' AND ' . $a . 'encerrado_em IS NULL'
             . ' AND ' . $a . 'fechado_em IS NULL)';
    }
}

if (!function_exists('shield_situacao_faixas')) {
    /**
     * As faixas, na ordem em que a lista mostra, com o valor do filtro
     * (filter_tipo_validade) que cada uma abre. O filtro e o nome antigo,
     * que os links do painel inteiro ja usam.
     */
    function shield_situacao_faixas()
    {
        return array(
            'valido'      => array('filtro' => 'em_dia',      'rotulo' => 'Em dia',      'cor' => 'ok'),
            'vence'       => array('filtro' => 'proximos',    'rotulo' => 'Vencendo',    'cor' => 'atencao'),
            'vencido'     => array('filtro' => 'vencido',     'rotulo' => 'Vencidas',    'cor' => 'erro'),
            'sem_licenca' => array('filtro' => 'sem_licenca', 'rotulo' => 'Sem licen&ccedil;a', 'cor' => 'venda'),
            'suspenso'    => array('filtro' => 'suspenso',    'rotulo' => 'Suspensas',   'cor' => 'erro'),
            'bloqueado'   => array('filtro' => 'bloqueado',   'rotulo' => 'Bloqueadas',  'cor' => 'atencao'),
            'encerrado'   => array('filtro' => 'encerrado',   'rotulo' => 'Encerradas',  'cor' => 'neutro'),
        );
    }

    /** filtro (em_dia, proximos...) -> chave da faixa; desconhecido devolve ''. */
    function shield_situacao_chave_do_filtro($filtro)
    {
        foreach (shield_situacao_faixas() as $chave => $f) {
            if ($f['filtro'] === (string) $filtro) {
                return $chave;
            }
        }

        return '';
    }
}

if (!function_exists('shield_situacao_contar')) {
    /**
     * Quantos clientes em cada faixa, EXCLUSIVAS, mais 'todas'. Uma consulta.
     * $where e um " WHERE ..." opcional (sem a propria situacao) com os seus
     * parametros. Base sem a tabela de assinatura conta sem o "renova sozinho".
     */
    function shield_situacao_contar(PDO $pdo, $where = '', array $params = array())
    {
        $contagem = array('todas' => 0);
        foreach (array_keys(shield_situacao_faixas()) as $chave) {
            $contagem[$chave] = 0;
        }

        foreach (array(true, false) as $comAssinatura) {
            try {
                $caso = shield_situacao_caso_sql('', $comAssinatura);
                $somas = array();
                foreach (array_keys(shield_situacao_faixas()) as $chave) {
                    $somas[] = "SUM((" . $caso . ") = '" . $chave . "') AS " . $chave;
                }
                $stmt = $pdo->prepare('SELECT COUNT(*) AS todas, ' . implode(', ', $somas) . ' FROM empresa' . $where);
                $stmt->execute($params);
                $linha = $stmt->fetch(PDO::FETCH_ASSOC) ?: array();
                foreach ($contagem as $chave => $ignora) {
                    $contagem[$chave] = (int) ($linha[$chave] ?? 0);
                }

                return $contagem;
            } catch (Throwable $tentaSemAssinatura) {
                // A primeira tentativa usa a tabela de assinatura; sem ela, conta sem.
            }
        }

        return $contagem;
    }
}
