<?php

// Atualizacao do painel pela web - 25/08/2026.
//
// O membro sobe o painel por FTP. Sem isto, cada correcao exige que ele mande
// a pasta inteira de novo -- e metade do parque nunca recebe melhoria nenhuma,
// o que faz o resto da reforma nao chegar em ninguem.
//
// O DESENHO E COPIADO DO ATUALIZADOR DO ERP, que ja esta provado em campo:
//
//   ler manifesto -> comparar versao -> baixar para .part -> conferir TAMANHO
//   -> conferir SHA256 -> extrair para pronta/ -> so entao trocar
//
// A ORDEM E A DEFESA. Nada da pasta do painel e tocado antes de o pacote estar
// baixado inteiro e conferido. A troca e a ultima etapa, e cada arquivo trocado
// vira .old antes de receber o novo -- falhando qualquer um, tudo volta.
//
// TRES COISAS QUE A HOSPEDAGEM DO MEMBRO IMPOE, e que mudam o desenho:
//
//   1. Sem shell e sem processo residente. Tudo roda por requisicao web.
//   2. O provedor corta a requisicao no limite de tempo dele. Por isso o
//      download vai em FATIAS, com Range, e o estado fica em disco: a proxima
//      requisicao continua de onde parou em vez de recomecar.
//   3. O endpoint de licenca NAO pode cair enquanto isto acontece. Por isso a
//      gravacao de cada arquivo termina em rename(), que e atomico no mesmo
//      sistema de arquivos: uma requisicao que chegue no meio le o arquivo
//      velho ou o novo, nunca um pela metade. Gravar por cima nao tem essa
//      garantia -- e o endpoint de licenca e a rota mais quente do sistema.

require_once __DIR__ . '/../nucleo/versao.php';
require_once __DIR__ . '/restos.php';

const SHIELD_ATU_FATIA_SEGUNDOS = 10;      // quanto cada requisicao baixa
const SHIELD_ATU_TETO_BYTES = 209715200;   // 200 MB: pacote maior e engano
const SHIELD_ATU_TEMPO_REDE = 20;

// ---------------------------------------------------------------- versao ---

function shield_atu_versao_instalada()
{
    return (string) SHIELD_VERSAO;
}

/** Os TRES primeiros numeros. O resto e rotulo e nao entra na conta. */
function shield_atu_versao_partes($versao)
{
    if (preg_match('/(\d+)(?:\.(\d+))?(?:\.(\d+))?/', (string) $versao, $m)) {
        return array((int) $m[1], (int) ($m[2] ?? 0), (int) ($m[3] ?? 0));
    }

    return array(0, 0, 0);
}

function shield_atu_versao_compara($a, $b)
{
    return shield_atu_versao_partes($a) <=> shield_atu_versao_partes($b);
}

// ------------------------------------------------------------- endereco ---

function shield_atu_url(PDO $pdo)
{
    return trim((string) shield_get_system_meta($pdo, 'atualizacao_url', ''));
}

function shield_atu_definir_url(PDO $pdo, $url)
{
    shield_set_system_meta($pdo, 'atualizacao_url', trim((string) $url));
}

/**
 * Aceita o endereco do manifesto OU o do proprio .zip -- neste caso procura o
 * versao.json ao lado. E a mesma regra do ERP, e existe porque o membro cola o
 * link que ele tem na mao, sem saber a diferenca entre os dois.
 */
function shield_atu_url_do_manifesto($url)
{
    $url = trim((string) $url);
    if ($url === '') {
        return '';
    }
    if (preg_match('/\.json(\?.*)?$/i', $url)) {
        return $url;
    }

    $semQuery = preg_replace('/\?.*$/', '', $url);

    return rtrim(str_replace(chr(92), '/', dirname($semQuery)), '/') . '/versao.json';
}

// ------------------------------------------------------------- manifesto ---

function shield_atu_buscar($url, &$erro)
{
    $erro = '';
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_TIMEOUT => SHIELD_ATU_TEMPO_REDE,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_USERAGENT => 'PainelShield/' . shield_atu_versao_instalada(),
    ));
    $corpo = curl_exec($ch);
    $codigo = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $falha = curl_error($ch);
    curl_close($ch);

    if ($corpo === false) {
        $erro = 'Nao consegui falar com o servidor: ' . $falha;
        return null;
    }
    if ($codigo !== 200) {
        $erro = 'O servidor respondeu ' . $codigo . ' no lugar do manifesto.';
        return null;
    }

    return (string) $corpo;
}

/**
 * Le e VALIDA o manifesto. Ele e o contrato inteiro da atualizacao: se vier
 * torto, o resto nao tem como se defender. A recusa e aqui.
 */
function shield_atu_ler_manifesto($url, &$erro)
{
    $texto = shield_atu_buscar($url, $erro);
    if ($texto === null) {
        return null;
    }

    return shield_atu_manifesto_de_texto($texto, $url, $erro);
}

/**
 * O manifesto a partir do TEXTO do versao.json -- 16/09/2026. Separado da busca
 * porque o texto agora chega por dois caminhos: baixado do endereco gravado ou
 * enviado pelo navegador. $url e o endereco de onde veio ('' no envio): serve
 * so para resolver o nome do zip ao lado do manifesto.
 */
function shield_atu_manifesto_de_texto($texto, $url, &$erro)
{
    $erro = '';
    $dados = json_decode((string) $texto, true);
    if (!is_array($dados)) {
        // Pagina de erro do provedor devolvida com status 200 cai aqui.
        $erro = 'O endereco respondeu, mas o conteudo nao e um manifesto.';
        return null;
    }

    $versao = trim((string) ($dados['versao'] ?? ''));
    $arquivo = trim((string) ($dados['arquivo'] ?? ''));
    $tamanho = (int) ($dados['tamanho'] ?? 0);
    $sha = strtolower(trim((string) ($dados['sha256'] ?? '')));

    if ($versao === '' || $arquivo === '') {
        $erro = 'O manifesto nao diz a versao ou o arquivo.';
        return null;
    }
    if ($tamanho <= 0 || $tamanho > SHIELD_ATU_TETO_BYTES) {
        $erro = 'O tamanho declarado no manifesto nao faz sentido.';
        return null;
    }
    if (!preg_match('/^[a-f0-9]{64}$/', $sha)) {
        $erro = 'O manifesto nao traz um sha256 valido.';
        return null;
    }

    // Nome solto = ao lado do manifesto; URL inteira = outro host, e vale.
    $arquivoUrl = $arquivo;
    if ((string) $url !== '' && !preg_match('#^https?://#i', $arquivo)) {
        $arquivoUrl = rtrim(str_replace(chr(92), '/', dirname(preg_replace('/\?.*$/', '', (string) $url))), '/')
            . '/' . ltrim($arquivo, '/');
    }

    return array(
        'versao' => $versao,
        'arquivo' => $arquivo,
        'arquivo_url' => $arquivoUrl,
        'tamanho' => $tamanho,
        'sha256' => $sha,
        'obrigatoria' => !empty($dados['obrigatoria']),
        'minima' => trim((string) ($dados['minima'] ?? '')),
        'notas' => trim((string) ($dados['notas'] ?? '')),
    );
}

/**
 * Diz o que fazer com este manifesto. O piso `minima` existe para o pacote que
 * so pode cair sobre quem ja passou por uma versao intermediaria -- senao o
 * codigo novo cai sobre um banco que migracao nenhuma tocou.
 */
/** O sha256 do ultimo pacote que o atualizador instalou (shield_system_meta). */
const SHIELD_ATU_META_SHA_INSTALADO = 'atualizacao_sha256_instalado';

/**
 * Ha o que instalar? Devolve ['ha', 'reinstalar', 'motivo'].
 *
 * A MESMA VERSAO COM OUTRO PACOTE PODE SER REINSTALADA (15/09/2026). O 4.2.8 foi
 * publicado de novo com o conserto do opcache, e quem ja estava nele ouvia "ja
 * esta na versao mais nova": so o numero era comparado. Com o sha256 do pacote
 * instalado guardado e outro no manifesto, oferece reinstalar. Sem sha256
 * guardado (instalado antes disto, ou extraido a mao) nao ha como saber.
 */
function shield_atu_avaliar(array $manifesto, $shaInstalado = '')
{
    $instalada = shield_atu_versao_instalada();
    $compara = (int) shield_atu_versao_compara($manifesto['versao'], $instalada);

    if ($compara < 0) {
        return array('ha' => false, 'reinstalar' => false, 'motivo' => 'O painel ja esta na versao mais nova.');
    }
    if ($compara === 0) {
        $sha = strtolower(trim((string) ($manifesto['sha256'] ?? '')));
        $instalado = strtolower(trim((string) $shaInstalado));
        if ($instalado === '' || $sha === '' || hash_equals($instalado, $sha)) {
            return array('ha' => false, 'reinstalar' => false, 'motivo' => 'O painel ja esta na versao mais nova.');
        }

        return array('ha' => true, 'reinstalar' => true,
                     'motivo' => 'O pacote desta versao foi publicado de novo e pode ser reinstalado.');
    }

    $minima = (string) $manifesto['minima'];
    if ($minima !== '' && shield_atu_versao_compara($instalada, $minima) < 0) {
        return array(
            'ha' => false,
            'reinstalar' => false,
            'motivo' => 'Esta versao exige passar antes pela ' . $minima
                . ', e o painel esta na ' . $instalada . '.',
        );
    }

    return array('ha' => true, 'reinstalar' => false, 'motivo' => '');
}

// ---------------------------------------------------------------- pastas ---

function shield_atu_raiz()
{
    return dirname(__DIR__, 2);
}

function shield_atu_pasta()
{
    // FORA do public/: aqui mora o .zip baixado e a arvore extraida dele.
    // Enquanto isso vivia em update/pacotes, o pacote de atualizacao ficava
    // dentro do diretorio servido pelo Apache.
    return shield_atu_raiz() . '/estagio/pacotes';
}

function shield_atu_garantir_pasta(&$erro)
{
    $erro = '';
    $pasta = shield_atu_pasta();
    if (!is_dir($pasta) && !@mkdir($pasta, 0775, true) && !is_dir($pasta)) {
        $erro = 'Nao consegui criar ' . $pasta . '. Confira a permissao de escrita.';
        return false;
    }
    if (!is_writable($pasta)) {
        $erro = 'Sem permissao de escrita em ' . $pasta . '.';
        return false;
    }

    // Pacote e estado nao sao para servir pela web.
    $guarda = $pasta . '/.htaccess';
    if (!is_file($guarda)) {
        @file_put_contents($guarda, "Require all denied" . PHP_EOL
            . "<IfModule !mod_authz_core.c>" . PHP_EOL . "Deny from all" . PHP_EOL . "</IfModule>" . PHP_EOL);
    }

    return true;
}

// ---------------------------------------------------------------- estado ---

function shield_atu_arquivo_estado()
{
    return shield_atu_pasta() . '/estado.json';
}

function shield_atu_estado()
{
    $p = shield_atu_arquivo_estado();
    if (!is_file($p)) {
        return array();
    }
    $d = json_decode((string) @file_get_contents($p), true);

    return is_array($d) ? $d : array();
}

function shield_atu_gravar_estado(array $estado)
{
    @file_put_contents(
        shield_atu_arquivo_estado(),
        json_encode($estado, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
    );
}

function shield_atu_zerar_estado()
{
    @unlink(shield_atu_arquivo_estado());
    @unlink(shield_atu_pasta() . '/baixando.part');
    @unlink(shield_atu_pasta() . '/_pacote.ok');
    shield_atu_apagar_arvore(shield_atu_pasta() . '/pronta');
}

// -------------------------------------------------------------- download ---

/**
 * Baixa uma FATIA e devolve quanto ja veio. Nao baixa tudo de uma vez de
 * proposito: hospedagem compartilhada corta a requisicao no limite de tempo, e
 * um download que recomeca do zero a cada corte nunca termina num pacote de
 * 20 MB. O Range faz a proxima requisicao continuar de onde parou.
 */
function shield_atu_baixar_fatia(array $manifesto, &$erro)
{
    $erro = '';
    if (!shield_atu_garantir_pasta($erro)) {
        return null;
    }

    $destino = shield_atu_pasta() . '/baixando.part';
    $ja = is_file($destino) ? (int) filesize($destino) : 0;

    if ($ja > (int) $manifesto['tamanho']) {
        // Sobrou lixo de uma tentativa anterior, com outro pacote.
        @unlink($destino);
        $ja = 0;
    }
    if ($ja >= (int) $manifesto['tamanho']) {
        return array('baixados' => $ja, 'total' => (int) $manifesto['tamanho'], 'completo' => true);
    }

    $arquivo = @fopen($destino, $ja > 0 ? 'ab' : 'wb');
    if ($arquivo === false) {
        $erro = 'Nao consegui abrir o arquivo de download.';
        return null;
    }

    $limite = microtime(true) + SHIELD_ATU_FATIA_SEGUNDOS;
    $ch = curl_init($manifesto['arquivo_url']);
    curl_setopt_array($ch, array(
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => SHIELD_ATU_FATIA_SEGUNDOS + SHIELD_ATU_TEMPO_REDE,
        CURLOPT_RANGE => $ja . '-',
        CURLOPT_USERAGENT => 'PainelShield/' . shield_atu_versao_instalada(),
        CURLOPT_WRITEFUNCTION => function ($ch, $pedaco) use ($arquivo, $limite) {
            $n = fwrite($arquivo, $pedaco);
            if ($n === false) {
                return 0;
            }
            // Passou da fatia: devolver menos do que veio encerra a conexao, e
            // a proxima requisicao continua pelo Range.
            return microtime(true) >= $limite ? 0 : $n;
        },
    ));
    $ok = curl_exec($ch);
    $codigo = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $numeroErro = curl_errno($ch);
    curl_close($ch);
    fclose($arquivo);

    $baixados = is_file($destino) ? (int) filesize($destino) : 0;

    // CURLE_WRITE_ERROR (23) e o NOSSO corte de fatia, nao e falha.
    if ($ok === false && $numeroErro !== CURLE_WRITE_ERROR && $baixados <= $ja) {
        $erro = 'O download nao avancou. Confira o endereco e a conexao.';
        return null;
    }
    if ($codigo !== 0 && $codigo !== 200 && $codigo !== 206) {
        $erro = 'O servidor respondeu ' . $codigo . ' ao entregar o pacote.';
        return null;
    }

    return array(
        'baixados' => $baixados,
        'total' => (int) $manifesto['tamanho'],
        'completo' => $baixados >= (int) $manifesto['tamanho'],
    );
}

// -------------------------------------------------------------- conferir ---

/**
 * Tamanho ANTES do sha256, e os dois antes de qualquer extracao. O tamanho pega
 * o download cortado e a pagina de erro do provedor salva como zip; o sha256
 * pega o resto. Sem isto, o que se extrai por cima do painel e o que o servidor
 * mandou -- seja la o que for.
 */
/**
 * Encosta uma FATIA enviada pelo navegador no mesmo baixando.part do download
 * -- 16/09/2026. So aceita a fatia que continua de onde o arquivo parou: aba
 * repetida ou rede que reenviou nao corrompe o pacote, e a resposta diz de
 * onde retomar. Posicao 0 recomeca (o membro escolheu outro zip). $pasta e so
 * para os testes.
 */
function shield_atu_receber_fatia(array $manifesto, $posicao, $bytes, &$erro, $pasta = null)
{
    $erro = '';
    if ($pasta === null) {
        if (!shield_atu_garantir_pasta($erro)) {
            return null;
        }
        $pasta = shield_atu_pasta();
    }
    $destino = rtrim((string) $pasta, '/') . '/baixando.part';
    $posicao = (int) $posicao;
    $total = (int) $manifesto['tamanho'];
    $ja = is_file($destino) ? (int) filesize($destino) : 0;

    if ($posicao === 0) {
        $ja = 0;
    } elseif ($posicao !== $ja) {
        $erro = 'A fatia veio para a posicao ' . $posicao . ', e o arquivo esta em ' . $ja . '. Continue de ' . $ja . '.';
        return null;
    }
    $bytes = (string) $bytes;
    if ($bytes === '') {
        $erro = 'A fatia veio vazia.';
        return null;
    }
    if ($ja + strlen($bytes) > $total) {
        $erro = 'O pacote passa dos ' . $total . ' bytes que o manifesto declara. Recusado.';
        return null;
    }

    $ok = @file_put_contents($destino, $bytes, $posicao === 0 ? 0 : FILE_APPEND);
    if ($ok !== strlen($bytes)) {
        $erro = 'Nao consegui gravar a fatia em ' . $destino . '.';
        return null;
    }
    $baixados = (int) filesize($destino);

    return array('baixados' => $baixados, 'total' => $total, 'completo' => $baixados >= $total);
}

function shield_atu_conferir(array $manifesto, &$erro)
{
    $erro = '';
    $p = shield_atu_pasta() . '/baixando.part';
    if (!is_file($p)) {
        $erro = 'O pacote baixado nao esta mais na pasta.';
        return false;
    }

    $tamanho = (int) filesize($p);
    if ($tamanho !== (int) $manifesto['tamanho']) {
        $erro = 'O pacote veio com ' . $tamanho . ' bytes e o manifesto diz '
            . (int) $manifesto['tamanho'] . '. Recusado.';
        return false;
    }

    if (!hash_equals((string) $manifesto['sha256'], (string) hash_file('sha256', $p))) {
        $erro = 'A soma sha256 do pacote nao confere com a do manifesto. Recusado.';
        return false;
    }

    return true;
}

// --------------------------------------------------------------- extrair ---

function shield_atu_apagar_arvore($caminho)
{
    if (!is_dir($caminho)) {
        return is_file($caminho) ? @unlink($caminho) : true;
    }

    $itens = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($caminho, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($itens as $item) {
        $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
    }

    return @rmdir($caminho);
}

function shield_atu_extrair(&$erro)
{
    $erro = '';
    $zipPath = shield_atu_pasta() . '/baixando.part';
    $pronta = shield_atu_pasta() . '/pronta';

    shield_atu_apagar_arvore($pronta);
    if (!@mkdir($pronta, 0775, true) && !is_dir($pronta)) {
        $erro = 'Nao consegui criar a pasta de estagio.';
        return false;
    }

    $zip = new ZipArchive();
    if ($zip->open($zipPath) !== true) {
        $erro = 'O pacote nao abre como zip.';
        return false;
    }

    // Caminho apontando para fora da pasta de estagio e ataque conhecido
    // (zip slip): confere-se ANTES de extrair, senao o estrago ja aconteceu.
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $nome = (string) $zip->getNameIndex($i);
        $primeiro = $nome === '' ? '' : $nome[0];
        if ($nome === '' || strpos($nome, '..') !== false || strpos($nome, ':') !== false
            || $primeiro === '/' || $primeiro === chr(92)) {
            $zip->close();
            $erro = 'O pacote traz um caminho invalido: ' . $nome;
            return false;
        }
    }

    if (!$zip->extractTo($pronta)) {
        $zip->close();
        $erro = 'Nao consegui extrair o pacote.';
        return false;
    }
    $zip->close();

    // Zip com uma pasta unica dentro (o "Download ZIP" do git faz assim): desce
    // um nivel, senao a troca copiaria a PASTA em vez do conteudo dela.
    $dentro = array_values(array_diff(scandir($pronta) ?: array(), array('.', '..')));
    if (count($dentro) === 1 && is_dir($pronta . '/' . $dentro[0])) {
        $pronta = $pronta . '/' . $dentro[0];
    }

    if (!is_file($pronta . '/index.php')) {
        $erro = 'O pacote nao parece ser o painel: nao achei o index.php dentro.';
        return false;
    }

    @file_put_contents(shield_atu_pasta() . '/_pacote.ok', $pronta);

    return true;
}

function shield_atu_pasta_pronta()
{
    $marca = shield_atu_pasta() . '/_pacote.ok';
    if (!is_file($marca)) {
        return '';
    }
    $p = trim((string) @file_get_contents($marca));

    return ($p !== '' && is_dir($p)) ? $p : '';
}

// --------------------------------------------------------------- aplicar ---

/**
 * O que e da INSTALACAO e nao do codigo: nunca e trocado por atualizacao.
 *
 * `estagio` entrou no lugar de `update/pacotes` em 04/09/2026. O estagio da
 * atualizacao mudou de lugar na fase 3 -- saiu de dentro do que o Apache serve
 * --, e esta lista ficou nomeando um caminho que nao existe mais e omitindo o
 * que existe. Nao chegou a morder porque o .gitignore impede o estagio/ de
 * entrar num pacote montado a partir do repositorio; mas uma lista de seguranca
 * que protege o lugar errado so avisa quando ja e tarde.
 *
 * A pasta inteira, e nao `estagio/pacotes`: e area de trabalho, e o que cair
 * ali dentro depois tambem nao e codigo.
 */
function shield_atu_preservados()
{
    return array('config', 'uploads', 'estagio', '.well-known');
}

/**
 * A troca. E a UNICA etapa que mexe na pasta do painel, e ela e reversivel:
 * cada destino vira .old antes de receber o novo e, falhando qualquer arquivo,
 * tudo volta.
 *
 * NAO trocar o par copy+rename por um copy direto sobre o destino: o rename e
 * atomico no mesmo sistema de arquivos, entao a requisicao de licenca que
 * chegue no meio le o arquivo velho ou o novo -- nunca um pela metade. Gravar
 * por cima abre exatamente a janela que este desenho existe para fechar.
 */
function shield_atu_aplicar(&$erro, array &$relatorio = array())
{
    $erro = '';
    $origem = shield_atu_pasta_pronta();
    if ($origem === '') {
        $erro = 'Nao ha pacote conferido para aplicar.';

        return false;
    }

    return shield_atu_aplicar_em($origem, shield_atu_raiz(), $erro, $relatorio);
}

/**
 * A troca propriamente dita, com origem e destino explicitos.
 *
 * Os caminhos entram por parametro para que isto possa ser TESTADO. Enquanto a
 * raiz saia de shield_atu_raiz(), exercitar a troca significava sobrescrever o
 * painel de quem rodasse a suite -- e por isso a etapa mais perigosa do projeto
 * era a menos coberta dele.
 *
 * ONDE O BACKUP FICA (ALTO-4, 08/09/2026): em `estagio/backup/<caminho>`, e nao
 * mais em `<destino>.old`. O `.old` ao lado do destino caia dentro de public/,
 * e extensao que o Apache nao conhece ele entrega como TEXTO -- um
 * public/api/licenca.php.old era o codigo-fonte na web. As extensoes negadas no
 * .htaccess e no vhost seguram isso, mas sao mitigacao: o estagio ja esta fora
 * do que o servidor publica, e e o lugar certo para material que e meio do
 * caminho.
 *
 * O rename continua ATOMICO porque estagio/ mora sob a mesma raiz, logo no
 * mesmo sistema de arquivos. Quem montar o estagio em outro volume faz o rename
 * falhar -- e falhar aqui e seguro: a troca aborta e desfaz o que ja fez. O que
 * nao pode acontecer e a requisicao de licenca ler um arquivo pela metade, e
 * disso o par copy+rename continua cuidando.
 */
function shield_atu_aplicar_em($origem, $raiz, &$erro, array &$relatorio = array())
{
    $erro = '';
    $origem = rtrim((string) $origem, '/');
    $raiz = rtrim((string) $raiz, '/');
    $preservar = shield_atu_preservados();
    $trocados = array();

    // A LISTA E CONFERIDA ANTES DE QUALQUER MUDANCA. Lista invalida nao pode
    // deixar a instalacao pela metade: se ha algo errado nela, o certo e nao
    // ter comecado.
    $remover = shield_atu_remocoes($origem, $raiz, $erro);
    if ($remover === false) {
        return false;
    }

    $itens = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($origem, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($itens as $item) {
        $relativo = str_replace(chr(92), '/', substr($item->getPathname(), strlen($origem) + 1));

        $pular = ($relativo === SHIELD_ATU_LISTA_REMOCAO);
        foreach ($preservar as $p) {
            if ($relativo === $p || strpos($relativo, $p . '/') === 0) {
                $pular = true;
                break;
            }
        }
        if ($pular) {
            continue;
        }

        $destino = $raiz . '/' . $relativo;

        if ($item->isDir()) {
            if (!is_dir($destino) && !@mkdir($destino, 0775, true) && !is_dir($destino)) {
                $erro = 'Nao consegui criar a pasta ' . $relativo . '. Nada foi alterado.';
                shield_atu_desfazer($trocados);

                return false;
            }
            continue;
        }

        $backup = shield_atu_backup_de($raiz, $relativo);
        $temBackup = false;
        if (is_file($destino)) {
            if (!shield_atu_garantir_pasta_de($backup)) {
                $erro = 'Nao consegui preparar o backup de ' . $relativo . '. Nada foi alterado.';
                shield_atu_desfazer($trocados);

                return false;
            }
            @unlink($backup);
            if (!@rename($destino, $backup)) {
                $erro = 'Nao consegui guardar a copia de ' . $relativo . '. Nada foi alterado.';
                shield_atu_desfazer($trocados);

                return false;
            }
            $temBackup = true;
        }

        if (!@copy($item->getPathname(), $destino . '.novo')
            || !@rename($destino . '.novo', $destino)) {
            @unlink($destino . '.novo');
            if ($temBackup) {
                @rename($backup, $destino);
            }
            $erro = 'Nao consegui gravar ' . $relativo . '. Nada foi alterado.';
            shield_atu_desfazer($trocados);

            return false;
        }

        $trocados[] = array($destino, $temBackup ? $backup : '');
    }

    // AS REMOCOES SO ACONTECEM COM A COPIA INTEIRA JA FEITA, e nao sao unlink:
    // o alvo e RENOMEADO para o mesmo backup dos substituidos, entra na lista
    // do desfazer e so some de verdade quando a faxina rodar, na requisicao
    // seguinte. Ate la, tudo volta.
    foreach ($remover as $relativo) {
        $alvo = $raiz . '/' . $relativo;
        if (!is_file($alvo)) {
            continue;
        }

        $backup = shield_atu_backup_de($raiz, $relativo);
        if (!shield_atu_garantir_pasta_de($backup)) {
            $erro = 'Nao consegui preparar o backup de ' . $relativo . '. Nada foi alterado.';
            shield_atu_desfazer($trocados);

            return false;
        }
        @unlink($backup);
        if (!@rename($alvo, $backup)) {
            $erro = 'Nao consegui remover ' . $relativo . '. Nada foi alterado.';
            shield_atu_desfazer($trocados);

            return false;
        }

        $trocados[] = array($alvo, $backup);
    }

    $relatorio['arquivos'] = count($trocados);
    $relatorio['removidos'] = count($remover);
    $relatorio['trocados'] = $trocados;

    // Avisa que ha backup e restos no disco. A faxina roda na proxima
    // requisicao, vinda do router -- nunca aqui: apagar o caminho de volta na
    // mesma requisicao em que se troca e ficar sem ele exatamente quando ele
    // serve.
    shield_atu_marcar_restos($raiz);

    return true;
}

/** Onde o backup de um caminho relativo mora. Fora do que o Apache serve. */
function shield_atu_backup_de($raiz, $relativo)
{
    return rtrim((string) $raiz, '/') . '/estagio/backup/' . ltrim((string) $relativo, '/');
}

/** Cria a pasta que vai receber o arquivo. Devolve false quando nao da. */
function shield_atu_garantir_pasta_de($arquivo)
{
    $pasta = dirname((string) $arquivo);

    return is_dir($pasta) || @mkdir($pasta, 0775, true) || is_dir($pasta);
}

/** O nome do arquivo que, dentro do pacote, diz o que sair da instalacao. */
const SHIELD_ATU_LISTA_REMOCAO = '_remover.txt';

/**
 * O que o pacote manda APAGAR da instalacao.
 *
 * O atualizador so sabia copiar por cima, entao arquivo que saiu do projeto
 * continuava vivo na maquina do membro para sempre -- sao os 90 orfaos de
 * docs/orfaos-do-move.md, e os que eram ponto de entrada continuavam sendo
 * servidos. Esta lista fecha isso.
 *
 * ELA VEM NO PACOTE, e nao no codigo, e a razao e pratica: assim uma
 * atualizacao futura pode remover o que esta introduziu, sem depender de
 * alguem lembrar de mexer no atualizador.
 *
 * E CADA LINHA E CONFERIDA, porque daqui sai um apagar na maquina do cliente.
 * Recusa caminho absoluto, caminho que sobe de pasta, qualquer coisa dentro do
 * que shield_atu_preservados() protege, e PASTA -- apagar pasta levaria junto o
 * que o membro tenha posto dentro dela, que o pacote nao conhece. Caminho que
 * ja nao existe e simplesmente pulado: o painel pode nunca ter tido aquilo.
 *
 * @return array|false os caminhos relativos, ou false com $erro preenchido
 */
function shield_atu_remocoes($origem, $raiz, &$erro)
{
    $erro = '';
    $lista = rtrim((string) $origem, '/') . '/' . SHIELD_ATU_LISTA_REMOCAO;
    if (!is_file($lista)) {
        return array();
    }

    $raiz = rtrim((string) $raiz, '/');
    $preservar = shield_atu_preservados();
    $saida = array();

    foreach (preg_split('/
||
/', (string) @file_get_contents($lista)) as $linha) {
        $caminho = str_replace(chr(92), '/', trim((string) $linha));
        if ($caminho === '' || $caminho[0] === '#') {
            continue;
        }

        $recusa = shield_atu_remocao_recusada($caminho, $preservar);
        if ($recusa !== '') {
            $erro = 'O ' . SHIELD_ATU_LISTA_REMOCAO . ' do pacote traz um caminho que nao posso'
                . ' apagar (' . $caminho . '): ' . $recusa . ' Nada foi alterado.';

            return false;
        }

        $alvo = $raiz . '/' . $caminho;

        if (is_dir($alvo)) {
            $erro = 'O ' . SHIELD_ATU_LISTA_REMOCAO . ' do pacote pede para apagar uma PASTA ('
                . $caminho . '), e isso levaria junto o que houver dentro dela. Nada foi alterado.';

            return false;
        }

        if (is_file($alvo)) {
            $saida[] = $caminho;
        }
    }

    return $saida;
}

/** Por que este caminho nao pode ser apagado. Vazio quando pode. */
function shield_atu_remocao_recusada($caminho, array $preservar)
{
    if ($caminho[0] === '/' || preg_match('/^[A-Za-z]:/', $caminho) === 1) {
        return 'e caminho absoluto.';
    }

    if (strpos($caminho, '..') !== false) {
        return 'sobe de pasta.';
    }

    foreach ($preservar as $p) {
        if ($caminho === $p || strpos($caminho, $p . '/') === 0) {
            return 'esta em ' . $p . '/, que e da instalacao do membro e nunca e tocada.';
        }
    }

    return '';
}

/** Devolve tudo o que ja tinha sido trocado. Chamado no primeiro erro. */
function shield_atu_desfazer(array $trocados)
{
    foreach (array_reverse($trocados) as $par) {
        list($destino, $backup) = $par;
        if ($backup !== '' && is_file($backup)) {
            @unlink($destino);
            @rename($backup, $destino);
        } else {
            @unlink($destino);
        }
    }
}

/**
 * Os .old da troca anterior e o estagio ja consumido. Roda no acesso SEGUINTE,
 * nunca junto da troca: apagar o caminho de volta na mesma requisicao em que se
 * troca e ficar sem ele exatamente quando ele serve.
 */
function shield_atu_limpar_restos($raiz = null)
{
    // A raiz entra por parametro para poder ser TESTADA. Sem isso, exercitar
    // esta funcao significaria apagar arquivo da instalacao de quem roda a
    // suite -- e por isso ela nao tinha teste nenhum ate 08/09/2026.
    $raiz = $raiz === null ? shield_atu_raiz() : rtrim((string) $raiz, '/');
    $n = 0;

    $itens = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($raiz, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($itens as $item) {
        if (!$item->isFile()) {
            continue;
        }
        $nome = $item->getFilename();
        if (substr($nome, -4) === '.old' || substr($nome, -5) === '.novo') {
            @unlink($item->getPathname());
            $n++;
        }
    }

    // A varredura acima continua existindo para os `.old` das trocas ANTIGAS,
    // que ficaram ao lado do destino em toda instalacao atualizada antes de
    // 08/09/2026. Ela e o que finalmente os tira do disco.
    //
    // O backup das trocas novas mora em estagio/backup e sai inteiro: sem isto
    // a arvore cresceria a cada atualizacao, e o estagio e a pasta que menos
    // gente olha.
    $backup = $raiz . '/estagio/backup';
    if (is_dir($backup)) {
        $arquivos = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($backup, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($arquivos as $arquivo) {
            if ($arquivo->isFile()) {
                $n++;
            }
        }
        shield_atu_apagar_arvore($backup);
    }

    return $n;
}
