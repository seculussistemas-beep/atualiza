<?php

// Os restos da troca, e o pouco que toda requisicao pode pagar -- 08/09/2026.
//
// O atualizador renomeia cada arquivo substituido para `<arquivo>.old` antes de
// receber o novo. Extensao que o Apache nao conhece ele entrega como TEXTO: um
// `public/api/licenca.php.old` seria o codigo-fonte aberto na web. As extensoes
// estao negadas no public/.htaccess e no docker/php/vhost.conf, mas isso e
// MITIGACAO -- o conserto e o resto sair do disco.
//
// E ele nao saia. shield_atu_limpar_restos() tinha um chamador so, a tela de
// atualizacao, e ainda dentro de `if (!$emJson)` -- entao nem durante a
// propria atualizacao rodava. Na pratica, quem atualizava e nao RECARREGAVA
// aquela tela ficava com os restos por tempo indeterminado. Nao era a excecao;
// era o estado normal.
//
// O QUE ESTE ARQUIVO RESOLVE e o custo. A faxina percorre a arvore inteira do
// painel; pendurar isso em toda requisicao seria trocar um vazamento por uma
// lentidao. Com a marca, a conferencia custa um is_file() e volta -- a
// varredura so acontece na primeira requisicao DEPOIS de uma troca, e some
// sozinha em seguida.
//
// Este arquivo e minusculo de proposito: quem o carrega e o router, a cada
// tela. O atualizador inteiro so entra em memoria quando ha o que limpar.

/** A marca fica no estagio, que ja esta fora do que o Apache serve. */
function shield_atu_marca_restos($raiz = null)
{
    $raiz = $raiz === null ? dirname(__DIR__, 2) : rtrim((string) $raiz, '/');

    return $raiz . '/estagio/pacotes/_restos.pendente';
}

/** Ha troca recente esperando faxina? O(1) -- e o que roda em toda tela. */
function shield_atu_restos_pendentes($raiz = null)
{
    return is_file(shield_atu_marca_restos($raiz));
}

/**
 * Registra que a troca deixou restos. Chamado por shield_atu_aplicar().
 *
 * Nao falha o update se nao conseguir gravar: sem a marca a faxina volta a
 * depender da tela de atualizacao, que e o comportamento antigo -- ruim, mas
 * nao e motivo para derrubar uma troca que deu certo.
 */
function shield_atu_marcar_restos($raiz = null)
{
    return @file_put_contents(shield_atu_marca_restos($raiz), date('c') . "\n") !== false;
}

/**
 * Limpa se houver o que limpar. Devolve quantos arquivos sairam.
 *
 * A MARCA SAI ANTES da varredura, de proposito. Se a faxina morrer no meio --
 * tempo de execucao, permissao --, a proxima requisicao nao tenta de novo e nao
 * entra em laco; o que sobrou espera a proxima atualizacao. Resto no disco e
 * problema conhecido e mitigado; requisicao que trava sozinha, nao.
 */
function shield_atu_limpar_pendentes($raiz = null)
{
    if (!shield_atu_restos_pendentes($raiz)) {
        return 0;
    }

    @unlink(shield_atu_marca_restos($raiz));

    require_once __DIR__ . '/atualizador.php';

    return shield_atu_limpar_restos($raiz);
}
