<?php

/**
 * Multa e juros por atraso -- 09/09/2026.
 *
 * Pedido por tres membros no levantamento de 08/09/2026
 * (docs/pesquisa-cobranca-comunidade.md). O mais preciso deles:
 *
 *   "que ele calcule multa + juros diario (valor ou percentual cadastrados via
 *    painel na regua de cobranca)"
 *
 * MULTA UMA VEZ, JUROS POR DIA. E como a lei e o mercado tratam inadimplencia
 * aqui, e e o que os membros descreveram. Multa que se repetisse a cada dia
 * dobraria a divida numa semana.
 *
 * NASCE DESLIGADO. Os dois percentuais padrao sao zero, entao quem nunca abrir
 * a tela nao passa a cobrar nada de ninguem. Recurso de dinheiro que se liga
 * sozinho na atualizacao e o tipo de surpresa que o membro descobre pelo
 * telefone do cliente dele.
 *
 * A CONTA MORA AQUI E SO AQUI. A cobranca guarda o resultado em
 * `encargos_centavos` e o principal continua sendo `valor_centavos -
 * encargos_centavos`, o que torna o recalculo IDEMPOTENTE: emitir de novo no
 * dia seguinte refaz a conta sobre o principal, nunca sobre o principal ja
 * inchado. Juros sobre juros nao foi combinado com ninguem.
 */

/** Chaves em shield_system_meta. */
const SHIELD_ENCARGOS_CHAVE_MULTA = 'cobranca_multa_percent';
const SHIELD_ENCARGOS_CHAVE_JUROS = 'cobranca_juros_dia_percent';

/**
 * A MULTA PODE SER EM DINHEIRO -- 01/10/2026, pedido de membro no feedback da
 * 4.2.10 ("deixa a multa como dinheiro ou porcentagem"). O pedido de 08/09 ja
 * dizia "valor ou percentual", e so o percentual tinha saido.
 *
 * E UM OU OUTRO, nunca os dois somados: o modo escolhe qual dos numeros vale. O
 * percentual continua gravado quando o modo e valor (e vice-versa), para quem
 * troca de ideia voltar ao numero que tinha. Sem a chave de modo -- toda
 * instalacao de antes desta data --, vale o percentual, como sempre valeu.
 */
const SHIELD_ENCARGOS_CHAVE_MULTA_MODO = 'cobranca_multa_modo';
const SHIELD_ENCARGOS_CHAVE_MULTA_VALOR = 'cobranca_multa_valor_centavos';
const SHIELD_ENCARGOS_MULTA_PERCENTUAL = 'percentual';
const SHIELD_ENCARGOS_MULTA_VALOR = 'valor';

/**
 * Teto dos juros, em percentual do principal.
 *
 * Sem ele, a cobranca esquecida por dois anos volta com juros maior que a
 * divida -- numero que ninguem paga e que so serve para o cliente sumir de vez.
 * Cem por cento ja e muito; passar disso e desistir de receber.
 */
const SHIELD_ENCARGOS_TETO_JUROS_PERCENT = 100.0;

/**
 * A conta. Funcao pura: nao le banco, nao le relogio -- quem chama passa o dia.
 *
 * $multaFixaCentavos, quando nao e null, e a multa em dinheiro e o percentual
 * da multa e ignorado (ver SHIELD_ENCARGOS_CHAVE_MULTA_MODO). Os juros sao sempre
 * percentuais: juros fixo por dia nao foi pedido por ninguem.
 *
 * Devolve ['dias' => int, 'multa' => int, 'juros' => int, 'total' => int],
 * tudo em centavos.
 */
function shield_encargos_calcular(
    int $principalCentavos,
    string $vencimento,
    string $hoje,
    float $multaPercent,
    float $jurosDiaPercent,
    ?int $multaFixaCentavos = null
): array {
    $zero = array('dias' => 0, 'multa' => 0, 'juros' => 0, 'total' => 0);

    if ($principalCentavos <= 0) {
        return $zero;
    }

    $venc = DateTimeImmutable::createFromFormat('!Y-m-d', substr(trim($vencimento), 0, 10));
    $dia = DateTimeImmutable::createFromFormat('!Y-m-d', substr(trim($hoje), 0, 10));
    if ($venc === false || $dia === false) {
        // Data ilegivel nao vira cobranca a mais. Errar para o lado de nao
        // cobrar e o unico erro que nao gera ligacao de cliente.
        return $zero;
    }

    // O proprio dia do vencimento ainda e dia de pagar. Multar quem pagou no
    // dia certo e o jeito mais rapido de perder a razao numa discussao.
    $dias = (int) $venc->diff($dia)->format('%r%a');
    if ($dias <= 0) {
        return $zero;
    }

    // Percentual negativo nao vira desconto: o campo da tela aceita "-5" se
    // alguem digitar, e atraso nao pode sair mais barato que pagar em dia.
    $multaPercent = max(0.0, $multaPercent);
    $jurosDiaPercent = max(0.0, $jurosDiaPercent);

    if ($multaFixaCentavos !== null) {
        // A MULTA FIXA NAO PASSA DO PRINCIPAL. R$ 50 de multa numa avulsa de
        // R$ 30 dobraria a divida no primeiro dia de atraso -- o mesmo raciocinio
        // do teto dos juros, so que para o numero que nao cresce.
        $multa = min(max(0, $multaFixaCentavos), $principalCentavos);
    } else {
        $multa = (int) round($principalCentavos * $multaPercent / 100);
    }
    $juros = (int) round($principalCentavos * $jurosDiaPercent / 100 * $dias);

    $teto = (int) round($principalCentavos * SHIELD_ENCARGOS_TETO_JUROS_PERCENT / 100);
    if ($juros > $teto) {
        $juros = $teto;
    }

    return array(
        'dias' => $dias,
        'multa' => $multa,
        'juros' => $juros,
        'total' => $multa + $juros,
    );
}

/**
 * O que esta configurado. Ausente, vale zero -- ver "nasce desligado" -- e o modo
 * da multa vale percentual, que e o que valia antes de existir modo.
 */
function shield_encargos_config(PDO $pdo): array
{
    try {
        $modo = (string) shield_get_system_meta($pdo, SHIELD_ENCARGOS_CHAVE_MULTA_MODO, SHIELD_ENCARGOS_MULTA_PERCENTUAL);

        return array(
            'multa' => (float) shield_get_system_meta($pdo, SHIELD_ENCARGOS_CHAVE_MULTA, '0'),
            'juros_dia' => (float) shield_get_system_meta($pdo, SHIELD_ENCARGOS_CHAVE_JUROS, '0'),
            'multa_modo' => $modo === SHIELD_ENCARGOS_MULTA_VALOR ? SHIELD_ENCARGOS_MULTA_VALOR : SHIELD_ENCARGOS_MULTA_PERCENTUAL,
            'multa_valor_centavos' => max(0, (int) shield_get_system_meta($pdo, SHIELD_ENCARGOS_CHAVE_MULTA_VALOR, '0')),
        );
    } catch (Throwable $semTabela) {
        return array('multa' => 0.0, 'juros_dia' => 0.0,
                     'multa_modo' => SHIELD_ENCARGOS_MULTA_PERCENTUAL, 'multa_valor_centavos' => 0);
    }
}

/** A multa que vale agora, em dinheiro: null quando o modo e percentual. */
function shield_encargos_multa_fixa(array $cfg): ?int
{
    return ($cfg['multa_modo'] ?? '') === SHIELD_ENCARGOS_MULTA_VALOR
        ? max(0, (int) ($cfg['multa_valor_centavos'] ?? 0))
        : null;
}

/** Ha alguma multa ou juros ligado? Para a tela dizer "desligado" so quando e. */
function shield_encargos_ligados(array $cfg): bool
{
    $multaFixa = shield_encargos_multa_fixa($cfg);
    $multa = $multaFixa !== null ? $multaFixa > 0 : (float) ($cfg['multa'] ?? 0) > 0;

    return $multa || (float) ($cfg['juros_dia'] ?? 0) > 0;
}

/**
 * Grava a configuracao. Os dois ultimos argumentos sao opcionais para quem so
 * mexe nos percentuais (os testes de antes desta data): sem eles o modo fica
 * percentual, como era.
 */
function shield_encargos_definir(
    PDO $pdo,
    float $multaPercent,
    float $jurosDiaPercent,
    string $multaModo = SHIELD_ENCARGOS_MULTA_PERCENTUAL,
    int $multaValorCentavos = 0
): void {
    $modo = $multaModo === SHIELD_ENCARGOS_MULTA_VALOR ? SHIELD_ENCARGOS_MULTA_VALOR : SHIELD_ENCARGOS_MULTA_PERCENTUAL;
    shield_set_system_meta($pdo, SHIELD_ENCARGOS_CHAVE_MULTA, (string) max(0.0, $multaPercent));
    shield_set_system_meta($pdo, SHIELD_ENCARGOS_CHAVE_JUROS, (string) max(0.0, $jurosDiaPercent));
    shield_set_system_meta($pdo, SHIELD_ENCARGOS_CHAVE_MULTA_MODO, $modo);
    shield_set_system_meta($pdo, SHIELD_ENCARGOS_CHAVE_MULTA_VALOR, (string) max(0, $multaValorCentavos));
}

/**
 * Recalcula os encargos de uma cobranca e devolve o que ela deve valer AGORA.
 *
 * IDEMPOTENTE de proposito: o principal e reconstruido tirando os encargos ja
 * gravados, entao chamar duas vezes no mesmo dia da o mesmo numero, e chamar no
 * dia seguinte anda os juros sem cobrar juros sobre juros.
 *
 * Devolve ['principal' => int, 'encargos' => array, 'valor' => int].
 */
function shield_encargos_da_cobranca(PDO $pdo, array $cobranca, ?string $hoje = null): array
{
    $valor = (int) ($cobranca['valor_centavos'] ?? 0);
    $jaGravado = (int) ($cobranca['encargos_centavos'] ?? 0);
    $principal = $valor - $jaGravado;

    $cfg = shield_encargos_config($pdo);
    $encargos = shield_encargos_calcular(
        $principal,
        (string) ($cobranca['vencimento'] ?? ''),
        $hoje ?? date('Y-m-d'),
        $cfg['multa'],
        $cfg['juros_dia'],
        shield_encargos_multa_fixa($cfg)
    );

    return array(
        'principal' => $principal,
        'encargos' => $encargos,
        'valor' => $principal + $encargos['total'],
    );
}

/**
 * Quanto a cobranca EMITIDA esta devendo de encargo em relacao ao que o PIX
 * pede -- em centavos, zero quando nada mudou. So olha; nao escreve.
 *
 * Existe porque o valor NAO anda sozinho depois da emissao. O PIX que o
 * cliente tem na mao pede o valor de ontem; se o painel subisse
 * `valor_centavos` por baixo dele, o pagamento chegaria menor que a cobranca
 * e cairia em "pagamento parcial, validade NAO estendida" -- o cliente teria
 * pago o que o painel mandou e ficado sem o mes. Quem troca o PIX e uma acao
 * de gente (shield_cobranca_reemitir), e esta funcao e o que a tela mostra
 * para a pessoa decidir.
 */
function shield_encargos_pendentes(PDO $pdo, array $cobranca, ?string $hoje = null): int
{
    $recalculo = shield_encargos_da_cobranca($pdo, $cobranca, $hoje);

    return max(0, (int) $recalculo['valor'] - (int) ($cobranca['valor_centavos'] ?? 0));
}

/**
 * MULTA E JUROS QUE O PROVEDOR COBRA NO ATRASO -- 14/10/2026.
 *
 * O painel so poe encargo no valor quando reemite, e o PIX que o cliente tem na
 * mao pede o valor de ontem: quem pagava atrasado o codigo da primeira emissao
 * pagava sem multa. O provedor que sabe cobrar sozinho (o Asaas, por `fine` e
 * `interest`) recebe aqui a regra da regua, para cobrar no dia em que o cliente
 * pagar. A sobra que ele cobra nao vira credito (shield_saldo_apos_pagamento).
 *
 * So para o codigo SEM encargo dentro: o reemitido ja traz multa e juros no
 * valor, e mandar a regra de novo cobraria a multa duas vezes. Desligado, null.
 *
 * Devolve ['multa_percentual' => float, 'multa_centavos' => int|null,
 * 'juros_mes_percentual' => float] -- a multa e um ou outro, como na regua; os
 * juros vao ao mes, que e como o Asaas os aceita (o dia da regua vezes 30).
 */
function shield_encargos_para_provedor(PDO $pdo, array $cobranca): ?array
{
    if ((int) ($cobranca['encargos_centavos'] ?? 0) > 0) {
        return null;
    }
    $cfg = shield_encargos_config($pdo);
    if (!shield_encargos_ligados($cfg)) {
        return null;
    }
    $fixa = shield_encargos_multa_fixa($cfg);

    return array(
        'multa_percentual' => $fixa === null ? max(0.0, (float) $cfg['multa']) : 0.0,
        // A multa fixa nao passa do principal, a regra de shield_encargos_calcular.
        'multa_centavos' => $fixa === null ? null : min($fixa, (int) ($cobranca['valor_centavos'] ?? 0)),
        'juros_mes_percentual' => round(max(0.0, (float) $cfg['juros_dia']) * 30, 4),
    );
}
