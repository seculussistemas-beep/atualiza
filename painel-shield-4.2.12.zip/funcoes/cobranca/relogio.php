<?php
/**
 * O relogio oportunista - 04/09/2026.
 *
 * O cron.php promete, no cabecalho, que "tudo o que ele faz tambem acontece
 * quando alguem abre o painel". Nao acontecia: a fila de verificacao dos
 * webhooks e a conciliacao so rodavam pelo cron.php -- e membro que nunca
 * configurou o agendador recebia o aviso do Asaas, guardava, e nunca
 * conferia. O pagamento ficava "em aberto" com o dinheiro na conta.
 *
 * Isto aqui e o que faltava: a cada abertura de tela do painel, no maximo
 * uma vez a cada poucos minutos, um lote pequeno das mesmas tarefas. O cron
 * continua sendo o jeito certo (lotes maiores, sem depender de alguem abrir
 * o painel); isto e a rede de seguranca.
 *
 * NADA AQUI SUSPENDE NINGUEM. E o mesmo limite do cron.
 */

require_once __DIR__ . '/cobranca_motor.php';
require_once __DIR__ . '/assinatura.php';

const SHIELD_RELOGIO_INTERVALO_SEGUNDOS = 300;

/**
 * A chave que o agendador poe na URL do /cron.php, entregue so a quem pode ve-la.
 *
 * ATE 16/09/2026 A PRIMEIRA CHAMADA, DE QUEM QUER QUE FOSSE, CRIAVA E IMPRIMIA.
 * Quem achasse o endereco de um painel recem instalado saia com uma chave
 * valida; e a chave manda na regua, que e a unica coisa do relogio que PARA a
 * loja de um cliente (o resto so descobre pagamento). E a chave gravada passava
 * a ser a do estranho: o membro nunca via a sua, porque tela nenhuma do painel
 * mostra essa chave -- por isso o conserto nao pode ser simplesmente calar.
 *
 * Entao quem decide e esta funcao, e a tela obedece: aberto por um
 * administrador logado, o proprio /cron.php VIRA a tela que faltava.
 *
 * Nao sortear outra quando ja existe e de proposito: o agendador ja configurado
 * na hospedagem continuaria chamando com a chave velha, e o relogio pararia
 * calado.
 *
 * @return array{chave: string, criada: bool, recusa: string}
 */
function shield_cron_chave_entregar(PDO $pdo, $ehAdmin)
{
    if (!$ehAdmin) {
        // A mesma resposta havendo chave ou nao: se existe uma e um bit que
        // quem esta de fora nao precisa.
        return array(
            'chave' => '',
            'criada' => false,
            'recusa' => 'A chave do relogio nao aparece para quem nao entrou no painel.'
                . ' Entre como administrador e abra este mesmo endereco:'
                . ' a chave aparece aqui, pronta para colar no agendador da hospedagem.',
        );
    }

    $chave = trim((string) shield_get_system_meta($pdo, 'cron_chave', ''));
    $criada = false;
    if ($chave === '') {
        $chave = bin2hex(random_bytes(16));
        shield_set_system_meta($pdo, 'cron_chave', $chave);
        $criada = true;
    }

    return array('chave' => $chave, 'criada' => $criada, 'recusa' => '');
}

/**
 * Roda o lote se ja passou o intervalo. Devolve o que fez, ou null se pulou.
 * Nunca lanca: uma falha aqui nao pode derrubar a tela que chamou.
 */
function shield_relogio_oportunista(PDO $pdo)
{
    try {
        $ultima = (int) shield_get_system_meta($pdo, 'relogio_oportunista_em', '0');
        if ($ultima > 0 && (time() - $ultima) < SHIELD_RELOGIO_INTERVALO_SEGUNDOS) {
            return null;
        }
        // Marca ANTES de trabalhar: duas abas abertas ao mesmo tempo nao
        // podem rodar o lote em dobro.
        shield_set_system_meta($pdo, 'relogio_oportunista_em', (string) time());
    } catch (Throwable $semMeta) {
        return null;
    }

    $feito = array('vencidas' => 0, 'fila' => 0, 'conciliadas' => 0, 'ciclo' => 0);

    try {
        $feito['vencidas'] = (int) shield_cobranca_marcar_vencidas($pdo);
    } catch (Throwable $ignorado) {
    }

    try {
        // O webhook chegou, foi guardado e enfileirou "va perguntar ao
        // provedor". Este e o passo que pergunta.
        $feito['fila'] = (int) shield_trabalho_processar($pdo, 5);
    } catch (Throwable $ignorado) {
    }

    try {
        // Webhook se perde. A conciliacao e quem vai olhar as abertas que ja
        // deviam ter resposta.
        if (function_exists('shield_cobranca_conciliar')) {
            $r = shield_cobranca_conciliar($pdo);
            $feito['conciliadas'] = (int) ($r['mudaram'] ?? 0);
        }
    } catch (Throwable $ignorado) {
    }

    try {
        // O PIX do proximo ciclo, uma vez por dia -- a mesma trava da tela de
        // assinaturas, para nao gerar duas vezes no mesmo dia.
        $dia = (string) shield_get_system_meta($pdo, 'assinatura_ciclo_gerado_em', '');
        if (substr($dia, 0, 10) !== date('Y-m-d')) {
            $r = shield_assinatura_gerar_ciclo($pdo, 7);
            shield_set_system_meta($pdo, 'assinatura_ciclo_gerado_em', date('Y-m-d H:i:s'));
            $feito['ciclo'] = (int) ($r['criadas'] ?? 0);

            // A VARREDURA DO ENCERRAMENTO, na mesma vez por dia -- 10/09/2026,
            // fatia 5. Teste que venceu e ninguem fechou em 30 dias ganha a
            // marca de encerrado (nada e apagado). Mesma trava diaria do ciclo.
            require_once __DIR__ . '/../licenca/encerramento.php';
            $feito['encerrados'] = (int) shield_encerramento_varrer($pdo);

            // MULTA E JUROS SOZINHOS (10/09/2026, tarde), se o membro ligou
            // na regua: reemite as vencidas com encargo pendente, uma vez por
            // dia. Ver shield_regua_reemitir_vencidas.
            require_once __DIR__ . '/regua.php';
            $feito['reemitidas'] = (int) (shield_regua_reemitir_vencidas($pdo)['reemitidas'] ?? 0);
        }
    } catch (Throwable $ignorado) {
    }

    return $feito;
}
