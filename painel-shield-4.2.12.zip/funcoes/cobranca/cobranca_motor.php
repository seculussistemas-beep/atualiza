<?php

// O motor de cobranca - 25/08/2026.
//
// Ele orquestra; quem fala com o mundo sao os adaptadores em src/Cobranca. O
// motor NAO SABE O NOME DE NENHUM GATEWAY, e e isso que faz provedor novo
// entrar sem tocar em tabela nem em tela.
//
// A REGRA QUE ATRAVESSA TUDO: WEBHOOK NAO E FONTE DA VERDADE. Ele dispara a
// verificacao, nunca a substitui. Nada aqui move dinheiro nem muda situacao
// porque um POST chegou dizendo que sim -- a situacao vem sempre do
// consultar() do provedor. Um webhook forjado, no maximo, faz o painel
// perguntar ao gateway.
//
// A ponte para a VALIDADE da licenca NAO esta aqui: ela e da fase seguinte, e
// de proposito. Esta fase fecha o dinheiro; a proxima liga o dinheiro a loja
// do cliente abrir.

require_once __DIR__ . '/../nucleo/autoload.php';
require_once __DIR__ . '/cobranca.php';
require_once __DIR__ . '/../licenca/validade.php';

use Shield\Cobranca\Registro;
use Shield\Cobranca\Resultado;

// Situacoes NOSSAS. A do provedor fica na tentativa; misturar as duas faria a
// regra de negocio conhecer o vocabulario de cada gateway.
const SHIELD_COB_RASCUNHO = 'rascunho';
const SHIELD_COB_ABERTA = 'aberta';
const SHIELD_COB_PAGA = 'paga';
const SHIELD_COB_VENCIDA = 'vencida';
const SHIELD_COB_CANCELADA = 'cancelada';
const SHIELD_COB_ESTORNADA = 'estornada';

/**
 * O que a tela chama de "em aberto": aberta, vencida e RASCUNHO. Rascunho
 * entra porque e cobranca guardada esperando alguem emitir -- coisa a fazer.
 * Uma lista so, para o recorte da tela e o badge da lateral contarem igual
 * (10/09/2026: o badge contava duas e a lista mostrava tres).
 */
function shield_cobranca_situacoes_em_aberto()
{
    return array(SHIELD_COB_ABERTA, SHIELD_COB_VENCIDA, SHIELD_COB_RASCUNHO);
}

/**
 * O recorte "pede prazo" -- 01/10/2026: a cobranca aberta ou vencida de um
 * cliente que pediu prazo pelo ERP e ainda espera resposta. A condicao, para o
 * alias da tabela `cobranca` que quem chama usa.
 *
 * O PEDIDO NAO AVISAVA NINGUEM. Ele nasce pendente (4.1.1) e so aparecia dentro
 * de Cobrancas, na linha da fatura, e na ficha: um membro perguntou no grupo
 * "aonde a gente recebe esse aviso", e a resposta era em lugar nenhum. A lista
 * filtrada e o badge da lateral leem daqui, para contarem a mesma coisa.
 *
 * Aberta e vencida, e nao rascunho: e so nelas que a tela desenha o pedido
 * (modules/cobranca/cobrancas.php, o $promRow), e e nelas que se responde.
 */
function shield_cobranca_onde_pede_prazo($alias = 'c')
{
    $a = preg_replace('/[^a-z_]/i', '', (string) $alias);

    return $a . ".situacao IN ('" . addslashes(SHIELD_COB_ABERTA) . "', '" . addslashes(SHIELD_COB_VENCIDA) . "')"
        . ' AND EXISTS (SELECT 1 FROM promessa_pagamento p'
        . ' WHERE p.fk_empresa = ' . $a . ".fk_empresa AND p.situacao = 'pendente')";
}

/**
 * Quantos CLIENTES pedem prazo e esperam resposta. A mesma conta do badge da
 * lateral (shield_lateral_sql_contagem('prazo')), para a tela e o menu nao
 * discordarem. Base sem `promessa_pagamento` devolve 0.
 */
function shield_cobranca_pedem_prazo_contar(PDO $pdo)
{
    try {
        return max(0, (int) $pdo->query(
            'SELECT COUNT(DISTINCT c.fk_empresa) FROM cobranca c WHERE ' . shield_cobranca_onde_pede_prazo('c')
        )->fetchColumn());
    } catch (Throwable $ignorado) {
        return 0;
    }
}

/**
 * Quanto o valor pago pode ficar abaixo do cobrado e ainda contar como pago.
 *
 * Existe por causa de arredondamento: o painel guarda centavos inteiros e os
 * gateways falam em reais com ponto flutuante, entao a volta pode diferir de um
 * centavo. Dois centavos cobrem isso com folga e nao chegam perto de acomodar
 * pagamento parcial de verdade.
 */
const SHIELD_COB_TOLERANCIA_CENTAVOS = 2;

/** O rotulo da tentativa que a reemissao matou no provedor. E por ele que a
 *  emissao sabe que aquele codigo NAO esta mais vivo e pode nascer outro. */
const SHIELD_COB_TENTATIVA_CANCELADA = 'cancelada pelo painel para reemitir';

/** Uma cobranca ja paga, cancelada ou estornada nao volta atras sozinha. */
function shield_cob_terminal($situacao)
{
    return in_array((string) $situacao, array(SHIELD_COB_PAGA, SHIELD_COB_CANCELADA,
                                              SHIELD_COB_ESTORNADA), true);
}

/**
 * A forma escolhida cabe no que o provedor FAZ? -- 09/09/2026.
 *
 * Devolve null quando cabe, ou a frase de recusa quando nao. Existe porque tres
 * adaptadores declaravam boleto e cartao em capacidades() e, no criar(),
 * travavam PIX e ignoravam a forma: o membro escolhia boleto, a linha gravava
 * "boleto", o cliente recebia PIX, e a coluna nunca era corrigida. A guarda
 * roda ANTES de falar com o provedor -- recusar depois deixaria tentativa e
 * encargo gravados para uma cobranca que nao saiu.
 *
 * Forma vazia passa: e o comportamento de sempre, o provedor decide. Forma que
 * o painel nao conhece tambem passa -- a guarda so sabe recusar o que sabe
 * comparar.
 */
function shield_cobranca_forma_recusa(array $capacidades, $forma, $provedorNome = '')
{
    $f = strtolower(trim((string) $forma));
    if ($f === '') {
        return null;
    }

    $mapa = array('pix' => 'pix', 'boleto' => 'boleto', 'cartao' => 'cartao', 'cartão' => 'cartao');
    if (!isset($mapa[$f])) {
        return null;
    }
    $chave = $mapa[$f];

    if (!empty($capacidades[$chave])) {
        return null;
    }

    $nome = trim((string) $provedorNome);

    return sprintf(
        '%s nao emite %s neste painel. Escolha outra forma, ou outra conta de recebimento.',
        $nome !== '' ? $nome : 'Este provedor',
        $chave === 'cartao' ? 'cartao' : $chave
    );
}

/**
 * AS FORMAS QUE ESTA CONTA COBRA -- 14/09/2026.
 *
 * O cruzamento de duas perguntas, e nenhuma delas sozinha: o que o PROVEDOR
 * faz (capacidades(), que desde 10/09 nao olha a conta) e o que o membro
 * marcou em "Cobra por" na tela de Formas de recebimento (aceita_pix,
 * aceita_boleto, aceita_cartao). So a primeira valia no fechamento e na
 * emissao, e a conta do Asaas com cartao desmarcado continuava oferecendo e
 * emitindo cartao; so a segunda valia em Cobrancas, e a Efi com boleto marcado
 * oferecia boleto.
 *
 * Dinheiro em especie nao faz nenhuma das tres: a forma dele e "dinheiro", e
 * so dele. Uma lista so, para toda tela mostrar o que o servidor aceita.
 */
function shield_conta_formas(array $conta)
{
    if ((string) ($conta['provedor'] ?? '') === 'dinheiro') {
        return array('dinheiro');
    }
    $adaptador = Registro::para((string) ($conta['provedor'] ?? ''));
    $caps = $adaptador !== null ? $adaptador->capacidades($conta) : array();

    // CONTA SEM NADA MARCADO VALE O QUE O PROVEDOR FAZ. Os flags viveram
    // desligados por padrao (ver Asaas::capacidades) e a emissao nunca os leu:
    // conta antiga com os tres em zero emite hoje, e ler "nada marcado" como
    // "nao cobra nada" a tiraria do fechamento no dia da atualizacao.
    $marcou = !empty($conta['aceita_pix']) || !empty($conta['aceita_boleto']) || !empty($conta['aceita_cartao']);
    $formas = array();
    foreach (array('pix', 'boleto', 'cartao') as $f) {
        if (!empty($caps[$f]) && (!$marcou || !empty($conta['aceita_' . $f]))) {
            $formas[] = $f;
        }
    }

    return $formas;
}

/**
 * A forma cabe no "Cobra por" da conta? Null quando cabe, a frase quando nao --
 * 14/09/2026. Chamada pelas telas que ESCOLHEM a forma: o fechamento, Mudar o
 * contrato e Cobrancas. A emissao ainda NAO a usa, de proposito: a mensalidade
 * do ciclo nasce sem forma e sai PIX, e recusar ali faria cada mensalidade de
 * uma conta sem PIX marcado parar em rascunho sem ninguem ver. Isso espera a
 * assinatura guardar a propria forma.
 *
 * FORMA VAZIA E PIX, fora do dinheiro: a mensalidade do ciclo nasce sem forma
 * e os cinco adaptadores emitem PIX com `forma ?? 'pix'`. Deixar a vazia
 * passar sem olhar (como shield_cobranca_forma_recusa faz) emitia PIX numa
 * conta em que o membro desmarcou o PIX.
 *
 * A frase diz a conta, o que ela cobra e onde mudar: quem le e o membro, e o
 * erro so ajuda se apontar a tela.
 */
function shield_conta_forma_recusa(array $conta, $forma)
{
    $f = strtolower(trim((string) $forma));
    if ($f === 'cartão') {
        $f = 'cartao';
    }
    if ($f === '') {
        if ((string) ($conta['provedor'] ?? '') === 'dinheiro') {
            return null;
        }
        $f = 'pix';
    }

    $formas = shield_conta_formas($conta);
    if (in_array($f, $formas, true)) {
        return null;
    }

    $nome = trim((string) ($conta['apelido'] ?? '')) ?: (string) ($conta['provedor'] ?? 'Esta conta');
    $rotulo = array('pix' => 'PIX', 'boleto' => 'boleto', 'cartao' => 'cartao', 'dinheiro' => 'dinheiro em especie');
    if ($formas === array()) {
        return sprintf(
            'A conta %s nao tem nenhuma forma marcada em "Cobra por". Marque o que ela cobra em Formas de recebimento, ou escolha outra conta.',
            $nome
        );
    }
    $nomes = array();
    foreach ($formas as $x) {
        $nomes[] = $rotulo[$x];
    }

    return sprintf(
        'A conta %s cobra so por %s; %s nao esta entre elas. Escolha uma dessas formas, ou mude o "Cobra por" dela em Formas de recebimento.',
        $nome, implode(' ou ', $nomes), $rotulo[$f] ?? $f
    );
}

/**
 * A CONTA ESTA PRONTA PARA COBRAR? Null quando esta, a frase quando nao -- 14/09/2026.
 *
 * "Nao consigo gerar a fatura, sempre da erro, e no PIX estatico tambem" (o dono).
 * O PIX na sua chave se liga pelo botao da linha em Formas de recebimento sem
 * chave nenhuma, e a falta so aparecia no criar() do adaptador: DEPOIS de a Nova
 * cobranca abrir (rascunho, e o credito do cliente ja consumido), DEPOIS de Mudar
 * o contrato cancelar a assinatura, e com a frase "o provedor nao respondeu", que
 * manda procurar o defeito no lugar errado. Quem escolhe a conta pergunta aqui
 * ANTES de gravar; a emissao pergunta de novo antes de qualquer efeito.
 *
 * NAO OLHA `ativo`, de proposito: a reemissao sai pela conta da tentativa, e o
 * membro que desligou uma conta ainda precisa trocar o codigo que o cliente tem
 * na mao. Quem so oferece conta ligada ja filtra na lista.
 *
 * So o que o painel confere sem falar com ninguem: o adaptador existe, e o PIX
 * estatico tem a chave. Credencial de gateway errada, so o gateway responde.
 */
function shield_conta_pronta_recusa(array $conta)
{
    $provedor = strtolower(trim((string) ($conta['provedor'] ?? '')));
    $nome = trim((string) ($conta['apelido'] ?? ''));
    if ($nome === '') {
        $nome = $provedor !== '' ? $provedor : 'escolhida';
    }
    if (Registro::para($provedor) === null) {
        return sprintf('A conta %s usa o provedor %s, que ainda nao tem adaptador neste painel. Escolha outra conta.', $nome, $provedor);
    }
    if ($provedor === 'pix_estatico') {
        // Vinda de shield_cob_conta, a credencial ja esta aberta; da lista, abre aqui.
        $credenciais = isset($conta['_credenciais']) ? (array) $conta['_credenciais'] : shield_cobranca_credenciais($conta);
        if (trim((string) ($credenciais['chave_pix'] ?? '')) === '') {
            return sprintf(
                'A conta %s esta sem a chave PIX, e sem ela nao ha codigo para mandar ao cliente. Cadastre a chave em Formas de recebimento, ou escolha outra conta.',
                $nome
            );
        }
    }

    return null;
}

/**
 * LIGAR A CONTA PERGUNTA SE ELA COBRA -- 15/09/2026. Null quando pode ligar, a
 * frase quando nao. E a mesma conferencia de shield_conta_pronta_recusa, feita
 * com as credenciais que VAO ficar gravadas (as do formulario por cima das
 * guardadas), e com a frase de quem esta em Formas de recebimento: la "escolha
 * outra conta" nao faz sentido. Desligar nunca pergunta nada.
 */
function shield_conta_ligar_recusa(array $conta, array $credenciais)
{
    $conta['_credenciais'] = $credenciais;
    $recusa = shield_conta_pronta_recusa($conta);
    if ($recusa !== null && strtolower(trim((string) ($conta['provedor'] ?? ''))) === 'pix_estatico') {
        return 'O PIX na sua chave nao foi ligado: falta a chave PIX. Preencha a chave e grave de novo; sem ela nao ha codigo para mandar ao cliente.';
    }

    return $recusa;
}

function shield_cob_ler(PDO $pdo, $id)
{
    $stmt = $pdo->prepare('SELECT * FROM cobranca WHERE id = :id LIMIT 1');
    $stmt->execute(array(':id' => (int) $id));
    $linha = $stmt->fetch(PDO::FETCH_ASSOC);

    return is_array($linha) ? $linha : null;
}

/**
 * LIGA O CAMINHO DE VOLTA DA CREDENCIAL (16/09/2026): o adaptador que renova
 * um token rotativo (Conta Azul) entrega o par novo por Credenciais::renovadas,
 * e e este gravador, com o PDO da requisicao, que o poe no cofre. Falha ao
 * gravar NAO derruba a emissao: o par novo ainda vale nesta requisicao, e o
 * que se perde e a persistencia -- o sintoma e a proxima requisicao ter de
 * autorizar de novo, nao um pagamento sem codigo.
 */
function shield_cobranca_ligar_renovacao(PDO $pdo)
{
    \Shield\Cobranca\Credenciais::aoRenovar(static function ($contaId, array $delta) use ($pdo) {
        try {
            shield_cobranca_credenciais_mesclar($pdo, (int) $contaId, $delta);
        } catch (Throwable $ignorado) {
            // ver o comentario acima
        }
    });
}

/** A conta com as credenciais ja abertas -- so aqui elas saem do cofre. */
function shield_cob_conta(PDO $pdo, $id)
{
    $conta = shield_cobranca_conta($pdo, $id);
    if ($conta === null) {
        return null;
    }
    $conta['_credenciais'] = shield_cobranca_credenciais($conta);
    // Quem abre a credencial e quem vai usa-la: o gravador do token renovado
    // entra aqui, uma vez por requisicao, com este PDO.
    shield_cobranca_ligar_renovacao($pdo);

    return $conta;
}

function shield_cob_empresa(PDO $pdo, $id)
{
    $stmt = $pdo->prepare('SELECT * FROM empresa WHERE codigo = :id LIMIT 1');
    $stmt->execute(array(':id' => (int) $id));
    $linha = $stmt->fetch(PDO::FETCH_ASSOC);

    return is_array($linha) ? $linha : null;
}

// ------------------------------------------------------------------- criar ---

/**
 * Abre a cobranca no painel. Ainda nao existe em provedor nenhum.
 *
 * O VALOR NAO VEM DO NAVEGADOR quando ha assinatura: sai do que esta gravado
 * nela, no servidor. Aceitar o valor que a tela mandou e como o desconto de
 * 100% entra em sistema de cobranca.
 */
// ------------------------------------------------------------------ saldo ---
//
// O PIX SAI COM O VALOR TRAVADO, mas dinheiro entra do jeito que entra. O que
// entrar A MAIS vira SALDO (credito) do cliente e desconta da proxima
// cobranca, sem ninguem editar valor a mao. A MENOS nao fecha a cobranca (ver
// shield_cobranca_aplicar_resultado): saldo negativo so existe se um dia a
// regra mudar, e o codigo abaixo ja o trata.
//
// Um numero por cliente, em centavos. Toda mudanca vai para a auditoria com o
// antes e o depois, que e o extrato.

function shield_saldo_ler(PDO $pdo, $empresa)
{
    try {
        $stmt = $pdo->prepare('SELECT saldo_centavos FROM empresa WHERE codigo = :e');
        $stmt->execute(array(':e' => (int) $empresa));
        $v = $stmt->fetchColumn();

        return $v === false ? 0 : (int) $v;
    } catch (Throwable $baseAntiga) {
        // Base sem a coluna (migracao 4.0.4 ainda nao aplicada): sem saldo.
        return 0;
    }
}

/** Soma (ou subtrai) do saldo do cliente e deixa o rastro. */
function shield_saldo_lancar(PDO $pdo, $empresa, $centavos, $motivo)
{
    $centavos = (int) $centavos;
    if ($centavos === 0) {
        return;
    }
    $antes = shield_saldo_ler($pdo, $empresa);
    try {
        $stmt = $pdo->prepare('UPDATE empresa SET saldo_centavos = saldo_centavos + :d WHERE codigo = :e');
        $stmt->execute(array(':d' => $centavos, ':e' => (int) $empresa));
    } catch (Throwable $baseAntiga) {
        return;
    }
    shield_auditar($pdo, 'saldo_cliente', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => (int) $empresa,
        'antes' => (string) $antes, 'depois' => (string) ($antes + $centavos),
        'detalhe' => ($centavos > 0 ? '+' : '-') . 'R$ ' . shield_dinheiro(abs($centavos)) . ' -- ' . $motivo,
    ));
}

/**
 * O CREDITO VOLTA PARA O CLIENTE quando a cobranca morre (cancelada ou
 * estornada) -- 11/09/2026. Devolve o que ela consumiu ao nascer e tira a
 * sobra que o pagamento gerou, e zera as duas marcas para nao devolver duas
 * vezes se a funcao for chamada de novo.
 */
function shield_saldo_desfazer(PDO $pdo, array $cobranca, $motivo)
{
    $id = (int) $cobranca['id'];
    $empresa = (int) $cobranca['fk_empresa'];

    $consumido = (int) ($cobranca['saldo_aplicado_centavos'] ?? 0);
    if ($consumido !== 0) {
        shield_saldo_lancar($pdo, $empresa, $consumido, 'credito devolvido: ' . $motivo . ' (cobranca #' . $id . ')');
        try {
            $pdo->prepare('UPDATE cobranca SET saldo_aplicado_centavos = 0 WHERE id = :id')->execute(array(':id' => $id));
        } catch (Throwable $baseAntiga) {
        }
    }

    // A sobra que o pagamento lancou sai junto: o dinheiro que a gerou voltou.
    // A que foi multa e juros do provedor nunca entrou no saldo, e nao sai dele.
    $pago = (int) ($cobranca['valor_pago_centavos'] ?? 0);
    $sobra = $pago - (int) $cobranca['valor_centavos'];
    if ($pago > 0 && $sobra > SHIELD_COB_TOLERANCIA_CENTAVOS && !shield_saldo_sobra_foi_encargo($pdo, $id)) {
        shield_saldo_lancar($pdo, $empresa, -$sobra, 'sobra desfeita: ' . $motivo . ' (cobranca #' . $id . ')');
    }
}

/**
 * Depois de uma cobranca ser paga: a diferenca entre o recebido e o cobrado
 * vai para o saldo. Chamado pelos dois caminhos de "paga" (provedor e a mao).
 *
 * A SOBRA DE QUEM PAGOU ATRASADO NAO E CREDITO (14/10/2026). Boleto e PIX tem
 * valor fixo: o que entra a mais pelo PROVEDOR depois do vencimento sao a multa
 * e os juros que o banco somou na hora de pagar -- os configurados na conta do
 * Asaas, ou (desde a mesma data) os da regua, que o painel passou a mandar com a
 * cobranca. Visto num membro: R$ 9,98 de juros do Asaas viraram credito do
 * cliente e foram descontados da mensalidade seguinte, devolvendo os juros. A
 * diferenca vai para o livro como `cobranca_encargos_do_provedor`, e e esse
 * registro que o estorno consulta para nao tirar do saldo o que nunca entrou nele.
 * A mao, e em dia, continua como sempre: a sobra e do cliente.
 */
function shield_saldo_apos_pagamento(PDO $pdo, array $cobranca, $pagoCentavos, $origem, $pagoEm = null)
{
    $diferenca = (int) $pagoCentavos - (int) $cobranca['valor_centavos'];
    // So a SOBRA vira saldo. Falta nao chega aqui pelo provedor (a cobranca
    // nem fecha), e a mao e decisao do membro naquela cobranca -- nao divida.
    if ($diferenca <= SHIELD_COB_TOLERANCIA_CENTAVOS) {
        return;
    }
    $diaPago = substr((string) ($pagoEm ?: date('Y-m-d')), 0, 10);
    $vence = substr((string) ($cobranca['vencimento'] ?? ''), 0, 10);
    if ($origem === 'provedor' && $vence !== '' && $diaPago > $vence) {
        shield_auditar($pdo, 'cobranca_encargos_do_provedor', array(
            'alvo_tipo' => 'cobranca', 'alvo_id' => (int) $cobranca['id'],
            'depois' => (string) $diferenca,
            'detalhe' => 'R$ ' . shield_dinheiro($diferenca) . ' de multa e juros cobrados pelo provedor no pagamento de '
                . $diaPago . ' (venceu em ' . $vence . '); nao vira credito',
        ));

        return;
    }
    shield_saldo_lancar($pdo, (int) $cobranca['fk_empresa'], $diferenca,
        ($diferenca > 0 ? 'pagou a mais' : 'pagou a menos') . ' na cobranca #' . (int) $cobranca['id']
        . ' (' . $origem . ')');
}

/**
 * AJUSTAR O CREDITO A MAO (14/10/2026). Ate aqui o saldo so mudava por conta
 * propria -- pagamento a mais, cobranca nova, cancelamento --, e o membro que
 * achava um credito errado so o tirava pelo banco. Grava o valor NOVO (zerar e
 * pedir 0), com motivo obrigatorio, e a diferenca vai para o livro como qualquer
 * outro lancamento (`saldo_cliente`, com o antes e o depois). Devolve a diferenca
 * lancada. Divida (saldo negativo) tambem se ajusta: o numero e o mesmo.
 */
function shield_saldo_ajustar(PDO $pdo, $empresa, $novoCentavos, $motivo)
{
    $motivo = trim((string) $motivo);
    if ($motivo === '') {
        throw new RuntimeException('Ajuste de credito sem motivo nao entra: o livro precisa dizer por que.');
    }
    $novoCentavos = (int) $novoCentavos;
    if ($novoCentavos < 0) {
        throw new RuntimeException('O credito novo nao pode ser negativo.');
    }
    $delta = $novoCentavos - shield_saldo_ler($pdo, $empresa);
    shield_saldo_lancar($pdo, (int) $empresa, $delta, 'ajuste a mao: ' . substr($motivo, 0, 150));

    return $delta;
}

/** A sobra desta cobranca foi multa e juros do provedor (nao entrou no saldo)? */
function shield_saldo_sobra_foi_encargo(PDO $pdo, $cobrancaId)
{
    try {
        $st = $pdo->prepare(
            "SELECT 1 FROM auditoria WHERE acao = 'cobranca_encargos_do_provedor' AND alvo_tipo = 'cobranca' AND alvo_id = :c LIMIT 1"
        );
        $st->execute(array(':c' => (string) (int) $cobrancaId));

        return $st->fetchColumn() !== false;
    } catch (Throwable $semTabela) {
        return false;
    }
}

function shield_cobranca_abrir(PDO $pdo, array $dados)
{
    $empresa = (int) ($dados['empresa'] ?? 0);
    if ($empresa <= 0) {
        throw new RuntimeException('Cobranca sem cliente.');
    }

    // O MESMO ENVIO DE FORMULARIO ABRE UMA COBRANCA SO -- 11/09/2026. Quem
    // passa `chave` recebe de volta a cobranca que aquela chave ja abriu, como
    // `empresa.fechamento_chave` faz no fechamento desde 10/09. Sem chave nada
    // muda: o ciclo, a mao e o fechamento seguem abrindo o que pedirem.
    $chave = substr(trim((string) ($dados['chave'] ?? '')), 0, 64);
    if ($chave !== '') {
        $jaFeita = shield_cobranca_por_chave($pdo, $chave);
        if ($jaFeita !== null) {
            return (int) $jaFeita['id'];
        }
    }

    $assinatura = isset($dados['assinatura']) ? (int) $dados['assinatura'] : null;
    $valor = (int) ($dados['valor_centavos'] ?? 0);
    // QUANTOS MESES esta cobranca compra, congelado aqui como o valor. Plano
    // avulso de 12 meses abre uma cobranca de 12; sem dizer nada, e um. Para
    // cobranca de assinatura o ciclo dela manda na hora de estender (V4_0_5).
    //
    // ZERO e "paga, nao move a validade" -- 10/09/2026, fatia 8: a cobranca
    // de AJUSTE do mes corrente (terminal ou modulo acrescentado) nao e um
    // mes a mais de licenca. So por pedido explicito, nunca por default.
    $meses = !empty($dados['nao_estende']) ? 0 : max(1, (int) ($dados['meses'] ?? 1));

    // A COBRANCA DE ASSINATURA CARREGA OS PROPRIOS MESES (11/09/2026): o ciclo
    // e congelado nela na hora de abrir. Antes a ponte voltava na assinatura
    // para ler ciclo_meses, e mudar o ciclo depois reescrevia quantos meses
    // uma fatura ja na rua comprava.
    $ciclo = 1;
    if ($assinatura) {
        $stmt = $pdo->prepare('SELECT valor_centavos, ciclo_meses FROM assinatura WHERE id = :id');
        $stmt->execute(array(':id' => $assinatura));
        $daAssinatura = $stmt->fetch(PDO::FETCH_ASSOC);
        if (is_array($daAssinatura)) {
            $valor = (int) $daAssinatura['valor_centavos'];
            $ciclo = max(1, (int) $daAssinatura['ciclo_meses']);
            if (!isset($dados['meses']) && empty($dados['nao_estende'])) {
                $meses = $ciclo;
            }
        }
    }

    if ($valor <= 0) {
        throw new RuntimeException('Cobranca sem valor.');
    }

    // A COMPOSICAO -- 09/09/2026. Modulos contratados e terminal alem
    // da cota entram no valor, e a lista deles entra na descricao. Opt-in de
    // proposito: quem pede compoe. Compor tudo somaria modulo mensal a uma
    // cobranca avulsa de doze meses, que e decisao de preco e nao de codigo.
    //
    // Vem ANTES do saldo porque o desconto do cliente se aplica sobre o que ele
    // de fato deve neste mes -- inclusive os adicionais.
    $composicao = null;
    if (!empty($dados['compor'])) {
        require_once __DIR__ . '/composicao.php';
        // Os itens mensais vezes o ciclo: seis meses de modulo na fatura do semestre.
        $composicao = shield_composicao_do_cliente($pdo, $empresa, $valor, $ciclo);
        $valor = (int) $composicao['total'];
    }

    // O SALDO ENTRA AQUI, na proxima cobranca do cliente: credito desconta,
    // debito soma. O que foi aplicado sai do saldo e vai para a descricao,
    // para o cliente ler por que o PIX deste mes veio diferente do plano.
    // Credito maior que a cobranca nao a zera: fica R$ 0,01 e o resto do
    // credito espera a proxima -- cobranca de zero nao emite em provedor.
    $descricao = (string) ($dados['descricao'] ?? 'Mensalidade');

    // O cliente precisa LER por que o PIX deste mes veio diferente do plano que
    // ele contratou. Sem esta frase, o adicional vira uma cobranca a mais sem
    // explicacao, e a explicacao chega por telefone.
    if ($composicao !== null) {
        $frase = shield_composicao_frase($composicao);
        if ($frase !== '') {
            $descricao .= ' (inclui ' . $frase . ')';
        }
    }

    $saldo = shield_saldo_ler($pdo, $empresa);
    $aplicado = 0;
    if ($saldo !== 0 && empty($dados['sem_saldo'])) {
        $aplicado = $saldo > 0 ? min($saldo, $valor - 1) : $saldo;
        if ($aplicado !== 0) {
            $valor -= $aplicado;
            $descricao .= $aplicado > 0
                ? ' (desconto de R$ ' . shield_dinheiro($aplicado) . ' do saldo)'
                : ' (inclui R$ ' . shield_dinheiro(abs($aplicado)) . ' que faltou antes)';
            shield_saldo_lancar($pdo, $empresa, -$aplicado, 'aplicado na cobranca nova');
        }
    }

    $stmt = $pdo->prepare(
        'INSERT INTO cobranca
            (fk_empresa, fk_assinatura, competencia, descricao, valor_centavos,
             meses, vencimento, situacao, forma, saldo_aplicado_centavos, chave_idempotencia)
         VALUES (:emp, :ass, :comp, :desc, :valor, :meses, :venc, :sit, :forma, :saldo, :chave)'
    );
    $linha = array(
        ':chave' => $chave !== '' ? $chave : null,
        // QUANTO DE CREDITO ESTA COBRANCA COMEU (11/09/2026). Sem o numero na
        // linha, cancelar ou estornar deixava o troco do cliente no chao: o
        // desconto so existia na prosa da descricao.
        ':saldo' => $aplicado,
        ':emp' => $empresa,
        ':ass' => $assinatura ?: null,
        ':comp' => $dados['competencia'] ?? null,
        ':desc' => substr($descricao, 0, 150),
        ':valor' => $valor,
        ':meses' => $meses,
        ':venc' => (string) ($dados['vencimento'] ?? date('Y-m-d')),
        ':sit' => SHIELD_COB_RASCUNHO,
        ':forma' => $dados['forma'] ?? null,
    );

    try {
        $stmt->execute($linha);
    } catch (PDOException $talvezRepetida) {
        // DOIS CLIQUES AO MESMO TEMPO, e nao o F5: o pre-teste la em cima nao
        // viu nada porque a outra requisicao ainda nao tinha gravado. A chave
        // e UNICA justamente para este caso; aqui so se devolve o que a outra
        // fez -- e o credito que ESTA passada consumiu volta, senao o cliente
        // pagaria o desconto duas vezes.
        $jaFeita = $chave !== '' ? shield_cobranca_por_chave($pdo, $chave) : null;
        if ($jaFeita === null) {
            throw $talvezRepetida;
        }
        if ($aplicado !== 0) {
            shield_saldo_lancar($pdo, $empresa, $aplicado, 'devolvido: a cobranca desse envio ja tinha sido aberta');
        }

        return (int) $jaFeita['id'];
    }

    $id = (int) $pdo->lastInsertId();
    shield_auditar($pdo, 'cobranca_aberta', array(
        'alvo_tipo' => 'cobranca', 'alvo_id' => $id,
        'detalhe' => 'R$ ' . shield_dinheiro($valor) . ' vencendo em '
            . (string) ($dados['vencimento'] ?? date('Y-m-d')),
    ));

    return $id;
}

// ------------------------------------------------------------------ emitir ---

/**
 * A cobranca que um envio de formulario ja abriu, ou null -- 11/09/2026.
 *
 * Base que ainda nao recebeu a V4_2_2 nao tem a coluna: devolve null, e o
 * painel volta a se comportar como antes em vez de parar de abrir cobranca.
 */
function shield_cobranca_por_chave(PDO $pdo, $chave)
{
    $chave = trim((string) $chave);
    if ($chave === '') {
        return null;
    }
    try {
        $stmt = $pdo->prepare('SELECT * FROM cobranca WHERE chave_idempotencia = :k LIMIT 1');
        $stmt->execute(array(':k' => $chave));
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $semColuna) {
        return null;
    }

    return is_array($linha) ? $linha : null;
}

/**
 * Manda a cobranca ao provedor e guarda a tentativa.
 *
 * A TENTATIVA E GRAVADA ANTES de a cobranca mudar de situacao, e o retorno cru
 * vai inteiro para ela. Quando o provedor responde algo que a gente nao previu,
 * e essa linha que responde o que aconteceu -- a situacao resumida nao.
 */
function shield_cobranca_emitir(PDO $pdo, $cobrancaId, $contaId)
{
    $cobranca = shield_cob_ler($pdo, $cobrancaId);
    if ($cobranca === null) {
        throw new RuntimeException('Cobranca nao encontrada.');
    }
    if (shield_cob_terminal($cobranca['situacao'])) {
        throw new RuntimeException('Esta cobranca ja esta ' . $cobranca['situacao'] . '.');
    }

    // UMA COBRANCA, UM CODIGO VIVO -- 11/09/2026. Emitir de novo criava outro
    // pagamento no gateway, e o painel passava a olhar so o novo: o cliente
    // que pagasse o primeiro nunca teria baixa. O caminho para trocar de
    // codigo e a reemissao, que CANCELA no provedor antes -- e e por isso que
    // ela nao esbarra aqui: a tentativa que ela cancelou deixa de ser viva.
    $viva = shield_cobranca_tentativa_viva($pdo, (int) $cobranca['id']);
    if ($viva !== null) {
        throw new RuntimeException(
            'Esta cobranca ja tem um codigo valendo no provedor (' . (string) $viva['id_externo']
            . '). Emitir de novo deixaria dois codigos vivos e o painel so olharia um. '
            . 'Para trocar o codigo, use a reemissao: ela cancela o antigo antes.'
        );
    }

    $conta = shield_cob_conta($pdo, $contaId);
    if ($conta === null) {
        throw new RuntimeException('Conta de recebimento nao encontrada.');
    }

    $provedor = Registro::para((string) $conta['provedor']);
    if ($provedor === null) {
        throw new RuntimeException(
            'O provedor ' . $conta['provedor'] . ' ainda nao tem adaptador neste painel.'
        );
    }

    // A CONTA PRONTA, antes dos encargos e da tentativa (14/09/2026). O PIX na
    // chave sem chave so recusava no criar(): na reemissao os encargos de hoje ja
    // estariam gravados numa cobranca que nao saiu. Ver shield_conta_pronta_recusa.
    $naoPronta = shield_conta_pronta_recusa($conta);
    if ($naoPronta !== null) {
        throw new RuntimeException($naoPronta);
    }

    $empresa = shield_cob_empresa($pdo, (int) $cobranca['fk_empresa']);
    if ($empresa === null) {
        throw new RuntimeException('O cliente desta cobranca nao existe mais.');
    }

    // O CNPJ TEM DE SER VALIDO antes de ir a um provedor de verdade -- 10/09/2026,
    // tarde. O Asaas recusa com "CPF/CNPJ informado e invalido", e o membro
    // nao entende o que fazer; aqui a recusa diz onde corrigir.
    $capsProvedor = $provedor->capacidades($conta);
    if (!empty($capsProvedor['automatico'])) {
        require_once __DIR__ . '/../licenca/licenca_assinada.php';
        if (!shield_documento_valido((string) ($empresa['cnpj'] ?? ''))) {
            throw new RuntimeException(
                'O CNPJ do cliente (' . (string) ($empresa['cnpj'] ?? '') . ') nao e valido, e o provedor recusa. '
                . 'Corrija o CNPJ no cadastro do cliente antes de emitir.'
            );
        }
    }

    // A FORMA TEM DE CABER NO PROVEDOR, e a conferencia vem ANTES dos encargos
    // e da tentativa: recusar depois deixaria escrita no banco uma emissao que
    // nao aconteceu. Ver shield_cobranca_forma_recusa.
    $recusa = shield_cobranca_forma_recusa(
        $provedor->capacidades($conta),
        $cobranca['forma'] ?? '',
        (string) (($conta['apelido'] ?? '') ?: ($conta['provedor'] ?? ''))
    );
    if ($recusa !== null) {
        throw new RuntimeException($recusa);
    }

    // MULTA E JUROS ENTRAM AQUI -- 09/09/2026. Na emissao, e nao no
    // vencimento: e este o momento em que o valor vira um PIX ou um boleto de
    // verdade, e ele tem de pedir o que o cliente deve HOJE.
    //
    // SO QUE "HOJE" PRESSUPOE QUE ELE JA TINHA O CODIGO (11/09/2026). Cobranca
    // que ficou em rascunho -- porque ha duas contas ativas e o ciclo nao sabe
    // por qual emitir, ou porque o provedor caiu na primeira tentativa -- nunca
    // chegou ao cliente. Emitir semanas depois cobrava multa cheia e juros de
    // todos os dias no PRIMEIRO codigo que ele ve, por um atraso que foi do
    // painel. Pela area do cliente era pior: ele le "R$ 149,00" na lista, clica
    // em gerar o codigo e recebe um PIX de R$ 152,72.
    //
    // A primeira emissao, entao, cobra o que foi combinado. Da segunda em
    // diante (a reemissao, que e o caminho de trocar o codigo) o atraso passa a
    // ser dele e os encargos entram.
    //
    // A cobranca e ATUALIZADA antes de o provedor ver, e nao ajustada so na
    // passagem. Se o numero do provedor e o do banco divergissem, o pagamento
    // voltaria maior que a cobranca e a diferenca viraria credito de saldo --
    // o cliente ganharia de volta a propria multa.
    //
    // Idempotente: shield_encargos_da_cobranca refaz a conta sobre o PRINCIPAL,
    // que e o valor menos os encargos ja gravados. Emitir de novo amanha anda
    // os juros de um dia, nunca cobra juros sobre juros.
    require_once __DIR__ . '/encargos.php';
    $jaEsteveNaRua = shield_cobranca_ultima_tentativa($pdo, (int) $cobranca['id']) !== null;
    $recalculo = $jaEsteveNaRua
        ? shield_encargos_da_cobranca($pdo, $cobranca)
        : array('valor' => (int) $cobranca['valor_centavos'], 'encargos' => array('total' => 0));
    if ($recalculo['valor'] !== (int) $cobranca['valor_centavos']) {
        $pdo->prepare(
            'UPDATE cobranca SET valor_centavos = :v, encargos_centavos = :e WHERE id = :id'
        )->execute(array(
            ':v' => $recalculo['valor'],
            ':e' => (int) $recalculo['encargos']['total'],
            ':id' => (int) $cobranca['id'],
        ));

        $cobranca['valor_centavos'] = $recalculo['valor'];
        $cobranca['encargos_centavos'] = (int) $recalculo['encargos']['total'];
    }

    $conta['_url_webhook'] = shield_cobranca_url_aviso($conta);
    // A regra da regua para o provedor cobrar no atraso (14/10/2026); quem nao
    // sabe cobrar sozinho ignora, como ignora `_url_webhook`.
    $conta['_encargos'] = shield_encargos_para_provedor($pdo, $cobranca);
    $resultado = $provedor->criar($cobranca, $conta, $empresa);

    $stmt = $pdo->prepare(
        'INSERT INTO cobranca_tentativa
            (fk_cobranca, fk_conta, provedor, id_externo, metodo, situacao_provedor,
             link_pagamento, copia_e_cola, linha_digitavel, retorno)
         VALUES (:cob, :conta, :prov, :ext, :metodo, :sitprov, :link, :copia, :linha, :retorno)'
    );
    $stmt->execute(array(
        ':cob' => (int) $cobranca['id'],
        ':conta' => (int) $conta['id'],
        ':prov' => (string) $conta['provedor'],
        ':ext' => $resultado->idExterno ?: null,
        ':metodo' => $resultado->metodo ?: null,
        ':sitprov' => $resultado->situacaoProvedor ?: null,
        ':link' => $resultado->link ?: null,
        ':copia' => $resultado->copiaECola ?: null,
        ':linha' => $resultado->linhaDigitavel !== '' ? substr($resultado->linhaDigitavel, 0, 60) : null,
        ':retorno' => $resultado->bruto ?: null,
    ));

    shield_cobranca_aplicar_resultado($pdo, $cobranca, $resultado, 'emissao');

    return $resultado;
}

/**
 * O endereco do aviso que VAI NA EMISSAO -- 17/09/2026. PagBank
 * (`notification_urls`) e InfinitePay (`webhook_url`) so avisam quem manda o
 * endereco em cada pedido; o adaptador que nao usa ignora `_url_webhook`.
 *
 * SO O ENDERECO DECLARADO EM SHIELD_APP_URL, E SO HTTPS. Nunca o Host da
 * requisicao: a emissao roda no cron e na area do cliente, que e publica, e o
 * Host vem de quem chama -- com o token na URL (InfinitePay) ele levaria o
 * segredo do webhook para o dominio de outro, e sem token levaria os avisos de
 * pagamento. Sem endereco declarado, vazio: o pedido sai como antes e a baixa
 * fica com a conciliacao.
 */
function shield_cobranca_url_aviso(array $conta)
{
    require_once __DIR__ . '/../nucleo/env.php';
    require_once __DIR__ . '/cobranca_credenciais.php';

    $base = rtrim(trim((string) shield_env('SHIELD_APP_URL', '')), '/');
    if (strpos($base, 'https://') !== 0) {
        return '';
    }
    $provedor = (string) ($conta['provedor'] ?? '');
    $url = $base . '/webhooks/cobranca.php?p=' . rawurlencode($provedor);
    $segredo = trim((string) ($conta['webhook_segredo'] ?? ''));
    if ($segredo !== '' && !empty(shield_cred_webhook($provedor)['token_na_url'])) {
        $url .= '&t=' . rawurlencode($segredo);
    }

    return $url;
}

/**
 * O que acontece com o aviso de pagamento desta conta por falta de SHIELD_APP_URL,
 * ou null quando nao falta nada -- 01/10/2026.
 *
 * SEM ISTO A FALTA ERA CALADA. shield_cobranca_url_aviso devolve vazio, o pedido
 * sai sem endereco e nada na tela diz que o provedor nao vai avisar. O pacote nao
 * traz `.env`, entao todo membro que ligasse a InfinitePay caia nisso, e a tela de
 * "esqueci a senha" era o unico lugar que citava a variavel.
 *
 * As frases sao diferentes de proposito: no PagBank a baixa ainda chega pela
 * conciliacao, mais devagar; na InfinitePay ela NUNCA chega, porque o
 * payment_check exige transaction_nsu e slug, que so o aviso traz (4.1.31).
 */
function shield_cobranca_aviso_na_emissao_recusa(string $provedor): ?string
{
    if (!in_array($provedor, array('infinitepay', 'pagbank'), true)) {
        return null;
    }

    require_once __DIR__ . '/../nucleo/env.php';
    $base = trim((string) shield_env('SHIELD_APP_URL', ''));
    if (strpos($base, 'https://') === 0) {
        return null;
    }

    $porque = $base === ''
        ? 'falta o SHIELD_APP_URL no arquivo .env do painel'
        : 'o SHIELD_APP_URL do .env nao comeca com https://';

    return $provedor === 'infinitepay'
        ? 'A InfinitePay so avisa o pagamento no endereco que vai em cada cobranca, e ' . $porque
            . '. Sem o aviso o painel nao consegue confirmar pagamento nenhum desta conta.'
        : 'O PagBank so avisa o pagamento no endereco que vai em cada cobranca, e ' . $porque
            . '. Sem o aviso a baixa so chega pela conferencia periodica, mais devagar.';
}

// ------------------------------------------------------- aplicar resultado ---

/**
 * Move a cobranca conforme o que o PROVEDOR disse. Idempotente.
 *
 * Chamada pela emissao, pela consulta e pela conciliacao -- e o unico lugar que
 * escreve situacao de cobranca vinda de fora. Ter tres caminhos escrevendo
 * situacao e como o mesmo pagamento acaba contado duas vezes.
 *
 * NAO DESFAZ TERMINAL. Cobranca ja paga que volte a ser consultada e o provedor
 * responda "aberta" -- por atraso de indice do lado dele -- continua paga: a
 * conta ja entrou. Voltar atras aqui tiraria do cliente uma validade que ele
 * pagou.
 */
function shield_cobranca_aplicar_resultado(PDO $pdo, array $cobranca, Resultado $r, $origem = '')
{
    if (!$r->conclusiva()) {
        // O provedor respondeu algo que nao sabemos ler. Na duvida entre pago e
        // nao sei, e nao sei.
        return false;
    }

    $atual = (string) $cobranca['situacao'];
    if (shield_cob_terminal($atual)) {
        return false;
    }

    $nova = (string) $r->situacao;
    if ($nova === $atual) {
        return false;
    }

    if ($nova === Resultado::PAGA) {
        // O VALOR E CONFERIDO ANTES DE A VALIDADE ANDAR -- 03/09/2026.
        //
        // Antes disto, qualquer pagamento que o provedor dissesse "aprovado"
        // estendia o periodo CHEIO, independente de quanto entrou: um PIX de um
        // real numa cobranca de cento e cinquenta fechava a cobranca e dava o
        // mes ao cliente. A auditoria de seguranca aponta o mesmo buraco no
        // caminho antigo (MED-1, em funcoes/pagamentos.php); ele existia aqui
        // tambem, e aqui ninguem tinha olhado.
        //
        // NAO FECHA E NAO ESTENDE quando falta dinheiro: a cobranca continua
        // aberta e o caso vai para a auditoria, para alguem decidir. Fechar
        // como "paga" com valor menor esconderia a diferenca, e estender seria
        // dar o periodo de graca; as duas escolhas tiram a decisao de quem
        // deveria toma-la.
        //
        // So vale quando o provedor DIZ o valor. Os seis automaticos dizem;
        // dinheiro e PIX estatico nunca chegam aqui como pagos, porque a
        // confirmacao deles e manual e ja passa por permissao propria.
        $esperado = (int) $cobranca['valor_centavos'];
        $pago = $r->valorPagoCentavos;

        // Pagamento MENOR nao fecha e nao estende: a cobranca continua aberta
        // e o caso vai para a auditoria, para alguem decidir. (Chegou a ser
        // relaxado em 04/09/2026 e voltou no mesmo dia: o membro nao sabia que
        // era assim e preferiu manter -- ninguem ganha o mes por R$ 1.)
        // Pagamento MAIOR fecha normalmente e a sobra vira credito do cliente.
        if ($pago !== null && $pago < ($esperado - SHIELD_COB_TOLERANCIA_CENTAVOS)) {
            shield_auditar($pdo, 'cobranca_pagamento_parcial', array(
                'alvo_tipo' => 'cobranca', 'alvo_id' => (int) $cobranca['id'],
                'detalhe' => 'PAGAMENTO MENOR QUE O COBRADO, validade NAO estendida: entraram R$ '
                    . shield_dinheiro($pago) . ' de R$ ' . shield_dinheiro($esperado)
                    . ' (' . trim($origem . ' ' . $r->situacaoProvedor) . ')',
            ));

            return false;
        }

        $stmt = $pdo->prepare(
            'UPDATE cobranca
                SET situacao = :sit, pago_em = :quando, valor_pago_centavos = :valor,
                    forma = COALESCE(:forma, forma)
              WHERE id = :id AND situacao NOT IN (:paga, :canc, :est)'
        );
        $stmt->execute(array(
            ':sit' => SHIELD_COB_PAGA,
            ':quando' => $r->pagoEm ?: date('Y-m-d H:i:s'),
            ':valor' => $r->valorPagoCentavos ?? (int) $cobranca['valor_centavos'],
            ':forma' => $r->metodo ?: null,
            ':id' => (int) $cobranca['id'],
            ':paga' => SHIELD_COB_PAGA,
            ':canc' => SHIELD_COB_CANCELADA,
            ':est' => SHIELD_COB_ESTORNADA,
        ));

        // rowCount 0 significa que outro caminho ja a fechou entre a leitura e
        // a escrita. Nao e erro -- e a corrida perdida, e o resultado e o mesmo.
        if ($stmt->rowCount() > 0) {
            shield_auditar($pdo, 'cobranca_paga', array(
                'alvo_tipo' => 'cobranca', 'alvo_id' => (int) $cobranca['id'],
                'antes' => $atual, 'depois' => SHIELD_COB_PAGA,
                'detalhe' => trim($origem . ' ' . $r->situacaoProvedor),
            ));

            shield_saldo_apos_pagamento($pdo, $cobranca,
                $r->valorPagoCentavos ?? (int) $cobranca['valor_centavos'], 'provedor', $r->pagoEm ?: null);
            shield_cobranca_estendeu_validade($pdo, $cobranca, 'pagamento confirmado pelo provedor');

            return true;
        }

        return false;
    }

    $stmt = $pdo->prepare('UPDATE cobranca SET situacao = :sit WHERE id = :id AND situacao = :atual');
    $stmt->execute(array(':sit' => $nova, ':id' => (int) $cobranca['id'], ':atual' => $atual));

    if ($stmt->rowCount() > 0 && shield_cob_terminal($nova)) {
        shield_auditar($pdo, 'cobranca_' . $nova, array(
            'alvo_tipo' => 'cobranca', 'alvo_id' => (int) $cobranca['id'],
            'antes' => $atual, 'depois' => $nova, 'detalhe' => $origem,
        ));

        // CANCELADA NO PROVEDOR DEVOLVE O CREDITO, COMO O BOTAO (06/10/2026). O
        // membro que cancelava no site do Asaas ou da Cora e clicava em Conferir
        // via a cobranca cancelada e o credito que ela tinha consumido ao nascer
        // sumido: shield_saldo_desfazer so morava em shield_cobranca_cancelar.
        // So aqui, depois do UPDATE que mudou a linha, e por isso uma vez so: a
        // proxima consulta acha a cobranca terminal e volta antes. A linha e lida
        // de novo porque quem chama pode ter carregado so parte das colunas, e
        // sem saldo_aplicado_centavos nada seria devolvido.
        if ($nova === SHIELD_COB_CANCELADA || $nova === SHIELD_COB_ESTORNADA) {
            $linha = $pdo->prepare('SELECT * FROM cobranca WHERE id = :id');
            $linha->execute(array(':id' => (int) $cobranca['id']));
            $fresca = $linha->fetch(PDO::FETCH_ASSOC);
            if ($fresca) {
                shield_saldo_desfazer($pdo, $fresca, 'cobranca ' . $nova . ' no provedor');
            }
        }
    }

    return $stmt->rowCount() > 0;
}

// As outras duas metades do motor. Separadas em tres arquivos porque um so
// passaria de 700 linhas -- e porque a fila e o webhook so existem por causa da
// hospedagem do membro, e um dia podem sair daqui inteiros.
require_once __DIR__ . '/cobranca_motor2.php';
require_once __DIR__ . '/cobranca_fila.php';

/**
 * Quanto cada cliente DEVE hoje, em centavos: a soma do que esta aberto ou
 * vencido -- 10/09/2026, fatia 1 da reorganizacao ("um lugar de
 * contar"). Rascunho nao entra: e cobranca guardada, ainda nao e divida.
 *
 * A lista de clientes e a ficha somavam cada uma com o proprio SQL. Devolve
 * codigo => centavos so para quem deve; base sem o modulo devolve vazio.
 *
 * Desde 14/09/2026 le de shield_cobranca_resumo_por_empresa: os grupos de
 * Cobrancas precisam do vencido junto, e duas somas de "aberto" em dois SQL
 * seriam duas respostas esperando para divergir. O retorno nao mudou.
 */
function shield_cobranca_em_aberto_por_empresa(PDO $pdo, array $codigos)
{
    $mapa = array();
    foreach (shield_cobranca_resumo_por_empresa($pdo, $codigos) as $codigo => $resumo) {
        $mapa[$codigo] = $resumo['aberto'];
    }

    return $mapa;
}

/**
 * O que cada cliente deve e quanto disso JA VENCEU -- 14/09/2026.
 *
 * `aberto` e aberta + vencida (rascunho fora, como sempre). `vencido` inclui a
 * aberta com vencimento passado: a situacao 'vencida' so e gravada quando o
 * relogio passa (shield_cobranca_marcar_vencidas), e ate la a linha da tela ja
 * sai vermelha -- o cabecalho do grupo nao pode chamar essa fatura de "a
 * vencer". O corte e o mesmo do relogio (vencimento < CURDATE()), para a
 * marcacao e a tela concordarem no dia da virada.
 *
 * `qtd_aberto` e `qtd_vencido` contam as FATURAS no mesmo recorte (14/09/2026): o
 * grupo de Cobrancas diz "2 vencidas" e "em dia" de relance, e a quantidade sai da
 * mesma consulta do dinheiro para as duas nao discordarem.
 *
 * @return array<int, array{aberto: int, vencido: int, qtd_aberto: int, qtd_vencido: int}> so quem deve
 */
function shield_cobranca_resumo_por_empresa(PDO $pdo, array $codigos)
{
    $limpos = array();
    foreach ($codigos as $c) {
        if ((int) $c > 0) {
            $limpos[] = (int) $c;
        }
    }
    if (!$limpos) {
        return array();
    }

    try {
        // :vencida2 e :vencida3, e nao :vencida de novo: marcador nomeado repetido estoura no PDO.
        $stmt = $pdo->prepare(
            'SELECT fk_empresa, SUM(valor_centavos) AS aberto,
                    SUM(CASE WHEN situacao = :vencida2 OR vencimento < CURDATE() THEN valor_centavos ELSE 0 END) AS vencido,
                    COUNT(*) AS qtd_aberto,
                    SUM(CASE WHEN situacao = :vencida3 OR vencimento < CURDATE() THEN 1 ELSE 0 END) AS qtd_vencido
               FROM cobranca
              WHERE fk_empresa IN (' . implode(',', array_unique($limpos)) . ') AND situacao IN (:aberta, :vencida)
              GROUP BY fk_empresa'
        );
        $stmt->execute(array(
            ':aberta' => SHIELD_COB_ABERTA, ':vencida' => SHIELD_COB_VENCIDA,
            ':vencida2' => SHIELD_COB_VENCIDA, ':vencida3' => SHIELD_COB_VENCIDA,
        ));
    } catch (Throwable $semTabela) {
        return array();
    }

    $mapa = array();
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $l) {
        $mapa[(int) $l['fk_empresa']] = array(
            'aberto' => (int) $l['aberto'], 'vencido' => (int) $l['vencido'],
            'qtd_aberto' => (int) $l['qtd_aberto'], 'qtd_vencido' => (int) $l['qtd_vencido'],
        );
    }

    return $mapa;
}
