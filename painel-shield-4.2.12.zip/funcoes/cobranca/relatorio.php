<?php

/**
 * Relatorio do periodo: o que entrou e o que esta para entrar -- 01/10/2026.
 *
 * Pedido no feedback da 4.2.10: "relatorio financeiro, ex. contas pagas / a
 * receber do periodo". O painel so tinha o "entrou nos ultimos 12 meses" da tela
 * de Assinaturas e os totais por cliente em Cobrancas -- nada por periodo
 * escolhido. "Contas a pagar" nao entra porque o painel nao registra despesa.
 *
 * CADA LADO TEM A SUA DATA, e e de proposito:
 *
 *   RECEBIDO conta pela data do PAGAMENTO (`pago_em`) e pelo valor que de fato
 *   entrou (`valor_pago_centavos`, ou o da fatura quando ele nao foi gravado) --
 *   a mesma regra de shield_receita_resumo, para as duas telas nao discordarem.
 *   Uma mensalidade de setembro paga em outubro e dinheiro de outubro.
 *
 *   A RECEBER conta pela data do VENCIMENTO. Rascunho entra, separado: e
 *   cobranca guardada que ainda nao foi emitida, e o membro precisa ver que ela
 *   existe para emitir.
 *
 * Cancelada e estornada nao entram em lado nenhum: nao e dinheiro que entrou
 * nem dinheiro que vai entrar.
 */

require_once __DIR__ . '/cobranca_motor.php'; // SHIELD_COB_*

/** Quantas linhas cada lista mostra. Os TOTAIS nao sofrem o corte: vem do banco. */
const SHIELD_RELATORIO_LIMITE = 500;

/**
 * O periodo pedido na URL. Sem nada, o mes corrente. Devolve
 * array('de' => Y-m-d, 'ate' => Y-m-d, 'erro' => ?string); com erro, o periodo
 * devolvido e o mes corrente, para a tela continuar mostrando alguma coisa.
 */
function shield_relatorio_periodo(array $get, ?string $hoje = null): array
{
    $dia = new DateTimeImmutable($hoje ?? 'today');
    $padrao = array('de' => $dia->format('Y-m-01'), 'ate' => $dia->format('Y-m-t'), 'erro' => null);

    $de = trim((string) ($get['de'] ?? ''));
    $ate = trim((string) ($get['ate'] ?? ''));
    if ($de === '' && $ate === '') {
        return $padrao;
    }

    $dDe = DateTimeImmutable::createFromFormat('!Y-m-d', $de);
    $dAte = DateTimeImmutable::createFromFormat('!Y-m-d', $ate);
    // createFromFormat aceita 2026-02-31 e vira marco: conferir a volta pega isso.
    if ($dDe === false || $dAte === false || $dDe->format('Y-m-d') !== $de || $dAte->format('Y-m-d') !== $ate) {
        return array('erro' => 'Data invalida. Mostrando o mes corrente.') + $padrao;
    }
    if ($dDe > $dAte) {
        return array('erro' => 'A data inicial vem depois da final. Mostrando o mes corrente.') + $padrao;
    }

    return array('de' => $de, 'ate' => $ate, 'erro' => null);
}

/**
 * Os numeros e as linhas do periodo. Base sem a tabela devolve tudo zerado.
 *
 * Devolve array(
 *   'recebido'  => array('total', 'qtd', 'linhas'),
 *   'a_receber' => array('vencido', 'qtd_vencido', 'a_vencer', 'qtd_a_vencer',
 *                        'rascunho', 'qtd_rascunho', 'linhas'),
 *   'cortado'   => bool,  -- alguma das listas passou do limite
 * ), valores em centavos.
 */
function shield_relatorio_financeiro(PDO $pdo, string $de, string $ate, ?string $hoje = null, int $limite = SHIELD_RELATORIO_LIMITE): array
{
    $hoje = $hoje ?? date('Y-m-d');
    $limite = max(1, $limite);
    // pago_em tem hora: "ate" inclui o dia inteiro, entao a borda e o dia seguinte.
    $ateExclusivo = (new DateTimeImmutable($ate))->modify('+1 day')->format('Y-m-d');

    $r = array(
        'recebido' => array('total' => 0, 'qtd' => 0, 'linhas' => array()),
        'a_receber' => array('vencido' => 0, 'qtd_vencido' => 0, 'a_vencer' => 0, 'qtd_a_vencer' => 0,
                             'rascunho' => 0, 'qtd_rascunho' => 0, 'linhas' => array()),
        'cortado' => false,
    );

    try {
        $onde = 'c.situacao = :paga AND c.pago_em >= :de AND c.pago_em < :ate';
        $p = array(':paga' => SHIELD_COB_PAGA, ':de' => $de, ':ate' => $ateExclusivo);

        $st = $pdo->prepare('SELECT COUNT(*) AS qtd, COALESCE(SUM(COALESCE(NULLIF(c.valor_pago_centavos, 0), c.valor_centavos)), 0) AS total
                               FROM cobranca c WHERE ' . $onde);
        $st->execute($p);
        $t = $st->fetch(PDO::FETCH_ASSOC) ?: array();
        $r['recebido']['qtd'] = (int) ($t['qtd'] ?? 0);
        $r['recebido']['total'] = (int) ($t['total'] ?? 0);

        $st = $pdo->prepare(
            'SELECT c.id, c.fk_empresa, c.descricao, c.vencimento, c.pago_em,
                    COALESCE(NULLIF(c.valor_pago_centavos, 0), c.valor_centavos) AS valor, e.razao
               FROM cobranca c LEFT JOIN empresa e ON e.codigo = c.fk_empresa
              WHERE ' . $onde . '
              ORDER BY c.pago_em DESC, c.id DESC
              LIMIT ' . ($limite + 1)
        );
        $st->execute($p);
        $linhas = $st->fetchAll(PDO::FETCH_ASSOC) ?: array();
        if (count($linhas) > $limite) {
            $r['cortado'] = true;
            $linhas = array_slice($linhas, 0, $limite);
        }
        $r['recebido']['linhas'] = $linhas;

        // A RECEBER. Vencido e o que ja passou da data de hoje -- pela data, e
        // nao pela palavra 'vencida', que so a passada do relogio grava: entre o
        // vencimento e a passada seguinte a fatura ainda diz 'aberta'.
        $onde = 'c.situacao IN (:a, :v, :r) AND c.vencimento >= :de AND c.vencimento <= :ate';
        $p = array(':a' => SHIELD_COB_ABERTA, ':v' => SHIELD_COB_VENCIDA, ':r' => SHIELD_COB_RASCUNHO,
                   ':de' => $de, ':ate' => $ate);
        $balde = "CASE WHEN c.situacao = :r2 THEN 'rascunho' WHEN c.vencimento < :hoje THEN 'vencido' ELSE 'a_vencer' END";

        $st = $pdo->prepare('SELECT ' . $balde . ' AS balde, COUNT(*) AS qtd, COALESCE(SUM(c.valor_centavos), 0) AS total
                               FROM cobranca c WHERE ' . $onde . ' GROUP BY balde');
        $st->execute($p + array(':r2' => SHIELD_COB_RASCUNHO, ':hoje' => $hoje));
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) ?: array() as $b) {
            $chave = (string) $b['balde'];
            $r['a_receber'][$chave] = (int) $b['total'];
            $r['a_receber']['qtd_' . $chave] = (int) $b['qtd'];
        }

        $st = $pdo->prepare(
            'SELECT c.id, c.fk_empresa, c.descricao, c.vencimento, c.situacao, c.valor_centavos AS valor, e.razao,
                    ' . $balde . ' AS balde
               FROM cobranca c LEFT JOIN empresa e ON e.codigo = c.fk_empresa
              WHERE ' . $onde . '
              ORDER BY c.vencimento ASC, c.id ASC
              LIMIT ' . ($limite + 1)
        );
        $st->execute($p + array(':r2' => SHIELD_COB_RASCUNHO, ':hoje' => $hoje));
        $linhas = $st->fetchAll(PDO::FETCH_ASSOC) ?: array();
        if (count($linhas) > $limite) {
            $r['cortado'] = true;
            $linhas = array_slice($linhas, 0, $limite);
        }
        $r['a_receber']['linhas'] = $linhas;
    } catch (Throwable $semTabela) {
        // Base antiga sem cobranca: a tela mostra zero, e nao erro.
    }

    return $r;
}

/**
 * Contas a receber, por cliente -- 06/10/2026.
 *
 * Pedido no feedback ("contas a receber: quem deve, quanto deve, ate quando").
 * O relatorio do periodo lista FATURA por fatura e pede datas; esta e a pergunta
 * de quem vai pegar o telefone: QUEM esta devendo, quanto ao todo, quanto disso
 * ja venceu, a fatura mais atrasada e o proximo vencimento -- sem periodo.
 *
 * Mesmas regras do relatorio, para as duas telas nao discordarem:
 *   - deve e fatura ABERTA ou VENCIDA; rascunho ainda nao foi ao cliente e
 *     entra so como contagem separada, para o membro saber que existe;
 *   - vencido e pela DATA, e nao pela palavra 'vencida' (a passada do relogio
 *     so grava depois);
 *   - cancelada e estornada nao entram.
 *
 * $quem: 'todos', 'atrasados' (so quem tem algo vencido) ou 'ate' (so faturas
 * com vencimento ate $ate, inclusive as ja vencidas). Mais atrasado primeiro.
 */
function shield_contas_receber(PDO $pdo, string $quem = 'todos', ?string $ate = null, ?string $hoje = null): array
{
    $hoje = $hoje ?? date('Y-m-d');
    $semana = (new DateTimeImmutable($hoje))->modify('+7 days')->format('Y-m-d');
    $r = array(
        'total' => 0, 'vencido' => 0, 'sete_dias' => 0, 'clientes' => 0, 'clientes_atrasados' => 0,
        'rascunho' => 0, 'qtd_rascunho' => 0, 'linhas' => array(),
    );

    try {
        $onde = 'c.situacao IN (:a, :v)';
        $p = array(':a' => SHIELD_COB_ABERTA, ':v' => SHIELD_COB_VENCIDA,
                   ':h1' => $hoje, ':h2' => $hoje, ':h3' => $hoje, ':h4' => $hoje, ':s' => $semana);
        if ($quem === 'ate' && $ate !== null) {
            $onde .= ' AND c.vencimento <= :ate';
            $p[':ate'] = $ate;
        }

        // Marcador repetido estoura no PDO: cada uso do "hoje" tem o seu.
        $st = $pdo->prepare(
            'SELECT c.fk_empresa, e.razao, e.cnpj, e.fone, e.encerrado_em,
                    COUNT(*) AS qtd, SUM(c.valor_centavos) AS total,
                    SUM(CASE WHEN c.vencimento < :h1 THEN c.valor_centavos ELSE 0 END) AS vencido,
                    SUM(CASE WHEN c.vencimento < :h2 THEN 1 ELSE 0 END) AS qtd_vencido,
                    SUM(CASE WHEN c.vencimento >= :h3 AND c.vencimento <= :s THEN c.valor_centavos ELSE 0 END) AS sete_dias,
                    MIN(c.vencimento) AS mais_antigo,
                    MIN(CASE WHEN c.vencimento >= :h4 THEN c.vencimento END) AS proximo
               FROM cobranca c LEFT JOIN empresa e ON e.codigo = c.fk_empresa
              WHERE ' . $onde . '
              GROUP BY c.fk_empresa, e.razao, e.cnpj, e.fone, e.encerrado_em'
        );
        $st->execute($p);
        $linhas = array();
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) ?: array() as $l) {
            $l['qtd'] = (int) $l['qtd'];
            $l['total'] = (int) $l['total'];
            $l['vencido'] = (int) $l['vencido'];
            $l['qtd_vencido'] = (int) $l['qtd_vencido'];
            $l['sete_dias'] = (int) $l['sete_dias'];
            $l['dias_atraso'] = $l['vencido'] > 0
                ? (int) (new DateTimeImmutable(substr((string) $l['mais_antigo'], 0, 10)))->diff(new DateTimeImmutable($hoje))->format('%a')
                : 0;
            if ($quem === 'atrasados' && $l['vencido'] === 0) {
                continue;
            }
            $linhas[] = $l;
            $r['total'] += $l['total'];
            $r['vencido'] += $l['vencido'];
            $r['sete_dias'] += $l['sete_dias'];
            $r['clientes']++;
            if ($l['vencido'] > 0) {
                $r['clientes_atrasados']++;
            }
        }
        // Quem esta ha mais tempo sem pagar primeiro (empate: quem deve mais
        // vencido); depois, quem esta em dia, pelo vencimento mais proximo.
        usort($linhas, static function (array $x, array $y): int {
            $ordem = array($y['dias_atraso'], $y['vencido']) <=> array($x['dias_atraso'], $x['vencido']);

            return $ordem !== 0 ? $ordem : strcmp((string) $x['proximo'], (string) $y['proximo']);
        });
        $r['linhas'] = $linhas;

        $st = $pdo->prepare('SELECT COUNT(*) AS qtd, COALESCE(SUM(valor_centavos), 0) AS total FROM cobranca WHERE situacao = :r');
        $st->execute(array(':r' => SHIELD_COB_RASCUNHO));
        $t = $st->fetch(PDO::FETCH_ASSOC) ?: array();
        $r['qtd_rascunho'] = (int) ($t['qtd'] ?? 0);
        $r['rascunho'] = (int) ($t['total'] ?? 0);
    } catch (Throwable $semTabela) {
        // Base antiga sem cobranca: a tela mostra zero, e nao erro.
    }

    return $r;
}
