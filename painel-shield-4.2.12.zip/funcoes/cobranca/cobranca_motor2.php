<?php

// Motor de cobranca, segunda metade - 25/08/2026.
//
// Consulta, confirmacao manual, cancelamento, estorno, webhook, fila e
// conciliacao. Carregado pelo cobranca_motor.php.

use Shield\Cobranca\Registro;
use Shield\Cobranca\Resultado;

/**
 * A tentativa que tem codigo VIVO no provedor, ou null -- 11/09/2026.
 *
 * "Viva" e: tem id_externo e nao foi cancelada pelo painel para reemitir. E a
 * pergunta que faltava antes de emitir. Sem ela, o segundo clique em "Emitir"
 * (ou no "Gerar o codigo" da area do cliente) criava um SEGUNDO pagamento no
 * gateway. Como todo o painel le so a ULTIMA tentativa, o primeiro codigo
 * continuava vivo la fora e invisivel aqui -- quem pagasse aquele nunca teria
 * baixa automatica, e a regua seguiria contando os dias de atraso.
 */
function shield_cobranca_tentativa_viva(PDO $pdo, $cobrancaId)
{
    $tentativa = shield_cobranca_ultima_tentativa($pdo, $cobrancaId);
    if ($tentativa === null || trim((string) $tentativa['id_externo']) === '') {
        return null;
    }
    if ((string) $tentativa['situacao_provedor'] === SHIELD_COB_TENTATIVA_CANCELADA) {
        return null;
    }

    return $tentativa;
}

/** A ultima tentativa de uma cobranca -- e por ela que se fala com o provedor. */
function shield_cobranca_ultima_tentativa(PDO $pdo, $cobrancaId)
{
    $stmt = $pdo->prepare(
        'SELECT * FROM cobranca_tentativa WHERE fk_cobranca = :id
          ORDER BY id DESC LIMIT 1'
    );
    $stmt->execute(array(':id' => (int) $cobrancaId));
    $linha = $stmt->fetch(PDO::FETCH_ASSOC);

    return is_array($linha) ? $linha : null;
}

/**
 * Pergunta ao provedor e aplica. E A FONTE DA VERDADE do sistema inteiro.
 *
 * Devolve o Resultado, ou null quando nao ha a quem perguntar (cobranca que
 * nunca foi emitida, ou provedor sem adaptador).
 */
function shield_cobranca_consultar(PDO $pdo, $cobrancaId)
{
    $cobranca = shield_cob_ler($pdo, $cobrancaId);
    if ($cobranca === null) {
        return null;
    }

    $tentativa = shield_cobranca_ultima_tentativa($pdo, $cobrancaId);
    if ($tentativa === null || trim((string) $tentativa['id_externo']) === '') {
        return null;
    }

    // A TENTATIVA QUE O PAINEL CANCELOU PARA REEMITIR NAO SE PERGUNTA -- 17/09/2026.
    // Com a emissao nova falhando, ela fica sendo a ultima; perguntada, respondia
    // "cancelada" (quem cancelou fomos nos), a cobranca inteira virava cancelada
    // com a divida de pe, e o rotulo sumia -- o codigo morto voltava a contar
    // como vivo. O caminho dali e o Emitir, como shield_cobranca_tentativa_viva diz.
    if ((string) $tentativa['situacao_provedor'] === SHIELD_COB_TENTATIVA_CANCELADA) {
        return null;
    }

    $conta = shield_cob_conta($pdo, (int) $tentativa['fk_conta']);
    $provedor = Registro::para((string) $tentativa['provedor']);
    if ($conta === null || $provedor === null) {
        return null;
    }

    $r = $provedor->consultar((string) $tentativa['id_externo'], $conta);

    // O CODIGO QUE A EMISSAO NAO TROUXE ENTRA AQUI -- 17/09/2026. O boleto do
    // Inter e assincrono: se as leituras da emissao pegassem "em processamento",
    // a tentativa ficava sem codigo para sempre (e, com id externo, o Emitir era
    // recusado). So PREENCHE o que esta vazio: o codigo que ja esta na mao do
    // cliente nao muda por baixo dele.
    $stmt = $pdo->prepare(
        'UPDATE cobranca_tentativa
            SET situacao_provedor = :sit, retorno = COALESCE(:retorno, retorno),
                link_pagamento = COALESCE(NULLIF(link_pagamento, ""), :link),
                copia_e_cola = COALESCE(NULLIF(copia_e_cola, ""), :copia),
                linha_digitavel = COALESCE(NULLIF(linha_digitavel, ""), :linha)
          WHERE id = :id'
    );
    $stmt->execute(array(
        ':sit' => $r->situacaoProvedor ?: null,
        ':retorno' => $r->bruto ?: null,
        ':link' => $r->link !== '' ? substr($r->link, 0, 500) : null,
        ':copia' => $r->copiaECola !== '' ? $r->copiaECola : null,
        ':linha' => $r->linhaDigitavel !== '' ? substr($r->linhaDigitavel, 0, 60) : null,
        ':id' => (int) $tentativa['id'],
    ));

    shield_cobranca_aplicar_resultado($pdo, $cobranca, $r, 'consulta');

    return $r;
}

// ------------------------------------------------------ confirmacao manual ---

/**
 * Quem pode confirmar pagamento a mao.
 *
 * A conferencia mora AQUI, e nao so na tela: tela esconde botao, funcao recusa
 * chamada. Sem isto, bastaria descobrir o endereco do POST -- e o unico ponto
 * do sistema onde alguem de dentro da meses de licenca sem dinheiro entrar nao
 * pode depender de o botao estar escondido.
 */
function shield_pode_confirmar_pagamento(PDO $pdo, ?array $usuario = null)
{
    $usuario = $usuario ?? (array) ($_SESSION['usuario'] ?? array());
    if (!isset($usuario['id'])) {
        return false;
    }

    try {
        $stmt = $pdo->prepare('SELECT pode_confirmar_pagamento FROM usuario WHERE id = :id');
        $stmt->execute(array(':id' => (int) $usuario['id']));
        $pode = $stmt->fetchColumn();

        return $pode !== false && (int) $pode === 1;
    } catch (Throwable $ignorado) {
        // Base ainda sem a coluna: cai no que valia antes -- administrador
        // confirma. Recusar aqui deixaria o membro sem confirmar nada ate
        // rodar a migracao, e isso e o caixa dele parado.
        return trim((string) ($usuario['acesso'] ?? '')) === '1';
    }
}

/**
 * O membro viu o dinheiro e confirma. ESTE E O PONTO MAIS SENSIVEL DO SISTEMA.
 *
 * Ele estende licenca sem prova externa nenhuma -- a prova e o operador. Por
 * isso: quem confirmou, quando, qual valor e por qual forma ficam no livro, e a
 * tela exige permissao propria para chegar aqui.
 *
 * NAO existe "desconfirmar": correcao e ESTORNO, que lanca o inverso com
 * motivo. O rastro fica.
 */
function shield_cobranca_confirmar_manual(PDO $pdo, $cobrancaId, $valorCentavos, $forma, $observacao = '')
{
    if (!shield_pode_confirmar_pagamento($pdo)) {
        throw new RuntimeException('Seu usuario nao tem permissao para confirmar pagamento a mao.');
    }

    $cobranca = shield_cob_ler($pdo, $cobrancaId);
    if ($cobranca === null) {
        throw new RuntimeException('Cobranca nao encontrada.');
    }
    if (shield_cob_terminal($cobranca['situacao'])) {
        throw new RuntimeException('Esta cobranca ja esta ' . $cobranca['situacao'] . '.');
    }

    $valor = (int) $valorCentavos;
    if ($valor <= 0) {
        $valor = (int) $cobranca['valor_centavos'];
    }

    $stmt = $pdo->prepare(
        'UPDATE cobranca
            SET situacao = :sit, pago_em = NOW(), valor_pago_centavos = :valor, forma = :forma
          WHERE id = :id AND situacao NOT IN (:paga, :canc, :est)'
    );
    $stmt->execute(array(
        ':sit' => SHIELD_COB_PAGA,
        ':valor' => $valor,
        ':forma' => substr((string) $forma, 0, 20),
        ':id' => (int) $cobrancaId,
        ':paga' => SHIELD_COB_PAGA,
        ':canc' => SHIELD_COB_CANCELADA,
        ':est' => SHIELD_COB_ESTORNADA,
    ));

    if ($stmt->rowCount() === 0) {
        throw new RuntimeException('A cobranca mudou de situacao enquanto voce confirmava.');
    }

    shield_auditar($pdo, 'pagamento_confirmado_a_mao', array(
        'alvo_tipo' => 'cobranca',
        'alvo_id' => (int) $cobrancaId,
        'antes' => (string) $cobranca['situacao'],
        'depois' => SHIELD_COB_PAGA,
        'detalhe' => 'R$ ' . shield_dinheiro($valor) . ' por ' . $forma
            . ($observacao !== '' ? ' -- ' . $observacao : ''),
    ));

    shield_saldo_apos_pagamento($pdo, $cobranca, $valor, 'confirmado a mao');
    shield_cobranca_estendeu_validade($pdo, $cobranca, 'confirmado a mao por ' . $forma);

    return shield_cobranca_baixar_no_provedor($pdo, $cobranca, $valor);
}

/**
 * O PDF DO BOLETO PELO PAINEL (19/10/2026). Para o provedor que nao da endereco
 * publico do boleto (o Inter: o PDF sai de uma chamada com certificado), o
 * painel o busca e entrega. Quem tem link continua com o "Abrir no provedor".
 *
 * $empresa, quando vem, e quem pede (a area do cliente): a cobranca tem de ser
 * dela, senao o numero na URL abriria o boleto de outra loja.
 */
function shield_cobranca_boleto_pdf(PDO $pdo, $cobrancaId, $empresa = null)
{
    $cobranca = shield_cob_ler($pdo, $cobrancaId);
    if ($cobranca === null || ($empresa !== null && (int) $cobranca['fk_empresa'] !== (int) $empresa)) {
        throw new RuntimeException('Cobranca nao encontrada.');
    }
    $tentativa = shield_cobranca_tentativa_viva($pdo, (int) $cobranca['id']);
    $provedor = $tentativa !== null ? Registro::para((string) $tentativa['provedor']) : null;
    if ($provedor === null || !method_exists($provedor, 'pdfBoleto')) {
        throw new RuntimeException('Esta cobranca nao tem boleto para imprimir por aqui.');
    }
    $conta = shield_cob_conta($pdo, (int) $tentativa['fk_conta']);
    if ($conta === null) {
        throw new RuntimeException('A conta que emitiu este boleto nao existe mais.');
    }

    return array(
        'pdf' => $provedor->pdfBoleto((string) $tentativa['id_externo'], $conta),
        'nome' => 'boleto-' . (int) $cobranca['id'] . '.pdf',
    );
}

/**
 * A linha mostra "Imprimir boleto"? So a do boleto de quem tem pdfBoleto e nao
 * da link -- a que tem link ja abre o boleto pelo provedor. Le as colunas da
 * lista de Cobrancas (provedor, metodo_emitido, situacao_provedor, link).
 */
function shield_cobranca_tem_pdf_do_painel(array $linha)
{
    // A area do cliente nao traz id_externo nem situacao_provedor: o que falta nao
    // e conferido aqui, e a rota confere de novo pela tentativa viva.
    if ((string) ($linha['metodo_emitido'] ?? '') !== 'boleto' || trim((string) ($linha['link'] ?? '')) !== ''
        || (array_key_exists('id_externo', $linha) && trim((string) $linha['id_externo']) === '')
        || (string) ($linha['situacao_provedor'] ?? '') === SHIELD_COB_TENTATIVA_CANCELADA) {
        return false;
    }
    $provedor = Registro::para((string) ($linha['provedor'] ?? ''));

    return $provedor !== null && method_exists($provedor, 'pdfBoleto');
}

/** Entrega o PDF e encerra. */
function shield_cobranca_enviar_pdf(array $arquivo)
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="' . $arquivo['nome'] . '"');
    header('Content-Length: ' . strlen($arquivo['pdf']));
    header('Cache-Control: private, no-store');
    echo $arquivo['pdf'];
    exit;
}

/**
 * O CODIGO NO PROVEDOR DEPOIS DA CONFIRMACAO A MAO (15/10/2026). Devolve a frase
 * para a tela -- null quando nao havia codigo vivo em provedor nenhum.
 *
 * A confirmacao de gente ja valeu antes daqui, e o que acontece no provedor NAO a
 * desfaz: quem digitou viu o dinheiro. Esta e a cortesia de nao deixar o codigo
 * pagavel nem o lembrete de atraso saindo. Por isso tropeco vira frase e livro,
 * nunca excecao.
 *
 * SO DA BAIXA QUEM TEM "RECEBIDO POR FORA" NA API (`receberEmDinheiro`: o Asaas).
 * Nos outros a saida seria cancelar o codigo, e isso morde: o boleto pago e ainda
 * nao compensado aparece pendente no provedor, e cancelar um boleto registrado
 * pode devolver o dinheiro a quem pagou. La fica o aviso de dar baixa a mao.
 *
 * PERGUNTA ANTES DE MARCAR: se o provedor ja diz pago, o cliente pagou o codigo, e
 * marcar "recebido em dinheiro" por cima registraria dois recebimentos.
 */
function shield_cobranca_baixar_no_provedor(PDO $pdo, array $cobranca, $valorCentavos)
{
    $tentativa = shield_cobranca_tentativa_viva($pdo, (int) $cobranca['id']);
    if ($tentativa === null) {
        return null;
    }
    $conta = shield_cob_conta($pdo, (int) $tentativa['fk_conta']);
    $provedor = Registro::para((string) $tentativa['provedor']);
    if ($conta === null || $provedor === null) {
        return null;
    }
    $idExterno = (string) $tentativa['id_externo'];
    $nome = (string) ($conta['nome'] ?? $tentativa['provedor']);

    if (!method_exists($provedor, 'receberEmDinheiro')) {
        // Dinheiro e PIX na sua chave nao tem codigo em lugar nenhum a baixar.
        if (in_array((string) $tentativa['provedor'], array('dinheiro', 'pix_estatico'), true)) {
            return null;
        }

        return 'A cobranca continua em aberto em ' . $nome . ': de baixa (ou cancele) por la, senao o cliente '
            . 'pode pagar o codigo de novo.';
    }

    try {
        if ($provedor->consultar($idExterno, $conta)->situacao === Resultado::PAGA) {
            return $nome . ' ja tinha esse pagamento: nada foi marcado la.';
        }
        $provedor->receberEmDinheiro($idExterno, $conta, (int) $valorCentavos, date('Y-m-d'));
    } catch (Throwable $e) {
        shield_auditar($pdo, 'cobranca_baixa_no_provedor_falhou', array(
            'alvo_tipo' => 'cobranca', 'alvo_id' => (int) $cobranca['id'],
            'detalhe' => $idExterno . ': ' . substr($e->getMessage(), 0, 200),
        ));

        return 'O pagamento foi confirmado aqui, mas ' . $nome . ' recusou a baixa (' . $e->getMessage()
            . '). De baixa por la, senao o cliente pode pagar o codigo de novo.';
    }

    shield_auditar($pdo, 'cobranca_baixa_no_provedor', array(
        'alvo_tipo' => 'cobranca', 'alvo_id' => (int) $cobranca['id'],
        'detalhe' => $idExterno . ' marcada como recebida em ' . $nome,
    ));

    return 'Baixa feita tambem em ' . $nome . ': o codigo deixou de valer e o cliente nao recebe mais lembrete.';
}

/**
 * Estorno. NAO APAGA o registro: lanca o inverso, com motivo.
 *
 * Confirmacao manual desfeita apagando a linha seria o jeito de dar meses de
 * licenca e nao deixar rastro -- exatamente o que a auditoria existe para
 * impedir.
 *
 * DESFAZ O QUE O PAGAMENTO FEZ (11/09/2026): recolhe os meses de licenca que
 * aquela cobranca deu e devolve o saldo ao estado anterior. Ate aqui o estorno
 * so trocava a palavra na tela -- o dinheiro voltava para o cliente e ele ficava
 * com os meses e com o troco. Recolher aqui e seguro porque estorno e ACAO de
 * gente, com motivo obrigatorio, e nao silencio de integracao.
 */
function shield_cobranca_estornar(PDO $pdo, $cobrancaId, $motivo)
{
    $cobranca = shield_cob_ler($pdo, $cobrancaId);
    if ($cobranca === null) {
        throw new RuntimeException('Cobranca nao encontrada.');
    }
    if ((string) $cobranca['situacao'] !== SHIELD_COB_PAGA) {
        throw new RuntimeException('So se estorna cobranca paga.');
    }
    if (trim((string) $motivo) === '') {
        throw new RuntimeException('Estorno sem motivo nao entra.');
    }

    $stmt = $pdo->prepare('UPDATE cobranca SET situacao = :sit WHERE id = :id AND situacao = :paga');
    $stmt->execute(array(':sit' => SHIELD_COB_ESTORNADA, ':id' => (int) $cobrancaId,
                         ':paga' => SHIELD_COB_PAGA));

    if ($stmt->rowCount() > 0) {
        // A validade e de outro assunto, e este arquivo nao tem requires
        // proprios (quem o carrega e o cobranca_motor.php).
        require_once __DIR__ . '/../licenca/validade.php';
        shield_validade_recolher($pdo, $cobranca, 'estorno: ' . $motivo);
        shield_saldo_desfazer($pdo, $cobranca, 'cobranca estornada');
    }

    shield_auditar($pdo, 'cobranca_estornada', array(
        'alvo_tipo' => 'cobranca', 'alvo_id' => (int) $cobrancaId,
        'antes' => SHIELD_COB_PAGA, 'depois' => SHIELD_COB_ESTORNADA,
        'detalhe' => (string) $motivo,
    ));

    return $stmt->rowCount() > 0;
}

function shield_cobranca_cancelar(PDO $pdo, $cobrancaId, $motivo = '')
{
    $cobranca = shield_cob_ler($pdo, $cobrancaId);
    if ($cobranca === null) {
        throw new RuntimeException('Cobranca nao encontrada.');
    }
    if (shield_cob_terminal($cobranca['situacao'])) {
        throw new RuntimeException('Esta cobranca ja esta ' . $cobranca['situacao'] . '.');
    }

    // Cancelar no painel TEM de cancelar no provedor, senao o cliente continua
    // recebendo lembrete de uma divida que o membro ja perdoou.
    //
    // E SE O PROVEDOR RECUSAR, NADA MUDA (11/09/2026). Ate aqui a recusa era
    // engolida: a cobranca ficava cancelada no painel e o codigo seguia vivo
    // no gateway. O cliente pagava um PIX que o painel ja tinha esquecido, e o
    // dinheiro entrava sem nunca ser creditado. E a mesma regra da reemissao.
    $tentativa = shield_cobranca_ultima_tentativa($pdo, $cobrancaId);
    if ($tentativa !== null && trim((string) $tentativa['id_externo']) !== '') {
        $conta = shield_cob_conta($pdo, (int) $tentativa['fk_conta']);
        $provedor = Registro::para((string) $tentativa['provedor']);
        if ($conta !== null && $provedor !== null && !$provedor->cancelar((string) $tentativa['id_externo'], $conta)) {
            throw new RuntimeException(
                'O provedor nao cancelou a cobranca (' . $tentativa['id_externo'] . '). Nada mudou no painel: '
                . 'o codigo que o cliente tem continua valendo, e cancelar so aqui esconderia um pagamento que ainda pode chegar.'
            );
        }
    }

    $stmt = $pdo->prepare('UPDATE cobranca SET situacao = :sit WHERE id = :id');
    $stmt->execute(array(':sit' => SHIELD_COB_CANCELADA, ':id' => (int) $cobrancaId));

    // O credito que ela consumiu ao nascer volta para o cliente.
    shield_saldo_desfazer($pdo, $cobranca, 'cobranca cancelada');

    shield_auditar($pdo, 'cobranca_cancelada', array(
        'alvo_tipo' => 'cobranca', 'alvo_id' => (int) $cobrancaId,
        'antes' => (string) $cobranca['situacao'], 'depois' => SHIELD_COB_CANCELADA,
        'detalhe' => (string) $motivo,
    ));

    return true;
}

/**
 * Passou do vencimento e continua aberta. E so um rotulo -- nao suspende nada,
 * nao avisa ninguem. A regua e a suspensao sao da fase seguinte.
 */
function shield_cobranca_marcar_vencidas(PDO $pdo)
{
    $stmt = $pdo->prepare(
        'UPDATE cobranca SET situacao = :venc
          WHERE situacao = :aberta AND vencimento < CURDATE()'
    );
    $stmt->execute(array(':venc' => SHIELD_COB_VENCIDA, ':aberta' => SHIELD_COB_ABERTA));

    return $stmt->rowCount();
}

// ------------------------------------------------------------------ ponte ---

/**
 * A ponte: cobranca paga estende a validade do cliente.
 *
 * UM LUGAR SO. Ela e chamada pelo caminho automatico e pelo manual, e a
 * idempotencia mora na tabela validade_movimento -- unicidade por cobranca.
 * Webhook chega, conciliacao chega logo atras, e sem isso o cliente ganharia um
 * mes de presente a cada verificacao.
 *
 * QUANTOS MESES sai da ASSINATURA quando ha uma, e da PROPRIA COBRANCA quando
 * nao ha (coluna `meses`, V4_0_5) -- nunca do valor pago nem do palpite.
 * Assinatura semestral estende seis; cobranca solta de um plano avulso de doze
 * meses estende doze; cobranca aberta sem dizer nada estende um. Deduzir o
 * ciclo pelo valor seria dar seis meses a quem pagou uma diferenca.
 *
 * Ate a 4.0.5 toda cobranca sem assinatura estendia UM mes, e a tela mostrava
 * "Plano de 12 meses". O cliente pagava os doze e ganhava um.
 *
 * NAO LEVANTA. Falhar em estender nao pode desfazer o pagamento -- o dinheiro
 * entrou. O que se faz e registrar alto, e o membro ajusta a validade a mao.
 */
function shield_cobranca_estendeu_validade(PDO $pdo, array $cobranca, $motivo)
{
    try {
        // A COTA QUE ESPERAVA O PAGAMENTO sobe aqui (fatia 8, "liberar so
        // quando pagar"): e o mesmo lugar onde o pagamento ja move a validade.
        require_once __DIR__ . '/../empresa/mudanca.php';
        shield_mudanca_liberar_se_pendente($pdo, $cobranca);

        // meses = 0 e a cobranca de AJUSTE do mes corrente: paga, nao move a
        // validade. Ate a fatia 8 todo avulso estendia pelo menos um mes, e
        // um ajuste de R$ 12,50 daria trinta dias de licenca.
        if (isset($cobranca['meses']) && (int) $cobranca['meses'] === 0 && empty($cobranca['fk_assinatura'])) {
            return null;
        }

        $meses = max(1, (int) ($cobranca['meses'] ?? 1));
        $ancora = '';
        if (!empty($cobranca['fk_assinatura'])) {
            // A FATURA MANDA (11/09/2026): ela carrega os meses do ciclo em que
            // foi aberta. Mudar o ciclo da assinatura depois nao reescreve o
            // que uma fatura ja na rua compra. A assinatura so e consultada
            // para fatura antiga, aberta antes de os meses viajarem nela
            // (a V4_2_0 alinha as que existiam).
            if ((int) ($cobranca['meses'] ?? 0) <= 0) {
                $stmt = $pdo->prepare('SELECT ciclo_meses FROM assinatura WHERE id = :id');
                $stmt->execute(array(':id' => (int) $cobranca['fk_assinatura']));
                $ciclo = $stmt->fetchColumn();
                if ($ciclo !== false) {
                    $meses = max(1, (int) $ciclo);
                }
            }
            // A mensalidade anda a partir do vencimento dela: a licenca passa
            // a valer ate o vencimento seguinte, que e o que a tela mostra.
            //
            // SO QUANDO NAO HA BURACO ATRAS (11/09/2026). Com tres mensalidades
            // em aberto, pagar a mais nova levava a validade para o vencimento
            // dela e ainda somava um ciclo: tres meses de licenca por um mes de
            // dinheiro, e as antigas ficavam abertas para sempre porque a loja
            // ja estava funcionando. Havendo fatura mais antiga em aberto, a
            // validade anda a partir dela mesma, um ciclo por pagamento.
            $ancora = substr((string) ($cobranca['vencimento'] ?? ''), 0, 10);
            try {
                $stmt = $pdo->prepare(
                    "SELECT COUNT(*) FROM cobranca
                      WHERE fk_empresa = :e AND fk_assinatura IS NOT NULL AND id <> :id
                        AND situacao IN ('aberta', 'vencida') AND vencimento < :venc"
                );
                $stmt->execute(array(':e' => (int) $cobranca['fk_empresa'], ':id' => (int) $cobranca['id'], ':venc' => $ancora));
                if ((int) $stmt->fetchColumn() > 0) {
                    $ancora = '';
                }
            } catch (Throwable $semTabela) {
            }
        }

        return shield_validade_estender($pdo, (int) $cobranca['fk_empresa'], $meses, array(
            'cobranca' => (int) $cobranca['id'],
            'motivo' => (string) $motivo,
            'ancora' => $ancora,
        ));
    } catch (Throwable $e) {
        shield_auditar($pdo, 'validade_nao_estendida', array(
            'alvo_tipo' => 'cobranca', 'alvo_id' => (int) $cobranca['id'],
            'detalhe' => 'O PAGAMENTO ENTROU E A VALIDADE NAO SE MOVEU: ' . $e->getMessage(),
        ));

        return null;
    }
}

/**
 * Troca o PIX (ou boleto, ou link) de uma cobranca ja emitida pelo de hoje --
 * 09/09/2026. E assim que multa e juros alcancam cobranca que ja
 * estava na rua quando venceu.
 *
 * O NUMERO QUE O CLIENTE TEM NA MAO E A VERDADE ate alguem troca-lo. Por isso
 * o valor da cobranca nao sobe sozinho no vencimento: o cliente pagaria o PIX
 * antigo, o pagamento chegaria menor e cairia em "parcial, validade NAO
 * estendida". Aqui a ordem e a que nao deixa dois PIX vivos:
 *
 *   1. cancela o antigo NO PROVEDOR; se ele nao cancelar, para aqui e nada
 *      muda -- dois PIX com valores diferentes e o pior dos mundos;
 *   2. emite de novo, pela mesma conta salvo pedido em contrario, e e a
 *      emissao que recalcula os encargos (ver shield_cobranca_emitir);
 *   3. devolve o rotulo "vencida" que a emissao tira: reemitir nao rejuvenesce
 *      a divida.
 *
 * Rascunho nao se reemite: nao ha o que cancelar. Use emitir.
 */
function shield_cobranca_reemitir(PDO $pdo, $cobrancaId, $contaId = 0)
{
    $cobranca = shield_cob_ler($pdo, $cobrancaId);
    if ($cobranca === null) {
        throw new RuntimeException('Cobranca nao encontrada.');
    }
    if (shield_cob_terminal($cobranca['situacao'])) {
        throw new RuntimeException('Esta cobranca ja esta ' . $cobranca['situacao'] . '.');
    }

    $tentativa = shield_cobranca_ultima_tentativa($pdo, $cobrancaId);
    if ($tentativa === null) {
        throw new RuntimeException('Esta cobranca nunca foi emitida: nao ha o que reemitir. Emita.');
    }

    if (trim((string) $tentativa['id_externo']) !== '') {
        $contaAntiga = shield_cob_conta($pdo, (int) $tentativa['fk_conta']);
        $provedor = Registro::para((string) $tentativa['provedor']);
        if ($contaAntiga === null || $provedor === null) {
            throw new RuntimeException(
                'A conta por onde esta cobranca foi emitida nao existe mais; nao da para cancelar o codigo antigo.'
            );
        }
        if (!$provedor->cancelar((string) $tentativa['id_externo'], $contaAntiga)) {
            throw new RuntimeException(
                'O provedor nao cancelou a cobranca antiga (' . $tentativa['id_externo']
                . '). Nada foi reemitido: o codigo que o cliente tem continua valendo.'
            );
        }
        // O CODIGO MORTO SAI DA LINHA, e nao so ganha um rotulo (11/09/2026).
        // O canal do ERP e a area do cliente leem a ultima tentativa sem olhar
        // a situacao: falhando a emissao nova logo abaixo, os dois passavam a
        // mostrar um copia-e-cola que o provedor ja tinha removido, ao lado do
        // valor novo -- exatamente o "codigo morto na mao do cliente" que a
        // regua promete que nao acontece. O `retorno` cru fica: e o rastro.
        $pdo->prepare(
            'UPDATE cobranca_tentativa
                SET situacao_provedor = :s, link_pagamento = NULL, copia_e_cola = NULL,
                    linha_digitavel = NULL
              WHERE id = :id'
        )->execute(array(':s' => SHIELD_COB_TENTATIVA_CANCELADA, ':id' => (int) $tentativa['id']));
    }

    $contaId = (int) $contaId > 0 ? (int) $contaId : (int) $tentativa['fk_conta'];
    $antes = (int) $cobranca['valor_centavos'];

    // A JANELA ENTRE CANCELAR E EMITIR FICA NO LIVRO (11/09/2026). Caindo a
    // rede dentro de criar(), o codigo antigo ja morreu e o novo nao nasceu: a
    // cobranca fica sem forma de ser paga ate alguem clicar em Emitir, e a
    // regua conta os dias de atraso de uma divida que o cliente nao consegue
    // quitar. Desfazer o cancelamento no provedor nao existe -- o que se pode
    // e deixar escrito o que houve, para quem for procurar.
    try {
        $resultado = shield_cobranca_emitir($pdo, $cobrancaId, $contaId);
    } catch (Throwable $naoEmitiu) {
        shield_auditar($pdo, 'cobranca_sem_codigo', array(
            'alvo_tipo' => 'cobranca', 'alvo_id' => (int) $cobrancaId,
            'detalhe' => 'o codigo antigo (' . (string) $tentativa['id_externo']
                . ') foi cancelado e a emissao nova falhou: ' . $naoEmitiu->getMessage()
                . ' -- a cobranca esta sem codigo ate alguem emitir de novo.',
        ));

        throw $naoEmitiu;
    }

    // A emissao aplica o que o provedor respondeu ("aberta"), e isso apaga o
    // rotulo "vencida" de uma cobranca que continua vencida.
    $pdo->prepare(
        'UPDATE cobranca SET situacao = :venc
          WHERE id = :id AND situacao = :aberta AND vencimento < CURDATE()'
    )->execute(array(':venc' => SHIELD_COB_VENCIDA, ':id' => (int) $cobrancaId, ':aberta' => SHIELD_COB_ABERTA));

    $depois = (int) (shield_cob_ler($pdo, $cobrancaId)['valor_centavos'] ?? $antes);
    shield_auditar($pdo, 'cobranca_reemitida', array(
        'alvo_tipo' => 'cobranca', 'alvo_id' => (int) $cobrancaId,
        'antes' => (string) $antes, 'depois' => (string) $depois,
        'detalhe' => 'reemitida: de R$ ' . shield_dinheiro($antes) . ' para R$ ' . shield_dinheiro($depois)
            . ' (codigo antigo ' . (string) $tentativa['id_externo'] . ' cancelado)',
    ));

    return $resultado;
}
