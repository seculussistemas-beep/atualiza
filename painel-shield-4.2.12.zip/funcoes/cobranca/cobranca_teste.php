<?php
/**
 * "Esta credencial funciona?" - 25/08/2026.
 *
 * Sem isto, o membro cola a chave, grava, e so descobre se acertou quando uma
 * cobranca falha -- com o cliente do outro lado esperando o PIX. A distancia
 * entre configurar e descobrir que configurou errado era de dias.
 *
 * COMO SE TESTA SEM CRIAR NADA: pergunta-se ao provedor por uma cobranca que
 * nao existe. A resposta separa os tres casos que importam:
 *
 *   nao autorizado  -> a credencial esta errada ou e de outro ambiente
 *   nao encontrado  -> a credencial esta CERTA (ele deixou perguntar)
 *   nao respondeu   -> rede, DNS, firewall -- nao e problema de chave
 *
 * Criar uma cobranca de um centavo para testar seria mais direto e e o que
 * muita gente faz. Nao aqui: cobranca de teste em conta de PRODUCAO aparece no
 * extrato do membro, pode disparar aviso ao cliente errado e alguem tem de
 * cancelar depois. Um 404 nao deixa rastro.
 */

require_once __DIR__ . '/cobranca.php';
require_once __DIR__ . '/cobranca_credenciais.php';
require_once __DIR__ . '/../nucleo/autoload.php';

use Shield\Cobranca\Registro;

if (!function_exists('shield_conta_testar')) {
    /**
     * @return array{ok:bool,titulo:string,detalhe:string}
     */
    function shield_conta_testar(array $conta)
    {
        $provedor = (string) ($conta['provedor'] ?? '');
        $adaptador = Registro::para($provedor);

        if ($adaptador === null) {
            return array('ok' => false, 'titulo' => 'Sem adaptador',
                         'detalhe' => 'O provedor ' . $provedor . ' ainda nao tem adaptador neste painel.');
        }

        $credenciais = shield_cobranca_credenciais($conta);
        $faltam = shield_cred_faltando($provedor, $credenciais);
        if ($faltam) {
            // Nem chega a ir na rede: falta dado, e dizer QUAL poupa a ida.
            return array('ok' => false, 'titulo' => 'Falta preencher',
                         'detalhe' => implode(', ', $faltam));
        }

        $capacidades = $adaptador->capacidades($conta);
        if (empty($capacidades['automatico'])) {
            return array('ok' => true, 'titulo' => 'Nao ha o que testar',
                         'detalhe' => 'Esta forma nao fala com provedor nenhum: '
                             . 'voce ve o dinheiro no seu banco e confirma na tela de cobrancas.');
        }

        $conta['_credenciais'] = $credenciais;

        // QUEM SABE SE TESTAR, TESTA (17/09/2026). A pergunta por uma cobranca
        // inventada, abaixo, le o 404 como "conectou" -- e a Cora responde 400 a
        // id fora do padrao dela, entao a credencial certa apareceria como
        // recusada. O adaptador com teste proprio devolve a frase, e a falha dele
        // e a frase dele, sem a leitura de 404.
        if (method_exists($adaptador, 'testarConexao')) {
            try {
                return array('ok' => true, 'titulo' => 'Conectou', 'detalhe' => (string) $adaptador->testarConexao($conta));
            } catch (Throwable $e) {
                $m = $e->getMessage();

                return array('ok' => false,
                             'titulo' => preg_match('/\b(401|403)\b/', $m) ? 'Credencial recusada' : 'O provedor recusou',
                             'detalhe' => $m);
            }
        }

        try {
            // Um id que nao existe em provedor nenhum. Se ele responder
            // qualquer coisa que nao seja "nao autorizado", a chave passou.
            //
            // O MERCADO PAGO E A EXCECAO: /v1/payments/{id} devolve 404 ANTES
            // de olhar o token, entao chave errada passava como "conectou".
            // Nele o teste bate numa rota que exige o token (a busca), que
            // responde 401 com chave errada e 200 com chave certa -- sem criar
            // nada tambem. (04/09/2026)
            if ($provedor === 'mercadopago') {
                $r = \Shield\Cobranca\Http::json('GET',
                    'https://api.mercadopago.com/v1/payments/search?limit=1',
                    array('Authorization: Bearer ' . (string) ($credenciais['access_token'] ?? ''),
                          'Accept: application/json'));
                if ($r['erro'] !== '') {
                    throw new RuntimeException($r['erro']);
                }
                if ($r['codigo'] >= 400) {
                    throw new RuntimeException('Mercado Pago recusou (HTTP ' . $r['codigo'] . '): '
                        . (string) ($r['json']['message'] ?? ''));
                }

                return array('ok' => true, 'titulo' => 'Conectou',
                             'detalhe' => 'O Mercado Pago aceitou a credencial e respondeu.');
            }

            $adaptador->consultar('shield-teste-inexistente-0', $conta);

            return array('ok' => true, 'titulo' => 'Conectou',
                         'detalhe' => 'O provedor aceitou a credencial e respondeu.');
        } catch (Throwable $e) {
            $m = $e->getMessage();

            if (preg_match('/\b(401|403)\b/', $m)
                || stripos($m, 'unauthorized') !== false
                || stripos($m, 'nao autorizado') !== false
                || stripos($m, 'invalid') !== false && stripos($m, 'token') !== false) {
                return array('ok' => false, 'titulo' => 'Credencial recusada',
                             'detalhe' => 'O provedor nao aceitou a chave. Confira se ela e do '
                                 . 'ambiente certo (' . ($conta['ambiente'] ?? 'producao') . '). '
                                 . $m);
            }

            if (preg_match('/\b404\b/', $m)
                || stripos($m, 'not found') !== false
                || stripos($m, 'nao encontrad') !== false) {
                // O QUE SE PROCURA: ele deixou perguntar e disse que nao achou.
                return array('ok' => true, 'titulo' => 'Conectou',
                             'detalhe' => 'A credencial funciona -- o provedor respondeu que a '
                                 . 'cobranca de teste nao existe, que e a resposta certa.');
            }

            if (stripos($m, 'nao consegui falar') !== false
                || stripos($m, 'timeout') !== false
                || stripos($m, 'could not resolve') !== false) {
                return array('ok' => false, 'titulo' => 'Nao alcancei o provedor',
                             'detalhe' => 'Nao e problema de chave: rede, DNS ou firewall. ' . $m);
            }

            // Erro que nao se encaixa: mostra o que o provedor disse, cru. A
            // frase dele e sempre mais util que uma nossa generica.
            return array('ok' => false, 'titulo' => 'O provedor recusou', 'detalhe' => $m);
        }
    }
}
