<?php

// A lista da tela de Cobrancas -- 14/09/2026.
//
// Saiu de modules/cobranca/cobrancas.php por causa da busca, que so se prova
// fora da tela. A consulta montava `cnpj LIKE '%<digitos da busca>%'` SEMPRE,
// e busca sem digito nenhum vira `LIKE '%%'`, que casa com todo CNPJ: buscar
// "padaria" devolvia as cobrancas do painel inteiro e parecia que a busca nao
// fazia nada. (Conferido no banco de desenvolvimento com um texto que nao
// existe: voltaram todas as linhas.)

require_once __DIR__ . '/cobranca_motor.php';

/** Quantas cobrancas a tela desenha. Busca-se uma a mais so para saber se cortou. */
const SHIELD_COB_LISTA_LIMITE = 200;

/**
 * Os digitos da busca quando ela tem CARA DE DOCUMENTO; '' quando nao tem.
 *
 * Cara de documento e so digito e a pontuacao de CNPJ/CPF, com pelo menos tres
 * digitos. Arrancar os digitos de qualquer texto fazia "Treinamento 2" procurar
 * CNPJ com um 2 dentro (quase todos), e "LTDA", sem digito, procurar '%%'.
 */
function shield_cobranca_busca_documento($busca)
{
    $busca = trim((string) $busca);
    if ($busca === '' || !preg_match('/^[\d.\/\-\s]+$/', $busca)) {
        return '';
    }
    $digitos = (string) preg_replace('/\D+/', '', $busca);

    return strlen($digitos) >= 3 ? $digitos : '';
}

/**
 * As cobrancas da tela, com a ultima tentativa de cada uma.
 *
 * $filtro: 'situacao' ('todas', 'abertas' ou uma situacao), 'empresa' (int ou
 * null) e 'q' (razao, descricao, e o CNPJ quando a busca tem cara de CNPJ).
 *
 * `cortada` diz que havia mais que $limite: agrupada por cliente, a lista sem
 * esse aviso mostraria parte das faturas de alguem como se fossem todas.
 *
 * @return array{linhas: array, cortada: bool}
 */
function shield_cobranca_lista(PDO $pdo, array $filtro, $limite = SHIELD_COB_LISTA_LIMITE)
{
    $limite = max(1, (int) $limite);
    $condicoes = array();
    $params = array();

    $situacao = (string) ($filtro['situacao'] ?? 'todas');
    if ($situacao === 'abertas') {
        $condicoes[] = 'c.situacao IN (:a, :v, :r)';
        $params = array(':a' => SHIELD_COB_ABERTA, ':v' => SHIELD_COB_VENCIDA, ':r' => SHIELD_COB_RASCUNHO);
    } elseif ($situacao === 'prazo') {
        // Quem pediu prazo e espera resposta (01/10/2026). O mesmo recorte do
        // badge da lateral: shield_cobranca_onde_pede_prazo.
        $condicoes[] = shield_cobranca_onde_pede_prazo('c');
    } elseif ($situacao === 'todas') {
        // "TODAS" NAO MOSTRA A CANCELADA (01/10/2026, decisao do Victor). Um membro
        // pediu para a cobranca feita por engano parar de "poluir a listagem" -- e
        // a tela abre em Todas. O registro continua no banco e no livro de
        // auditoria; ele mora no filtro proprio, `cancelada`, pelo ramo abaixo.
        // A estornada fica: ela foi paga, e o que aconteceu com o dinheiro importa.
        $condicoes[] = 'c.situacao <> :canc';
        $params[':canc'] = SHIELD_COB_CANCELADA;
    } else {
        $condicoes[] = 'c.situacao = :s';
        $params[':s'] = $situacao;
    }

    $empresa = (int) ($filtro['empresa'] ?? 0);
    if ($empresa > 0) {
        $condicoes[] = 'c.fk_empresa = :empresa';
        $params[':empresa'] = $empresa;
    }

    $busca = substr(trim((string) ($filtro['q'] ?? '')), 0, 255);
    if ($busca !== '') {
        $partes = array('e.razao LIKE :q', 'c.descricao LIKE :q2');
        $params[':q'] = '%' . $busca . '%';
        $params[':q2'] = '%' . $busca . '%';

        $documento = shield_cobranca_busca_documento($busca);
        if ($documento !== '') {
            // O CNPJ pode estar gravado com pontuacao (a API de licenca e a
            // edicao do cadastro ja comparam assim): tira dos dois lados. Aspas
            // simples, e nao duplas: com ANSI_QUOTES "." vira nome de coluna.
            $partes[] = "REPLACE(REPLACE(REPLACE(REPLACE(e.cnpj, '.', ''), '/', ''), '-', ''), ' ', '') LIKE :qd";
            $params[':qd'] = '%' . $documento . '%';
        }
        $condicoes[] = '(' . implode(' OR ', $partes) . ')';
    }
    $onde = $condicoes ? ' WHERE ' . implode(' AND ', $condicoes) : '';

    $stmt = $pdo->prepare(
        /* A ULTIMA TENTATIVA VEM INTEIRA, e nao so o link: com cinco gateways,
           saber que a cobranca esta paga sem saber POR ONDE nao concilia nada. O
           LEFT JOIN sai por subconsulta unica em vez de cinco escalares -- eram
           cinco varreduras da mesma tabela por linha. */
        'SELECT c.*, e.razao, e.cnpj,
                t.provedor, t.id_externo, t.link_pagamento AS link, t.copia_e_cola AS copia,
                t.linha_digitavel AS linha,
                t.situacao_provedor, t.metodo AS metodo_emitido, t.fk_conta,
                co.apelido AS conta_apelido
           FROM cobranca c
           LEFT JOIN empresa e ON e.codigo = c.fk_empresa
           LEFT JOIN cobranca_tentativa t
                  ON t.id = (SELECT x.id FROM cobranca_tentativa x
                              WHERE x.fk_cobranca = c.id ORDER BY x.id DESC LIMIT 1)
           LEFT JOIN conta_recebimento co ON co.id = t.fk_conta'
        . $onde . ' ORDER BY c.vencimento DESC, c.id DESC LIMIT ' . ($limite + 1)
    );
    $stmt->execute($params);
    $linhas = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();

    $cortada = count($linhas) > $limite;
    if ($cortada) {
        array_pop($linhas);
    }

    return array('linhas' => $linhas, 'cortada' => $cortada);
}

/**
 * As linhas agrupadas por cliente, na ordem de quem pede acao -- 14/09/2026.
 *
 * Primeiro quem tem valor vencido, depois quem tem valor a vencer, depois o
 * resto; dentro de cada faixa, pelo nome. O grupo vem FECHADO na tela, entao
 * a ordem e o cabecalho sao tudo o que o membro le antes de abrir.
 *
 * O dinheiro e as quantidades ($resumo, de shield_cobranca_resumo_por_empresa)
 * vem do banco e nao das linhas: a lista para em SHIELD_COB_LISTA_LIMITE, e a fatura vencida
 * mais antiga e justamente a que cai fora do corte. O que sai das linhas
 * (a emitir, em aberto na lista, avisou) e so o que o grupo ABERTO mostra.
 *
 * Pura, sem banco, e mantem a ordem das linhas dentro de cada grupo.
 */
function shield_cobranca_grupos(array $linhas, array $resumo)
{
    $grupos = array();
    foreach ($linhas as $c) {
        $codigo = (int) ($c['fk_empresa'] ?? 0);
        if (!isset($grupos[$codigo])) {
            $razao = trim((string) ($c['razao'] ?? ''));
            $grupos[$codigo] = array(
                'razao' => $razao !== '' ? $razao : 'Cliente removido',
                'cnpj' => (string) ($c['cnpj'] ?? ''),
                'aberto' => (int) ($resumo[$codigo]['aberto'] ?? 0),
                'vencido' => (int) ($resumo[$codigo]['vencido'] ?? 0),
                // QUANTAS, alem de quanto (14/09/2026): o cabecalho diz "2 vencidas" e "em
                // dia" de relance, e contar pelas linhas erraria no corte da lista.
                'qtd_aberto' => (int) ($resumo[$codigo]['qtd_aberto'] ?? 0),
                'qtd_vencido' => (int) ($resumo[$codigo]['qtd_vencido'] ?? 0),
                'rascunhos' => 0,
                'em_aberto_na_lista' => 0,
                'avisou' => false,
                'linhas' => array(),
            );
        }

        $sit = (string) ($c['situacao'] ?? '');
        if ($sit === SHIELD_COB_RASCUNHO) {
            $grupos[$codigo]['rascunhos']++;
        }
        // A promessa de prazo so tem onde ser respondida numa linha aberta ou
        // vencida (4.1.12): o cabecalho so a anuncia quando essa linha existe.
        if ($sit === SHIELD_COB_ABERTA || $sit === SHIELD_COB_VENCIDA) {
            $grupos[$codigo]['em_aberto_na_lista']++;
        }
        if (!shield_cob_terminal($sit) && !empty($c['informado_em'])) {
            $grupos[$codigo]['avisou'] = true;
        }
        $grupos[$codigo]['linhas'][] = $c;
    }

    uasort($grupos, static function (array $a, array $b) {
        $faixaA = $a['vencido'] > 0 ? 0 : ($a['aberto'] > 0 ? 1 : 2);
        $faixaB = $b['vencido'] > 0 ? 0 : ($b['aberto'] > 0 ? 1 : 2);

        return ($faixaA <=> $faixaB) ?: strcasecmp($a['razao'], $b['razao']);
    });

    return $grupos;
}
