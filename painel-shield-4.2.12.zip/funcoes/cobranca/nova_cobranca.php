<?php

// A Nova cobranca da tela de Cobrancas -- 14/09/2026.
//
// Saiu de modules/cobranca/cobrancas.php para a regra de "Cobrar por" poder ser
// provada fora da tela: a suite nao tem POST logado (tests/Apoio/CasoHttp.php so
// tem getHttp e postJson), e o defeito que trouxe a funcao para ca so aparece
// quando o pagamento entra, muito depois do clique.

require_once __DIR__ . '/cobranca_motor.php';
require_once __DIR__ . '/../planos/ciclo.php';   // SHIELD_PLANO_PREPAGO_MAX_MESES, o teto do personalizado

/**
 * Os planos que "Cobrar por" oferece: pre-pago (tipo avulso) e ativo.
 *
 * Um filtro so para a lista da tela e para o POST. Escrito duas vezes, a lista
 * mostrava so pre-pago ativo e o POST aceitava qualquer id, e um plano de
 * assinatura ou desligado mandado a mao gravava os meses dele.
 */
const SHIELD_PLANO_PREPAGO_ATIVO_SQL = "(status IS NULL OR TRIM(status) IN ('', 'ativo')) AND tipo = 'avulso'";

/**
 * O que o POST de "abrir" da Nova cobranca manda a shield_cobranca_abrir.
 *
 * AVULSA NAO COMPRA MES; SO O PLANO COMPRA -- 14/09/2026, regra do dono.
 * Instalacao, backup, treinamento: pagos, nao movem a validade. A tela mandava
 * meses = 1 para a avulsa sem ninguem pedir (o padrao do motor e 1, e o motor
 * esta certo em nao mudar: CobrancaMotorTest segura isso), e a instalacao de
 * R$ 50 paga junto com a mensalidade levou a licenca de 15/10 a 15/11. Vender
 * meses e o plano pre-pago em "Cobrar por", ou Mudar o contrato.
 *
 * Qualquer outra origem e recusada: o que chega aqui e a avulsa, um plano ou o
 * periodo personalizado (17/09/2026), que compra os meses digitados.
 */
function shield_cobranca_dados_da_origem(PDO $pdo, array $post)
{
    $origem = trim((string) ($post['origem'] ?? 'avulsa'));

    // "assinatura_plano:" SAIU DA TELA -- 10/09/2026, fatia 7 da reorganizacao.
    // A assinatura nasce no FECHAMENTO, o unico lugar que sabe o contrato
    // inteiro. Um link antigo que ainda mande isso cai aqui em vez de criar
    // assinatura por fora.
    if (strpos($origem, 'assinatura_plano:') === 0) {
        throw new RuntimeException('Assinatura nova nasce em Dar inicio ao contrato (Em avaliacao), nao aqui.');
    }

    $descricao = trim((string) ($post['descricao'] ?? ''));
    $dados = array(
        'empresa' => (int) ($post['empresa'] ?? 0),
        // NUNCA A ASSINATURA DO POST. Com fk_assinatura o motor troca o valor
        // digitado pelo da assinatura, e a ponte do pagamento recua ao ciclo dela
        // e estende a validade mesmo com nao_estende. A mensalidade nasce pelo
        // ciclo; o campo oculto da tela sobrou da opcao que saiu em 10/09/2026.
        'assinatura' => null,
        'competencia' => date('Y-m-01'),
        'descricao' => $descricao,
        'valor_centavos' => shield_centavos((string) ($post['valor'] ?? '')),
        'vencimento' => (string) ($post['vencimento'] ?? date('Y-m-d')),
        // A MESMA expressao que a tela confere contra a conta antes de abrir:
        // lida com outro padrao, a conferencia e a gravacao discordariam.
        'forma' => (string) ($post['forma'] ?? 'pix'),
        // O F5 da tela reenvia o mesmo corpo (nao ha POST-redirect-GET), e sem a
        // chave cada reenvio abria outra cobranca igual. Ver shield_cobranca_abrir.
        'chave' => (string) ($post['chave'] ?? ''),
    );

    if ($origem === 'avulsa') {
        $dados['nao_estende'] = true;
        // "Mensalidade" era o nome padrao, e a instalacao chegava assim ao ERP e a
        // area do cliente, ao lado da mensalidade de verdade.
        if ($dados['descricao'] === '') {
            $dados['descricao'] = 'Cobranca avulsa';
        }

        return $dados;
    }

    // PERIODO PERSONALIZADO -- 17/09/2026, pedido de membro. O negocio fechado
    // fora da tabela de planos: meses e valor digitados na hora, sem cadastrar
    // plano. Compra os meses como o plano, e por isso vem de uma escolha propria
    // em "Cobrar por", com os meses num campo que so ela liga: a avulsa continua
    // sem comprar nada.
    if ($origem === 'personalizado') {
        $meses = trim((string) ($post['meses'] ?? ''));
        if (!ctype_digit($meses) || (int) $meses < 1 || (int) $meses > SHIELD_PLANO_PREPAGO_MAX_MESES) {
            throw new RuntimeException('No periodo personalizado, informe de 1 a ' . SHIELD_PLANO_PREPAGO_MAX_MESES . ' meses de licenca.');
        }
        if ($dados['valor_centavos'] <= 0) {
            throw new RuntimeException('Informe o valor do periodo personalizado.');
        }
        $dados['meses'] = (int) $meses;
        if ($dados['descricao'] === '') {
            $dados['descricao'] = 'Periodo de ' . $dados['meses'] . ($dados['meses'] === 1 ? ' mes' : ' meses');
        }

        return $dados;
    }

    if (strpos($origem, 'plano:') !== 0) {
        throw new RuntimeException('Escolha em "Cobrar por" a cobranca avulsa, um plano ou o periodo personalizado.');
    }

    // O PLANO VEM DO CADASTRO, com o filtro da lista. O valor tambem e o do
    // cadastro, e nao o do campo: ninguem apaga um zero e cobra menos do que o
    // plano custa.
    $stmt = $pdo->prepare(
        'SELECT valor, recorrencia, descricao FROM planos WHERE id = :id AND ' . SHIELD_PLANO_PREPAGO_ATIVO_SQL . ' LIMIT 1'
    );
    $stmt->execute(array(':id' => (int) substr($origem, 6)));
    $plano = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$plano) {
        throw new RuntimeException('O plano escolhido nao existe mais ou nao e um pre-pago ativo. Escolha outro em "Cobrar por".');
    }
    $dados['valor_centavos'] = shield_centavos((string) $plano['valor']);
    $dados['meses'] = max(1, (int) $plano['recorrencia']);
    if ($dados['descricao'] === '') {
        $nome = trim((string) ($plano['descricao'] ?? ''));
        $dados['descricao'] = $nome !== '' ? $nome : 'Plano de ' . $dados['meses'] . ($dados['meses'] == 1 ? ' mes' : ' meses');
    }

    return $dados;
}

/**
 * O POST de "abrir" da Nova cobranca, inteiro -- 14/09/2026.
 *
 * Saiu da tela pelo mesmo motivo de shield_cobranca_dados_da_origem: a ordem das
 * conferencias so se prova fora dela (CobrancaNovaTest). Devolve
 * ['cobranca' => id, 'repetido' => bool, 'emitida' => bool, 'dinheiro' => bool];
 * as frases ficam na tela, com o tempo de cada uma.
 *
 * A CONTA E CONFERIDA ANTES DE ABRIR: a forma no "Cobra por" dela e a conta pronta
 * (o PIX na chave precisa da chave). Recusar depois deixava a cobranca em rascunho
 * com o credito do cliente ja consumido, por um erro de escolha. Conta 0 e
 * rascunho: ali a forma e so um rotulo.
 *
 * DINHEIRO EM ESPECIE COBRA AQUI TAMBEM (14/09/2026, o dono: "nao consigo gerar
 * fatura avulsa em dinheiro"). A conta de dinheiro nao gera codigo, e por isso saia
 * de "quem gera"; mas emitir nela e o que faz a cobranca nascer ABERTA, a receber e
 * contando no que o cliente deve, e nao rascunho "aguardando a fatura ser gerada".
 * A baixa e o Confirmar da lista, quando o dinheiro entra.
 */
function shield_cobranca_nova_abrir(PDO $pdo, array $post)
{
    $dados = shield_cobranca_dados_da_origem($pdo, $post);

    $contaId = (int) ($post['conta'] ?? 0);
    $conta = null;
    if ($contaId > 0) {
        $conta = shield_cob_conta($pdo, $contaId);
        if ($conta === null) {
            throw new RuntimeException('A conta de recebimento escolhida nao existe mais. Escolha outra.');
        }
        // A forma conferida e a que sera GRAVADA, e nao a do POST lida de novo com
        // outro padrao: as duas discordando, a conta de dinheiro passaria na
        // conferencia e a cobranca nasceria PIX.
        $recusa = shield_conta_forma_recusa($conta, (string) $dados['forma']);
        if ($recusa === null) {
            $recusa = shield_conta_pronta_recusa($conta);
        }
        if ($recusa !== null) {
            throw new RuntimeException($recusa);
        }
    }

    // F5 NAO EMITE DE NOVO. A tela nao tem POST-redirect-GET: o reenvio traz a mesma
    // chave e o motor devolve a cobranca que ela ja abriu -- e emitir por cima do
    // codigo vivo seria recusado, com frase de erro para quem so recarregou.
    // Perguntado ANTES de abrir: depois, a chave ja existe.
    $jaAberta = shield_cobranca_por_chave($pdo, (string) $dados['chave']);
    $id = shield_cobranca_abrir($pdo, $dados);
    $r = array(
        'cobranca' => $id,
        'repetido' => $jaAberta !== null,
        'emitida' => false,
        'dinheiro' => $conta !== null && (string) $conta['provedor'] === 'dinheiro',
    );
    if ($jaAberta === null && $conta !== null) {
        shield_cobranca_emitir($pdo, $id, $contaId);
        $r['emitida'] = true;
    }

    return $r;
}
