<?php
/**
 * O QUE CADA PROVEDOR PEDE, dito em um lugar so. 25/08/2026.
 *
 * Antes esta informacao vivia em tres lugares que ja discordavam: um `$campos`
 * dentro da tela (que so conhecia asaas, pix_estatico e dinheiro), um mapa de
 * conversao do legado dentro do `cobranca.php` (que conhecia todos, com outros
 * nomes) e o que cada adaptador de fato lia do array de credenciais. O efeito
 * pratico: a tela nao pedia a credencial do Mercado Pago, entao a conta ficava
 * cadastrada e sem como funcionar -- e o membro lia "sem adaptador ainda"
 * quando o problema era que ninguem tinha perguntado a chave dele.
 *
 * O ROTULO E O QUE O MEMBRO LE NO PORTAL DO GATEWAY, e nao o nome do campo no
 * JSON. Quem esta configurando tem a tela do provedor aberta ao lado; se o
 * painel chamar de "client_secret" o que la se chama "Chave secreta", ele
 * procura por dez minutos.
 *
 * `segredo` decide o tipo do campo e o mascaramento na tela; `ajuda` e o
 * caminho ate a credencial dentro do portal -- e o que economiza a busca.
 */

if (!function_exists('shield_cred_catalogo')) {
    function shield_cred_catalogo()
    {
        return array(
            'asaas' => array(
                'access_token' => array(
                    'rotulo' => 'Chave de API',
                    'segredo' => true,
                    'ajuda' => 'No Asaas: menu do perfil > Integracoes > Gerar chave de API.',
                ),
                'wallet_id' => array(
                    'rotulo' => 'Wallet ID (opcional)',
                    'segredo' => false,
                    'ajuda' => 'So se voce recebe por split. Em branco, o dinheiro cai na conta principal.',
                ),
            ),
            'efi' => array(
                'efi_client_id' => array(
                    'rotulo' => 'Client_Id',
                    'segredo' => false,
                    'ajuda' => 'Na Efi: API > Aplicacoes > a sua aplicacao.',
                ),
                'efi_client_secret' => array(
                    'rotulo' => 'Client_Secret',
                    'segredo' => true,
                    'ajuda' => 'Na mesma tela do Client_Id.',
                ),
                'efi_certificado' => array(
                    'rotulo' => 'Certificado .p12 em base64',
                    'segredo' => true,
                    'ajuda' => 'A Efi EXIGE certificado no PIX. Baixe o .p12 em API > Meus certificados e cole aqui o conteudo em base64.',
                ),
                'efi_chave_pix' => array(
                    'rotulo' => 'Chave PIX que recebe',
                    'segredo' => false,
                    'ajuda' => 'A chave cadastrada na propria Efi. Sem ela o PIX nao tem para onde ir.',
                ),
            ),
            'pagarme' => array(
                'pagarme_secret_key' => array(
                    'rotulo' => 'Secret Key',
                    'segredo' => true,
                    'ajuda' => 'No Pagar.me (Stone): Configuracoes > Chaves > chave secreta, a que comeca com sk_.',
                ),
            ),
            'mercadopago' => array(
                'access_token' => array(
                    'rotulo' => 'Access Token',
                    'segredo' => true,
                    // O caminho e o nome da tela sao os do portal, palavra por palavra:
                    // e assim que o membro acha sem adivinhar (11/09/2026).
                    'ajuda' => 'No Mercado Pago: Suas integracoes > a sua aplicacao > Credenciais de producao'
                        . ' (ou Credenciais de teste, para experimentar).',
                ),
                'public_key' => array(
                    'rotulo' => 'Public Key (opcional)',
                    'segredo' => false,
                    // O painel NAO usa (conferido em 11/09/2026): o cartao aqui e um
                    // link de checkout hospedado, e quem digita o numero e o Mercado
                    // Pago. O campo fica porque guardar nao custa e o dia em que
                    // houver cartao dentro do painel ela sera pedida; a ajuda diz a
                    // verdade para ninguem procurar o que nao precisa.
                    'ajuda' => 'Na mesma tela do Access Token. O painel nao usa hoje -- o cartao aqui e um'
                        . ' link do proprio Mercado Pago, e quem digita o numero e ele. Pode deixar em branco.',
                ),
            ),
            'pagbank' => array(
                'pagbank_token' => array(
                    'rotulo' => 'Token de API',
                    'segredo' => true,
                    'ajuda' => 'No PagBank: Venda online > Integracoes > Gerar token.',
                ),
            ),
            // A CORA E INTEGRACAO DIRETA (17/09/2026): Client ID mais o par de
            // certificado que ela entrega em Conta > Integracoes via APIs, um por
            // ambiente, e o token o painel pede sozinho. O "token de acesso" que
            // morava aqui a Cora nao entrega a quem integra a propria conta. O
            // par entra por upload, como no Inter e no C6.
            'cora' => array(
                'cora_client_id' => array(
                    'rotulo' => 'Client ID',
                    'segredo' => false,
                    'ajuda' => 'No app ou no site da Cora: Conta > Integracoes via APIs > Integracao Direta.'
                        . ' Producao e Stage tem cada um o seu Client ID e o seu certificado.',
                ),
                'cora_certificado_crt' => array(
                    'rotulo' => 'Certificado (certificate.pem)',
                    'segredo' => true,
                    'ajuda' => 'Mande o certificate.pem e o private-key.key nos campos de arquivo abaixo;'
                        . ' o painel confere o par e guarda os dois.',
                ),
                'cora_certificado_key' => array(
                    'rotulo' => 'Chave privada (private-key.key)',
                    'segredo' => true,
                    'ajuda' => 'Vai junto com o certificado, pelo campo de arquivo.',
                ),
            ),
            // INTER, C6 E INFINITEPAY (16/09/2026). O certificado do Inter e do
            // C6 NAO se cola: a tela recebe o .crt e o .key por upload e grava
            // no formato que o adaptador le (funcoes/cobranca/certificado_cliente.php).
            // Os campos do certificado ficam no catalogo porque e por ele que a
            // tela diz "falta X" e o teste de conexao recusa antes da rede.
            'inter' => array(
                'inter_client_id' => array(
                    'rotulo' => 'Client ID',
                    'segredo' => false,
                    'ajuda' => 'No Internet Banking do Inter (PJ): Aplicacoes > a sua aplicacao. Ela precisa dos escopos de'
                        . ' cobranca (boleto-cobranca.read/write) e de PIX (cob.read/write, pix.read).',
                ),
                'inter_client_secret' => array(
                    'rotulo' => 'Client Secret',
                    'segredo' => true,
                    'ajuda' => 'Na mesma tela do Client ID.',
                ),
                'inter_certificado' => array(
                    'rotulo' => 'Certificado (.crt + .key)',
                    'segredo' => true,
                    'ajuda' => 'O Inter EXIGE certificado em toda chamada. Mande os dois arquivos que o Inter entregou'
                        . ' ao criar a aplicacao, nos campos de arquivo abaixo; o painel confere o par e guarda.'
                        . ' Colar aqui tambem serve: o .p12 em base64.',
                ),
                'inter_certificado_senha' => array(
                    'rotulo' => 'Senha do certificado (opcional)',
                    'segredo' => true,
                    'ajuda' => 'So se voce colou um .p12 com senha. O par enviado por arquivo nao tem senha.',
                ),
                'inter_chave_pix' => array(
                    'rotulo' => 'Chave PIX que recebe',
                    'segredo' => false,
                    'ajuda' => 'A chave cadastrada na conta do Inter. Sem ela o PIX nao tem para onde ir; o boleto nao a usa.',
                ),
                'inter_dias_apos_vencimento' => array(
                    'rotulo' => 'Dias para pagar depois do vencimento (opcional)',
                    'segredo' => false,
                    'ajuda' => 'Quantos dias o boleto e o PIX ainda aceitam pagamento depois de vencer. Vazio vale 30;'
                        . ' o Inter aceita ate 60; 0 faz expirar no proprio vencimento. Multa e juros da Regua de'
                        . ' cobranca vao no boleto e sao cobrados pelo Inter no atraso.',
                ),
            ),
            'c6bank' => array(
                'c6_client_id' => array(
                    'rotulo' => 'Client ID',
                    'segredo' => false,
                    'ajuda' => 'No portal de desenvolvedores do C6 (BaaS): a credencial da sua integracao.',
                ),
                'c6_client_secret' => array(
                    'rotulo' => 'Client Secret',
                    'segredo' => true,
                    'ajuda' => 'Na mesma tela do Client ID.',
                ),
                'c6_certificado_crt' => array(
                    'rotulo' => 'Certificado (.crt)',
                    'segredo' => true,
                    'ajuda' => 'Mande o .crt e o .key nos campos de arquivo abaixo; o painel confere o par e guarda os dois.',
                ),
                'c6_certificado_key' => array(
                    'rotulo' => 'Chave privada (.key)',
                    'segredo' => true,
                    'ajuda' => 'Vai junto com o .crt, pelo campo de arquivo.',
                ),
                'c6_chave_pix' => array(
                    'rotulo' => 'Chave PIX aleatoria (EVP)',
                    'segredo' => false,
                    'ajuda' => 'A chave aleatoria da conta C6: o BolePix so aceita esse tipo. O QR do boleto aponta para ela.',
                ),
            ),
            'infinitepay' => array(
                'infinitepay_handle' => array(
                    'rotulo' => 'InfiniteTag',
                    'segredo' => false,
                    'ajuda' => 'O seu identificador na InfinitePay (o que vem depois do $ no link de pagamento).'
                        . ' Nao ha chave de API: o link nasce so com ele.',
                ),
            ),
            // CONTA AZUL (16/09/2026): so o que o membro digita ou escolhe. Os
            // tokens (contaazul_access_token, _refresh_token, _expira_em), a
            // lista de contas (contaazul_contas) e o servico (contaazul_servico)
            // tambem moram na credencial cifrada, mas nascem da conexao OAuth e
            // do adaptador -- no catalogo virariam campo de texto na tela.
            'contaazul' => array(
                'contaazul_client_id' => array(
                    'rotulo' => 'Client ID',
                    'segredo' => false,
                    'ajuda' => 'No Portal do Desenvolvedor do Conta Azul (developers-portal.contaazul.com): crie uma'
                        . ' aplicacao de PRODUCAO com a URL de redirecionamento mostrada abaixo, e copie o Client ID.',
                ),
                'contaazul_client_secret' => array(
                    'rotulo' => 'Client Secret',
                    'segredo' => true,
                    'ajuda' => 'Na mesma tela do Client ID. Grave os dois e clique em Conectar ao Conta Azul.',
                ),
                'contaazul_conta_financeira' => array(
                    'rotulo' => 'Conta de cobran&ccedil;a',
                    'segredo' => false,
                    'ajuda' => 'A conta financeira do Conta Azul que recebe (tipo Cobran&ccedil;as Conta Azul, ou a'
                        . ' Conta PJ). A lista aparece depois de conectar.',
                ),
            ),
            'pix_estatico' => array(
                // O tipo vem primeiro porque e ele que diz como a chave deve
                // ser escrita: CPF so digitos, celular com +55, e-mail em
                // minusculas. Sem o tipo, a tela nao tem como aplicar mascara
                // nem conferir, e chave errada so aparece quando o cliente
                // tenta pagar.
                'tipo_chave' => array(
                    'rotulo' => 'Tipo da chave',
                    'segredo' => false,
                    'ajuda' => 'Diz como a chave e escrita, e a tela confere antes de gravar.',
                ),
                'chave_pix' => array(
                    'rotulo' => 'Sua chave PIX',
                    'segredo' => false,
                    'ajuda' => 'Escreva como esta no seu banco; a mascara ajusta sozinha.',
                ),
                'nome_recebedor' => array(
                    // O APLICATIVO DE QUEM PAGA NAO MOSTRA ESTE NOME (17/09/2026): pelo
                    // Manual de Padroes do Pix, o pagador ignora o nome do codigo e o
                    // banco mostra o titular da chave cadastrado no DICT.
                    'rotulo' => 'Nome do recebedor no c&oacute;digo',
                    'segredo' => false,
                    'ajuda' => 'Ate 25 caracteres, vai dentro do c&oacute;digo. O aplicativo de quem paga mostra o titular'
                        . ' da chave, com o nome que o seu banco tem cadastrado, e nao este.',
                ),
                'cidade' => array(
                    'rotulo' => 'Cidade',
                    'segredo' => false,
                    'ajuda' => 'Ate 15 caracteres, sem acento -- e o que o padrao do Banco Central aceita.',
                ),
            ),
            'dinheiro' => array(),
        );
    }
}

if (!function_exists('shield_cred_campos')) {
    /** Os campos de um provedor. Provedor fora do catalogo devolve vazio em vez
     *  de estourar: conta antiga de um provedor que saiu ainda abre. */
    function shield_cred_campos($provedor)
    {
        $c = shield_cred_catalogo();

        return isset($c[(string) $provedor]) ? $c[(string) $provedor] : array();
    }
}

if (!function_exists('shield_cred_ambiente')) {
    /**
     * O QUE O BOTAO PRODUCAO/HOMOLOGACAO FAZ EM CADA PROVEDOR -- 11/09/2026.
     *
     * A tela prometia a todos "homologacao e o sandbox do provedor: nada de
     * dinheiro real", e isso so e verdade para quem tem OUTRO ENDERECO de
     * sandbox -- Asaas, Cora, Efi e PagBank, cujos adaptadores trocam a base
     * pelo `ambiente`. No Mercado Pago e no Pagar.me o endereco e um so: quem
     * decide se e teste ou producao e a CREDENCIAL que voce colou, e o botao
     * nao muda nada. Marcar Homologacao com a chave de producao ali movia
     * dinheiro de verdade com a tela dizendo que nao.
     *
     * E O SEGUNDO BOTAO LEVA O NOME QUE O PROVEDOR USA. Cada um batizou o
     * proprio: Asaas e PagBank dizem Sandbox, a Cora diz Stage (o host e
     * api.stage.cora.com.br), a Efi diz Homologacao (pix-h) e o Mercado Pago
     * diz Teste, na propria tela de credenciais. O painel dizia "Homologacao"
     * para todos, que e a palavra de um so. O valor gravado continua
     * producao/teste; o que muda e o que o membro le.
     *
     * Devolve `separado` (o botao troca de servidor), `ajuda` e `rotulos`.
     */
    function shield_cred_ambiente($provedor)
    {
        $provedor = (string) $provedor;
        $comSandbox = array(
            'asaas' => 'Sandbox',
            'pagbank' => 'Sandbox',
            'pagseguro' => 'Sandbox',
            'cora' => 'Stage',
            'efi' => 'Homologa&ccedil;&atilde;o',
            // O Inter chama de Sandbox (o host e o UAT, cdpj.partners.uatinter.co)
            // e o C6 tambem (baas-api-sandbox). 16/09/2026.
            'inter' => 'Sandbox',
            'c6bank' => 'Sandbox',
        );

        if (isset($comSandbox[$provedor])) {
            return array(
                'separado' => true,
                'rotulos' => array('producao' => 'Produ&ccedil;&atilde;o', 'teste' => $comSandbox[$provedor]),
                'ajuda' => $comSandbox[$provedor] . ' &eacute; o ambiente de teste do provedor: o painel fala'
                    . ' com OUTRO servidor e nada de dinheiro real.',
            );
        }

        if (in_array($provedor, array('mercadopago', 'pagarme'), true)) {
            return array(
                'separado' => false,
                'rotulos' => array('producao' => 'Produ&ccedil;&atilde;o', 'teste' => 'Teste'),
                'ajuda' => '<strong>Aqui quem decide &eacute; a credencial, e n&atilde;o este bot&atilde;o.</strong>'
                    . ' O endere&ccedil;o &eacute; o mesmo nos dois casos: o provedor tem uma chave de teste e'
                    . ' outra de produ&ccedil;&atilde;o. Marque o que combina com a chave que voc&ecirc; colou,'
                    . ' para a tela n&atilde;o dizer uma coisa e a conta fazer outra.',
            );
        }

        if ($provedor === 'contaazul') {
            // "Nao oferecemos um ambiente de sandbox dedicado" (developers.contaazul.com,
            // aboutapis): o teste e uma conta de desenvolvimento de 30 dias, no mesmo endereco.
            return array(
                'separado' => false,
                'rotulos' => array('producao' => 'Produ&ccedil;&atilde;o', 'teste' => 'Teste'),
                'ajuda' => '<strong>O Conta Azul n&atilde;o tem sandbox.</strong> O endere&ccedil;o &eacute; um s&oacute;;'
                    . ' quem decide &eacute; a aplica&ccedil;&atilde;o conectada (a de desenvolvimento do portal, com'
                    . ' dados fict&iacute;cios por 30 dias, ou a de produ&ccedil;&atilde;o). O bot&atilde;o fica aqui'
                    . ' s&oacute; como etiqueta.',
            );
        }

        if ($provedor === 'infinitepay') {
            // Nao ha sandbox nem credencial de teste: todo link e real.
            return array(
                'separado' => false,
                'rotulos' => array('producao' => 'Produ&ccedil;&atilde;o', 'teste' => 'Teste'),
                'ajuda' => '<strong>A InfinitePay n&atilde;o tem ambiente de teste.</strong> Todo link gerado &eacute;'
                    . ' real e recebe dinheiro de verdade; o bot&atilde;o fica aqui s&oacute; como etiqueta.',
            );
        }

        return array(
            'separado' => false,
            'rotulos' => array('producao' => 'Produ&ccedil;&atilde;o', 'teste' => 'Teste'),
            'ajuda' => 'Esta forma n&atilde;o fala com provedor nenhum: o bot&atilde;o fica aqui s&oacute; como'
                . ' etiqueta, e n&atilde;o muda nada.',
        );
    }
}

if (!function_exists('shield_cred_webhook')) {
    /**
     * COMO O PORTAL DE CADA PROVEDOR CHAMA O SEGREDO DO WEBHOOK -- 11/09/2026.
     *
     * O painel guarda um campo so (`conta_recebimento.webhook_segredo`) e
     * chamava todos de "Segredo do webhook", que nao e o nome de nenhum: no
     * Asaas e "Token de autenticacao", no Mercado Pago e "Assinatura secreta",
     * e o membro ficava com um campo no painel e outro nome no portal sem saber
     * se era a mesma coisa. E a mesma regra dos campos de credencial, que ja
     * levam o nome do portal.
     *
     * Devolve `rotulo` e `ajuda`. Provedor fora da lista cai no generico.
     */
    function shield_cred_webhook($provedor)
    {
        $mapa = array(
            // ASAAS E MERCADO PAGO RECUSAM O AVISO SEM SEGREDO (17/09/2026): a URL
            // do webhook do painel nao leva segredo, e aceitar sem conferir deixava
            // o endpoint aberto a qualquer POST. A baixa de quem nao gravou chega
            // pela conciliacao.
            'asaas' => array(
                'rotulo' => 'Token de autentica&ccedil;&atilde;o',
                'recusa_sem_segredo' => true,
                'ajuda' => 'No Asaas: Integra&ccedil;&otilde;es &gt; Webhooks &gt; Token de autentica&ccedil;&atilde;o'
                    . ' (o bot&atilde;o "Gerar Token"). Cole aqui o MESMO valor que ficou l&aacute;.',
            ),
            'mercadopago' => array(
                'rotulo' => 'Assinatura secreta',
                'recusa_sem_segredo' => true,
                'ajuda' => 'No Mercado Pago: Suas integra&ccedil;&otilde;es &gt; a sua aplica&ccedil;&atilde;o &gt;'
                    . ' Webhooks &gt; Assinatura secreta. E o que vem no cabe&ccedil;alho x-signature.',
            ),
            'pagbank' => array(
                'rotulo' => 'Token que assina o aviso',
                'ajuda' => 'E o mesmo Token de API da conta: o PagBank assina o corpo com ele e manda'
                    . ' o resultado no cabe&ccedil;alho x-authenticity-token. Vazio, vale o Token de API gravado acima;'
                    . ' aviso sem essa assinatura &eacute; recusado.',
            ),
            'pagseguro' => array(
                'rotulo' => 'Token que assina o aviso',
                'ajuda' => 'E o mesmo Token de API da conta: o PagBank assina o corpo com ele e manda'
                    . ' o resultado no cabe&ccedil;alho x-authenticity-token. Vazio, vale o Token de API gravado acima;'
                    . ' aviso sem essa assinatura &eacute; recusado.',
            ),
            'pagarme' => array(
                // A ASSINATURA DO PAGAR.ME DISPENSA SEGREDO (17/09/2026): o aviso vem
                // assinado em RS256 (X-Webhook-Asymmetric-Signature) e o painel confere
                // pela chave publica dele. O campo so serve ao Basic da Dashboard.
                'rotulo' => 'Usu&aacute;rio e senha do webhook (opcional)',
                'ajuda' => 'O painel confere a assinatura que o Pagar.me p&otilde;e em cada aviso, sem segredo nenhum.'
                    . ' S&oacute; se voc&ecirc; ligou a autentica&ccedil;&atilde;o do webhook na Dashboard do Pagar.me,'
                    . ' grave aqui <code>usuario:senha</code>, os mesmos de l&aacute;.',
            ),
            // A CORA TAMBEM NAO ASSINA (17/09/2026, developers.cora.com.br): o aviso
            // e um POST sem corpo, sem assinatura, segredo ou IP documentado. Ate
            // aqui ela ficava sem token, todo aviso dela levava 401 e a baixa
            // dependia so da conciliacao. O cadastro e pela API, como no Inter.
            'cora' => array(
                'rotulo' => 'Token da URL do webhook',
                'token_na_url' => true,
                'ajuda' => 'A Cora n&atilde;o assina o aviso. Invente um valor aqui e clique em'
                    . ' <strong>Gravar e cadastrar o webhook</strong>: o painel cadastra na Cora a URL acima,'
                    . ' j&aacute; com o token no fim (na Cora isso s&oacute; se faz pela API, n&atilde;o h&aacute; tela).'
                    . ' Aviso sem esse token &eacute; recusado, e a baixa fica s&oacute; por conta da concilia&ccedil;&atilde;o.',
            ),
            // A EFI TAMBEM CONFERE PELO TOKEN DA URL (17/09/2026): o cadastro do
            // webhook vai com x-skip-mtls-checking, porque hospedagem compartilhada
            // nao confere certificado de cliente -- sem o token, qualquer POST
            // entrava como autentico. O cadastro e pela API, como no Inter.
            'efi' => array(
                'rotulo' => 'Token da URL do webhook',
                'token_na_url' => true,
                'ajuda' => 'A Efi n&atilde;o assina o aviso. Invente um valor aqui e clique em'
                    . ' <strong>Gravar e cadastrar o webhook</strong>: o painel cadastra na Efi a URL acima,'
                    . ' j&aacute; com o token no fim (na Efi isso s&oacute; se faz pela API, n&atilde;o h&aacute; tela).'
                    . ' Aviso sem esse token &eacute; recusado, e a baixa fica s&oacute; por conta da concilia&ccedil;&atilde;o.',
            ),
            // OS TRES QUE NAO ASSINAM (16/09/2026): o segredo vai NA URL que o
            // membro cola no portal (&t=...), e a tela monta a URL com ele.
            // Sem segredo o aviso e recusado (401) e nada e enfileirado -- para
            // a InfinitePay isso significa que o pagamento NUNCA e confirmado,
            // porque a consulta dela depende dos dados do aviso.
            'inter' => array(
                'rotulo' => 'Token da URL do webhook',
                'token_na_url' => true,
                // O Inter nao tem tela de webhook: o cadastro e pela API, e o botao
                // "Gravar e cadastrar o webhook no Inter" faz os dois PUTs (PIX pela
                // chave, boleto) com a URL ja com o token (developers.inter.co, 16/09/2026).
                'ajuda' => 'O Inter n&atilde;o assina o aviso. Invente um valor aqui e clique em'
                    . ' <strong>Gravar e cadastrar o webhook no Inter</strong>: o painel cadastra a URL acima,'
                    . ' j&aacute; com o token no fim, para PIX e para boleto (no Inter isso s&oacute; se faz pela API,'
                    . ' n&atilde;o h&aacute; tela). Aviso sem esse token &eacute; recusado.',
            ),
            'c6bank' => array(
                'rotulo' => 'Token da URL do webhook',
                'token_na_url' => true,
                'ajuda' => 'O C6 n&atilde;o assina o aviso. Invente um valor aqui, grave, e cadastre no portal do'
                    . ' C6 a URL acima j&aacute; com ele no fim. Aviso sem esse token &eacute; recusado.',
            ),
            'infinitepay' => array(
                'rotulo' => 'Token da URL do webhook',
                'token_na_url' => true,
                'ajuda' => '<strong>Obrigat&oacute;rio para o pagamento ser confirmado.</strong> A InfinitePay'
                    . ' n&atilde;o assina o aviso e a consulta dela depende dos dados que s&oacute; o aviso traz.'
                    . ' Invente um valor aqui, grave, e cadastre na InfinitePay (Checkout &gt; webhook) a URL'
                    . ' acima j&aacute; com ele no fim.',
            ),
            // NAO HA WEBHOOK NO CONTA AZUL (developers.contaazul.com, "Futuro da
            // API", 16/09/2026): "sera preciso implementar polling". A tela nao
            // mostra URL nem pede segredo (`sem_webhook`); quem descobre o
            // pagamento e a conciliacao, perguntando pela cobranca.
            'contaazul' => array(
                'rotulo' => 'Sem webhook',
                'sem_webhook' => true,
                'ajuda' => '<strong>O Conta Azul n&atilde;o avisa quando o cliente paga: n&atilde;o tem webhook.</strong>'
                    . ' N&atilde;o h&aacute; URL para cadastrar. O painel pergunta ao Conta Azul pela cobran&ccedil;a de tempos'
                    . ' em tempos (a concilia&ccedil;&atilde;o: a cada passada do cron, ou quando algu&eacute;m abre o painel)'
                    . ' e no bot&atilde;o Conferir da tela de cobran&ccedil;as. Entre o pagamento e a baixa pode haver esse'
                    . ' intervalo, e s&oacute; a cobran&ccedil;a marcada como <strong>QUITADO</strong> no Conta Azul conta como paga.',
            ),
        );
        $generico = array(
            'rotulo' => 'Segredo do webhook',
            'ajuda' => 'O mesmo valor cadastrado no portal do provedor.',
        );

        $r = isset($mapa[(string) $provedor]) ? $mapa[(string) $provedor] : $generico;
        $r += array('token_na_url' => false, 'sem_webhook' => false, 'recusa_sem_segredo' => false);

        return $r;
    }
}

if (!function_exists('shield_cred_faltando')) {
    /**
     * Quais credenciais OBRIGATORIAS ainda nao foram preenchidas.
     *
     * E o que permite a tela dizer "esta conta nao vai funcionar, falta X" em
     * vez de deixar o membro descobrir na primeira cobranca que falha -- que e
     * onde ele descobre hoje, com o cliente esperando do outro lado.
     *
     * Campo com "(opcional)" no rotulo nao entra na conta.
     */
    function shield_cred_faltando($provedor, array $credenciais)
    {
        $faltam = array();
        foreach (shield_cred_campos($provedor) as $campo => $meta) {
            if (strpos((string) $meta['rotulo'], '(opcional)') !== false) {
                continue;
            }
            if (trim((string) (isset($credenciais[$campo]) ? $credenciais[$campo] : '')) === '') {
                $faltam[] = (string) $meta['rotulo'];
            }
        }

        return $faltam;
    }
}

if (!function_exists('shield_webhook_cadastro_frase')) {
    /**
     * O que a tela diz depois de cadastrar o webhook no provedor -- 17/09/2026.
     *
     * O adaptador devolve o que cadastrou, por alvo (`pix`/`boleto` no Inter,
     * `faturas` na Cora). "Grave a chave PIX" so faz sentido quando o alvo PIX
     * existe e falhou: e o Inter sem chave. Perguntar `empty($feito['pix'])`
     * dizia isso tambem a quem nem tem alvo PIX.
     *
     * @param array<string,bool> $feito
     */
    function shield_webhook_cadastro_frase(array $feito, $apelido)
    {
        $partes = array();
        foreach ($feito as $qual => $ok) {
            $partes[] = ($ok ? 'cadastrado' : 'NAO cadastrado') . ' para ' . $qual;
        }

        $frase = 'Webhook ' . implode(', ', $partes) . ' no ' . (string) $apelido . '.';
        if (array_key_exists('pix', $feito) && !$feito['pix']) {
            $frase .= ' Para o PIX, grave a chave PIX que recebe e cadastre de novo.';
        }

        return $frase;
    }
}

if (!function_exists('shield_cred_mascara')) {
    /**
     * O segredo como ele pode ser MOSTRADO: comeco, fim, e o meio escondido.
     *
     * Nao se exibe credencial guardada -- mas exibir NADA e pior do que
     * parece: o membro nao consegue conferir se colou a chave certa, e a
     * duvida "sera que salvou?" faz ele colar de novo a cada visita. Quatro
     * caracteres de cada ponta identificam a chave sem revela-la.
     */
    function shield_cred_mascara($valor)
    {
        $v = trim((string) $valor);
        $n = strlen($v);
        if ($n === 0) {
            return '';
        }
        if ($n <= 12) {
            return str_repeat('.', max(4, $n));
        }

        return substr($v, 0, 4) . str_repeat('.', 8) . substr($v, -4);
    }
}
