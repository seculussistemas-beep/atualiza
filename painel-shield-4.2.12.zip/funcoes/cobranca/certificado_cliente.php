<?php
/**
 * O certificado de cliente (.crt + .key) que o banco entrega -- 16/09/2026.
 *
 * O Inter, o C6 e a Cora exigem mTLS, e os tres entregam ao membro um par de arquivos:
 * o certificado (.crt) e a chave privada (.key). O painel guarda credencial em
 * texto cifrado, entao os dois precisam virar texto -- .p12 em base64 no Inter
 * (e o que o adaptador abre com openssl_pkcs12_read, como o da Efi), os dois
 * PEM em base64 no C6 e na Cora.
 *
 * O PACOTE DO MEMBRO FAZIA ISSO NUMA PAGINA PUBLICA (public/conversor_inter.php
 * e conversor_c6bank.php): sem login, recebendo a CHAVE PRIVADA do banco por
 * upload e devolvendo o base64 para colar. Chave privada em URL aberta e
 * exatamente o que este painel existe para nao deixar acontecer. O servico
 * mora aqui, chamado pela tela de Formas de recebimento, atras da sessao de
 * dono, e o arquivo nunca e gravado em disco: e lido do upload temporario,
 * conferido e cifrado no mesmo pedido.
 *
 * O PAR E CONFERIDO ANTES DE GRAVAR (openssl_x509_check_private_key). Quem tem
 * mais de uma aplicacao no banco tem mais de um par, e chave de outro
 * certificado so apareceria como handshake recusado, com erro de TLS que nao
 * diz nada.
 */

if (!function_exists('shield_certificado_provedores_com_par')) {
    /** Os provedores cuja credencial e um par .crt/.key enviado por arquivo. */
    function shield_certificado_provedores_com_par()
    {
        return array('inter', 'c6bank', 'cora');
    }
}

if (!function_exists('shield_certificado_campo_guardado')) {
    /**
     * O campo que diz a tela se ja ha certificado guardado -- 17/09/2026.
     *
     * Era um ternario entre Inter e C6 escrito na propria tela: o terceiro
     * provedor com par caia no campo do C6, e a tela dizia "ainda nao ha
     * certificado" com o certificado guardado.
     */
    function shield_certificado_campo_guardado($provedor)
    {
        $campos = array(
            'inter' => 'inter_certificado',
            'c6bank' => 'c6_certificado_crt',
            'cora' => 'cora_certificado_crt',
        );
        $provedor = strtolower(trim((string) $provedor));

        return isset($campos[$provedor]) ? $campos[$provedor] : '';
    }
}

if (!function_exists('shield_certificado_par_para_credenciais')) {
    /**
     * Confere o par e devolve os campos de credencial que o adaptador le.
     *
     * @return array<string,string>
     * @throws RuntimeException quando um dos dois nao abre ou nao casam
     */
    function shield_certificado_par_para_credenciais($provedor, $crtPem, $keyPem)
    {
        $provedor = strtolower(trim((string) $provedor));
        if (!in_array($provedor, shield_certificado_provedores_com_par(), true)) {
            throw new RuntimeException('O provedor ' . $provedor . ' nao usa certificado de cliente.');
        }

        $crtPem = (string) $crtPem;
        $keyPem = (string) $keyPem;

        $certificado = @openssl_x509_read($crtPem);
        if ($certificado === false) {
            throw new RuntimeException('O arquivo .crt nao e um certificado que o painel consiga ler. Mande o .crt que o banco entregou, em PEM.');
        }
        $chave = @openssl_pkey_get_private($keyPem);
        if ($chave === false) {
            throw new RuntimeException('O arquivo .key nao e uma chave privada que o painel consiga ler (chave com senha nao e aceita).');
        }
        if (!openssl_x509_check_private_key($certificado, $chave)) {
            throw new RuntimeException('A chave privada nao e a deste certificado. Confira se o .crt e o .key sao do MESMO par.');
        }

        if ($provedor === 'inter') {
            // Sem senha, de proposito: e como o adaptador tenta abrir, e
            // pedir uma senha que o membro nao tem so cria um campo para errar.
            $p12 = '';
            if (!openssl_pkcs12_export($certificado, $p12, $chave, '')) {
                throw new RuntimeException('Nao consegui montar o certificado do Inter: ' . (string) openssl_error_string());
            }

            return array('inter_certificado' => base64_encode($p12));
        }

        if ($provedor === 'cora') {
            // Os dois PEM, como no C6: e o par que a Integracao Direta da Cora
            // entrega (certificate.pem e private-key.key). 17/09/2026.
            return array(
                'cora_certificado_crt' => base64_encode($crtPem),
                'cora_certificado_key' => base64_encode($keyPem),
            );
        }

        return array(
            'c6_certificado_crt' => base64_encode($crtPem),
            'c6_certificado_key' => base64_encode($keyPem),
        );
    }
}

if (!function_exists('shield_certificado_par_do_upload')) {
    /**
     * Le os dois arquivos do formulario ($_FILES) e devolve a credencial, ou
     * null quando nenhum foi enviado (gravar sem arquivo mantem o guardado).
     * Um so dos dois e recusado: nao ha meio certificado.
     *
     * @throws RuntimeException
     */
    function shield_certificado_par_do_upload($provedor, array $arquivos)
    {
        $ler = static function ($nome) use ($arquivos) {
            $a = isset($arquivos[$nome]) && is_array($arquivos[$nome]) ? $arquivos[$nome] : array();
            $erro = (int) ($a['error'] ?? UPLOAD_ERR_NO_FILE);
            if ($erro === UPLOAD_ERR_NO_FILE) {
                return null;
            }
            if ($erro !== UPLOAD_ERR_OK) {
                throw new RuntimeException('O envio do arquivo ' . $nome . ' falhou (erro ' . $erro . '). Tente de novo.');
            }
            // Certificado e chave tem poucos KB; mais que isso nao e um deles.
            if ((int) ($a['size'] ?? 0) > 65536) {
                throw new RuntimeException('O arquivo ' . $nome . ' e grande demais para ser um certificado ou uma chave.');
            }
            $conteudo = @file_get_contents((string) ($a['tmp_name'] ?? ''));
            if ($conteudo === false || trim($conteudo) === '') {
                throw new RuntimeException('Nao consegui ler o arquivo ' . $nome . '.');
            }

            return $conteudo;
        };

        $crt = $ler('arquivo_crt');
        $key = $ler('arquivo_key');
        if ($crt === null && $key === null) {
            return null;
        }
        if ($crt === null || $key === null) {
            throw new RuntimeException('Mande os dois arquivos juntos, o .crt e o .key: um sem o outro nao serve.');
        }

        return shield_certificado_par_para_credenciais($provedor, $crt, $key);
    }
}
