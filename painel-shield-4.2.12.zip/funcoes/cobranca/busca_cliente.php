<?php

/**
 * A BUSCA "NOME OU CNPJ" SOBRE UMA LISTA JA CARREGADA -- 14/09/2026.
 *
 * Saiu de modules/cobranca/assinaturas.php porque a tela tem dois cartoes
 * (quem e recorrente e quem e pre-pago) e o campo so filtrava o de cima: quem
 * procurava um pre-pago lia "nenhuma assinatura" com o cliente la embaixo,
 * inteiro, fora da busca. Uma funcao so, para os dois cartoes nao casarem por
 * criterios diferentes.
 *
 * O CNPJ SO ENTRA QUANDO A BUSCA TEM CARA DE DOCUMENTO, pela mesma regra da
 * tela de Cobrancas (shield_cobranca_busca_documento). A versao da tela
 * arrancava os digitos de qualquer texto: "Mercado 24" procurava tambem CNPJ
 * com um 24 dentro, e a busca trazia gente que nao tinha nada com o nome.
 */

require_once __DIR__ . '/lista.php'; // shield_cobranca_busca_documento

/**
 * As linhas cuja `razao` contem a busca (sem caixa) ou cujo `cnpj` contem os
 * digitos dela. Busca vazia devolve a lista como veio; com busca, o resultado
 * vem reindexado.
 */
function shield_busca_cliente(array $linhas, $busca)
{
    $busca = trim((string) $busca);
    if ($busca === '') {
        return $linhas;
    }

    $agulha = mb_strtolower($busca);
    $documento = shield_cobranca_busca_documento($busca);

    return array_values(array_filter($linhas, static function ($linha) use ($agulha, $documento) {
        if (mb_strpos(mb_strtolower((string) ($linha['razao'] ?? '')), $agulha) !== false) {
            return true;
        }

        // O CNPJ pode estar gravado com pontuacao: tira dos dois lados.
        return $documento !== ''
            && strpos((string) preg_replace('/\D+/', '', (string) ($linha['cnpj'] ?? '')), $documento) !== false;
    }));
}
