<?php

// Assinaturas: os dois modos - 25/08/2026.
//
// NATIVA  -- quem gera a cobranca de cada ciclo e o PROVEDOR. O painel
//            acompanha: as cobrancas nascem la e chegam por webhook ou pela
//            conciliacao, e o painel as espelha para a tela e a regua
//            funcionarem igual. Risco proprio: o provedor cobrar e o painel
//            nao ficar sabendo.
//
// MANUAL  -- quem gera e o PAINEL, a cada ciclo. Serve para PIX estatico,
//            dinheiro e gateway sem assinatura. Risco proprio: o painel
//            esquecer de gerar.
//
// O PAINEL PRECISA SABER EM QUAL MODO CADA ASSINATURA ESTA, e por isso o modo e
// campo e nao deducao: sem ele, a rotina de geracao criaria cobranca para quem
// o provedor ja esta cobrando -- o cliente recebe duas.
//
// O CASO QUE MAIS APARECE EM PRODUCAO E O QUE MENOS APARECE EM TESTE: cliente
// que estava em dinheiro e passa a pagar por cartao recorrente TROCA DE MODO no
// meio do ciclo. A troca nao pode gerar cobranca duplicada no mes da virada nem
// deixar um mes descoberto. Por isso a competencia -- e nao a data -- e a chave
// de tudo aqui.

require_once __DIR__ . '/cobranca_motor.php';
require_once __DIR__ . '/../nucleo/data_zerada.php'; // a data zerada em SQL, sem pedir conversao

/** A competencia e o primeiro dia do mes: e ela que identifica o ciclo. */
function shield_assinatura_competencia($data = null)
{
    $d = $data ? new DateTimeImmutable((string) $data) : new DateTimeImmutable('today');

    return $d->format('Y-m-01');
}

/**
 * O vencimento daquele ciclo, respeitando o dia escolhido.
 *
 * Dia 31 em mes de 30 cai no ULTIMO dia do mes, e nao no dia 1 do seguinte --
 * que e o que a soma ingenua faz e o que faria a cobranca de fevereiro vencer
 * em marco.
 */
function shield_assinatura_vencimento($competencia, $dia)
{
    $mes = new DateTimeImmutable((string) $competencia);
    $ultimo = (int) $mes->format('t');
    $dia = max(1, min((int) $dia, $ultimo));

    return $mes->setDate((int) $mes->format('Y'), (int) $mes->format('n'), $dia)->format('Y-m-d');
}

/**
 * A competencia da PRIMEIRA mensalidade de uma assinatura que nasce agora --
 * 11/09/2026.
 *
 * E a do mes de $quando, a nao ser que o vencimento dela ja tenha passado: ai e
 * a do mes seguinte. Sem isso, trocar um pre-pago com validade ate o dia 25
 * para assinatura com vencimento no dia 10 criava a competencia do mes corrente
 * vencendo quinze dias atras -- o relogio gerava e emitia na mesma passada, com
 * multa e juros de um atraso que nunca houve, e a regua ja contava os dias para
 * suspender quem tinha acabado de assinar.
 */
function shield_assinatura_primeira_competencia($quando, $dia)
{
    $competencia = shield_assinatura_competencia($quando);
    if (shield_assinatura_vencimento($competencia, $dia) >= date('Y-m-d')) {
        return $competencia;
    }

    return (new DateTimeImmutable($competencia))->modify('+1 month')->format('Y-m-01');
}

function shield_assinatura_ler(PDO $pdo, $id)
{
    $stmt = $pdo->prepare('SELECT * FROM assinatura WHERE id = :id LIMIT 1');
    $stmt->execute(array(':id' => (int) $id));
    $linha = $stmt->fetch(PDO::FETCH_ASSOC);

    return is_array($linha) ? $linha : null;
}

/**
 * Gera as cobrancas do ciclo das assinaturas MANUAIS que estao vencendo.
 *
 * IDEMPOTENTE POR (assinatura, competencia) -- e a unicidade esta no BANCO, nao
 * so aqui. Rodar duas vezes no mesmo dia, ou dois acessos ao painel no mesmo
 * segundo, nao geram duas cobrancas. Isso o cliente ve.
 *
 * NAO GERA PARA ASSINATURA NATIVA: la quem cobra e o provedor, e gerar aqui
 * faria o cliente receber duas.
 */
/**
 * OS PRE-PAGOS -- 10/09/2026, tarde: cliente com validade e sem assinatura
 * ativa, com a ultima fatura paga ao lado. E a outra metade da tela de
 * assinaturas: quem paga de uma vez.
 */
function shield_prepagos_lista(PDO $pdo)
{
    try {
        return $pdo->query(
            "SELECT e.codigo, e.razao, e.cnpj, e.validade_licenca,
                    (SELECT COALESCE(NULLIF(c.valor_pago_centavos, 0), c.valor_centavos) FROM cobranca c
                      WHERE c.fk_empresa = e.codigo AND c.situacao = 'paga' ORDER BY c.pago_em DESC, c.id DESC LIMIT 1) AS ultimo_valor,
                    (SELECT c.pago_em FROM cobranca c WHERE c.fk_empresa = e.codigo AND c.situacao = 'paga' ORDER BY c.pago_em DESC, c.id DESC LIMIT 1) AS ultimo_pago,
                    (SELECT c.meses FROM cobranca c WHERE c.fk_empresa = e.codigo AND c.situacao = 'paga' ORDER BY c.pago_em DESC, c.id DESC LIMIT 1) AS ultimo_meses,
                    (SELECT COALESCE(SUM(COALESCE(NULLIF(c.valor_pago_centavos, 0), c.valor_centavos)), 0) FROM cobranca c
                      WHERE c.fk_empresa = e.codigo AND c.situacao = 'paga' AND c.pago_em >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)) AS pago_12m
               FROM empresa e
              WHERE e.encerrado_em IS NULL AND " . shield_sql_com_validade('e.validade_licenca') . "
                AND NOT EXISTS (SELECT 1 FROM assinatura a WHERE a.fk_empresa = e.codigo AND a.situacao = 'ativa')
              ORDER BY e.validade_licenca"
        )->fetchAll(PDO::FETCH_ASSOC) ?: array();
    } catch (Throwable $semTabela) {
        return array();
    }
}

/**
 * Se alguma fatura desta loja que COMPRA LICENCA ja foi paga: separa "aguardando
 * o primeiro" de "vencida".
 *
 * SO CONTA A FATURA DA ASSINATURA OU A QUE CARREGA MESES (14/09/2026). A avulsa
 * de ajuste (meses = 0, "paga, nao move a validade", 4.1.7) paga nao e o
 * primeiro pagamento de contrato nenhum; contando ela, a faixa da assinatura
 * deixava de dizer "aguardando o primeiro pagamento" para quem nunca pagou
 * mensalidade.
 */
function shield_cobranca_ja_pagou(PDO $pdo, $empresa)
{
    try {
        $st = $pdo->prepare(
            "SELECT 1 FROM cobranca
              WHERE fk_empresa = ? AND situacao = 'paga'
                AND (fk_assinatura IS NOT NULL OR meses > 0)
              LIMIT 1"
        );
        $st->execute(array((int) $empresa));

        return (bool) $st->fetchColumn();
    } catch (Throwable $semTabela) {
        return false;
    }
}

/** Quanto entrou nos ultimos 12 meses e quanto esta na rua (aberta + vencida). */
function shield_receita_resumo(PDO $pdo)
{
    $r = array('recebido_12m' => 0, 'a_receber' => 0, 'vencido' => 0);
    try {
        $r['recebido_12m'] = (int) $pdo->query("SELECT COALESCE(SUM(COALESCE(NULLIF(valor_pago_centavos, 0), valor_centavos)), 0) FROM cobranca
                                                  WHERE situacao = 'paga' AND pago_em >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)")->fetchColumn();
        $r['a_receber'] = (int) $pdo->query("SELECT COALESCE(SUM(valor_centavos), 0) FROM cobranca WHERE situacao IN ('aberta', 'vencida')")->fetchColumn();
        $r['vencido'] = (int) $pdo->query("SELECT COALESCE(SUM(valor_centavos), 0) FROM cobranca WHERE situacao = 'vencida'")->fetchColumn();
    } catch (Throwable $semTabela) {
    }

    return $r;
}

/**
 * A CONTA PADRAO de emissao: a unica ativa que nao e dinheiro, ou 0 quando ha
 * duas ou mais (o painel nao escolhe por ninguem). Extraida do ciclo em
 * 10/09/2026 para Mudar o contrato mostrar a mesma resposta.
 */
function shield_conta_padrao(PDO $pdo)
{
    try {
        $ids = $pdo->query(
            "SELECT id FROM conta_recebimento WHERE ativo = 1 AND provedor <> 'dinheiro'"
        )->fetchAll(PDO::FETCH_COLUMN);

        return count($ids) === 1 ? (int) $ids[0] : 0;
    } catch (Throwable $semTabela) {
        return 0;
    }
}

function shield_assinatura_gerar_ciclo(PDO $pdo, $ateDias = 7)
{
    $hoje = new DateTimeImmutable('today');
    $limite = $hoje->modify('+' . max(0, (int) $ateDias) . ' days');

    $stmt = $pdo->prepare(
        'SELECT * FROM assinatura
          WHERE situacao = :ativa AND modo = :manual
          ORDER BY id'
    );
    $stmt->execute(array(':ativa' => 'ativa', ':manual' => 'manual'));

    $criadas = 0;
    $puladas = 0;

    // Uma consulta so, fora do laco: a conta padrao e a mesma para todas as
    // assinaturas desta passada. Ver o comentario no ponto da emissao.
    //
    // CONTA DE VERDADE, na tabela -- e nao shield_cobranca_contas(), que
    // tambem apresenta o gateway LEGADO convertido como se fosse conta. A
    // conversao existe para a tela nao obrigar o membro a reconfigurar; como
    // padrao de emissao automatica ela surpreenderia: emitiria por um
    // caminho que o membro nunca abriu nem conferiu.
    //
    // "DINHEIRO" NAO ENTRA NA CONTA. A V4_0_4 ja instala a conta de dinheiro
    // em especie LIGADA em toda instalacao ("nao ha o que configurar nela"),
    // entao "a unica ativa" seria sempre ela em painel recem-instalado, e
    // ligar um gateway de verdade faria DUAS ativas -- a regra deixaria de
    // valer justamente quando o membro se preparou para ela. Dinheiro nao
    // gera nada que se mande ao cliente (nem PIX, nem boleto, nem link);
    // emitir nele so muda a situacao. Fica de fora do "padrao".
    $contaPadrao = shield_conta_padrao($pdo);

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $a) {
        $competencia = trim((string) ($a['proxima_competencia'] ?? ''));
        if ($competencia === '') {
            $competencia = shield_assinatura_competencia();
        }

        $vencimento = shield_assinatura_vencimento($competencia, (int) $a['dia_vencimento']);

        // So gera o que ja esta na janela. Adiantar o ano inteiro encheria a
        // tela do membro de cobranca que ninguem vai olhar por meses.
        if (new DateTimeImmutable($vencimento) > $limite) {
            continue;
        }

        try {
            $id = shield_cobranca_abrir($pdo, array(
                'empresa' => (int) $a['fk_empresa'],
                'assinatura' => (int) $a['id'],
                'competencia' => $competencia,
                'descricao' => 'Mensalidade ' . (new DateTimeImmutable($competencia))->format('m/Y'),
                'valor_centavos' => (int) $a['valor_centavos'],
                // Os meses viajam na fatura (11/09/2026): e ela que diz quanto
                // o pagamento estende, nao a assinatura de hoje.
                'meses' => max(1, (int) $a['ciclo_meses']),
                'vencimento' => $vencimento,
                // A MENSALIDADE E COMPOSTA -- 09/09/2026. Modulos
                // contratados e terminal alem da cota entram aqui, e nao na
                // unha do membro todo mes. Ver funcoes/cobranca/composicao.php.
                //
                // So o ciclo compoe. Cobranca avulsa continua valendo o que
                // alguem digitou: somar modulo mensal a uma compra de doze
                // meses e uma decisao de preco que nao cabe ao codigo tomar
                // sozinho.
                'compor' => true,
                // A FORMA E A DA ASSINATURA (14/09/2026). Sem ela a mensalidade
                // nascia sem forma e os adaptadores emitem PIX: quem fechou em
                // boleto recebia boleto so na primeira fatura, que o fechamento
                // abre com a forma, e PIX do segundo mes em diante. Vazia continua
                // sendo o PIX de sempre.
                'forma' => trim((string) ($a['forma'] ?? '')) !== '' ? (string) $a['forma'] : null,
            ));
            $criadas++;

            // A conta da assinatura emite na hora. Sem ela, vale a CONTA PADRAO
            // -- corrigido em 09/09/2026: antes a cobranca nascia em
            // rascunho e alguem clicava Emitir todo mes, e a assinatura so
            // ganhava conta se o membro a tivesse escolhido na PRIMEIRA
            // cobranca. Praticamente todos os 43 do levantamento pediram
            // recorrencia "sem redigitar"; para quem nao escolheu conta, era
            // "sem redigitar, mas com um clique por mes".
            //
            // A padrao e a MAIS SIMPLES QUE NAO SURPREENDE: a unica conta
            // ativa, quando ha uma so. Duas ou mais, o painel nao escolhe por
            // ninguem e fica em rascunho como sempre ficou -- e o caso de quem
            // recebe por dois caminhos e decide por cliente.
            $conta = (int) ($a['fk_conta'] ?? 0);
            if ($conta <= 0 && $contaPadrao > 0) {
                $conta = $contaPadrao;
            }

            if ($conta > 0) {
                try {
                    shield_cobranca_emitir($pdo, $id, $conta);
                } catch (Throwable $ignorado) {
                    // Provedor fora do ar nao pode impedir a cobranca de
                    // existir: ela fica em rascunho e a proxima passada emite.
                }
            }
        } catch (PDOException $e) {
            // 23000 = a competencia ja tem cobranca. E o caminho normal de
            // quem roda duas vezes no mesmo dia.
            if ($e->getCode() !== '23000') {
                throw $e;
            }
            $puladas++;
        }

        shield_assinatura_avancar($pdo, $a);
    }

    return array('criadas' => $criadas, 'puladas' => $puladas);
}

/** Empurra a assinatura para o ciclo seguinte. */
function shield_assinatura_avancar(PDO $pdo, array $a)
{
    $competencia = trim((string) ($a['proxima_competencia'] ?? ''));
    if ($competencia === '') {
        $competencia = shield_assinatura_competencia();
    }

    $proxima = (new DateTimeImmutable($competencia))
        ->modify('+' . max(1, (int) $a['ciclo_meses']) . ' month')
        ->format('Y-m-01');

    $stmt = $pdo->prepare('UPDATE assinatura SET proxima_competencia = :p WHERE id = :id');
    $stmt->execute(array(':p' => $proxima, ':id' => (int) $a['id']));
}

/**
 * Cancelar no painel TEM de cancelar no provedor.
 *
 * Sem isto, o membro cancela aqui, o cliente continua sendo cobrado la, e quem
 * descobre e o cliente -- na fatura do cartao.
 */
function shield_assinatura_cancelar(PDO $pdo, $id, $motivo = '')
{
    $a = shield_assinatura_ler($pdo, $id);
    if ($a === null) {
        throw new RuntimeException('Assinatura nao encontrada.');
    }

    if ((string) $a['modo'] === 'nativa' && trim((string) $a['id_no_provedor']) !== ''
        && !empty($a['fk_conta'])) {
        $conta = shield_cob_conta($pdo, (int) $a['fk_conta']);
        $provedor = $conta ? Shield\Cobranca\Registro::para((string) $conta['provedor']) : null;
        if ($provedor !== null) {
            // Falhar aqui NAO pode deixar a assinatura ativa no painel: o
            // membro decidiu cancelar. O que se faz e registrar e seguir, para
            // ele ver que precisa cancelar no portal do provedor tambem.
            try {
                $provedor->cancelar((string) $a['id_no_provedor'], $conta);
            } catch (Throwable $e) {
                shield_auditar($pdo, 'assinatura_cancelar_provedor_falhou', array(
                    'alvo_tipo' => 'assinatura', 'alvo_id' => (int) $id,
                    'detalhe' => 'CANCELE TAMBEM NO PROVEDOR: ' . $e->getMessage(),
                ));
            }
        }
    }

    $stmt = $pdo->prepare('UPDATE assinatura SET situacao = :s WHERE id = :id');
    $stmt->execute(array(':s' => 'cancelada', ':id' => (int) $id));

    shield_auditar($pdo, 'assinatura_cancelada', array(
        'alvo_tipo' => 'assinatura', 'alvo_id' => (int) $id,
        'antes' => (string) $a['situacao'], 'depois' => 'cancelada',
        'detalhe' => (string) $motivo,
    ));

    return true;
}

if (!function_exists('shield_assinatura_ciclo_nome')) {
    /**
     * O ciclo em palavra de gente: "mensal", "semestral", "anual".
     *
     * A tela dizia "1 mes(es), dia 5". Ninguem fala assim, e o "(es)" e o
     * atalho de quem nao quis escolher entre singular e plural -- custa uma
     * linha e o membro le a tela inteira mais rapido.
     */
    function shield_assinatura_ciclo_nome($meses)
    {
        $meses = (int) $meses;
        $nomes = array(1 => 'mensal', 2 => 'bimestral', 3 => 'trimestral',
                       4 => 'quadrimestral', 6 => 'semestral', 12 => 'anual',
                       24 => 'bienal');
        if (isset($nomes[$meses])) {
            return $nomes[$meses];
        }

        return 'a cada ' . $meses . ' meses';
    }
}

if (!function_exists('shield_assinatura_por_mes')) {
    /**
     * Quanto a assinatura vale POR MES, em centavos.
     *
     * Sem isto nao existe receita recorrente somavel: um semestral de R$ 774 e
     * um mensal de R$ 129 valem o mesmo por mes, e a tela mostrava 774 ao lado
     * de 129 como se fossem grandezas comparaveis. Somar a coluna "valor" de
     * uma carteira com ciclos misturados da um numero que nao significa nada.
     */
    function shield_assinatura_por_mes(array $a)
    {
        $ciclo = max(1, (int) ($a['ciclo_meses'] ?? 1));

        return (int) round(((int) ($a['valor_centavos'] ?? 0)) / $ciclo);
    }
}

/**
 * GERAR DE NOVO A MENSALIDADE CANCELADA -- 14/10/2026.
 *
 * Visto num membro: cancelou a mensalidade para tirar um desconto errado e nao
 * havia como gerar a do mesmo mes de novo. O ciclo nao gera, porque a
 * competencia e unica por assinatura (uk_cobranca_competencia) e a cancelada a
 * ocupa; e a avulsa que ele abriu no lugar nao estende a licenca. Aqui a
 * cancelada SOLTA a competencia (vira NULL, que a chave unica aceita a vontade --
 * ela continua no banco, no livro e no filtro de canceladas) e a nova nasce como
 * o ciclo a faria: mesma competencia, mesmo vencimento, meses do ciclo, composta,
 * na forma e na conta da assinatura (ou na padrao). Devolve o id da nova.
 *
 * So assinatura ATIVA: a cancelada ou trocada para pre-pago nao tem mensalidade
 * para gerar, e gerar ali ressuscitaria cobranca de quem saiu.
 */
function shield_assinatura_regerar(PDO $pdo, $cobrancaId)
{
    $st = $pdo->prepare('SELECT * FROM cobranca WHERE id = :id');
    $st->execute(array(':id' => (int) $cobrancaId));
    $velha = $st->fetch(PDO::FETCH_ASSOC);
    if (!$velha || (string) $velha['situacao'] !== SHIELD_COB_CANCELADA) {
        throw new RuntimeException('So a mensalidade cancelada se gera de novo.');
    }
    $competencia = trim((string) ($velha['competencia'] ?? ''));
    if (!empty($velha['fk_assinatura']) && $competencia === '') {
        // O F5 do mesmo clique: a cancelada ja soltou o mes para outra.
        $ja = $pdo->prepare("SELECT 1 FROM auditoria WHERE acao = 'cobranca_gerada_de_novo' AND antes = :v LIMIT 1");
        $ja->execute(array(':v' => (string) (int) $velha['id']));
        if ($ja->fetchColumn()) {
            throw new RuntimeException('Esta mensalidade ja foi gerada de novo: a nova esta na lista do cliente.');
        }
    }
    if (empty($velha['fk_assinatura']) || $competencia === '') {
        throw new RuntimeException('Esta cobranca nao e mensalidade de assinatura: abra outra em Nova cobranca.');
    }

    $st = $pdo->prepare('SELECT * FROM assinatura WHERE id = :id');
    $st->execute(array(':id' => (int) $velha['fk_assinatura']));
    $a = $st->fetch(PDO::FETCH_ASSOC);
    if (!$a || (string) $a['situacao'] !== 'ativa') {
        throw new RuntimeException('A assinatura deste cliente nao esta ativa: nao ha mensalidade para gerar.');
    }

    $propria = !$pdo->inTransaction();
    if ($propria) {
        $pdo->beginTransaction();
    }
    try {
        $pdo->prepare('UPDATE cobranca SET competencia = NULL WHERE id = :id')->execute(array(':id' => (int) $velha['id']));
        try {
            $id = shield_cobranca_abrir($pdo, array(
                'empresa' => (int) $a['fk_empresa'],
                'assinatura' => (int) $a['id'],
                'competencia' => $competencia,
                'descricao' => 'Mensalidade ' . (new DateTimeImmutable($competencia))->format('m/Y'),
                'valor_centavos' => (int) $a['valor_centavos'],
                'meses' => max(1, (int) $a['ciclo_meses']),
                'vencimento' => substr((string) $velha['vencimento'], 0, 10),
                'compor' => true,
                'forma' => trim((string) ($a['forma'] ?? '')) !== '' ? (string) $a['forma'] : null,
            ));
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                throw new RuntimeException('Esta competencia ja tem outra mensalidade: confira a lista do cliente.');
            }
            throw $e;
        }
        shield_auditar($pdo, 'cobranca_gerada_de_novo', array(
            'alvo_tipo' => 'cobranca', 'alvo_id' => $id,
            'antes' => (string) (int) $velha['id'],
            'detalhe' => 'mensalidade ' . substr($competencia, 0, 7) . ' gerada de novo no lugar da cobranca cancelada #' . (int) $velha['id'],
        ));
        if ($propria) {
            $pdo->commit();
        }
    } catch (Throwable $e) {
        if ($propria && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    // Emitir vem DEPOIS do commit, como no ciclo: provedor fora do ar nao desfaz
    // a mensalidade, ela fica em rascunho e a proxima passada (ou o Emitir) sai.
    $conta = (int) ($a['fk_conta'] ?? 0);
    if ($conta <= 0) {
        $conta = shield_conta_padrao($pdo);
    }
    if ($conta > 0) {
        try {
            shield_cobranca_emitir($pdo, $id, $conta);
        } catch (Throwable $ignorado) {
        }
    }

    return $id;
}
