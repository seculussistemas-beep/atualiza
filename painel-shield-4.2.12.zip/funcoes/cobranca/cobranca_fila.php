<?php

// Fila, webhook e conciliacao - 25/08/2026.
//
// TRES PECAS QUE SO EXISTEM POR CAUSA DA HOSPEDAGEM DO MEMBRO: sem shell e sem
// processo residente, nada roda sozinho. A fila e uma tabela, quem a empurra e
// uma requisicao web, e a conciliacao -- que num sistema com processo residente
// seria rede de seguranca -- aqui e a PECA PRINCIPAL.
//
// Porque: webhook se perde. O provedor tenta, a hospedagem estava fora do ar,
// ele desiste. Num painel sem processo proprio, se ninguem for perguntar, o
// pagamento simplesmente nunca aparece.

use Shield\Cobranca\Registro;

/** Quantas cobrancas a conciliacao olha por rodada. */
const SHIELD_CONCILIA_LOTE = 40;
/** Quantas vezes um trabalho tenta antes de desistir. */
const SHIELD_TRABALHO_TENTATIVAS = 5;

function shield_trabalho_enfileirar(PDO $pdo, $tipo, array $carga = array(), $atrasoSegundos = 0)
{
    $stmt = $pdo->prepare(
        'INSERT INTO trabalho (tipo, carga, situacao, proxima_em)
         VALUES (:tipo, :carga, :sit, DATE_ADD(NOW(), INTERVAL :atraso SECOND))'
    );
    $stmt->execute(array(
        ':tipo' => substr((string) $tipo, 0, 40),
        ':carga' => json_encode($carga, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
        ':sit' => 'pendente',
        ':atraso' => max(0, (int) $atrasoSegundos),
    ));

    return (int) $pdo->lastInsertId();
}

/**
 * Tira UM trabalho da fila, marcando-o como em andamento no mesmo passo.
 *
 * A reivindicacao e por UPDATE condicional e confere rowCount: sem isso, dois
 * acessos ao painel no mesmo segundo processariam o mesmo trabalho -- e
 * trabalho de cobranca processado duas vezes e dinheiro contado duas vezes.
 * E o mesmo desenho da fila do LojaZap.
 */
function shield_trabalho_reivindicar(PDO $pdo)
{
    $stmt = $pdo->prepare(
        'SELECT id FROM trabalho
          WHERE situacao = :pend AND proxima_em <= NOW()
          ORDER BY id LIMIT 1'
    );
    $stmt->execute(array(':pend' => 'pendente'));
    $id = $stmt->fetchColumn();
    if ($id === false) {
        return null;
    }

    $stmt = $pdo->prepare(
        'UPDATE trabalho SET situacao = :fazendo, tentativas = tentativas + 1
          WHERE id = :id AND situacao = :pend'
    );
    $stmt->execute(array(':fazendo' => 'processando', ':id' => (int) $id, ':pend' => 'pendente'));

    if ($stmt->rowCount() !== 1) {
        return null;      // outro acesso levou este; a proxima rodada pega outro
    }

    $stmt = $pdo->prepare('SELECT * FROM trabalho WHERE id = :id');
    $stmt->execute(array(':id' => (int) $id));
    $linha = $stmt->fetch(PDO::FETCH_ASSOC);

    return is_array($linha) ? $linha : null;
}

function shield_trabalho_fechar(PDO $pdo, $id, $situacao, $resultado = '')
{
    $stmt = $pdo->prepare(
        'UPDATE trabalho SET situacao = :sit, resultado = :res WHERE id = :id'
    );
    $stmt->execute(array(':sit' => $situacao, ':res' => substr((string) $resultado, 0, 2000),
                         ':id' => (int) $id));
}

/**
 * Devolve o trabalho para a fila com espera crescente.
 *
 * A espera cresce porque a falha mais comum e o provedor fora do ar: insistir
 * de segundo em segundo nao adianta e ainda gasta a requisicao do membro.
 */
function shield_trabalho_adiar(PDO $pdo, array $trabalho, $motivo)
{
    $tentativas = (int) $trabalho['tentativas'];
    if ($tentativas >= SHIELD_TRABALHO_TENTATIVAS) {
        shield_trabalho_fechar($pdo, $trabalho['id'], 'desistiu', $motivo);

        return false;
    }

    $espera = min(3600, 60 * (2 ** ($tentativas - 1)));
    $stmt = $pdo->prepare(
        'UPDATE trabalho
            SET situacao = :pend, resultado = :res,
                proxima_em = DATE_ADD(NOW(), INTERVAL :espera SECOND)
          WHERE id = :id'
    );
    $stmt->execute(array(':pend' => 'pendente', ':res' => substr((string) $motivo, 0, 2000),
                         ':espera' => $espera, ':id' => (int) $trabalho['id']));

    return true;
}

/** Processa ate N trabalhos. Devolve quantos fechou. */
function shield_trabalho_processar(PDO $pdo, $quantos = 10)
{
    $feitos = 0;

    for ($i = 0; $i < (int) $quantos; $i++) {
        $trabalho = shield_trabalho_reivindicar($pdo);
        if ($trabalho === null) {
            break;
        }

        $carga = json_decode((string) $trabalho['carga'], true);
        $carga = is_array($carga) ? $carga : array();

        try {
            switch ((string) $trabalho['tipo']) {
                case 'conferir_cobranca':
                    // O trabalho que o webhook cria. Ele nao aplica nada por
                    // conta propria: manda PERGUNTAR ao provedor.
                    $r = shield_cobranca_consultar($pdo, (int) ($carga['cobranca'] ?? 0));
                    shield_trabalho_fechar($pdo, $trabalho['id'], 'feito',
                                           $r ? $r->situacao : 'sem tentativa para consultar');
                    break;

                case 'enviar_email':
                    // O envio sai daqui, e nao da tela: servidor de e-mail
                    // lento e comum, e a alternativa e o membro esperando
                    // trinta segundos numa tela que so ia confirmar um
                    // pagamento.
                    require_once __DIR__ . '/../notificacao/email.php';
                    shield_email_enviar_agora($pdo, (string) ($carga['para'] ?? ''),
                                              (string) ($carga['assunto'] ?? ''),
                                              (string) ($carga['html'] ?? ''));
                    shield_trabalho_fechar($pdo, $trabalho['id'], 'feito',
                                           'enviado para ' . (string) ($carga['para'] ?? ''));
                    break;

                default:
                    shield_trabalho_fechar($pdo, $trabalho['id'], 'desistiu',
                                           'tipo desconhecido: ' . $trabalho['tipo']);
            }
            $feitos++;
        } catch (Throwable $e) {
            shield_trabalho_adiar($pdo, $trabalho, $e->getMessage());
        }
    }

    return $feitos;
}

// ----------------------------------------------------------------- webhook ---

/**
 * Recebe o webhook: confere a assinatura, GUARDA O EVENTO CRU e enfileira a
 * verificacao. Devolve o que responder ao provedor.
 *
 * ELE NAO MOVE NADA. Nem situacao de cobranca, nem dinheiro, nem validade. O
 * maximo que um POST forjado consegue e fazer o painel perguntar ao gateway --
 * e o gateway responde a verdade.
 *
 * RESPONDER RAPIDO E TRABALHAR DEPOIS: o provedor precisa do 200 imediato, e a
 * consulta que confirma o pagamento pode demorar. Provedor que nao recebe 200
 * reenvia, e reenvia fora de ordem.
 */
function shield_webhook_receber(PDO $pdo, $nomeProvedor, $corpo, array $cabecalhos)
{
    $provedor = Registro::para((string) $nomeProvedor);
    if ($provedor === null) {
        return array('http' => 404, 'texto' => 'provedor desconhecido', 'cobranca' => null);
    }

    // A conta ATIVA daquele provedor. Sem ela nao ha segredo para conferir.
    $stmt = $pdo->prepare(
        'SELECT * FROM conta_recebimento WHERE provedor = :p ORDER BY ativo DESC, id LIMIT 1'
    );
    $stmt->execute(array(':p' => (string) $nomeProvedor));
    $conta = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!is_array($conta)) {
        return array('http' => 404, 'texto' => 'sem conta deste provedor', 'cobranca' => null);
    }
    $conta['_credenciais'] = shield_cobranca_credenciais($conta);

    $evento = $provedor->lerWebhook((string) $corpo, $cabecalhos, $conta);
    if ($evento === null) {
        return array('http' => 400, 'texto' => 'corpo nao reconhecido', 'cobranca' => null);
    }

    // SEM SEGREDO GRAVADO E OUTRO MOTIVO (17/09/2026): Asaas e Mercado Pago
    // passaram a recusar o aviso da conta sem token, e quem investiga precisa
    // separar "alguem forjou" de "o membro nao gravou o segredo".
    $semSegredo = !$evento->assinaturaConfere && trim((string) ($conta['webhook_segredo'] ?? '')) === '';

    // IDEMPOTENCIA: o mesmo id de evento so entra uma vez. Provedor reenvia --
    // e reenvia fora de ordem --, e sem isto a segunda entrega enfileiraria
    // outra verificacao do mesmo pagamento.
    $stmt = $pdo->prepare(
        'INSERT INTO webhook_evento (provedor, id_evento, tipo, corpo, assinatura_confere, situacao)
         VALUES (:prov, :id, :tipo, :corpo, :confere, :sit)
         ON DUPLICATE KEY UPDATE id = id'
    );
    $stmt->execute(array(
        ':prov' => (string) $nomeProvedor,
        ':id' => substr($evento->id, 0, 120),
        ':tipo' => substr($evento->tipo, 0, 60),
        ':corpo' => (string) $corpo,
        ':confere' => (int) $evento->assinaturaConfere,
        ':sit' => $evento->assinaturaConfere ? 'recebido' : ($semSegredo ? 'sem_segredo' : 'assinatura_invalida'),
    ));

    if ($stmt->rowCount() === 0) {
        // Ja tinha vindo. 200 mesmo assim: recusar faria o provedor reenviar
        // para sempre.
        return array('http' => 200, 'texto' => 'repetido', 'cobranca' => null);
    }

    if (!$evento->assinaturaConfere) {
        // Fica GRAVADO, e nao processado. E o que responde "alguem esta
        // batendo no meu webhook" -- que sem esta linha ninguem descobre.
        return array('http' => 401, 'texto' => $semSegredo ? 'conta sem segredo do webhook' : 'assinatura nao confere', 'cobranca' => null);
    }

    $cobranca = null;
    if ($evento->idExterno !== '') {
        $stmt = $pdo->prepare(
            'SELECT fk_cobranca FROM cobranca_tentativa
              WHERE provedor = :p AND id_externo = :ext ORDER BY id DESC LIMIT 1'
        );
        $stmt->execute(array(':p' => (string) $nomeProvedor, ':ext' => $evento->idExterno));
        $achado = $stmt->fetchColumn();
        $cobranca = $achado === false ? null : (int) $achado;
    }

    // O AVISO DO CARTAO TRAZ OUTRO ID -- 11/09/2026. Nas tres formas de cartao
    // (Mercado Pago, PagBank e Pagar.me) o painel guarda o id do CHECKOUT e o
    // provedor avisa com o id do PEDIDO ou da cobranca interna dele: a
    // igualdade exata nunca casa e o evento era arquivado como 'sem_cobranca'.
    // A referencia `shield-<id>` viaja na criacao dos tres, e e por ela que da
    // para achar. Nao ha risco em confiar no corpo aqui: por doutrina o webhook
    // nao move nada, ele so DISPARA a consulta ao provedor.
    if ($cobranca === null) {
        $cobranca = shield_cobranca_por_referencia($pdo, (string) $nomeProvedor, (string) $corpo);
    }

    // O ID QUE A CONSULTA PRECISA PODE NASCER NO AVISO -- 16/09/2026. A
    // InfinitePay confirma por payment_check, que exige transaction_nsu e slug,
    // e os dois so existem no webhook. O adaptador os entrega em
    // idParaConsultar; aqui eles vao para a ultima tentativa, e e com esse id
    // que shield_cobranca_consultar vai perguntar. So depois de a assinatura
    // conferir (o 401 acima ja saiu), e o conteudo nao decide nada: a
    // situacao continua vindo do provedor.
    if ($cobranca !== null && $evento->idParaConsultar !== '' && $evento->idParaConsultar !== $evento->idExterno) {
        $stmt = $pdo->prepare(
            'SELECT id FROM cobranca_tentativa WHERE fk_cobranca = :c AND provedor = :p ORDER BY id DESC LIMIT 1'
        );
        $stmt->execute(array(':c' => $cobranca, ':p' => (string) $nomeProvedor));
        $tentativa = $stmt->fetchColumn();
        if ($tentativa !== false) {
            $pdo->prepare('UPDATE cobranca_tentativa SET id_externo = :novo WHERE id = :id')
                ->execute(array(':novo' => substr($evento->idParaConsultar, 0, 120), ':id' => (int) $tentativa));
        }
    }

    if ($cobranca !== null) {
        shield_trabalho_enfileirar($pdo, 'conferir_cobranca', array('cobranca' => $cobranca));
    }

    $stmt = $pdo->prepare(
        'UPDATE webhook_evento SET situacao = :sit, processado_em = NOW()
          WHERE provedor = :p AND id_evento = :id'
    );
    $stmt->execute(array(':sit' => $cobranca !== null ? 'enfileirado' : 'sem_cobranca',
                         ':p' => (string) $nomeProvedor, ':id' => substr($evento->id, 0, 120)));

    // `cobranca` diz a quem chamou SE o motor novo reconheceu o aviso como
    // seu. E o que a ponte (abaixo) usa para decidir se o antigo ainda precisa
    // olhar. null aqui nao e erro: e "nao e minha".
    return array('http' => 200, 'texto' => 'ok', 'cobranca' => $cobranca);
}

/**
 * Os cabecalhos HTTP como o adaptador os procura: minusculos, com `-`, sem o
 * prefixo HTTP_. Recebe $_SERVER (ou qualquer array no formato dele) para
 * poder ser exercitado sem servidor.
 */
function shield_webhook_cabecalhos(array $servidor)
{
    $cabecalhos = array();
    foreach ($servidor as $chave => $valor) {
        if (strncmp((string) $chave, 'HTTP_', 5) === 0) {
            $cabecalhos[strtolower(str_replace('_', '-', substr((string) $chave, 5)))] = (string) $valor;
        }
    }

    // O AUTHORIZATION QUE O APACHE ESCONDE (17/09/2026). Com mod_php ele nao vira
    // HTTP_AUTHORIZATION: o Basic chega desmontado em PHP_AUTH_USER e PHP_AUTH_PW,
    // ou em REDIRECT_HTTP_AUTHORIZATION quando o .htaccess o repassa. E por ele que
    // o Basic da Dashboard do Pagar.me confere.
    if (!isset($cabecalhos['authorization'])) {
        if (trim((string) ($servidor['REDIRECT_HTTP_AUTHORIZATION'] ?? '')) !== '') {
            $cabecalhos['authorization'] = (string) $servidor['REDIRECT_HTTP_AUTHORIZATION'];
        } elseif (isset($servidor['PHP_AUTH_USER'])) {
            $cabecalhos['authorization'] = 'Basic ' . base64_encode(
                (string) $servidor['PHP_AUTH_USER'] . ':' . (string) ($servidor['PHP_AUTH_PW'] ?? '')
            );
        }
    }

    // O TOKEN DA URL (16/09/2026): quem nao assina o aviso (Inter, C6,
    // InfinitePay) confere pelo `t=` que o membro poe na URL do portal. Ele
    // vira o cabecalho sintetico x-shield-token -- e SO ele: um cabecalho
    // HTTP de verdade com esse nome e apagado, senao qualquer um forjaria o
    // token sem conhecer a URL.
    unset($cabecalhos[\Shield\Cobranca\TokenWebhook::CABECALHO]);
    $query = array();
    parse_str((string) ($servidor['QUERY_STRING'] ?? ''), $query);
    if (isset($query['t']) && is_string($query['t']) && trim($query['t']) !== '') {
        // O INTER ACRESCENTA "/pix" A URL CADASTRADA no aviso de PIX (o callback
        // vai para webhookUrl/pix -- developers.inter.co, 16/09/2026). Com o
        // token no fim da query ele chega como "abc/pix"; o sufixo sai, e o
        // segredo nunca leva barra.
        $cabecalhos[\Shield\Cobranca\TokenWebhook::CABECALHO] = (string) preg_replace('#/pix$#', '', trim($query['t']));
    }

    // O data.id DA URL DO MERCADO PAGO (17/09/2026): a assinatura dele e
    // calculada sobre o id que vem na query (?data.id=...), e o adaptador so ve
    // cabecalhos. O parse_str troca o ponto do nome por sublinhado. Mesma regra
    // do token: um cabecalho HTTP de verdade com esse nome e apagado.
    unset($cabecalhos[\Shield\Cobranca\Provedores\MercadoPago::CABECALHO_DATA_ID]);
    if (isset($query['data_id']) && is_string($query['data_id']) && trim($query['data_id']) !== '') {
        $cabecalhos[\Shield\Cobranca\Provedores\MercadoPago::CABECALHO_DATA_ID] = trim($query['data_id']);
    }

    return $cabecalhos;
}

// A "ponte" entre os dois motores (shield_webhook_ponte) morou aqui de
// 04/09/2026 a 10/09/2026: o motor novo olhava o aviso primeiro e, se nao o
// reconhecesse, o antigo (tabela `pedido`) tentava dar baixa. Saiu junto com
// o motor antigo; os webhooks chamam shield_webhook_receber direto.

// ------------------------------------------------------------- conciliacao ---

/**
 * A cobranca que um aviso cita pela referencia `shield-<id>`, ou null.
 *
 * So vale quando a cobranca TEM tentativa naquele provedor: um aviso de um
 * gateway nao fala de cobranca emitida noutro.
 */
function shield_cobranca_por_referencia(PDO $pdo, $nomeProvedor, $corpo)
{
    if (!preg_match('/shield-(\d{1,10})/', (string) $corpo, $achado)) {
        return null;
    }

    $stmt = $pdo->prepare(
        'SELECT fk_cobranca FROM cobranca_tentativa
          WHERE provedor = :p AND fk_cobranca = :c ORDER BY id DESC LIMIT 1'
    );
    $stmt->execute(array(':p' => (string) $nomeProvedor, ':c' => (int) $achado[1]));
    $id = $stmt->fetchColumn();

    return $id === false ? null : (int) $id;
}

/**
 * A ordem em que a conciliacao pergunta -- 11/09/2026.
 *
 * QUEM ESTA HA MAIS TEMPO SEM SER OLHADA VEM PRIMEIRO, e quem nunca foi vem
 * antes de todas. Antes a ordem era por vencimento mais antigo, com lote fixo:
 * um punhado de cobrancas vencidas que ninguem vai pagar ocupava o lote inteiro
 * em toda rodada, e a que venceu ontem -- a que tem chance de estar paga --
 * nunca era perguntada. O defeito nao era de cartao: era de fila.
 */
function shield_cobranca_fila_de_conciliacao(PDO $pdo, $lote = SHIELD_CONCILIA_LOTE)
{
    $stmt = $pdo->prepare(
        'SELECT c.id
           FROM cobranca c
           JOIN cobranca_tentativa t ON t.fk_cobranca = c.id
          WHERE c.situacao IN (:aberta, :vencida)
            AND t.id_externo IS NOT NULL AND t.id_externo <> ""
          GROUP BY c.id
          ORDER BY (c.conferida_em IS NULL) DESC, c.conferida_em ASC, c.vencimento ASC
          LIMIT ' . max(1, min(200, (int) $lote))
    );
    $stmt->execute(array(':aberta' => SHIELD_COB_ABERTA, ':vencida' => SHIELD_COB_VENCIDA));

    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

/**
 * Vai perguntar ao provedor sobre as cobrancas que continuam abertas.
 *
 * NUM PAINEL SEM PROCESSO RESIDENTE ELA NAO E REDE DE SEGURANCA: E A PECA
 * PRINCIPAL. Webhook se perde -- o provedor tenta, a hospedagem estava fora, e
 * ele desiste. Sem alguem indo perguntar, o pagamento nunca aparece e o cliente
 * fica cobrado de uma coisa que pagou.
 *
 * O lote e pequeno de proposito: ela roda na requisicao de quem abriu o painel,
 * e ninguem pode esperar quarenta idas a rede para a tela carregar.
 */
function shield_cobranca_conciliar(PDO $pdo, $lote = SHIELD_CONCILIA_LOTE)
{
    $olhadas = 0;
    $mudaram = 0;
    foreach (shield_cobranca_fila_de_conciliacao($pdo, $lote) as $id) {
        $olhadas++;
        // A MARCA VEM ANTES DA PERGUNTA, de proposito: provedor fora do ar
        // deixaria a cobranca sem marca nenhuma e ela voltaria para a frente da
        // fila na rodada seguinte, prendendo o lote outra vez. Perder uma volta
        // e melhor do que travar a fila.
        $pdo->prepare('UPDATE cobranca SET conferida_em = NOW() WHERE id = :id')
            ->execute(array(':id' => (int) $id));
        try {
            $antes = shield_cob_ler($pdo, $id);
            shield_cobranca_consultar($pdo, $id);
            $depois = shield_cob_ler($pdo, $id);
            if ($antes && $depois && $antes['situacao'] !== $depois['situacao']) {
                $mudaram++;
            }
        } catch (Throwable $ignorado) {
            // Provedor fora do ar nao pode derrubar a rodada inteira: a
            // proxima passada tenta de novo.
        }
    }

    return array('olhadas' => $olhadas, 'mudaram' => $mudaram);
}
