<?php

// A regua de cobranca - 25/08/2026.
//
// COBRANCA AUTOMATICA SEM REGUA E CORTE AUTOMATICO. Por isso ela existe desde o
// primeiro dia e nao "depois que estabilizar": lembra antes, avisa no dia,
// insiste, da CARENCIA, e so entao chega perto de suspender.
//
// E ela NAO SUSPENDE SOZINHA por padrao. O passo de suspensao PROPOE; quem
// aperta o botao e o membro. Suspender desliga o caixa de uma loja, e a
// assimetria vale aqui inteira: estender exige prova, suspender exige
// deliberacao. Quem quiser automatico liga na tela -- e a decisao fica dele,
// registrada.
//
// NADA AQUI SUSPENDE POR SILENCIO. A regua so olha cobranca que EXISTE e esta
// vencida. Gateway fora do ar, webhook perdido, cron que nao rodou e fila
// parada nao produzem cobranca vencida nenhuma -- produzem ausencia, e ausencia
// nao suspende.

require_once __DIR__ . '/../licenca/validade.php';
require_once __DIR__ . '/cobranca_motor.php';

const SHIELD_REGUA_CHAVE_AUTOMATICA = 'regua_suspensao_automatica';

function shield_regua_passos(PDO $pdo, $somenteAtivos = true)
{
    try {
        $sql = 'SELECT * FROM regua_passo' . ($somenteAtivos ? ' WHERE ativo = 1' : '')
            . ' ORDER BY dias';

        return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: array();
    } catch (Throwable $ignorado) {
        return array();
    }
}

/** Apaga um passo da regua (10/09/2026, noite). Fica no livro: o passo apagado e a unica copia. */
function shield_regua_remover_passo(PDO $pdo, $id)
{
    $stmt = $pdo->prepare('SELECT * FROM regua_passo WHERE id = :id');
    $stmt->execute(array(':id' => (int) $id));
    $p = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!is_array($p)) {
        return false;
    }
    $pdo->prepare('DELETE FROM regua_passo WHERE id = :id')->execute(array(':id' => (int) $id));
    shield_auditar($pdo, 'regua_passo_removido', array(
        'alvo_tipo' => 'regua_passo', 'alvo_id' => (int) $id, 'antes' => json_encode($p),
        'detalhe' => 'passo ' . (int) $p['dias'] . ' dia(s), ' . (string) $p['acao'] . ' removido',
    ));

    return true;
}

function shield_regua_suspensao_automatica(PDO $pdo)
{
    return trim((string) shield_get_system_meta($pdo, SHIELD_REGUA_CHAVE_AUTOMATICA, '0')) === '1';
}

const SHIELD_REGUA_CHAVE_REEMISSAO = 'regua_reemissao_automatica';

/**
 * Multa e juros SOZINHOS -- 10/09/2026, tarde. O valor de uma cobranca
 * emitida nao anda por baixo do PIX que o cliente tem na mao (ver a nota
 * da mensalidade composta); o que anda e a ACAO de reemitir, que cancela o codigo antigo
 * no provedor e emite o de hoje. Ate aqui era clique do membro. Ligado isto,
 * a rotina diaria faz o clique: para cada vencida com encargo pendente,
 * reemite -- e so mexe se o provedor cancelar o antigo. Como o ERP mostra o
 * codigo ATUAL a cada abertura, o cliente nunca fica com codigo morto.
 *
 * Nasce desligado: atualizar o painel nao pode fazer cobranca subir sozinha.
 */
function shield_regua_reemissao_automatica(PDO $pdo)
{
    return trim((string) shield_get_system_meta($pdo, SHIELD_REGUA_CHAVE_REEMISSAO, '0')) === '1';
}

function shield_regua_definir_reemissao(PDO $pdo, $ligada)
{
    shield_set_system_meta($pdo, SHIELD_REGUA_CHAVE_REEMISSAO, $ligada ? '1' : '0');
    shield_auditar($pdo, 'regua_reemissao_automatica', array(
        'depois' => $ligada ? 'ligada' : 'desligada',
        'detalhe' => $ligada
            ? 'a rotina passa a reemitir as vencidas com multa e juros sozinha'
            : 'multa e juros voltam a entrar so no clique de reemitir',
    ));
}

/** Reemite as vencidas com encargo pendente. Desligada, nao toca em nada. */
function shield_regua_reemitir_vencidas(PDO $pdo)
{
    $feito = array('reemitidas' => 0, 'puladas' => 0, 'falhas' => 0);
    if (!shield_regua_reemissao_automatica($pdo)) {
        return $feito;
    }
    require_once __DIR__ . '/cobranca_motor2.php';
    require_once __DIR__ . '/encargos.php';

    $stmt = $pdo->prepare('SELECT * FROM cobranca WHERE situacao = :v ORDER BY id');
    $stmt->execute(array(':v' => SHIELD_COB_VENCIDA));
    $primeiroCodigo = $pdo->prepare(
        "SELECT MIN(criado_em) FROM cobranca_tentativa WHERE fk_cobranca = :c AND COALESCE(id_externo, '') <> ''"
    );
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $c) {
        try {
            if (shield_encargos_pendentes($pdo, $c) <= 0) {
                $feito['puladas']++;
                continue;
            }
            $tentativa = shield_cobranca_ultima_tentativa($pdo, (int) $c['id']);
            if ($tentativa === null || trim((string) $tentativa['id_externo']) === '') {
                $feito['puladas']++;   // nunca foi ao provedor: nao ha codigo a trocar
                continue;
            }
            if ((string) $tentativa['provedor'] === 'dinheiro') {
                // DINHEIRO NAO TEM CODIGO NA RUA (15/09/2026): reemitir so abria
                // outra tentativa DIN<id> a cada dia de juros. O valor com encargo
                // aparece na tela, e quem recebe no balcao decide.
                $feito['puladas']++;
                continue;
            }
            // O PRIMEIRO CODIGO SAIU DEPOIS DO VENCIMENTO (15/09/2026): o cliente
            // nunca teve como pagar em dia -- ciclo gerado com o relogio atrasado,
            // ou fatura que ficou em rascunho. Provado num MySQL 8.4: a mesma
            // passada emitia sem encargo (4.1.21) e ja reemitia com multa, antes
            // de o cliente ver o primeiro PIX. Reemitir a mao continua.
            $primeiroCodigo->execute(array(':c' => (int) $c['id']));
            $saiu = substr((string) $primeiroCodigo->fetchColumn(), 0, 10);
            if ($saiu !== '' && $saiu > substr((string) $c['vencimento'], 0, 10)) {
                $feito['puladas']++;
                continue;
            }
            shield_cobranca_reemitir($pdo, (int) $c['id']);
            $feito['reemitidas']++;
        } catch (Throwable $e) {
            $feito['falhas']++;      // provedor nao cancelou, ou caiu: fica para amanha
        }
    }

    return $feito;
}

function shield_regua_definir_automatica(PDO $pdo, $ligada)
{
    shield_set_system_meta($pdo, SHIELD_REGUA_CHAVE_AUTOMATICA, $ligada ? '1' : '0');
    shield_auditar($pdo, 'regua_suspensao_automatica', array(
        'depois' => $ligada ? 'ligada' : 'desligada',
        'detalhe' => $ligada
            ? 'a regua passa a suspender sozinha ao fim do prazo'
            : 'a regua passa a apenas propor a suspensao',
    ));
}

/**
 * Passa a regua. Devolve o que fazer com cada cliente -- e faz o que for
 * seguro fazer sozinho.
 *
 * O que ela FAZ sozinha: marcar vencidas, e (se o membro tiver ligado)
 * suspender.
 * O que ela PROPOE: os avisos, que a fase do canal com o ERP e do e-mail
 * entrega, e a suspensao quando o automatico esta desligado.
 *
 * $somenteMostrar: a TELA da regua chama esta funcao so para desenhar a lista,
 * e com o automatico ligado ela re-suspendia na mesma requisicao quem o membro
 * acabara de liberar (11/09/2026). Quem suspende de verdade e o relogio.
 */
function shield_regua_passar(PDO $pdo, $somenteMostrar = false)
{
    shield_cobranca_marcar_vencidas($pdo);

    $passos = shield_regua_passos($pdo);
    if ($passos === array()) {
        return array('avisos' => array(), 'suspensoes' => array(), 'propostas' => array());
    }

    $automatica = shield_regua_suspensao_automatica($pdo) && !$somenteMostrar;

    $stmt = $pdo->prepare(
        'SELECT c.id, c.fk_empresa, c.descricao, c.valor_centavos, c.vencimento,
                c.situacao, e.razao, e.cnpj, e.email, e.suspenso_em
           FROM cobranca c
           JOIN empresa e ON e.codigo = c.fk_empresa
          WHERE c.situacao IN (:aberta, :vencida)
          ORDER BY c.vencimento'
    );
    $stmt->execute(array(':aberta' => SHIELD_COB_ABERTA, ':vencida' => SHIELD_COB_VENCIDA));

    $hoje = new DateTimeImmutable('today');
    $avisos = array();
    $suspensoes = array();
    $propostas = array();

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $c) {
        $vence = new DateTimeImmutable((string) $c['vencimento']);
        $dias = (int) $hoje->diff($vence)->format('%r%a') * -1;   // positivo = atrasada

        foreach ($passos as $passo) {
            if ($dias !== (int) $passo['dias']) {
                continue;
            }

            $ehSuspender = (string) $passo['acao'] === 'suspender';

            if ($ehSuspender && !empty($c['suspenso_em'])) {
                continue;      // ja esta suspenso; nem aviso nem proposta de novo
            }

            // O TEXTO DO PASSO VAI SEMPRE, inclusive no 'suspender' -- corrigido
            // em 09/09/2026. Antes o ramo de suspensao saia do laco com
            // um `continue` ANTES desta linha, e o "Aviso final antes da
            // suspensao" -- que e o padrao de fabrica desse passo e que o
            // membro edita na tela -- nunca chegou a e-mail nenhum. O cliente
            // era suspenso sem ouvir a ultima palavra, que e justamente a que
            // diz a data em que o sistema para.
            $avisos[] = array(
                'cobranca' => $c,
                'acao' => (string) $passo['acao'],
                'texto' => (string) $passo['texto'],
                'dias' => $dias,
            );

            if ($ehSuspender) {
                if ($automatica) {
                    if (shield_validade_suspender($pdo, (int) $c['fk_empresa'],
                            'regua: ' . $dias . ' dia(s) de atraso na cobranca ' . $c['id'])) {
                        $suspensoes[] = $c;
                    }
                } else {
                    // O padrao. A regua chega ate aqui e PARA.
                    $propostas[] = $c;
                }
            }
        }
    }

    return array('avisos' => $avisos, 'suspensoes' => $suspensoes, 'propostas' => $propostas);
}

/**
 * O aviso da regua sai UMA VEZ por cobranca e por passo -- 08/10/2026.
 *
 * shield_regua_passar devolve todo aviso cujo passo bate com os dias de atraso
 * de HOJE, e nao guarda nada: o cron a cada 5 minutos (o que o README manda)
 * enfileirava o mesmo e-mail em toda passada daquele dia, ate 288 vezes para o
 * cliente final. Achado ao rodar o cron real na bancada com o Mailpit: a segunda
 * passada, segundos depois da primeira, enfileirou os mesmos dois avisos.
 *
 * A marca mora no livro (`regua_aviso_enviado`, alvo a cobranca, detalhe o
 * passo): indexado por alvo, e de quebra o membro ve quando o cliente foi
 * avisado. So se marca o que foi para a fila -- cliente sem e-mail nao gasta o
 * passo, e quem preencher o e-mail no mesmo dia ainda recebe.
 */
function shield_regua_aviso_detalhe(array $aviso)
{
    return 'passo ' . (int) $aviso['dias'] . ' dia(s): ' . (string) $aviso['acao'];
}

function shield_regua_aviso_ja_enviado(PDO $pdo, array $aviso)
{
    try {
        $st = $pdo->prepare(
            "SELECT 1 FROM auditoria
              WHERE acao = 'regua_aviso_enviado' AND alvo_tipo = 'cobranca' AND alvo_id = :c AND detalhe = :d
              LIMIT 1"
        );
        $st->execute(array(':c' => (string) (int) $aviso['cobranca']['id'], ':d' => shield_regua_aviso_detalhe($aviso)));

        return $st->fetchColumn() !== false;
    } catch (Throwable $semTabela) {
        // Sem o livro nao ha como saber: melhor um aviso a mais do que nenhum.
        return false;
    }
}

function shield_regua_aviso_marcar(PDO $pdo, array $aviso, $para)
{
    shield_auditar($pdo, 'regua_aviso_enviado', array(
        'alvo_tipo' => 'cobranca', 'alvo_id' => (int) $aviso['cobranca']['id'],
        'depois' => (string) $para, 'ator' => 'rotina',
        'detalhe' => shield_regua_aviso_detalhe($aviso),
    ));
}
