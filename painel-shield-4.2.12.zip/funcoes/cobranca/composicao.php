<?php

/**
 * A composicao da mensalidade -- 09/09/2026.
 *
 * Ate aqui o valor da cobranca vinha inteiro do plano ou da assinatura. Tudo o
 * que fugisse disso o membro somava a mao ou nao cobrava -- e o levantamento de
 * 08/09/2026 mostrou que isso e a maioria: DEZOITO das quarenta e tres
 * softwarehouses cobram terminal adicional todo mes, na unha, e NOVE vendem por
 * modulos.
 *
 * A mensalidade passa a ser BASE + ITENS:
 *
 *   base     -- o plano ou a assinatura, como sempre foi;
 *   modulos  -- o que o cliente contratou alem do basico;
 *   terminal -- maquina que quer trabalhar e nao cabe na cota.
 *
 * ---------------------------------------------------------------------------
 * A DECISAO QUE MAIS IMPORTA AQUI: qual e a base do terminal adicional.
 *
 * E O CONTRATADO, nunca o recusado. A primeira versao deste arquivo cobrava por
 * maquina RECUSADA pela cota, e a conta andava para tras: o membro aumentava a
 * cota para a loja trabalhar, a maquina parava de ser recusada, a recusa saia
 * da janela e A FATURA DIMINUIA. Liberar custava menos do que barrar.
 *
 * Sao dois numeros:
 *
 *   terminais_inclusos -- quantos o valor do plano ja cobre;
 *   nterminais         -- quantos a licenca de fato libera.
 *
 * Cobra-se a diferenca. Subiu a cota, subiu a fatura; baixou, baixou. A conta
 * acompanha a decisao, e a decisao e do membro -- que e como os dezoito relatos
 * descrevem: "o valor padrao cobre ate 3 PDVs; a partir do 4o, a gente cobra um
 * valor de PDV adicional".
 *
 * A RECUSA CONTINUA SENDO MEDIDA, em shield_composicao_batendo_na_porta, mas
 * como AVISO DE VENDA e nao como fatura: "tem maquina querendo entrar". Cobrar
 * por ela seria faturar uma maquina que nao trabalha.
 * ---------------------------------------------------------------------------
 *
 * FALHA ABERTO em tudo: base sem as tabelas novas cobra a base e mais nada.
 * Cliente que nao consegue pagar a mensalidade porque o painel nao soube somar
 * um modulo e um estrago maior do que deixar de faturar o adicional do mes.
 */

require_once __DIR__ . '/../licenca/parque.php';   // SHIELD_PARQUE_DIAS_SUMIDO

/**
 * Quantos dias para tras a recusa ainda conta como "maquina que quer
 * trabalhar". Um mes: e o ciclo da propria mensalidade.
 */
const SHIELD_COMPOSICAO_JANELA_DIAS = 30;

/**
 * Os modulos que este cliente tem contratados AGORA.
 *
 * O valor cobrado e o COPIADO no contrato, e nao o do catalogo: reajustar a
 * tabela nao pode reajustar sozinho quem fechou por outro preco. E o mesmo
 * motivo de cobranca.valor_centavos ser copiado do plano.
 */
function shield_composicao_modulos(PDO $pdo, int $empresa): array
{
    try {
        $stmt = $pdo->prepare(
            'SELECT em.id, em.valor_centavos, m.nome
               FROM empresa_modulo em
               JOIN modulo m ON m.id = em.fk_modulo
              WHERE em.fk_empresa = :emp AND em.ate IS NULL
              ORDER BY m.nome'
        );
        $stmt->execute(array(':emp' => $empresa));

        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
    } catch (Throwable $semTabela) {
        return array();
    }
}

/**
 * Quantos terminais este cliente contratou ALEM do que o plano dele cobre.
 *
 * E esta a base da cobranca, e nao a recusa -- ver o cabecalho deste arquivo.
 *
 * Cota zero e o cliente em DEMONSTRACAO: licenca liberada para todo mundo, sem
 * contrato de terminal nenhum. Cobrar adicional dele seria faturar cortesia.
 */
function shield_composicao_terminais_extras(PDO $pdo, int $empresa): int
{
    try {
        $stmt = $pdo->prepare(
            'SELECT COALESCE(nterminais, 0) AS cota,
                    COALESCE(terminais_inclusos, 0) AS inclusos
               FROM empresa WHERE codigo = :emp'
        );
        $stmt->execute(array(':emp' => $empresa));
        $linha = $stmt->fetch(PDO::FETCH_ASSOC) ?: array();

        $cota = (int) ($linha['cota'] ?? 0);
        if ($cota <= 0) {
            return 0;
        }

        return max(0, $cota - (int) ($linha['inclusos'] ?? 0));
    } catch (Throwable $semColuna) {
        // Base sem a 4.0.8: ninguem paga adicional, que e o estado de antes.
        return 0;
    }
}

/**
 * Quantas maquinas bateram e foram BARRADAS pela cota na janela.
 *
 * Isto e AVISO DE VENDA, e nao fatura: "tem maquina querendo entrar, quer
 * liberar?". Foi base de cobranca por algumas horas em 09/09/2026 e estava
 * errado -- ver o cabecalho deste arquivo.
 */
function shield_composicao_batendo_na_porta(PDO $pdo, int $empresa): int
{
    try {
        // DISTINCT pela impressao: a mesma maquina insistindo todo dia e uma
        // maquina, nao trinta. Impressao vazia nao vira maquina propria --
        // linha antiga sem fingerprint agruparia tudo num terminal fantasma.
        $stmt = $pdo->prepare(
            'SELECT COUNT(DISTINCT fingerprint) FROM terminal_batida
              WHERE fk_empresa = :emp
                AND resultado = :res
                AND fingerprint IS NOT NULL AND fingerprint <> \'\'
                AND batido_em > (NOW() - INTERVAL ' . (int) SHIELD_COMPOSICAO_JANELA_DIAS . ' DAY)'
        );
        $stmt->execute(array(':emp' => $empresa, ':res' => 'excedente'));

        return (int) $stmt->fetchColumn();
    } catch (Throwable $semTabela) {
        return 0;
    }
}

/**
 * A mensalidade inteira deste cliente.
 *
 * Devolve ['base' => int, 'itens' => array, 'total' => int]. Cada item tem
 * tipo, descricao, valor e -- no terminal -- quantidade.
 *
 * A LISTA DE ITENS E O PRODUTO, tanto quanto o total: e ela que vai para a
 * descricao da cobranca, e e por ela que o cliente entende por que o PIX deste
 * mes veio diferente do plano que ele contratou.
 */
function shield_composicao_do_cliente(PDO $pdo, int $empresa, int $baseCentavos, int $vezes = 1): array
{
    // $vezes e o CICLO da assinatura (11/09/2026): modulo e terminal extra sao
    // precos por mes, e a cobranca de um semestre cobre seis deles. Ate aqui
    // entravam uma vez por fatura, qualquer que fosse o ciclo.
    $vezes = max(1, $vezes);
    $itens = array();

    foreach (shield_composicao_modulos($pdo, $empresa) as $m) {
        $valor = (int) $m['valor_centavos'];
        if ($valor === 0) {
            // Modulo cortesia: aparece no cadastro, nao aparece na fatura.
            continue;
        }
        $itens[] = array(
            'tipo' => 'modulo',
            'descricao' => (string) $m['nome'] . ($vezes > 1 ? ' x' . $vezes : ''),
            'valor' => $valor * $vezes,
        );
    }

    $extras = shield_composicao_terminais_extras($pdo, $empresa);
    if ($extras > 0) {
        try {
            $stmt = $pdo->prepare('SELECT valor_terminal_centavos FROM empresa WHERE codigo = :e');
            $stmt->execute(array(':e' => $empresa));
            $preco = (int) $stmt->fetchColumn();
        } catch (Throwable $semColuna) {
            $preco = 0;
        }

        // Zero e "nao cobro terminal", e e o padrao de quem nunca configurou.
        if ($preco > 0) {
            $itens[] = array(
                'tipo' => 'terminal',
                'descricao' => $extras . ' terminal(is) alem do contratado' . ($vezes > 1 ? ' x' . $vezes : ''),
                'quantidade' => $extras,
                'valor' => $preco * $extras * $vezes,
            );
        }
    }

    $total = $baseCentavos;
    foreach ($itens as $i) {
        $total += (int) $i['valor'];
    }

    return array('base' => $baseCentavos, 'itens' => $itens, 'total' => $total);
}

/**
 * A composicao em uma frase, para a descricao da cobranca.
 * Sem itens devolve vazio -- cobranca simples continua com a descricao simples.
 */
function shield_composicao_frase(array $composicao): string
{
    if (empty($composicao['itens'])) {
        return '';
    }

    $partes = array();
    foreach ($composicao['itens'] as $i) {
        $partes[] = $i['descricao'];
    }

    return implode(', ', $partes);
}
