<?php

// Cobranca -- esqueleto e dinheiro - 25/08/2026.
//
// Esta e a fase do ESQUEMA: as tabelas, a conversao do que ja existia e as
// contas de dinheiro. O motor -- interface de provedor, fila, webhook e
// conciliacao -- vem na fase seguinte, e vai encostar aqui.
//
// DINHEIRO E INTEIRO EM CENTAVOS, SEMPRE. Nao ha float em lugar nenhum deste
// caminho: 0,1 + 0,2 nao da 0,3 em ponto flutuante, e num sistema que soma
// mensalidade isso aparece como um centavo que ninguem explica. A tabela
// `planos` que ja existia guarda valor em VARCHAR -- e o tipo de escolha que
// se paga depois, e por isso a nova nao a repete.

require_once __DIR__ . '/../contrato/assinatura_a1.php';   // shield_encrypt_secret / _decrypt_

// Os provedores que o painel conhece. As capacidades sao o PADRAO da casa: a
// conta pode reduzi-las, nunca inventa-las.
//
// pix_estatico e dinheiro entram aqui como provedores de verdade, de proposito.
// Assim a tela, a regua e o historico tratam os tres iguais, e o que muda e so
// quem confirma o pagamento. Sem isso, "cobranca manual" viraria um caminho
// paralelo com regras proprias -- e regra que existe em dois lugares diverge.
function shield_cobranca_provedores()
{
    return array(
        'asaas' => array(
            'nome' => 'Asaas', 'automatico' => true,
            'pix' => 1, 'boleto' => 1, 'cartao' => 1, 'assinatura' => 1,
        ),
        'mercadopago' => array(
            'nome' => 'Mercado Pago', 'automatico' => true,
            'pix' => 1, 'boleto' => 1, 'cartao' => 1, 'assinatura' => 1,
        ),
        // O NOME MUDOU, O CODIGO NAO: contas antigas guardam 'pagseguro' e
        // o Registro aponta as duas para o mesmo adaptador. Aqui fica so o
        // 'pagbank', que e o que o membro le ao criar conta nova.
        'pagbank' => array(
            'nome' => 'PagBank', 'automatico' => true,
            'pix' => 1, 'boleto' => 1, 'cartao' => 1, 'assinatura' => 0,
        ),
        'pagseguro' => array(
            'nome' => 'PagBank (cadastro antigo)', 'automatico' => true,
            'pix' => 1, 'boleto' => 1, 'cartao' => 1, 'assinatura' => 0,
        ),
        'pagarme' => array(
            'nome' => 'Pagar.me (Stone)', 'automatico' => true,
            'pix' => 1, 'boleto' => 1, 'cartao' => 1, 'assinatura' => 0,
        ),
        // A Efi so faz PIX neste painel: boleto e cartao dela sao outra API,
        // sem mTLS. Declarar o que o adaptador NAO faz e o que impede a tela
        // de oferecer o que ela nao entrega.
        'efi' => array(
            'nome' => 'Efi', 'automatico' => true,
            'pix' => 1, 'boleto' => 0, 'cartao' => 0, 'assinatura' => 0,
        ),
        'cora' => array(
            'nome' => 'Cora', 'automatico' => true,
            'pix' => 1, 'boleto' => 1, 'cartao' => 0, 'assinatura' => 0,
        ),
        // Os tres de 16/09/2026 vieram de membros. Inter e InfinitePay tem
        // uso real em campo; o C6 NINGUEM rodou (o membro nao conseguiu
        // ativar a cobranca na conta). Nenhum faz assinatura recorrente.
        'inter' => array(
            'nome' => 'Banco Inter', 'automatico' => true,
            'pix' => 1, 'boleto' => 1, 'cartao' => 0, 'assinatura' => 0,
        ),
        'c6bank' => array(
            'nome' => 'C6 Bank', 'automatico' => true,
            'pix' => 1, 'boleto' => 1, 'cartao' => 0, 'assinatura' => 0,
        ),
        // A InfinitePay e um link de checkout: PIX ou cartao, quem escolhe e o
        // cliente na pagina dela.
        'infinitepay' => array(
            'nome' => 'InfinitePay', 'automatico' => true,
            'pix' => 1, 'boleto' => 0, 'cartao' => 1, 'assinatura' => 0,
        ),
        // O Conta Azul (16/09/2026) e um ERP: a cobranca nasce presa a uma
        // parcela de venda, sem webhook (a conciliacao descobre o pagamento) e
        // com token OAuth2 autorizado no navegador. Escrito pela documentacao;
        // ninguem rodou contra a API.
        'contaazul' => array(
            'nome' => 'Conta Azul', 'automatico' => true,
            'pix' => 1, 'boleto' => 1, 'cartao' => 1, 'assinatura' => 0,
        ),
        // Os nomes levam acento DE VERDADE, e nao entidade HTML: eles passam
        // por shield_h() em toda tela que os mostra, e entidade escapada duas
        // vezes vira "&ccedil;" impresso. E texto de tela, nao codigo.
        'pix_estatico' => array(
            'nome' => 'PIX estático (confirmação manual)', 'automatico' => false,
            'pix' => 1, 'boleto' => 0, 'cartao' => 0, 'assinatura' => 0,
        ),
        'dinheiro' => array(
            'nome' => 'Dinheiro em espécie (confirmação manual)', 'automatico' => false,
            'pix' => 0, 'boleto' => 0, 'cartao' => 0, 'assinatura' => 0,
        ),
    );
}

// ----------------------------------------------------------------- dinheiro ---

/**
 * Texto do operador -> centavos. Aceita "1.234,56", "1234.56", "1234" e "R$ 10".
 *
 * A conversao e feita em INTEIRO no fim (round), nunca deixando o float
 * atravessar: (int) (10.15 * 100) da 1014 em ponto flutuante binario.
 */
function shield_centavos($texto)
{
    if (is_int($texto)) {
        return $texto;
    }

    $t = trim((string) $texto);
    if ($t === '') {
        return 0;
    }

    $t = preg_replace('/[^0-9,.\-]/', '', $t);

    // Duas pontuacoes: a ULTIMA e a decimal, a outra e separador de milhar.
    $ultimaVirgula = strrpos($t, ',');
    $ultimoPonto = strrpos($t, '.');

    if ($ultimaVirgula !== false && $ultimoPonto !== false) {
        if ($ultimaVirgula > $ultimoPonto) {
            $t = str_replace(array('.', ','), array('', '.'), $t);
        } else {
            $t = str_replace(',', '', $t);
        }
    } elseif ($ultimaVirgula !== false) {
        $t = str_replace(',', '.', $t);
    } elseif ($ultimoPonto !== false) {
        // SO PONTO, e ai o texto e ambiguo: quem digita "1.234" no Brasil quer
        // mil duzentos e trinta e quatro reais, e quem cola "1234.56" de outro
        // sistema quer os centavos. O que separa os dois e o tamanho do ultimo
        // grupo -- tres digitos e milhar, um ou dois e centavo.
        //
        // NAO simplificar para "ponto e sempre decimal": e o caminho por onde
        // R$ 1.234,00 vira R$ 1,23 sem ninguem perceber.
        $depois = substr($t, $ultimoPonto + 1);
        $milhar = (substr_count($t, '.') > 1) || (strlen($depois) === 3 && ctype_digit($depois));
        if ($milhar) {
            $t = str_replace('.', '', $t);
        }
    }

    return (int) round(((float) $t) * 100);
}

/** Centavos -> texto do operador. Nao inventa "R$": quem decide e a tela. */
function shield_dinheiro($centavos)
{
    return number_format(((int) $centavos) / 100, 2, ',', '.');
}

// ------------------------------------------------------------------ contas ---

function shield_cobranca_tabelas_existem(PDO $pdo)
{
    try {
        $pdo->query('SELECT 1 FROM conta_recebimento LIMIT 1');

        return true;
    } catch (Throwable $ignorado) {
        return false;
    }
}

/** As credenciais saem do cofre so na hora de usar, nunca na listagem. */
function shield_cobranca_credenciais(array $conta)
{
    $cifrado = trim((string) ($conta['credenciais'] ?? ''));
    if ($cifrado === '') {
        return array();
    }

    try {
        $texto = shield_decrypt_secret($cifrado);
    } catch (Throwable $ignorado) {
        return array();
    }

    $dados = json_decode((string) $texto, true);

    return is_array($dados) ? $dados : array();
}

function shield_cobranca_guardar_credenciais(array $credenciais)
{
    $limpo = array();
    foreach ($credenciais as $chave => $valor) {
        $valor = trim((string) $valor);
        if ($valor !== '') {
            $limpo[(string) $chave] = $valor;
        }
    }

    if ($limpo === array()) {
        return null;
    }

    return shield_encrypt_secret(json_encode($limpo, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
}

/**
 * ALGUMAS CHAVES DA CREDENCIAL MUDAM SEM O MEMBRO DIGITAR -- 16/09/2026. O
 * refresh_token do Conta Azul rotaciona a cada renovacao e o antigo morre na
 * hora; o id do servico que o adaptador cria la e guardado para nao procurar
 * de novo. Entra por cima do que esta gravado, chave a chave: o resto fica.
 * Valor vazio no delta apaga a chave (shield_cobranca_guardar_credenciais
 * descarta o vazio). Devolve false quando a conta nao existe.
 */
function shield_cobranca_credenciais_mesclar(PDO $pdo, $contaId, array $delta)
{
    $conta = shield_cobranca_conta($pdo, (int) $contaId);
    if ($conta === null) {
        return false;
    }
    $atuais = shield_cobranca_credenciais($conta);
    foreach ($delta as $chave => $valor) {
        $atuais[(string) $chave] = (string) $valor;
    }
    $pdo->prepare('UPDATE conta_recebimento SET credenciais = :c WHERE id = :id')
        ->execute(array(':c' => shield_cobranca_guardar_credenciais($atuais), ':id' => (int) $contaId));

    return true;
}

function shield_cobranca_contas(PDO $pdo, $somenteAtivas = false)
{
    if (!shield_cobranca_tabelas_existem($pdo)) {
        return array();
    }

    $sql = 'SELECT * FROM conta_recebimento'
        . ($somenteAtivas ? ' WHERE ativo = 1' : '')
        . ' ORDER BY ativo DESC, provedor, apelido';

    return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: array();
}

function shield_cobranca_conta(PDO $pdo, $id)
{
    $stmt = $pdo->prepare('SELECT * FROM conta_recebimento WHERE id = :id LIMIT 1');
    $stmt->execute(array(':id' => (int) $id));
    $linha = $stmt->fetch(PDO::FETCH_ASSOC);

    return is_array($linha) ? $linha : null;
}

// --------------------------------------------------------------- auditoria ---

/**
 * O rastro. Chamada por quem mexe em dinheiro, validade ou bloqueio.
 *
 * NAO levanta excecao: auditoria que derruba a operacao que ela deveria
 * registrar e pior do que auditoria nenhuma. Quando ela falha, o que se perde e
 * a linha do livro -- e nao o pagamento do cliente.
 *
 * ATOR aceita nulo e vira "rotina": "quem estendeu a validade" precisa ter
 * resposta tambem quando quem estendeu foi a regua, sem ninguem na frente.
 */
function shield_auditar(PDO $pdo, $acao, array $dados = array())
{
    try {
        $usuario = $_SESSION['usuario'] ?? array();
        $ator = trim((string) ($dados['ator'] ?? ($usuario['nome'] ?? $usuario['login'] ?? '')));

        $stmt = $pdo->prepare(
            'INSERT INTO auditoria
                (ator, fk_usuario, acao, alvo_tipo, alvo_id, antes, depois, detalhe, ip, quando)
             VALUES (:ator, :usu, :acao, :tipo, :alvo, :antes, :depois, :detalhe, :ip, NOW())'
        );

        $texto = function ($v) {
            if ($v === null || $v === '') {
                return null;
            }

            return is_scalar($v) ? (string) $v
                : json_encode($v, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        };

        $stmt->execute(array(
            ':ator' => substr($ator !== '' ? $ator : 'rotina', 0, 80),
            ':usu' => isset($usuario['id']) ? (int) $usuario['id'] : null,
            ':acao' => substr((string) $acao, 0, 60),
            ':tipo' => substr((string) ($dados['alvo_tipo'] ?? ''), 0, 40) ?: null,
            ':alvo' => substr((string) ($dados['alvo_id'] ?? ''), 0, 40) ?: null,
            ':antes' => $texto($dados['antes'] ?? null),
            ':depois' => $texto($dados['depois'] ?? null),
            ':detalhe' => substr((string) ($dados['detalhe'] ?? ''), 0, 255) ?: null,
            ':ip' => substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45) ?: null,
        ));

        return true;
    } catch (Throwable $ignorado) {
        return false;
    }
}

// ---------------------------------------------------------------- conversao ---

/**
 * Traz para conta_recebimento o que ja estava configurado em `gateways`.
 *
 * O PONTO E O MEMBRO NAO REFAZER NADA. Ele ja tem conta de gateway ligada e
 * funcionando; a reforma nao pode custar a ele uma tarde reconfigurando
 * credencial que ele nem lembra onde guardou.
 *
 * IDEMPOTENTE: roda em todo acesso ao /update/ e nao duplica nem sobrescreve o
 * que ja foi convertido. Quem chegou depois -- credencial mudada no painel
 * velho -- nao volta atras: a conversao so cria o que falta.
 *
 * As credenciais entram CIFRADAS. A `gateways` guardava em texto puro, e uma
 * copia de banco vazada entregava a conta de recebimento do membro junto.
 */
function shield_cobranca_converter_contas(PDO $pdo)
{
    if (!shield_cobranca_tabelas_existem($pdo)) {
        return array('criadas' => 0, 'puladas' => 0);
    }

    $criadas = 0;
    $puladas = 0;

    // De cada gateway, o que interessa: qual campo e credencial de qual.
    $mapa = array(
        'asaas' => array('access_token', 'wallet_id', 'webhook_token'),
        'mercadopago' => array('access_token', 'public_key', 'client_id', 'client_secret', 'webhook_token'),
        'pagseguro' => array('ps_email', 'ps_token', 'webhook_token'),
        'efi' => array('efi_client_id', 'efi_client_secret', 'efi_pix_cert_base64',
                       'efi_pix_cert_password', 'efi_pix_key', 'webhook_token'),
        'cora' => array('client_id', 'client_secret', 'webhook_token'),
    );

    try {
        $antigos = $pdo->query('SELECT * FROM gateways')->fetchAll(PDO::FETCH_ASSOC) ?: array();
    } catch (Throwable $ignorado) {
        $antigos = array();
    }

    $existe = $pdo->prepare('SELECT COUNT(*) FROM conta_recebimento WHERE provedor = :p AND apelido = :a');
    $insere = $pdo->prepare(
        'INSERT INTO conta_recebimento
            (provedor, apelido, ambiente, ativo, credenciais,
             aceita_pix, aceita_boleto, aceita_cartao, aceita_assinatura, webhook_segredo)
         VALUES (:prov, :apelido, :amb, :ativo, :cred,
                 :pix, :boleto, :cartao, :assinatura, :segredo)'
    );

    $catalogo = shield_cobranca_provedores();

    foreach ($antigos as $linha) {
        $provedor = strtolower(trim((string) ($linha['gateway_name'] ?? '')));
        if ($provedor === '' || !isset($catalogo[$provedor])) {
            continue;
        }
        // Dinheiro e PIX na sua chave nunca foram gateway: a V4_0_4 ja os
        // instala, e converter uma linha antiga com esse nome DUPLICAVA o
        // dinheiro em especie (10/09/2026, noite).
        if (in_array($provedor, array('dinheiro', 'pix_estatico'), true)) {
            $puladas++;
            continue;
        }

        $existe->execute(array(':p' => $provedor, ':a' => $catalogo[$provedor]['nome']));
        if ((int) $existe->fetchColumn() > 0) {
            $puladas++;
            continue;
        }

        $credenciais = array();
        foreach ($mapa[$provedor] ?? array() as $campo) {
            if (isset($linha[$campo])) {
                $credenciais[$campo] = (string) $linha[$campo];
            }
        }

        // O ambiente vinha em tres colunas diferentes conforme o gateway --
        // producao, ps_sandbox, efi_sandbox. Aqui vira um campo so.
        $ehProducao = strtolower(trim((string) ($linha['producao'] ?? 'n'))) === 's';
        if ($provedor === 'pagseguro') {
            $ehProducao = strtolower(trim((string) ($linha['ps_sandbox'] ?? 'n'))) !== 's';
        } elseif ($provedor === 'efi') {
            $ehProducao = strtolower(trim((string) ($linha['efi_sandbox'] ?? 'n'))) !== 's';
        }

        // A capacidade sai do que ESTAVA marcado; nao havendo nada marcado,
        // cai no padrao do provedor. Conta convertida que chegasse sem nenhum
        // metodo nao emitiria cobranca nenhuma, e o membro nao saberia por que.
        $pix = (int) ($linha['pix_ativo'] ?? 0);
        $boleto = (int) ($linha['boleto_ativo'] ?? 0);
        $cartao = (int) ($linha['cartao_ativo'] ?? 0);
        if (!$pix && !$boleto && !$cartao) {
            $pix = (int) $catalogo[$provedor]['pix'];
            $boleto = (int) $catalogo[$provedor]['boleto'];
            $cartao = (int) $catalogo[$provedor]['cartao'];
        }

        $insere->execute(array(
            ':prov' => $provedor,
            ':apelido' => $catalogo[$provedor]['nome'],
            ':amb' => $ehProducao ? 'producao' : 'teste',
            ':ativo' => (int) !empty($linha['active']),
            ':cred' => shield_cobranca_guardar_credenciais($credenciais),
            ':pix' => $pix,
            ':boleto' => $boleto,
            ':cartao' => $cartao,
            ':assinatura' => (int) $catalogo[$provedor]['assinatura'],
            ':segredo' => (string) ($linha['webhook_token'] ?? '') ?: null,
        ));
        $criadas++;
    }

    // Os dois manuais existem em toda instalacao, desligados. Sao a saida de
    // quem nao tem conta de gateway -- e o membro que so recebe PIX na chave
    // dele e dinheiro no balcao e a maioria, nao a excecao.
    // POR PROVEDOR, e nao por nome (10/09/2026, noite): a V4_0_4 instala o
    // dinheiro como "Dinheiro em especie", sem o "(confirmacao manual)" do
    // catalogo, e conferir pelo nome fazia TODA instalacao nova nascer com
    // dois dinheiros -- este conversor roda no /update da instalacao.
    $existeProvedor = $pdo->prepare('SELECT COUNT(*) FROM conta_recebimento WHERE provedor = :p');
    foreach (array('pix_estatico', 'dinheiro') as $provedor) {
        $existeProvedor->execute(array(':p' => $provedor));
        if ((int) $existeProvedor->fetchColumn() > 0) {
            $puladas++;
            continue;
        }

        $insere->execute(array(
            ':prov' => $provedor,
            ':apelido' => $catalogo[$provedor]['nome'],
            ':amb' => 'producao',
            ':ativo' => 0,
            ':cred' => null,
            ':pix' => (int) $catalogo[$provedor]['pix'],
            ':boleto' => 0,
            ':cartao' => 0,
            ':assinatura' => 0,
            ':segredo' => null,
        ));
        $criadas++;
    }

    return array('criadas' => $criadas, 'puladas' => $puladas);
}

/**
 * O nome da conta como a tela deve mostrar -- 10/09/2026. O apelido
 * das contas instaladas pela V4_0_4 nasceu sem acento (a migracao e ASCII de
 * proposito); aqui ele volta com acento, e conta sem confirmacao automatica
 * diz isso ao lado, porque e o que decide se alguem vai ter de dar baixa a
 * mao. Nao muda nada no banco.
 */
function shield_conta_rotulo(array $conta)
{
    $prov = (string) ($conta['provedor'] ?? '');
    $apelido = trim((string) ($conta['apelido'] ?? ''));
    $bonito = array(
        'dinheiro' => 'Dinheiro em espécie',
        'pix_estatico' => 'PIX estático',
    );
    if (isset($bonito[$prov]) && ($apelido === '' || stripos($apelido, 'dinheiro em especie') === 0 || stripos($apelido, 'pix estatico') === 0)) {
        $apelido = $bonito[$prov];
    }
    if ($apelido === '') {
        $apelido = $prov;
    }
    $catalogo = shield_cobranca_provedores();
    $manual = isset($catalogo[$prov]) && empty($catalogo[$prov]['automatico']);

    return $apelido . ($manual ? ' · confirmação manual' : '');
}

/** As contas com as automaticas primeiro: quem confirma sozinho vem antes de quem depende de gente. */
function shield_contas_para_escolher(array $contas)
{
    $catalogo = shield_cobranca_provedores();
    usort($contas, static function ($a, $b) use ($catalogo) {
        $ma = empty($catalogo[(string) ($a['provedor'] ?? '')]['automatico']) ? 1 : 0;
        $mb = empty($catalogo[(string) ($b['provedor'] ?? '')]['automatico']) ? 1 : 0;
        if ($ma !== $mb) {
            return $ma <=> $mb;
        }

        return strcasecmp(shield_conta_rotulo($a), shield_conta_rotulo($b));
    });

    return $contas;
}
