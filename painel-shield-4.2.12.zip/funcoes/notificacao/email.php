<?php

// E-mail do painel - 25/08/2026.
//
// E A BASE, NAO A ALTERNATIVA. Funciona para o cliente que ainda nao atualizou
// o ERP, para quem esta com o sistema desligado, e e o unico canal que alcanca
// quem ainda nem e cliente.
//
// O E-MAIL SAI PELA FILA, e nao na requisicao que o disparou. Servidor de
// e-mail lento e comum, e a alternativa e o membro esperando trinta segundos
// numa tela que ele achou que so ia confirmar um pagamento.
//
// A MARCA E A DO MEMBRO. Ele revende com a identidade dele e o cliente final ve
// o nome dele -- nao o nosso. Nada aqui escreve "Shield" para o cliente.

require_once __DIR__ . '/../nucleo/autoload.php';
require_once __DIR__ . '/../cobranca/cobranca.php';
require_once __DIR__ . '/../nucleo/env.php';

const SHIELD_EMAIL_CHAVE = 'email_config';

/**
 * O SMTP do .env -- 03/09/2026. Quem administra o painel preenche as
 * SHIELD_SMTP_* e o e-mail passa a sair, sem tela de configuracao. Vazio
 * quando SHIELD_SMTP_HOST nao esta la.
 *
 * As chaves sao as mesmas da configuracao do banco, para o resto deste
 * arquivo nao saber de onde veio.
 */
function shield_email_config_do_env()
{
    $servidor = trim(shield_env('SHIELD_SMTP_HOST', ''));
    if ($servidor === '') {
        return array();
    }

    $seguranca = strtolower(trim(shield_env('SHIELD_SMTP_SECURITY', 'tls')));
    if (!in_array($seguranca, array('tls', 'ssl', 'none'), true)) {
        $seguranca = 'tls';
    }

    return array(
        'servidor' => $servidor,
        'porta' => (int) shield_env('SHIELD_SMTP_PORT', $seguranca === 'ssl' ? '465' : '587'),
        'usuario' => shield_env('SHIELD_SMTP_USER', ''),
        'senha' => shield_env('SHIELD_SMTP_PASSWORD', ''),
        'seguranca' => $seguranca,
        'remetente' => trim(shield_env('SHIELD_SMTP_FROM', shield_env('SHIELD_SMTP_USER', ''))),
        'nome' => trim(shield_env('SHIELD_SMTP_FROM_NAME', '')),
    );
}

/** O .env vence: e o que o administrador acabou de escrever, e nao um cofre antigo. */
function shield_email_config(PDO $pdo)
{
    $env = shield_email_config_do_env();
    if ($env !== array()) {
        return $env;
    }

    $cru = trim((string) shield_get_system_meta($pdo, SHIELD_EMAIL_CHAVE, ''));
    if ($cru === '') {
        return array();
    }

    try {
        $dados = json_decode((string) shield_decrypt_secret($cru), true);
    } catch (Throwable $ignorado) {
        return array();
    }

    return is_array($dados) ? $dados : array();
}

function shield_email_configurado(PDO $pdo)
{
    $c = shield_email_config($pdo);

    return trim((string) ($c['servidor'] ?? '')) !== ''
        && trim((string) ($c['remetente'] ?? '')) !== '';
}

/** A marca do membro, que e a que o cliente final ve. */
function shield_email_marca(PDO $pdo)
{
    try {
        $s = $pdo->query('SELECT fantasia, razao, telefone FROM softhouse LIMIT 1')
                 ->fetch(PDO::FETCH_ASSOC);
    } catch (Throwable $ignorado) {
        $s = null;
    }

    $nome = trim((string) ($s['fantasia'] ?? ''));
    if ($nome === '') {
        $nome = trim((string) ($s['razao'] ?? ''));
    }

    // A cor tambem, porque o e-mail e o UNICO artefato do produto que sai do
    // painel e fica na caixa de entrada de um terceiro, assinado com o nome do
    // membro. Um botao azul embaixo do nome de uma empresa verde e a falha de
    // marca mais visivel e mais duradoura que este produto consegue produzir --
    // e-mail nao recarrega.
    //
    // A REGEX NAO E HIGIENE, E A PROTECAO: o valor vai para dentro de um
    // atributo style=. String qualquer vinda do banco ali dentro e injecao de
    // HTML em mensagem enviada para terceiro.
    $cor = '';
    try {
        if (function_exists('shield_get_system_meta')) {
            $cor = trim((string) shield_get_system_meta($pdo, 'marca_cor', ''));
        }
    } catch (Throwable $ignorado) {
        $cor = '';
    }
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $cor)) {
        $cor = defined('SHIELD_MARCA_COR_PADRAO') ? SHIELD_MARCA_COR_PADRAO : '#00697f';
    }

    return array(
        'nome' => $nome !== '' ? $nome : 'Suporte',
        'telefone' => trim((string) ($s['telefone'] ?? '')),
        'cor' => strtolower($cor),
        'cor_letra' => shield_email_letra_sobre($cor),
    );
}

/* A letra do botao, calculada e nao fixada.
 *
 * Cliente de e-mail nao le variavel CSS nem color-mix: o hex tem de ir cru no
 * style=. O painel esconde este problema com --bs-btn-color: #fff fixo, que
 * funciona so porque o padrao e escuro -- mas o membro escolhe a cor dele num
 * <input type="color"> sem critica nenhuma. Escolhendo o ciano da marca, branco
 * sobre ele da 2,00:1, e a norma e explicita: sobre o ciano o texto e grafite.
 *
 * Luminancia relativa da WCAG, com o limiar em 0,35 -- onde branco e grafite
 * empatam na pratica. Amarelo e ciano caem para o grafite; azul, verde e roxo
 * ficam com o branco.
 */
function shield_email_letra_sobre($hex)
{
    $rgb = array_map('hexdec', str_split(ltrim((string) $hex, '#'), 2));
    $canal = function ($v) {
        $v = $v / 255;
        return $v <= 0.04045 ? $v / 12.92 : pow(($v + 0.055) / 1.055, 2.4);
    };
    $lum = 0.2126 * $canal($rgb[0]) + 0.7152 * $canal($rgb[1]) + 0.0722 * $canal($rgb[2]);

    return $lum < 0.35 ? '#ffffff' : '#101010';
}

/**
 * Poe o e-mail na fila. NAO envia agora.
 *
 * Devolve false quando nao ha para onde mandar -- e isso NAO e erro: cliente
 * sem e-mail cadastrado e o caso comum, e derrubar a operacao por causa disso
 * seria impedir o pagamento por falta de um campo opcional.
 */
function shield_email_enfileirar(PDO $pdo, $para, $assunto, $html)
{
    $para = trim((string) $para);
    if ($para === '' || !filter_var($para, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    return shield_trabalho_enfileirar($pdo, 'enviar_email', array(
        'para' => $para,
        'assunto' => (string) $assunto,
        'html' => (string) $html,
    )) > 0;
}

/** Envia de verdade. Chamada pela fila -- nao chamar direto da tela. */
function shield_email_enviar_agora(PDO $pdo, $para, $assunto, $html)
{
    $c = shield_email_config($pdo);
    if (trim((string) ($c['servidor'] ?? '')) === '') {
        throw new RuntimeException('O envio de e-mail ainda nao foi configurado.');
    }

    $marca = shield_email_marca($pdo);

    $smtp = new Shield\Email\Smtp(
        (string) $c['servidor'],
        (int) ($c['porta'] ?? 587),
        (string) ($c['usuario'] ?? ''),
        (string) ($c['senha'] ?? ''),
        (string) ($c['seguranca'] ?? 'tls')
    );

    return $smtp->enviar(
        (string) $c['remetente'],
        (string) ($c['nome'] ?? $marca['nome']),
        $para,
        $assunto,
        $html
    );
}

/**
 * O molde das mensagens. Simples de proposito: e-mail de cobranca que parece
 * campanha de marketing vai para a promocoes, e a promocoes ninguem abre.
 */
function shield_email_molde(PDO $pdo, $titulo, $corpo, $acaoTexto = '', $acaoUrl = '')
{
    $marca = shield_email_marca($pdo);
    $e = static function ($t) {
        return htmlspecialchars((string) $t, ENT_QUOTES, 'UTF-8');
    };

    $botao = '';
    if ($acaoTexto !== '' && $acaoUrl !== '') {
        $botao = '<p style="margin:24px 0"><a href="' . $e($acaoUrl) . '"'
            . ' style="background:' . $e($marca['cor']) . ';color:' . $e($marca['cor_letra'])
            . ';padding:12px 22px;border-radius:4px;'
            . 'text-decoration:none;display:inline-block">' . $e($acaoTexto) . '</a></p>';
    }

    return '<!doctype html><html lang="pt-br"><body style="margin:0;padding:24px;'
        . 'font-family:Arial,Helvetica,sans-serif;color:#222;background:#f4f4f4">'
        . '<div style="max-width:34rem;margin:0 auto;background:#fff;padding:28px;border-radius:6px">'
        . '<h1 style="font-size:19px;margin:0 0 16px">' . $e($titulo) . '</h1>'
        . $corpo . $botao
        . '<hr style="border:0;border-top:1px solid #e3e3e3;margin:24px 0">'
        . '<p style="font-size:12px;color:#666;margin:0">' . $e($marca['nome'])
        . ($marca['telefone'] !== '' ? ' &middot; ' . $e($marca['telefone']) : '')
        . '</p></div></body></html>';
}

/** O texto de cada passo da regua, ja com a marca do membro. */
function shield_email_da_regua(PDO $pdo, array $aviso)
{
    $c = $aviso['cobranca'];
    $e = static function ($t) {
        return htmlspecialchars((string) $t, ENT_QUOTES, 'UTF-8');
    };

    $valor = shield_dinheiro((int) $c['valor_centavos']);
    $vence = date('d/m/Y', strtotime((string) $c['vencimento']));

    $titulo = (int) $aviso['dias'] > 0
        ? 'Mensalidade em aberto desde ' . $vence
        : ((int) $aviso['dias'] === 0 ? 'Sua mensalidade vence hoje' : 'Sua mensalidade vence em breve');

    $corpo = '<p>' . $e((string) $aviso['texto']) . '</p>'
        . '<p><strong>' . $e((string) $c['descricao']) . '</strong><br>'
        . 'Valor: R$ ' . $e($valor) . '<br>'
        . 'Vencimento: ' . $e($vence) . '</p>';

    if ((int) $aviso['dias'] > 0) {
        // O que NAO se escreve aqui: ameaca de corte com data. Quem decide se o
        // sistema para e a validade da licenca, e a regua so chega a propor a
        // suspensao depois da carencia -- prometer corte antes disso e mentira
        // que o membro vai ter de desmentir no telefone.
        $corpo .= '<p>Se voc&ecirc; j&aacute; pagou, pode desconsiderar este aviso.</p>';
    }

    return array('assunto' => $titulo, 'html' => shield_email_molde($pdo, $titulo, $corpo));
}
