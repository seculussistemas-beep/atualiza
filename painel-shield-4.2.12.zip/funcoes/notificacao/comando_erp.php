<?php

// O que a resposta da licenca leva de volta ao ERP - 25/08/2026.
//
// O ERP ja bate aqui a cada 18 horas. Usar essa batida como CANAL DE COMANDO
// custa quase nada -- o campo ja viaja -- e resolve duas coisas que hoje
// dependem de o cliente saber fazer:
//
//   PEDIR O LOG. Hoje o suporte diz "compacta a pasta C:\Sistema\logs\<data> e
//   manda", e boa parte dos clientes nao consegue. O ERP grava um passo antes
//   de cada etapa que pode travar, entao "o sistema travou" vira "travou na
//   leitura do XML da compra, as 14:53, na versao 7.4.6".
//
//   AVISAR O OPERADOR. A Central de Notificacoes do ERP ja existe, com toast,
//   sino e silenciar. Ela chega em quem usa o sistema todo dia -- nao num
//   numero de WhatsApp que pode estar errado.
//
// COMPATIVEL PARA TRAS, sempre: ERP que nao conhece os campos os ignora, como
// sempre fez. Nenhuma versao do ERP quebra por causa deles.
//
// E AVISO NUNCA E BLOQUEIO. Fatura em aberto nao trava caixa. Quem decide se o
// sistema abre continua sendo a validade da licenca, pela regua. Misturar as
// duas coisas transformaria atraso de pagamento em loja parada sem carencia --
// exatamente o que o desenho da regua evita.

require_once __DIR__ . '/../cobranca/cobranca.php';
// O motor inteiro, e nao so o esqueleto: o "conferir pagamento" do ERP
// pergunta ao provedor pela mesma consulta que a tela de cobrancas usa.
require_once __DIR__ . '/../cobranca/cobranca_motor.php';

/**
 * Ha pedido de log pendente para este terminal?
 *
 * O pedido e consumido AQUI, ao ser entregue: sem isso, o ERP mandaria a mesma
 * pasta a cada 18 horas ate alguem lembrar de desmarcar.
 */
function shield_comando_pedido_de_log(PDO $pdo, $terminalId)
{
    $terminalId = (int) $terminalId;
    if ($terminalId <= 0) {
        return null;
    }

    try {
        // A coluna da pasta inteira chega na 4.1.0; base intermediaria pede o
        // periodo como sempre.
        $temPasta = function_exists('shield_column_exists')
            && shield_column_exists($pdo, 'terminais', 'log_pedido_pasta');
        $stmt = $pdo->prepare(
            'SELECT log_pedido_de, log_pedido_ate' . ($temPasta ? ', log_pedido_pasta' : ', 0 AS log_pedido_pasta')
            . ' FROM terminais WHERE CODIGO = :id AND log_pedido_de IS NOT NULL LIMIT 1'
        );
        $stmt->execute(array(':id' => $terminalId));
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($linha)) {
            return null;
        }

        $stmt = $pdo->prepare(
            'UPDATE terminais SET log_pedido_de = NULL, log_pedido_ate = NULL'
            . ($temPasta ? ', log_pedido_pasta = 0' : '') . ' WHERE CODIGO = :id'
        );
        $stmt->execute(array(':id' => $terminalId));

        $pedido = array(
            'de' => substr((string) $linha['log_pedido_de'], 0, 10),
            'ate' => substr((string) ($linha['log_pedido_ate'] ?: $linha['log_pedido_de']), 0, 10),
        );
        // A PASTA INTEIRA -- 10/09/2026. O ERP que conhece o campo manda a
        // pasta de logs completa (todos os dias, todos os arquivos, com a
        // estrutura); o que nao conhece le so de/ate e manda o periodo. O
        // periodo vai junto de proposito: e o fallback.
        if (!empty($linha['log_pedido_pasta'])) {
            $pedido['pasta'] = 'completa';
        }

        return $pedido;
    } catch (Throwable $ignorado) {
        // Base ainda sem as colunas: nao pedir log e o certo, e a licenca segue.
        return null;
    }
}

/**
 * O aviso que o operador da loja vai ver na Central do ERP.
 *
 * UM SO, e o mais urgente. A Central desenha bem um aviso e mal uma lista; e
 * operador que recebe tres avisos de uma vez nao le nenhum.
 *
 * A FATURA VEM PRIMEIRO -- 11/09/2026 (era o contrario). Com contrato mensal
 * a validade e o vencimento da proxima fatura: dez dias antes o aviso de
 * "licenca vencendo" ganhava e mandava o cliente procurar o suporte,
 * escondendo a mensalidade que ele podia pagar ali mesmo. Havendo fatura em
 * aberto, o aviso e a fatura (valor, vencimento e os dias), e o ERP leva
 * direto a aba Mensalidade; "licenca vencendo" fica para quem nao tem o
 * que pagar -- pre-pago sem fatura emitida, que ai e mesmo com o suporte.
 *
 * O LEAD EM AVALIACAO RECEBE 'teste_acabando' -- 14/09/2026. A API empresta a
 * validade do fim do teste na copia em memoria (marca '_teste'), e o teste
 * padrao, de sete dias, cabe inteiro na janela de dez: o lead recebia
 * "licenca vencendo -- procure o suporte para renovar" desde a primeira
 * batida, sem ter licenca nenhuma a renovar. Mesmos campos (vence, dias), tipo
 * proprio. O ERP em campo descarta tipo que nao conhece (AvisoDoPainel, em
 * uPrincipal.pas), entao o aviso errado some ja; o ERP que aprender o tipo diz
 * "sua avaliacao termina". A fatura em aberto continua ganhando, tambem do lead.
 */
function shield_comando_aviso(PDO $pdo, array $empresa)
{
    try {
        $hoje = new DateTimeImmutable('today');
        $stmt = $pdo->prepare(
            'SELECT id, descricao, vencimento, valor_centavos
               FROM cobranca
              WHERE fk_empresa = :emp AND situacao IN (:aberta, :vencida)
              ORDER BY vencimento LIMIT 1'
        );
        $stmt->execute(array(
            ':emp' => (int) ($empresa['codigo'] ?? 0),
            ':aberta' => 'aberta',
            ':vencida' => 'vencida',
        ));
        $c = $stmt->fetch(PDO::FETCH_ASSOC);

        if (is_array($c)) {
            $vence = substr((string) $c['vencimento'], 0, 10);
            $diasFatura = 0;
            try {
                $diasFatura = (int) $hoje->diff(new DateTimeImmutable($vence))->format('%r%a');
            } catch (Throwable $dataRuim) {
            }

            return array(
                'tipo' => 'fatura_aberta',
                'vence' => $vence,
                // Em CENTAVOS, como em todo o resto. O ERP formata; mandar
                // "R$ 149,00" faria o outro lado ter de desmontar texto.
                'valor' => (int) $c['valor_centavos'],
                'descricao' => (string) $c['descricao'],
                // Negativo quando ja venceu. O ERP tambem sabe contar; vai
                // porque e o relogio do painel que decide o que e "hoje".
                'dias' => $diasFatura,
            );
        }

        $validade = trim((string) ($empresa['validade_licenca'] ?? ''));
        if ($validade !== '' && $validade !== '0000-00-00') {
            $dias = (int) $hoje
                ->diff(new DateTimeImmutable(substr($validade, 0, 10)))
                ->format('%r%a');

            // Dentro da janela em que o operador ainda tem tempo de resolver.
            // Antes disso o aviso vira paisagem; depois, ja e tarde.
            if ($dias <= 10) {
                return array(
                    'tipo' => !empty($empresa['_teste']) ? 'teste_acabando' : 'licenca_vencendo',
                    'vence' => substr($validade, 0, 10),
                    'dias' => $dias,
                );
            }
        }
    } catch (Throwable $ignorado) {
        // Aviso e cortesia; licenca e o caixa abrindo. Falhar aqui nao pode
        // atrapalhar a resposta.
        return null;
    }

    return null;
}

/** Marca que o membro quer o log daquele terminal. */
function shield_comando_pedir_log(PDO $pdo, $terminalId, $de, $ate, $pastaInteira = false)
{
    $temPasta = function_exists('shield_column_exists')
        && shield_column_exists($pdo, 'terminais', 'log_pedido_pasta');
    $stmt = $pdo->prepare(
        'UPDATE terminais SET log_pedido_de = :de, log_pedido_ate = :ate, log_pedido_em = NOW()'
        . ($temPasta ? ', log_pedido_pasta = :pasta' : '') . ' WHERE CODIGO = :id'
    );
    $params = array(':de' => $de, ':ate' => $ate, ':id' => (int) $terminalId);
    if ($temPasta) {
        $params[':pasta'] = $pastaInteira ? 1 : 0;
    }
    $stmt->execute($params);

    shield_auditar($pdo, 'log_pedido', array(
        'alvo_tipo' => 'terminal', 'alvo_id' => (int) $terminalId,
        'detalhe' => ($pastaInteira ? 'a pasta inteira (periodo de apoio ' : 'de ') . $de . ' a ' . $ate . ($pastaInteira ? ')' : ''),
    ));

    return $stmt->rowCount() > 0;
}

function shield_comando_cancelar_pedido(PDO $pdo, $terminalId)
{
    $stmt = $pdo->prepare(
        'UPDATE terminais SET log_pedido_de = NULL, log_pedido_ate = NULL WHERE CODIGO = :id'
    );
    $stmt->execute(array(':id' => (int) $terminalId));

    return $stmt->rowCount() > 0;
}

// ------------------------------------------------------------------ disco ---

function shield_comando_pasta_logs()
{
    $pasta = dirname(__DIR__, 2) . '/uploads/logs';
    if (!is_dir($pasta)) {
        @mkdir($pasta, 0775, true);
    }

    // Sem isto, o zip de log de um cliente fica acessivel por URL para quem
    // adivinhar o nome -- e o nome esta na tela do painel.
    $guarda = $pasta . '/.htaccess';
    if (!is_file($guarda)) {
        @file_put_contents($guarda, "Require all denied" . PHP_EOL
            . "<IfModule !mod_authz_core.c>" . PHP_EOL . "Deny from all" . PHP_EOL
            . "</IfModule>" . PHP_EOL);
    }

    return $pasta;
}

/**
 * Apaga o que passou do prazo. Roda junto do resto, no cron e no painel.
 *
 * Log de suporte serve por semanas, nao por anos -- e a cota da hospedagem do
 * membro e dele, nao nossa.
 */
function shield_comando_expurgar_logs(PDO $pdo)
{
    try {
        $stmt = $pdo->query('SELECT id, arquivo FROM log_capturado WHERE expurgo_em < CURDATE()');
        $n = 0;
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $linha) {
            $caminho = shield_comando_pasta_logs() . '/' . basename((string) $linha['arquivo']);
            if (is_file($caminho)) {
                @unlink($caminho);
            }
            $n++;
        }

        if ($n > 0) {
            $pdo->query('DELETE FROM log_capturado WHERE expurgo_em < CURDATE()');
        }

        return $n;
    } catch (Throwable $ignorado) {
        return 0;
    }
}

// ----------------------------------------------------------- pagar pelo ERP ---
//
// O CLIENTE PAGA PELA TELA DE LICENCA DO ERP - 04/09/2026.
//
// A batida ja trazia "ha fatura aberta"; passa a trazer COMO pagar: o codigo
// PIX ou o link que o provedor devolveu quando o membro emitiu, e por qual
// conta. O ERP mostra o QR, copia o codigo, abre o link -- e nunca fala com
// gateway nenhum: quem sabe conversar com os provedores e este painel, e a
// credencial de gateway nao vai para a loja.
//
// DUAS ACOES VOLTAM DO ERP. `conferir_pagamento` pergunta ao provedor (a fonte
// da verdade) e, se pagou, a validade anda pela mesma ponte de sempre;
// `informar_pagamento` so MARCA a cobranca -- e aviso, nao prova: quem
// confirma PIX estatico e dinheiro continua sendo o membro, olhando o extrato.
// NADA AQUI ESTENDE VALIDADE POR PALAVRA DO CLIENTE.

/**
 * A cobranca em aberto deste cliente, do jeito que a aba Mensalidade precisa.
 *
 * Rascunho ENTRA: a tela diz "ainda nao emitida, fale com o suporte" em vez
 * de "nada a pagar", que seria mentira. Devolve null quando nao ha o que
 * pagar -- ou quando a base ainda nao tem o modulo de cobranca, porque nada
 * aqui pode segurar a licenca.
 */
function shield_comando_cobranca(PDO $pdo, array $empresa)
{
    // A MAIS URGENTE e a primeira da lista -- o contrato com o ERP exige que
    // `cobranca` e `cobrancas[0]` sejam a mesma. Uma consulta so, nao duas.
    $todas = shield_comando_cobrancas($pdo, $empresa, 1);

    return $todas ? $todas[0] : null;
}

/**
 * TODAS as cobrancas em aberto deste cliente, na ordem de urgencia -- 10/09/2026,
 * a pedido do lado Delphi. Sete das casas do levantamento cobram
 * implantacao, rede e manutencao a parte da mensalidade; o cliente so
 * enxergava uma, pagava aquela e continuava devendo sem saber. Cada item tem
 * exatamente o formato do `cobranca` de sempre.
 *
 * $comPagasRecentes (11/09/2026): traz tambem as PAGAS dos ultimos sete
 * dias, por ULTIMO. E para a API do ERP: sem elas a tela nunca chegava a
 * dizer "paga -- obrigado", porque no instante em que o pagamento entrava
 * a fatura sumia da lista. A area do cliente nao pede: ela ja lista as
 * fechadas por conta propria. Nunca na frente de algo a pagar.
 */
function shield_comando_cobrancas(PDO $pdo, array $empresa, $limite = 20, $comPagasRecentes = false)
{
    try {
        // As colunas do aviso chegam na 4.0.5; base intermediaria responde
        // sem elas em vez de nao responder.
        $temInformado = function_exists('shield_column_exists')
            && shield_column_exists($pdo, 'cobranca', 'informado_em');
        $colunas = $temInformado ? ', c.informado_em, c.informado_forma' : '';
        // As pagas recentes (ver o cabecalho): a clausula e a ordenacao so
        // existem quando pedidas, e o SQL de sempre fica byte a byte igual.
        $pagas = $comPagasRecentes
            ? ' OR (c.situacao = :p AND c.pago_em >= DATE_SUB(NOW(), INTERVAL 7 DAY))'
            : '';
        $pagasPorUltimo = $comPagasRecentes ? '(c.situacao = :p2), ' : '';

        $sql = static function ($linha) use ($colunas, $pagas, $pagasPorUltimo, $limite) {
            return 'SELECT c.id, c.descricao, c.valor_centavos, c.vencimento, c.situacao, c.forma' . $colunas . ',
                    t.provedor, t.metodo, t.link_pagamento, t.copia_e_cola' . $linha . ',
                    co.apelido
               FROM cobranca c
               LEFT JOIN cobranca_tentativa t
                      ON t.id = (SELECT x.id FROM cobranca_tentativa x
                                  WHERE x.fk_cobranca = c.id ORDER BY x.id DESC LIMIT 1)
               LEFT JOIN conta_recebimento co ON co.id = t.fk_conta
              WHERE c.fk_empresa = :emp AND (c.situacao IN (:r, :a, :v)' . $pagas . ')
              ORDER BY ' . $pagasPorUltimo . '(c.situacao = :r2), c.vencimento, c.id LIMIT ' . max(1, (int) $limite);
        };
        $parametros = array(
            ':emp' => (int) ($empresa['codigo'] ?? 0),
            ':r' => 'rascunho', ':a' => 'aberta', ':v' => 'vencida',
            // RASCUNHO VAI PARA O FIM DA FILA -- 09/09/2026. Ele nao
            // tem PIX nem link: e uma cobranca guardada, nunca emitida. Na
            // frente de uma aberta, ele escondia do cliente justamente o que
            // ele conseguia pagar. So volta quando e a unica coisa em aberto,
            // porque ai ao menos diz quanto vai custar.
            ':r2' => 'rascunho',
        );
        if ($comPagasRecentes) {
            $parametros[':p'] = 'paga';
            $parametros[':p2'] = 'paga';
        }
        // A LINHA DIGITAVEL CHEGA NA V4_2_10, E A ROTA DE LICENCA NAO ESPERA O
        // /update: entre subir o pacote e rodar a migracao, pedir a coluna
        // derrubava a lista inteira no catch de baixo, e a aba Mensalidade do ERP
        // ficava muda. Descoberta por tentativa: perguntar ao INFORMATION_SCHEMA
        // aqui custaria uma consulta a mais a cada caixa que abre.
        try {
            $stmt = $pdo->prepare($sql(', t.linha_digitavel'));
            $stmt->execute($parametros);
        } catch (PDOException $semALinha) {
            $stmt = $pdo->prepare($sql(''));
            $stmt->execute($parametros);
        }
        $catalogo = shield_cobranca_provedores();
        $lista = array();
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $c) {
            $prov = (string) ($c['provedor'] ?? '');
            $manual = ($prov !== '') && isset($catalogo[$prov]) && empty($catalogo[$prov]['automatico']);

            $lista[] = array(
                'id' => (int) $c['id'],
                'descricao' => (string) $c['descricao'],
                // Em CENTAVOS, como em todo o resto. O ERP formata.
                'valor' => (int) $c['valor_centavos'],
                'vencimento' => substr((string) $c['vencimento'], 0, 10),
                'situacao' => (string) $c['situacao'],
                'provedor' => $prov,
                'apelido' => (string) (($c['apelido'] ?? '') ?: ($catalogo[$prov]['nome'] ?? '')),
                'metodo' => (string) ($c['metodo'] ?? ''),
                'forma' => (string) ($c['forma'] ?? ''),
                'manual' => $manual,
                'link' => (string) ($c['link_pagamento'] ?? ''),
                'copia_e_cola' => (string) ($c['copia_e_cola'] ?? ''),
                'informado_em' => (string) ($c['informado_em'] ?? ''),
                'informado_forma' => (string) ($c['informado_forma'] ?? ''),
                // POR ULTIMO, como toda chave nova (17/09/2026). No boleto hibrido
                // `copia_e_cola` e o PIX e esta e a linha do boleto; no boleto sem
                // PIX as duas trazem a mesma linha. Vazia fora do boleto.
                'linha_digitavel' => (string) ($c['linha_digitavel'] ?? ''),
            );
        }

        return $lista;
    } catch (Throwable $ignorado) {
        // Base sem o modulo de cobranca: sem mensalidade na tela, e a
        // licenca segue.
        return array();
    }
}

/**
 * O cliente avisou, pelo ERP, que pagou. Marca a cobranca e deixa rastro.
 *
 * Devolve '' quando marcou, ou o motivo de nao ter marcado. A cobranca tem
 * de ser DESTE cliente e estar em aberto: aviso sobre cobranca alheia, ou
 * sobre uma ja paga, nao marca nada.
 */
function shield_comando_informar_pagamento(PDO $pdo, array $empresa, $cobrancaId, $forma, $obs, $canal = 'ERP do cliente')
{
    $cobrancaId = (int) $cobrancaId;
    if ($cobrancaId <= 0) {
        return 'cobranca nao informada';
    }

    try {
        $stmt = $pdo->prepare(
            'SELECT id, situacao FROM cobranca WHERE id = :id AND fk_empresa = :emp LIMIT 1'
        );
        $stmt->execute(array(':id' => $cobrancaId, ':emp' => (int) ($empresa['codigo'] ?? 0)));
        $c = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($c)) {
            return 'cobranca nao e deste cliente';
        }
        if (in_array((string) $c['situacao'], array('paga', 'cancelada', 'estornada'), true)) {
            return 'cobranca ja esta ' . $c['situacao'];
        }

        $forma = substr(preg_replace('/[^a-z_]/', '', strtolower((string) $forma)), 0, 20);
        $obs = substr(trim((string) $obs), 0, 150);

        $stmt = $pdo->prepare(
            'UPDATE cobranca
                SET informado_em = NOW(), informado_forma = :forma, informado_obs = :obs
              WHERE id = :id'
        );
        $stmt->execute(array(':forma' => $forma !== '' ? $forma : null,
                             ':obs' => $obs !== '' ? $obs : null, ':id' => $cobrancaId));

        shield_auditar($pdo, 'pagamento_informado_pelo_cliente', array(
            'alvo_tipo' => 'cobranca', 'alvo_id' => $cobrancaId,
            'ator' => (string) $canal,
            'detalhe' => 'o cliente avisou (' . (string) $canal . ') que pagou'
                . ($forma !== '' ? ' por ' . $forma : '')
                . ($obs !== '' ? ' -- ' . $obs : ''),
        ));

        return '';
    } catch (Throwable $e) {
        // Base ainda sem as colunas (migracao 4.0.5): o aviso nao tem onde
        // morar, e a licenca segue.
        return 'o painel ainda nao recebe aviso de pagamento';
    }
}

/**
 * O cliente clicou em "Conferir pagamento". Pergunta ao provedor pela mesma
 * consulta que a tela de cobrancas usa -- a fonte da verdade -- e, se pagou,
 * a validade JA ANDOU pela ponte de sempre antes de esta funcao voltar.
 *
 * Devolve a situacao que o provedor respondeu, ou '' quando nao havia a quem
 * perguntar (cobranca de outro cliente, nunca emitida, ou provedor manual).
 */
function shield_comando_conferir_pagamento(PDO $pdo, array $empresa, $cobrancaId)
{
    $cobrancaId = (int) $cobrancaId;
    if ($cobrancaId <= 0) {
        return '';
    }

    try {
        $stmt = $pdo->prepare('SELECT id FROM cobranca WHERE id = :id AND fk_empresa = :emp LIMIT 1');
        $stmt->execute(array(':id' => $cobrancaId, ':emp' => (int) ($empresa['codigo'] ?? 0)));
        if ($stmt->fetchColumn() === false) {
            return '';
        }

        $r = shield_cobranca_consultar($pdo, $cobrancaId);

        return $r === null ? '' : (string) $r->situacao;
    } catch (Throwable $e) {
        // Provedor fora do ar nao pode derrubar a licenca: o cliente tenta de
        // novo, e o motivo fica no log do servidor.
        error_log('[licenca] conferir pagamento ' . $cobrancaId . ': ' . $e->getMessage());

        return '';
    }
}
