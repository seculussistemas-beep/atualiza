<?php

/**
 * Mudar no meio do contrato -- 10/09/2026, fatia 8 da reorganizacao
 * (docs/reorganizacao-do-painel.md, secao 6).
 *
 * Hoje isso existia pela metade: o membro mudava os terminais no contrato, a
 * cota subia na hora e a proxima cobranca ja saia com o valor novo -- mas o
 * mes corrente passava em branco e nada dizia o que ia acontecer.
 *
 * A janela pede O NUMERO FINAL, nao uma diferenca ("quero que fique 6", e nao
 * "adicionar 2"). Antes de confirmar, ela mostra:
 *   - o antes e o depois com a data ("R$ 175,00 -> R$ 225,00 a partir da
 *     cobranca de 10/10");
 *   - o mes corrente COMO PERGUNTA: uma cobranca avulsa proporcional, com valor
 *     editavel e caixa desmarcavel -- adicionar terminal no dia 28 e cobrar o
 *     mes cheio gera discussao;
 *   - a opcao de so liberar quando pagar: a cota sobe apenas quando aquela
 *     cobranca for confirmada, pela ponte de pagamento de sempre;
 *   - o aviso ao reduzir: quantas maquinas param, e que nao ha devolucao.
 *
 * Pre-pago nao tem mensalidade para reajustar: sai so a avulsa. Modulo usa a
 * mesma janela, sem o aviso de parada -- modulo nao para caixa.
 *
 * shield_mudanca_calcular e PURA (sem banco, sem relogio): e ela que a tela
 * mostra e o teste prova. As outras leem e gravam.
 */

require_once __DIR__ . '/../cobranca/cobranca_motor.php';
require_once __DIR__ . '/../cobranca/assinatura.php';
require_once __DIR__ . '/../licenca/parque.php';
require_once __DIR__ . '/empresa.php';

use Shield\Cobranca\Registro;

/**
 * A conta. $atual e $novo tem nterminais, inclusos, valor_terminal (centavos)
 * e modulos (id => centavos). $ctx: base (mensalidade da assinatura, 0 no
 * pre-pago), modo ('assinatura'|'prepago'), proxima (Y-m-d da proxima
 * cobranca do ciclo, ou ''), ciclo_dias (int), vivos (caixas dando sinal),
 * hoje (Y-m-d).
 *
 * Devolve antes, depois, delta (mensal, pode ser negativo), proporcional
 * (o que o mes corrente sugere cobrar; zero ao reduzir), dias_restantes,
 * reduz (bool), param (quantas maquinas vivas deixam de abrir), itens do
 * depois.
 */
function shield_mudanca_calcular(array $atual, array $novo, array $ctx)
{
    $mensal = static function (array $c, int $base) {
        $extras = max(0, (int) $c['nterminais'] - (int) $c['inclusos']);
        $terminais = (int) $c['nterminais'] > 0 ? $extras * (int) $c['valor_terminal'] : 0;
        $modulos = 0;
        foreach ((array) $c['modulos'] as $centavos) {
            $modulos += (int) $centavos;
        }

        return array('total' => $base + $terminais + $modulos, 'terminais' => $terminais, 'modulos' => $modulos, 'extras' => $extras);
    };

    $base = (string) ($ctx['modo'] ?? 'assinatura') === 'prepago' ? 0 : (int) ($ctx['base'] ?? 0);
    $a = $mensal($atual, $base);
    $d = $mensal($novo, $base);
    $delta = $d['total'] - $a['total'];

    $hoje = new DateTimeImmutable((string) ($ctx['hoje'] ?? 'today'));
    $proxima = trim((string) ($ctx['proxima'] ?? ''));
    if ($proxima !== '') {
        $dias = max(0, (int) $hoje->diff(new DateTimeImmutable($proxima))->format('%r%a'));
        $cicloDias = max(1, (int) ($ctx['ciclo_dias'] ?? 30));
    } else {
        // Sem proxima cobranca (pre-pago): o mes civil e a referencia.
        $dias = (int) $hoje->format('t') - (int) $hoje->format('j');
        $cicloDias = (int) $hoje->format('t');
    }
    $dias = min($dias, $cicloDias);

    // So o que ENTROU e proporcional; o que saiu nao devolve (esta escrito).
    $proporcional = $delta > 0 ? (int) round($delta * $dias / $cicloDias) : 0;

    $reduz = (int) $novo['nterminais'] > 0 && (int) $novo['nterminais'] < (int) $atual['nterminais'];
    $param = $reduz ? max(0, (int) ($ctx['vivos'] ?? 0) - (int) $novo['nterminais']) : 0;

    return array(
        'antes' => $a['total'], 'depois' => $d['total'], 'delta' => $delta,
        'proporcional' => $proporcional, 'dias_restantes' => $dias, 'ciclo_dias' => $cicloDias,
        'reduz' => $reduz, 'param' => $param,
        'terminais_depois' => $d['terminais'], 'modulos_depois' => $d['modulos'], 'extras_depois' => $d['extras'],
    );
}

/** O contrato como esta hoje, e o contexto da conta, lidos do banco. */
function shield_mudanca_atual(PDO $pdo, $codigo)
{
    $codigo = (int) $codigo;
    $e = shield_cob_empresa($pdo, $codigo);
    if ($e === null) {
        throw new RuntimeException('Cliente nao encontrado.');
    }

    $modulos = array();
    try {
        $stmt = $pdo->prepare('SELECT fk_modulo, valor_centavos FROM empresa_modulo WHERE fk_empresa = :e AND ate IS NULL');
        $stmt->execute(array(':e' => $codigo));
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $m) {
            $modulos[(int) $m['fk_modulo']] = (int) $m['valor_centavos'];
        }
    } catch (Throwable $semTabela) {
    }

    $atual = array(
        'nterminais' => (int) ($e['nterminais'] ?? 0),
        'inclusos' => (int) ($e['terminais_inclusos'] ?? 0),
        'valor_terminal' => (int) ($e['valor_terminal_centavos'] ?? 0),
        'modulos' => $modulos,
    );

    $ctx = array('modo' => 'prepago', 'base' => 0, 'proxima' => '', 'ciclo_dias' => 30, 'hoje' => date('Y-m-d'),
                 'vivos' => (int) (shield_parque_vivos_por_empresa($pdo, array($codigo))[$codigo] ?? 0),
                 'assinatura' => null);
    try {
        $stmt = $pdo->prepare("SELECT * FROM assinatura WHERE fk_empresa = :e AND situacao = 'ativa' ORDER BY id DESC LIMIT 1");
        $stmt->execute(array(':e' => $codigo));
        $ass = $stmt->fetch(PDO::FETCH_ASSOC);
        if (is_array($ass)) {
            $competencia = (string) ($ass['proxima_competencia'] ?: shield_assinatura_competencia());
            $ctx['modo'] = 'assinatura';
            // valor_centavos e o preco do CICLO; a conta da mudanca e a tela
            // pensam por mes (11/09/2026).
            $ctx['base'] = (int) round((int) $ass['valor_centavos'] / max(1, (int) $ass['ciclo_meses']));
            $ctx['mensal'] = $ctx['base'];
            $ctx['proxima'] = shield_assinatura_vencimento($competencia, (int) $ass['dia_vencimento']);
            $ctx['ciclo_dias'] = 30 * max(1, (int) $ass['ciclo_meses']);
            $ctx['assinatura'] = $ass;
        }
    } catch (Throwable $semTabela) {
    }

    return array('empresa' => $e, 'atual' => $atual, 'ctx' => $ctx);
}

/**
 * Normaliza o pedido da tela: numero final, inclusos, valor do extra e a
 * lista de modulos (ids) com o valor de tabela COPIADO para os novos e o
 * valor combinado mantido para os que ja estavam.
 */
function shield_mudanca_novo(PDO $pdo, array $atual, array $pedido)
{
    $ids = array_values(array_unique(array_map('intval', (array) ($pedido['modulos'] ?? array()))));
    $modulos = array();
    foreach ($ids as $id) {
        if ($id <= 0) {
            continue;
        }
        if (isset($atual['modulos'][$id])) {
            $modulos[$id] = $atual['modulos'][$id];
            continue;
        }
        $stmt = $pdo->prepare('SELECT valor_centavos FROM modulo WHERE id = :id AND ativo = 1');
        $stmt->execute(array(':id' => $id));
        $v = $stmt->fetchColumn();
        if ($v !== false) {
            $modulos[$id] = (int) $v;
        }
    }

    return array(
        'nterminais' => max(0, (int) ($pedido['nterminais'] ?? $atual['nterminais'])),
        'inclusos' => max(0, (int) ($pedido['inclusos'] ?? $atual['inclusos'])),
        'valor_terminal' => max(0, (int) ($pedido['valor_terminal'] ?? $atual['valor_terminal'])),
        'modulos' => $modulos,
    );
}

/**
 * Aplica. $opcoes: cobrar_agora (bool), valor_avulsa (centavos, ja editado
 * pela pessoa), liberar_ao_pagar (bool), conta (id, 0 = so registrar).
 * Devolve ['cobranca' => id|null, 'pendente' => bool, 'aviso' => string].
 *
 * A ORDEM: modulos e preco do extra mudam na hora (nao param caixa). A COTA
 * muda na hora, salvo "liberar so quando pagar" com aumento e cobranca: ai
 * a cota pretendida vai na cobranca e sobe quando ela for confirmada.
 * Reducao e sempre na hora -- e o aviso ja disse quantas param.
 */
function shield_mudanca_aplicar(PDO $pdo, $codigo, array $novo, array $opcoes, $ator)
{
    $codigo = (int) $codigo;
    $lido = shield_mudanca_atual($pdo, $codigo);
    $atual = $lido['atual'];
    $antes = $lido['empresa'];
    $conta = shield_mudanca_calcular($atual, $novo, $lido['ctx']);

    $cobrarAgora = !empty($opcoes['cobrar_agora']) && (int) ($opcoes['valor_avulsa'] ?? 0) > 0;
    $aumenta = (int) $novo['nterminais'] > (int) $atual['nterminais'];
    $pendente = $cobrarAgora && $aumenta && !empty($opcoes['liberar_ao_pagar']);

    // A FORMA DA AVULSA TEM DE ESTAR NO "COBRA POR" DA CONTA (14/09/2026).
    // Conferida ANTES de gravar: depois, a recusa do motor virava o aviso "o
    // provedor nao respondeu", com o contrato ja mudado e a cobranca aberta --
    // e mandava o membro procurar o problema no provedor.
    if ($cobrarAgora && (int) ($opcoes['conta'] ?? 0) > 0) {
        $contaLinha = shield_cobranca_conta($pdo, (int) $opcoes['conta']);
        $recusa = $contaLinha !== null ? shield_conta_forma_recusa($contaLinha, (string) ($opcoes['forma'] ?? 'pix')) : null;
        // A CONTA PRONTA TAMBEM (14/09/2026): o PIX na chave sem chave passava daqui,
        // gravava o contrato e so recusava na emissao, como "o provedor nao respondeu".
        if ($recusa === null && $contaLinha !== null) {
            $recusa = shield_conta_pronta_recusa($contaLinha);
        }
        if ($recusa !== null) {
            throw new RuntimeException($recusa);
        }
    }

    $propria = !$pdo->inTransaction();
    if ($propria) {
        $pdo->beginTransaction();
    }
    try {
        // Modulos: fecha o que saiu, abre o que entrou com o valor copiado.
        foreach ($atual['modulos'] as $id => $v) {
            if (!isset($novo['modulos'][$id])) {
                $pdo->prepare('UPDATE empresa_modulo SET ate = CURDATE() WHERE fk_empresa = :e AND fk_modulo = :m AND ate IS NULL')
                    ->execute(array(':e' => $codigo, ':m' => $id));
            }
        }
        foreach ($novo['modulos'] as $id => $v) {
            if (!isset($atual['modulos'][$id])) {
                $pdo->prepare('INSERT INTO empresa_modulo (fk_empresa, fk_modulo, valor_centavos, desde) VALUES (:e, :m, :v, CURDATE())')
                    ->execute(array(':e' => $codigo, ':m' => $id, ':v' => (int) $v));
            }
        }

        // O contrato. A cota fica onde esta quando "liberar so quando pagar".
        // COTA VAZIA CONTINUA VAZIA (14/09/2026): a tela mostra NULL como 0, e so
        // NULL herda a cota do teste no primeiro pagamento (4.1.28). O 0 que volta
        // sem o numero ter mudado e a cota vazia de antes, e nao "sem limite".
        $cotaAntes = ($antes['nterminais'] ?? null) === null ? null : (int) $atual['nterminais'];
        $cotaNova = ($cotaAntes === null && (int) $novo['nterminais'] === 0) ? null : (int) $novo['nterminais'];
        $pdo->prepare(
            'UPDATE empresa SET nterminais = :n, terminais_inclusos = :i, valor_terminal_centavos = :v WHERE codigo = :c'
        )->execute(array(
            ':n' => $pendente ? $cotaAntes : $cotaNova,
            ':i' => (int) $novo['inclusos'], ':v' => (int) $novo['valor_terminal'], ':c' => $codigo,
        ));

        // O mes corrente, como pergunta respondida: a avulsa proporcional.
        //
        // F5 NAO ABRE A SEGUNDA (11/09/2026). Na segunda passada o contrato ja
        // esta no estado novo e nada muda -- mas `cobrar_agora` e
        // `valor_avulsa` continuam vindo do POST reenviado, entao nascia outra
        // avulsa com a mesma descricao e o mesmo valor, tambem emitida: dois
        // PIX iguais na mao do cliente. A chave vem do formulario, e a tela a
        // gera uma vez.
        $cobrancaId = null;
        $repetido = false;
        if ($cobrarAgora) {
            $jaFeita = shield_cobranca_por_chave($pdo, (string) ($opcoes['chave'] ?? ''));
            if ($jaFeita !== null) {
                $cobrancaId = (int) $jaFeita['id'];
                $repetido = true;
            } else {
                $cobrancaId = shield_cobranca_abrir($pdo, array(
                    'empresa' => $codigo,
                    'competencia' => date('Y-m-01'),
                    'descricao' => 'Ajuste do contrato (mes corrente, ' . $conta['dias_restantes'] . ' dias)',
                    'valor_centavos' => (int) $opcoes['valor_avulsa'],
                    'vencimento' => (string) ($opcoes['vencimento'] ?? date('Y-m-d', strtotime('+5 days'))),
                    'forma' => (string) ($opcoes['forma'] ?? 'pix'),
                    'nao_estende' => true,
                    'chave' => (string) ($opcoes['chave'] ?? ''),
                ));
                if ($pendente) {
                    $pdo->prepare('UPDATE cobranca SET libera_nterminais = :n WHERE id = :id')
                        ->execute(array(':n' => (int) $novo['nterminais'], ':id' => $cobrancaId));
                }
            }
        }

        if ($propria) {
            $pdo->commit();
        }
    } catch (Throwable $e) {
        if ($propria && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    shield_empresa_auditar_cadastro($pdo, $codigo, $antes, shield_cob_empresa($pdo, $codigo) ?: $antes);
    shield_auditar($pdo, 'contrato_alterado', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => $codigo, 'ator' => (string) $ator,
        'antes' => (string) $conta['antes'], 'depois' => (string) $conta['depois'],
        'detalhe' => 'terminais ' . $atual['nterminais'] . ' -> ' . $novo['nterminais']
            . ($pendente ? ' (libera quando pagar)' : '')
            . ', mensalidade R$ ' . shield_dinheiro($conta['antes']) . ' -> R$ ' . shield_dinheiro($conta['depois'])
            . ($cobrancaId ? ', avulsa do mes corrente R$ ' . shield_dinheiro((int) $opcoes['valor_avulsa']) : ', sem cobranca do mes corrente')
            . ($conta['param'] > 0 ? '; ' . $conta['param'] . ' maquina(s) param de abrir, sem devolucao' : ''),
    ));

    $aviso = '';
    if ($cobrancaId && (int) ($opcoes['conta'] ?? 0) > 0 && !$repetido) {
        try {
            shield_cobranca_emitir($pdo, $cobrancaId, (int) $opcoes['conta']);
        } catch (Throwable $e) {
            $aviso = 'Contrato alterado, mas o provedor nao respondeu: ' . $e->getMessage() . ' A cobranca ficou em rascunho.';
        }
    }

    return array('cobranca' => $cobrancaId, 'pendente' => $pendente, 'aviso' => $aviso, 'conta' => $conta);
}

/**
 * A cobranca do ajuste foi PAGA: sobe a cota que ficou esperando. Chamada
 * pela ponte de pagamento (shield_cobranca_estendeu_validade) -- o mesmo
 * lugar onde o pagamento ja estende a validade. Base sem a coluna: nada.
 */
/**
 * A FORMA QUE ACOMPANHA A TROCA DE CONTA, ou null quando a troca tem de recusar --
 * 14/09/2026, o dono: "mudar o modo de pagamento para dinheiro sempre da erro".
 *
 * A mesma, quando a conta nova a cobra. ENTRANDO OU SAINDO DO DINHEIRO EM ESPECIE
 * a forma nao e escolha de ninguem: o dinheiro so cobra "dinheiro", e "dinheiro"
 * nao existe em conta nenhuma alem dele. Entao ela vira a do dinheiro, ou a
 * primeira que a conta nova cobra. Sem isto a troca para o caixa era sempre
 * recusada -- o fechamento grava 'pix' na assinatura desde a V4_2_4 -- com a frase
 * de marcar o "Cobra por" de uma conta que nao tem "Cobra por"; e a volta do caixa
 * para o gateway, tambem.
 *
 * Null quando a conta nova nao faz a forma e a troca nao passa pelo dinheiro:
 * boleto para uma conta so de PIX e escolha do membro, e continua recusada.
 */
function shield_mudanca_forma_na_conta(array $conta, $forma)
{
    $f = strtolower(trim((string) $forma));
    if ((string) ($conta['provedor'] ?? '') === 'dinheiro') {
        return 'dinheiro';
    }
    if (shield_conta_forma_recusa($conta, $f) === null) {
        return $f;
    }
    $formas = shield_conta_formas($conta);

    return ($f === 'dinheiro' && $formas !== array()) ? $formas[0] : null;
}

/**
 * O que a troca de conta vai fazer -- 10/09/2026, tarde. A conta escolhida
 * no fechamento fica FIXA na assinatura e o ciclo emite nela todo mes; trocar
 * e aqui, e a troca leva junto o que esta na rua.
 *
 * Devolve conta_atual, a lista das cobrancas abertas ja emitidas (que serao
 * canceladas no provedor antigo e emitidas no novo, com o mesmo vencimento e
 * o mesmo valor), quantos rascunhos so mudam de conta, e 'recusa' quando a
 * conta nova nao faz a forma de alguma cobranca na rua -- ai nada muda.
 */
function shield_mudanca_conta_previa(PDO $pdo, $codigo, $contaNova)
{
    require_once __DIR__ . '/../cobranca/cobranca_motor2.php';
    $codigo = (int) $codigo;
    $contaNova = (int) $contaNova;
    $lido = shield_mudanca_atual($pdo, $codigo);
    $ass = $lido['ctx']['assinatura'];

    $previa = array(
        'assinatura' => is_array($ass) ? (int) $ass['id'] : null,
        'conta_atual' => is_array($ass) ? (int) ($ass['fk_conta'] ?? 0) : 0,
        'reemitir' => array(),
        'rascunhos' => 0,
        'recusa' => null,
        // A FORMA QUE VAI JUNTO quando a troca entra ou sai do dinheiro (14/09/2026):
        // id da cobranca sem codigo na rua => forma nova; e a da assinatura, ou null.
        'formas_rascunho' => array(),
        'forma_assinatura' => null,
    );

    $conta = $contaNova > 0 ? shield_cob_conta($pdo, $contaNova) : null;
    $provedor = $conta !== null ? Registro::para((string) $conta['provedor']) : null;
    if ($contaNova > 0 && ($conta === null || empty($conta['ativo']) || $provedor === null)) {
        $previa['recusa'] = 'A conta de recebimento escolhida nao existe, esta desligada ou nao tem adaptador.';

        return $previa;
    }
    // Ligada nao e pronta (14/09/2026): o PIX na chave se liga sem chave, e trocar para
    // ele deixava toda mensalidade seguinte parada em rascunho na emissao.
    $naoPronta = $conta !== null ? shield_conta_pronta_recusa($conta) : null;
    if ($naoPronta !== null) {
        $previa['recusa'] = $naoPronta;

        return $previa;
    }
    if ($contaNova > 0 && $contaNova === $previa['conta_atual']) {
        $previa['recusa'] = 'O contrato ja esta nessa conta.';

        return $previa;
    }

    $stmt = $pdo->prepare(
        "SELECT * FROM cobranca WHERE fk_empresa = :e AND situacao IN ('aberta', 'vencida', 'rascunho') ORDER BY vencimento, id"
    );
    $stmt->execute(array(':e' => $codigo));
    // A recusa diz tambem onde a forma muda junto com a conta: "mude o Cobra por"
    // sozinho nao serve a quem quer outra forma.
    $recusaForma = static function ($forma) use ($conta) {
        $frase = shield_conta_forma_recusa($conta, (string) $forma);

        return $frase === null ? null : $frase . ' Para trocar a forma junto com a conta, use "Como paga", logo acima.';
    };
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $c) {
        $tentativa = (string) $c['situacao'] === 'rascunho' ? null : shield_cobranca_ultima_tentativa($pdo, (int) $c['id']);
        if ($tentativa === null || trim((string) $tentativa['id_externo']) === '') {
            // Rascunho, ou aberta sem codigo no provedor: so muda de conta -- e de
            // forma, quando a troca entra ou sai do dinheiro. A forma que nao segue
            // fica como estava, sem recusa: nada dela esta na rua.
            $previa['rascunhos']++;
            $seguinte = $provedor !== null ? shield_mudanca_forma_na_conta($conta, (string) ($c['forma'] ?? '')) : null;
            if ($seguinte !== null && $seguinte !== (string) ($c['forma'] ?? '')) {
                $previa['formas_rascunho'][(int) $c['id']] = $seguinte;
            }
            continue;
        }
        if ((int) $tentativa['fk_conta'] === $contaNova) {
            continue;                 // ja esta na conta nova
        }
        $c['id'] = (int) $c['id'];
        $c['id_externo'] = (string) $tentativa['id_externo'];
        if ($provedor !== null) {
            // O "Cobra por" da conta nova, e nao so o provedor (14/09/2026); a forma
            // segue sozinha so quando a troca passa pelo dinheiro.
            $c['forma_nova'] = shield_mudanca_forma_na_conta($conta, (string) ($c['forma'] ?? ''));
            if ($c['forma_nova'] === null && $previa['recusa'] === null) {
                $previa['recusa'] = $recusaForma((string) ($c['forma'] ?? ''));
            }
        }
        $previa['reemitir'][] = $c;
    }

    // A FORMA DA ASSINATURA TAMBEM TEM DE CABER NA CONTA NOVA (14/09/2026). Com
    // assinatura.forma gravada, o ciclo abre cada mensalidade nela: trocar uma
    // assinatura em boleto para uma conta que so cobra PIX nao falha agora, falha
    // todo mes na emissao, e a mensalidade fica parada em rascunho sem ninguem
    // ver. Forma vazia e assinatura antiga, que sempre saiu em PIX: fica como
    // estava, sem recusa nova. Entrando ou saindo do dinheiro, a forma vai junto
    // (shield_mudanca_forma_na_conta) e a recusa nao acontece.
    if (is_array($ass) && $provedor !== null && $previa['recusa'] === null) {
        $formaAss = trim((string) ($ass['forma'] ?? ''));
        $seguinte = shield_mudanca_forma_na_conta($conta, $formaAss);
        if ($seguinte === null && $formaAss !== '') {
            $previa['recusa'] = $recusaForma($formaAss);
        } elseif ($seguinte !== null && $seguinte !== $formaAss) {
            $previa['forma_assinatura'] = $seguinte;
        }
    }

    return $previa;
}

/**
 * Troca a conta do contrato e reemite o que estava na rua.
 *
 * A ORDEM QUE IMPORTA: a previa recusa ANTES de mexer em qualquer coisa. So
 * entao a assinatura passa a apontar para a conta nova (o ciclo e os
 * rascunhos ja saem por ela), e cada cobranca emitida passa por
 * shield_cobranca_reemitir -- que cancela no provedor antigo e, SO SE ele
 * cancelar, emite no novo. Provedor que nao cancela deixa aquela cobranca
 * onde estava, e a tela e avisada: dois codigos vivos e o pior dos mundos.
 *
 * Vencimento e valor nao mudam. A excecao e a vencida com multa e juros
 * configurados: reemitir e a acao que traz os encargos de hoje.
 *
 * Devolve ['assinatura', 'reemitidas' => ids, 'falhas' => id => motivo].
 */
function shield_mudanca_trocar_conta(PDO $pdo, $codigo, $contaNova, $ator)
{
    $codigo = (int) $codigo;
    $contaNova = (int) $contaNova;
    if ($contaNova <= 0) {
        throw new RuntimeException('Escolha a conta de recebimento nova.');
    }
    $previa = shield_mudanca_conta_previa($pdo, $codigo, $contaNova);
    if ($previa['recusa'] !== null) {
        throw new RuntimeException($previa['recusa']);
    }

    if ($previa['assinatura'] !== null) {
        // A forma vai junto so quando a previa disse (entrando ou saindo do dinheiro):
        // e com ela que o ciclo abre a proxima mensalidade.
        if ($previa['forma_assinatura'] !== null) {
            $pdo->prepare('UPDATE assinatura SET fk_conta = :c, forma = :f WHERE id = :id')
                ->execute(array(':c' => $contaNova, ':f' => $previa['forma_assinatura'], ':id' => (int) $previa['assinatura']));
        } else {
            $pdo->prepare('UPDATE assinatura SET fk_conta = :c WHERE id = :id')
                ->execute(array(':c' => $contaNova, ':id' => (int) $previa['assinatura']));
        }
    }

    // Sem codigo na rua, a forma nova e so a palavra na linha: nada a cancelar.
    foreach ($previa['formas_rascunho'] as $cobrancaId => $formaNova) {
        $pdo->prepare("UPDATE cobranca SET forma = :f WHERE id = :id AND situacao IN ('rascunho', 'aberta', 'vencida')")
            ->execute(array(':f' => $formaNova, ':id' => (int) $cobrancaId));
    }

    $reemitidas = array();
    $falhas = array();
    foreach ($previa['reemitir'] as $c) {
        // A FORMA MUDA ANTES DE REEMITIR, porque a emissao confere a forma contra o
        // provedor novo (o dinheiro recusa "pix").
        $formaAntes = $c['forma'] ?? null;
        $mudaForma = isset($c['forma_nova']) && $c['forma_nova'] !== (string) $formaAntes;
        if ($mudaForma) {
            $pdo->prepare('UPDATE cobranca SET forma = :f WHERE id = :id')
                ->execute(array(':f' => $c['forma_nova'], ':id' => (int) $c['id']));
        }
        try {
            shield_cobranca_reemitir($pdo, (int) $c['id'], $contaNova);
            $reemitidas[] = (int) $c['id'];
        } catch (Throwable $e) {
            // A FORMA SO VOLTA SE O CODIGO ANTIGO CONTINUA VIVO (o provedor antigo nao
            // cancelou): ai a cobranca segue sendo o que o cliente tem na mao. Cancelado
            // o antigo e falhando o novo, ela fica sem codigo e com a forma nova -- e com
            // ela que o Emitir da lista acende a conta que o contrato ja usa. Voltar
            // para "dinheiro" deixaria so o caixa aceso no Emitir.
            $viva = $mudaForma ? shield_cobranca_tentativa_viva($pdo, (int) $c['id']) : null;
            if ($viva !== null && (string) $viva['id_externo'] === (string) $c['id_externo']) {
                $pdo->prepare('UPDATE cobranca SET forma = :f WHERE id = :id')
                    ->execute(array(':f' => $formaAntes, ':id' => (int) $c['id']));
            }
            $falhas[(int) $c['id']] = $e->getMessage();
        }
    }

    shield_auditar($pdo, 'contrato_trocou_conta', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => $codigo, 'ator' => (string) $ator,
        'antes' => (string) $previa['conta_atual'], 'depois' => (string) $contaNova,
        'detalhe' => 'conta de recebimento trocada; reemitidas: ' . (count($reemitidas) > 0 ? implode(', ', $reemitidas) : 'nenhuma')
            . (count($falhas) > 0 ? '; ficaram na antiga: ' . implode(', ', array_keys($falhas)) : ''),
    ));

    return array('assinatura' => $previa['assinatura'], 'reemitidas' => $reemitidas, 'falhas' => $falhas);
}

/**
 * MUDAR COMO O CLIENTE PAGA -- 10/09/2026, tarde. Assinatura <-> pre-pago,
 * ou os numeros da propria assinatura (valor, ciclo, dia, conta).
 *
 * A REGRA QUE O DONO DO PRODUTO DITOU: a mudanca vale quando o periodo ja
 * pago terminar. Por isso tudo aqui se ancora em $fim = a validade atual (ou
 * hoje, se ja venceu):
 *   - para PRE-PAGO: a assinatura e cancelada (o ciclo para de gerar) e nasce
 *     UMA cobranca com os meses e o valor do periodo, vencendo em $fim. Paga,
 *     a validade anda a partir de $fim (shield_validade_estender ja faz
 *     isso); nao paga, a licenca vence e fica esperando.
 *   - para ASSINATURA: nasce a assinatura com a primeira competencia no mes
 *     de $fim e o dia escolhido; o ciclo gera a primeira mensalidade sete
 *     dias antes, como sempre. Ja havendo assinatura, so os numeros mudam e
 *     valem a partir da proxima cobranca.
 *
 * $pedido: modo ('assinatura'|'prepago'), valor_centavos (o MENSAL, nos dois
 * modos), meses (pre-pago), ciclo_meses e dia_vencimento (assinatura), conta,
 * forma. A assinatura grava o mensal vezes o ciclo (11/09/2026) e a forma, que
 * o ciclo usa em cada mensalidade (14/09/2026).
 */
function shield_mudanca_modo(PDO $pdo, $codigo, array $pedido, $ator)
{
    require_once __DIR__ . '/fechamento.php';
    require_once __DIR__ . '/../planos/ciclo.php';
    $codigo = (int) $codigo;
    $lido = shield_mudanca_atual($pdo, $codigo);
    $e = $lido['empresa'];
    $atual = $lido['atual'];
    $ass = $lido['ctx']['assinatura'];

    $modo = (string) ($pedido['modo'] ?? '') === 'prepago' ? 'prepago' : 'assinatura';
    $valor = max(0, (int) ($pedido['valor_centavos'] ?? 0));
    if ($valor <= 0) {
        throw new RuntimeException('Digite o valor mensal.');
    }
    $conta = max(0, (int) ($pedido['conta'] ?? 0));
    $forma = in_array((string) ($pedido['forma'] ?? ''), array('pix', 'boleto', 'cartao', 'dinheiro'), true) ? (string) $pedido['forma'] : 'pix';

    // A FORMA TEM DE ESTAR NO "COBRA POR" DA CONTA (14/09/2026), e a recusa vem
    // AQUI, antes da transacao. Depois dela a assinatura ja estaria cancelada
    // e a fatura do pre-pago aberta, e a recusa so apareceria como "ficou em
    // rascunho": a troca feita pela metade do que se pediu.
    if ($conta > 0) {
        $contaLinha = shield_cobranca_conta($pdo, $conta);
        if ($contaLinha === null) {
            throw new RuntimeException('A conta de recebimento escolhida nao existe.');
        }
        $recusa = shield_conta_forma_recusa($contaLinha, $forma);
        // Pronta, alem da forma (14/09/2026): o PIX na chave sem chave cancelava a
        // assinatura e deixava a fatura do pre-pago em rascunho, com um aviso depois.
        if ($recusa === null) {
            $recusa = shield_conta_pronta_recusa($contaLinha);
        }
        if ($recusa !== null) {
            throw new RuntimeException($recusa);
        }
    }

    $validade = trim((string) ($e['validade_licenca'] ?? ''));
    $hoje = date('Y-m-d');
    $fim = ($validade !== '' && $validade !== '0000-00-00' && substr($validade, 0, 10) > $hoje) ? substr($validade, 0, 10) : $hoje;

    $propria = !$pdo->inTransaction();
    if ($propria) {
        $pdo->beginTransaction();
    }
    try {
        $cobrancaId = null;
        $repetido = false;
        $assinaturaId = is_array($ass) ? (int) $ass['id'] : null;

        if ($modo === 'prepago') {
            $meses = max(1, (int) ($pedido['meses'] ?? 1));
            $recusa = shield_plano_recorrencia_recusa('avulso', (string) $meses);
            if ($recusa !== null) {
                throw new RuntimeException($recusa);
            }
            if (is_array($ass)) {
                shield_assinatura_cancelar($pdo, (int) $ass['id'], 'trocou para pre-pago de ' . $meses . ' meses a partir de ' . date('d/m/Y', strtotime($fim)));
                $assinaturaId = null;
            }
            // O periodo inteiro, composto como no fechamento: a previa recebe
            // a base do PERIODO (o mensal vezes os meses) e soma modulos e
            // caixas fora do plano vezes os meses.
            $n = shield_fechamento_normalizar(array_merge($e, array(
                'chave' => 'modo', 'modo' => 'prepago', 'meses' => $meses, 'valor_centavos' => $valor * $meses,
                'modulos' => array_keys($atual['modulos']),
                'nterminais' => $atual['nterminais'], 'terminais_inclusos' => $atual['inclusos'],
                'valor_terminal_centavos' => $atual['valor_terminal'],
            )));
            $total = (int) shield_fechamento_previa($pdo, $n)['total'];
            // F5 AQUI E PIOR QUE NA AVULSA (11/09/2026): esta cobranca carrega
            // `meses`, entao a duplicata nao cobra so o dinheiro duas vezes --
            // ela DA O DOBRO DE LICENCA quando as duas sao pagas. E o segundo
            // envio nem esbarrava no cancelamento da assinatura, porque na
            // segunda passada ela ja estava cancelada.
            $jaFeita = shield_cobranca_por_chave($pdo, (string) ($pedido['chave'] ?? ''));
            if ($jaFeita !== null) {
                $cobrancaId = (int) $jaFeita['id'];
                $repetido = true;
            } else {
                $cobrancaId = shield_cobranca_abrir($pdo, array(
                    'empresa' => $codigo,
                    'competencia' => date('Y-m-01', strtotime($fim)),
                    'descricao' => 'Pre-pago ' . $meses . ' ' . ($meses === 1 ? 'mes' : 'meses') . ' a partir de ' . date('d/m/Y', strtotime($fim)),
                    'valor_centavos' => $total,
                    'meses' => $meses,
                    'vencimento' => $fim,
                    'forma' => $forma,
                    'chave' => (string) ($pedido['chave'] ?? ''),
                ));
            }
        } else {
            $ciclo = max(1, (int) ($pedido['ciclo_meses'] ?? 1));
            $recusa = shield_plano_recorrencia_recusa('assinatura', (string) $ciclo);
            if ($recusa !== null) {
                throw new RuntimeException($recusa);
            }
            // ATE 31 -- 23/09/2026. Ver a nota do campo em modules/clientes/mudanca.php:
            // quem lida com mes curto e shield_assinatura_vencimento, que corta pelo
            // ultimo dia do mes; aqui o teto so apagava a escolha do membro.
            $dia = max(1, min(31, (int) ($pedido['dia_vencimento'] ?? 10)));
            if (is_array($ass)) {
                // Os numeros da assinatura que ja existe: valem a partir da proxima.
                // A forma muda junto (14/09/2026): e com ela que o ciclo abre a proxima.
                $pdo->prepare('UPDATE assinatura SET valor_centavos = :v, ciclo_meses = :c, dia_vencimento = :d, fk_conta = :conta, forma = :forma WHERE id = :id')
                    ->execute(array(':v' => $valor * $ciclo, ':c' => $ciclo, ':d' => $dia, ':conta' => $conta > 0 ? $conta : null, ':forma' => $forma, ':id' => (int) $ass['id']));
            } else {
                $pdo->prepare(
                    'INSERT INTO assinatura (fk_empresa, fk_plano, fk_conta, modo, valor_centavos, ciclo_meses, dia_vencimento, situacao, proxima_competencia, forma)
                     VALUES (:e, NULL, :conta, :modo, :valor, :ciclo, :dia, :sit, :comp, :forma)'
                )->execute(array(
                    ':e' => $codigo, ':conta' => $conta > 0 ? $conta : null, ':modo' => 'manual', ':valor' => $valor * $ciclo,
                    // A forma fica na assinatura: o ciclo abre cada mensalidade com ela (14/09/2026).
                    ':forma' => $forma,
                    ':ciclo' => $ciclo, ':dia' => $dia, ':sit' => 'ativa',
                    // A primeira mensalidade e a do mes em que o pre-pago acaba
                    // -- E NUNCA UMA QUE JA VENCEU (11/09/2026). O dia do
                    // vencimento vem do formulario e nao era comparado com nada:
                    // validade ate 25/09 com dia 10 dava a competencia de
                    // setembro vencendo no dia 10, quinze dias atras. O relogio
                    // gerava e emitia na mesma passada, com multa e juros de um
                    // atraso que nunca houve, e a regua ja contava os dias para
                    // suspender um cliente que acabara de assinar.
                    ':comp' => shield_assinatura_primeira_competencia($fim, $dia),
                ));
                $assinaturaId = (int) $pdo->lastInsertId();
            }
        }

        shield_auditar($pdo, 'contrato_trocou_modo', array(
            'alvo_tipo' => 'empresa', 'alvo_id' => $codigo, 'ator' => (string) $ator,
            'antes' => is_array($ass) ? 'assinatura' : 'prepago', 'depois' => $modo,
            'detalhe' => ($modo === 'prepago'
                ? 'pre-pago de ' . (int) $pedido['meses'] . ' meses, R$ ' . shield_dinheiro($valor) . '/mes'
                : 'assinatura R$ ' . shield_dinheiro($valor) . ' a cada ' . (int) ($pedido['ciclo_meses'] ?? 1) . ' mes(es), dia ' . (int) ($pedido['dia_vencimento'] ?? 10))
                . '; vale a partir de ' . date('d/m/Y', strtotime($fim)),
        ));

        if ($propria) {
            $pdo->commit();
        }
    } catch (Throwable $x) {
        if ($propria && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $x;
    }

    // Emite DEPOIS de gravar, como no fechamento: provedor fora do ar deixa a
    // cobranca em rascunho, e nao desfaz a mudanca.
    $aviso = '';
    if ($cobrancaId !== null && $conta > 0 && !$repetido) {
        try {
            shield_cobranca_emitir($pdo, $cobrancaId, $conta);
        } catch (Throwable $x) {
            $aviso = 'A cobranca do pre-pago ficou em rascunho: ' . $x->getMessage();
        }
    }

    return array('modo' => $modo, 'fim' => $fim, 'cobranca' => $cobrancaId, 'assinatura' => $assinaturaId, 'aviso' => $aviso);
}

function shield_mudanca_liberar_se_pendente(PDO $pdo, array $cobranca)
{
    $n = (int) ($cobranca['libera_nterminais'] ?? 0);
    if ($n <= 0) {
        return false;
    }
    try {
        $stmt = $pdo->prepare('UPDATE empresa SET nterminais = :n WHERE codigo = :c AND COALESCE(nterminais, 0) < :n2');
        $stmt->execute(array(':n' => $n, ':c' => (int) $cobranca['fk_empresa'], ':n2' => $n));
        $pdo->prepare('UPDATE cobranca SET libera_nterminais = NULL WHERE id = :id')->execute(array(':id' => (int) $cobranca['id']));
    } catch (Throwable $semColuna) {
        return false;
    }

    shield_auditar($pdo, 'cota_liberada_ao_pagar', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => (int) $cobranca['fk_empresa'], 'ator' => 'rotina',
        'depois' => (string) $n,
        'detalhe' => 'a cobranca #' . (int) $cobranca['id'] . ' foi paga: a cota sobe para ' . $n . ' terminais',
    ));

    return true;
}
