<?php

/**
 * Apagar deixa rastro -- 09/09/2026.
 *
 * As quatro telas de exclusao (cliente, um terminal, todos os terminais de um
 * cliente, plano) davam DELETE e redirecionavam. Sumia um cliente e ninguem
 * sabia quem, quando, nem o que ele tinha. O livro de auditoria ja existia
 * para cobranca e cadastro; faltava justamente para o que nao volta.
 *
 * Cada funcao grava em `antes` O QUE FOI APAGADO, nao so que apagou: depois
 * do DELETE, o livro e a unica copia que sobra. Quem tem de reconstituir um
 * cliente removido por engano comeca por ali.
 *
 * AS TELAS CHAMAM ESTAS FUNCOES E NAO DAO DELETE. Um DELETE solto numa tela
 * e exatamente o que este arquivo veio corrigir.
 */

require_once __DIR__ . '/../cobranca/cobranca.php'; // shield_auditar
require_once __DIR__ . '/../licenca/estado_terminal.php'; // shield_terminal_acoes: a regra da lixeira da tela

/**
 * Apaga o cliente e as maquinas dele. Devolve false quando o cliente nao
 * existe -- e nesse caso nao grava nada, porque nao houve nada.
 *
 * `empresa` e MyISAM e `terminais` e InnoDB: a transacao so protege a segunda
 * metade. E limitacao do esquema, ja conhecida; o rastro no livro e o que
 * permite ao menos saber o que sumiu se a primeira metade falhar.
 *
 * `$onde` vai no fim da frase do livro ("pela Limpeza de cadastros"): o
 * detalhe diz de que tela veio.
 */
function shield_excluir_empresa(PDO $pdo, $codigo, $onde = '')
{
    $codigo = (int) $codigo;
    if ($codigo <= 0) {
        return false;
    }

    $stmt = $pdo->prepare(
        'SELECT codigo, razao, cnpj, nterminais, validade_licenca, bloqueado
           FROM empresa WHERE codigo = :c LIMIT 1'
    );
    $stmt->execute(array(':c' => $codigo));
    $empresa = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!is_array($empresa)) {
        return false;
    }

    $stmt = $pdo->prepare('SELECT CODIGO, NOME_COMPUTADOR, APELIDO, MAC FROM terminais WHERE FK_EMPRESA = :c ORDER BY CODIGO');
    $stmt->execute(array(':c' => $codigo));
    $terminais = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();

    // A tela pode ja estar dentro de uma transacao (e a suite sempre esta):
    // abrir outra estoura "There is already an active transaction".
    $propria = !$pdo->inTransaction();
    if ($propria) {
        $pdo->beginTransaction();
    }
    try {
        $pdo->prepare('DELETE FROM terminais WHERE FK_EMPRESA = :c')->execute(array(':c' => $codigo));
        $stmt = $pdo->prepare('DELETE FROM empresa WHERE codigo = :c');
        $stmt->execute(array(':c' => $codigo));
        if ($stmt->rowCount() <= 0) {
            if ($propria) {
                $pdo->rollBack();
            }

            return false;
        }
        if ($propria) {
            $pdo->commit();
        }
    } catch (Throwable $e) {
        if ($propria && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    shield_auditar($pdo, 'cliente_excluido', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => $codigo,
        'antes' => array('empresa' => $empresa, 'terminais' => $terminais),
        'detalhe' => 'cliente ' . (string) $empresa['razao'] . ' (' . (string) $empresa['cnpj'] . ') apagado com '
            . count($terminais) . ' terminais' . (trim((string) $onde) !== '' ? ' ' . trim((string) $onde) : ''),
    ));

    return true;
}

/**
 * Apaga uma maquina. Com `$soDaEmpresa`, so se ela for daquele cliente -- e
 * a guarda que impede um link antigo, com outro cliente em foco, de apagar a
 * maquina errada. Devolve false quando nao apagou.
 *
 * SO APAGA O QUE A TELA OFERECE APAGAR -- 14/09/2026. A lixeira so aparece na
 * vaga livre e na desativada (shield_terminal_acoes), mas o POST aceitava
 * qualquer codigo: aba aberta desde antes de a maquina voltar a dar sinal, ou
 * formulario montado a mao, apagava o caixa que estava vendendo. A recusa e
 * RuntimeException com o motivo, e nada e apagado nem gravado no livro.
 * PDOException tambem e RuntimeException: quem chama pega a do banco antes.
 */
function shield_excluir_terminal(PDO $pdo, $codigo, $soDaEmpresa = null)
{
    $codigo = (int) $codigo;
    if ($codigo <= 0) {
        return false;
    }

    $sql = 'SELECT t.CODIGO, t.FK_EMPRESA, t.NOME_COMPUTADOR, t.APELIDO, t.MAC, t.ULTIMO_ACESSO, t.DESATIVADO_EM, t.VERSAO_EXE, e.razao
              FROM terminais t LEFT JOIN empresa e ON e.codigo = t.FK_EMPRESA
             WHERE t.CODIGO = :c';
    $params = array(':c' => $codigo);
    if ($soDaEmpresa !== null) {
        $sql .= ' AND t.FK_EMPRESA = :e';
        $params[':e'] = (int) $soDaEmpresa;
    }
    $stmt = $pdo->prepare($sql . ' LIMIT 1');
    $stmt->execute($params);
    $terminal = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!is_array($terminal)) {
        return false;
    }

    $recusa = shield_terminal_recusa_apagar($terminal);
    if ($recusa !== '') {
        throw new RuntimeException($recusa);
    }

    $stmt = $pdo->prepare('DELETE FROM terminais WHERE CODIGO = :c');
    $stmt->execute(array(':c' => $codigo));
    if ($stmt->rowCount() <= 0) {
        return false;
    }

    $apelido = trim((string) ($terminal['APELIDO'] ?? ''));
    $nome = (string) $terminal['NOME_COMPUTADOR'];
    shield_auditar($pdo, 'terminal_excluido', array(
        'alvo_tipo' => 'terminal', 'alvo_id' => $codigo,
        'antes' => $terminal,
        'detalhe' => 'terminal ' . ($apelido !== '' ? $apelido . ' (' . $nome . ')' : $nome)
            . ' ' . (string) $terminal['MAC'] . ' apagado de ' . (string) ($terminal['razao'] ?? 'cliente ' . $terminal['FK_EMPRESA']),
    ));

    return true;
}

/**
 * O MOTIVO DE NAO APAGAR ESTA MAQUINA, ou '' quando pode -- 14/09/2026.
 *
 * A regra NAO e escrita aqui: e a de shield_terminal_acoes, a mesma que
 * desenha a lixeira. Se um dia a calada ganhar "apagar" la, o servidor aceita
 * junto; regra copiada aqui faria o botao aparecer e o POST recusar.
 *
 *   trabalhando  apagar nao adianta: o ERP recadastra a maquina na proxima
 *                abertura, e ela volta sem o apelido
 *   calada       ainda ocupa vaga; o caminho e liberar a vaga primeiro
 *
 * Aceita a linha de `terminais` com ULTIMO_ACESSO e DESATIVADO_EM: sem a
 * segunda, a desativada com sinal recente pareceria trabalhando.
 */
function shield_terminal_recusa_apagar(array $terminal, $agora = null)
{
    if (in_array('apagar', shield_terminal_acoes($terminal, $agora), true)) {
        return '';
    }

    $estado = shield_terminal_estado($terminal, $agora);
    if ($estado['chave'] === 'calada') {
        return 'Esta maquina esta calada e ainda ocupa vaga ate ' . date('d/m/Y', strtotime((string) $estado['ocupa_ate']))
            . '. Libere a vaga primeiro: so se apaga maquina com a vaga livre ou desativada.';
    }

    return 'Esta maquina deu sinal nos ultimos ' . SHIELD_PARQUE_DIAS_SUMIDO . ' dias e nao pode ser apagada:'
        . ' o ERP a cadastra de novo na proxima abertura.';
}

/**
 * O QUE "EXCLUIR TODOS" APAGA E O QUE FICA -- 14/09/2026. Devolve
 * array('apagaveis' => linhas, 'ficam' => array('trabalhando' => n, 'calada' => n)).
 *
 * Uma funcao para a tela de confirmacao ("quantas vao?") e para o apagar: se a
 * tela contasse por um SQL e o apagar decidisse por outro, a confirmacao
 * prometeria um numero e o livro gravaria outro.
 */
function shield_terminais_apagaveis_da_empresa(PDO $pdo, $fkEmpresa, $agora = null)
{
    $resposta = array('apagaveis' => array(), 'ficam' => array('trabalhando' => 0, 'calada' => 0));
    $fkEmpresa = (int) $fkEmpresa;
    if ($fkEmpresa <= 0) {
        return $resposta;
    }

    $stmt = $pdo->prepare(
        'SELECT CODIGO, NOME_COMPUTADOR, APELIDO, MAC, ULTIMO_ACESSO, DESATIVADO_EM
           FROM terminais WHERE FK_EMPRESA = :e ORDER BY CODIGO'
    );
    $stmt->execute(array(':e' => $fkEmpresa));
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: array() as $terminal) {
        if (shield_terminal_recusa_apagar($terminal, $agora) === '') {
            $resposta['apagaveis'][] = $terminal;
            continue;
        }
        $chave = shield_terminal_estado($terminal, $agora)['chave'];
        $resposta['ficam'][$chave] = ($resposta['ficam'][$chave] ?? 0) + 1;
    }

    return $resposta;
}

/**
 * Apaga as maquinas de um cliente que ja nao ocupam vaga (vaga livre e
 * desativada). Devolve quantas foram; zero nao grava nada.
 *
 * ATE 14/09/2026 APAGAVA TODAS, inclusive o caixa que vendia naquela hora --
 * justamente o que a lixeira de cada linha ja se recusava a oferecer. A trava
 * agora e a de shield_excluir_terminal, maquina por maquina, e quantas ficaram
 * vai para o livro. Quem quer saber o que ficou pergunta a
 * shield_terminais_apagaveis_da_empresa depois de apagar.
 *
 * NAO E O CAMINHO DE shield_excluir_empresa NEM DA LIMPEZA: ali o cliente
 * inteiro sai, e maquina de cliente que nao existe nao tem a quem servir.
 * Aqueles continuam levando todas.
 */
function shield_excluir_terminais_da_empresa(PDO $pdo, $fkEmpresa, $agora = null)
{
    $fkEmpresa = (int) $fkEmpresa;
    if ($fkEmpresa <= 0) {
        return 0;
    }

    $previa = shield_terminais_apagaveis_da_empresa($pdo, $fkEmpresa, $agora);
    $terminais = $previa['apagaveis'];
    if (!$terminais) {
        return 0;
    }

    $stmt = $pdo->prepare('SELECT razao FROM empresa WHERE codigo = :e LIMIT 1');
    $stmt->execute(array(':e' => $fkEmpresa));
    $razao = (string) ($stmt->fetchColumn() ?: ('cliente ' . $fkEmpresa));

    // Um marcador por codigo, como a Limpeza: sao inteiros, mas a convencao do
    // painel e parametro. FK_EMPRESA junto e a mesma guarda do link antigo.
    $codigos = array_map('intval', array_column($terminais, 'CODIGO'));
    $marcadores = implode(',', array_fill(0, count($codigos), '?'));
    $stmt = $pdo->prepare('DELETE FROM terminais WHERE FK_EMPRESA = ? AND CODIGO IN (' . $marcadores . ')');
    $stmt->execute(array_merge(array($fkEmpresa), $codigos));
    $apagados = (int) $stmt->rowCount();
    if ($apagados <= 0) {
        return 0;
    }

    $ficam = (int) $previa['ficam']['trabalhando'] + (int) $previa['ficam']['calada'];
    shield_auditar($pdo, 'terminais_excluidos', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => $fkEmpresa,
        'antes' => $terminais,
        'detalhe' => $apagados . ' terminais de ' . $razao . ' apagados de uma vez'
            . ($ficam > 0
                ? '; ficaram ' . $ficam . ' que ainda ocupam vaga (' . (int) $previa['ficam']['trabalhando']
                    . ' trabalhando, ' . (int) $previa['ficam']['calada'] . ' calada' . ((int) $previa['ficam']['calada'] === 1 ? '' : 's') . ')'
                : ''),
    ));

    return $apagados;
}

/** Apaga um plano. O que ele valia fica no livro; cobrancas ja abertas nao mudam. */
function shield_excluir_plano(PDO $pdo, $id)
{
    $id = (int) $id;
    if ($id <= 0) {
        return false;
    }

    $stmt = $pdo->prepare('SELECT * FROM planos WHERE id = :i LIMIT 1');
    $stmt->execute(array(':i' => $id));
    $plano = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!is_array($plano)) {
        return false;
    }

    $stmt = $pdo->prepare('DELETE FROM planos WHERE id = :i');
    $stmt->execute(array(':i' => $id));
    if ($stmt->rowCount() <= 0) {
        return false;
    }

    shield_auditar($pdo, 'plano_excluido', array(
        'alvo_tipo' => 'plano', 'alvo_id' => $id,
        'antes' => $plano,
        'detalhe' => 'plano ' . (string) ($plano['descricao'] ?? '') . ' (' . (string) ($plano['tipo'] ?? '') . ', '
            . (string) ($plano['recorrencia'] ?? '') . ' meses, R$ ' . (string) ($plano['valor'] ?? '') . ') apagado',
    ));

    return true;
}
