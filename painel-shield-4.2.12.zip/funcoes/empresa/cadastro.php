<?php
/**
 * Cadastrar o cliente ANTES de instalar -- 16/09/2026, pedido de um membro.
 *
 * Ate aqui o unico lugar do painel que criava empresa era a rota de licenca
 * (shield_licenca_criar_empresa): a loja so existia depois que o ERP dela
 * ligou. Quem fecha o valor da ativacao antes de instalar fazia a volta pelo
 * proprio computador -- base limpa, cadastra a empresa no ERP, deixa o painel
 * ver --, e pagava dois precos escondidos:
 *
 * A MAQUINA FANTASMA. A mesma chamada que cria a empresa registra o terminal de
 * quem chamou. O computador do membro entrava na cota do cliente e ocupava vaga
 * por trinta dias; com cota pequena, a maquina da loja de verdade chegava e era
 * recusada por cota cheia.
 *
 * O RELOGIO DO TESTE. Ele contava do nascimento do cadastro, entao fechar hoje
 * e instalar daqui a tres semanas entregava a loja com o teste vencido no
 * primeiro dia. Por isso o padrao daqui e `primeira_maquina`: o teste comeca
 * quando alguem realmente instalar (shield_licenca_iniciar_teste_na_primeira_maquina).
 *
 * O QUE ESTA TELA NAO FAZ: liberar licenca. A empresa nasce SEM validade, como
 * a que chega pelo auto-cadastro -- quem libera continua sendo o pagamento, ou
 * a cortesia da primeira fatura no inicio do contrato. Cadastrar aqui e so
 * deixar a loja pronta para receber contrato e cobranca.
 */

require_once __DIR__ . '/../licenca/licenca_assinada.php';   // shield_documento_valido
require_once __DIR__ . '/../licenca/teste.php';              // shield_teste_config
require_once __DIR__ . '/../cobranca/cobranca.php';          // shield_auditar

if (!function_exists('shield_cliente_teste_ate')) {
    /**
     * A data de fim do teste que a tela escolheu, ou null para "comeca quando a
     * primeira maquina ligar".
     *
     * `sem` grava ONTEM em vez de apagar o teste: e o mesmo vocabulario que o
     * resto do painel ja le (teste vencido), e nao exige coluna nova para dizer
     * "este aqui nao tem teste".
     */
    function shield_cliente_teste_ate(array $dados, array $cfg)
    {
        $modo = (string) ($dados['teste'] ?? 'primeira_maquina');

        if ($modo === 'sem') {
            return date('Y-m-d', strtotime('-1 day'));
        }

        if ($modo === 'data') {
            $ate = substr(trim((string) ($dados['teste_ate'] ?? '')), 0, 10);
            $dia = DateTimeImmutable::createFromFormat('!Y-m-d', $ate);
            if ($dia === false) {
                throw new RuntimeException('A data de fim do teste nao foi entendida. Use o seletor de data.');
            }
            if ($dia->format('Y-m-d') < date('Y-m-d')) {
                throw new RuntimeException('A data de fim do teste ja passou. Escolha hoje ou uma data adiante.');
            }

            return $dia->format('Y-m-d');
        }

        return null;
    }
}

if (!function_exists('shield_cliente_cadastrar')) {
    /**
     * Cria a loja como LEAD e devolve o codigo. Recusa com RuntimeException, e
     * a frase e para o membro ler na tela.
     */
    function shield_cliente_cadastrar(PDO $pdo, array $dados)
    {
        $cnpj = preg_replace('/\D+/', '', (string) ($dados['cnpj'] ?? ''));
        if (!shield_documento_valido($cnpj)) {
            throw new RuntimeException(
                'O CNPJ nao passa na conferencia dos digitos. Confira o numero -- e o mesmo que o ERP vai mandar,'
                . ' e e por ele que a loja sera reconhecida quando instalar.'
            );
        }

        $razao = trim((string) ($dados['razao'] ?? ''));
        if ($razao === '') {
            throw new RuntimeException('Escreva o nome do cliente: e por ele que voce acha a loja na lista.');
        }

        // A MESMA BUSCA DA ROTA DE LICENCA, com a pontuacao tirada dos DOIS
        // lados: o cadastro legado do ERP grava o documento com mascara, e
        // comparar cru criaria um segundo cadastro para a mesma loja -- a
        // maquina dela cairia num dos dois, a esmo.
        $stmt = $pdo->prepare(
            'SELECT codigo, razao FROM empresa
              WHERE REPLACE(REPLACE(REPLACE(cnpj, ".", ""), "/", ""), "-", "") = :cnpj
              ORDER BY codigo LIMIT 1'
        );
        $stmt->execute(array(':cnpj' => $cnpj));
        $ja = $stmt->fetch(PDO::FETCH_ASSOC);
        if (is_array($ja)) {
            $nome = trim((string) ($ja['razao'] ?? ''));
            throw new RuntimeException(
                'Este CNPJ ja esta no painel: ' . ($nome !== '' ? $nome : 'cliente sem nome')
                . ' (codigo ' . (int) $ja['codigo'] . '). Abra a ficha dele em vez de cadastrar de novo.'
            );
        }

        $testeAte = shield_cliente_teste_ate($dados, shield_teste_config($pdo));
        $texto = static function ($v, $tam) {
            return substr(trim((string) $v), 0, $tam);
        };

        // As colunas de endereco sao NOT NULL sem default (4.1.29): o que nao se
        // sabe ainda entra como texto vazio, e o ERP completa quando a loja
        // instalar (shield_licenca_completar_cadastro).
        // `cadastro_manual` (V4_2_7) e a marca que autoriza carimbar o teste na
        // primeira maquina. Quem chega pela rota de licenca nunca a tem, e por
        // isso a linha dele continua sem ser escrita (4.1.5).
        $pdo->prepare(
            'INSERT INTO empresa (cnpj, razao, endereco, cidade, bairro, cep, uf, fone, email,
                                  data, nterminais, validade_licenca, bloqueado, teste_ate, cadastro_manual)
             VALUES (:cnpj, :razao, :endereco, :cidade, :bairro, :cep, :uf, :fone, :email,
                     NOW(), NULL, NULL, :bloqueado, :teste_ate, 1)'
        )->execute(array(
            ':cnpj' => $cnpj,
            ':razao' => $texto($razao, 50),
            ':endereco' => $texto($dados['endereco'] ?? '', 50),
            ':cidade' => $texto($dados['cidade'] ?? '', 35),
            ':bairro' => $texto($dados['bairro'] ?? '', 35),
            ':cep' => preg_replace('/\D+/', '', (string) ($dados['cep'] ?? '')),
            ':uf' => strtoupper($texto($dados['uf'] ?? '', 2)),
            ':fone' => $texto($dados['fone'] ?? '', 20),
            ':email' => $texto($dados['email'] ?? '', 120),
            ':bloqueado' => 'N',
            ':teste_ate' => $testeAte,
        ));

        $codigo = (int) $pdo->lastInsertId();

        shield_auditar($pdo, 'cliente_cadastrado', array(
            'alvo_tipo' => 'empresa',
            'alvo_id' => $codigo,
            'depois' => array('cnpj' => $cnpj, 'razao' => $razao, 'teste_ate' => $testeAte),
            'detalhe' => 'cadastrado a mao, sem terminal; teste '
                . ($testeAte === null ? 'comeca na primeira maquina' : 'ate ' . $testeAte),
        ));

        return $codigo;
    }
}
