<?php

/**
 * Limpeza das empresas que chegaram sozinhas e nunca viraram cliente.
 *
 * Com o auto-cadastro, todo mundo que instala aparece: cliente testando, tecnico
 * experimentando, CNPJ digitado errado, copia que ninguem vendeu. A lista cresce
 * e deixa de servir justamente para o que ela existe -- ver quem esta esperando
 * voce fechar negocio.
 *
 * O criterio e DUPLO, e nao e detalhe: sem validade E sem sinal ha
 * SHIELD_LIMPEZA_DIAS dias. Empresa que ainda pinga e prospecto vivo -- apaga-la
 * seria jogar fora exatamente quem esta testando agora.
 *
 * E DELETE de verdade, nunca 'bloqueado'. Quem sai daqui pode voltar um dia e
 * fechar negocio; marcado como bloqueado ele voltaria RECUSADO, e ninguem
 * lembraria por que. Apagado, ele se cadastra de novo como qualquer instalacao
 * nova.
 *
 * NAO roda sozinha. Apagar cadastro de cliente de madrugada, sem ninguem na
 * frente, e o tipo de automatismo que morde uma vez e nunca mais se confia.
 *
 * SAIU DA TELA EM 17/09/2026, junto com o ultimo DELETE solto do painel: a tela
 * apagava empresa e terminais direto, e o livro de auditoria nao ficava sabendo
 * nem quem saiu. Agora cada empresa passa por shield_excluir_empresa, que grava
 * o que foi apagado.
 */

require_once __DIR__ . '/exclusao.php'; // shield_excluir_empresa

if (!defined('SHIELD_LIMPEZA_DIAS')) {
    define('SHIELD_LIMPEZA_DIAS', 90);
}

/**
 * As candidatas, com o que se precisa saber para decidir.
 *
 * "visto" e o sinal mais RECENTE entre os terminais dela; nulo quer dizer que
 * nenhuma maquina jamais apareceu.
 *
 * ENCERRADAS ENTRAM NA LISTA -- 10/09/2026, fatia 5. Encerrar e marca (ficha do
 * cliente ou a rotina, no teste que ninguem fechou); apagar de verdade e AQUI,
 * com gente conferindo. Sem isso a marca nao teria saida.
 */
function shield_limpeza_candidatas(PDO $pdo)
{
    $stmt = $pdo->prepare(
        "SELECT e.codigo, e.cnpj, e.razao, e.cidade, e.uf, e.data, e.encerrado_em, e.encerrado_por, e.encerrado_motivo,
                (SELECT COUNT(*) FROM terminais t WHERE t.FK_EMPRESA = e.codigo) AS maquinas,
                (SELECT MAX(t.ULTIMO_ACESSO) FROM terminais t WHERE t.FK_EMPRESA = e.codigo) AS visto
           FROM empresa e
          WHERE e.validade_licenca IS NULL OR e.encerrado_em IS NOT NULL
         HAVING encerrado_em IS NOT NULL
             OR (visto IS NULL AND e.data < DATE_SUB(NOW(), INTERVAL :dias DAY))
             OR (visto IS NOT NULL AND visto < DATE_SUB(NOW(), INTERVAL :dias2 DAY))
          ORDER BY visto IS NULL DESC, visto ASC, e.codigo ASC"
    );
    $stmt->execute(array(':dias' => SHIELD_LIMPEZA_DIAS, ':dias2' => SHIELD_LIMPEZA_DIAS));

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
}

/**
 * Apaga as marcadas que ainda sao candidatas. Devolve
 * array('apagadas' => n, 'fora' => n, 'erro' => texto).
 *
 * A LISTA E REFEITA AQUI: o que veio do formulario e so a marcacao do operador.
 * Empresa que deixou de ser candidata entre a tela e o botao -- porque voltou a
 * dar sinal, ou porque alguem inseriu a validade -- nao pode ser apagada por
 * causa de um POST antigo. Essas contam em 'fora'.
 *
 * UMA EMPRESA POR VEZ, pela funcao que grava no livro. Nao ha transacao em volta
 * de todas: `empresa` e MyISAM e nunca voltou no rollback, e o que ja saiu fica
 * registrado. Na primeira falha para, e 'erro' diz quantas sairam antes.
 */
function shield_limpeza_apagar(PDO $pdo, array $codigos)
{
    $resposta = array('apagadas' => 0, 'fora' => 0, 'erro' => '');
    $marcadas = array_values(array_unique(array_filter(array_map('intval', $codigos), static function ($v) {
        return $v > 0;
    })));
    if ($marcadas === array()) {
        return $resposta;
    }

    $validas = array();
    foreach (shield_limpeza_candidatas($pdo) as $c) {
        $validas[(int) $c['codigo']] = true;
    }

    foreach ($marcadas as $codigo) {
        if (!isset($validas[$codigo])) {
            $resposta['fora']++;
            continue;
        }
        try {
            if (shield_excluir_empresa($pdo, $codigo, 'pela Limpeza de cadastros')) {
                $resposta['apagadas']++;
            } else {
                $resposta['fora']++;
            }
        } catch (Throwable $e) {
            error_log('[limpeza] empresa ' . $codigo . ': ' . $e->getMessage());
            $resposta['erro'] = 'Nao foi possivel remover a empresa ' . $codigo . ' (' . $e->getMessage() . ').'
                . ($resposta['apagadas'] > 0 ? ' As ' . $resposta['apagadas'] . ' anteriores ja sairam.' : '');
            break;
        }
    }

    return $resposta;
}
