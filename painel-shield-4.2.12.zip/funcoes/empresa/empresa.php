<?php

if (!function_exists('shield_terminais_url')) {
    function shield_terminais_url(array $params)
    {
        return shield_build_url('terminais.php', $params);
    }
}

/*
 * `empresa` e o contexto publico de navegacao: e o mesmo nome usado pela
 * lista de clientes, pelo parque e pela ficha. `fk_empresa` continua aceito
 * nas URLs antigas e nos formularios que ja estavam abertos no navegador.
 * Assim a transicao nao quebra favoritos nem volta o operador para "todas"
 * quando ele sai de uma ficha de cliente.
 */
if (!function_exists('shield_empresa_contexto_id')) {
    function shield_empresa_contexto_id(array $origem)
    {
        $valor = $origem['empresa'] ?? ($origem['fk_empresa'] ?? null);
        if (!filter_var($valor, FILTER_VALIDATE_INT)) {
            return null;
        }

        $empresa = (int) $valor;
        return $empresa > 0 ? $empresa : null;
    }
}

if (!function_exists('shield_url_com_empresa')) {
    function shield_url_com_empresa($basePath, $empresa = null, array $params = array())
    {
        if ($empresa !== null && (int) $empresa > 0) {
            $params['empresa'] = (int) $empresa;
        }

        return shield_build_url($basePath, $params);
    }
}

if (!function_exists('shield_terminal_redirect_url')) {
    function shield_terminal_redirect_url($status = null, $fkEmpresa = null, $q = '', $page = null)
    {
        $params = [];
        if ($fkEmpresa !== null && (int) $fkEmpresa > 0) {
            $params['empresa'] = (int) $fkEmpresa;
        }
        if ($q !== '') {
            $params['q'] = (string) $q;
        }
        if ($status !== null && $status !== '') {
            $params['status'] = (string) $status;
        }
        if ($page !== null && (int) $page > 1) {
            $params['page'] = (int) $page;
        }

        return shield_terminais_url($params);
    }
}

if (!function_exists('shield_bulk_redirect_url')) {
    function shield_bulk_redirect_url($status, $fkEmpresa, $q = '', $page = null)
    {
        $params = ['empresa' => (int) $fkEmpresa];
        if ($q !== '') {
            $params['q'] = (string) $q;
        }
        if ($page !== null && (int) $page > 1) {
            $params['page'] = (int) $page;
        }
        if ($status !== null && $status !== '') {
            $params['status'] = (string) $status;
        }

        return shield_terminais_url($params);
    }
}

/**
 * O livro da tela de editar cadastro -- 09/09/2026.
 *
 * Ate aqui NENHUMA tela de cliente auditava: `grep -rn shield_auditar
 * modules/clientes/` devolvia zero. E a de editar cadastro grava os tres
 * numeros que decidem se a loja trabalha -- a cota de terminais, a validade e
 * o bloqueio.
 *
 * A COTA NAO E ROTULO: o painel a usa para devolver `excedente` no token
 * assinado, e o ERP traduz isso em caixa que nao abre. Baixar a cota derruba
 * maquina que estava vendendo, e ninguem tinha como saber depois quem baixou,
 * quando, nem qual era o numero antes.
 *
 * SO O QUE MUDOU ENTRA NA LINHA. Despejar o cadastro inteiro a cada gravacao
 * esconderia a alteracao no meio de campos iguais, e quem le o livro esta
 * procurando exatamente a diferenca.
 *
 * A LISTA E FECHADA de proposito. Campo que nao esta aqui nao vira linha --
 * assim mudar endereco ou telefone nao enche o livro de ruido, e o dia em que
 * um campo novo passar a valer dinheiro alguem precisa vir aqui e decidir.
 */
if (!function_exists('shield_empresa_campos_auditados')) {
    function shield_empresa_campos_auditados()
    {
        return array(
            'nterminais'         => 'terminais',
            'terminais_inclusos' => 'terminais inclusos',
            'valor_terminal'     => 'terminal adicional',
            'validade_licenca'   => 'validade',
            'bloqueado'          => 'bloqueio',
            'cnpj_representante' => 'representante',
        );
    }
}

if (!function_exists('shield_empresa_representante')) {
    /**
     * O CNPJ DO REPRESENTANTE A GRAVAR -- 17/09/2026. Devolve
     * array('valor' => string|null, 'erro' => string).
     *
     * A tela conferia o numero contra a tabela `representante`, que nada grava
     * desde que as telas de representante sairam. O caminho legado do ERP grava
     * a coluna (uDadosWeb.pas copia do Firebird, e o cadastro de la poe 14 zeros
     * quando a loja deixa em branco): salvar o Contrato desses clientes dava
     * "Representante nao encontrado" ate alguem apagar o campo.
     *
     * VAI COMO VEIO, so sem espaco nas pontas, e sem digito verificador: o
     * ControleWeb Licencas filtra a coluna com igualdade, e os 14 zeros sao o
     * valor de fabrica do ERP. O que ja estava gravado passa sem conferencia --
     * nao foi a tela que o escreveu.
     */
    function shield_empresa_representante($texto, $gravado = null)
    {
        $texto = trim((string) $texto);
        if ($texto === '') {
            return array('valor' => null, 'erro' => '');
        }
        if ($gravado !== null && $texto === trim((string) $gravado)) {
            return array('valor' => $texto, 'erro' => '');
        }
        if (strlen($texto) > 20 || !preg_match('/^[0-9.\/ -]+$/', $texto) || !preg_match('/[0-9]/', $texto)) {
            return array('valor' => null, 'erro' => 'CNPJ do representante invalido: so numeros, ponto, barra e traco.');
        }

        return array('valor' => $texto, 'erro' => '');
    }
}

if (!function_exists('shield_empresa_auditar_cadastro')) {
    /**
     * Devolve true quando escreveu. Gravacao que nao mudou nada devolve false
     * sem tocar o livro -- nao e evento, e linha assim so afoga o que importa.
     */
    function shield_empresa_auditar_cadastro(PDO $pdo, $codigo, array $antes, array $depois)
    {
        $rotulos = shield_empresa_campos_auditados();

        $de = array();
        $para = array();
        $frases = array();

        foreach ($rotulos as $campo => $rotulo) {
            if (!array_key_exists($campo, $antes) || !array_key_exists($campo, $depois)) {
                continue;
            }

            // Comparacao como TEXTO: o formulario devolve tudo em string e o
            // banco devolve int para nterminais. Comparando com === direto,
            // 2 e "2" contariam como mudanca e toda gravacao viraria linha.
            if ((string) $antes[$campo] === (string) $depois[$campo]) {
                continue;
            }

            $de[$campo] = $antes[$campo];
            $para[$campo] = $depois[$campo];

            $mostra = static function ($v) {
                $v = trim((string) $v);
                return $v === '' ? '(vazio)' : $v;
            };
            $frases[] = $rotulo . ': ' . $mostra($antes[$campo]) . ' para ' . $mostra($depois[$campo]);
        }

        if ($para === array()) {
            return false;
        }

        // Carregado aqui dentro, e nao no topo: este arquivo entra em toda tela
        // de cliente, e cobranca.php e pesado. So quem grava paga o custo.
        require_once __DIR__ . '/../cobranca/cobranca.php';
        if (!function_exists('shield_auditar')) {
            return false;
        }

        return shield_auditar($pdo, 'cliente_cadastro_alterado', array(
            'alvo_tipo' => 'empresa',
            'alvo_id'   => (int) $codigo,
            'antes'     => $de,
            'depois'    => $para,
            'detalhe'   => implode('; ', $frases),
        ));
    }
}
