<?php

/**
 * O fechamento numa tela so -- 10/09/2026, fatia 7 da reorganizacao
 * (docs/reorganizacao-do-painel.md, secao 5, passos 5 a 7).
 *
 * O lead em avaliacao vira contrato numa unica gravacao: cadastro,
 * responsaveis, o que contratou (terminais, inclusos, terminal extra,
 * modulos), como paga (assinatura ou pre-pago, valor digitado na hora, sem
 * plano cadastrado antes), por onde o dinheiro entra, e a primeira cobranca.
 *
 * A ORDEM QUE IMPORTA:
 *   1. shield_fechamento_validar CONFERE TUDO antes de gravar qualquer coisa;
 *   2. shield_fechamento_gravar grava tudo numa transacao;
 *   3. SO ENTAO fala com o provedor (emitir). Caindo a internet ali, o cliente
 *      ja esta cadastrado e a cobranca fica em rascunho esperando o botao de
 *      tentar de novo.
 *
 * O CONTRATO SO COMECA GERANDO A FATURA (14/09/2026, noite). A caixa "Emitir a
 * primeira cobranca agora" saiu: o Dar inicio sempre emite, e emitir_agora nao
 * e mais lido. O que ja se sabe ANTES e impediria a fatura de sair (conta
 * desligada, PIX na chave sem chave, CNPJ que o gateway recusa) e recusado
 * antes de gravar, por shield_fechamento_fatura_recusa. So o que depende de
 * falar com o provedor (credencial recusada, rede fora) fica para o passo 3:
 * desfazer o contrato depois de o provedor ter visto a cobranca deixaria um
 * codigo vivo la fora sem cobranca aqui dentro, e `empresa` e MyISAM.
 *
 * A CHAVE UNICA e o que faz F5 nao cadastrar duas vezes: o segundo POST com a
 * mesma chave devolve o que o primeiro fez. A unicidade e do banco.
 *
 * CADASTRAR NAO LIBERA O ERP. A licenca so anda quando o pagamento entra, pela
 * ponte de sempre (shield_validade_estender). A unica excecao e a cortesia da
 * primeira fatura, marcada a mao (liberar_agora). Quem faz o cliente e o
 * fechado_em, gravado so pelo "Dar inicio ao contrato" (4.1.19).
 *
 * O RASCUNHO NAO E CONTRATO (14/09/2026). "Gravar rascunho" guarda o formulario
 * em empresa.fechamento_rascunho e mais nada: sem assinatura, cobranca, modulo,
 * cota, validade, cortesia, senha da area nem fechado_em. Ate aqui os dois
 * botoes passavam pela mesma gravacao, e o rascunho tirava a loja de Em
 * avaliacao, matava o teste de sete dias e deixava uma assinatura ativa que o
 * ciclo emitia no mes seguinte.
 */

require_once __DIR__ . '/../cobranca/cobranca_motor.php';
require_once __DIR__ . '/../cobranca/assinatura.php';
require_once __DIR__ . '/../planos/ciclo.php';
require_once __DIR__ . '/../licenca/modulos_licenca.php';
require_once __DIR__ . '/empresa.php';

use Shield\Cobranca\Registro;

/** Os campos de cadastro que o fechamento grava, com o tamanho da coluna. */
function shield_fechamento_campos_cadastro()
{
    return array(
        'razao' => 50, 'endereco' => 50, 'bairro' => 35, 'cidade' => 35, 'cep' => 8, 'uf' => 2,
        'fone' => 20, 'email' => 255,
        'responsavel_nome' => 255, 'responsavel_fone' => 20, 'responsavel_email' => 255,
        'financeiro_nome' => 255, 'financeiro_fone' => 20, 'financeiro_email' => 255,
    );
}

/**
 * O valor de um campo de cadastro para o banco -- 15/09/2026. Vazio vira NULL,
 * menos nas colunas NOT NULL da tabela antiga (razao, endereco, bairro, cidade,
 * cep, uf), que recebem ''. O NULL ali so passava porque o MariaDB relaxado da
 * bancada o troca por '' com aviso; em modo estrito, o padrao de hospedagem que
 * o ajuste da conexao mantem (4.1.28), era erro 1048 e o contrato nao comecava.
 * O fechamento e o Contrato do cliente gravam por aqui.
 */
function shield_fechamento_valor_cadastro($campo, $valor)
{
    if ((string) $valor !== '') {
        return $valor;
    }

    return in_array($campo, array('razao', 'endereco', 'bairro', 'cidade', 'cep', 'uf'), true) ? '' : null;
}

/**
 * Normaliza o que veio do formulario. Devolve o mesmo array, limpo: textos
 * cortados no tamanho da coluna, CEP so digitos, UF maiuscula, numeros
 * inteiros, datas Y-m-d ou ''.
 */
function shield_fechamento_normalizar(array $d)
{
    $n = array();
    foreach (shield_fechamento_campos_cadastro() as $campo => $tamanho) {
        $v = trim((string) ($d[$campo] ?? ''));
        if ($campo === 'cep') {
            $v = preg_replace('/\D+/', '', $v);
        }
        // Telefone guarda SO DIGITOS (ate 11): a mascara (00)00000-0000 e da tela.
        if (substr($campo, -4) === 'fone') {
            $v = substr(preg_replace('/\D+/', '', $v), 0, 11);
        }
        if ($campo === 'uf') {
            $v = strtoupper($v);
        }
        $n[$campo] = substr($v, 0, $tamanho);
    }

    $n['chave'] = substr(preg_replace('/[^A-Za-z0-9\-]/', '', (string) ($d['chave'] ?? '')), 0, 40);
    $n['nterminais'] = max(0, (int) ($d['nterminais'] ?? 0));
    $n['terminais_inclusos'] = max(0, (int) ($d['terminais_inclusos'] ?? 0));
    // A TELA MANDA INCLUSOS + ADICIONAIS (10/09/2026, noite); o contratado e a soma.
    if (isset($d['terminais_adicionais'])) {
        $n['nterminais'] = $n['terminais_inclusos'] + max(0, (int) $d['terminais_adicionais']);
    }
    $n['valor_terminal_centavos'] = max(0, (int) ($d['valor_terminal_centavos'] ?? 0));
    $n['modulos'] = array_values(array_unique(array_map('intval', (array) ($d['modulos'] ?? array()))));

    $n['modo'] = (string) ($d['modo'] ?? '') === 'prepago' ? 'prepago' : 'assinatura';
    $n['valor_centavos'] = max(0, (int) ($d['valor_centavos'] ?? 0));
    $n['ciclo_meses'] = max(1, (int) ($d['ciclo_meses'] ?? 1));
    $n['meses'] = max(1, (int) ($d['meses'] ?? 1));
    $n['vencimento'] = shield_fechamento_data((string) ($d['vencimento'] ?? ''));
    $n['conta'] = max(0, (int) ($d['conta'] ?? 0));
    // "dinheiro" e a forma da conta de dinheiro em especie: sem codigo, o membro da baixa.
    $n['forma'] = in_array((string) ($d['forma'] ?? ''), array('pix', 'boleto', 'cartao', 'dinheiro'), true) ? (string) $d['forma'] : 'pix';
    // DAR INICIO SEMPRE EMITE (14/09/2026, noite). O campo que vier e ignorado
    // de proposito: a caixa saiu da tela, e um "0" so chega de tela aberta antes
    // da atualizacao ou de chamador antigo. Ler o "0" deixaria o contrato comecar
    // sem fatura de novo. O rascunho desliga logo abaixo: la nada vai ao provedor.
    $n['emitir_agora'] = true;
    // A CORTESIA DA PRIMEIRA FATURA (11/09/2026): a licenca vale desde ja ate
    // o vencimento da primeira cobranca, sem o cliente ter pago nada. So nesta
    // primeira; dali em diante quem precisa de prazo pede pela promessa.
    $n['liberar_agora'] = !empty($d['liberar_agora']);
    // A SENHA DA AREA DO CLIENTE (10/09/2026, tarde): vazia = nao mexe.
    $n['area_senha'] = (string) ($d['area_senha'] ?? '');
    // O BOTAO QUE FOI CLICADO (14/09/2026). Os dois mandavam `salvar` e ninguem
    // lia: o rascunho era so "iniciar sem emitir". O padrao e iniciar, porque e
    // o que todo chamador sem o campo (Mudar o contrato, editar o cadastro, os
    // testes) sempre quis dizer. No rascunho nada vai ao provedor e nada libera
    // a licenca, marque a pessoa o que marcar.
    $n['salvar'] = (string) ($d['salvar'] ?? '') === 'rascunho' ? 'rascunho' : 'iniciar';
    if ($n['salvar'] === 'rascunho') {
        $n['emitir_agora'] = false;
        $n['liberar_agora'] = false;
    }

    return $n;
}

function shield_fechamento_data($texto)
{
    $texto = substr(trim((string) $texto), 0, 10);
    $d = DateTimeImmutable::createFromFormat('!Y-m-d', $texto);

    return ($d instanceof DateTimeImmutable && $d->format('Y-m-d') === $texto) ? $texto : '';
}

/**
 * CONFERE TUDO ANTES DE GRAVAR. Devolve campo => mensagem; vazio quando pode
 * gravar. Recebe o array ja normalizado.
 *
 * O CEP e cobrado AQUI, e nao na hora de emitir o boleto -- que e quando ja
 * e tarde. So para boleto: PIX nao precisa de endereco.
 */
function shield_fechamento_validar(PDO $pdo, array $n)
{
    // O RASCUNHO SO CONFERE FORMATO (14/09/2026): ele nao grava nada que tenha
    // efeito, e cobrar responsaveis, conta e valor de quem so quer guardar metade
    // da ligacao faria o membro perder a outra metade.
    if (($n['salvar'] ?? 'iniciar') === 'rascunho') {
        return shield_fechamento_validar_rascunho($n);
    }

    $erros = array();

    if ($n['chave'] === '') {
        $erros['chave'] = 'A tela abriu sem chave; recarregue.';
    }
    if ($n['razao'] === '') {
        $erros['razao'] = 'Informe a razao social.';
    }
    if ($n['nterminais'] < 1) {
        $erros['nterminais'] = 'Quantos caixas o cliente contratou? Pelo menos um.';
    }
    if ($n['terminais_inclusos'] > $n['nterminais']) {
        $erros['terminais_inclusos'] = 'Inclusos no plano nao pode passar do contratado.';
    }
    if ($n['valor_centavos'] <= 0) {
        $erros['valor_centavos'] = 'Digite o valor.';
    }
    if ($n['vencimento'] === '') {
        $erros['vencimento'] = 'Informe o vencimento como data.';
    }
    if ($n['modo'] === 'assinatura' && shield_plano_recorrencia_recusa('assinatura', (string) $n['ciclo_meses']) !== null) {
        $erros['ciclo_meses'] = shield_plano_recorrencia_recusa('assinatura', (string) $n['ciclo_meses']);
    }
    if ($n['modo'] === 'prepago' && shield_plano_recorrencia_recusa('avulso', (string) $n['meses']) !== null) {
        $erros['meses'] = shield_plano_recorrencia_recusa('avulso', (string) $n['meses']);
    }
    // OS RESPONSAVEIS SAO OBRIGATORIOS (10/09/2026): quem assina e quem paga,
    // com nome, telefone de 10 ou 11 digitos e e-mail que e e-mail.
    foreach (array('responsavel' => 'quem assina', 'financeiro' => 'quem paga') as $quem => $rotulo) {
        if ($n[$quem . '_nome'] === '') {
            $erros[$quem . '_nome'] = 'Informe o nome de ' . $rotulo . '.';
        }
        if ($n[$quem . '_fone'] === '') {
            $erros[$quem . '_fone'] = 'Informe o telefone de ' . $rotulo . '.';
        } elseif (!in_array(strlen($n[$quem . '_fone']), array(10, 11), true)) {
            $erros[$quem . '_fone'] = 'Telefone de ' . $rotulo . ' incompleto: precisa de DDD e numero.';
        }
        if ($n[$quem . '_email'] === '') {
            $erros[$quem . '_email'] = 'Informe o e-mail de ' . $rotulo . '.';
        } elseif (filter_var($n[$quem . '_email'], FILTER_VALIDATE_EMAIL) === false) {
            $erros[$quem . '_email'] = 'E-mail de ' . $rotulo . ' precisa de @ e ponto.';
        }
    }
    if ($n['fone'] !== '' && !in_array(strlen($n['fone']), array(10, 11), true)) {
        $erros['fone'] = 'Telefone da loja incompleto: precisa de DDD e numero.';
    }
    // A CONTA E OBRIGATORIA (10/09/2026): nao existe "ninguem agora". Sem
    // conta a cobranca nao teria por onde sair, nem agora nem depois.
    if ($n['conta'] <= 0) {
        $erros['conta'] = 'Escolha a conta de recebimento por onde a cobranca vai sair.';
    }
    if ($n['email'] !== '' && filter_var($n['email'], FILTER_VALIDATE_EMAIL) === false) {
        $erros['email'] = 'E-mail da loja precisa de @ e ponto.';
    }
    if ($n['area_senha'] !== '' && strlen($n['area_senha']) < 6) {
        $erros['area_senha'] = 'A senha da area do cliente precisa de pelo menos 6 caracteres.';
    }
    if ($n['area_senha'] !== '' && $n['email'] === '') {
        $erros['area_senha'] = 'A senha da area do cliente precisa do e-mail da loja: e com ele que o cliente entra.';
    }
    if ($n['vencimento'] !== '' && $n['vencimento'] < date('Y-m-d')) {
        $erros['vencimento'] = 'O primeiro vencimento nao pode ser antes de hoje.';
    }
    if ($n['forma'] === 'boleto' && strlen($n['cep']) !== 8) {
        $erros['cep'] = 'Boleto precisa do CEP do cliente (8 digitos). Agora, e nao na hora de emitir.';
    }

    if ($n['conta'] > 0) {
        $conta = shield_cobranca_conta($pdo, $n['conta']);
        if ($conta === null || empty($conta['ativo'])) {
            $erros['conta'] = 'A conta de recebimento escolhida nao existe ou esta desligada.';
        } else {
            $provedor = Registro::para((string) $conta['provedor']);
            if ($provedor === null) {
                $erros['conta'] = 'O provedor ' . $conta['provedor'] . ' ainda nao tem adaptador neste painel.';
            } else {
                // A FORMA TEM DE ESTAR NO "COBRA POR" DA CONTA (14/09/2026), e nao
                // so no que o provedor faz: o Asaas faz cartao, a conta com cartao
                // desmarcado nao cobra por ele. Dinheiro entra na mesma regra: e a
                // unica forma da conta de dinheiro, e de nenhuma outra.
                $recusa = shield_conta_forma_recusa($conta, $n['forma']);
                if ($recusa !== null) {
                    $erros['forma'] = $recusa;
                }
            }
        }
    }

    foreach ($n['modulos'] as $m) {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM modulo WHERE id = :id AND ativo = 1');
        $stmt->execute(array(':id' => $m));
        if ((int) $stmt->fetchColumn() === 0) {
            $erros['modulos'] = 'Um dos modulos marcados saiu do catalogo.';
        }
    }

    return $erros;
}

/**
 * A conferencia do rascunho: so formato. Obrigatorias so a chave e a razao; o
 * resto, quando preenchido, tem de estar escrito direito, porque volta para a
 * tela e para o "Dar inicio", que confere tudo de novo.
 */
function shield_fechamento_validar_rascunho(array $n)
{
    $erros = array();
    if ($n['chave'] === '') {
        $erros['chave'] = 'A tela abriu sem chave; recarregue.';
    }
    if ($n['razao'] === '') {
        $erros['razao'] = 'Informe a razao social.';
    }
    if ($n['terminais_inclusos'] > $n['nterminais']) {
        $erros['terminais_inclusos'] = 'Inclusos no plano nao pode passar do contratado.';
    }
    foreach (array('fone' => 'da loja', 'responsavel_fone' => 'de quem assina', 'financeiro_fone' => 'de quem paga') as $campo => $rotulo) {
        if ($n[$campo] !== '' && !in_array(strlen($n[$campo]), array(10, 11), true)) {
            $erros[$campo] = 'Telefone ' . $rotulo . ' incompleto: precisa de DDD e numero.';
        }
    }
    foreach (array('email' => 'da loja', 'responsavel_email' => 'de quem assina', 'financeiro_email' => 'de quem paga') as $campo => $rotulo) {
        if ($n[$campo] !== '' && filter_var($n[$campo], FILTER_VALIDATE_EMAIL) === false) {
            $erros[$campo] = 'E-mail ' . $rotulo . ' precisa de @ e ponto.';
        }
    }
    if ($n['cep'] !== '' && strlen($n['cep']) !== 8) {
        $erros['cep'] = 'CEP com 8 digitos, ou em branco.';
    }

    return $erros;
}

/**
 * A conta que a tela mostra antes de confirmar: base, modulos, terminal
 * extra, total -- a mesma composicao que o ciclo vai usar todo mes.
 */
function shield_fechamento_previa(PDO $pdo, array $n)
{
    require_once __DIR__ . '/../cobranca/composicao.php';
    $itens = array();
    // OS ITENS MENSAIS ENTRAM VEZES O PERIODO. No pre-pago, vezes os meses
    // pagos de uma vez (o valor digitado ja e o do periodo). Na assinatura,
    // vezes o CICLO -- 11/09/2026: ate aqui era "vezes um", e uma semestral
    // levava um mes de modulo numa fatura que cobre seis. O valor digitado na
    // assinatura e o MENSAL, e por isso aqui ele tambem multiplica.
    $assinatura = $n['modo'] !== 'prepago';
    $vezes = $assinatura ? max(1, (int) $n['ciclo_meses']) : max(1, (int) $n['meses']);
    $total = $assinatura ? $n['valor_centavos'] * $vezes : $n['valor_centavos'];
    $porMes = $assinatura ? $n['valor_centavos'] : (int) round($n['valor_centavos'] / $vezes);

    foreach ($n['modulos'] as $m) {
        $stmt = $pdo->prepare('SELECT nome, valor_centavos FROM modulo WHERE id = :id');
        $stmt->execute(array(':id' => $m));
        $mod = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($mod) {
            $itens[] = array('nome' => (string) $mod['nome'] . ($vezes > 1 ? ' x ' . $vezes : ''), 'centavos' => (int) $mod['valor_centavos'] * $vezes);
            $total += (int) $mod['valor_centavos'] * $vezes;
            $porMes += (int) $mod['valor_centavos'];
        }
    }

    $extras = max(0, $n['nterminais'] - $n['terminais_inclusos']);
    if ($extras > 0 && $n['valor_terminal_centavos'] > 0) {
        $itens[] = array(
            'nome' => $extras . ' terminal' . ($extras === 1 ? '' : 'is') . ' fora do plano' . ($vezes > 1 ? ' x ' . $vezes : ''),
            'centavos' => $extras * $n['valor_terminal_centavos'] * $vezes,
        );
        $total += $extras * $n['valor_terminal_centavos'] * $vezes;
        $porMes += $extras * $n['valor_terminal_centavos'];
    }

    // 'total' e o da COBRANCA (do ciclo ou do periodo); 'por_mes' e o que a
    // tela mostra ao lado, para o membro conferir contra o que combinou.
    return array('base' => $n['valor_centavos'], 'itens' => $itens, 'total' => $total, 'extras' => $extras,
                 'vezes' => $vezes, 'por_mes' => $porMes);
}

/**
 * GRAVA TUDO DE UMA VEZ. Devolve ['empresa', 'assinatura' (id|null),
 * 'cobranca' (id|null), 'emitida' (bool), 'aviso' (string), 'repetido' (bool),
 * 'salvar' ('iniciar'|'rascunho')]. A tela decide a frase por 'salvar', e nao
 * por 'emitida': o Dar inicio com o provedor fora do ar tambem faz o cliente.
 *
 * Idempotente pela chave: o segundo POST devolve o que o primeiro fez.
 *
 * `empresa` e MyISAM e o resto InnoDB: a transacao protege assinatura,
 * modulos e cobranca; o UPDATE do cadastro e o ultimo passo antes do commit,
 * para a janela de meio-gravado ser a menor possivel.
 */
function shield_fechamento_gravar(PDO $pdo, $codigo, array $n, $ator)
{
    $codigo = (int) $codigo;
    $ator = substr(trim((string) $ator), 0, 80) ?: 'rotina';

    // O RASCUNHO NAO PASSA DAQUI (14/09/2026): ver o cabecalho.
    if (($n['salvar'] ?? 'iniciar') === 'rascunho') {
        return shield_fechamento_gravar_rascunho($pdo, $codigo, $n, $ator);
    }

    // F5: a mesma chave ja fechou. Devolve o que foi feito, sem gravar nada.
    $stmt = $pdo->prepare('SELECT codigo FROM empresa WHERE fechamento_chave = :k LIMIT 1');
    $stmt->execute(array(':k' => $n['chave']));
    $jaFechou = (int) $stmt->fetchColumn();
    if ($jaFechou > 0) {
        return shield_fechamento_resultado_anterior($pdo, $jaFechou);
    }

    $empresa = shield_cob_empresa($pdo, $codigo);
    if ($empresa === null) {
        throw new RuntimeException('Cliente nao encontrado.');
    }
    $antes = $empresa;

    // UM CONTRATO POR CLIENTE (11/09/2026, alargado em 14/09/2026). A chave so
    // protege o F5 da MESMA tela; abrir o fechamento de novo gera chave nova. A
    // recusa vem DEPOIS da chave: antes dela, o F5 do primeiro envio viraria erro.
    $recusa = shield_fechamento_ja_iniciado($pdo, $empresa);
    if ($recusa !== null) {
        throw new RuntimeException($recusa);
    }

    // A FATURA TEM DE PODER SAIR (14/09/2026, noite): o que ja se sabe que a
    // impediria recusa aqui, antes de qualquer gravacao.
    $recusa = shield_fechamento_fatura_recusa($pdo, $n, $empresa);
    if ($recusa !== null) {
        throw new RuntimeException($recusa);
    }

    $propria = !$pdo->inTransaction();
    if ($propria) {
        $pdo->beginTransaction();
    }
    try {
        // 1. Modulos: fecha o que saiu, abre o que entrou, com o valor de
        //    tabela COPIADO (mexer no catalogo depois nao reajusta ninguem).
        $stmt = $pdo->prepare('SELECT id, fk_modulo FROM empresa_modulo WHERE fk_empresa = :e AND ate IS NULL');
        $stmt->execute(array(':e' => $codigo));
        $abertos = array();
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $em) {
            $abertos[(int) $em['fk_modulo']] = (int) $em['id'];
        }
        foreach ($abertos as $modulo => $id) {
            if (!in_array($modulo, $n['modulos'], true)) {
                $pdo->prepare('UPDATE empresa_modulo SET ate = CURDATE() WHERE id = :id')->execute(array(':id' => $id));
            }
        }
        foreach ($n['modulos'] as $modulo) {
            if (isset($abertos[$modulo])) {
                continue;
            }
            $stmt = $pdo->prepare('SELECT valor_centavos FROM modulo WHERE id = :id');
            $stmt->execute(array(':id' => $modulo));
            $pdo->prepare(
                'INSERT INTO empresa_modulo (fk_empresa, fk_modulo, valor_centavos, desde) VALUES (:e, :m, :v, CURDATE())'
            )->execute(array(':e' => $codigo, ':m' => $modulo, ':v' => (int) $stmt->fetchColumn()));
        }

        // 2. Assinatura (so no modo assinatura). Nasce AQUI, e nao na tela de
        //    cobrancas: o fechamento e o unico lugar que sabe o contrato inteiro.
        $assinaturaId = null;
        if ($n['modo'] === 'assinatura') {
            $stmt = $pdo->prepare(
                'INSERT INTO assinatura
                    (fk_empresa, fk_plano, fk_conta, modo, valor_centavos, ciclo_meses, dia_vencimento, situacao, proxima_competencia, forma)
                 VALUES (:e, NULL, :conta, :modo, :valor, :ciclo, :dia, :sit, :comp, :forma)'
            );
            $stmt->execute(array(
                ':e' => $codigo,
                // A FORMA FICA NA ASSINATURA (14/09/2026): o ciclo abre cada
                // mensalidade com ela. Antes so a primeira saia na forma escolhida.
                ':forma' => $n['forma'],
                ':conta' => $n['conta'] > 0 ? $n['conta'] : null,
                ':modo' => 'manual',
                // A ASSINATURA GUARDA O PRECO DO CICLO (11/09/2026): e o que a
                // cobranca de cada ciclo cobra e o que shield_assinatura_por_mes
                // divide. A tela pede o mensal; a multiplicacao mora aqui.
                ':valor' => $n['valor_centavos'] * max(1, (int) $n['ciclo_meses']),
                ':ciclo' => $n['ciclo_meses'],
                // O dia do primeiro vencimento vira o dia de todo ciclo. Ate 31
                // desde 23/09/2026: o corte em 28 fazia a assinatura vencer num
                // dia diferente do da primeira fatura que o cliente recebeu.
                // Mes curto quem resolve e shield_assinatura_vencimento.
                ':dia' => max(1, min(31, (int) date('j', strtotime($n['vencimento'])))),
                ':sit' => 'ativa',
                ':comp' => shield_assinatura_competencia($n['vencimento']),
            ));
            $assinaturaId = (int) $pdo->lastInsertId();
        }

        // 3. O cadastro, os responsaveis, o contrato e a chave -- NUNCA a
        //    validade. Antes da primeira cobranca porque a composicao le o
        //    contrato (inclusos, valor do extra, modulos) da propria empresa.
        $sets = array();
        $params = array(':codigo' => $codigo, ':chave' => $n['chave']);
        foreach (array_keys(shield_fechamento_campos_cadastro()) as $campo) {
            $sets[] = $campo . ' = :' . $campo;
            $params[':' . $campo] = shield_fechamento_valor_cadastro($campo, $n[$campo]);
        }
        $sets[] = 'nterminais = :nterminais';
        $params[':nterminais'] = $n['nterminais'];
        $sets[] = 'terminais_inclusos = :inclusos';
        $params[':inclusos'] = $n['terminais_inclusos'];
        $sets[] = 'valor_terminal_centavos = :vt';
        $params[':vt'] = $n['valor_terminal_centavos'];
        $sets[] = 'fechamento_chave = :chave';
        $sets[] = 'fechado_em = NOW()';
        // O contrato comecou: o rascunho, se havia, virou isto aqui e sai da fila.
        $sets[] = 'fechamento_rascunho = NULL';
        $sets[] = 'rascunho_em = NULL';
        // A VALIDADE SO E TOCADA AQUI, e so por escolha explicita de quem
        // fechou. Ela vai ate o vencimento da primeira cobranca: pago, a ponte
        // de pagamento anda a partir dessa data (a ancora de 4.1.12) e o
        // cliente nao perde dia nenhum; nao pago, vence sozinha e a regua
        // assume, como qualquer mes seguinte.
        if ($n['liberar_agora']) {
            $sets[] = 'validade_licenca = :validade';
            $params[':validade'] = $n['vencimento'];
        }
        if ($n['area_senha'] !== '') {
            $sets[] = 'area_senha = :area_senha';
            $params[':area_senha'] = password_hash($n['area_senha'], PASSWORD_DEFAULT);
        }
        $pdo->prepare('UPDATE empresa SET ' . implode(', ', $sets) . ' WHERE codigo = :codigo')->execute($params);

        // 4. A primeira cobranca. Assinatura: a mensalidade COMPOSTA (modulos e
        //    terminal extra entram, como todo mes). Pre-pago: o valor digitado,
        //    com os meses gravados para a validade andar o combinado.
        if ($n['modo'] === 'assinatura') {
            $cobrancaId = shield_cobranca_abrir($pdo, array(
                'empresa' => $codigo,
                'assinatura' => $assinaturaId,
                'competencia' => shield_assinatura_competencia($n['vencimento']),
                'descricao' => 'Mensalidade ' . date('m/Y', strtotime($n['vencimento'])),
                'valor_centavos' => $n['valor_centavos'],
                'meses' => $n['ciclo_meses'],
                'vencimento' => $n['vencimento'],
                'forma' => $n['forma'],
                'compor' => true,
            ));
            // O ciclo seguinte comeca DEPOIS desta: senao a passada de amanha
            // geraria a mesma competencia e a unicidade recusaria com barulho.
            $stmt = $pdo->prepare('SELECT * FROM assinatura WHERE id = :id');
            $stmt->execute(array(':id' => $assinaturaId));
            shield_assinatura_avancar($pdo, $stmt->fetch(PDO::FETCH_ASSOC));
        } else {
            $cobrancaId = shield_cobranca_abrir($pdo, array(
                'empresa' => $codigo,
                'competencia' => date('Y-m-01', strtotime($n['vencimento'])),
                'descricao' => 'Pre-pago ' . $n['meses'] . ' ' . ($n['meses'] === 1 ? 'mes' : 'meses'),
                // O periodo inteiro: valor digitado + itens mensais x meses (ver a previa).
                'valor_centavos' => shield_fechamento_previa($pdo, $n)['total'],
                'meses' => $n['meses'],
                'vencimento' => $n['vencimento'],
                'forma' => $n['forma'],
            ));
        }

        if ($propria) {
            $pdo->commit();
        }
    } catch (Throwable $e) {
        if ($propria && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    if ($n['liberar_agora']) {
        // Licenca dada sem dinheiro entrar e decisao de gente: fica no livro
        // com a data ate onde vale, que e o que alguem vai querer conferir.
        shield_auditar($pdo, 'licenca_adiantada', array(
            'alvo_tipo' => 'empresa', 'alvo_id' => $codigo, 'ator' => $ator,
            'depois' => (string) $n['vencimento'],
            'detalhe' => 'liberado no fechamento, antes do primeiro pagamento: a licenca vale ate '
                . date('d/m/Y', strtotime($n['vencimento'])) . ', o vencimento da primeira fatura.',
        ));
    }

    shield_empresa_auditar_cadastro($pdo, $codigo, $antes, shield_cob_empresa($pdo, $codigo) ?: $antes);
    shield_auditar($pdo, 'fechamento', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => $codigo, 'ator' => $ator,
        // O LIVRO DIZ O BOTAO (14/09/2026): o rascunho tem acao propria,
        // fechamento_rascunho. Antes os dois deixavam o mesmo rastro.
        'detalhe' => 'botao Dar inicio ao contrato: ' . ($n['modo'] === 'assinatura'
                ? 'assinatura ' . shield_plano_ciclo_rotulo($n['ciclo_meses']) . ' de R$ ' . shield_dinheiro($n['valor_centavos'] * max(1, (int) $n['ciclo_meses']))
                    . ((int) $n['ciclo_meses'] > 1 ? ' (R$ ' . shield_dinheiro($n['valor_centavos']) . ' por mes)' : '')
                : 'pre-pago de ' . $n['meses'] . ' meses por R$ ' . shield_dinheiro($n['valor_centavos']))
            . ', ' . $n['nterminais'] . ' terminais (' . $n['terminais_inclusos'] . ' inclusos), '
            . count($n['modulos']) . ' modulo(s); primeiro vencimento ' . date('d/m/Y', strtotime($n['vencimento']))
            . '. A licenca so anda quando pagar.',
    ));

    // 5. SO AGORA o provedor, SEMPRE (14/09/2026, noite). Falhando aqui, o
    //    contrato FICA iniciado e a fatura fica em rascunho, com o aviso dizendo
    //    onde emitir. Desfazer nao e opcao: o provedor pode ter criado o codigo
    //    antes de a resposta se perder, e apagar a cobranca deixaria esse codigo
    //    vivo sem ninguem aqui para dar baixa.
    //
    //    "EMITIDA" E A COBRANCA TER SAIDO DO RASCUNHO, e nao a emissao nao ter
    //    estourado: resposta que o motor nao sabe ler grava a tentativa e deixa
    //    a cobranca onde estava. Assim a frase continua certa para o dinheiro e
    //    o PIX na chave, que abrem a fatura sem provedor do outro lado, seja qual
    //    for o jeito que o motor venha a dar a eles.
    $aviso = '';
    $erroEmissao = '';
    try {
        shield_cobranca_emitir($pdo, $cobrancaId, $n['conta']);
    } catch (Throwable $e) {
        $erroEmissao = $e->getMessage();
    }
    $depois = shield_cob_ler($pdo, $cobrancaId);
    $emitida = is_array($depois) && (string) $depois['situacao'] !== SHIELD_COB_RASCUNHO;
    if (!$emitida) {
        $aviso = ($erroEmissao !== ''
                ? 'Contrato iniciado, mas a primeira fatura nao saiu: ' . rtrim($erroEmissao, '. ') . '.'
                : 'Contrato iniciado, mas o provedor respondeu sem dizer se a fatura foi criada.')
            . ' Ela ficou em rascunho em Cobrancas: confira ali e emita quando a conta responder.';
        // O livro guarda o motivo: o aviso da tela some no proximo clique.
        shield_auditar($pdo, 'fechamento_fatura_nao_saiu', array(
            'alvo_tipo' => 'empresa', 'alvo_id' => $codigo, 'ator' => $ator,
            'detalhe' => 'contrato iniciado com a primeira fatura (cobranca ' . (int) $cobrancaId . ') em rascunho: '
                . ($erroEmissao !== '' ? $erroEmissao : 'resposta do provedor sem situacao'),
        ));
    }

    return array(
        'empresa' => $codigo, 'assinatura' => $assinaturaId, 'cobranca' => $cobrancaId,
        'emitida' => $emitida, 'aviso' => $aviso, 'repetido' => false, 'salvar' => 'iniciar',
    );
}

/**
 * Por que este cliente NAO pode passar pelo fechamento de novo, ou null.
 *
 * Ate 14/09/2026 a recusa so olhava assinatura ativa: o segundo fechamento em
 * pre-pago abria outra fatura com meses, tambem emitida, e o cliente antigo,
 * com validade e sem fechado_em, podia ser "fechado" de novo pela rota
 * digitada. Contrato iniciado, licenca (mesmo vencida) ou assinatura ativa:
 * qualquer um dos tres ja e contrato, e contrato muda por "Mudar o contrato".
 *
 * A PALAVRA "assinatura" FICA NA FRASE: EstornoECreditoTest confere, e e o
 * caso que o membro mais encontra.
 */
function shield_fechamento_ja_iniciado(PDO $pdo, array $empresa)
{
    $frase = 'Este cliente ja tem contrato iniciado (assinatura, pre-pago ou licenca). Para mudar valor, ciclo, conta ou forma, use "Mudar o contrato" na ficha dele.';
    if (trim((string) ($empresa['fechado_em'] ?? '')) !== '') {
        return $frase;
    }
    $validade = trim((string) ($empresa['validade_licenca'] ?? ''));
    if ($validade !== '' && $validade !== '0000-00-00') {
        return $frase;
    }
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM assinatura WHERE fk_empresa = :e AND situacao = 'ativa'");
        $stmt->execute(array(':e' => (int) ($empresa['codigo'] ?? 0)));
        if ((int) $stmt->fetchColumn() > 0) {
            return $frase;
        }
    } catch (PDOException $semTabela) {
    }

    return null;
}

/**
 * Por que a primeira fatura NAO sairia por esta conta, ou null -- 14/09/2026,
 * noite. So o que da para saber sem falar com o provedor, porque e isso que
 * pode ser recusado antes de gravar; o resto e o passo 5 de
 * shield_fechamento_gravar.
 *
 * "GERAR A FATURA" MUDA COM A CONTA, e nenhuma pode falhar por falta de
 * provedor: no gateway e o codigo emitido la; no PIX na chave e o copia e cola
 * montado aqui com a chave do membro (sem chave o adaptador recusa, e por isso
 * a pergunta vem antes); no dinheiro e a cobranca aberta a receber no balcao.
 * As tres saem pela mesma shield_cobranca_emitir.
 *
 * O CNPJ entra porque o motor o recusa antes de ir a gateway automatico, e
 * nesta tela ele esta travado: comecar o contrato com a fatura presa para
 * sempre em rascunho seria o contrato sem fatura que saiu.
 *
 * As frases NAO dizem "nada foi gravado": a tela ja abre a lista de erros com
 * essa frase, e repetida no fim de cada item ela so atrapalha a leitura.
 */
function shield_fechamento_fatura_recusa(PDO $pdo, array $n, array $empresa)
{
    $conta = (int) ($n['conta'] ?? 0) > 0 ? shield_cob_conta($pdo, (int) $n['conta']) : null;
    if ($conta === null || empty($conta['ativo'])) {
        return 'Escolha uma conta de recebimento ligada: e por ela que a primeira fatura sai.';
    }
    $provedor = Registro::para((string) $conta['provedor']);
    if ($provedor === null) {
        return 'O provedor ' . $conta['provedor'] . ' ainda nao tem adaptador neste painel.';
    }
    $nome = trim((string) ($conta['apelido'] ?? '')) ?: (string) $conta['provedor'];
    if ((string) $conta['provedor'] === 'pix_estatico' && trim((string) ($conta['_credenciais']['chave_pix'] ?? '')) === '') {
        return 'A conta ' . $nome . ' esta sem chave PIX, e a primeira fatura nao sairia. '
            . 'Cadastre a chave em Formas de recebimento, ou escolha outra conta.';
    }
    if (!empty($provedor->capacidades($conta)['automatico'])) {
        require_once __DIR__ . '/../licenca/licenca_assinada.php'; // shield_documento_valido
        if (!shield_documento_valido((string) ($empresa['cnpj'] ?? ''))) {
            return 'O CNPJ desta loja (' . (string) ($empresa['cnpj'] ?? '') . ') nao e valido, e ' . $nome
                . ' recusaria a fatura. Escolha a conta de dinheiro ou a de PIX na sua chave, que nao passam por provedor.';
        }
    }

    return null;
}

/** O que o rascunho guarda: o formulario menos a chave, a senha e as caixas, que so valem no Dar inicio. */
function shield_fechamento_rascunho_campos()
{
    return array_merge(array_keys(shield_fechamento_campos_cadastro()), array(
        'nterminais', 'terminais_inclusos', 'valor_terminal_centavos', 'modulos',
        'modo', 'valor_centavos', 'ciclo_meses', 'meses', 'vencimento', 'conta', 'forma',
    ));
}

/**
 * GRAVA O RASCUNHO, E SO ELE (14/09/2026). O formulario vai inteiro para
 * empresa.fechamento_rascunho como JSON, e rascunho_em marca de quando e -- e
 * e isso que a fila de avaliacao mostra. Nenhuma outra coluna muda, nem a do
 * cadastro: o que foi digitado so vale no "Dar inicio", que confere tudo.
 *
 * Sobrescrever e idempotente: F5 grava o mesmo texto de novo. A SENHA DA AREA
 * NAO ENTRA, nem no JSON: a area do cliente abre para quem tem senha, e quem
 * ainda avalia nao tem contrato para ver nem cobranca para pagar.
 */
function shield_fechamento_gravar_rascunho(PDO $pdo, $codigo, array $n, $ator)
{
    $codigo = (int) $codigo;
    $empresa = shield_cob_empresa($pdo, $codigo);
    if ($empresa === null) {
        throw new RuntimeException('Cliente nao encontrado.');
    }
    // Rascunho de quem ja tem contrato abriria um segundo pela mesma tela.
    $recusa = shield_fechamento_ja_iniciado($pdo, $empresa);
    if ($recusa !== null) {
        throw new RuntimeException($recusa);
    }

    $guardar = array();
    foreach (shield_fechamento_rascunho_campos() as $campo) {
        $guardar[$campo] = $n[$campo] ?? null;
    }
    $pdo->prepare('UPDATE empresa SET fechamento_rascunho = :r, rascunho_em = NOW() WHERE codigo = :c')->execute(array(
        ':r' => json_encode($guardar, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
        ':c' => $codigo,
    ));

    shield_auditar($pdo, 'fechamento_rascunho', array(
        'alvo_tipo' => 'empresa', 'alvo_id' => $codigo, 'ator' => (string) $ator,
        'detalhe' => 'botao Gravar rascunho: '
            . ($n['modo'] === 'assinatura' ? 'assinatura de R$ ' . shield_dinheiro($n['valor_centavos']) . ' por mes' : 'pre-pago de ' . $n['meses'] . ' meses por R$ ' . shield_dinheiro($n['valor_centavos']))
            . ', ' . (int) $n['nterminais'] . ' terminais, ' . count($n['modulos']) . ' modulo(s). Nada foi ao provedor e a loja continua em avaliacao.',
    ));

    return array(
        'empresa' => $codigo, 'assinatura' => null, 'cobranca' => null,
        'emitida' => false, 'aviso' => '', 'repetido' => false, 'salvar' => 'rascunho',
    );
}

/**
 * O rascunho guardado, pronto para o array_merge da tela; array vazio quando
 * nao ha. So volta o que shield_fechamento_rascunho_campos lista.
 *
 * VENCIMENTO QUE JA PASSOU NAO VOLTA: o Dar inicio recusa data antes de hoje e
 * o campo tem min de hoje, entao o membro abriria o rascunho numa tela que nao
 * deixa concluir. Sem ele, vale o padrao da tela.
 */
function shield_fechamento_rascunho_ler(array $empresa)
{
    $dados = json_decode((string) ($empresa['fechamento_rascunho'] ?? ''), true);
    if (!is_array($dados)) {
        return array();
    }
    $volta = array_intersect_key($dados, array_flip(shield_fechamento_rascunho_campos()));
    $vence = shield_fechamento_data((string) ($volta['vencimento'] ?? ''));
    if ($vence === '' || $vence < date('Y-m-d')) {
        unset($volta['vencimento']);
    }

    return $volta;
}

/** O que o primeiro POST com esta chave fez, para o segundo devolver igual. */
function shield_fechamento_resultado_anterior(PDO $pdo, $codigo)
{
    $stmt = $pdo->prepare('SELECT id FROM assinatura WHERE fk_empresa = :e ORDER BY id DESC LIMIT 1');
    $stmt->execute(array(':e' => (int) $codigo));
    $assinatura = (int) $stmt->fetchColumn();

    $stmt = $pdo->prepare('SELECT id, situacao FROM cobranca WHERE fk_empresa = :e ORDER BY id DESC LIMIT 1');
    $stmt->execute(array(':e' => (int) $codigo));
    $c = $stmt->fetch(PDO::FETCH_ASSOC) ?: array('id' => 0, 'situacao' => '');

    return array(
        'empresa' => (int) $codigo, 'assinatura' => $assinatura > 0 ? $assinatura : null,
        'cobranca' => (int) $c['id'], 'emitida' => (string) $c['situacao'] !== SHIELD_COB_RASCUNHO,
        'aviso' => 'Este fechamento ja tinha sido gravado (F5?). Nada foi feito de novo.', 'repetido' => true,
        'salvar' => 'iniciar',
    );
}
