<?php

/**
 * O contrato do cliente e o aceite dele -- 01/10/2026.
 *
 * Pedido no feedback da 4.2.10 ("possibilidade de gerar o PDF do contrato
 * assinado"). Ate aqui o painel nao tinha DOCUMENTO de contrato nenhum: o
 * "contrato" era so o que o "Dar inicio ao contrato" grava (empresa,
 * assinatura, modulos, primeira fatura). As tabelas `contratos` e
 * `config_contratos` da V2_0_0 nunca foram lidas por codigo nenhum, e o A1
 * guardado em Minha empresa nunca assinou nada.
 *
 * DECIDIDO COM O VICTOR: o texto e um MODELO que cada membro escreve uma vez,
 * com campos que o painel preenche; e "assinado" e o ACEITE do cliente final na
 * area do cliente -- "li e aceito", com data, IP, o e-mail que entrou e o hash do
 * texto. Nada de A1 aqui: ele assinaria pela revenda, e quem precisa concordar
 * e o cliente.
 *
 * O ACEITE GUARDA O TEXTO INTEIRO, e nao so o hash. O modelo muda, o preco muda
 * (Mudar o contrato), o endereco muda; o PDF do que foi aceito tem de sair igual
 * ao que o cliente leu naquele dia. O hash vai impresso no PDF para quem quiser
 * conferir que o texto e o registrado.
 *
 * TEXTO MUDOU, ACEITE DE NOVO. Se o texto preenchido de hoje nao bate com o do
 * ultimo aceite (outro modelo, outro valor, outra cota), a area do cliente pede
 * o aceite outra vez; o antigo fica no historico. Por isso nenhum campo pode
 * depender do relogio -- uma {{data}} de hoje faria todo cliente "perder" o
 * aceite a cada meia-noite.
 *
 * NASCE DESLIGADO (4.1): sem o membro gravar o modelo e ligar o aceite, a area
 * do cliente nao mostra contrato nenhum.
 */

// O AUTOLOAD DO PAINEL, E NAO O DO COMPOSER, que o painel nao carrega: sem esta linha
// o Shield\Pdf\Documento existe nos testes, onde o Composer resolve tudo, e da erro
// fatal no painel. Foi assim que a primeira versao deste arquivo passou na suite
// inteira e quebrou no primeiro PDF gerado de verdade.
require_once __DIR__ . '/../nucleo/autoload.php';
require_once __DIR__ . '/../cobranca/cobranca.php';      // shield_dinheiro, shield_auditar
require_once __DIR__ . '/../licenca/situacao.php';       // shield_cnpj
require_once __DIR__ . '/../planos/ciclo.php';           // shield_plano_ciclo_rotulo

const SHIELD_CONTRATO_CHAVE_MODELO = 'contrato_modelo';
const SHIELD_CONTRATO_CHAVE_ATIVO = 'contrato_ativo';

/** O teto do modelo: um contrato de verdade tem poucas paginas, e o campo e TEXT. */
const SHIELD_CONTRATO_MAX_CARACTERES = 60000;

/** O ponto de partida que a tela oferece a quem ainda nao escreveu o seu. */
function shield_contrato_modelo_padrao(): string
{
    $texto = @file_get_contents(__DIR__ . '/modelo_padrao.txt');

    return is_string($texto) ? str_replace("\r\n", "\n", $texto) : '';
}

/**
 * O que esta configurado. 'gravado' diz se o membro ja gravou algum modelo --
 * sem isso a tela mostra o padrao como sugestao, e nada vale ainda.
 */
function shield_contrato_config(PDO $pdo): array
{
    try {
        $modelo = (string) shield_get_system_meta($pdo, SHIELD_CONTRATO_CHAVE_MODELO, '');
        $ativo = (string) shield_get_system_meta($pdo, SHIELD_CONTRATO_CHAVE_ATIVO, '0') === '1';
    } catch (Throwable $semTabela) {
        $modelo = '';
        $ativo = false;
    }

    return array(
        'modelo' => $modelo !== '' ? $modelo : shield_contrato_modelo_padrao(),
        'gravado' => $modelo !== '',
        'ativo' => $ativo && $modelo !== '',
    );
}

/** Grava o modelo e liga ou desliga o aceite na area do cliente. */
function shield_contrato_definir(PDO $pdo, string $modelo, bool $ativo): void
{
    $modelo = trim(str_replace(array("\r\n", "\r"), "\n", $modelo));
    if ($modelo === '') {
        throw new RuntimeException('O modelo do contrato esta vazio. Escreva o texto antes de gravar.');
    }
    if (mb_strlen($modelo) > SHIELD_CONTRATO_MAX_CARACTERES) {
        throw new RuntimeException('O modelo passou de ' . SHIELD_CONTRATO_MAX_CARACTERES . ' caracteres. Encurte o texto.');
    }

    $antes = shield_contrato_config($pdo);
    shield_set_system_meta($pdo, SHIELD_CONTRATO_CHAVE_MODELO, $modelo);
    shield_set_system_meta($pdo, SHIELD_CONTRATO_CHAVE_ATIVO, $ativo ? '1' : '0');

    shield_auditar($pdo, 'contrato_modelo_gravado', array(
        'alvo_tipo' => 'contrato_modelo',
        'antes' => array('hash' => $antes['gravado'] ? hash('sha256', $antes['modelo']) : null, 'ativo' => $antes['ativo']),
        'depois' => array('hash' => hash('sha256', $modelo), 'ativo' => $ativo),
        'detalhe' => $ativo ? 'aceite ligado na area do cliente' : 'aceite desligado',
    ));
}

/** Os campos que o painel preenche, com a explicacao que a tela mostra. */
function shield_contrato_campos(): array
{
    return array(
        'cliente_razao' => 'Razão social do cliente',
        'cliente_cnpj' => 'CNPJ ou CPF do cliente',
        'cliente_endereco' => 'Endereço do cliente, com cidade e CEP',
        'cliente_email' => 'E-mail do cliente',
        'cliente_responsavel' => 'Quem assina pelo cliente (Contrato do cliente)',
        'revenda_razao' => 'A sua razão social (Minha empresa)',
        'revenda_cnpj' => 'O seu CNPJ',
        'revenda_endereco' => 'O seu endereço',
        'revenda_email' => 'O seu e-mail de contato',
        'revenda_telefone' => 'O seu telefone',
        'plano' => 'Como o cliente paga, numa frase: valor, ciclo e vencimento',
        'valor_mensal' => 'Valor por mês da assinatura',
        'ciclo' => 'Ciclo de cobrança (mensal, trimestral...)',
        'valor_ciclo' => 'Valor de cada fatura do ciclo',
        'dia_vencimento' => 'Dia do vencimento',
        'terminais' => 'Quantidade de terminais contratados',
        'modulos' => 'Módulos contratados, com o valor de cada um',
        'inicio' => 'Data em que o contrato começou',
    );
}

/** O valor de cada campo para este cliente. Nada aqui depende do relogio. */
function shield_contrato_valores(PDO $pdo, array $empresa): array
{
    $codigo = (int) ($empresa['codigo'] ?? 0);
    $juntar = static function (array $partes): string {
        return implode(', ', array_values(array_filter(array_map('trim', $partes), static fn ($p) => $p !== '')));
    };

    $softhouse = array();
    try {
        $softhouse = $pdo->query('SELECT * FROM softhouse LIMIT 1')->fetch(PDO::FETCH_ASSOC) ?: array();
    } catch (Throwable $semTabela) {
    }

    $cidadeCliente = trim((string) ($empresa['cidade'] ?? '')) . (trim((string) ($empresa['uf'] ?? '')) !== '' ? '/' . trim((string) $empresa['uf']) : '');
    $cidadeRevenda = trim((string) ($softhouse['cidade'] ?? '')) . (trim((string) ($softhouse['estado'] ?? '')) !== '' ? '/' . trim((string) $softhouse['estado']) : '');
    $cepCliente = trim((string) ($empresa['cep'] ?? ''));
    $cepRevenda = trim((string) ($softhouse['cep'] ?? ''));

    $v = array(
        'cliente_razao' => trim((string) ($empresa['razao'] ?? '')),
        'cliente_cnpj' => shield_cnpj((string) ($empresa['cnpj'] ?? '')),
        'cliente_endereco' => $juntar(array((string) ($empresa['endereco'] ?? ''), (string) ($empresa['bairro'] ?? ''),
            $cidadeCliente, $cepCliente !== '' ? 'CEP ' . $cepCliente : '')),
        'cliente_email' => trim((string) ($empresa['email'] ?? '')),
        'cliente_responsavel' => trim((string) ($empresa['responsavel_nome'] ?? '')),
        'revenda_razao' => trim((string) ($softhouse['razao'] ?? '')),
        'revenda_cnpj' => shield_cnpj((string) ($softhouse['cnpj'] ?? '')),
        'revenda_endereco' => $juntar(array(trim((string) ($softhouse['endereco'] ?? '')) . (trim((string) ($softhouse['numero'] ?? '')) !== '' ? ', ' . trim((string) $softhouse['numero']) : ''),
            $cidadeRevenda, $cepRevenda !== '' ? 'CEP ' . $cepRevenda : '')),
        'revenda_email' => trim((string) ($softhouse['email'] ?? '')),
        'revenda_telefone' => trim((string) ($softhouse['telefone'] ?? '')),
        'terminais' => ($empresa['nterminais'] ?? null) === null || $empresa['nterminais'] === '' ? 'não informado' : (string) (int) $empresa['nterminais'],
        'inicio' => !empty($empresa['fechado_em']) ? date('d/m/Y', strtotime((string) $empresa['fechado_em'])) : 'a data de início do contrato',
        'plano' => 'pré-pago, pelo valor de cada fatura emitida',
        'valor_mensal' => 'conforme cada fatura',
        'ciclo' => 'pré-pago',
        'valor_ciclo' => 'conforme cada fatura',
        'dia_vencimento' => 'o da fatura',
        'modulos' => 'nenhum módulo adicional',
    );

    try {
        $st = $pdo->prepare("SELECT * FROM assinatura WHERE fk_empresa = :e AND situacao = 'ativa' ORDER BY id DESC LIMIT 1");
        $st->execute(array(':e' => $codigo));
        $a = $st->fetch(PDO::FETCH_ASSOC);
        if (is_array($a)) {
            $ciclo = max(1, (int) ($a['ciclo_meses'] ?? 1));
            $porCiclo = (int) ($a['valor_centavos'] ?? 0);
            $porMes = (int) round($porCiclo / $ciclo);
            $rotulo = (string) shield_plano_ciclo_rotulo($ciclo);
            $v['valor_mensal'] = 'R$ ' . shield_dinheiro($porMes);
            $v['ciclo'] = $rotulo;
            $v['valor_ciclo'] = 'R$ ' . shield_dinheiro($porCiclo);
            $v['dia_vencimento'] = (string) (int) ($a['dia_vencimento'] ?? 0);
            $v['plano'] = 'assinatura de R$ ' . shield_dinheiro($porMes) . ' por mês, cobrada ' . $rotulo
                . ($ciclo > 1 ? ' (R$ ' . shield_dinheiro($porCiclo) . ' por fatura)' : '')
                . ', com vencimento todo dia ' . (int) ($a['dia_vencimento'] ?? 0);
        }
    } catch (Throwable $semTabela) {
    }

    try {
        $st = $pdo->prepare(
            'SELECT m.nome, em.valor_centavos FROM empresa_modulo em JOIN modulo m ON m.id = em.fk_modulo
              WHERE em.fk_empresa = :e AND em.ate IS NULL ORDER BY m.nome'
        );
        $st->execute(array(':e' => $codigo));
        $mods = array();
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) ?: array() as $m) {
            $mods[] = trim((string) $m['nome']) . ' (R$ ' . shield_dinheiro((int) $m['valor_centavos']) . ' por mês)';
        }
        if ($mods !== array()) {
            $v['modulos'] = implode('; ', $mods);
        }
    } catch (Throwable $semTabela) {
    }

    return $v;
}

/**
 * Troca {{campo}} pelo valor. Campo desconhecido fica como esta, para o membro
 * ver na previa que escreveu errado, em vez de sumir calado.
 */
function shield_contrato_preencher(string $modelo, array $valores): string
{
    $texto = preg_replace_callback('/\{\{\s*([a-z_]+)\s*\}\}/', static function (array $m) use ($valores) {
        return array_key_exists($m[1], $valores) ? (string) $valores[$m[1]] : $m[0];
    }, str_replace(array("\r\n", "\r"), "\n", $modelo));

    return trim((string) $texto);
}

/** O hash que identifica o texto: o que vai impresso no PDF e no registro do aceite. */
function shield_contrato_hash(string $texto): string
{
    return hash('sha256', str_replace(array("\r\n", "\r"), "\n", $texto));
}

/** O ultimo aceite deste cliente, ou null. Base sem a tabela devolve null. */
function shield_contrato_ultimo_aceite(PDO $pdo, int $empresa): ?array
{
    try {
        $st = $pdo->prepare('SELECT * FROM contrato_aceite WHERE fk_empresa = :e ORDER BY aceito_em DESC, id DESC LIMIT 1');
        $st->execute(array(':e' => $empresa));
        $a = $st->fetch(PDO::FETCH_ASSOC);

        return is_array($a) ? $a : null;
    } catch (Throwable $semTabela) {
        return null;
    }
}

/**
 * Tudo o que as telas precisam saber do contrato deste cliente, numa conta so:
 * array('ativo', 'aplica', 'texto', 'hash', 'aceite', 'pendente').
 *
 * 'aplica' e o aceite ligado E o cliente com contrato iniciado (`fechado_em`):
 * o lead em avaliacao ainda nao tem contrato para aceitar.
 */
function shield_contrato_situacao(PDO $pdo, array $empresa): array
{
    $cfg = shield_contrato_config($pdo);
    $texto = shield_contrato_preencher($cfg['modelo'], shield_contrato_valores($pdo, $empresa));
    $hash = shield_contrato_hash($texto);
    $aceite = shield_contrato_ultimo_aceite($pdo, (int) ($empresa['codigo'] ?? 0));
    $aplica = $cfg['ativo'] && !empty($empresa['fechado_em']);

    return array(
        'ativo' => $cfg['ativo'],
        'aplica' => $aplica,
        'texto' => $texto,
        'hash' => $hash,
        'aceite' => $aceite,
        'pendente' => $aplica && ($aceite === null || (string) $aceite['hash'] !== $hash),
    );
}

/**
 * Registra o aceite. $hashLido e o hash do texto que a tela mostrou: se o texto
 * de agora for outro (o membro mexeu no modelo enquanto o cliente lia), o aceite
 * e recusado, porque o cliente concordaria com um texto que nao leu.
 *
 * Idempotente: o mesmo texto ja aceito devolve o aceite que existe (F5).
 */
function shield_contrato_aceitar(PDO $pdo, array $empresa, string $hashLido, string $email, string $ip, string $navegador): array
{
    $s = shield_contrato_situacao($pdo, $empresa);
    if (!$s['aplica']) {
        throw new RuntimeException('Não há contrato para aceitar agora.');
    }
    if (!hash_equals($s['hash'], trim($hashLido))) {
        throw new RuntimeException('O contrato foi atualizado enquanto você lia. Leia a versão nova abaixo e aceite de novo.');
    }
    if ($s['aceite'] !== null && (string) $s['aceite']['hash'] === $s['hash']) {
        return $s['aceite'];
    }

    $codigo = (int) $empresa['codigo'];
    $pdo->prepare(
        'INSERT INTO contrato_aceite (fk_empresa, hash, texto, aceito_em, ip, navegador, email)
         VALUES (:e, :h, :t, NOW(), :ip, :nav, :email)'
    )->execute(array(
        ':e' => $codigo, ':h' => $s['hash'], ':t' => $s['texto'],
        ':ip' => substr(trim($ip), 0, 45), ':nav' => substr(trim($navegador), 0, 255), ':email' => substr(trim($email), 0, 150),
    ));

    shield_auditar($pdo, 'contrato_aceito', array(
        'alvo_tipo' => 'empresa',
        'alvo_id' => $codigo,
        'depois' => array('hash' => $s['hash'], 'ip' => $ip, 'email' => $email),
        'detalhe' => 'contrato aceito na area do cliente',
    ));

    return (array) shield_contrato_ultimo_aceite($pdo, $codigo);
}

/**
 * O PDF de um texto de contrato. Com $aceite, o registro dele vai no fim; sem,
 * o arquivo sai marcado como MINUTA. O texto e o que se quer imprimir: o do
 * aceite (para o que foi aceito) ou o de agora (para a previa).
 *
 * Primeira linha nao vazia vira o titulo; linha que comeca com "# " vira
 * subtitulo de clausula; linha vazia e um respiro.
 */
function shield_contrato_pdf(string $texto, string $hash, ?array $aceite, array $empresa): string
{
    $doc = new \Shield\Pdf\Documento();
    $linhas = explode("\n", str_replace(array("\r\n", "\r"), "\n", trim($texto)));
    $tituloFeito = false;
    foreach ($linhas as $linha) {
        $linha = rtrim($linha);
        if (!$tituloFeito && trim($linha) !== '') {
            $doc->titulo(trim($linha));
            $tituloFeito = true;
            continue;
        }
        if (trim($linha) === '') {
            $doc->espaco(5.0);
        } elseif (strncmp(ltrim($linha), '# ', 2) === 0) {
            $doc->secao(trim(substr(ltrim($linha), 2)));
        } else {
            $doc->paragrafo($linha);
        }
    }

    $doc->espaco(14.0);
    if ($aceite !== null) {
        $quando = strtotime((string) $aceite['aceito_em']);
        $doc->paragrafo('Aceite eletrônico', true, 10.5);
        $doc->paragrafo('Aceito em ' . date('d/m/Y', $quando) . ' às ' . date('H:i', $quando)
            . ', na área do cliente, pelo acesso de ' . ((string) $aceite['email'] !== '' ? (string) $aceite['email'] : 'e-mail não informado')
            . ', a partir do endereço IP ' . ((string) $aceite['ip'] !== '' ? (string) $aceite['ip'] : 'não registrado') . '.', false, 9.0);
        if ((string) ($aceite['navegador'] ?? '') !== '') {
            $doc->paragrafo('Navegador: ' . (string) $aceite['navegador'], false, 8.0);
        }
    } else {
        $doc->paragrafo('MINUTA: este contrato ainda não foi aceito pelo cliente.', true, 10.5);
    }
    $doc->paragrafo('Código de conferência do texto (SHA-256): ' . $hash, false, 8.0);

    $doc->rodape(trim((string) ($empresa['razao'] ?? '')) . ' · CNPJ ' . shield_cnpj((string) ($empresa['cnpj'] ?? ''))
        . ' · conferência ' . substr($hash, 0, 12));

    return $doc->gerar();
}

/** O nome do arquivo: o CNPJ em digitos, e a marca de minuta quando nao ha aceite. */
function shield_contrato_nome_arquivo(array $empresa, bool $aceito): string
{
    return 'contrato_' . preg_replace('/\D+/', '', (string) ($empresa['cnpj'] ?? '')) . ($aceito ? '' : '_minuta') . '.pdf';
}

/** Manda o PDF e encerra. Buffer limpo antes: aviso do PHP no corpo estragaria o arquivo. */
function shield_contrato_enviar_pdf(string $pdf, string $nome): void
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if (function_exists('shield_csrf_sem_filtro')) {
        shield_csrf_sem_filtro();
    }
    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="' . preg_replace('/[^A-Za-z0-9_.-]/', '', $nome) . '"');
    header('Content-Length: ' . strlen($pdf));
    header('X-Content-Type-Options: nosniff');
    echo $pdf;
    exit;
}
