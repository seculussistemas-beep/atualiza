<?php

require_once __DIR__ . '/../nucleo/system_bootstrap.php';

function shield_a1_upload_dir()
{
    return shield_root_path() . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'certificados';
}

function shield_a1_upload_dir_relative()
{
    return 'uploads/certificados';
}

function shield_a1_max_upload_size()
{
    return 5 * 1024 * 1024;
}

function shield_a1_ensure_storage_paths()
{
    $dir = shield_a1_upload_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
        throw new RuntimeException('Nao foi possivel criar o diretorio de certificados.');
    }

    $indexPath = $dir . DIRECTORY_SEPARATOR . 'index.html';
    if (!is_file($indexPath)) {
        @file_put_contents($indexPath, '');
    }

    $htaccessPath = $dir . DIRECTORY_SEPARATOR . '.htaccess';
    if (!is_file($htaccessPath)) {
        $rules = "Options -Indexes\n<FilesMatch \".*\">\nRequire all denied\n</FilesMatch>\n";
        @file_put_contents($htaccessPath, $rules);
    }
}

function shield_a1_is_valid_upload_extension($filename)
{
    $extension = strtolower((string) pathinfo((string) $filename, PATHINFO_EXTENSION));
    return in_array($extension, ['pfx', 'p12'], true);
}

function shield_a1_store_uploaded_file(array $upload)
{
    if (!isset($upload['error']) || (int) $upload['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Falha no upload do certificado A1.');
    }

    if (empty($upload['name']) || !shield_a1_is_valid_upload_extension((string) $upload['name'])) {
        throw new RuntimeException('Formato invalido. Envie um arquivo .pfx ou .p12.');
    }

    if (!isset($upload['size']) || (int) $upload['size'] <= 0) {
        throw new RuntimeException('Arquivo de certificado vazio.');
    }

    if ((int) $upload['size'] > shield_a1_max_upload_size()) {
        throw new RuntimeException('O certificado excede o limite de 5MB.');
    }

    if (empty($upload['tmp_name']) || !is_uploaded_file((string) $upload['tmp_name'])) {
        throw new RuntimeException('Upload invalido do certificado.');
    }

    shield_a1_ensure_storage_paths();

    $extension = strtolower((string) pathinfo((string) $upload['name'], PATHINFO_EXTENSION));
    $storedName = bin2hex(random_bytes(24)) . '.' . $extension;
    $destination = shield_a1_upload_dir() . DIRECTORY_SEPARATOR . $storedName;

    if (!@move_uploaded_file((string) $upload['tmp_name'], $destination)) {
        throw new RuntimeException('Nao foi possivel salvar o arquivo do certificado.');
    }

    return shield_a1_upload_dir_relative() . '/' . $storedName;
}

function shield_a1_resolve_file_path($relativePath)
{
    $relativePath = str_replace('\\', '/', (string) $relativePath);
    $relativePath = ltrim($relativePath, '/');
    return shield_root_path() . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativePath);
}

function shield_a1_remove_file($relativePath)
{
    if (!$relativePath) {
        return;
    }

    $fullPath = shield_a1_resolve_file_path($relativePath);
    $root = realpath(shield_a1_upload_dir());
    $target = is_file($fullPath) ? realpath($fullPath) : false;
    if ($root !== false && $target !== false && str_starts_with($target, $root . DIRECTORY_SEPARATOR)) {
        @unlink($target);
    }
}

function shield_a1_read_uploaded_binary(array $upload)
{
    if (empty($upload['tmp_name']) || !is_uploaded_file((string) $upload['tmp_name'])) {
        throw new RuntimeException('Arquivo temporario do certificado nao encontrado.');
    }

    $binary = @file_get_contents((string) $upload['tmp_name']);
    if ($binary === false || $binary === '') {
        throw new RuntimeException('Nao foi possivel ler o arquivo do certificado A1.');
    }

    return $binary;
}

function shield_a1_subject_to_string(array $subject)
{
    $orderedKeys = ['CN', 'O', 'OU', 'C', 'ST', 'L', 'emailAddress'];
    $parts = [];

    foreach ($orderedKeys as $key) {
        if (!isset($subject[$key])) {
            continue;
        }

        $value = $subject[$key];
        if (is_array($value)) {
            $value = implode(', ', $value);
        }
        $value = trim((string) $value);
        if ($value !== '') {
            $parts[] = $key . '=' . $value;
        }
    }

    if (!empty($parts)) {
        return implode(', ', $parts);
    }

    foreach ($subject as $key => $value) {
        if (is_array($value)) {
            $value = implode(', ', $value);
        }
        $value = trim((string) $value);
        if ($value !== '') {
            $parts[] = (string) $key . '=' . $value;
        }
    }

    return implode(', ', $parts);
}

function shield_a1_display_subject(array $subject)
{
    foreach (['CN', 'O', 'OU'] as $key) {
        if (!isset($subject[$key])) {
            continue;
        }
        $value = $subject[$key];
        if (is_array($value)) {
            $value = reset($value);
        }
        $value = trim((string) $value);
        if ($value !== '') {
            return $value;
        }
    }

    return shield_a1_subject_to_string($subject);
}

function shield_a1_fingerprint_sha256($certificatePem)
{
    $fingerprint = @openssl_x509_fingerprint((string) $certificatePem, 'sha256');
    if ($fingerprint !== false && $fingerprint !== '') {
        return strtoupper((string) $fingerprint);
    }

    $clean = str_replace(
        ["-----BEGIN CERTIFICATE-----", "-----END CERTIFICATE-----", "\r", "\n"],
        '',
        (string) $certificatePem
    );
    $der = base64_decode($clean, true);
    if ($der === false) {
        return '';
    }

    return strtoupper(hash('sha256', $der));
}

function shield_a1_parse_pkcs12($binaryContent, $password)
{
    if (!is_string($password) || $password === '') {
        throw new RuntimeException('Informe a senha do certificado A1.');
    }

    $certs = [];
    $readOk = @openssl_pkcs12_read((string) $binaryContent, $certs, $password);
    if (!$readOk || empty($certs['cert']) || empty($certs['pkey'])) {
        throw new RuntimeException('Certificado A1 invalido ou senha incorreta.');
    }

    $parsed = @openssl_x509_parse((string) $certs['cert']);
    if ($parsed === false) {
        throw new RuntimeException('Nao foi possivel interpretar o certificado A1.');
    }

    $validFromTs = isset($parsed['validFrom_time_t']) ? (int) $parsed['validFrom_time_t'] : null;
    $validToTs = isset($parsed['validTo_time_t']) ? (int) $parsed['validTo_time_t'] : null;
    if (empty($validToTs)) {
        throw new RuntimeException('Validade do certificado nao identificada.');
    }

    $subject = isset($parsed['subject']) && is_array($parsed['subject']) ? $parsed['subject'] : [];
    $serial = '';
    if (!empty($parsed['serialNumberHex'])) {
        $serial = strtoupper((string) $parsed['serialNumberHex']);
    } elseif (!empty($parsed['serialNumber'])) {
        $serial = strtoupper((string) $parsed['serialNumber']);
    }

    return [
        'certificate_pem' => (string) $certs['cert'],
        'private_key_pem' => (string) $certs['pkey'],
        'subject_display' => shield_a1_display_subject($subject),
        'subject_full' => shield_a1_subject_to_string($subject),
        'serial' => $serial,
        'thumbprint' => shield_a1_fingerprint_sha256((string) $certs['cert']),
        'valid_from_ts' => $validFromTs,
        'valid_to_ts' => $validToTs,
        'valid_from_db' => $validFromTs ? date('Y-m-d H:i:s', $validFromTs) : null,
        'valid_to_db' => date('Y-m-d H:i:s', $validToTs),
    ];
}

function shield_encrypt_secret($plainText)
{
    $plainText = (string) $plainText;
    if ($plainText === '') {
        return '';
    }

    $key = shield_ensure_crypto_key();
    $iv = random_bytes(16);
    $cipher = @openssl_encrypt($plainText, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    if ($cipher === false) {
        throw new RuntimeException('Falha ao criptografar segredo.');
    }

    $mac = hash_hmac('sha256', $iv . $cipher, $key, true);
    return base64_encode($iv . $mac . $cipher);
}

function shield_decrypt_secret($cipherText)
{
    $cipherText = (string) $cipherText;
    if ($cipherText === '') {
        return '';
    }

    $decoded = base64_decode($cipherText, true);
    if ($decoded === false || strlen($decoded) < 49) {
        throw new RuntimeException('Segredo criptografado invalido.');
    }

    $iv = substr($decoded, 0, 16);
    $mac = substr($decoded, 16, 32);
    $cipher = substr($decoded, 48);
    $key = shield_ensure_crypto_key();

    $calcMac = hash_hmac('sha256', $iv . $cipher, $key, true);
    if (!hash_equals($mac, $calcMac)) {
        throw new RuntimeException('Falha de integridade no segredo criptografado.');
    }

    $plain = @openssl_decrypt($cipher, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    if ($plain === false) {
        throw new RuntimeException('Falha ao descriptografar segredo.');
    }

    return (string) $plain;
}

function shield_a1_status($validToDb)
{
    if (empty($validToDb)) {
        return ['label' => 'Nao configurado', 'class' => 'secondary', 'days' => null];
    }

    $validToTs = strtotime((string) $validToDb);
    if ($validToTs === false) {
        return ['label' => 'Data invalida', 'class' => 'warning', 'days' => null];
    }

    $days = (int) floor(($validToTs - time()) / 86400);
    if ($days < 0) {
        return ['label' => 'Vencido', 'class' => 'danger', 'days' => $days];
    }
    if ($days <= 30) {
        return ['label' => 'Expira em breve', 'class' => 'warning', 'days' => $days];
    }

    return ['label' => 'Valido', 'class' => 'success', 'days' => $days];
}

function shield_a1_assert_not_expired($validToDb)
{
    $status = shield_a1_status($validToDb);
    if ($status['label'] === 'Vencido') {
        throw new RuntimeException('Certificado A1 vencido.');
    }
}

function shield_a1_runtime_result($ok, $code, $message, array $certData = [])
{
    return [
        'ok' => (bool) $ok,
        'code' => (string) $code,
        'message' => (string) $message,
        'cert_data' => $certData,
    ];
}

function shield_a1_runtime_validation(array $softhouse)
{
    $relativePath = trim((string) ($softhouse['certificado_a1_arquivo'] ?? ''));
    $encryptedPassword = trim((string) ($softhouse['certificado_a1_senha_enc'] ?? ''));

    if ($relativePath === '' && $encryptedPassword === '') {
        return shield_a1_runtime_result(
            false,
            'cert_required',
            'Certificado A1 e senha ainda nao foram configurados.'
        );
    }

    if ($relativePath === '') {
        return shield_a1_runtime_result(
            false,
            'cert_file_missing',
            'Arquivo do certificado A1 nao cadastrado.'
        );
    }

    if ($encryptedPassword === '') {
        return shield_a1_runtime_result(
            false,
            'cert_secret_missing',
            'Senha criptografada do certificado A1 nao cadastrada.'
        );
    }

    $fullPath = shield_a1_resolve_file_path($relativePath);
    if (!is_file($fullPath)) {
        return shield_a1_runtime_result(
            false,
            'cert_file_missing',
            'Arquivo do certificado A1 nao encontrado no servidor.'
        );
    }

    $binary = @file_get_contents($fullPath);
    if ($binary === false || $binary === '') {
        return shield_a1_runtime_result(
            false,
            'cert_file_missing',
            'Nao foi possivel ler o arquivo do certificado A1.'
        );
    }

    try {
        $password = shield_decrypt_secret($encryptedPassword);
    } catch (Throwable $exception) {
        $message = strtolower(trim((string) $exception->getMessage()));
        if (str_contains($message, 'integridade') || str_contains($message, 'criptografado invalido')) {
            return shield_a1_runtime_result(
                false,
                'cert_crypto_mismatch',
                'Falha ao descriptografar a senha do certificado. Reenvie o A1 para criptografar com a chave atual.'
            );
        }

        return shield_a1_runtime_result(
            false,
            'cert_invalid',
            'Nao foi possivel validar a senha criptografada do certificado A1.'
        );
    }

    try {
        $parsed = shield_a1_parse_pkcs12($binary, $password);
    } catch (Throwable $exception) {
        $message = strtolower(trim((string) $exception->getMessage()));

        if (str_contains($message, 'senha incorreta') || str_contains($message, 'invalido')) {
            return shield_a1_runtime_result(
                false,
                'cert_password_invalid',
                'Arquivo PFX/P12 invalido ou senha incompativel.'
            );
        }

        return shield_a1_runtime_result(
            false,
            'cert_parse_error',
            'Nao foi possivel interpretar o certificado A1.'
        );
    }

    try {
        shield_a1_assert_not_expired($parsed['valid_to_db'] ?? null);
    } catch (Throwable $exception) {
        return shield_a1_runtime_result(
            false,
            'cert_expired',
            'Certificado A1 vencido.'
        );
    }

    $parsed['relative_path'] = $relativePath;
    $parsed['full_path'] = $fullPath;

    return shield_a1_runtime_result(
        true,
        'cert_ok',
        'Certificado pronto para assinar contratos.',
        $parsed
    );
}

function shield_format_datetime_br($datetime)
{
    if (empty($datetime)) {
        return 'N/D';
    }

    $timestamp = strtotime((string) $datetime);
    if ($timestamp === false) {
        return 'N/D';
    }

    return date('d/m/Y H:i', $timestamp);
}
