<?php

/**
 * Limite de tentativas de login -- 04/09/2026.
 *
 * MED-5 de docs/auditoria-seguranca.md. A tela de login nao contava tentativa,
 * nao atrasava e nao bloqueava -- e, pior, nao deixava rastro de que alguem
 * tinha tentado.
 *
 * DUAS CONTAGENS SEPARADAS, e nao uma:
 *
 *   por LOGIN digitado -- pega quem martela uma conta so;
 *   por IP             -- pega quem varre uma lista de e-mails, caso em que
 *                         nenhum login sozinho chega perto do limite.
 *
 * O teto do IP e mais folgado porque uma loja inteira pode sair por um NAT so:
 * apertar ali tranca o time do cliente junto com o atacante.
 *
 * NUNCA BLOQUEIA PARA SEMPRE. O bloqueio e uma janela que anda: passados
 * SHIELD_LOGIN_JANELA_MIN minutos sem tentativa nova, a conta volta sozinha.
 * Bloqueio permanente por login errado transforma a protecao em arma -- basta
 * o atacante errar a senha do administrador de proposito para tira-lo do ar, e
 * ai o ataque nao precisa nem acertar.
 *
 * FALHA ABERTO, e isto e deliberado. Se a tabela nao existe -- membro que
 * recebeu o codigo novo e ainda nao rodou o /update -- ou o banco engasga,
 * estas funcoes deixam passar. A alternativa seria trancar todo mundo para fora
 * do painel por causa de uma migracao pendente, o que e um estrago maior do que
 * o que se esta evitando. A senha continua sendo conferida por bcrypt de
 * qualquer jeito; o que se perde e o teto, nao a autenticacao.
 */

/** Quanto tempo a janela olha para tras. */
const SHIELD_LOGIN_JANELA_MIN = 15;

/** Falhas no mesmo login digitado antes de travar. */
const SHIELD_LOGIN_MAX_POR_LOGIN = 5;

/** Falhas vindas do mesmo IP antes de travar. Folgado: pode ser um NAT. */
const SHIELD_LOGIN_MAX_POR_IP = 20;

function shield_login_ip(): string
{
    return substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
}

/**
 * Normaliza o que foi digitado para servir de chave.
 *
 * Minusculas para "Admin@X" e "admin@x" contarem juntos -- senao alternar a
 * caixa dobra o teto de graca.
 */
function shield_login_chave(string $digitado): string
{
    return substr(mb_strtolower(trim($digitado)), 0, 190);
}

/**
 * Quantas falhas caíram na janela para esta chave.
 * Devolve 0 quando nao da para saber (ver "falha aberto" no topo).
 */
function shield_login_falhas(PDO $pdo, string $tipo, string $chave, ?int $janelaMin = null): int
{
    if ($chave === '') {
        return 0;
    }

    try {
        // A janela entra no SQL como numero literal, e nao como parametro:
        // INTERVAL nao aceita placeholder em prepare NATIVO -- so funcionaria
        // com a emulacao do PDO ligada, que e o padrao hoje mas e configuracao
        // e nao garantia. E constante do codigo, nunca entrada de usuario.
        // A janela e a do painel por padrao; a area do cliente passa a dela
        // (5 minutos, 10/09/2026): la a senha e da loja, nao do operador.
        $janela = max(1, (int) ($janelaMin ?? SHIELD_LOGIN_JANELA_MIN));

        $stmt = $pdo->prepare(
            'SELECT COUNT(*) FROM login_tentativa
              WHERE tipo = :tipo AND chave = :chave
                AND criado_em > (NOW() - INTERVAL ' . $janela . ' MINUTE)'
        );
        $stmt->bindValue(':tipo', $tipo);
        $stmt->bindValue(':chave', $chave);
        $stmt->execute();

        return (int) $stmt->fetchColumn();
    } catch (Throwable $semTabela) {
        return 0;
    }
}

/**
 * Este pedido de login pode seguir para a conferencia de senha?
 *
 * Devolve null quando pode; quando nao pode, devolve a mensagem pronta para a
 * tela -- ja com quantos minutos faltam, porque "tente mais tarde" sem numero
 * so gera chamado no suporte.
 */
function shield_login_bloqueado(PDO $pdo, string $digitado, ?int $janelaMin = null, ?int $maxPorLogin = null): ?string
{
    $janela = max(1, (int) ($janelaMin ?? SHIELD_LOGIN_JANELA_MIN));
    $max = max(1, (int) ($maxPorLogin ?? SHIELD_LOGIN_MAX_POR_LOGIN));
    $porLogin = shield_login_falhas($pdo, 'login', shield_login_chave($digitado), $janela);
    $porIp = shield_login_falhas($pdo, 'ip', shield_login_ip(), $janela);

    if ($porLogin < $max && $porIp < SHIELD_LOGIN_MAX_POR_IP) {
        return null;
    }

    return sprintf(
        'Tentativas demais. Espere %d minutos e tente de novo.',
        $janela
    );
}

/**
 * Registra a falha -- duas linhas, uma por contagem.
 *
 * Grava tambem na auditoria, quando ela existe: ate hoje nao havia NENHUM
 * rastro de tentativa de entrada malsucedida, entao um ataque em curso era
 * invisivel mesmo para quem fosse procurar.
 */
function shield_login_registrar_falha(PDO $pdo, string $digitado): void
{
    $ip = shield_login_ip();
    $agente = substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 160);

    try {
        $stmt = $pdo->prepare(
            'INSERT INTO login_tentativa (tipo, chave, ip, agente) VALUES (:tipo, :chave, :ip, :agente)'
        );
        foreach ([['login', shield_login_chave($digitado)], ['ip', $ip]] as [$tipo, $chave]) {
            if ($chave === '') {
                continue;
            }
            $stmt->execute([':tipo' => $tipo, ':chave' => $chave, ':ip' => $ip, ':agente' => $agente]);
        }
    } catch (Throwable $semTabela) {
        // Ver "falha aberto" no topo.
    }

    try {
        require_once dirname(__DIR__) . '/cobranca/cobranca.php';
        if (function_exists('shield_auditar')) {
            shield_auditar($pdo, 'login_falhou', array(
                'alvo_tipo' => 'usuario',
                // O que foi DIGITADO, nao um usuario -- na maioria das vezes
                // ele nem existe, e e isso que interessa saber.
                'detalhe' => substr(shield_login_chave($digitado) . ' de ' . $ip, 0, 190),
            ));
        }
    } catch (Throwable $ignorado) {
        // Auditoria nunca decide se alguem entra ou nao.
    }
}

/**
 * Entrou: limpa o que havia contra este login e contra este IP.
 *
 * Sem isto, quem errou quatro vezes e acertou na quinta continuaria a um passo
 * do bloqueio pelo resto da janela.
 */
function shield_login_limpar(PDO $pdo, string $digitado): void
{
    try {
        $stmt = $pdo->prepare('DELETE FROM login_tentativa WHERE (tipo = :t1 AND chave = :c1) OR (tipo = :t2 AND chave = :c2)');
        $stmt->execute([
            ':t1' => 'login', ':c1' => shield_login_chave($digitado),
            ':t2' => 'ip', ':c2' => shield_login_ip(),
        ]);
    } catch (Throwable $semTabela) {
        // Ver "falha aberto" no topo.
    }
}

/**
 * Faxina do que envelheceu. Oportunista: roda junto com a entrada bem-sucedida,
 * que e rara o bastante para nao pesar e frequente o bastante para a tabela nao
 * crescer sem limite.
 */
function shield_login_faxina(PDO $pdo): void
{
    try {
        $pdo->exec('DELETE FROM login_tentativa WHERE criado_em < (NOW() - INTERVAL 1 DAY)');
    } catch (Throwable $semTabela) {
        // Ver "falha aberto" no topo.
    }
}

/**
 * Registra UMA contagem qualquer na mesma tabela, com tipo proprio.
 *
 * Existe porque shield_login_falhas() ja e generica na leitura e nao havia a
 * metade da escrita: shield_login_registrar_falha() grava sempre o par
 * login+ip do formulario de entrada. Quem precisa contar outra coisa -- a
 * recuperacao de senha conta pedidos por IP, com tipo 'senha_ip' -- usava a
 * leitura e nao tinha como alimentar.
 *
 * Falha aberto, como o resto do arquivo: sem tabela, nao conta e nao atrapalha.
 * Chave vazia nao vira linha -- em CLI e cron nao ha REMOTE_ADDR, e contar o
 * "IP vazio" juntaria todo mundo numa chave so.
 */
function shield_login_registrar(PDO $pdo, string $tipo, string $chave): void
{
    if ($chave === '') {
        return;
    }

    try {
        $pdo->prepare(
            'INSERT INTO login_tentativa (tipo, chave, ip, agente) VALUES (:tipo, :chave, :ip, :agente)'
        )->execute([
            ':tipo' => substr($tipo, 0, 10),
            ':chave' => substr($chave, 0, 190),
            ':ip' => shield_login_ip(),
            ':agente' => substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 160),
        ]);
    } catch (Throwable $semTabela) {
        // Ver "falha aberto" no topo.
    }
}
