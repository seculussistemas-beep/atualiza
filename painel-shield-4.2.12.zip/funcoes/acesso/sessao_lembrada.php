<?php

// "Manter conectado" -- 03/09/2026.
//
// A sessao do PHP dura 8 horas (session.gc_maxlifetime). Quem marcou a caixa
// no login ganha um cookie de 30 dias; quando a sessao some, o cookie recria
// ela sozinho, sem tela de login.
//
// O COOKIE E "seletor:validador". O seletor acha a linha em sessao_lembrada; o
// validador e comparado com hash_equals contra o SHA-256 guardado. A cada uso o
// validador e trocado: cookie copiado de um navegador deixa de valer no outro
// na primeira vez que qualquer um dos dois abrir o painel.
//
// AS FUNCOES NAO MEXEM EM COOKIE NEM EM SESSAO: recebem e devolvem strings.
// setcookie() e $_SESSION ficam com quem chama (login, verificar_sesao,
// logout). E o que deixa isto testavel na linha de comando.

const SHIELD_LEMBRAR_COOKIE = 'shield_lembrar';
const SHIELD_LEMBRAR_DIAS = 30;

/**
 * Cria a linha e devolve o valor do cookie. NULL se o usuario nao existir.
 */
function shield_lembrar_criar(PDO $pdo, $usuarioId, $ip = '', $agente = '')
{
    $seletor = bin2hex(random_bytes(12));
    $validador = bin2hex(random_bytes(32));

    $stmt = $pdo->prepare(
        'INSERT INTO sessao_lembrada (fk_usuario, seletor, validador_hash, expira_em, ip, agente)
         VALUES (:u, :s, :h, DATE_ADD(NOW(), INTERVAL ' . (int) SHIELD_LEMBRAR_DIAS . ' DAY), :ip, :ag)'
    );
    $stmt->execute(array(
        ':u' => (int) $usuarioId,
        ':s' => $seletor,
        ':h' => hash('sha256', $validador),
        ':ip' => substr((string) $ip, 0, 45) ?: null,
        ':ag' => substr((string) $agente, 0, 160) ?: null,
    ));

    return $seletor . ':' . $validador;
}

/**
 * Confere o cookie. Devolve ['usuario' => linha de usuario, 'cookie' => valor
 * novo para regravar] ou NULL quando nao vale. Cookie que nao bate com o hash
 * e apagado na hora: ou foi adulterado, ou foi usado de outro lugar.
 */
function shield_lembrar_restaurar(PDO $pdo, $cookie)
{
    $cookie = (string) $cookie;
    if (!preg_match('/^([a-f0-9]{24}):([a-f0-9]{64})$/', $cookie, $m)) {
        return null;
    }
    list(, $seletor, $validador) = $m;

    $stmt = $pdo->prepare(
        'SELECT id, fk_usuario, validador_hash FROM sessao_lembrada
          WHERE seletor = :s AND expira_em > NOW() LIMIT 1'
    );
    $stmt->execute(array(':s' => $seletor));
    $linha = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!is_array($linha)) {
        return null;
    }

    if (!hash_equals((string) $linha['validador_hash'], hash('sha256', $validador))) {
        $pdo->prepare('DELETE FROM sessao_lembrada WHERE id = :id')->execute(array(':id' => (int) $linha['id']));
        return null;
    }

    $stmt = $pdo->prepare('SELECT * FROM usuario WHERE id = :u LIMIT 1');
    $stmt->execute(array(':u' => (int) $linha['fk_usuario']));
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!is_array($usuario)) {
        $pdo->prepare('DELETE FROM sessao_lembrada WHERE id = :id')->execute(array(':id' => (int) $linha['id']));
        return null;
    }

    // Gira o validador. O seletor fica: e ele que identifica este navegador.
    $novoValidador = bin2hex(random_bytes(32));
    $pdo->prepare(
        'UPDATE sessao_lembrada SET validador_hash = :h, ultimo_uso = NOW() WHERE id = :id'
    )->execute(array(':h' => hash('sha256', $novoValidador), ':id' => (int) $linha['id']));

    return array('usuario' => $usuario, 'cookie' => $seletor . ':' . $novoValidador);
}

/** Apaga a linha deste cookie (sair). Cookie invalido: nao faz nada. */
function shield_lembrar_esquecer(PDO $pdo, $cookie)
{
    if (!preg_match('/^([a-f0-9]{24}):/', (string) $cookie, $m)) {
        return;
    }
    $pdo->prepare('DELETE FROM sessao_lembrada WHERE seletor = :s')->execute(array(':s' => $m[1]));
}

/** Os atributos do cookie, iguais aos da sessao: HttpOnly, SameSite=Lax, Secure quando em HTTPS. */
function shield_lembrar_opcoes_cookie($expiraEm)
{
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';

    return array(
        'expires' => (int) $expiraEm,
        'path' => '/',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    );
}

/** Grava o cookie no navegador. Separado para as funcoes acima nao tocarem em header. */
function shield_lembrar_gravar_cookie($valor)
{
    setcookie(SHIELD_LEMBRAR_COOKIE, (string) $valor,
        shield_lembrar_opcoes_cookie(time() + SHIELD_LEMBRAR_DIAS * 86400));
}

function shield_lembrar_apagar_cookie()
{
    setcookie(SHIELD_LEMBRAR_COOKIE, '', shield_lembrar_opcoes_cookie(time() - 86400));
}
