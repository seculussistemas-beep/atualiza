<?php

// Recuperacao de senha -- 03/09/2026.
//
// O fluxo classico, sem invencao: a pessoa informa o e-mail, recebe um link
// que vale por uma hora, abre o link e escolhe a senha nova.
//
// A TELA NUNCA DIZ SE O E-MAIL EXISTE. "Se houver conta com esse e-mail, o
// link foi enviado" e a resposta tanto para quem existe quanto para quem nao
// existe. Do contrario o formulario vira uma lista de quem tem acesso ao
// painel, para quem quiser testar endereco por endereco.
//
// O ENVIO SAI NA HORA, e nao pela fila de includes/email.php. A fila e
// oportunista: roda quando alguem abre o painel ou quando o cron chama. Quem
// esqueceu a senha esta do lado de fora, esperando o e-mail -- nao ha quem
// puxe a fila por ele. Os vinte segundos de SMTP lento sao dele mesmo.

require_once __DIR__ . '/../notificacao/email.php';
require_once __DIR__ . '/../nucleo/env.php';
require_once __DIR__ . '/senha_forca.php';
require_once __DIR__ . '/limite_login.php';

const SHIELD_SENHA_TOKEN_MINUTOS = 60;
const SHIELD_SENHA_PEDIDOS_POR_HORA = 3;

// Teto por ORIGEM, na janela de SHIELD_LOGIN_JANELA_MIN.
//
// O teto de tres por hora e por CONTA, e nem chega a ser consultado quando o
// usuario nao existe -- o retorno de 'sem_usuario' vem antes dele. Ou seja:
// quem varria uma lista de e-mails para descobrir quem tem acesso ao painel
// nao encontrava limite nenhum. Este e o teto que pega a varredura.
//
// Folgado pelo mesmo motivo do teto de IP do login: uma loja inteira pode sair
// por um NAT so, e apertar aqui tranca o time do cliente junto com o atacante.
const SHIELD_SENHA_PEDIDOS_POR_IP = 10;
const SHIELD_SENHA_MINIMO = 8;

/**
 * De onde o link do e-mail aponta. SO o endereco que a instalacao declarou em
 * SHIELD_APP_URL. Nao havendo um, devolve vazio -- e quem chamou recusa o
 * pedido.
 *
 * NAO CAIA NA TENTACAO DE COMPLETAR COM $_SERVER['HTTP_HOST']. Foi assim ate
 * 08/09/2026, e era uma tomada de conta: o Host vem do cliente, o Apache do
 * projeto atende qualquer Host (um <VirtualHost *:80> so), e este link carrega
 * um token que TROCA A SENHA. O atacante pedia a redefinicao para o e-mail da
 * vitima mandando `Host: evil.tld`; o painel enviava um e-mail legitimo, com a
 * marca do membro, apontando para https://evil.tld/redefinir_senha.php?token=
 * <token valido por uma hora>. A vitima clicava, o token chegava no servidor
 * do atacante, e ele redefinia a senha no painel de verdade -- inclusive a de
 * administrador. X-Forwarded-Proto tem o mesmo defeito e some junto: com o
 * endereco declarado, o esquema ja esta escrito nele.
 *
 * Falhar fechado custa um aviso na tela do administrador. Falhar aberto custa
 * a conta.
 */
function shield_senha_url_base()
{
    $env = trim(shield_env('SHIELD_APP_URL', ''));

    return $env === '' ? '' : rtrim($env, '/');
}

/**
 * Pede o link. Devolve ['enviado' => bool, 'motivo' => string] para o LOG e
 * para os testes -- a tela mostra a mesma frase neutra em quase todos os
 * casos. A excecao e 'sem_smtp': isso e configuracao do painel, nao segredo
 * de usuario, e o administrador precisa saber que o e-mail nao vai sair.
 *
 * $enviar e o canal (para o teste nao precisar de servidor). Quando vem, quem
 * chamou responde pela entrega, e a checagem de SMTP configurado nao se aplica.
 */
/**
 * O que a TELA pode decidir sem saber se o usuario existe -- 08/09/2026.
 *
 * Esta funcao existe para tirar a enumeracao do caminho da resposta. A
 * mensagem ja era uniforme desde 03/09; o RELOGIO nao era. Conta inexistente
 * voltava depois de um SELECT indexado, em milissegundos; conta existente so
 * voltava depois do SMTP sincrono inteiro -- src/Email/Smtp.php fixa
 * TEMPO = 20. Bastava cronometrar para separar quem tem acesso ao painel de
 * quem nao tem, sem acertar senha nenhuma e sem ler mensagem diferente.
 *
 * O que ela responde depende so de CONFIGURACAO DO PAINEL, nunca do usuario:
 * vazio, sem_url_base, sem_smtp ou ok. Com isso a tela inteira e montada e
 * enviada antes de o painel sequer procurar a conta, e o resto -- procurar,
 * gravar token, mandar e-mail -- roda depois da resposta fechada, onde o
 * relogio do atacante nao alcanca.
 *
 * O teto por IP NAO entra aqui de proposito: ele grava, e gravar duas vezes
 * faria cada pedido contar em dobro. Ele continua dentro de
 * shield_senha_pedir(), que roda depois.
 *
 * @return string 'ok' quando pode seguir; o motivo quando nao
 */
function shield_senha_pre_checagem(PDO $pdo, $identificacao, $urlBase, ?callable $enviar = null)
{
    if (trim((string) $identificacao) === '') {
        return 'vazio';
    }

    if (trim((string) $urlBase) === '') {
        return 'sem_url_base';
    }

    if ($enviar === null && !shield_email_configurado($pdo)) {
        return 'sem_smtp';
    }

    return 'ok';
}

function shield_senha_pedir(PDO $pdo, $identificacao, $urlBase, ?callable $enviar = null)
{
    $identificacao = trim((string) $identificacao);
    if ($identificacao === '') {
        return array('enviado' => false, 'motivo' => 'vazio');
    }

    // ANTES de qualquer coisa no banco. Sem endereco declarado nao ha link, e
    // recusar depois de gravar deixaria um token vivo por uma hora, contando
    // no teto de tres por hora, sem ninguem ter recebido nada -- um jeito
    // silencioso de trancar a recuperacao de quem foi alvo.
    if (trim((string) $urlBase) === '') {
        return array('enviado' => false, 'motivo' => 'sem_url_base');
    }

    // ANTES de procurar o usuario, e nao depois: e justamente o pedido por
    // conta que NAO existe que precisa contar, senao a varredura passa livre.
    // Pedido barrado nao vira linha nova -- contar o bloqueio tambem faria a
    // janela andar sozinha e o IP nunca sair do castigo.
    $ip = shield_login_ip();
    if ($ip !== '' && shield_login_falhas($pdo, 'senha_ip', $ip) >= SHIELD_SENHA_PEDIDOS_POR_IP) {
        return array('enviado' => false, 'motivo' => 'limite_ip');
    }
    shield_login_registrar($pdo, 'senha_ip', $ip);

    if ($enviar === null && !shield_email_configurado($pdo)) {
        return array('enviado' => false, 'motivo' => 'sem_smtp');
    }

    // Dois nomes para o mesmo valor: o PDO nao aceita o mesmo placeholder repetido.
    $stmt = $pdo->prepare(
        'SELECT id, nome, login, email FROM usuario WHERE email = :e OR login = :l LIMIT 1'
    );
    $stmt->execute(array(':e' => $identificacao, ':l' => $identificacao));
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!is_array($usuario)) {
        return array('enviado' => false, 'motivo' => 'sem_usuario');
    }

    $para = trim((string) $usuario['email']);
    if ($para === '' || !filter_var($para, FILTER_VALIDATE_EMAIL)) {
        return array('enviado' => false, 'motivo' => 'sem_email');
    }

    // Tres pedidos por hora por conta. Nao e contra o dono da conta -- e
    // contra quem quiser encher a caixa dele de links a partir daqui.
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) FROM senha_recuperacao
          WHERE fk_usuario = :u AND criado_em > DATE_SUB(NOW(), INTERVAL 1 HOUR)'
    );
    $stmt->execute(array(':u' => (int) $usuario['id']));
    if ((int) $stmt->fetchColumn() >= SHIELD_SENHA_PEDIDOS_POR_HORA) {
        return array('enviado' => false, 'motivo' => 'limite');
    }

    // Um link vivo por vez: pedir de novo mata o anterior.
    $pdo->prepare('UPDATE senha_recuperacao SET usado_em = NOW()
                    WHERE fk_usuario = :u AND usado_em IS NULL')
        ->execute(array(':u' => (int) $usuario['id']));

    $token = bin2hex(random_bytes(32));

    $pdo->prepare(
        'INSERT INTO senha_recuperacao (fk_usuario, token_hash, expira_em, ip)
         VALUES (:u, :h, DATE_ADD(NOW(), INTERVAL ' . (int) SHIELD_SENHA_TOKEN_MINUTOS . ' MINUTE), :ip)'
    )->execute(array(
        ':u' => (int) $usuario['id'],
        ':h' => hash('sha256', $token),
        ':ip' => substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45) ?: null,
    ));

    $link = rtrim((string) $urlBase, '/') . '/redefinir_senha.php?token=' . $token;
    $e = static function ($t) {
        return htmlspecialchars((string) $t, ENT_QUOTES, 'UTF-8');
    };

    $assunto = 'Redefinir a senha do painel';
    $corpo = '<p>Ol&aacute;, ' . $e($usuario['nome']) . '.</p>'
        . '<p>Recebemos um pedido para trocar a senha do seu acesso ao painel. '
        . 'O bot&atilde;o abaixo vale por ' . (int) SHIELD_SENHA_TOKEN_MINUTOS
        . ' minutos e funciona uma &uacute;nica vez.</p>'
        . '<p style="font-size:12px;color:#666">Se n&atilde;o foi voc&ecirc;, ignore este e-mail: '
        . 'a senha atual continua valendo.</p>';
    $html = shield_email_molde($pdo, $assunto, $corpo, 'Escolher a senha nova', $link);

    try {
        if ($enviar !== null) {
            $enviar($para, $assunto, $html, $link);
        } else {
            shield_email_enviar_agora($pdo, $para, $assunto, $html);
        }
    } catch (Throwable $falha) {
        return array('enviado' => false, 'motivo' => 'falha_envio: ' . $falha->getMessage());
    }

    shield_auditar($pdo, 'senha_recuperacao_pedida', array(
        'ator' => (string) $usuario['login'],
        'alvo_tipo' => 'usuario',
        'alvo_id' => (int) $usuario['id'],
        'detalhe' => 'link enviado para ' . $para,
    ));

    return array('enviado' => true, 'motivo' => 'ok');
}

/** O registro de um token que ainda vale, com o usuario dele. Ou null. */
function shield_senha_token_buscar(PDO $pdo, $token)
{
    $token = trim((string) $token);
    if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
        return null;
    }

    $stmt = $pdo->prepare(
        'SELECT r.id, r.fk_usuario, u.nome, u.login, u.email
           FROM senha_recuperacao r
           JOIN usuario u ON u.id = r.fk_usuario
          WHERE r.token_hash = :h AND r.usado_em IS NULL AND r.expira_em > NOW()
          LIMIT 1'
    );
    $stmt->execute(array(':h' => hash('sha256', $token)));
    $linha = $stmt->fetch(PDO::FETCH_ASSOC);

    return is_array($linha) ? $linha : null;
}

/**
 * Troca a senha. Devolve ['ok' => bool, 'erro' => string]; o erro ja vem em
 * portugues para a tela.
 */
function shield_senha_redefinir(PDO $pdo, $token, $nova, $confirmacao)
{
    $registro = shield_senha_token_buscar($pdo, $token);
    if ($registro === null) {
        return array('ok' => false, 'erro' => 'Este link não vale mais. Peça um novo.');
    }

    $nova = (string) $nova;
    if (strlen($nova) < SHIELD_SENHA_MINIMO) {
        return array('ok' => false, 'erro' => 'A senha precisa ter pelo menos '
            . SHIELD_SENHA_MINIMO . ' caracteres.');
    }
    if (!shield_senha_forte($nova)) {
        return array('ok' => false, 'erro' => shield_senha_regra_texto());
    }
    if (!hash_equals($nova, (string) $confirmacao)) {
        return array('ok' => false, 'erro' => 'As duas senhas não são iguais.');
    }

    $pdo->prepare('UPDATE usuario SET senha = :s WHERE id = :u')
        ->execute(array(':s' => password_hash($nova, PASSWORD_DEFAULT), ':u' => (int) $registro['fk_usuario']));

    $pdo->prepare('UPDATE senha_recuperacao SET usado_em = NOW() WHERE id = :id')
        ->execute(array(':id' => (int) $registro['id']));

    // QUEM JA ESTAVA DENTRO SAI. Trocar a senha sem isto nao resolvia o caso
    // em que a recuperacao mais e usada -- conta comprometida: o cookie de
    // "manter conectado" vale 30 dias e se renova a cada uso, entao quem tomou
    // a conta continuava logado depois de a vitima redefinir, achando que
    // tinha resolvido. O painel ja sabia fazer isso no botao "sair de todos os
    // aparelhos" (modules/usuarios/perfil.php).
    //
    // Depois do token queimado e dentro de try/catch de proposito: base sem a
    // migracao de sessao_lembrada lancaria aqui com a senha JA trocada, e o
    // dono receberia uma tela de erro sobre uma troca que deu certo.
    try {
        $pdo->prepare('DELETE FROM sessao_lembrada WHERE fk_usuario = :u')
            ->execute(array(':u' => (int) $registro['fk_usuario']));
    } catch (Throwable $semTabela) {
        // Sessao lembrada e conveniencia; a senha nova ja vale.
    }

    shield_auditar($pdo, 'senha_redefinida', array(
        'ator' => (string) $registro['login'],
        'alvo_tipo' => 'usuario',
        'alvo_id' => (int) $registro['fk_usuario'],
        'detalhe' => 'pelo link de recuperacao',
    ));

    return array('ok' => true, 'erro' => '');
}
