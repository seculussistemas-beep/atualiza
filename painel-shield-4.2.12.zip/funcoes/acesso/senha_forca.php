<?php

// Forca da senha -- 03/09/2026.
//
// UMA regra, em dois lugares que precisam concordar: aqui (o que o servidor
// aceita) e no medidor da tela (templates/entrada.php), que mostra a mesma
// conta enquanto a pessoa digita. Se mudar a escala, mude nos dois.
//
// A escala olha TAMANHO e VARIEDADE (minuscula, maiuscula, numero, simbolo),
// e tamanho compensa variedade: "minha padaria abre cedo" e melhor do que
// "Pad@1" e a regra reconhece isso.
//
//   0 vazia   1 fraca   2 razoavel   3 boa   4 forte
//
// O painel exige 3 (boa). E o que a tela chama de "senha forte".

const SHIELD_SENHA_FORCA_MINIMA = 3;

function shield_senha_forca($senha)
{
    $senha = (string) $senha;
    $tamanho = strlen($senha);
    if ($tamanho === 0) {
        return 0;
    }

    $classes = 0;
    $classes += preg_match('/[a-z]/', $senha) ? 1 : 0;
    $classes += preg_match('/[A-Z]/', $senha) ? 1 : 0;
    $classes += preg_match('/[0-9]/', $senha) ? 1 : 0;
    $classes += preg_match('/[^a-zA-Z0-9]/', $senha) ? 1 : 0;

    if ($tamanho < 8) {
        return 1;
    }
    if (($tamanho >= 12 && $classes >= 3) || ($tamanho >= 16 && $classes >= 2)) {
        return 4;
    }
    if ($classes >= 3 || ($tamanho >= 12 && $classes >= 2)) {
        return 3;
    }
    if ($classes >= 2) {
        return 2;
    }

    return 1;
}

function shield_senha_forte($senha)
{
    return shield_senha_forca($senha) >= SHIELD_SENHA_FORCA_MINIMA;
}

/** O texto de recusa, o mesmo em toda tela que pede senha. */
function shield_senha_regra_texto()
{
    return 'A senha precisa ser pelo menos "boa": 8 ou mais caracteres misturando letras, números e símbolos, ou uma frase longa.';
}
