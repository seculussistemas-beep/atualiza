<?php
/**
 * O administrador do primeiro acesso -- 17/09/2026.
 *
 * Morava dentro de public/install/setup.php. Saiu para ca para poder ser
 * testado: e o UNICO lugar do painel que cria usuario, e um defeito aqui so
 * aparece em instalacao nova, que a suite nao atravessa.
 *
 * E FOI ASSIM QUE UM PASSOU. A permissao de confirmar pagamento a mao nasceu
 * na V3_0_2 "com 1 para quem JA e administrador", e a base nascia com o
 * administrador de fabrica: a migracao o marcava e o primeiro acesso so o
 * atualizava. Quando a senha fixa saiu da baseline (16/09/2026), o primeiro
 * acesso passou a CRIAR o administrador com o padrao da coluna, 0 -- e nenhuma
 * tela grava essa permissao. Painel novo nascia sem ninguem capaz de confirmar
 * dinheiro ou PIX na chave.
 */

if (!function_exists('shield_primeiro_admin_gravar')) {
    /**
     * Cria o administrador do primeiro acesso, ou reaproveita o que ja existe
     * (a base de antes de 16/09/2026 nascia com um de fabrica), e devolve o id.
     * Roda dentro da transacao da tela.
     */
    function shield_primeiro_admin_gravar(PDO $pdo, $nome, $email, $senhaHash)
    {
        $dados = array(
            'nome' => (string) $nome,
            'login' => (string) $email,
            'senha' => (string) $senhaHash,
            'email' => (string) $email,
        );

        $existente = $pdo->query("SELECT id FROM usuario WHERE TRIM(acesso) = '1' ORDER BY id ASC LIMIT 1")->fetchColumn();
        if ($existente !== false) {
            $pdo->prepare(
                "UPDATE usuario
                 SET nome = :nome,
                     login = :login,
                     senha = :senha,
                     data = CURDATE(),
                     uf = 'NA',
                     acesso = '1',
                     email = :email,
                     cnpj = '00000000000000'
                 WHERE id = :id"
            )->execute($dados + array('id' => (int) $existente));
            $id = (int) $existente;
        } else {
            $pdo->prepare(
                "INSERT INTO usuario (nome, login, senha, data, uf, acesso, email, cnpj)
                 VALUES (:nome, :login, :senha, CURDATE(), 'NA', '1', :email, '00000000000000')"
            )->execute($dados);
            $id = (int) $pdo->lastInsertId();
        }

        // O dono do painel confirma pagamento, nos dois caminhos: no que cria e
        // no que reaproveita -- este cura quem instalou entre 16/09 e o conserto.
        // Em comando proprio para os dois acima ficarem como sempre foram.
        try {
            $pdo->prepare('UPDATE usuario SET pode_confirmar_pagamento = 1 WHERE id = :id')->execute(array('id' => $id));
        } catch (PDOException $e) {
            // 1054 e base sem a V3_0_2, e ali shield_pode_confirmar_pagamento ja
            // cai em "administrador confirma". Qualquer outro erro sobe: e a
            // transacao da tela que decide.
            if ((int) ($e->errorInfo[1] ?? 0) !== 1054) {
                throw $e;
            }
        }

        return $id;
    }
}
