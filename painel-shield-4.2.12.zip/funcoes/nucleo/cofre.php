<?php

// O cofre da instalacao -- 15/09/2026.
//
// A crypto_key do config/app.php cifra a chave privada da licenca
// (licenca_emissor) e as credenciais dos gateways (conta_recebimento). Ela
// nasce sozinha no primeiro uso (shield_ensure_crypto_key), e ai morava a
// armadilha: um config/app.php novo sobre um banco ja usado -- instalacao do
// zero, banco copiado de outro painel -- ganhava chave nova calado, e os
// segredos antigos ficavam ilegiveis. Visto num membro: a API passou a
// responder 500, o ERP seguiu com a ultima licenca guardada por ate sete dias
// e nenhum bloqueio chegou as lojas.
//
// Aqui mora a pergunta "o banco tem segredo cifrado?", a decisao do instalador
// (a chave antiga, conferida, ou comecar as chaves do zero de proposito) e a
// frase que explica a falha de cifra nas telas.

require_once __DIR__ . '/system_bootstrap.php';

/**
 * Segredos que dependem da chave: a chave da licenca ATIVA, as credenciais de
 * gateway, a senha do certificado A1 e o SMTP guardado no banco. O A1 e o SMTP
 * entraram depois (15/09/2026): com o opcache velho a chave foi trocada e a
 * senha do A1 ficou ilegivel, porque a guarda nao a contava.
 */
function shield_cofre_contar_segredos(PDO $pdo)
{
    $total = 0;
    foreach (array(
        "SELECT COUNT(*) FROM licenca_emissor WHERE ativo = 1 AND chave_privada <> ''",
        "SELECT COUNT(*) FROM conta_recebimento WHERE credenciais IS NOT NULL AND credenciais <> ''",
        "SELECT COUNT(*) FROM softhouse WHERE certificado_a1_senha_enc IS NOT NULL AND certificado_a1_senha_enc <> ''",
        "SELECT COUNT(*) FROM shield_system_meta WHERE meta_key = 'email_config' AND meta_value IS NOT NULL AND meta_value <> ''",
    ) as $sql) {
        try {
            $total += (int) $pdo->query($sql)->fetchColumn();
        } catch (Throwable $semTabela) {
            // Banco novo, antes das migracoes: nao ha o que proteger.
        }
    }

    return $total;
}

function shield_cofre_frase_recusa($segredos)
{
    return 'O config/app.php esta sem a crypto_key, mas o banco tem ' . (int) $segredos
        . ' segredo(s) cifrado(s) com a chave de antes (a chave da licenca, credenciais de gateway). '
        . 'Gerar outra os deixaria ilegiveis.';
}

/**
 * Null quando pode gerar uma crypto_key nova; a frase quando nao. Sem banco
 * configurado ou alcancavel nao ha o que conferir, e pode -- e o caso da
 * instalacao nova, antes do banco.
 */
function shield_cofre_recusa_gerar_chave(?PDO $pdo = null)
{
    if ($pdo === null) {
        try {
            $config = shield_load_database_config();
            if (!shield_is_database_configured($config)) {
                return null;
            }
            $pdo = shield_create_pdo_connection($config);
        } catch (Throwable $semBanco) {
            return null;
        }
    }

    $segredos = shield_cofre_contar_segredos($pdo);

    return $segredos > 0 ? shield_cofre_frase_recusa($segredos) : null;
}

/**
 * A crypto_key (base64) abre os segredos deste banco? So o mac e conferido --
 * o mesmo formato de shield_encrypt_secret: iv (16), mac (32), cifra --, que e
 * o que diz se a chave e a mesma sem abrir segredo nenhum. Sem segredo para
 * provar, abre.
 */
function shield_cofre_chave_abre(PDO $pdo, $chaveBase64)
{
    $chave = shield_decode_crypto_key($chaveBase64);
    if ($chave === null) {
        return false;
    }

    $amostra = '';
    foreach (array(
        "SELECT chave_privada FROM licenca_emissor WHERE ativo = 1 AND chave_privada <> '' ORDER BY id DESC LIMIT 1",
        "SELECT credenciais FROM conta_recebimento WHERE credenciais IS NOT NULL AND credenciais <> '' ORDER BY id LIMIT 1",
        "SELECT certificado_a1_senha_enc FROM softhouse WHERE certificado_a1_senha_enc IS NOT NULL AND certificado_a1_senha_enc <> '' LIMIT 1",
        "SELECT meta_value FROM shield_system_meta WHERE meta_key = 'email_config' AND meta_value <> '' LIMIT 1",
    ) as $sql) {
        try {
            $amostra = (string) $pdo->query($sql)->fetchColumn();
        } catch (Throwable $semTabela) {
            $amostra = '';
        }
        if ($amostra !== '') {
            break;
        }
    }
    if ($amostra === '') {
        return true;
    }

    $bruto = base64_decode($amostra, true);
    if ($bruto === false || strlen($bruto) < 49) {
        return false;
    }

    return hash_equals(substr($bruto, 16, 32), hash_hmac('sha256', substr($bruto, 0, 16) . substr($bruto, 48), $chave, true));
}

/**
 * A decisao do instalador. Devolve ['erro' => ?string, 'crypto_key' => ?string,
 * 'recomecar' => bool]; crypto_key preenchida e a que vai para o config/app.php.
 *
 * config/app.php com chave, ou banco sem segredo: nada muda. Banco usado sem
 * chave: a antiga colada (e conferida contra um segredo), ou o "comecar do
 * zero" marcado. Nenhum dos dois: recusa, e nada e instalado.
 */
function shield_cofre_decidir_instalacao(PDO $pdo, array $appConfig, array $post)
{
    $r = array('erro' => null, 'crypto_key' => null, 'recomecar' => false);

    if (shield_decode_crypto_key($appConfig['crypto_key'] ?? '') !== null) {
        return $r;
    }
    $segredos = shield_cofre_contar_segredos($pdo);
    if ($segredos === 0) {
        return $r;
    }

    $antiga = trim((string) ($post['crypto_key_antiga'] ?? ''));
    if ($antiga !== '') {
        if (shield_decode_crypto_key($antiga) === null) {
            $r['erro'] = 'A crypto_key colada nao e valida. E o valor da linha crypto_key do config/app.php antigo: 44 caracteres, terminando em =.';
        } elseif (!shield_cofre_chave_abre($pdo, $antiga)) {
            $r['erro'] = 'Essa crypto_key nao abre os segredos deste banco. Confira se e o config/app.php da instalacao que usava este banco.';
        } else {
            $r['crypto_key'] = $antiga;
        }

        return $r;
    }

    if (!empty($post['recomecar_chaves'])) {
        $r['recomecar'] = true;
        $r['crypto_key'] = shield_generate_crypto_key();

        return $r;
    }

    $r['erro'] = 'Este banco ja foi usado por outra instalacao do painel: tem ' . $segredos
        . ' segredo(s) cifrado(s) com a crypto_key dela (a chave da licenca, credenciais de gateway). '
        . 'Cole abaixo a crypto_key do config/app.php antigo, ou marque "comecar as chaves do zero". '
        . 'Do zero, sera preciso gerar outro par em Chaves, recompilar o ERP e cadastrar de novo as credenciais.';

    return $r;
}

/**
 * Comecar as chaves do zero: desliga o que a chave nova nao abre. A chave da
 * licenca antiga fica no historico, desligada (o numero kid continua contando);
 * a credencial que ninguem mais le e apagada e a conta desligada, para nao ser
 * oferecida na hora de cobrar.
 */
function shield_cofre_recomecar(PDO $pdo)
{
    $emissores = $pdo->exec('UPDATE licenca_emissor SET ativo = 0 WHERE ativo = 1');
    $contas = $pdo->exec("UPDATE conta_recebimento SET credenciais = NULL, ativo = 0 WHERE credenciais IS NOT NULL AND credenciais <> ''");
    // A senha do A1 e o SMTP cifrados com a chave velha tambem nao abrem mais: sai
    // o que ninguem le, e o membro digita de novo na tela de cada um.
    foreach (array(
        "UPDATE softhouse SET certificado_a1_senha_enc = NULL WHERE certificado_a1_senha_enc IS NOT NULL AND certificado_a1_senha_enc <> ''",
        "DELETE FROM shield_system_meta WHERE meta_key = 'email_config'",
    ) as $sql) {
        try {
            $pdo->exec($sql);
        } catch (Throwable $semTabela) {
        }
    }

    return array('emissores' => (int) $emissores, 'contas' => (int) $contas);
}

/** A frase que explica uma falha de cifra, ou '' quando a falha e outra. */
function shield_cofre_falha_explicada($mensagem)
{
    $mensagem = (string) $mensagem;

    if (stripos($mensagem, 'O config/app.php esta sem a crypto_key') !== false) {
        return 'O config/app.php desta instalacao esta sem a crypto_key, e o banco tem segredos cifrados com ela. '
            . 'Enquanto isso o painel nao assina licenca: o ERP segue com a ultima que recebeu, por ate 7 dias, e nenhum bloqueio chega as lojas. '
            . 'Para resolver: devolva o config/app.php do backup. Sem ele, apague o config/app.php e passe pelo instalador, que pede a chave antiga '
            . 'ou comeca as chaves do zero; do zero, gere um par novo em Chaves, cole o bloco no ERP com o LICENCA_KID igual ao numero da chave, '
            . 'recompile e cadastre de novo as credenciais em Formas de recebimento.';
    }

    foreach (array('Falha de integridade no segredo criptografado', 'Falha ao descriptografar segredo', 'Segredo criptografado invalido') as $trecho) {
        if (stripos($mensagem, $trecho) !== false) {
            return 'A chave privada da licenca foi cifrada com uma crypto_key que nao e a do config/app.php desta instalacao. '
                . 'Acontece quando o painel e instalado do zero sobre um banco que ja era usado, quando o banco vem de outra instalacao '
                . 'ou quando o config/app.php e trocado. Enquanto isso o painel nao assina licenca: o ERP segue com a ultima que recebeu, '
                . 'por ate 7 dias, e nenhum bloqueio chega as lojas. Para resolver: devolva o config/app.php antigo (a linha crypto_key). '
                . 'Sem ele, gere um par novo em Chaves, cole o bloco no ERP com o LICENCA_KID igual ao numero da chave, recompile '
                . 'e cadastre de novo as credenciais em Formas de recebimento.';
        }
    }

    return '';
}
