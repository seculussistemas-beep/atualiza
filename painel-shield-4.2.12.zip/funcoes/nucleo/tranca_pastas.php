<?php

// A segunda tranca, criada em tempo de execucao -- 08/09/2026.
//
// O que protege o codigo hoje e o DocumentRoot apontar para public/: o resto
// simplesmente nao esta na pasta publicada. Os .htaccess por pasta existem
// para o dia em que isso nao for verdade -- instalacao antiga que nunca
// reapontou, hospedagem que serve a raiz, alguem "arrumando" a configuracao.
//
// Ate 08/09/2026 a doutrina alcancava seis pastas (banco/, funcoes/, modules/,
// router/, security/, templates/) e deixava de fora justamente as duas que
// mais doem: src/, que e o codigo das classes, e config/, que guarda a
// crypto_key -- a chave que cifra a privada da licenca e a senha do
// certificado A1 -- alem das credenciais do banco.
//
// POR QUE NAO BASTA COMMITAR O ARQUIVO: shield_atu_preservados() protege a
// pasta `config` inteira da copia do atualizador, e com razao (e onde mora a
// instalacao do membro). O efeito colateral e que NADA que venha no pacote e
// escrito ali -- nem uma tranca. Quem ja tem o painel instalado so a recebe se
// alguem a criar de dentro, e o lugar dessa criacao e o /update, junto das
// outras reconciliacoes que alcancam instalacao existente.

/**
 * As pastas que nunca podem ser servidas e que o PACOTE NAO ALCANCA.
 *
 * As tres primeiras sao exatamente as que shield_atu_preservados() protege da
 * copia do atualizador, menos `.well-known` -- que existe para ser servida, e
 * e por onde o Let's Encrypt confere o dominio. Pasta preservada e, por
 * definicao, pasta onde nada do pacote e escrito: se ela nao pode ser servida,
 * a unica forma de a tranca chegar em quem ja instalou e por dentro.
 *
 * uploads/ esta aqui pelo que ela guarda HOJE: `certificados/`, com o .pfx do
 * A1 do membro, e `logs/` do ERP. Nao e mais pasta de imagem publica -- a foto
 * de perfil saiu quando a pasta ficou fora do docroot (ver o comentario em
 * modules/usuarios/perfil.php). Com o DocumentRoot na raiz, deixar isso aberto
 * e entregar o certificado de assinatura por download direto.
 *
 * src/ nao e preservada -- o pacote alcanca e o .htaccess dela vai commitado --
 * mas fica na lista para o /update repor se o arquivo se perder num refactor,
 * que e exatamente o modo de falhar que a segunda tranca existe para cobrir.
 */
function shield_tranca_pastas()
{
    return array('config', 'estagio', 'uploads', 'src');
}

/** O conteudo da tranca: as duas sintaxes, porque hospedagem antiga roda 2.2. */
function shield_tranca_conteudo()
{
    return "<IfModule mod_authz_core.c>\n"
        . "    Require all denied\n"
        . "</IfModule>\n"
        . "<IfModule !mod_authz_core.c>\n"
        . "    Deny from all\n"
        . "</IfModule>\n";
}

/**
 * Cria o .htaccess de negacao na pasta, se faltar.
 *
 * NAO SOBRESCREVE. Se ja existe um arquivo ali, ele pode ter regra propria que
 * alguem colocou por um motivo -- e a tranca que se quer garantir ja esta
 * cumprida pela existencia dele. Devolve true so quando criou de fato.
 *
 * Pasta inexistente devolve false em vez de erro: o /update roda em painel
 * torto, e uma pasta faltando nao pode derrubar a atualizacao.
 */
function shield_tranca_pasta($pasta)
{
    $pasta = rtrim((string) $pasta, '/\\');

    if ($pasta === '' || !is_dir($pasta)) {
        return false;
    }

    $arquivo = $pasta . DIRECTORY_SEPARATOR . '.htaccess';
    if (file_exists($arquivo)) {
        return false;
    }

    return @file_put_contents($arquivo, shield_tranca_conteudo()) !== false;
}

/**
 * Passa por todas e devolve os nomes das que ganharam tranca agora, para o
 * /update poder dizer ao membro o que mudou.
 *
 * @return string[]
 */
function shield_tranca_pastas_do_painel()
{
    $raiz = dirname(__DIR__, 2);
    $criadas = array();

    foreach (shield_tranca_pastas() as $pasta) {
        if (shield_tranca_pasta($raiz . DIRECTORY_SEPARATOR . $pasta)) {
            $criadas[] = $pasta . '/';
        }
    }

    return $criadas;
}
