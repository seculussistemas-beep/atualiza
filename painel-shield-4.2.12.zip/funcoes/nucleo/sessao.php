<?php

/**
 * A SESSAO ABRE COM O COOKIE TRANCADO -- 11/09/2026.
 *
 * Ate aqui session_start() saia com o padrao do PHP: sem HttpOnly, sem
 * SameSite e sem Secure. O cookie da sessao e o que um XSS roubaria e o que
 * um site de fora tentaria carregar num POST; as tres flags fecham as duas
 * portas sem mudar nada no painel. Secure so quando a pagina veio por HTTPS:
 * em bancada HTTP o cookie ainda precisa existir.
 *
 * Uma funcao so, chamada pelo router (csrf.php) e por verificar_sesao.php,
 * para as flags nao dependerem de quem abriu a sessao primeiro.
 */
function shield_sessao_abrir()
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $https = (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off')
        || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443
        || strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
    session_set_cookie_params(array(
        'lifetime' => 0,
        'path' => '/',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ));
    session_start();
}
