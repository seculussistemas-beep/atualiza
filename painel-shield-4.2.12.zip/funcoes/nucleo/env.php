<?php

// O .env do painel -- 03/09/2026.
//
// Um unico lugar para o que e SEGREDO DA INSTALACAO e nao do codigo: senha do
// SMTP, endereco publico do painel. O arquivo fica na raiz, ao lado do
// .env.example, e esta no .gitignore.
//
// A ORDEM E: variavel de ambiente de verdade > .env > padrao. Quem roda no
// compose pode passar tudo por `environment:` e nunca ter um .env; quem sobe
// por FTP numa hospedagem sem shell escreve o .env e pronto. Os dois caminhos
// chegam na mesma funcao.
//
// NAO e o dotenv do composer, de proposito: o membro sobe a pasta pronta e nao
// roda composer do outro lado (ver includes/autoload.php). E um leitor de
// KEY=VALUE, que e tudo que este arquivo precisa ser.

/**
 * Le o texto de um .env e devolve chave => valor. Pura: nao toca em disco nem
 * em getenv(), para poder ser testada com uma string.
 *
 * Aceita: linha em branco, comentario com #, `export CHAVE=valor`, valor entre
 * aspas simples ou duplas (com o # dentro preservado), e comentario no fim de
 * linha sem aspas (`CHAVE=valor # explicacao`).
 */
function shield_env_parse($conteudo)
{
    $saida = array();

    foreach (preg_split('/\r\n|\r|\n/', (string) $conteudo) as $linha) {
        $linha = trim($linha);
        if ($linha === '' || $linha[0] === '#') {
            continue;
        }
        if (strncmp($linha, 'export ', 7) === 0) {
            $linha = trim(substr($linha, 7));
        }

        $igual = strpos($linha, '=');
        if ($igual === false) {
            continue;
        }

        $chave = trim(substr($linha, 0, $igual));
        if ($chave === '' || !preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $chave)) {
            continue;
        }

        $valor = trim(substr($linha, $igual + 1));

        if ($valor !== '' && ($valor[0] === '"' || $valor[0] === "'")) {
            $aspas = $valor[0];
            $fim = strpos($valor, $aspas, 1);
            $valor = $fim === false ? substr($valor, 1) : substr($valor, 1, $fim - 1);
            if ($aspas === '"') {
                $valor = str_replace(array('\\n', '\\"'), array("\n", '"'), $valor);
            }
        } else {
            // Sem aspas, o # abre comentario -- so quando vem depois de espaco,
            // para uma cor "#1a6fb8" nao virar valor vazio.
            $valor = (string) preg_replace('/\s+#.*$/', '', $valor);
        }

        $saida[$chave] = $valor;
    }

    return $saida;
}

/** O .env da raiz, lido uma vez por requisicao. Sem arquivo, array vazio. */
function shield_env_arquivo()
{
    static $cache = null;

    if ($cache === null) {
        $caminho = dirname(__DIR__, 2) . '/.env';
        $cache = is_file($caminho) && is_readable($caminho)
            ? shield_env_parse((string) file_get_contents($caminho))
            : array();
    }

    return $cache;
}

/**
 * O valor de uma variavel, na ordem: ambiente do processo, .env, padrao.
 * Vazio conta como ausente -- `SHIELD_SMTP_HOST=` no .env quer dizer "nao
 * configurei", e nao "configurei como nada".
 */
function shield_env($chave, $padrao = '')
{
    $valor = getenv($chave);
    if ($valor === false || $valor === '') {
        $valor = isset($_ENV[$chave]) ? (string) $_ENV[$chave] : '';
    }
    if ($valor === '') {
        $arquivo = shield_env_arquivo();
        $valor = isset($arquivo[$chave]) ? (string) $arquivo[$chave] : '';
    }

    return $valor === '' ? (string) $padrao : (string) $valor;
}
