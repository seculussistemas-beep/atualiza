<?php

if (!function_exists('shield_h')) {
    function shield_h($value)
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}
