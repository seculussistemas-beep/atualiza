<?php

function shield_root_path()
{
    // DOIS niveis, e nao um: este arquivo desceu de includes/ para
    // funcoes/nucleo/ na fase 4. Enquanto foi um, shield_root_path()
    // devolvia /funcoes e TODO caminho derivado dela apontava para o vazio --
    // config/, public/install/, o banco. O painel se trancava por fora e o
    // diagnostico acusava "inexistente" em pasta que existe.
    return dirname(__DIR__, 2);
}

function shield_config_dir()
{
    return shield_root_path() . DIRECTORY_SEPARATOR . 'config';
}

function shield_app_config_path()
{
    return shield_config_dir() . DIRECTORY_SEPARATOR . 'app.php';
}

function shield_db_config_path()
{
    return shield_config_dir() . DIRECTORY_SEPARATOR . 'database.php';
}

function shield_baseline_sql_path()
{
    return shield_root_path() . DIRECTORY_SEPARATOR . 'banco' . DIRECTORY_SEPARATOR . 'BancoCompleto.sql';
}

function shield_migrations_dir()
{
    // Junto do BancoCompleto.sql: as duas coisas descrevem o mesmo esquema, e
    // nenhuma delas e pagina. Saiu de update/ quando update/ virou so a tela.
    return shield_root_path() . DIRECTORY_SEPARATOR . 'banco' . DIRECTORY_SEPARATOR . 'migrations';
}

function shield_default_app_config()
{
    return [
        'app_name' => 'Painel Shield',
        'app_version' => '2.0.0',
        // 03/09/2026: piso subiu de 8.0 para 8.2. Nao e preferencia por versao
        // nova -- o PHP 8.0 morreu em 26/11/2023 e o 8.1 em 31/12/2025, e
        // nenhum dos dois recebe mais correcao de seguranca. Declarar 8.0 como
        // minimo era declarar suporte a runtime abandonado ha quase tres anos.
        //
        // ESTE VALOR NAO BASTA SOZINHO. Ele e o padrao; a instalacao existente
        // tem o dela gravado em config/app.php, e shield_load_php_array_file()
        // faz array_replace(padrao, arquivo) -- o ARQUIVO vence. Quem leva o
        // piso novo para quem ja instalou e shield_reconcile_version_floors(),
        // chamada pelo /update. Mexer so aqui pareceria feito e nao teria
        // efeito nenhum onde importa.
        'php_min_version' => '8.2.0',
        'php_recommended_version' => '8.4.0',
        'installed' => false,
        'installed_at' => null,
        'crypto_key' => '',
    ];
}

function shield_default_db_config()
{
    return [
        'configured' => false,
        'host' => 'localhost',
        'port' => 3306,
        'database' => '',
        'username' => '',
        'password' => '',
        'charset' => 'utf8',
    ];
}

function shield_load_php_array_file($path, array $fallback)
{
    if (!is_file($path)) {
        return $fallback;
    }

    $data = require $path;
    if (!is_array($data)) {
        return $fallback;
    }

    return array_replace($fallback, $data);
}

function shield_load_app_config()
{
    return shield_load_php_array_file(shield_app_config_path(), shield_default_app_config());
}

function shield_load_database_config()
{
    return shield_load_php_array_file(shield_db_config_path(), shield_default_db_config());
}

function shield_decode_crypto_key($encodedKey)
{
    $encodedKey = trim((string) $encodedKey);
    if ($encodedKey === '') {
        return null;
    }

    $decoded = base64_decode($encodedKey, true);
    if ($decoded === false || strlen($decoded) !== 32) {
        return null;
    }

    return $decoded;
}

function shield_generate_crypto_key()
{
    return base64_encode(random_bytes(32));
}

function shield_ensure_crypto_key()
{
    $appConfig = shield_load_app_config();
    $decoded = shield_decode_crypto_key($appConfig['crypto_key'] ?? '');
    if ($decoded !== null) {
        return $decoded;
    }

    // O DISCO PRIMEIRO (15/09/2026): o config/app.php lido acima veio do opcache,
    // que pode estar velho mesmo com a chave ja gravada -- provado num Apache com
    // o padrao do PHP. Chave no disco e a chave; so sem ela se pensa em gerar.
    $doDisco = shield_crypto_key_do_disco();
    if ($doDisco !== null) {
        return $doDisco;
    }

    // O COFRE PERGUNTA ANTES (15/09/2026): chave nova sobre um banco que ja tem
    // segredo cifrado deixa todos ilegiveis, calado -- foi o que parou a licenca
    // de um membro que instalou do zero sobre o banco antigo. Ver cofre.php.
    require_once __DIR__ . '/cofre.php';
    $recusa = shield_cofre_recusa_gerar_chave();
    if ($recusa !== null) {
        throw new RuntimeException($recusa);
    }

    $generated = shield_generate_crypto_key();
    $appConfig['crypto_key'] = $generated;
    if (!shield_write_app_config($appConfig)) {
        throw new RuntimeException('Nao foi possivel persistir a chave criptografica da aplicacao.');
    }

    $decoded = shield_decode_crypto_key($generated);
    if ($decoded === null) {
        throw new RuntimeException('Falha ao validar chave criptografica gerada.');
    }

    return $decoded;
}

function shield_is_database_configured(array $config)
{
    if (empty($config['configured'])) {
        return false;
    }

    return trim((string) ($config['host'] ?? '')) !== ''
        && trim((string) ($config['database'] ?? '')) !== ''
        && trim((string) ($config['username'] ?? '')) !== '';
}

function shield_ensure_directory($directory)
{
    if (is_dir($directory)) {
        return true;
    }

    return @mkdir($directory, 0775, true);
}

function shield_write_php_array_file($path, array $data)
{
    $content = "<?php\n\nreturn " . var_export($data, true) . ";\n";
    if (file_put_contents($path, $content) === false) {
        return false;
    }

    // O CACHE DO ARQUIVO SAI JUNTO COM A GRAVACAO (15/09/2026). Estes arquivos
    // sao lidos com require, e o opcache guardava a versao anterior: provado num
    // Apache com o padrao do PHP (revalidate_freq=2), o "Gerar par" gravava a
    // crypto_key, relia o config/app.php do cache sem ela e gravava outra por
    // cima -- a chave privada da licenca ficava ilegivel. O @ e porque hospedagem
    // com opcache.restrict_api recusa; para ela, shield_crypto_key_do_disco.
    clearstatcache(true, $path);
    if (function_exists('opcache_invalidate')) {
        @opcache_invalidate($path, true);
    }

    return true;
}

/**
 * A crypto_key lida direto do texto do config/app.php, sem require e portanto
 * sem opcache, ou null. E a pergunta que shield_ensure_crypto_key faz antes de
 * gerar chave nova: o cache pode estar velho mesmo depois do opcache_invalidate
 * (hospedagem com restrict_api), mas o disco nao.
 */
function shield_crypto_key_do_disco($path = null)
{
    $path = $path === null ? shield_app_config_path() : (string) $path;
    $texto = is_file($path) ? @file_get_contents($path) : false;
    if (!is_string($texto) || preg_match("/'crypto_key'\\s*=>\\s*'([A-Za-z0-9+\\/=]+)'/", $texto, $m) !== 1) {
        return null;
    }

    return shield_decode_crypto_key($m[1]);
}

/**
 * O config com a crypto_key do disco quando ele chega sem chave -- 15/09/2026.
 *
 * Provado em PHP-FPM e OpenLiteSpeed com opcache.restrict_api e
 * validate_timestamps=0: o opcache_invalidate e recusado, quem le o app.php do
 * cache velho (sem chave) e grava de volta -- o piso de versao do /update faz
 * isso -- apagava a chave do arquivo. Nenhum caminho grava chave vazia de
 * proposito; chave informada vence a do disco.
 */
function shield_app_config_com_chave_do_disco(array $config, $path = null)
{
    if (trim((string) ($config['crypto_key'] ?? '')) !== '') {
        return $config;
    }
    $doDisco = shield_crypto_key_do_disco($path);
    if ($doDisco !== null) {
        $config['crypto_key'] = base64_encode($doDisco);
    }

    return $config;
}

function shield_write_app_config(array $config)
{
    if (!shield_ensure_directory(shield_config_dir())) {
        return false;
    }

    return shield_write_php_array_file(shield_app_config_path(), shield_app_config_com_chave_do_disco($config));
}

function shield_write_database_config(array $config)
{
    if (!shield_ensure_directory(shield_config_dir())) {
        return false;
    }

    return shield_write_php_array_file(shield_db_config_path(), $config);
}

/**
 * Leva o piso de PHP novo para quem JA instalou -- 03/09/2026.
 *
 * O config/app.php e escrito uma vez, na instalacao, e nunca mais. Como
 * shield_load_php_array_file() faz array_replace(padrao, arquivo), o valor
 * gravado la vence o padrao do codigo para sempre. Sem esta rotina, subir o
 * minimo em shield_default_app_config() so valeria para instalacao nova -- e a
 * base inteira, que e justamente quem esta em PHP velho, nunca veria a
 * mudanca.
 *
 * SO SOBE, NUNCA DESCE. Membro que deliberadamente exigiu mais do que o padrao
 * mantem o que escolheu; se o padrao do codigo for menor ou igual ao que ja
 * esta gravado, nada e tocado. Isso tambem torna a funcao idempotente: rodar
 * dez vezes tem o mesmo efeito de rodar uma.
 *
 * Devolve o que mudou, em texto, para o /update mostrar. Vazio = nada a fazer.
 */
function shield_reconcile_version_floors()
{
    $atual = shield_load_app_config();
    $padrao = shield_default_app_config();
    $mudancas = [];

    foreach (['php_min_version', 'php_recommended_version'] as $chave) {
        $gravado = trim((string) ($atual[$chave] ?? ''));
        $novo = trim((string) ($padrao[$chave] ?? ''));

        if ($novo === '') {
            continue;
        }

        // version_compare e nao comparacao de string: '8.10.0' > '8.9.0' e
        // verdade em versao e mentira em texto.
        if ($gravado === '' || version_compare($novo, $gravado, '>')) {
            $atual[$chave] = $novo;
            $mudancas[] = sprintf(
                '%s: %s -> %s',
                $chave,
                $gravado === '' ? '(ausente)' : $gravado,
                $novo
            );
        }
    }

    if ($mudancas === []) {
        return [];
    }

    if (!shield_write_app_config($atual)) {
        throw new RuntimeException('Nao foi possivel gravar config/app.php com os novos requisitos de PHP.');
    }

    return $mudancas;
}

/* Leva a cor de marca nova para quem ja instalou.
 *
 * Mesmo problema do piso de PHP, em outro lugar: o padrao esta no codigo, mas
 * quem VENCE e o valor gravado -- aqui, shield_system_meta.marca_cor, que o
 * casco le e despeja num <style> inline depois do <link> da folha. Editar
 * public/css/painel.css nao muda um pixel de instalacao que ja rodou.
 *
 * SO TROCA O QUE AINDA E DE FABRICA. Se o membro escolheu a propria cor na tela
 * de softhouse, ela fica -- reconciliar por cima disso seria desfazer escolha
 * deliberada, e ele nao teria como saber por que a marca dele mudou sozinha.
 * Por isso a condicao e igualdade exata com o azul antigo, e nao "parece azul".
 *
 * Idempotente: rodada a segunda vez, o valor ja nao e o antigo e nada acontece.
 *
 * Devolve o que mudou, em texto, para o /update mostrar. Vazio = nada a fazer.
 */
function shield_reconcile_marca_padrao(PDO $pdo)
{
    if (!shield_table_exists($pdo, 'shield_system_meta')) {
        return [];
    }

    $gravada = strtolower(trim((string) shield_get_system_meta($pdo, 'marca_cor', '')));

    // Ausente conta como de fabrica: a instalacao nunca escolheu cor, entao o
    // padrao do codigo e que estava valendo -- e o padrao mudou.
    if ($gravada !== '' && $gravada !== SHIELD_MARCA_COR_FABRICA_ANTIGA) {
        return [];
    }

    shield_set_system_meta($pdo, 'marca_cor', SHIELD_MARCA_COR_PADRAO);

    return [sprintf(
        'marca_cor: %s -> %s',
        $gravada === '' ? '(ausente)' : $gravada,
        SHIELD_MARCA_COR_PADRAO
    )];
}

function shield_current_request_path()
{
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $path = parse_url($uri, PHP_URL_PATH);
    if (!is_string($path) || $path === '') {
        $path = '/';
    }

    $trimmed = rtrim($path, '/');
    return $trimmed === '' ? '/' : $trimmed;
}

function shield_guard_skip_path($path)
{
    if ($path === '/install' || str_starts_with($path, '/install/')) {
        return true;
    }

    if ($path === '/update' || str_starts_with($path, '/update/')) {
        return true;
    }

    // Servicos lidos por PROGRAMA, nao por navegador - 23/08/2026.
    // Sem isto o painel meio instalado responde um 302 para a tela de
    // instalacao, e quem esta do outro lado e o ERP de uma loja: ele receberia
    // HTML onde espera JSON. Deixando passar, o erro chega como resposta
    // legivel em vez de um redirecionamento silencioso.
    if ($path === '/api' || str_starts_with($path, '/api/')) {
        return true;
    }

    // A AREA DO CLIENTE (10/09/2026, tarde) e aberta pelo cliente FINAL, pelo
    // link que o ERP recebeu. Mandar essa pessoa para o instalador do painel
    // do membro nao faz sentido em nenhum cenario: painel sem instalar nao
    // tem cliente nenhum, e a propria tela responde "link nao abre".
    if ($path === '/area_cliente.php') {
        return true;
    }

    return false;
}

/**
 * ESTE CAMINHO E LIDO POR PROGRAMA? -- 16/09/2026.
 *
 * O aviso do gateway (webhooks) e o relogio (cron.php) nao tem gente do outro
 * lado. O porteiro mandava os dois para a tela de instalacao ou de atualizacao,
 * e o gateway recebia HTML onde espera JSON: para ele a entrega deu certo, e o
 * aviso do pagamento se perde. A rota de licenca ja era DISPENSADA do porteiro
 * pelo mesmo motivo (shield_guard_skip_path), mas dispensar nao serve aqui: com
 * migracao pendente o webhook gravaria num esquema velho, e o cron rodaria a
 * fila sobre ele. O que muda e a RESPOSTA -- ver shield_guard_parar.
 */
function shield_guard_servico_json($path)
{
    $path = (string) $path;
    if ($path === '/webhooks' || str_starts_with($path, '/webhooks/') || $path === '/cron.php') {
        return true;
    }

    // AS URLS ANTIGAS DE WEBHOOK NA RAIZ -- 17/09/2026. /pagseguro_webhook.php,
    // /efi_webhook.php e /cora_webhook.php sao rotas que caem em public/webhooks/,
    // e o gateway que ainda as tem cadastradas recebia o 302 de tela. Sem o .php
    // tambem e rota (public/.htaccess). PortaoServicoTest confere contra
    // routes.php: rota nova que caia em public/webhooks/ tem de entrar aqui.
    return (bool) preg_match('#^/(pagseguro|efi|cora)_webhook(\.php)?$#', $path);
}

/**
 * A SAIDA DO PORTEIRO: 302 para quem tem navegador, 503 em JSON para quem e
 * programa -- 16/09/2026.
 *
 * O 503 e a escolha certa e nao um detalhe: para o gateway ele significa "tente
 * de novo depois", e e isso que faz o aviso voltar quando o painel terminar a
 * atualizacao (o Inter, por exemplo, reenvia quatro vezes). 200 com HTML seria
 * entrega feita, e o pagamento so seria descoberto pela conciliacao, dias
 * depois; 404 faria alguns provedores desistirem de vez.
 */
function shield_guard_parar($servico, $destino, $motivo)
{
    if (!$servico) {
        shield_redirect($destino);
    }

    // Nada de HTML antes do JSON: o filtro de saida do CSRF pode estar aberto.
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
        header('Retry-After: 300');
        http_response_code(503);
    }
    echo json_encode(array('ok' => false, 'erro' => 'painel em manutencao', 'motivo' => (string) $motivo));
    exit;
}

function shield_redirect($location)
{
    if (!headers_sent()) {
        header('Location: ' . $location);
    }
    exit;
}

/**
 * As opcoes de TLS da conexao, ou array() quando o config/database.php nao pede
 * -- 15/09/2026. Provado num MySQL 8.4 com require_secure_transport=ON, que
 * recusava o painel com 3159.
 *
 * NO MYSQLND QUEM LIGA O TLS E O ATTR_SSL_CA, MESMO VAZIO. So o
 * VERIFY_SERVER_CERT continua sem criptografia, e so o CA vazio sem o VERIFY da
 * 2002. Com CA informado o certificado e conferido por padrao, inclusive o nome
 * do host; o autoassinado da hospedagem pede 'ssl_verify' => false. Sem CA a
 * conferencia fica desligada, a nao ser que se peca: ai vale o pacote de
 * certificados do sistema.
 */
function shield_pdo_opcoes_ssl(array $config)
{
    $ca = trim((string) ($config['ssl_ca'] ?? ''));
    if (empty($config['ssl']) && $ca === '') {
        return array();
    }
    $verificar = array_key_exists('ssl_verify', $config) ? (bool) $config['ssl_verify'] : ($ca !== '');
    if ($ca === '' && $verificar && function_exists('openssl_get_cert_locations')) {
        $ca = (string) (openssl_get_cert_locations()['default_cert_file'] ?? '');
    }

    // Pdo\Mysql:: e o nome do PHP 8.4; o PDO::MYSQL_ATTR_ fica obsoleto no 8.5.
    if (defined('Pdo\\Mysql::ATTR_SSL_CA')) {
        $attrCa = constant('Pdo\\Mysql::ATTR_SSL_CA');
        $attrVerificar = constant('Pdo\\Mysql::ATTR_SSL_VERIFY_SERVER_CERT');
    } elseif (defined('PDO::MYSQL_ATTR_SSL_CA')) {
        $attrCa = PDO::MYSQL_ATTR_SSL_CA;
        $attrVerificar = PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT;
    } else {
        throw new RuntimeException('O config/database.php pede conexao criptografada (ssl), mas o pdo_mysql deste PHP nao tem TLS.');
    }

    return array($attrCa => $ca, $attrVerificar => $verificar);
}

function shield_create_pdo_connection(array $config)
{
    if (!shield_is_database_configured($config)) {
        throw new RuntimeException('Configuracao de banco de dados incompleta.');
    }

    $host = trim((string) $config['host']);
    $port = (int) ($config['port'] ?? 3306);
    $database = trim((string) $config['database']);
    $username = (string) $config['username'];
    $password = (string) ($config['password'] ?? '');
    $charset = trim((string) ($config['charset'] ?? 'utf8'));
    if ($charset === '') {
        $charset = 'utf8';
    }

    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=%s',
        $host,
        $port > 0 ? $port : 3306,
        $database,
        $charset
    );

    $pdo = new PDO(
        $dsn,
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ] + shield_pdo_opcoes_ssl($config)
    );

    // O MODO DO SERVIDOR NAO E O DO PAINEL -- 14/09/2026. Membro em hospedagem
    // cPanel abriu a Central num banco recem-instalado e leu "1525 Incorrect
    // DATE value: '0000-00-00'". O painel compara validade_licenca com a data
    // zerada em onze consultas; o MySQL 8, com NO_ZERO_DATE ou NO_ZERO_IN_DATE
    // na sessao (o padrao dele), converte a constante para DATE ao preparar a
    // consulta e recusa -- com a tabela vazia, antes de ler linha nenhuma. O
    // MariaDB da bancada aceita a mesma comparacao calado, e por isso a suite
    // nunca viu.
    //
    // O ajuste mora AQUI, e nao consulta a consulta, porque todo PDO do painel
    // nasce nesta funcao -- telas, API de licenca, webhooks, cron, instalador e
    // /update --, e a consulta que alguem escrever amanha ja nasce coberta.
    // NAO e PDO::MYSQL_ATTR_INIT_COMMAND: la, um SET recusado derrubaria a
    // conexao inteira, inclusive a do caixa da loja pedindo licenca.
    shield_pdo_ajustar_sql_mode($pdo);

    return $pdo;
}

/**
 * O sql_mode da hospedagem sem os modos que o painel nunca foi escrito para
 * aguentar, e so eles.
 *
 * NO_ZERO_DATE e NO_ZERO_IN_DATE: o 1525 da data zerada, acima.
 *
 * ONLY_FULL_GROUP_BY: shield_parque_versoes agrupa por
 * COALESCE(NULLIF(TRIM(VERSAO_EXE), ...)) e o MariaDB com esse modo recusa com
 * 1055 (medido no 10.11, 14/09/2026) -- e ela roda na Central sem try, entao a
 * tela cairia do mesmo jeito com outro numero. A suite roda sem o modo, e
 * nenhuma outra consulta do painel foi conferida com ele. Tira-lo nao muda o
 * resultado de consulta nenhuma que ja era valida: so deixa de recusar.
 *
 * TRADITIONAL SAI JUNTO, e nao por zelo: o MariaDB lista o apelido ao lado dos
 * modos que ele liga, e devolver a lista com ele religa NO_ZERO_DATE e
 * NO_ZERO_IN_DATE no mesmo SET (medido no 10.11). Os outros modos dele ja
 * estao na lista um a um, entao o rigor que sobra e o mesmo.
 *
 * O RESTO FICA COMO O SERVIDOR QUER, e STRICT principalmente: ele recusa texto
 * em coluna numerica e data VAZIA gravada em coluna date, e isso e defeito de
 * verdade, nao dialeto. Tirar o STRICT mudaria o que toda instalacao em
 * MariaDB grava; tirar os modos daqui nao muda nada gravado, porque o painel
 * nao grava data zerada em lugar nenhum -- so compara com ela.
 */
function shield_sql_mode_compativel($modo)
{
    $fora = array('NO_ZERO_DATE', 'NO_ZERO_IN_DATE', 'ONLY_FULL_GROUP_BY', 'TRADITIONAL');
    $fica = array();
    foreach (explode(',', strtoupper((string) $modo)) as $parte) {
        $parte = trim($parte);
        if ($parte !== '' && !in_array($parte, $fora, true)) {
            $fica[] = $parte;
        }
    }

    return implode(',', $fica);
}

/**
 * Tira da SESSAO os modos de shield_sql_mode_compativel. true quando a sessao
 * fica sem eles (ou ja estava), false quando o servidor nao deixou.
 *
 * NUNCA LEVANTA EXCECAO: roda na abertura de toda conexao, inclusive a do caixa
 * da loja pedindo licenca. Servidor que recusa o SET fica como estava -- o que
 * nao compara com data zerada segue funcionando e a Central explica o resto --,
 * em vez de o painel inteiro cair por causa de um ajuste.
 *
 * So a leitura quando nao ha o que mudar, que e o caso das hospedagens em
 * MariaDB relaxado: uma ida ao banco por conexao, sem tabela e sem
 * INFORMATION_SCHEMA (documentacao do projeto, 4.2).
 */
function shield_pdo_ajustar_sql_mode(PDO $pdo)
{
    $atual = '';
    try {
        $atual = (string) $pdo->query('SELECT @@SESSION.sql_mode')->fetchColumn();
        if (preg_match('/(^|,)(NO_ZERO_DATE|NO_ZERO_IN_DATE|ONLY_FULL_GROUP_BY|TRADITIONAL)(,|$)/i', $atual) !== 1) {
            return true;
        }
        $pdo->exec('SET SESSION sql_mode = ' . $pdo->quote(shield_sql_mode_compativel($atual)));

        return true;
    } catch (Throwable $recusado) {
        // O MODO QUE FICOU VAI PARA A TELA (15/09/2026). Provado num MySQL 8 com o
        // SET negado: as listas que engolem excecao (Em avaliacao, pre-pagos,
        // contadores, carteira) mostravam zero sem aviso. Sem a leitura do modo
        // nao ha o que afirmar, e nada e marcado.
        if ($atual !== '') {
            shield_sql_mode_pendente($atual);
        }

        return false;
    }
}

/**
 * O sql_mode que a sessao nao conseguiu tirar nesta requisicao, ou ''. A
 * estrutura das telas pergunta aqui e avisa; passar um texto marca, passar ''
 * limpa (os testes).
 */
function shield_sql_mode_pendente($marcar = null)
{
    static $pendente = '';
    if ($marcar !== null) {
        $pendente = (string) $marcar;
    }

    return $pendente;
}

/**
 * O numero do erro do MySQL: do errorInfo do PDO e, na falta dele, do texto --
 * excecao relancada por outra camada perde o errorInfo e guarda so a frase, e a
 * frase e o que o membro manda por WhatsApp. 0 quando nao ha numero.
 */
function shield_banco_erro_codigo(Throwable $erro)
{
    $codigo = 0;
    if ($erro instanceof PDOException && is_array($erro->errorInfo) && isset($erro->errorInfo[1])) {
        $codigo = (int) $erro->errorInfo[1];
    }
    if ($codigo === 0 && preg_match('/SQLSTATE\[[0-9A-Z]{5}\]:[^:]*:\s*(\d{4})\b/', $erro->getMessage(), $m) === 1) {
        $codigo = (int) $m[1];
    }
    // A falha de CONEXAO tem outro formato: "SQLSTATE[HY000] [3159] ...".
    if ($codigo === 0 && preg_match('/SQLSTATE\[[0-9A-Z]{5}\]\s*\[(\d{4})\]/', $erro->getMessage(), $m) === 1) {
        $codigo = (int) $m[1];
    }

    return $codigo;
}

/**
 * O que fazer quando a CONEXAO falhou por TLS, ou '' -- 15/09/2026. Provado num
 * MySQL 8.4 com require_secure_transport=ON. A frase depende do que foi pedido:
 * o 3159 e de quem ainda nao marcou TLS; o 2002 de SSL e de quem marcou e o
 * certificado nao passou (CA errado, host com outro nome, autoassinado
 * conferido); e o servidor SEM TLS responde 2006 "gone away" a quem marcou,
 * frase que sozinha nao aponta para a caixa. Serve ao instalador e ao banco.php.
 */
function shield_banco_dica_conexao(Throwable $erro, array $config)
{
    $tipo = shield_banco_erro_tipo($erro);
    if ($tipo === 'tls') {
        return 'Este servidor so aceita conexao criptografada. Marque "Conexao criptografada (TLS)"'
            . ' (no config/database.php, \'ssl\' => true) e teste de novo.';
    }
    if ($tipo === 'tls_certificado') {
        return 'A conexao criptografada foi recusada pelo certificado do servidor: confira o caminho do CA, use no host o mesmo'
            . ' nome que esta no certificado, ou desmarque "Conferir o certificado" (\'ssl_verify\' => false) se ele for autoassinado.';
    }
    $pediuTls = !empty($config['ssl']) || trim((string) ($config['ssl_ca'] ?? '')) !== '';
    $codigo = shield_banco_erro_codigo($erro);
    if ($pediuTls && $codigo === 2006) {
        return 'O servidor nao oferece conexao criptografada: desmarque "Conexao criptografada (TLS)"'
            . ' (no config/database.php, \'ssl\' => false) e teste de novo.';
    }

    return shield_banco_dica_comum($codigo, $erro->getMessage(), (string) ($config['host'] ?? ''));
}

/**
 * O QUE PODE SER, para as falhas de conexao que mais chegam do grupo (16/10/2026).
 * A frase do driver ("2002 Operation not permitted") nao diz a quem pedir ajuda, e
 * o membro fica entre o painel e a hospedagem. Cada caso diz a causa provavel e o
 * que fazer; vazio quando o codigo nao e dos conhecidos -- frase inventada para
 * erro que nao se conhece confunde mais do que o erro cru.
 */
function shield_banco_dica_comum($codigo, $mensagem, $host = '')
{
    $codigo = (int) $codigo;
    $mensagem = (string) $mensagem;
    $local = in_array(strtolower(trim((string) $host)), array('localhost', ''), true);

    if ($codigo === 2002 && stripos($mensagem, 'Operation not permitted') !== false) {
        return 'A hospedagem barrou o PHP de abrir conexao com o banco (bloqueio de seguranca, como SELinux ou'
            . ' firewall, ou limite de conexoes/processos da conta). Se acontece so as vezes -- no meio de um envio, por'
            . ' exemplo --, e limite: tente de novo em alguns minutos e peca a hospedagem para conferir os limites da'
            . ' conta. Se acontece sempre, peca a hospedagem que libere a conexao do PHP ao MySQL'
            . ($local ? '; tambem vale trocar o host de "localhost" para "127.0.0.1" no config/database.php.' : '.');
    }
    if ($codigo === 2002 && stripos($mensagem, 'No such file or directory') !== false) {
        return 'O PHP procurou o banco pelo arquivo de socket local e nao achou. Troque o host de "localhost" para'
            . ' "127.0.0.1" no config/database.php, ou use o endereco do banco que a hospedagem informa.';
    }
    if (in_array($codigo, array(2002, 2003), true)
        && (stripos($mensagem, 'refused') !== false || stripos($mensagem, 'timed out') !== false)) {
        return 'O servidor do banco nao atendeu nesse endereco e porta. Confira o host e a porta no'
            . ' config/database.php (o painel da hospedagem mostra os dois) e se o MySQL esta no ar.';
    }
    if ($codigo === 2002 && (stripos($mensagem, 'getaddrinfo') !== false || stripos($mensagem, 'Name or service') !== false)) {
        return 'O nome do servidor do banco nao existe. Confira o host no config/database.php.';
    }
    if ($codigo === 1045) {
        return 'Usuario ou senha do banco recusados. Confira os dois no config/database.php. Se estiverem certos, o'
            . ' usuario pode nao ter permissao de entrar a partir deste servidor: no painel da hospedagem, de acesso'
            . ' do usuario ao banco.';
    }
    if ($codigo === 1044) {
        return 'O usuario entrou, mas nao tem permissao neste banco. No painel da hospedagem, associe o usuario ao'
            . ' banco com todos os privilegios.';
    }
    if ($codigo === 1049) {
        return 'O banco com esse nome nao existe. Confira o nome no config/database.php (na hospedagem costuma vir'
            . ' com um prefixo, como "conta_shield").';
    }
    if (in_array($codigo, array(1040, 1203, 1226), true)) {
        return 'O banco esta no limite de conexoes da conta. Costuma passar em alguns minutos; se repetir, peca a'
            . ' hospedagem para aumentar o limite (max_user_connections).';
    }
    if ($codigo === 1524) {
        return 'O usuario do banco foi criado com um metodo de senha que este MySQL nao aceita'
            . ' (mysql_native_password). Recrie o usuario pelo painel da hospedagem, sem escolher o metodo.';
    }
    if (in_array($codigo, array(2006, 2013), true)) {
        return 'A conexao com o banco caiu no meio. Costuma ser instabilidade da hospedagem: tente de novo; se'
            . ' repetir, peca a hospedagem para conferir o MySQL.';
    }

    return '';
}

/**
 * O tipo da falha de banco, para a tela dizer o que fazer: 'modo' quando o
 * erro e dos que o sql_mode da hospedagem provoca e o painel nao (1525, a data
 * zerada; 1055, o ONLY_FULL_GROUP_BY); 'tls' e 'tls_certificado' na conexao
 * (shield_banco_dica_conexao); '' para o resto. O 'modo' so chega a tela quando
 * o ajuste da conexao nao foi aceito.
 */
function shield_banco_erro_tipo(Throwable $erro)
{
    $codigo = shield_banco_erro_codigo($erro);

    // 3159: o servidor so aceita conexao criptografada. 2002/2026 falando de SSL:
    // o TLS foi tentado e o certificado nao passou. Medido no MySQL 8.4.
    if ($codigo === 3159) {
        return 'tls';
    }
    if (in_array($codigo, array(2002, 2026), true) && stripos($erro->getMessage(), 'SSL') !== false) {
        return 'tls_certificado';
    }

    if (in_array($codigo, array(1055, 1525), true)) {
        return 'modo';
    }

    // O 1292 SO E MODO QUANDO FALA DA DATA ZERADA (15/09/2026). Com o ajuste
    // recusado, os UPDATEs de validade e de avaliacao dao "1292 Incorrect date
    // value: '0000-00-00'" (medido no MySQL 8.0.45); 1292 de outra data e dado
    // errado de verdade, e a orientacao da hospedagem nao o resolveria.
    return $codigo === 1292 && strpos($erro->getMessage(), "'0000-00-00") !== false ? 'modo' : '';
}

function shield_split_sql_statements($sql)
{
    $length = strlen($sql);
    $statements = [];
    $buffer = '';
    $inSingle = false;
    $inDouble = false;
    $inBacktick = false;

    for ($i = 0; $i < $length; $i++) {
        $char = $sql[$i];
        $next = $i + 1 < $length ? $sql[$i + 1] : '';

        if (!$inSingle && !$inDouble && !$inBacktick) {
            if ($char === '-' && $next === '-') {
                $prev = $i > 0 ? $sql[$i - 1] : "\n";
                $third = $i + 2 < $length ? $sql[$i + 2] : '';
                if (ctype_space($prev) && ($third === '' || ctype_space($third))) {
                    while ($i < $length && $sql[$i] !== "\n") {
                        $i++;
                    }
                    continue;
                }
            }

            if ($char === '#') {
                while ($i < $length && $sql[$i] !== "\n") {
                    $i++;
                }
                continue;
            }

            if ($char === '/' && $next === '*') {
                $endPos = strpos($sql, '*/', $i + 2);
                if ($endPos === false) {
                    break;
                }
                $i = $endPos + 1;
                continue;
            }
        }

        if ($char === "'" && !$inDouble && !$inBacktick) {
            $escaped = $i > 0 && $sql[$i - 1] === '\\';
            if (!$escaped) {
                $inSingle = !$inSingle;
            }
            $buffer .= $char;
            continue;
        }

        if ($char === '"' && !$inSingle && !$inBacktick) {
            $escaped = $i > 0 && $sql[$i - 1] === '\\';
            if (!$escaped) {
                $inDouble = !$inDouble;
            }
            $buffer .= $char;
            continue;
        }

        if ($char === '`' && !$inSingle && !$inDouble) {
            $inBacktick = !$inBacktick;
            $buffer .= $char;
            continue;
        }

        if ($char === ';' && !$inSingle && !$inDouble && !$inBacktick) {
            $statement = trim($buffer);
            if ($statement !== '') {
                $statements[] = $statement;
            }
            $buffer = '';
            continue;
        }

        $buffer .= $char;
    }

    $tail = trim($buffer);
    if ($tail !== '') {
        $statements[] = $tail;
    }

    return $statements;
}

function shield_is_sql_control_statement($statement)
{
    return preg_match('/^(SET|START\s+TRANSACTION|COMMIT|LOCK\s+TABLES|UNLOCK\s+TABLES)\b/i', ltrim($statement)) === 1;
}

function shield_strip_utf8_bom($content)
{
    if (!is_string($content) || $content === '') {
        return '';
    }

    if (strncmp($content, "\xEF\xBB\xBF", 3) === 0) {
        return substr($content, 3);
    }

    return $content;
}

function shield_parse_baseline_schema($baselinePath)
{
    static $cache = [];

    if (isset($cache[$baselinePath])) {
        return $cache[$baselinePath];
    }

    if (!is_file($baselinePath)) {
        throw new RuntimeException('Arquivo de baseline nao encontrado: ' . $baselinePath);
    }

    $sql = file_get_contents($baselinePath);
    if ($sql === false) {
        throw new RuntimeException('Falha ao ler arquivo de baseline.');
    }
    $sql = shield_strip_utf8_bom($sql);

    $schema = [
        'table_order' => [],
        'tables' => [],
    ];

    $statements = shield_split_sql_statements($sql);
    foreach ($statements as $statement) {
        $statement = trim($statement);
        if ($statement === '' || shield_is_sql_control_statement($statement)) {
            continue;
        }

        if (preg_match('/^CREATE\s+TABLE\s+`?([a-zA-Z0-9_]+)`?/i', $statement, $matches)) {
            $table = strtolower($matches[1]);
            if (!isset($schema['tables'][$table])) {
                $schema['tables'][$table] = [
                    'name' => $matches[1],
                    'create' => null,
                    'alters' => [],
                    'inserts' => [],
                ];
                $schema['table_order'][] = $table;
            }
            $schema['tables'][$table]['create'] = $statement;
            continue;
        }

        if (preg_match('/^ALTER\s+TABLE\s+`?([a-zA-Z0-9_]+)`?/i', $statement, $matches)) {
            $table = strtolower($matches[1]);
            if (!isset($schema['tables'][$table])) {
                $schema['tables'][$table] = [
                    'name' => $matches[1],
                    'create' => null,
                    'alters' => [],
                    'inserts' => [],
                ];
                $schema['table_order'][] = $table;
            }
            $schema['tables'][$table]['alters'][] = $statement;
            continue;
        }

        if (preg_match('/^INSERT\s+INTO\s+`?([a-zA-Z0-9_]+)`?/i', $statement, $matches)) {
            $table = strtolower($matches[1]);
            if (!isset($schema['tables'][$table])) {
                $schema['tables'][$table] = [
                    'name' => $matches[1],
                    'create' => null,
                    'alters' => [],
                    'inserts' => [],
                ];
                $schema['table_order'][] = $table;
            }
            $schema['tables'][$table]['inserts'][] = $statement;
        }
    }

    $cache[$baselinePath] = $schema;
    return $schema;
}

function shield_required_baseline_tables($baselinePath)
{
    $schema = shield_parse_baseline_schema($baselinePath);
    return array_values(array_map(
        static function ($table) {
            return strtolower($table);
        },
        $schema['table_order']
    ));
}

/**
 * TABELAS DA BASELINE QUE UMA MIGRACAO DERRUBOU -- 17/09/2026. tabela => migracao.
 *
 * O BancoCompleto.sql nao pode perder o CREATE delas: migracao velha as altera
 * numa instalacao nova (a V2_0_2 converte o charset de `etiquetas`), e o 1146 nao
 * e tolerado. Mas a instalacao e o /update criam toda tabela da baseline que
 * falta, e o porteiro manda o painel para o /update enquanto faltar uma: sem esta
 * lista, a tabela derrubada prenderia o painel na tela de atualizacao e voltaria
 * vazia no clique seguinte.
 *
 * Vale so depois que a migracao que derruba rodou. Antes dela -- a instalacao nova
 * inteira, por exemplo -- a tabela e da baseline como qualquer outra.
 */
function shield_baseline_tabelas_que_sairam()
{
    return [
        'etiquetas' => 'V4_2_9__tabelas_que_ninguem_usava.sql',
    ];
}

/**
 * Das tabelas acima, as que ja sairam desta base: array(tabela minuscula => true).
 * Recebe o mapa de shield_fetch_applied_migrations, que quem chama ja tem.
 */
function shield_baseline_tabelas_derrubadas(array $aplicadas)
{
    $fora = [];
    foreach (shield_baseline_tabelas_que_sairam() as $tabela => $migracao) {
        $status = strtolower(trim((string) ($aplicadas[$migracao]['status'] ?? '')));
        if ($status === 'applied') {
            $fora[strtolower($tabela)] = true;
        }
    }

    return $fora;
}

function shield_existing_tables(PDO $pdo)
{
    $stmt = $pdo->query('SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE()');
    $tables = [];
    foreach ($stmt as $row) {
        $tables[] = strtolower($row['TABLE_NAME']);
    }
    return $tables;
}

function shield_table_exists(PDO $pdo, $tableName)
{
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table_name'
    );
    $stmt->execute(['table_name' => $tableName]);
    return (int) $stmt->fetchColumn() > 0;
}

function shield_prepare_insert_ignore($statement)
{
    return preg_replace('/^INSERT\s+INTO/i', 'INSERT IGNORE INTO', $statement, 1);
}

function shield_is_idempotent_sql_error(PDOException $exception)
{
    $driverCode = isset($exception->errorInfo[1]) ? (int) $exception->errorInfo[1] : 0;
    $nonFatalCodes = [1050, 1060, 1061, 1062, 1091, 1826];
    return in_array($driverCode, $nonFatalCodes, true);
}

function shield_sync_missing_baseline_tables(PDO $pdo, $baselinePath, array &$logs = [])
{
    $schema = shield_parse_baseline_schema($baselinePath);
    $existing = array_flip(shield_existing_tables($pdo));
    // A que uma migracao ja derrubou nao volta (shield_baseline_tabelas_que_sairam).
    $derrubadas = shield_baseline_tabelas_derrubadas(
        isset($existing['shield_migrations']) ? shield_fetch_applied_migrations($pdo) : []
    );
    $createdTables = [];
    $createdCount = 0;

    foreach ($schema['table_order'] as $tableKey) {
        $tableConfig = $schema['tables'][$tableKey];
        $tableName = $tableConfig['name'];
        if (isset($existing[strtolower($tableName)]) || isset($derrubadas[strtolower($tableName)])) {
            continue;
        }

        if (empty($tableConfig['create'])) {
            $logs[] = ['level' => 'warning', 'message' => 'Tabela sem CREATE no baseline: ' . $tableName];
            continue;
        }

        $logs[] = ['level' => 'info', 'message' => 'Criando tabela ausente: ' . $tableName];
        $pdo->exec($tableConfig['create']);
        $createdCount++;
        $createdTables[] = $tableName;

        foreach ($tableConfig['alters'] as $alterStatement) {
            try {
                $pdo->exec($alterStatement);
            } catch (PDOException $exception) {
                if (shield_is_idempotent_sql_error($exception)) {
                    $logs[] = [
                        'level' => 'warning',
                        'message' => 'ALTER ignorado por idempotencia em ' . $tableName . ': ' . $exception->getMessage(),
                    ];
                    continue;
                }
                throw $exception;
            }
        }

        foreach ($tableConfig['inserts'] as $insertStatement) {
            $insertIgnore = shield_prepare_insert_ignore($insertStatement);
            try {
                $pdo->exec($insertIgnore);
            } catch (PDOException $exception) {
                if (shield_is_idempotent_sql_error($exception)) {
                    $logs[] = [
                        'level' => 'warning',
                        'message' => 'INSERT ignorado por idempotencia em ' . $tableName . ': ' . $exception->getMessage(),
                    ];
                    continue;
                }
                throw $exception;
            }
        }

        $existing[strtolower($tableName)] = true;
    }

    return [
        'created_count' => $createdCount,
        'created_tables' => $createdTables,
    ];
}

function shield_ensure_version_tables(PDO $pdo)
{
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS shield_system_meta (
            meta_key VARCHAR(100) NOT NULL PRIMARY KEY,
            meta_value TEXT NOT NULL,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS shield_migrations (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            migration_version VARCHAR(20) NOT NULL,
            filename VARCHAR(255) NOT NULL,
            checksum CHAR(64) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'applied',
            log_text TEXT NULL,
            executed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_filename (filename)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci"
    );
}

/* A cor de fabrica da marca, e a que ela substituiu.
 *
 * Sao DUAS constantes porque a reconciliacao do /update precisa saber nao so
 * para onde ir, mas de onde: ela troca a cor gravada SO quando o valor no banco
 * ainda e exatamente o azul antigo -- quem escolheu a propria cor mantem a
 * dela. Sem o valor antigo nomeado, esse "so quando" vira um literal solto no
 * meio do atualizador.
 *
 * O padrao NAO e o ciano puro #02c8f0: ciano com letra branca da 2,00:1, e a
 * norma da marca diz que sobre o ciano o texto e sempre grafite. Quem preenche
 * botao em fundo claro e o ciano-texto; o ciano puro so aparece como acento
 * sobre escuro (--marca-clara em public/css/painel.css).
 */
if (!defined('SHIELD_MARCA_COR_PADRAO')) {
    define('SHIELD_MARCA_COR_PADRAO', '#00697f');
}
if (!defined('SHIELD_MARCA_COR_FABRICA_ANTIGA')) {
    define('SHIELD_MARCA_COR_FABRICA_ANTIGA', '#1a6fb8');
}

function shield_set_system_meta(PDO $pdo, $key, $value)
{
    $stmt = $pdo->prepare(
        'INSERT INTO shield_system_meta (meta_key, meta_value) VALUES (:meta_key, :meta_value)
         ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value)'
    );
    $stmt->execute([
        'meta_key' => $key,
        'meta_value' => (string) $value,
    ]);
}

function shield_get_system_meta(PDO $pdo, $key, $default = '')
{
    if (!shield_table_exists($pdo, 'shield_system_meta')) {
        return $default;
    }

    $stmt = $pdo->prepare('SELECT meta_value FROM shield_system_meta WHERE meta_key = :meta_key LIMIT 1');
    $stmt->execute(['meta_key' => $key]);
    $value = $stmt->fetchColumn();
    return $value === false ? $default : $value;
}

function shield_parse_migration_filename($filename)
{
    if (!preg_match('/^V(\d+)_(\d+)_(\d+)__([a-zA-Z0-9_\-]+)\.sql$/', $filename, $matches)) {
        return null;
    }

    $major = (int) $matches[1];
    $minor = (int) $matches[2];
    $patch = (int) $matches[3];

    return [
        'major' => $major,
        'minor' => $minor,
        'patch' => $patch,
        'version' => $major . '.' . $minor . '.' . $patch,
        'slug' => $matches[4],
    ];
}

function shield_list_migrations($migrationsDir)
{
    if (!is_dir($migrationsDir)) {
        return [];
    }

    $files = scandir($migrationsDir);
    if ($files === false) {
        return [];
    }

    $migrations = [];
    foreach ($files as $file) {
        if ($file === '.' || $file === '..') {
            continue;
        }

        $fullPath = $migrationsDir . DIRECTORY_SEPARATOR . $file;
        if (!is_file($fullPath)) {
            continue;
        }

        $parts = shield_parse_migration_filename($file);
        if ($parts === null) {
            continue;
        }

        $migrations[] = [
            'filename' => $file,
            'path' => $fullPath,
            'version' => $parts['version'],
            'major' => $parts['major'],
            'minor' => $parts['minor'],
            'patch' => $parts['patch'],
            'checksum' => shield_migration_checksum($fullPath),
            // As contas byte a byte de antes. Ficam so para reconhecer o que as
            // bases em campo ja tem gravado -- ver shield_migration_checksum.
            'checksum_legado' => shield_migration_checksums_legado($fullPath),
        ];
    }

    usort(
        $migrations,
        static function (array $a, array $b) {
            return [$a['major'], $a['minor'], $a['patch'], $a['filename']]
                <=> [$b['major'], $b['minor'], $b['patch'], $b['filename']];
        }
    );

    return $migrations;
}

function shield_fetch_applied_migrations(PDO $pdo)
{
    if (!shield_table_exists($pdo, 'shield_migrations')) {
        return [];
    }

    $rows = $pdo->query(
        'SELECT migration_version, filename, checksum, status, executed_at FROM shield_migrations ORDER BY id ASC'
    )->fetchAll(PDO::FETCH_ASSOC);

    $map = [];
    foreach ($rows as $row) {
        $map[$row['filename']] = $row;
    }
    return $map;
}

// O checksum e da migracao NORMALIZADA em LF - 25/08/2026.
//
// Era hash_file() puro, byte a byte, e por isso a quebra de linha entrava na
// conta: bastava um cliente de FTP em modo ASCII, um editor ou um checkout com
// autocrlf tocar num .sql ja aplicado para o painel INTEIRO parar -- toda rota
// passa a redirecionar para /update/, que responde "Checksum divergente" e nao
// deixa passar. Nada mudou no SQL; mudou o \r.
//
// NAO voltar para hash_file: o conteudo e que precisa ser o mesmo, nao os bytes.
function shield_migration_checksum($caminho)
{
    $conteudo = file_get_contents($caminho);
    if ($conteudo === false) {
        return '';
    }

    return hash('sha256', str_replace(array("\r\n", "\r"), "\n", $conteudo));
}

// Confere o que esta gravado contra a conta nova E contra a antiga. Base que
// ja rodava antes desta mudanca tem a antiga gravada e continua valendo: quem
// a atualiza e o shield_run_pending_migrations, quando passa por ela.
function shield_migration_checksums_legado($caminho)
{
    $conteudo = file_get_contents($caminho);
    if ($conteudo === false) {
        return array();
    }

    $lf = str_replace(array("
", "
"), "
", $conteudo);

    // Como esta, tudo em LF e tudo em CRLF: sao as tres formas em que o mesmo
    // arquivo pode ter sido somado antes, conforme quem o gravou por ultimo.
    return array_values(array_unique(array(
        hash('sha256', $conteudo),
        hash('sha256', $lf),
        hash('sha256', str_replace("
", "
", $lf)),
    )));
}

function shield_migration_checksum_confere($gravado, array $migration)
{
    $gravado = (string) $gravado;

    if ($gravado === (string) ($migration['checksum'] ?? '')) {
        return true;
    }

    return in_array($gravado, (array) ($migration['checksum_legado'] ?? array()), true);
}

function shield_record_migration(PDO $pdo, array $migration, $status, $logText = null)
{
    $stmt = $pdo->prepare(
        'INSERT INTO shield_migrations (migration_version, filename, checksum, status, log_text)
         VALUES (:migration_version, :filename, :checksum, :status, :log_text)
         ON DUPLICATE KEY UPDATE
            migration_version = VALUES(migration_version),
            checksum = VALUES(checksum),
            status = VALUES(status),
            log_text = VALUES(log_text),
            executed_at = CURRENT_TIMESTAMP'
    );

    $stmt->execute([
        'migration_version' => $migration['version'],
        'filename' => $migration['filename'],
        'checksum' => $migration['checksum'],
        'status' => $status,
        'log_text' => $logText,
    ]);
}

/**
 * A ultima linha de erro do log, para a faixa da tela. Vazio nunca acontece na
 * pratica (quem falha sempre registra), mas a frase generica volta se acontecer:
 * faixa sem texto nenhum seria pior do que a de antes.
 */
function shield_ultimo_erro_do_log(array $logs)
{
    for ($i = count($logs) - 1; $i >= 0; $i--) {
        if ((string) ($logs[$i]['level'] ?? '') === 'error') {
            return (string) $logs[$i]['message'];
        }
    }

    return 'o banco recusou, e o motivo esta no "Log da Atualizacao", no fim desta tela.';
}

function shield_execute_migration_file(PDO $pdo, array $migration, array &$logs)
{
    $sql = file_get_contents($migration['path']);
    if ($sql === false) {
        $message = 'Nao foi possivel ler migracao: ' . $migration['filename'];
        shield_record_migration($pdo, $migration, 'failed', $message);
        $logs[] = ['level' => 'error', 'message' => $message];
        return false;
    }
    $sql = shield_strip_utf8_bom($sql);

    $statements = shield_split_sql_statements($sql);
    $statements = array_values(array_filter(
        $statements,
        static function ($statement) {
            $statement = trim($statement);
            return $statement !== '' && !shield_is_sql_control_statement($statement);
        }
    ));

    $transactionStarted = false;
    try {
        if (!$pdo->inTransaction()) {
            $pdo->beginTransaction();
            $transactionStarted = true;
        }
    } catch (Throwable $ignored) {
        $transactionStarted = false;
    }

    try {
        foreach ($statements as $statement) {
            try {
                $pdo->exec($statement);
            } catch (PDOException $exception) {
                if (shield_is_idempotent_sql_error($exception)) {
                    $logs[] = [
                        'level' => 'warning',
                        'message' => 'Aviso de idempotencia em ' . $migration['filename'] . ': ' . $exception->getMessage(),
                    ];
                    continue;
                }
                throw $exception;
            }
        }

        shield_record_migration($pdo, $migration, 'applied');
        if ($transactionStarted && $pdo->inTransaction()) {
            $pdo->commit();
        }
        $logs[] = ['level' => 'success', 'message' => 'Migracao aplicada: ' . $migration['filename']];
        return true;
    } catch (Throwable $exception) {
        if ($transactionStarted && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        shield_record_migration($pdo, $migration, 'failed', $exception->getMessage());
        $logs[] = [
            'level' => 'error',
            'message' => 'Falha na migracao ' . $migration['filename'] . ': ' . $exception->getMessage(),
        ];
        return false;
    }
}

function shield_run_migrations(PDO $pdo, $migrationsDir, array &$logs = [])
{
    shield_ensure_version_tables($pdo);
    $migrations = shield_list_migrations($migrationsDir);
    $applied = shield_fetch_applied_migrations($pdo);

    $appliedCount = 0;
    $skippedCount = 0;
    $checksumWarnings = [];
    $latestVersion = shield_get_system_meta($pdo, 'db_version', '0.0.0');

    foreach ($migrations as $migration) {
        $filename = $migration['filename'];

        if (isset($applied[$filename])) {
            $existing = $applied[$filename];
            $existingStatus = strtolower(trim((string) ($existing['status'] ?? '')));
            $existingChecksum = (string) ($existing['checksum'] ?? '');
            $currentChecksum = (string) $migration['checksum'];

            if ($existingStatus === 'applied') {
                if (!shield_migration_checksum_confere($existingChecksum, $migration)) {
                    // AVISO, e nao parada. A migracao ja rodou -- o que mudou
                    // foi o arquivo, depois. Antes isto abortava a rodada
                    // inteira, entao um .sql antigo tocado por um cliente de
                    // FTP em modo ASCII trancava TODA migracao futura, para
                    // sempre, e o painel passava a redirecionar tudo para
                    // /update/ -- que respondia com este mesmo erro e nao
                    // deixava passar. Punia o alvo errado.
                    //
                    // NAO transformar de volta em erro: a deteccao continua
                    // aqui, alta, e quem precisa dela e quem edita migracao
                    // aplicada -- nao quem so quer receber a proxima.
                    $checksumWarnings[] = $filename;
                    $logs[] = [
                        'level' => 'warning',
                        'message' => 'Migracao ja aplicada com checksum diferente do arquivo atual: '
                            . $filename . '. Ela nao roda de novo; corrija com uma migracao NOVA.',
                    ];
                }

                if ($existingChecksum !== $currentChecksum) {
                    // Bateu pela conta antiga: regrava na nova, uma vez so.
                    shield_record_migration($pdo, $migration, 'applied',
                        'Checksum regravado no formato normalizado em LF.');
                }

                $skippedCount++;
                $latestVersion = $migration['version'];
                continue;
            }

            if ($existingChecksum !== $currentChecksum) {
                $logs[] = [
                    'level' => 'warning',
                    'message' => 'Checksum divergente em migracao com status nao aplicado (' . $filename . '). Reprocessando.',
                ];
            }
        }

        if (!shield_execute_migration_file($pdo, $migration, $logs)) {
            // A CAUSA VAI NA FAIXA VERMELHA -- 24/09/2026, membro na instalacao.
            // Ela dizia so "Falha ao aplicar migracoes.", e o motivo do banco
            // (tabela que nao existe, coluna que falta, privilegio negado) ficava
            // la embaixo, no "Log da Atualizacao", fora da tela. Sem ele nao da
            // para dizer nem se o defeito e do pacote ou da base do membro, e o
            // print que ele manda no grupo sempre corta antes do log.
            return [
                'success' => false,
                'applied_count' => $appliedCount,
                'skipped_count' => $skippedCount,
                'latest_version' => $latestVersion,
                'error' => 'Falha ao aplicar migracoes: ' . shield_ultimo_erro_do_log($logs),
            ];
        }

        $appliedCount++;
        $latestVersion = $migration['version'];
    }

    if (empty($migrations) && $latestVersion === '') {
        $latestVersion = '0.0.0';
    }

    shield_set_system_meta($pdo, 'db_version', $latestVersion);
    shield_set_system_meta($pdo, 'last_update_at', date('c'));

    return [
        'success' => true,
        'applied_count' => $appliedCount,
        'skipped_count' => $skippedCount,
        'latest_version' => $latestVersion,
        'checksum_warnings' => $checksumWarnings,
        'error' => null,
    ];
}

function shield_detect_pending_updates(PDO $pdo, $baselinePath, $migrationsDir)
{
    $requiredTables = shield_required_baseline_tables($baselinePath);
    $existingTables = shield_existing_tables($pdo);
    $existingMap = array_flip($existingTables);

    // Este caminho roda em TODA requisicao (o porteiro): as migracoes aplicadas
    // sao lidas uma vez, e so quando a tabela delas ja veio na lista acima.
    $temTabelaDeMigracoes = isset($existingMap['shield_migrations']);
    $applied = $temTabelaDeMigracoes ? shield_fetch_applied_migrations($pdo) : [];
    $derrubadas = shield_baseline_tabelas_derrubadas($applied);

    $missingTables = [];
    foreach ($requiredTables as $requiredTable) {
        $minuscula = strtolower($requiredTable);
        if (!isset($existingMap[$minuscula]) && !isset($derrubadas[$minuscula])) {
            $missingTables[] = $requiredTable;
        }
    }

    $migrations = shield_list_migrations($migrationsDir);
    $pendingMigrations = [];
    $checksumErrors = [];

    if (!empty($migrations)) {
        if (!$temTabelaDeMigracoes) {
            foreach ($migrations as $migration) {
                $pendingMigrations[] = $migration['filename'];
            }
        } else {
            foreach ($migrations as $migration) {
                $filename = $migration['filename'];
                if (!isset($applied[$filename])) {
                    $pendingMigrations[] = $filename;
                    continue;
                }

                $existingStatus = strtolower(trim((string) ($applied[$filename]['status'] ?? '')));
                if ($existingStatus !== 'applied') {
                    $pendingMigrations[] = $filename;
                    continue;
                }

                if (!shield_migration_checksum_confere($applied[$filename]['checksum'], $migration)) {
                    $checksumErrors[] = $filename;
                }
            }
        }
    }

    return [
        // O checksum divergente NAO entra mais nesta conta. Ele e um aviso
        // sobre uma migracao que JA rodou; deixa-lo aqui fazia o painel
        // inteiro redirecionar para /update/ para sempre por causa de um
        // arquivo antigo que alguem tocou -- e /update/ recusava, entao nao
        // havia saida. Ele continua saindo em checksum_errors, e a tela de
        // atualizacao o mostra.
        'needs_update' => !empty($missingTables) || !empty($pendingMigrations),
        'missing_tables' => $missingTables,
        'pending_migrations' => $pendingMigrations,
        'checksum_errors' => $checksumErrors,
    ];
}

function shield_ini_to_bytes($value)
{
    if ($value === '' || $value === null) {
        return 0;
    }

    $value = trim((string) $value);
    $last = strtolower(substr($value, -1));
    $number = (float) $value;

    switch ($last) {
        case 'g':
            $number *= 1024;
        case 'm':
            $number *= 1024;
        case 'k':
            $number *= 1024;
    }

    return (int) $number;
}

function shield_collect_environment_diagnostics(?array $dbConfig = null, ?PDO $pdo = null)
{
    $appConfig = shield_load_app_config();
    $minPhp = (string) ($appConfig['php_min_version'] ?? '8.2.0');
    $recommendedPhp = (string) ($appConfig['php_recommended_version'] ?? '8.4.0');
    $currentPhp = PHP_VERSION;

    $items = [];
    $hasCriticalFailure = false;

    $phpStatus = 'PASS';
    if (version_compare($currentPhp, $minPhp, '<')) {
        $phpStatus = 'FAIL';
        $hasCriticalFailure = true;
    } elseif (version_compare($currentPhp, $recommendedPhp, '<')) {
        $phpStatus = 'WARN';
    }
    $items[] = [
        'label' => 'PHP',
        'current' => $currentPhp,
        'required' => 'min ' . $minPhp . ' / recomendado ' . $recommendedPhp,
        'status' => $phpStatus,
        'critical' => true,
    ];

    // Sem mysqli desde 17/09/2026: o banco.php so abre o PDO.
    $requiredExtensions = ['pdo', 'pdo_mysql', 'curl', 'json', 'mbstring', 'openssl', 'fileinfo', 'simplexml'];
    foreach ($requiredExtensions as $extension) {
        $loaded = extension_loaded($extension);
        if (!$loaded) {
            $hasCriticalFailure = true;
        }
        $items[] = [
            'label' => 'Extensao: ' . $extension,
            'current' => $loaded ? 'carregada' : 'ausente',
            'required' => 'obrigatoria',
            'status' => $loaded ? 'PASS' : 'FAIL',
            'critical' => true,
        ];
    }

    $availablePdoDrivers = class_exists('PDO') ? PDO::getAvailableDrivers() : [];
    $hasMysqlDriver = in_array('mysql', $availablePdoDrivers, true);
    if (!$hasMysqlDriver) {
        $hasCriticalFailure = true;
    }
    $items[] = [
        'label' => 'PDO drivers',
        'current' => empty($availablePdoDrivers) ? 'nenhum' : implode(', ', $availablePdoDrivers),
        'required' => 'mysql',
        'status' => $hasMysqlDriver ? 'PASS' : 'FAIL',
        'critical' => true,
    ];

    $memoryLimit = ini_get('memory_limit');
    $memoryBytes = shield_ini_to_bytes($memoryLimit);
    $memoryStatus = $memoryBytes > 0 && $memoryBytes < 134217728 ? 'WARN' : 'PASS';
    $items[] = [
        'label' => 'memory_limit',
        'current' => (string) $memoryLimit,
        'required' => '>= 128M recomendado',
        'status' => $memoryStatus,
        'critical' => false,
    ];

    $maxExecution = (int) ini_get('max_execution_time');
    $executionStatus = $maxExecution > 0 && $maxExecution < 30 ? 'WARN' : 'PASS';
    $items[] = [
        'label' => 'max_execution_time',
        'current' => (string) $maxExecution,
        'required' => '>= 30 recomendado',
        'status' => $executionStatus,
        'critical' => false,
    ];

    $items[] = [
        'label' => 'post_max_size',
        'current' => (string) ini_get('post_max_size'),
        'required' => 'ajustar conforme ambiente',
        'status' => 'PASS',
        'critical' => false,
    ];

    $items[] = [
        'label' => 'upload_max_filesize',
        'current' => (string) ini_get('upload_max_filesize'),
        'required' => 'ajustar conforme ambiente',
        'status' => 'PASS',
        'critical' => false,
    ];

    $items[] = [
        'label' => 'timezone',
        'current' => (string) date_default_timezone_get(),
        'required' => 'definido',
        'status' => date_default_timezone_get() ? 'PASS' : 'WARN',
        'critical' => false,
    ];

    $items[] = [
        'label' => 'Horario servidor',
        'current' => date('Y-m-d H:i:s'),
        'required' => 'sincronizado',
        'status' => 'PASS',
        'critical' => false,
    ];

    $openBasedir = (string) ini_get('open_basedir');
    $items[] = [
        'label' => 'open_basedir',
        'current' => $openBasedir !== '' ? $openBasedir : 'nao definido',
        'required' => 'nao bloquear pastas do sistema',
        'status' => 'PASS',
        'critical' => false,
    ];

    $checkPaths = [
        shield_config_dir() => 'config/',
        // As duas moram em public/ desde que o docroot desceu para la: elas sao
        // TELA, e tela e a unica coisa que fica dentro do que o Apache serve.
        // Enquanto estas linhas mediam a raiz, o diagnostico dava "inexistente"
        // nas duas, marcava has_critical_failures e o update/index.php recusava
        // rodar migracao -- o painel se trancava por fora.
        shield_root_path() . DIRECTORY_SEPARATOR . 'public'
            . DIRECTORY_SEPARATOR . 'install' => 'public/install/',
        shield_root_path() . DIRECTORY_SEPARATOR . 'public'
            . DIRECTORY_SEPARATOR . 'update' => 'public/update/',
    ];
    foreach ($checkPaths as $path => $label) {
        $exists = is_dir($path);
        $writable = $exists && is_writable($path);
        $status = $writable ? 'PASS' : 'FAIL';
        if (!$writable) {
            $hasCriticalFailure = true;
        }
        $items[] = [
            'label' => 'Permissao de escrita: ' . $label,
            'current' => $exists ? ($writable ? 'ok' : 'sem permissao') : 'inexistente',
            'required' => 'gravacao obrigatoria',
            'status' => $status,
            'critical' => true,
        ];
    }

    if ($pdo !== null) {
        try {
            $dbVersion = (string) $pdo->query('SELECT VERSION()')->fetchColumn();
            $items[] = [
                'label' => 'Banco de dados',
                'current' => $dbVersion !== '' ? $dbVersion : 'conectado',
                'required' => 'conexao ativa',
                'status' => 'PASS',
                'critical' => true,
            ];
        } catch (Throwable $exception) {
            $items[] = [
                'label' => 'Banco de dados',
                'current' => 'erro ao consultar versao',
                'required' => 'conexao ativa',
                'status' => 'WARN',
                'critical' => false,
            ];
        }
    } else {
        $items[] = [
            'label' => 'Banco de dados',
            'current' => 'nao conectado',
            'required' => 'conexao ativa para instalar/atualizar',
            'status' => 'WARN',
            'critical' => false,
        ];
    }

    if ($dbConfig !== null) {
        $configured = shield_is_database_configured($dbConfig);
        $items[] = [
            'label' => 'Config banco',
            'current' => $configured ? 'preenchida' : 'incompleta',
            'required' => 'host/database/username',
            'status' => $configured ? 'PASS' : 'WARN',
            'critical' => false,
        ];
    }

    return [
        'items' => $items,
        'has_critical_failures' => $hasCriticalFailure,
    ];
}

function shield_has_admin_user(PDO $pdo)
{
    if (!shield_table_exists($pdo, 'usuario')) {
        return false;
    }

    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM usuario WHERE TRIM(acesso) = '1'");
        return (int) $stmt->fetchColumn() > 0;
    } catch (Throwable $exception) {
        return false;
    }
}

function shield_has_softhouse(PDO $pdo)
{
    if (!shield_table_exists($pdo, 'softhouse')) {
        return false;
    }

    try {
        $stmt = $pdo->query('SELECT COUNT(*) FROM softhouse');
        return (int) $stmt->fetchColumn() > 0;
    } catch (Throwable $exception) {
        return false;
    }
}

function shield_is_first_access_completed(PDO $pdo)
{
    return trim((string) shield_get_system_meta($pdo, 'first_access_completed', '0')) === '1';
}

function shield_is_first_access_admin_completed(PDO $pdo)
{
    return trim((string) shield_get_system_meta($pdo, 'first_access_admin_completed', '0')) === '1';
}

function shield_mark_first_access_completed(PDO $pdo)
{
    if (!shield_table_exists($pdo, 'shield_system_meta')) {
        throw new RuntimeException('Tabela shield_system_meta nao encontrada para marcar primeiro acesso.');
    }

    shield_set_system_meta($pdo, 'first_access_completed', '1');
    shield_set_system_meta($pdo, 'first_access_completed_at', date('c'));
}

function shield_requires_first_access_setup(PDO $pdo)
{
    return !shield_has_admin_user($pdo)
        || !shield_is_first_access_completed($pdo);
}

function shield_enforce_installation_guard()
{
    if (PHP_SAPI === 'cli') {
        return;
    }

    $path = shield_current_request_path();
    if (shield_guard_skip_path($path)) {
        return;
    }

    // Quem e programa nao recebe 302 para tela nenhuma: recebe 503 em JSON e
    // volta depois (shield_guard_servico_json / shield_guard_parar).
    $servico = shield_guard_servico_json($path);

    $appConfig = shield_load_app_config();
    $alreadyInstalled = !empty($appConfig['installed']);

    $dbConfig = shield_load_database_config();
    $dbConfigured = shield_is_database_configured($dbConfig);

    if (!$alreadyInstalled || !$dbConfigured) {
        shield_guard_parar($servico, '/install/', 'instalacao_incompleta');
    }

    try {
        $pdo = shield_create_pdo_connection($dbConfig);
    } catch (Throwable $exception) {
        shield_guard_parar($servico, '/install/?error=db_connection', 'sem_banco');
    }

    // O /update/ passou a exigir administrador logado (08/09/2026). Se o login
    // tambem viesse para ca, a tela que DA a sessao ficaria atras da tela que
    // EXIGE a sessao e ninguem conseguiria autorizar a propria atualizacao --
    // o painel se trancaria por fora na primeira migracao nova.
    require_once __DIR__ . '/update_guarda.php';
    $dispensado = shield_update_login_dispensado($path);

    try {
        $pending = shield_detect_pending_updates($pdo, shield_baseline_sql_path(), shield_migrations_dir());
        if (!empty($pending['needs_update']) && !$dispensado) {
            shield_guard_parar($servico, '/update/', 'atualizacao_pendente');
        }
    } catch (Throwable $exception) {
        if (!$dispensado) {
            shield_guard_parar($servico, '/update/?error=pending_check', 'atualizacao_pendente');
        }
    }

    if (shield_requires_first_access_setup($pdo)) {
        shield_guard_parar($servico, '/install/setup.php', 'primeiro_acesso');
    }
}
