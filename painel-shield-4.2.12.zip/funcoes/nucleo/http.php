<?php

if (!function_exists('shield_build_url')) {
    function shield_build_url($basePath, array $params = [])
    {
        $filtered = [];
        foreach ($params as $key => $value) {
            if ($value === null || $value === '') {
                continue;
            }
            $filtered[$key] = $value;
        }

        $query = http_build_query($filtered);
        return (string) $basePath . ($query !== '' ? ('?' . $query) : '');
    }
}

if (!function_exists('shield_resposta_encerrar')) {
    /**
     * Entrega a resposta ao cliente e deixa o script seguir trabalhando.
     *
     * Serve a um caso so, e vale dizer qual: ha trabalho cujo TEMPO nao pode
     * ser observado de fora. O "esqueci a senha" e o exemplo -- o envio do
     * e-mail so acontece quando a conta existe, e um SMTP de vinte segundos
     * contra um SELECT de milissegundos entrega, pelo relogio, a lista de quem
     * tem acesso ao painel.
     *
     * NAO E IGUAL NOS DOIS SAPIs, e nao adianta fingir que e:
     *
     *   PHP-FPM  -- fastcgi_finish_request() fecha a conexao de verdade. O
     *               tempo total que o cliente mede passa a ser so o da pagina.
     *   mod_php  -- nao existe equivalente. Esvaziar os buffers entrega os
     *               bytes na hora, entao o tempo ate o PRIMEIRO byte para de
     *               depender do que vem depois; a conexao, porem, so fecha
     *               quando o script termina, e quem cronometrar a resposta
     *               inteira ainda ve diferenca. E menos vazamento, nao zero.
     *
     * SEM Content-Length de proposito. Ele fecharia a conexao tambem no
     * mod_php, mas teria de ser medido antes do filtro de saida do CSRF, que
     * acrescenta bytes depois -- um numero curto trunca a pagina no navegador.
     * Pagina certa chegando devagar e melhor que pagina cortada chegando
     * rapido.
     *
     * @return bool true quando a conexao foi realmente fechada
     */
    function shield_resposta_encerrar()
    {
        @ignore_user_abort(true);

        if (function_exists('fastcgi_finish_request')) {
            @fastcgi_finish_request();

            return true;
        }

        while (ob_get_level() > 0) {
            @ob_end_flush();
        }
        @flush();

        return false;
    }
}
