<?php

// O portao do /update/ -- 08/09/2026.
//
// Ate esta data a tela de update nao perguntava nada a ninguem: um GET anonimo
// em /update/ aplicava migracao, criava tabela ausente, convertia conta de
// recebimento e reescrevia o config/app.php. Era a rota mais poderosa do
// painel, e a unica sem porta.
//
// A regra mora aqui, e nao dentro da tela, por dois motivos. O primeiro e que
// a tela sao 293 linhas de HTML com a decisao no meio -- foi assim que o
// buraco passou despercebido em duas leituras. O segundo e que regra de
// autorizacao sem teste e so uma intencao.
//
// NAO ENTROU no system_bootstrap.php de proposito: aquele arquivo e o tronco
// que todas as sessoes disputam, e este conserto nao precisa
// dele.

/**
 * Quem pode mandar o /update/ APLICAR. Devolve ['pode' => bool, 'motivo' => string].
 *
 * $temAdmin vem de shield_has_admin_user(): existe alguem com acesso '1' no
 * banco? $sessao e o $_SESSION.
 *
 * A JANELA DA INSTALACAO e o caso que nao se pode fechar por engano: enquanto
 * nao existe administrador nao ha a quem pedir sessao, e e exatamente quando o
 * /update/ precisa rodar -- o instalador termina redirecionando para ca. Ela
 * fecha sozinha assim que o primeiro administrador nasce.
 *
 * O instalador que ACABOU de criar o administrador cai num terceiro caso: ja
 * ha admin, ainda nao houve login. Para esse, ele mesmo marca a sessao antes
 * de redirecionar -- liberacao explicita, com nome, e nao um "vai que da
 * certo" deduzido do referer ou do relogio.
 */
function shield_update_pode_aplicar($temAdmin, array $sessao)
{
    if (!empty($sessao['shield_update_liberado'])) {
        return array('pode' => true, 'motivo' => 'janela_instalacao');
    }

    if (!$temAdmin) {
        return array('pode' => true, 'motivo' => 'janela_instalacao');
    }

    if ((string) ($sessao['usuario']['login'] ?? '') === '') {
        return array('pode' => false, 'motivo' => 'precisa_login');
    }

    // TRIM porque e assim que o painel decide quem e administrador no banco
    // (shield_has_admin_user: "WHERE TRIM(acesso) = '1'"). Espaco na coluna
    // nao pode rebaixar o administrador so aqui.
    if (trim((string) ($sessao['usuario']['acesso'] ?? '')) !== '1') {
        return array('pode' => false, 'motivo' => 'sem_permissao');
    }

    return array('pode' => true, 'motivo' => 'sessao_admin');
}

/**
 * O item de diagnostico que diz para onde o Apache esta apontando.
 *
 * AVISA, NAO TRANCA -- 'critical' e sempre false, e isso e desenho, nao
 * descuido. Item critico bloqueia a atualizacao inteira, e ja aconteceu neste
 * mesmo diagnostico: enquanto a conferencia de escrita media a raiz em vez de
 * public/, ela marcava falha critica e "o painel se trancava por fora"
 * (system_bootstrap.php:1233-1237). Quem esta com o DocumentRoot na raiz e
 * justamente quem mais precisa conseguir atualizar -- travar seria prender a
 * pessoa do lado errado da porta.
 *
 * Sem DOCUMENT_ROOT (CLI, cron) nao se afere: nao aferir nao e estar errado.
 */
function shield_docroot_item($docrootAtual, $publicEsperado)
{
    $normalizar = static function ($caminho) {
        return rtrim(str_replace('\\', '/', trim((string) $caminho)), '/');
    };

    $atual = $normalizar($docrootAtual);
    $esperado = $normalizar($publicEsperado);

    $item = array(
        'label' => 'DocumentRoot do servidor',
        'current' => $atual === '' ? 'nao informado (CLI/cron)' : $atual,
        'required' => $esperado === '' ? 'a pasta public/ do painel' : $esperado,
        'status' => 'PASS',
        'critical' => false,
        'aviso' => '',
    );

    if ($atual === '' || $esperado === '' || $atual === $esperado) {
        return $item;
    }

    // O AVISO DIZ O QUE VALE HOJE (15/09/2026). Ele dizia que o .htaccess da raiz
    // nao viajava no pacote e que arquivos ficavam alcancaveis por URL -- verdade
    // antes de 10/09. Desde entao o .htaccess da raiz vem no zip, manda toda
    // requisicao para public/ e o atualizador o troca como qualquer arquivo; cada
    // pasta interna tem a tranca propria. Continua WARN porque o recomendado e o
    // dominio em public/: sem mod_rewrite, so as trancas por pasta seguram.
    $item['status'] = 'WARN';
    $item['aviso'] = 'O servidor esta publicando ' . $atual . ', e o recomendado e ' . $esperado . '. '
        . 'Assim tambem funciona: o .htaccess da raiz, que vem no pacote, manda toda requisicao para public/, '
        . 'e config/, funcoes/ e as outras pastas internas continuam trancadas. Mas se o mod_rewrite for desligado '
        . 'na hospedagem ou esse .htaccess sumir, so as trancas de cada pasta seguram. Quando puder, aponte o '
        . 'dominio para a pasta public/.';

    return $item;
}

/**
 * A tela que precisa passar mesmo com migracao pendente.
 *
 * shield_enforce_installation_guard() manda o painel inteiro para /update/
 * quando ha migracao pendente, e o guarda roda dentro do banco.php -- que o
 * login inclui. Como o /update/ passou a exigir administrador logado
 * (08/09/2026), mandar o login para la trancaria o painel por fora: a tela que
 * DA a sessao ficaria atras da tela que EXIGE a sessao, e o membro nao teria
 * como autorizar a propria atualizacao.
 *
 * Sair entra na mesma lista: nao adianta poder entrar sem poder trocar de
 * conta, e quem cai no /update/ como usuario comum precisa de uma saida.
 *
 * A comparacao e EXATA de proposito. Um str_starts_with('/login') deixaria
 * passar /loginqualquercoisa.php.
 */
function shield_update_login_dispensado($path)
{
    return in_array((string) $path, array('/login.php', '/login', '/logout.php', '/logout'), true);
}

/**
 * A tela deve APLICAR nesta requisicao?
 *
 * Duas condicoes, e cada uma protege de um lado:
 *
 * - ter direito ($portao['pode']) fecha o GET anonimo que aplicava migracao,
 *   criava tabela e reescrevia o config/app.php ate 08/09/2026;
 * - ter PEDIDO (POST com acao=aplicar) impede que uma simples visita do
 *   administrador -- ou um <img src="/update/"> numa pagina qualquer --
 *   dispare a atualizacao sem ele querer.
 *
 * A excecao e a janela da instalacao, que continua aplicando no GET: e para ca
 * que o instalador manda o navegador, ainda nao ha administrador para pedir
 * sessao, e obrigar um clique ali seria transformar um conserto de seguranca
 * em degrau no meio da instalacao de quem nunca viu o painel.
 */
function shield_update_deve_aplicar(array $portao, $metodo, $acao)
{
    if (empty($portao['pode'])) {
        return false;
    }

    if (($portao['motivo'] ?? '') === 'janela_instalacao') {
        return true;
    }

    return strtoupper((string) $metodo) === 'POST' && (string) $acao === 'aplicar';
}
