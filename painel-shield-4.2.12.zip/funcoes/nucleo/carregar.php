<?php

/**
 * O que TODA requisicao do painel carrega -- 03/09/2026.
 *
 * Substitui o antigo funcoes/bootstrap.php, que era a mesma lista sem ordem
 * nenhuma: onze require em sequencia, misturando escape de HTML com motor de
 * pagamento. Aqui a lista continua sendo lista -- o que mudou e que ela diz de
 * que assunto e cada linha, e por que aquele assunto e carregado sempre.
 *
 * SO O QUE E MESMO DE TODA REQUISICAO entra aqui. Foi medido na fase 2: jogar
 * todo o codigo procedural na carga somava 12 ms por requisicao, 130% a mais
 * do que /api/licenca.php gasta hoje -- e essa e a rota que cada caixa chama em
 * cada abertura de loja. Cobranca, licenca, contrato, atualizacao e acesso
 * seguem com require explicito de quem precisa deles.
 *
 * O CARREGADOR DE CLASSES E OUTRO ARQUIVO, nucleo/autoload.php, e ele nao entra
 * nesta lista de proposito: quem o carrega e cada arquivo de src/ que precisa,
 * porque nem toda requisicao toca em classe.
 */

// --- infraestrutura: nao tem dominio, todo mundo usa -----------------------
require_once __DIR__ . '/html.php';      // escape de saida
require_once __DIR__ . '/http.php';      // resposta e redirect
require_once __DIR__ . '/esquema.php';   // versao do painel, coluna existe?

// --- dominio que as telas leem em quase todo lugar -------------------------
require_once __DIR__ . '/../empresa/empresa.php';

// --- o caminho ANTIGO de pagamento SAIU em 10/09/2026 --------------------
//
// funcoes/financeiro/ (pagamentos, mercadopago, cora, gateway) era carregado
// em toda requisicao do painel para atender os webhooks e as telas de
// gateway do motor antigo, da tabela `pedido`. O motor novo nao depende de
// nada dali. A cifra do serial legado (cryptChave/mudaChave), que tinha ficado
// aqui depois disso em licenca/serial_legado.php, saiu em 01/10/2026 junto com a
// tela "Gerar serial": o painel nao libera mais o ERP antigo por contra-senha, e
// o caminho sem internet e a licenca em arquivo.
