<?php

// Versao do CODIGO do painel - 25/08/2026.
//
// Este arquivo viaja com o codigo, e e o unico lugar que diz qual versao esta
// instalada. NAO confundir com:
//
//   config/app.php -> 'app_version'   e da INSTALACAO, escrito pelo instalador
//                                     e nunca mais tocado. Nao acompanha o
//                                     codigo que chega pela atualizacao.
//   shield_system_meta.db_version     e do BANCO, movido pelas migracoes.
//
// Quem decide se ha atualizacao e ESTE numero contra o do manifesto -- data de
// arquivo nao serve (relogio de servidor errado nunca mais atualizaria) e
// versao de banco nao serve (as duas andam em ritmos diferentes).
//
// A comparacao usa os TRES primeiros numeros; o que vier depois e rotulo de
// bancada e nao entra na conta.

if (!defined('SHIELD_VERSAO')) {
    define('SHIELD_VERSAO', '4.2.12');
}

/** So os tres numeros, para a tela. O rotulo de bancada nao e para o membro ver. */
if (!function_exists('shield_versao_exibida')) {
    function shield_versao_exibida()
    {
        return preg_match('/^\d+\.\d+\.\d+/', (string) SHIELD_VERSAO, $m) ? $m[0] : (string) SHIELD_VERSAO;
    }
}
