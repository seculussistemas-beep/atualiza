<?php

/**
 * A data zerada em SQL, num lugar so -- 16/09/2026.
 *
 * O painel nao grava '0000-00-00' em lugar nenhum: ele COMPARA com ela, porque
 * o cadastro legado do ERP grava a data zerada onde o painel grava NULL, e as
 * duas querem dizer a mesma coisa -- "sem licenca". Onze consultas faziam essa
 * comparacao escrevendo o literal ao lado da coluna.
 *
 * E AI ESTA O DEFEITO, e ele nao e de logica: com NO_ZERO_DATE ou
 * NO_ZERO_IN_DATE na sessao (o padrao do MySQL 8.0 e do 8.4), o servidor
 * converte esse literal para DATE ao PREPARAR a consulta e recusa -- 1525 na
 * leitura, 1292 no UPDATE --, com a tabela vazia, antes de ler linha nenhuma.
 * O ajuste de sessao de shield_create_pdo_connection (4.1.28) tira os dois
 * modos e cura, mas so enquanto o servidor aceitar o `SET SESSION`. Onde ele e
 * recusado o estrago e calado e caro: medido em MySQL 8.4, o pagamento e
 * confirmado e a validade NAO anda (o UPDATE de shield_validade_estender cai no
 * 1292 e o livro fica com `validade_nao_estendida`), e a varredura do
 * encerramento devolve zero porque o 1525 cai no catch de "base sem coluna".
 *
 * A CURA E NAO PEDIR A CONVERSAO. Comparando texto com texto -- CAST da coluna
 * para CHAR(10) -- nao ha literal de data para o servidor validar, e a resposta
 * e a mesma no MariaDB 10.11, no MySQL 8.0 e no 8.4, com os modos ligados ou
 * desligados. O CHAR(10) tambem corta a hora, entao a mesma expressao serve a
 * coluna `date` e a `datetime` que guarde a data zerada.
 *
 * NAO ha indice a perder: `empresa` tem indice em codigo e fechamento_chave --
 * nunca em validade_licenca --, e toda consulta daqui ja varria a
 * tabela. O caminho quente (a API de licenca) nao compara com a data zerada em
 * SQL; ela decide em PHP, com o valor ja lido.
 *
 * SO A COMPARACAO MUDA. "Sem validade" continua sendo NULL OU zerada, e
 * "com validade" o contrario exato, como as onze consultas sempre disseram.
 */

if (!function_exists('shield_sql_data_zerada')) {
    /** A coluna guarda a data zerada. Texto contra texto, nunca data. */
    function shield_sql_data_zerada($coluna)
    {
        return 'CAST(' . $coluna . " AS CHAR(10)) = '0000-00-00'";
    }

    /** Sem licenca: NULL ou zerada -- as duas coisas que o cadastro usa para dizer o mesmo. */
    function shield_sql_sem_validade($coluna)
    {
        return '(' . $coluna . ' IS NULL OR ' . shield_sql_data_zerada($coluna) . ')';
    }

    /** Tem validade: o contrario exato de shield_sql_sem_validade. */
    function shield_sql_com_validade($coluna)
    {
        return '(' . $coluna . ' IS NOT NULL AND CAST(' . $coluna . " AS CHAR(10)) <> '0000-00-00')";
    }

    /**
     * A validade, ou NULL quando ela e zerada -- para entrar num COALESCE.
     *
     * Devolve TEXTO ('AAAA-MM-DD'), e nao DATE: e o que mantem o literal fora
     * do caminho. GREATEST e DATE_ADD trabalham com essa string do mesmo jeito
     * (a ordem lexicografica de AAAA-MM-DD e a ordem das datas), e o
     * `INTERVAL n MONTH` continua grampeando o fim do mes -- 31/01 mais um mes
     * da 28/02, conferido nos tres servidores.
     */
    function shield_sql_validade_ou_nulo($coluna)
    {
        return 'NULLIF(CAST(' . $coluna . " AS CHAR(10)), '0000-00-00')";
    }
}
