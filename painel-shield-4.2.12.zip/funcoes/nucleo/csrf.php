<?php

/**
 * Token anti-CSRF -- 04/09/2026.
 *
 * Fecha o ALTO-3 de docs/auditoria-seguranca.md: o painel nao tinha protecao
 * nenhuma contra requisicao forjada de outro site. Vinte e seis telas gravam a
 * partir de POST, e nenhuma conferia de onde o POST veio.
 *
 * O QUE SEGURAVA ATE AQUI era o SameSite=Lax do cookie de sessao, e ele e
 * defesa fraca por dois motivos: quem o define e o ambiente, nao a aplicacao --
 * na hospedagem do membro vale o padrao do PHP, que e vazio --, e mesmo quando
 * definido quem aplica e o navegador do administrador. Protecao do painel nao
 * deveria depender de qual navegador o admin abriu.
 *
 * POR QUE INJETAR EM VEZ DE EDITAR OS 26 FORMULARIOS: o campo escondido entra
 * por um filtro de saida no router (shield_csrf_injetar), e nao a mao arquivo
 * por arquivo. Editar 26 telas e um trabalho que ERRA POR OMISSAO -- basta
 * esquecer um formulario para aquela tela quebrar em producao, e o sintoma
 * (botao que nao faz nada) nao aponta para o CSRF. O filtro nao esquece, e
 * formulario novo nasce protegido sem ninguem lembrar de nada.
 *
 * UM TOKEN POR SESSAO, e nao por formulario. Token por formulario protege
 * marginalmente mais e quebra o basico: o membro que abre duas abas do painel
 * teria a primeira invalidada pela segunda.
 */

const SHIELD_CSRF_CAMPO = '_csrf';
const SHIELD_CSRF_CABECALHO = 'HTTP_X_CSRF_TOKEN';

/**
 * O token da sessao. Cria na primeira chamada.
 *
 * Inicia a sessao se ainda nao houver: este arquivo e chamado pelo router,
 * antes de a tela decidir se precisa de sessao, e sem ela nao ha onde guardar.
 */
function shield_csrf_token(): string
{
    require_once __DIR__ . '/sessao.php';
    shield_sessao_abrir();

    if (empty($_SESSION[SHIELD_CSRF_CAMPO])) {
        $_SESSION[SHIELD_CSRF_CAMPO] = bin2hex(random_bytes(32));
    }

    return (string) $_SESSION[SHIELD_CSRF_CAMPO];
}

/**
 * O POST atual traz um token que confere?
 *
 * Aceita no corpo (formulario) ou no cabecalho X-CSRF-Token (chamada por
 * JavaScript, que nao passa por formulario nenhum).
 *
 * hash_equals e nao ===: comparacao de segredo em tempo constante.
 */
function shield_csrf_valido(): bool
{
    $esperado = shield_csrf_token();

    $recebido = (string) ($_POST[SHIELD_CSRF_CAMPO] ?? '');
    if ($recebido === '') {
        $recebido = (string) ($_SERVER[SHIELD_CSRF_CABECALHO] ?? '');
    }

    return $recebido !== '' && hash_equals($esperado, $recebido);
}

/**
 * Campo escondido, para quem quiser por a mao no proprio formulario.
 */
function shield_csrf_campo(): string
{
    return '<input type="hidden" name="' . SHIELD_CSRF_CAMPO . '" value="'
        . htmlspecialchars(shield_csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
}

/**
 * Liga a protecao nesta pagina: recusa POST sem token e injeta o campo na saida.
 *
 * O router chama isto para toda rota (ver shield_csrf_guardar_rota). As telas
 * de install/ e update/ chamam direto, porque elas NAO passam pelo router --
 * sao pasta servida pelo .htaccess, e o gancho do router nao as alcanca.
 *
 * Sem isto o setup.php ficava de fora, e ele e a tela que cria a conta do
 * ADMINISTRADOR no primeiro acesso: um POST forjado durante a instalacao
 * definiria a senha do admin.
 */
function shield_csrf_proteger(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && !shield_csrf_valido()) {
        http_response_code(403);
        header('Content-Type: text/html; charset=utf-8');
        echo '<h1>Sessao expirada</h1>'
            . '<p>O formulario foi enviado com um codigo de seguranca invalido ou vencido. '
            . 'Isso costuma acontecer quando a pagina ficou aberta por muito tempo.</p>'
            . '<p>Volte, recarregue a tela e envie de novo.</p>';
        exit;
    }

    ob_start('shield_csrf_injetar');
}

/**
 * Desliga o filtro de saida antes de transmitir arquivo.
 *
 * O filtro trabalha sobre a resposta INTEIRA, entao ele segura na memoria tudo
 * o que a tela escrever. Para HTML isso e alguns kilobytes; para um download --
 * o instalador, um zip de log, um arquivo de licenca -- seria o arquivo todo,
 * e um instalador de dezenas de megabytes bateria no memory_limit.
 *
 * Quem vai transmitir chama isto antes do primeiro header de download. E
 * seguro chamar mesmo sem filtro aberto.
 */
function shield_csrf_sem_filtro(): void
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
}

/**
 * Filtro de saida: poe o campo escondido em todo formulario POST da pagina.
 *
 * Roda como callback de ob_start(), entao recebe o HTML pronto e devolve o
 * HTML alterado.
 *
 * NAO mexe em formulario que posta para OUTRO dominio -- ali o token nao teria
 * uso e ainda vazaria o segredo da sessao para terceiro. Hoje nao existe
 * nenhum no painel; a guarda esta aqui para o dia em que existir.
 *
 * Resposta que nao tem formulario nenhum volta intacta, sem custo -- e o caso
 * do JSON que algumas rotas devolvem.
 */
function shield_csrf_injetar(string $html): string
{
    if (stripos($html, '<form') === false) {
        return $html;
    }

    $campo = shield_csrf_campo();

    // A ETIQUETA SO FECHA NO `>` QUE ESTA FORA DE ASPAS -- 09/09/2026.
    //
    // Antes esta busca era `<form\b[^>]*>`, que parava no PRIMEIRO `>`. Um
    // atributo com `>` dentro -- um `onsubmit` com `n>0`, um `data-` qualquer --
    // fazia o campo escondido ser enfiado NO MEIO do atributo, e o resto virava
    // texto visivel na tela do membro.
    //
    // Nao e defeito de quem escreveu o atributo: `>` e valido dentro de valor
    // de atributo, e o filtro roda sobre a resposta INTEIRA de toda tela do
    // painel. Errar aqui nao quebra um formulario, quebra a pagina -- e o
    // sintoma nao aponta para o CSRF.
    //
    // O que a alternancia diz: ou um caractere que nao e aspas nem `>`, ou um
    // trecho entre aspas duplas, ou um entre aspas simples. Assim o `>` dentro
    // das aspas e engolido junto com elas.
    return (string) preg_replace_callback(
        '#<form\b(?:[^>"\']|"[^"]*"|\'[^\']*\')*>#i',
        static function (array $m) use ($campo): string {
            $tag = $m[0];

            // Formulario sem method= e GET por padrao; so POST precisa.
            if (!preg_match('#\bmethod\s*=\s*["\']?\s*post#i', $tag)) {
                return $tag;
            }

            // action apontando para outro dominio: nao injeta.
            if (preg_match('#\baction\s*=\s*["\']([^"\']*)["\']#i', $tag, $a)) {
                $destino = trim($a[1]);
                if ($destino !== '' && preg_match('#^(https?:)?//#i', $destino)) {
                    $host = parse_url($destino, PHP_URL_HOST);
                    if ($host !== null && strcasecmp((string) $host, (string) ($_SERVER['HTTP_HOST'] ?? '')) !== 0) {
                        return $tag;
                    }
                }
            }

            return $tag . $campo;
        },
        $html
    );
}
