<?php

// Ajudantes de esquema e versao - 25/08/2026.
//
// Estas duas funcoes moravam em funcoes/representantes.php e
// funcoes/financeiro.php, que sairam na Fase 1. Nao tem nada a ver com
// representante nem com financeiro: uma pergunta se a coluna existe e a outra
// diz a versao do painel. Ficaram orfas do arquivo errado e vieram para ca.
//
// NAO devolver estas funcoes para arquivo de modulo: o painel inteiro depende
// delas e modulo e coisa que sai.

if (!function_exists('shield_column_exists')) {
    function shield_column_exists(PDO $pdo, $table, $column)
    {
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table_name AND COLUMN_NAME = :column_name'
        );
        $stmt->execute([
            ':table_name' => (string) $table,
            ':column_name' => (string) $column,
        ]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

if (!function_exists('shield_versao_do_painel')) {
    // Chamava-se shield_fin_db_version_label. O prefixo _fin_ era heranca do
    // arquivo onde ela por acaso morava; quem a le e o rodape, a tela de login
    // e -- daqui para frente -- o motor de atualizacao. Nome novo, mesma conta.
    function shield_versao_do_painel(?PDO $pdo = null)
    {
        $dbVersion = '';

        if (!$pdo instanceof PDO && isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) {
            $pdo = $GLOBALS['pdo'];
        }

        if ($pdo instanceof PDO) {
            try {
                if (function_exists('shield_get_system_meta')) {
                    $dbVersion = trim((string) shield_get_system_meta($pdo, 'db_version', ''));
                } else {
                    $stmt = $pdo->query(
                        "SELECT meta_value FROM shield_system_meta WHERE meta_key = 'db_version' LIMIT 1"
                    );
                    $dbVersion = trim((string) $stmt->fetchColumn());
                }
            } catch (Throwable $ignored) {
                $dbVersion = '';
            }
        }

        if ($dbVersion === '' && function_exists('shield_load_app_config')) {
            $appConfig = shield_load_app_config();
            $dbVersion = trim((string) ($appConfig['app_version'] ?? ''));
        }

        if ($dbVersion === '') {
            $dbVersion = '0.0.0';
        }

        return $dbVersion;
    }
}
