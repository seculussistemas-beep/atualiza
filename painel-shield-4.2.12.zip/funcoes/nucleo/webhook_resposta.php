<?php

// A resposta dos webhooks -- 08/09/2026.
//
// Os cinco webhooks antigos (asaas, cora, efi, mercadopago, pagseguro)
// terminavam com o par solto `http_response_code(); echo json_encode();`, e
// abriam com um header('Content-Type') ANTES dos require. Nessa ordem, um
// unico byte escapado -- um Warning, um Deprecated, um BOM em arquivo incluido
// -- faz o PHP transmitir os cabecalhos ja enfileirados, com 200, e o
// http_response_code() do fim nao tem mais efeito.
//
// O estrago nao e o JSON sujo: e o 200. Recebendo 200, o gateway marca o aviso
// como entregue e NAO REENVIA. Um pagamento que falhou de verdade some sem uma
// linha de log dizendo por que -- e o cliente fica com a licenca vencida
// tendo pago.
//
// Por isso a resposta passa a sair de um lugar so: drena o buffer (jogando
// fora o que tenha escapado), confere que ainda da para falar, e so entao
// emite cabecalho e status. Mesmo desenho de public/webhooks/cobranca.php e de
// public/api/licenca.php, que ja faziam certo.
//
// public/webhooks/cobranca.php mantem o responder proprio: a assinatura dele e
// outra (texto, nao estrutura) e ele ja esta correto -- reescrever caminho de
// dinheiro que funciona so para unificar nome de funcao e risco sem troco.

/**
 * Fecha a resposta de um webhook: status, cabecalhos e corpo JSON.
 *
 * ENCERRA A REQUISICAO. Depois de responder ao gateway nao ha mais nada a
 * fazer, e qualquer byte que viesse a seguir sujaria o corpo que acabou de
 * sair.
 *
 * @param int   $http  status HTTP a devolver
 * @param mixed $corpo qualquer coisa que o json_encode saiba serializar
 */
function shield_webhook_responder($http, $corpo)
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    // headers_sent() so e falso porque o buffer segurou tudo ate aqui. Se
    // ainda assim algo escapou (saida antes do ob_start, por exemplo), nao da
    // para consertar o status -- resta nao piorar, entregando o corpo.
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        http_response_code((int) $http);
    }

    echo json_encode($corpo);
    exit;
}
