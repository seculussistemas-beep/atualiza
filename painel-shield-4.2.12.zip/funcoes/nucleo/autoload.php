<?php

// Carregador PSR-4 do codigo novo - 25/08/2026.
//
// O painel inteiro e require_once, e continua sendo: o velho fica como esta ate
// ser tocado. O que nasce daqui para frente -- comecando pelos adaptadores de
// provedor de pagamento -- mora em src/ com namespace.
//
// A MAO, e nao pelo composer, de proposito: o membro sobe o painel por FTP com
// a pasta pronta, e nao roda `composer dump-autoload` do outro lado. Um
// autoload gerado que ficasse desatualizado quebraria a instalacao dele com um
// erro que nao diz nada -- classe nao encontrada, sem pista de por que.
//
// Sao quinze linhas e nao tem cache: em painel deste tamanho o custo e um
// file_exists por classe, e o previsivel vale mais do que o rapido aqui.

spl_autoload_register(static function ($classe) {
    $prefixo = 'Shield' . chr(92);
    if (strncmp($classe, $prefixo, strlen($prefixo)) !== 0) {
        return;
    }

    $relativo = substr($classe, strlen($prefixo));
    $caminho = dirname(__DIR__, 2) . '/src/' . str_replace(chr(92), '/', $relativo) . '.php';

    if (is_file($caminho)) {
        require_once $caminho;
    }
});
